function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $step_0$({$: "Nil"});
}

function $step_0$(_previous_0) {
  return $done_0$(_previous_0, {$: "Item", "label": {$: "Spawn"}, "value": ($$$$047deferred$045assembly$045v1$047fixture$058run$({$: "../deferred-assembly-v1/fixture.Spawns"}, false))});
}

function $done_0$(_previous_0, _value_0) {
  return $step_1$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047deferred$045assembly$045v1$047fixture$058run$(_mode_0, _fail_0) {
  return $$$$047deferred$045assembly$045v1$047fixture$058created$(_mode_0, _fail_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058factory$()), {$: "../deferred-assembly-v1/assembly.Mail", "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(100)), "retired": {$: "Nil"}, "returned": {$: "Nil"}, "errors": {$: "Nil"}})));
}

function $step_1$(_previous_0) {
  return $done_1$(_previous_0, {$: "Item", "label": {$: "Insert"}, "value": ($$$$047deferred$045assembly$045v1$047fixture$058run$({$: "../deferred-assembly-v1/fixture.Inserts"}, false))});
}

function $$$$047deferred$045assembly$045v1$047fixture$058created$(_mode_0, _fail_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $$$$047deferred$045assembly$045v1$047fixture$058reserved$(_mode_0, _fail_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    const _resource_0 = _result_0["resource"];
    return $$$$047deferred$045assembly$045v1$047fixture$058factory_refused$(($$$$047deferred$045assembly$045v1$047fixture$058mail$(_resource_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(_value_0) {
  return {$: "../../complete-v1/controls.Owner", "value": {$: "../../typed.Number", "value": _value_0}, "sentinel": array_node([_value_0], [((_value_0 + 1) >>> 0)])};
}

function $done_1$(_previous_0, _value_0) {
  return $step_2$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047deferred$045assembly$045v1$047fixture$058reserved$(_mode_0, _fail_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Reserved") {
    const _target_0 = _t_0["handle"];
    return $$$$047deferred$045assembly$045v1$047fixture$058activated$(_mode_0, _fail_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058activate$1261$(_world_0, _target_0)));
  } else {
    return $$$$047deferred$045assembly$045v1$047fixture$058refused_report$(($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047deferred$045assembly$045v1$047fixture$058factory_refused$(_result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "../deferred-assembly-v1/fixture.FactoryRefused", "mail": _view_0};
}

function $$$$047deferred$045assembly$045v1$047fixture$058mail$(_value_0) {
  const _value_1 = _value_0["value"];
  const _retired_0 = _value_0["retired"];
  const _returned_0 = _value_0["returned"];
  const _errors_0 = _value_0["errors"];
  return $$$$047deferred$045assembly$045v1$047fixture$058mail_join$(_errors_0, ($$$$047$$$047adoption$045v1$047observation$058payload$(_value_1)), ($$$$047deferred$045assembly$045v1$047fixture$058payloads$(_retired_0)), ($$$$047deferred$045assembly$045v1$047fixture$058packets$(_returned_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Created", "factory": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047generic$045assembly$045v1$047second$045owner$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $step_2$(_previous_0) {
  return $done_2$(_previous_0, {$: "Item", "label": {$: "Failure"}, "value": ($$$$047deferred$045assembly$045v1$047fixture$058run$({$: "../deferred-assembly-v1/fixture.Spawns"}, true))});
}

function $$$$047deferred$045assembly$045v1$047fixture$058activated$(_mode_0, _fail_0, _target_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Accepted") {
    return $$$$047deferred$045assembly$045v1$047fixture$058seeded$(($$$$047deferred$045assembly$045v1$047fixture$058selected$(_mode_0, _target_0)), _fail_0, ($$$$047deferred$045assembly$045v1$047fixture$058is_invalid$(_mode_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace$1261$(($$$$047generic$045assembly$045v1$047second$045owner$058family$()), ($$$$047deferred$045assembly$045v1$047fixture$058late$(_mode_0, _target_0, _world_0)), _target_0, {$: "Some", "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(10))})));
  } else {
    return $$$$047deferred$045assembly$045v1$047fixture$058refused_report$(($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058refused_report$(_result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "../deferred-assembly-v1/fixture.Report", "before": _view_0, "committed": _view_0, "barrier": _view_0, "instance": {$: "None"}, "result": {$: "../deferred-assembly-v1/fixture.Refused"}};
}

function $$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047deferred$045assembly$045v1$047fixture$058snapshot_join$({$: "../generic-assembly-v1/observation.Meta", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "capacity": _capacity_0, "depth": _depth_0, "events": _events_0, "registrations": _registrations_0, "nextSystemId": _system_0, "clock": _clock_0}, ($$$$047generic$045assembly$045v1$047observation$058bools$(_live_0)), ($$$$047generic$045assembly$045v1$047observation$058column$1260$(_store_0)), ($$$$047deferred$045assembly$045v1$047fixture$058mail$(_resource_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058mail_join$(_errors_0, _value_0, _retired_0, _returned_0) {
  const _value_1 = _value_0["fst"];
  const _a_0 = _value_0["snd"];
  const _retired_1 = _retired_0["fst"];
  const _b_0 = _retired_0["snd"];
  const _returned_1 = _returned_0["fst"];
  const _c_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": {$: "../deferred-assembly-v1/assembly.Mail", "value": _value_1, "retired": _retired_1, "returned": _returned_1, "errors": _errors_0}, "snd": {$: "../deferred-assembly-v1/fixture.MailView", "value": _a_0, "retired": _b_0, "returned": _c_0, "errors": _errors_0}};
}

function $$$$047$$$047adoption$045v1$047observation$058payload$(_owner_0) {
  const _raw_0 = _owner_0["value"];
  const _sentinel_0 = _owner_0["sentinel"];
  return $$$$047$$$047adoption$045v1$047observation$058payload_done$(_raw_0, ($$$$047$$$047adoption$045v1$047observation$058array$(_sentinel_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058payloads$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return $$$$047deferred$045assembly$045v1$047fixture$058payloads_join$(($$$$047generic$045assembly$045v1$047observation$058payload$(_head_0)), ($$$$047deferred$045assembly$045v1$047fixture$058payloads$(_tail_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058packets$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return $$$$047deferred$045assembly$045v1$047fixture$058packets_join$(($$$$047deferred$045assembly$045v1$047fixture$058packet$(_head_0)), ($$$$047deferred$045assembly$045v1$047fixture$058packets$(_tail_0)));
  }
}

function $$$$047generic$045assembly$045v1$047second$045owner$058empty$(_unit_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058empty$1260$();
}

function $done_2$(_previous_0, _value_0) {
  return $step_3$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047deferred$045assembly$045v1$047fixture$058seeded$(_operation_0, _fail_0, _invalid_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    return $$$$047deferred$045assembly$045v1$047fixture$058prepared$(_operation_0, _fail_0, _invalid_0, _world_0);
  } else {
    const _world_1 = _result_0["world"];
    return $$$$047deferred$045assembly$045v1$047fixture$058refused_report$(($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_1)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058selected$(_mode_0, _target_0) {
  if (_mode_0.$ === "../deferred-assembly-v1/fixture.Spawns") {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-requests.Spawn"};
  } else if (_mode_0.$ === "../deferred-assembly-v1/fixture.Invalid") {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-requests.Spawn"};
  } else if (_mode_0.$ === "../deferred-assembly-v1/fixture.Inserts") {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-requests.Insert", "target": _target_0};
  } else if (_mode_0.$ === "../deferred-assembly-v1/fixture.LateMissing") {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-requests.Insert", "target": _target_0};
  } else {
    const _foreign_0 = _mode_0["target"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-requests.Insert", "target": _foreign_0};
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058is_invalid$(_mode_0) {
  if (_mode_0.$ === "../deferred-assembly-v1/fixture.Invalid") {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047generic$045assembly$045v1$047second$045owner$058family$() {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$())))};
}

function $$$$047deferred$045assembly$045v1$047fixture$058late$(_mode_0, _target_0, _world_0) {
  if (_mode_0.$ === "../deferred-assembly-v1/fixture.LateMissing") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058enqueue$1261$(_world_0, run_clo((_x_0) => {
  return $$$$047deferred$045assembly$045v1$047fixture$058kill$(_target_0, _x_0);
}));
  } else {
    return _world_0;
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(_value_0) {
  return {$: "../generic-assembly-v1/second-owner.Owner", "raw": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Number", "value": _value_0}, "words": array_node([_value_0], [((_value_0 + 10) >>> 0)]), "flags": array_node([true], [false])};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047deferred$045assembly$045v1$047fixture$058snapshot_join$(_meta_0, _live_0, _column_0, _mail_0, _pending_0) {
  const _ns_0 = _meta_0["namespace"];
  const _next_0 = _meta_0["nextId"];
  const _high_0 = _meta_0["highWater"];
  const _capacity_0 = _meta_0["capacity"];
  const _depth_0 = _meta_0["depth"];
  const _events_0 = _meta_0["events"];
  const _registrations_0 = _meta_0["registrations"];
  const _system_0 = _meta_0["nextSystemId"];
  const _clock_0 = _meta_0["clock"];
  const _live_1 = _live_0["fst"];
  const _a_0 = _live_0["snd"];
  const _column_1 = _column_0["fst"];
  const _b_0 = _column_0["snd"];
  const _mail_1 = _mail_0["fst"];
  const _c_0 = _mail_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _d_0 = _pending_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_1, "capacity": _capacity_0, "depth": _depth_0, "store": _column_1, "resource": _mail_1, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _system_0, "clock": _clock_0}, "snd": {$: "../deferred-assembly-v1/fixture.Snapshot", "meta": {$: "../generic-assembly-v1/observation.Meta", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "capacity": _capacity_0, "depth": _depth_0, "events": _events_0, "registrations": _registrations_0, "nextSystemId": _system_0, "clock": _clock_0}, "live": _a_0, "column": _b_0, "mail": _c_0, "pending": _d_0}};
}

function $$$$047generic$045assembly$045v1$047observation$058bools$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047observation$058bool_join$(($$$$047generic$045assembly$045v1$047observation$058bools$(_left_0)), ($$$$047generic$045assembly$045v1$047observation$058bools$(_right_0)));
  }
}

function $$$$047generic$045assembly$045v1$047observation$058column$1260$(_owner_0) {
  if (_owner_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return $$$$047generic$045assembly$045v1$047observation$058column_done$1260$(_stamps_0, ($$$$047generic$045assembly$045v1$047observation$058slots$(_values_0)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": {$: "../generic-assembly-v1/observation.ColumnView", "supported": false, "slots": {$: "Nil"}, "stamps": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Reserved", "handle": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047adoption$045v1$047observation$058payload_done$(_raw_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _cells_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../complete-v1/controls.Owner", "value": _raw_0, "sentinel": _owner_0}, "snd": {$: "../../adoption-v1/observation.PayloadView", "raw": _raw_0, "sentinel": _cells_0}};
}

function $$$$047$$$047adoption$045v1$047observation$058array$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047$$$047adoption$045v1$047observation$058joined$(($$$$047$$$047adoption$045v1$047observation$058array$(_left_0)), ($$$$047$$$047adoption$045v1$047observation$058array$(_right_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058payloads_join$(_head_0, _tail_0) {
  const _head_1 = _head_0["fst"];
  const _a_0 = _head_0["snd"];
  const _tail_1 = _tail_0["fst"];
  const _b_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_1, "tail": _tail_1}, "snd": {$: "Con", "head": _a_0, "tail": _b_0}};
}

function $$$$047generic$045assembly$045v1$047observation$058payload$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _words_0 = _owner_0["words"];
  const _flags_0 = _owner_0["flags"];
  return $$$$047generic$045assembly$045v1$047observation$058payload_done$(_raw_0, ($$$$047generic$045assembly$045v1$047observation$058array$(_words_0)), ($$$$047generic$045assembly$045v1$047observation$058bools$(_flags_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058packets_join$(_head_0, _tail_0) {
  const _head_1 = _head_0["fst"];
  const _a_0 = _head_0["snd"];
  const _tail_1 = _tail_0["fst"];
  const _b_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_1, "tail": _tail_1}, "snd": {$: "Con", "head": _a_0, "tail": _b_0}};
}

function $$$$047deferred$045assembly$045v1$047fixture$058packet$(_value_0) {
  const _owner_0 = _value_0["owner"];
  const _original_0 = _value_0["original"];
  const _canonical_0 = _value_0["canonical"];
  return $$$$047deferred$045assembly$045v1$047fixture$058packet_join$(_original_0, _canonical_0, ($$$$047generic$045assembly$045v1$047observation$058option$(_owner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058empty$1260$() {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $step_3$(_previous_0) {
  return $done_3$(_previous_0, {$: "Item", "label": {$: "Foreign"}, "value": ($$$$047deferred$045assembly$045v1$047fixture$058foreign$())});
}

function $$$$047deferred$045assembly$045v1$047fixture$058prepared$(_operation_0, _fail_0, _invalid_0, _world_0) {
  return $$$$047deferred$045assembly$045v1$047fixture$058registered$(_operation_0, _fail_0, _invalid_0, ($$$$047deferred$045assembly$045v1$047fixture$058define$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058enqueue$1261$(($$$$047deferred$045assembly$045v1$047fixture$058marked$(_world_0)), run_clo((_x_0) => {
  return $$$$047deferred$045assembly$045v1$047fixture$058marked$(_x_0);
}))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058key$1260$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047generic$045assembly$045v1$047second$045owner$058identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058component$1260$("second-owner");
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047deferred$045assembly$045v1$047fixture$058kill$(_target_0, _world_0) {
  return $$$$047deferred$045assembly$045v1$047fixture$058dead$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058deactivate$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Rejected", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Accepted"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047generic$045assembly$045v1$047observation$058bool_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047generic$045assembly$045v1$047observation$058column_done$1260$(_stamps_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _owner_0, "stamps": _stamps_0}, "snd": {$: "../generic-assembly-v1/observation.ColumnView", "supported": true, "slots": _view_0, "stamps": _stamps_0}};
}

function $$$$047generic$045assembly$045v1$047observation$058slots$(_owner_0) {
  if (_owner_0.length === 1) {
    const _owner_1 = _owner_0[0];
    return $$$$047generic$045assembly$045v1$047observation$058leaf$(($$$$047generic$045assembly$045v1$047observation$058option$(_owner_1)));
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047observation$058slot_join$(($$$$047generic$045assembly$045v1$047observation$058slots$(_left_0)), ($$$$047generic$045assembly$045v1$047observation$058slots$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047$$$047adoption$045v1$047observation$058joined$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047generic$045assembly$045v1$047observation$058payload_done$(_raw_0, _result_0, _flagged_0) {
  const _owner_0 = _result_0["fst"];
  const _cells_0 = _result_0["snd"];
  const _flags_0 = _flagged_0["fst"];
  const _view_0 = _flagged_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/second-owner.Owner", "raw": _raw_0, "words": _owner_0, "flags": _flags_0}, "snd": {$: "../generic-assembly-v1/observation.PayloadView", "raw": _raw_0, "words": _cells_0, "flags": _view_0}};
}

function $$$$047generic$045assembly$045v1$047observation$058array$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047observation$058joined$(($$$$047generic$045assembly$045v1$047observation$058array$(_left_0)), ($$$$047generic$045assembly$045v1$047observation$058array$(_right_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058packet_join$(_original_0, _canonical_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Packet", "owner": _owner_0, "original": _original_0, "canonical": _canonical_0}, "snd": {$: "../deferred-assembly-v1/fixture.PacketView", "owner": _view_0, "original": _original_0, "canonical": _canonical_0}};
}

function $$$$047generic$045assembly$045v1$047observation$058option$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047generic$045assembly$045v1$047observation$058some$(($$$$047generic$045assembly$045v1$047observation$058payload$(_owner_1)));
  }
}

function $done_3$(_previous_0, _value_0) {
  return $step_4$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047deferred$045assembly$045v1$047fixture$058foreign$() {
  return $$$$047deferred$045assembly$045v1$047fixture$058foreign_created$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058factory$()), {$: "../deferred-assembly-v1/assembly.Mail", "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(100)), "retired": {$: "Nil"}, "returned": {$: "Nil"}, "errors": {$: "Nil"}})));
}

function $$$$047deferred$045assembly$045v1$047fixture$058registered$(_operation_0, _fail_0, _invalid_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Registered") {
    const _world_0 = _result_0["world"];
    const _local_0 = _result_0["instance"];
    return $$$$047deferred$045assembly$045v1$047fixture$058observed$(_operation_0, _fail_0, _invalid_0, ($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_0)), _local_0);
  } else {
    const _world_1 = _result_0["world"];
    return $$$$047deferred$045assembly$045v1$047fixture$058refused_report$(($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_1)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058define$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045local$058registered$1261$(_world_0, "declared-deferred-owned", ($$$$047deferred$045assembly$045v1$047assembly$058access$1260$()), {$: "../deferred-assembly-v1/fixture.State", "codec": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047persistence$045declaration$058constructed$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Integer"})), "recoveries": {$: "Nil"}});
}

function $$$$047deferred$045assembly$045v1$047fixture$058marked$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "Unit"}, "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058component$1260$(_key_0) {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047deferred$045assembly$045v1$047fixture$058dead$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058set_live_join$1261$(false, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047generic$045assembly$045v1$047observation$058leaf$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": {$: "Con", "head": _view_0, "tail": {$: "Nil"}}};
}

function $$$$047generic$045assembly$045v1$047observation$058slot_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047generic$045assembly$045v1$047observation$058joined$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047generic$045assembly$045v1$047observation$058some$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _view_0}};
}

function $step_4$(_previous_0) {
  return $done_4$(_previous_0, {$: "Item", "label": {$: "LateMissing"}, "value": ($$$$047deferred$045assembly$045v1$047fixture$058run$({$: "../deferred-assembly-v1/fixture.LateMissing"}, false))});
}

function $$$$047deferred$045assembly$045v1$047fixture$058foreign_created$(_result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _world_0 = _result_0["world"];
    return $$$$047deferred$045assembly$045v1$047fixture$058foreign_reserved$(_factory_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    const _resource_0 = _result_0["resource"];
    return $$$$047deferred$045assembly$045v1$047fixture$058factory_refused$(($$$$047deferred$045assembly$045v1$047fixture$058mail$(_resource_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058observed$(_operation_0, _fail_0, _invalid_0, _world_0, _local_0) {
  const _world_1 = _world_0["fst"];
  const _before_0 = _world_0["snd"];
  return $$$$047deferred$045assembly$045v1$047fixture$058ran$(_before_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058run$1261$(_local_0, _world_1, {$: "../deferred-assembly-v1/fixture.Args", "operation": _operation_0, "first": ($$$$047deferred$045assembly$045v1$047fixture$058incoming$(11, _invalid_0)), "second": ($$$$047deferred$045assembly$045v1$047fixture$058incoming$(22, _invalid_0)), "fail": _fail_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045local$058registered$1261$(_world_0, _name_0, _access_0, _local_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058register$1261$(_world_0, _name_0, _access_0, _local_0);
}

function $$$$047deferred$045assembly$045v1$047assembly$058access$1260$() {
  return $List$append$(($$$$047deferred$045assembly$045v1$047assembly$058names$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045query$045declaration$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045query$045declaration$058write$1260$()))))), {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058key$1261$(($$$$047deferred$045assembly$045v1$047fixture$058resource_identity$()))), "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047persistence$045declaration$058constructed$1260$(_codec_0) {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/persistence-declaration.Constructed", "codec": _codec_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $done_4$(_previous_0, _value_0) {
  return $step_5$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047deferred$045assembly$045v1$047fixture$058foreign_reserved$(_factory_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Reserved") {
    const _target_0 = _t_0["handle"];
    return $$$$047deferred$045assembly$045v1$047fixture$058created$({$: "../deferred-assembly-v1/fixture.ForeignTarget", "target": _target_0}, false, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058create$1261$(_factory_0, {$: "../deferred-assembly-v1/assembly.Mail", "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(100)), "retired": {$: "Nil"}, "returned": {$: "Nil"}, "errors": {$: "Nil"}})));
  } else {
    return $$$$047deferred$045assembly$045v1$047fixture$058refused_report$(($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058ran$(_before_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Completed") {
    const _world_0 = _result_0["world"];
    const _local_0 = _result_0["instance"];
    const _t_0 = _result_0["result"];
    if (_t_0.$ === "Done") {
      const _outputs_0 = _t_0["value"];
      return $$$$047deferred$045assembly$045v1$047fixture$058completed$(_before_0, _world_0, ($$$$047deferred$045assembly$045v1$047fixture$058instance$(_local_0)), ($$$$047deferred$045assembly$045v1$047fixture$058operations$(_outputs_0)));
    } else {
      return $$$$047deferred$045assembly$045v1$047fixture$058failed$(_before_0, _world_0, ($$$$047deferred$045assembly$045v1$047fixture$058instance$(_local_0)));
    }
  } else {
    const _world_1 = _result_0["world"];
    const _local_1 = _result_0["instance"];
    const _args_0 = _result_0["args"];
    return $$$$047deferred$045assembly$045v1$047fixture$058invocation_refused$(_before_0, _world_1, ($$$$047deferred$045assembly$045v1$047fixture$058instance$(_local_1)), ($$$$047deferred$045assembly$045v1$047fixture$058args_view$(_args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058run$1261$(_instance_0, _world_0, _args_0) {
  const _namespace_0 = _instance_0["namespace"];
  const _id_0 = _instance_0["id"];
  const _name_0 = _instance_0["name"];
  const _access_0 = _instance_0["access"];
  const _local_0 = _instance_0["local"];
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058checked$1261$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _args_0);
}

function $$$$047deferred$045assembly$045v1$047fixture$058incoming$(_value_0, _invalid_0) {
  if (!_invalid_0) {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(_value_0);
  } else {
    return {$: "../generic-assembly-v1/second-owner.Owner", "raw": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Text", "value": "invalid-integer"}, "words": array_node([_value_0], [((_value_0 + 10) >>> 0)]), "flags": array_node([true], [false])};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058register$1261$(_world_0, _name_0, _access_0, _local_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058register_named$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0, _local_0);
}

function $$$$047deferred$045assembly$045v1$047assembly$058names$1260$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _tail_0 = _clauses_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047deferred$045assembly$045v1$047assembly$058names$1260$(_tail_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045query$045declaration$058clauses$1260$(_declaration_0) {
  const _clauses_0 = _declaration_0["clauses"];
  return _clauses_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045query$045declaration$058write$1260$() {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/ordinary-query-declaration.Declaration", "grant": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058write_family$1260$()), "select": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058family_match$1260$(_x_0);
}), "clauses": {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$()))), "mode": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/ordinary-query-declaration.Write"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058key$1261$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047deferred$045assembly$045v1$047fixture$058resource_identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058component$1261$("decoded-resource");
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replaced$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $step_5$(_previous_0) {
  return $done_5$(_previous_0, {$: "Item", "label": {$: "Invalid"}, "value": ($$$$047deferred$045assembly$045v1$047fixture$058run$({$: "../deferred-assembly-v1/fixture.Invalid"}, false))});
}

function $$$$047deferred$045assembly$045v1$047fixture$058completed$(_before_0, _world_0, _instance_0, _outputs_0) {
  const _view_0 = _instance_0["snd"];
  const _views_0 = _outputs_0["snd"];
  return $$$$047deferred$045assembly$045v1$047fixture$058report$(_before_0, _view_0, {$: "../deferred-assembly-v1/fixture.Completed", "outputs": _views_0}, ($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058instance$(_value_0) {
  const _ns_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _t_0 = _value_0["local"];
  const _codec_0 = _t_0["codec"];
  const _entries_0 = _t_0["recoveries"];
  return $$$$047deferred$045assembly$045v1$047fixture$058instance_join$(_ns_0, _id_0, _name_0, _access_0, _codec_0, ($$$$047deferred$045assembly$045v1$047fixture$058recoveries$(_entries_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058operations$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return $$$$047deferred$045assembly$045v1$047fixture$058operations_join$(($$$$047deferred$045assembly$045v1$047fixture$058operation$(_head_0)), ($$$$047deferred$045assembly$045v1$047fixture$058operations$(_tail_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058failed$(_before_0, _world_0, _instance_0) {
  const _view_0 = _instance_0["snd"];
  return $$$$047deferred$045assembly$045v1$047fixture$058report$(_before_0, _view_0, {$: "../deferred-assembly-v1/fixture.Failed"}, ($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058invocation_refused$(_before_0, _world_0, _local_0, _args_0) {
  const _view_0 = _local_0["snd"];
  const _argView_0 = _args_0["snd"];
  return $$$$047deferred$045assembly$045v1$047fixture$058report$(_before_0, _view_0, {$: "../deferred-assembly-v1/fixture.InvocationRefused", "args": _argView_0}, ($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(_world_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058args_view$(_args_0) {
  const _operation_0 = _args_0["operation"];
  const _first_0 = _args_0["first"];
  const _second_0 = _args_0["second"];
  const _fail_0 = _args_0["fail"];
  return $$$$047deferred$045assembly$045v1$047fixture$058args_join$(_operation_0, _fail_0, ($$$$047generic$045assembly$045v1$047observation$058payload$(_first_0)), ($$$$047generic$045assembly$045v1$047observation$058payload$(_second_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058checked$1261$(_allowed_0, _instance_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Refused", "world": _world_0, "instance": _instance_0, "args": _args_0};
  } else {
    const _namespace_0 = _instance_0["namespace"];
    const _id_0 = _instance_0["id"];
    const _name_0 = _instance_0["name"];
    const _access_0 = _instance_0["access"];
    const _local_0 = _instance_0["local"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058completed$1261$(_namespace_0, _id_0, _name_0, _access_0, ($$$$047deferred$045assembly$045v1$047fixture$058runner$(_world_0, _local_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058register_named$1261$(_named_0, _name_0, _access_0, _local_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058register_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0, _local_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058write_family$1260$() {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058get$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058set$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058family_match$1260$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058selected_join$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/compose.Required"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058get$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058component$1261$(_key_0) {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $done_5$(_previous_0, _value_0) {
  return $step_6$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047deferred$045assembly$045v1$047fixture$058report$(_before_0, _instance_0, _result_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _committed_0 = _observed_0["snd"];
  return $$$$047deferred$045assembly$045v1$047fixture$058barrier_report$(_before_0, _committed_0, _instance_0, _result_0, ($$$$047deferred$045assembly$045v1$047fixture$058snapshot$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058barrier$1260$(_world_0)))));
}

function $$$$047deferred$045assembly$045v1$047fixture$058instance_join$(_ns_0, _id_0, _name_0, _access_0, _codec_0, _result_0) {
  const _recoveries_0 = _result_0["fst"];
  const _views_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Instance", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": {$: "../deferred-assembly-v1/fixture.State", "codec": _codec_0, "recoveries": _recoveries_0}}, "snd": {$: "../deferred-assembly-v1/fixture.InstanceView", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "codec": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047persistence$045declaration$058codec$1260$(_codec_0)), "recoveries": _views_0}};
}

function $$$$047deferred$045assembly$045v1$047fixture$058recoveries$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    return $$$$047deferred$045assembly$045v1$047fixture$058recoveries_join$(($$$$047deferred$045assembly$045v1$047fixture$058recovery$(_head_0)), ($$$$047deferred$045assembly$045v1$047fixture$058recoveries$(_tail_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058operations_join$(_head_0, _tail_0) {
  const _head_1 = _head_0["fst"];
  const _a_0 = _head_0["snd"];
  const _tail_1 = _tail_0["fst"];
  const _b_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_1, "tail": _tail_1}, "snd": {$: "Con", "head": _a_0, "tail": _b_0}};
}

function $$$$047deferred$045assembly$045v1$047fixture$058operation$(_value_0) {
  if (_value_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Accepted") {
    const _target_0 = _value_0["target"];
    const _spawned_0 = _value_0["spawned"];
    const _canonical_0 = _value_0["canonical"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Accepted", "target": _target_0, "spawned": _spawned_0, "canonical": _canonical_0}, "snd": {$: "../deferred-assembly-v1/fixture.AcceptedView", "target": _target_0, "spawned": _spawned_0, "canonical": _canonical_0}};
  } else {
    const _owner_0 = _value_0["owner"];
    const _error_0 = _value_0["error"];
    return $$$$047deferred$045assembly$045v1$047fixture$058refused_join$(_error_0, ($$$$047generic$045assembly$045v1$047observation$058option$(_owner_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058args_join$(_operation_0, _fail_0, _first_0, _second_0) {
  const _first_1 = _first_0["fst"];
  const _a_0 = _first_0["snd"];
  const _second_1 = _second_0["fst"];
  const _b_0 = _second_0["snd"];
  return {$: "Tuple", "fst": {$: "../deferred-assembly-v1/fixture.Args", "operation": _operation_0, "first": _first_1, "second": _second_1, "fail": _fail_0}, "snd": {$: "../deferred-assembly-v1/fixture.ArgsView", "operation": _operation_0, "first": _a_0, "second": _b_0, "fail": _fail_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058completed$1261$(_namespace_0, _id_0, _name_0, _access_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Succeeded") {
    const _world_0 = _outcome_0["world"];
    const _local_0 = _outcome_0["local"];
    const _out_0 = _outcome_0["output"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Completed", "world": _world_0, "instance": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, "result": {$: "Done", "value": _out_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _local_1 = _outcome_0["local"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Completed", "world": _world_1, "instance": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_1}, "result": {$: "Fail", "error": _error_0}};
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058runner$(_world_0, _state_0, _args_0) {
  const _codec_0 = _state_0["codec"];
  const _previous_0 = _state_0["recoveries"];
  return $$$$047deferred$045assembly$045v1$047fixture$058invoked$(_codec_0, _previous_0, ($$$$047deferred$045assembly$045v1$047assembly$058invoke$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045local$058begin_owner$1260$(_world_0, _codec_0)), _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047local$058register_result$1261$(_registered_0, _namespace_0, _name_0, _access_0, _local_0) {
  const _world_0 = _registered_0["fst"];
  const _t_0 = _registered_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Registered") {
    const _id_0 = _t_0["id"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Registered", "world": _world_0, "instance": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}};
  } else {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.RegistrationRejected", "world": _world_0, "local": _local_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_get$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$())))}, _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058set$1260$(_frame_0, _replacement_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_set$1261$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$())))}, _tx_0, _handle_0, _replacement_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058selected_join$1260$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047generic$045assembly$045v1$047second$045owner$058take$(_column_0) {
  return {$: "Tuple", "fst": {$: "Unit"}, "snd": _column_0};
}

function $step_6$(_previous_0) {
  return $done_6$(_previous_0, {$: "Item", "label": {$: "FailedInsert"}, "value": ($$$$047deferred$045assembly$045v1$047fixture$058run$({$: "../deferred-assembly-v1/fixture.Inserts"}, true))});
}

function $$$$047deferred$045assembly$045v1$047fixture$058barrier_report$(_before_0, _committed_0, _instance_0, _result_0, _observed_0) {
  const _barrier_0 = _observed_0["snd"];
  return {$: "../deferred-assembly-v1/fixture.Report", "before": _before_0, "committed": _committed_0, "barrier": _barrier_0, "instance": {$: "Some", "value": _instance_0}, "result": _result_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047persistence$045declaration$058codec$1260$(_declaration_0) {
  const _codec_0 = _declaration_0["codec"];
  return _codec_0;
}

function $$$$047deferred$045assembly$045v1$047fixture$058recoveries_join$(_head_0, _tail_0) {
  const _head_1 = _head_0["fst"];
  const _a_0 = _head_0["snd"];
  const _tail_1 = _tail_0["fst"];
  const _b_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_1, "tail": _tail_1}, "snd": {$: "Con", "head": _a_0, "tail": _b_0}};
}

function $$$$047deferred$045assembly$045v1$047fixture$058recovery$(_value_0) {
  const _outputs_0 = _value_0["outputs"];
  const _payloads_0 = _value_0["packets"];
  return $$$$047deferred$045assembly$045v1$047fixture$058recovery_join$(($$$$047deferred$045assembly$045v1$047fixture$058operations$(_outputs_0)), ($$$$047deferred$045assembly$045v1$047fixture$058packets$(_payloads_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058refused_join$(_error_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Refused", "owner": _owner_0, "error": _error_0}, "snd": {$: "../deferred-assembly-v1/fixture.RefusedView", "owner": _view_0, "error": _error_0}};
}

function $$$$047deferred$045assembly$045v1$047fixture$058invoked$(_codec_0, _previous_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _outputs_0 = _t_0["fst"];
  const _fail_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045local$058finish_deferred$1260$({$: "../deferred-assembly-v1/fixture.State", "codec": _codec_0, "recoveries": _previous_0}, _outputs_0, _owner_0, ($$$$047deferred$045assembly$045v1$047fixture$058outcome$(_fail_0)));
}

function $$$$047deferred$045assembly$045v1$047assembly$058invoke$1260$(_owner_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045local$058begin_owner$1260$(_world_0, _codec_0) {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Owner", "batch": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058begin$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058begin$1261$(_world_0)))), "declaration": _codec_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_get$1260$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
  } else if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _reason_0 = _result_0["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_set$1261$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/compose.Required") {
    if (_value_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/compose.Present") {
    if (_value_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/compose.Absent") {
    if (_value_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_1)), "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $done_6$(_previous_0, _value_0) {
  return $step_7$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058recovery_join$(_outputs_0, _packets_0) {
  const _outputs_1 = _outputs_0["fst"];
  const _a_0 = _outputs_0["snd"];
  const _packets_1 = _packets_0["fst"];
  const _b_0 = _packets_0["snd"];
  return {$: "Tuple", "fst": {$: "../deferred-assembly-v1/fixture.Recovery", "outputs": _outputs_1, "packets": _packets_1}, "snd": {$: "../deferred-assembly-v1/fixture.RecoveryView", "outputs": _a_0, "packets": _b_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045local$058finish_deferred$1260$(_local_0, _output_0, _owner_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045local$058deferred$1260$(_local_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058finish$1260$(_owner_0, _outcome_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058outcome$(_fail_0) {
  if (!_fail_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Success"};
  } else {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Failure", "error": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, _ctx_0) {
  return $$$$047deferred$045assembly$045v1$047fixture$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058begin$1260$(_tx_0) {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047compose$058first_error$(_previous_0, _error_0) {
  if (_previous_0.$ === "None") {
    return {$: "Some", "value": _error_0};
  } else {
    const _previous_1 = _previous_0["value"];
    return {$: "Some", "value": _previous_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.MissingEntity"}}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0) {
  return _column_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $step_7$(_previous_0) {
  return $done_7$(_previous_0, {$: "Item", "label": {$: "FailedInvalid"}, "value": ($$$$047deferred$045assembly$045v1$047fixture$058run$({$: "../deferred-assembly-v1/fixture.Invalid"}, true))});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045local$058deferred$1260$(_local_0, _output_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Committed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Succeeded", "world": _world_0, "local": _local_0, "output": _output_0};
  } else {
    const _world_1 = _result_0["world"];
    const _packets_0 = _result_0["payloads"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/local.Failed", "world": _world_1, "local": ($$$$047deferred$045assembly$045v1$047fixture$058retained$(_local_0, _output_0, _packets_0)), "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058finish$1260$(_owner_0, _outcome_0) {
  const _batch_0 = _owner_0["batch"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058finish$1260$(_batch_0, _outcome_0);
}

function $$$$047deferred$045assembly$045v1$047fixture$058body$1260$(_args_0, _ctx_0) {
  const _operation_0 = _args_0["operation"];
  const _first_0 = _args_0["first"];
  const _second_0 = _args_0["second"];
  const _fail_0 = _args_0["fail"];
  return $$$$047deferred$045assembly$045v1$047fixture$058before_done$1260$(_operation_0, _first_0, _second_0, _fail_0, run_loop($$$$047deferred$045assembly$045v1$047fixture$058resource$1260$(_ctx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(200)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get_store$1260$(_id_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Written", "tx": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.WriteRejected", "tx": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.WriteFailure", "tx": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_replaced$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Rejected", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Rejected", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Rejected", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $done_7$(_previous_0, _value_0) {
  return $List$reverse$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047deferred$045assembly$045v1$047fixture$058retained$(_local_0, _outputs_0, _packets_0) {
  const _codec_0 = _local_0["codec"];
  const _previous_0 = _local_0["recoveries"];
  return {$: "../deferred-assembly-v1/fixture.State", "codec": _codec_0, "recoveries": {$: "Con", "head": {$: "../deferred-assembly-v1/fixture.Recovery", "outputs": _outputs_0, "packets": _packets_0}, "tail": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058finish$1260$(_batch_0, _outcome_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  if (_outcome_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058committed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058tx_finish$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058stage$1260$(($List$reverse$(_prepared_0)), _tx_0)), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Success"})));
  } else {
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058failed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058originals$1260$(($List$reverse$(_prepared_0)))), _error_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Failure", "error": _error_0})));
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058before_done$1260$(_operation_0, _first_0, _second_0, _fail_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  return $$$$047deferred$045assembly$045v1$047fixture$058first_done$1260$(_operation_0, _second_0, _fail_0, run_loop($$$$047deferred$045assembly$045v1$047fixture$058decode$1260$(_ctx_0, _operation_0, _first_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058resource$1260$(_ctx_0, _value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058owned_request$1260$(_ctx_0, _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058view$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_stamp_done$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_replaced$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Rejected", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Rejected", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058committed$1260$(_observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Committed", "world": _world_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058stage$1260$(_prepared_0, _tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058staged$1260$(_prepared_0, ($List$reverse$(_commands_0)), 0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Nil"}, "events": _events_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058failed$1260$(_payloads_0, _error_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Failed", "world": _world_0, "payloads": _payloads_0, "error": _error_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058originals$1260$($0) {
  for (;;) {
    {
      const _prepared_0 = $0;
      if (_prepared_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          continue;
        } else {
          const _payload_0 = _t_0["payload"];
          const _tail_1 = _prepared_0["tail"];
          return {$: "Con", "head": _payload_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058originals$1260$(_tail_1))};
        }
      }
    }
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058first_done$1260$(_operation_0, _second_0, _fail_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _first_0 = _result_0["snd"];
  return $$$$047deferred$045assembly$045v1$047fixture$058second_done$1260$(_first_0, _fail_0, run_loop($$$$047deferred$045assembly$045v1$047fixture$058decode$1260$(_ctx_0, _operation_0, _second_0)));
}

function $$$$047deferred$045assembly$045v1$047fixture$058decode$1260$(_ctx_0, _operation_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058owned_request$1261$(_ctx_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Input", "operation": _operation_0, "owner": _owner_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058owned_request$1260$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058owned_request_field$1260$(($$$$047deferred$045assembly$045v1$047fixture$058resource_field$1260$(($$$$047deferred$045assembly$045v1$047assembly$058grants$1260$())))))(_ctx_0), _input_0);
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_stamp_done$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_observed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058staged$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _prepared_0 = $0;
      const _commands_0 = $1;
      const _current_0 = $2;
      const _tx_0 = $3;
      if (_prepared_0.$ === "Nil") {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058remaining$1260$(_commands_0, _tx_0);
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          $1 = _commands_0;
          $2 = _current_0;
          $3 = _tx_0;
          continue;
        } else {
          const _target_1 = _t_0["target"];
          const _payload_0 = _t_0["payload"];
          const _position_0 = _t_0["position"];
          const _tail_1 = _prepared_0["tail"];
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058staged_after$1260$(_target_1, _payload_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058staged$1260$(_tail_1, _x_0, _position_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058preceding$1260$((_position_0 < _current_0 ? 0 : _position_0 - _current_0), _commands_0, _tx_0)));
        }
      }
    }
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058second_done$1260$(_first_0, _fail_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _second_0 = _result_0["snd"];
  return $$$$047deferred$045assembly$045v1$047fixture$058done$1260$({$: "Con", "head": _first_0, "tail": {$: "Con", "head": _second_0, "tail": {$: "Nil"}}}, _fail_0, run_loop($$$$047deferred$045assembly$045v1$047fixture$058resource$1260$(_ctx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(300)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058owned_request$1261$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058owned_request_field$1261$(($$$$047deferred$045assembly$045v1$047fixture$058decode_field$1260$(($$$$047deferred$045assembly$045v1$047assembly$058grants$1260$())))))(_ctx_0), _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058owned_request_field$1260$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047deferred$045assembly$045v1$047fixture$058resource_field$1260$(_ops_0) {
  const _resource_0 = _ops_0["resource"];
  return _resource_0;
}

function $$$$047deferred$045assembly$045v1$047assembly$058grants$1260$() {
  return {$: "../deferred-assembly-v1/assembly.Ops", "decode": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058grant$1260$()), "resource": ($$$$047deferred$045assembly$045v1$047assembly$058resource_grant$1260$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058rollback$1262$(_undo_0, _world_0)), "outcome": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058remaining$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _tx_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _tx_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058staged_after$1260$(_target_0, _payload_0, _next_0, _result_0) {
  const _after_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return run_tail(_next_0(_after_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045delivery$058enqueue$1260$(_before_0, _target_0, _payload_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058preceding$1260$($0, $1, $2) {
  for (;;) {
    {
      const _count_0 = $0;
      const _commands_0 = $1;
      const _tx_0 = $2;
      if (_count_0 === 0) {
        return {$: "Tuple", "fst": _commands_0, "snd": _tx_0};
      } else {
        const _rest_0 = (_count_0 - 1);
        if (_commands_0.$ === "Nil") {
          return {$: "Tuple", "fst": {$: "Nil"}, "snd": _tx_0};
        } else {
          const _command_0 = _commands_0["head"];
          const _tail_0 = _commands_0["tail"];
          $0 = _rest_0;
          $1 = _tail_0;
          $2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0));
          continue;
        }
      }
    }
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058done$1260$(_outputs_0, _fail_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": _outputs_0, "snd": _fail_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047capabilities$058owned_request_field$1261$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047deferred$045assembly$045v1$047fixture$058decode_field$1260$(_ops_0) {
  const _decode_0 = _ops_0["decode"];
  return _decode_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058grant$1260$() {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058request$1260$(_x_0, _x_1);
});
})};
}

function $$$$047deferred$045assembly$045v1$047assembly$058resource_grant$1260$() {
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047deferred$045assembly$045v1$047assembly$058replace$1260$(_x_0, _x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_swap$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058rollback$1262$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045delivery$058enqueue$1260$(_tx_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045delivery$058apply$1260$(_x_0, _handle_0, _payload_0);
}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058request$1260$(_frame_0, _input_0) {
  const _batch_0 = _frame_0["batch"];
  const _declaration_0 = _frame_0["declaration"];
  const _operation_0 = _input_0["operation"];
  const _owner_0 = _input_0["owner"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058validated$1260$(_declaration_0, _batch_0, _operation_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047persistence$045declaration$058validate$1260$(_declaration_0, _owner_0)));
}

function $$$$047deferred$045assembly$045v1$047assembly$058replace$1260$(_owner_0, _incoming_0) {
  const _t_0 = _owner_0["batch"];
  const _t_1 = _t_0["tx"];
  const _world_0 = _t_1["world"];
  const _undo_0 = _t_1["undo"];
  const _commands_0 = _t_1["commands"];
  const _events_0 = _t_1["events"];
  const _prepared_0 = _t_0["prepared"];
  const _declaration_0 = _owner_0["declaration"];
  return $$$$047deferred$045assembly$045v1$047assembly$058replaced$1260$(_declaration_0, _prepared_0, _undo_0, _commands_0, _events_0, ($$$$047deferred$045assembly$045v1$047assembly$058swapped$1260$(_world_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058restore_swap$1261$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045delivery$058apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045delivery$058apply_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058validated$1260$(_declaration_0, _batch_0, _operation_0, _receipt_0) {
  const _owner_0 = _receipt_0["owner"];
  const _t_0 = _receipt_0["checked"];
  if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Rejected") {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Refused", "owner": {$: "Some", "value": _owner_0}, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Validation", "error": _error_0}}};
  } else {
    const _canonical_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058enqueue$1260$(_declaration_0, _batch_0, _operation_0, _canonical_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047persistence$045declaration$058validate$1260$(_declaration_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$058decode_owner$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047persistence$045declaration$058codec$1260$(_declaration_0)), _owner_0);
}

function $$$$047deferred$045assembly$045v1$047assembly$058replaced$1260$(_declaration_0, _prepared_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _old_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Owner", "batch": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047deferred$045assembly$045v1$047assembly$058restored$1260$(($$$$047deferred$045assembly$045v1$047assembly$058swapped$1260$(_x_0, _old_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "declaration": _declaration_0}, "snd": {$: "Unit"}};
}

function $$$$047deferred$045assembly$045v1$047assembly$058swapped$1260$(_world_0, _incoming_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _old_0 = _t_0["value"];
  const _retired_0 = _t_0["retired"];
  const _returned_0 = _t_0["returned"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../deferred-assembly-v1/assembly.Mail", "value": _incoming_0, "retired": _retired_0, "returned": _returned_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _system_0, "clock": _clock_0}, "snd": _old_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _words_0 = _owner_0["words"];
  const _flags_0 = _owner_0["flags"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/second-owner.Owner", "raw": _raw_0, "words": _words_0, "flags": _flags_0}, "snd": _raw_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058viewed$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Owned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045delivery$058apply_checked$1260$(_observed_0, _handle_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047deferred$045assembly$045v1$047fixture$058recover$(_world_0, _payload_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.MissingEntity"});
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045delivery$058deliver$1260$(($$$$047deferred$045assembly$045v1$047fixture$058attempt$(_world_0, _handle_0, _payload_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058enqueue$1260$(_declaration_0, _batch_0, _operation_0, _canonical_0, _projected_0) {
  const _owner_0 = _projected_0["fst"];
  const _original_0 = _projected_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058enqueue_packet$1260$(_declaration_0, _batch_0, _operation_0, _owner_0, _original_0, _canonical_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$058decode_owner$1260$(_codec_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$058decode_projected$1260$(_codec_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
}

function $$$$047deferred$045assembly$045v1$047assembly$058restored$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058swap$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047deferred$045assembly$045v1$047fixture$058recover$(_world_0, _packet_0, _error_0) {
  return $$$$047deferred$045assembly$045v1$047assembly$058recover$1260$(_world_0, _packet_0, _error_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045delivery$058deliver$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-delivery.Delivered") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047deferred$045assembly$045v1$047fixture$058recover$(_world_1, _payload_0, _error_0);
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058attempt$(_world_0, _target_0, _packet_0) {
  return $$$$047deferred$045assembly$045v1$047assembly$058attempt$1260$(_world_0, _target_0, _packet_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058enqueue_packet$1260$(_declaration_0, _batch_0, _operation_0, _owner_0, _original_0, _canonical_0) {
  if (_operation_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-requests.Insert") {
    const _target_0 = _operation_0["target"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058inserted$1260$(_declaration_0, _target_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058insert$1260$(_batch_0, _target_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _original_0, "canonical": _canonical_0})));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058spawned$1260$(_declaration_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058spawn$1260$(_batch_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _original_0, "canonical": _canonical_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$058decode_projected$1260$(_codec_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _raw_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$058decode_budget$1260$(_codec_0, _raw_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058budget$(_codec_0, _raw_0)), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047deferred$045assembly$045v1$047assembly$058recover$1260$(_world_0, _packet_0, _error_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _value_0 = _t_0["value"];
  const _retired_0 = _t_0["retired"];
  const _returned_0 = _t_0["returned"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../deferred-assembly-v1/assembly.Mail", "value": _value_0, "retired": _retired_0, "returned": {$: "Con", "head": _packet_0, "tail": _returned_0}, "errors": {$: "Con", "head": _error_0, "tail": _errors_0}}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047deferred$045assembly$045v1$047assembly$058attempt$1260$(_world_0, _target_0, _packet_0) {
  const _owner_0 = _packet_0["owner"];
  const _original_0 = _packet_0["original"];
  const _canonical_0 = _packet_0["canonical"];
  return $$$$047deferred$045assembly$045v1$047assembly$058attempted$1260$(_original_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047component$058replace$1261$(($$$$047generic$045assembly$045v1$047second$045owner$058family$()), _world_0, _target_0, ($$$$047deferred$045assembly$045v1$047fixture$058normalize$(_canonical_0, _owner_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058inserted$1260$(_declaration_0, _target_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Accepted", "target": _target_0, "spawned": false, "canonical": _canonical_0}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Owner", "batch": _batch_1, "declaration": _declaration_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Refused", "owner": _owner_0, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Entity", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058insert$1260$(_batch_0, _target_0, _payload_0) {
  const _t_0 = _batch_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058checked$1260$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045requests$058spawned$1260$(_declaration_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Spawned") {
    const _batch_0 = _result_0["batch"];
    const _target_0 = _result_0["target"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Accepted", "target": _target_0, "spawned": true, "canonical": _canonical_0}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Owner", "batch": _batch_1, "declaration": _declaration_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Refused", "owner": _owner_0, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Entity", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058spawn$1260$(_batch_0, _payload_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058spawn_reserved$1260$(_prepared_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, {$: "Unit"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$058decode_budget$1260$(_codec_0, _raw_0, _fuel_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalized$1260$(_fuel_0, _codec_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058owned$1260$(_fuel_0, _codec_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Owned", "owner": _owner_0, "description": _raw_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058budget$(_codec_0, _raw_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058raw_size$(_raw_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058codec_size$(_codec_0));
  const _x_2 = nat_chk(_x_0 + 1);
  const _x_3 = nat_chk(_x_1 * _x_2);
  return nat_chk(4 * _x_3);
}

function $$$$047deferred$045assembly$045v1$047assembly$058attempted$1260$(_original_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-delivery.Delivered", "world": ($$$$047deferred$045assembly$045v1$047assembly$058retire$1260$(_previous_0, _world_0))};
  } else {
    const _world_1 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-delivery.Undelivered", "world": _world_1, "payload": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Packet", "owner": ($$$$047deferred$045assembly$045v1$047fixture$058normalize$(_original_0, _incoming_0)), "original": _original_0, "canonical": _canonical_0}, "error": _error_0};
  }
}

function $$$$047deferred$045assembly$045v1$047fixture$058normalize$(_raw_0, _owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _owner_0["value"];
    const _words_0 = _t_0["words"];
    const _flags_0 = _t_0["flags"];
    return {$: "Some", "value": {$: "../generic-assembly-v1/second-owner.Owner", "raw": _raw_0, "words": _words_0, "flags": _flags_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058checked$1260$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_checked$1260$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_prepared_0, _target_0)));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058count_commands$1262$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058spawn_reserved$1260$(_prepared_0, _payload_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Reserved") {
    const _target_0 = _t_1["handle"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058spawn_positioned$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058positioned$1260$({$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.ReservationReceipt", "target": _target_0}, "tail": _prepared_0}, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058count_commands$1262$(_commands_0)))));
  } else {
    const _error_0 = _t_1["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.SpawnRefused", "batch": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058spawn_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalized$1260$(_fuel_0, _codec_0, _result_0) {
  const _owner_0 = _result_0["owner"];
  const _t_0 = _result_0["checked"];
  if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Accepted") {
    const _value_0 = _t_0["value"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Receipt", "owner": _owner_0, "checked": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Accepted", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical$(_fuel_0, _codec_0, _value_0))}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Receipt", "owner": _owner_0, "checked": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Rejected", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058owned$1260$(_fuel_0, _codec_0, _input_0) {
  const _owner_0 = _input_0["owner"];
  const _description_0 = _input_0["description"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Receipt", "owner": _owner_0, "checked": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058validate$(_fuel_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Work", "codec": _codec_0, "raw": _description_0, "path": "$"}, "tail": {$: "Nil"}}}, _description_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058codec_size$(_codec_0) {
  if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Nullable") {
    const _inner_0 = _codec_0["inner"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058codec_size$(_inner_0));
    return nat_chk(1 + _x_0);
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.ArrayValue") {
    const _inner_1 = _codec_0["inner"];
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058codec_size$(_inner_1));
    return nat_chk(1 + _x_1);
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Struct") {
    const _t_0 = _codec_0["fields"];
    if (_t_0.$ === "Nil") {
      return 1;
    } else {
      const _t_1 = _t_0["head"];
      const _child_0 = _t_1["codec"];
      const _rest_0 = _t_0["tail"];
      const _x_2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058codec_size$(_child_0));
      const _x_3 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058codec_size$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Struct", "fields": _rest_0}));
      const _x_4 = nat_chk(_x_2 + _x_3);
      return nat_chk(1 + _x_4);
    }
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058raw_size$(_raw_0) {
  if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array") {
    const _t_0 = _raw_0["items"];
    if (_t_0.$ === "Nil") {
      return 1;
    } else {
      const _head_0 = _t_0["head"];
      const _rest_0 = _t_0["tail"];
      const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058raw_size$(_head_0));
      const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058raw_size$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array", "items": _rest_0}));
      return nat_chk(_x_0 + _x_1);
    }
  } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object") {
    const _t_1 = _raw_0["fields"];
    if (_t_1.$ === "Nil") {
      return 1;
    } else {
      const _t_2 = _t_1["head"];
      const _child_0 = _t_2["value"];
      const _rest_1 = _t_1["tail"];
      const _x_2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058raw_size$(_child_0));
      const _x_3 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045size$058raw_size$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object", "fields": _rest_1}));
      return nat_chk(_x_2 + _x_3);
    }
  } else {
    return 1;
  }
}

function $$$$047deferred$045assembly$045v1$047assembly$058retire$1260$(_previous_0, _world_0) {
  if (_previous_0.$ === "None") {
    return _world_0;
  } else {
    const _old_0 = _previous_0["value"];
    const _ns_0 = _world_0["namespace"];
    const _next_0 = _world_0["nextId"];
    const _high_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _t_0 = _world_0["resource"];
    const _value_0 = _t_0["value"];
    const _retired_0 = _t_0["retired"];
    const _returned_0 = _t_0["returned"];
    const _errors_0 = _t_0["errors"];
    const _events_0 = _world_0["events"];
    const _commands_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _system_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../deferred-assembly-v1/assembly.Mail", "value": _value_0, "retired": {$: "Con", "head": _old_0, "tail": _retired_0}, "returned": _returned_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _system_0, "clock": _clock_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_checked$1260$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _result_0) {
  const _prepared_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Refused", "batch": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058count_commands$1262$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_prepared_0, _target_0) {
  if (_prepared_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": false};
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Prepared") {
      const _handle_0 = _t_0["target"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _tail_0 = _prepared_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_join$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Prepared", "target": _handle_0, "payload": _payload_0, "position": _position_0}, false, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_tail_0, _target_0)));
    } else {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _tail_1 = _prepared_0["tail"];
      const _otherNs_0 = _target_0["namespace"];
      const _otherId_0 = _target_0["id"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_join$1260$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.ReservationReceipt", "target": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}}, ($Bool$and$((_ns_0 === _otherNs_0), (_id_0 === _otherId_0))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_tail_1, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Handle", "namespace": _otherNs_0, "id": _otherId_0})));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Inserted", "batch": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Prepared", "target": _target_0, "payload": _payload_0, "position": _position_0}, "tail": _prepared_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058count_commands$1262$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058counted$1262$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058count_commands$1262$(_tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058spawn_positioned$1260$(_target_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.Spawned", "batch": _batch_0, "target": _target_0};
  } else {
    const _batch_1 = _result_0["batch"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-batch.SpawnRefused", "batch": _batch_1, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical$($0, $1, $2) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _codec_0 = $1;
      const _raw_0 = $2;
      if (_fuel_0 === 0) {
        return _raw_0;
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Nullable") {
          const _inner_0 = _codec_0["inner"];
          if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Null") {
            return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Null"};
          } else {
            $0 = _more_0;
            $1 = _inner_0;
            $2 = _raw_0;
            continue;
          }
        } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.ArrayValue") {
          const __0 = _codec_0["inner"];
          if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array") {
            const _t_0 = _raw_0["items"];
            if (_t_0.$ === "Nil") {
              return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array", "items": {$: "Nil"}};
            } else {
              const _head_0 = _t_0["head"];
              const _tail_0 = _t_0["tail"];
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical_array_join$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical$(_more_0, __0, _head_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical$(_more_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.ArrayValue", "inner": __0}, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array", "items": _tail_0})));
            }
          } else {
            return _raw_0;
          }
        } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Struct") {
          const _t_1 = _codec_0["fields"];
          if (_t_1.$ === "Nil") {
            if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object") {
              return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object", "fields": {$: "Nil"}};
            } else {
              return _raw_0;
            }
          } else {
            const _t_2 = _t_1["head"];
            const _name_0 = _t_2["name"];
            const _codec_1 = _t_2["codec"];
            const _rest_0 = _t_1["tail"];
            if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object") {
              const _values_0 = _raw_0["fields"];
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical_struct_join$(_name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical$(_more_0, _codec_1, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058field$(_name_0, _values_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical$(_more_0, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Struct", "fields": _rest_0}, {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object", "fields": _values_0})));
            } else {
              return _raw_0;
            }
          }
        } else {
          return _raw_0;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058validate$($0, $1, $2) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _step_0 = $1;
      const _original_0 = $2;
      if (_fuel_0 === 0) {
        if (_step_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop") {
          const _error_0 = _step_0["error"];
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Rejected", "error": _error_0};
        } else {
          const _t_0 = _step_0["work"];
          if (_t_0.$ === "Nil") {
            return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Accepted", "value": _original_0};
          } else {
            const _t_1 = _t_0["head"];
            const _path_0 = _t_1["path"];
            return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Rejected", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.FuelExhausted", "path": _path_0}};
          }
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_step_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop") {
          const _error_1 = _step_0["error"];
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Rejected", "error": _error_1};
        } else {
          const _t_2 = _step_0["work"];
          if (_t_2.$ === "Nil") {
            return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Accepted", "value": _original_0};
          } else {
            const _t_3 = _t_2["head"];
            const _codec_0 = _t_3["codec"];
            const _raw_0 = _t_3["raw"];
            const _path_1 = _t_3["path"];
            const _rest_0 = _t_2["tail"];
            $0 = _more_0;
            $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058expand$(_codec_0, _raw_0, _path_1, _rest_0));
            $2 = _original_0;
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058receipt_join$1260$(_entry_0, _seen_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _found_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _tail_0}, "snd": (_seen_0 || _found_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047bundle$045batch$058counted$1262$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical_array_join$(_head_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array") {
    const _values_0 = _tail_0["items"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array", "items": {$: "Con", "head": _head_0, "tail": _values_0}};
  } else {
    return _tail_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058canonical_struct_join$(_name_0, _head_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object") {
    const _fields_0 = _tail_0["fields"];
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object", "fields": {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Field", "name": _name_0, "value": _head_0}, "tail": _fields_0}};
  } else {
    return _tail_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058field$(_name_0, _fields_0) {
  if (_fields_0.$ === "Nil") {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Missing"};
  } else {
    const _t_0 = _fields_0["head"];
    const _key_0 = _t_0["name"];
    const _value_0 = _t_0["value"];
    const _rest_0 = _fields_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058field_choose$(($String$eq$(_name_0, _key_0)), _value_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058field$(_name_0, _rest_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058expand$(_codec_0, _raw_0, _path_0, _rest_0) {
  if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Integer") {
    if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Number") {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.SignedInteger") {
      const __1 = _raw_0["negative"];
      const _magnitude_0 = _raw_0["magnitude"];
      const _x_0 = ($Nat$div$(_magnitude_0, nat_chk(65536 * 65536)));
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$((_x_0 < 2097152), _path_0, "integer", {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.SignedInteger", "negative": __1, "magnitude": _magnitude_0}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Float") {
      const _value_0 = _raw_0["value"];
      const _x_1 = Math.fround(Math.floor(_value_0));
      const _x_2 = Math.fround(Math.abs(_value_0));
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$(($Bool$and$((_x_1 === _value_0), (_x_2 < 9007199254740992))), _path_0, "integer", {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Float", "value": _value_0}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Binary64") {
      const _high_0 = _raw_0["high"];
      const _low_0 = _raw_0["low"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_integer$(_high_0, _low_0)), _path_0, "integer", {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Binary64", "high": _high_0, "low": _low_0}, _rest_0);
    } else {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "integer", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.FiniteNumber") {
    if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Number") {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.SignedInteger") {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Float") {
      const _value_1 = _raw_0["value"];
      const _x_3 = Math.fround(Math.abs(_value_1));
      const _x_4 = 3.4028234663852886e+38;
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$((_x_3 <= _x_4), _path_0, "finite number", {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Float", "value": _value_1}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Binary64") {
      const _high_1 = _raw_0["high"];
      const __5 = _raw_0["low"];
      const _x_5 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary64_exponent$(_high_1));
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$((_x_5 < 2047), _path_0, "finite number", {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Binary64", "high": _high_1, "low": __5}, _rest_0);
    } else {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "finite number", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.StringValue") {
    if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Text") {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Utf16Text") {
      const _units_0 = _raw_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058valid$(_units_0)), _path_0, "string", {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Utf16Text", "units": _units_0}, _rest_0);
    } else {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "string", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.BoolValue") {
    if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Boolean") {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": _rest_0};
    } else {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "boolean", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Literal") {
    const _value_2 = _codec_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058equal$(_value_2, _raw_0)), _path_0, "literal", _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.LiteralValues") {
    const _values_0 = _codec_0["values"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058alternatives$(_values_0, _raw_0)), _path_0, "literal", _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.LiteralRendered") {
    const _values_1 = _codec_0["values"];
    const _expected_0 = _codec_0["expected"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058alternatives$(_values_1, _raw_0)), _path_0, _expected_0, _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Nullable") {
    const __8 = _codec_0["inner"];
    if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Null") {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": _rest_0};
    } else {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Work", "codec": __8, "raw": _raw_0, "path": _path_0}, "tail": _rest_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.ArrayValue") {
    const _inner_0 = _codec_0["inner"];
    if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array") {
      const _items_0 = _raw_0["items"];
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058array_work$(_inner_0, _items_0, _path_0, 0, _rest_0))};
    } else {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "array", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Struct") {
    const _fields_0 = _codec_0["fields"];
    if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object") {
      const _values_2 = _raw_0["fields"];
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058struct_work$(_fields_0, _values_2, _path_0, _rest_0))};
    } else {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "object", "actual": _raw_0}};
    }
  } else {
    const _ns_0 = _codec_0["namespace"];
    if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Handle") {
      const _actual_0 = _raw_0["namespace"];
      const _id_0 = _raw_0["id"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$(($Bool$and$((_ns_0 === _actual_0), (_id_0 > 0))), _path_0, "same-world handle", {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Handle", "namespace": _actual_0, "id": _id_0}, _rest_0);
    } else {
      return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "same-world handle", "actual": _raw_0}};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058spawned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058field_choose$(_equal_0, _value_0, _next_0) {
  if (_equal_0) {
    return _value_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058choose_checked$(_valid_0, _path_0, _expected_0, _raw_0, _rest_0) {
  if (_valid_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Continue", "work": _rest_0};
  } else {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid", "path": _path_0, "expected": _expected_0, "actual": _raw_0}};
  }
}

function $Nat$div$(_a_0, _b_0) {
  return $Pair$fst$(nat_divmod(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_integer$(_high_0, _low_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary64_exponent$(_high_0));
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_integer_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_numeric$(_high_0, _low_0)), (_x_0 < 1076));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary64_exponent$(_high_0) {
  const _x_0 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  return (2048 === 0 ? _x_0 : _x_0 % 2048);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058valid$(_units_0) {
  if (_units_0.$ === "Nil") {
    return true;
  } else {
    const _unit_0 = _units_0["head"];
    const _tail_0 = _units_0["tail"];
    return $Bool$and$((_unit_0 <= 65535), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058valid$(_tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058equal$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Null") {
    if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Null") {
      return true;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Null"})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Text") {
    const _a_1 = _a_0["value"];
    if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Text") {
      const _b_1 = _b_0["value"];
      return $String$eq$(_a_1, _b_1);
    } else if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Utf16Text") {
      const _b_2 = _b_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058text$(_a_1)), _b_2);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Text", "value": _a_1})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Utf16Text") {
    const _a_2 = _a_0["units"];
    if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Utf16Text") {
      const _b_3 = _b_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058checked$(_a_2, _b_3);
    } else if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Text") {
      const _b_4 = _b_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058checked$(_a_2, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058text$(_b_4)));
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Utf16Text", "units": _a_2})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Boolean") {
    const _a_3 = _a_0["value"];
    if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Boolean") {
      const _b_5 = _b_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_bool$(_a_3, _b_5);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$({$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Boolean", "value": _a_3})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$(_b_0)));
    }
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$(_a_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$(_b_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058alternatives$(_values_0, _raw_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _value_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058equal$(_value_0, _raw_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058alternatives$(_tail_0, _raw_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058array_work$(_codec_0, _items_0, _path_0, _index_0, _rest_0) {
  if (_items_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _value_0 = _items_0["head"];
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($U32$show$(_index_0));
    const _x_1 = (_x_0 + "]");
    const _x_2 = ("[" + _x_1);
    return {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Work", "codec": _codec_0, "raw": _value_0, "path": (_path_0 + _x_2)}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058array_work$(_codec_0, _tail_0, _path_0, ((_index_0 + 1) >>> 0), _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058struct_work$(_fields_0, _values_0, _path_0, _rest_0) {
  if (_fields_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _t_0 = _fields_0["head"];
    const _name_0 = _t_0["name"];
    const _codec_0 = _t_0["codec"];
    const _tail_0 = _fields_0["tail"];
    const _x_0 = ("." + _name_0);
    return {$: "Con", "head": {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Work", "codec": _codec_0, "raw": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058field$(_name_0, _values_0)), "path": (_path_0 + _x_0)}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058struct_work$(_tail_0, _values_0, _path_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Accepted") {
    return _world_0;
  } else {
    return _world_0;
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $Pair$fst$(_p_0) {
  const _a_0 = _p_0["fst"];
  return _a_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_integer_checked$(_result_0, _small_0) {
  return $Bool$and$(_small_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_integer_normal$(_result_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_numeric$(_high_0, _low_0) {
  const _x_0 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_1 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_2 = (2048 === 0 ? _x_1 : _x_1 % 2048);
  const _x_3 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_4 = (2048 === 0 ? _x_3 : _x_3 % 2048);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_parts$((_high_0 >= 2147483648), (2048 === 0 ? _x_0 : _x_0 % 2048), (1048576 === 0 ? _high_0 : _high_0 % 1048576), _low_0, (_x_2 === 2047), (_x_4 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_numeric$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Finite") {
    const _an_0 = _a_0["negative"];
    const _ah_0 = _a_0["high"];
    const _al_0 = _a_0["low"];
    const _ae_0 = _a_0["exponent"];
    if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Finite") {
      const _bn_0 = _b_0["negative"];
      const _bh_0 = _b_0["high"];
      const _bl_0 = _b_0["low"];
      const _be_0 = _b_0["exponent"];
      return $Bool$and$(($Bool$and$(($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_bool$(_an_0, _bn_0)), (_ah_0 === _bh_0))), (_al_0 === _bl_0))), (_ae_0 === _be_0));
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Infinity") {
    const _a_1 = _a_0["negative"];
    if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Infinity") {
      const _b_1 = _b_0["negative"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_bool$(_a_1, _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.NaN") {
    if (_b_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.NaN") {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric$(_raw_0) {
  if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Number") {
    const _value_0 = _raw_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize$(64, false, 0, _value_0, 1074);
  } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.SignedInteger") {
    const _negative_0 = _raw_0["negative"];
    const _value_1 = _raw_0["magnitude"];
    const _x_0 = ($Nat$div$(_value_1, nat_chk(65536 * 65536)));
    const _x_1 = ($Nat$mod$(_value_1, nat_chk(65536 * 65536)));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize$(64, _negative_0, (_x_0 >>> 0), (_x_1 >>> 0), 1074);
  } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Float") {
    const _value_2 = _raw_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058float_numeric$(f32_bits(_value_2));
  } else if (_raw_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Binary64") {
    const _high_0 = _raw_0["high"];
    const _low_0 = _raw_0["low"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_numeric$(_high_0, _low_0);
  } else {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.NotNumber"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058checked$(_left_0, _right_0) {
  return $Bool$and$(($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058valid$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058valid$(_right_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058equal$(_left_0, _right_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058text$(_value_0) {
  if (_value_0 === "") {
    return {$: "Nil"};
  } else {
    const _t_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
    const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
    const _x_0 = _t_0.codePointAt(0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058scalar$(_t_0.codePointAt(0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058text$(_tail_0)), (_x_0 < 65536));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058same_bool$(_a_0, _b_0) {
  if (_a_0) {
    if (_b_0) {
      return true;
    } else {
      return false;
    }
  } else {
    if (!_b_0) {
      return true;
    } else {
      return false;
    }
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_integer_normal$(_result_0) {
  if (_result_0.$ === "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Finite") {
    const _high_0 = _result_0["high"];
    const _low_0 = _result_0["low"];
    const _exponent_0 = _result_0["exponent"];
    const _x_0 = ($Bool$and$((_high_0 === 0), (_low_0 === 0)));
    const _x_1 = ($Bool$and$((_exponent_0 >= 1074), (_exponent_0 <= 1126)));
    return (_x_0 || _x_1);
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058binary_parts$(_negative_0, _exponent_0, _high_0, _low_0, _special_0, _zero_0) {
  if (_special_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric_special$(_negative_0, ($Bool$and$((_high_0 === 0), (_low_0 === 0))));
  } else {
    if (_zero_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize$(64, _negative_0, _high_0, _low_0, 0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize$(64, _negative_0, ((_high_0 + 1048576) >>> 0), _low_0, ((_exponent_0 - 1) >>> 0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize$(_fuel_0, _negative_0, _high_0, _low_0, _exponent_0) {
  const _x_0 = (2 === 0 ? _low_0 : _low_0 % 2);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize_checked$(_fuel_0, _negative_0, _high_0, _low_0, _exponent_0, ($Bool$and$((_high_0 === 0), (_low_0 === 0))), (_x_0 === 0));
}

function $Nat$mod$(_a_0, _b_0) {
  return $Pair$snd$(nat_divmod(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058float_numeric$(_bits_0) {
  const _x_0 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_1 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_2 = (256 === 0 ? _x_1 : _x_1 % 256);
  const _x_3 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_4 = (256 === 0 ? _x_3 : _x_3 % 256);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058float_parts$(_bits_0, (256 === 0 ? _x_0 : _x_0 % 256), (8388608 === 0 ? _bits_0 : _bits_0 % 8388608), (_x_2 === 255), (_x_4 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058equal$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058empty$(_right_0);
  } else {
    const _head_0 = _left_0["head"];
    const _tail_0 = _left_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058compared$(_head_0, _right_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058equal$(_tail_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058scalar$(_code_0, _rest_0, _bmp_0) {
  if (_bmp_0) {
    return {$: "Con", "head": _code_0, "tail": _rest_0};
  } else {
    const _x_0 = ((_code_0 - 65536) >>> 0);
    const _x_1 = (1024 === 0 ? 0 : (_x_0 / 1024) >>> 0);
    const _x_2 = ((_code_0 - 65536) >>> 0);
    const _x_3 = (1024 === 0 ? _x_2 : _x_2 % 1024);
    return {$: "Con", "head": ((55296 + _x_1) >>> 0), "tail": {$: "Con", "head": ((56320 + _x_3) >>> 0), "tail": _rest_0}};
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric_special$(_negative_0, _infinite_0) {
  if (_infinite_0) {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Infinity", "negative": _negative_0};
  } else {
    return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.NaN"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize_checked$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _negative_0 = $1;
      const _high_0 = $2;
      const _low_0 = $3;
      const _exponent_0 = $4;
      const _zero_0 = $5;
      const _even_0 = $6;
      if (_fuel_0 === 0) {
        if (_zero_0) {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Finite", "negative": false, "high": 0, "low": 0, "exponent": 0};
        } else {
          if (!_even_0) {
            return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          } else {
            return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          }
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_zero_0) {
          return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Finite", "negative": false, "high": 0, "low": 0, "exponent": 0};
        } else {
          if (!_even_0) {
            return {$: "../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          } else {
            const _x_0 = (2 === 0 ? _high_0 : _high_0 % 2);
            const _x_1 = (2 === 0 ? 0 : (_low_0 / 2) >>> 0);
            const _x_2 = (Math.imul(_x_0, 2147483648) >>> 0);
            const _x_3 = (2 === 0 ? 0 : (_low_0 / 2) >>> 0);
            const _x_4 = (2 === 0 ? _x_3 : _x_3 % 2);
            $0 = _more_0;
            $1 = _negative_0;
            $2 = (2 === 0 ? 0 : (_high_0 / 2) >>> 0);
            $3 = ((_x_1 + _x_2) >>> 0);
            $4 = ((_exponent_0 + 1) >>> 0);
            $5 = false;
            $6 = (_x_4 === 0);
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058float_parts$(_bits_0, _exponent_0, _fraction_0, _special_0, _zero_0) {
  if (_special_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058numeric_special$((_bits_0 >= 2147483648), (_fraction_0 === 0));
  } else {
    if (_zero_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize$(64, (_bits_0 >= 2147483648), 0, _fraction_0, 925);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045data$058normalize$(64, (_bits_0 >= 2147483648), 0, ((_fraction_0 + 8388608) >>> 0), ((_exponent_0 + 924) >>> 0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058empty$(_units_0) {
  if (_units_0.$ === "Nil") {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047ordinary$045snapshot$045integration$047src$047ecs$047decode$045utf16$058compared$(_head_0, _other_0, _next_0) {
  if (_other_0.$ === "Nil") {
    return false;
  } else {
    const _value_0 = _other_0["head"];
    const _tail_0 = _other_0["tail"];
    return $Bool$and$((_head_0 === _value_0), _next_0(_tail_0));
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,1,2,0,0,0,1,1,0,2,1,0,15,1,0,7,1,1,2,0,2,0,0,26,1,61,7,0,8,3,0,0,0,4,0,0,0,5,0,0,0,6,0,0,0,7,0,0,0,8,0,0,0,9,0,0,0,10,0,0,0,7,0,2,11,0,1,0,1,84,12,0,5,0,1,519,20,519,39,519,58,704,65,951,7,0,1,13,0,4,0,0,99,2,259,3,431,4,485,7,0,1,14,0,2,0,0,110,1,202,7,1,12,15,0,0,0,16,0,0,0,17,0,1,0,0,187,18,0,2,0,0,188,1,199,19,0,1,0,0,200,20,0,2,0,0,187,1,187,21,0,1,0,0,201,22,0,1,0,0,202,23,0,1,0,0,188,24,0,2,0,0,187,1,187,25,0,1,0,0,218,26,0,1,0,0,233,0,7,0,2,27,0,0,0,28,0,0,0,2,1,4,7,1,2,29,0,0,1,30,0,2,1,0,217,1,202,0,7,1,2,31,0,0,1,32,0,2,1,0,110,1,218,7,1,2,33,0,0,1,34,0,2,1,0,248,1,233,7,1,1,35,0,2,0,0,201,1,110,7,1,2,36,0,0,1,37,0,2,1,0,274,1,259,7,1,1,38,0,3,0,0,287,1,202,2,405,7,1,12,39,0,0,0,40,0,0,0,41,0,1,0,0,187,42,0,2,0,0,188,1,199,43,0,1,0,0,200,44,0,2,0,0,187,1,187,45,0,1,0,0,201,46,0,1,0,0,202,47,0,1,0,0,188,48,0,2,0,0,187,1,187,49,0,1,0,0,364,50,0,1,0,0,379,7,1,2,51,0,0,1,52,0,2,1,0,287,1,364,7,1,2,53,0,0,1,54,0,2,1,0,394,1,379,7,1,1,55,0,2,0,0,201,1,287,7,1,2,56,0,0,1,57,0,2,1,0,420,1,405,7,1,2,58,0,0,0,59,0,0,0,7,1,2,60,0,0,1,61,0,2,1,0,446,1,431,7,1,1,62,0,3,0,0,459,4,287,5,287,7,0,2,63,0,0,0,64,0,1,0,1,472,7,0,1,65,0,3,0,0,287,1,202,2,405,7,1,2,66,0,0,1,67,0,2,1,0,500,1,485,7,1,4,68,0,0,0,69,0,0,0,70,0,0,0,71,0,0,0,7,0,1,72,0,5,0,0,536,9,405,10,626,13,84,18,187,7,0,1,73,0,9,0,0,187,1,187,2,187,3,187,4,199,5,561,6,583,7,187,8,187,7,1,2,74,0,0,1,75,0,2,1,0,576,1,561,7,1,1,76,0,0,0,7,1,2,77,0,0,1,78,0,2,1,0,598,1,583,7,1,1,79,0,3,0,0,187,1,201,2,611,7,1,2,80,0,0,1,81,0,2,1,0,201,1,611,7,0,1,82,0,3,0,0,188,1,639,2,667,7,1,2,83,0,0,1,84,0,2,1,0,654,1,639,7,1,2,85,0,0,0,86,0,1,0,0,274,7,1,2,87,0,0,1,88,0,2,1,0,682,1,667,7,1,1,89,0,2,0,0,187,1,693,7,0,1,90,0,2,0,0,187,1,187,7,0,2,91,0,0,0,92,0,1,0,1,717,7,0,1,93,0,6,0,0,187,1,187,2,201,3,611,4,736,5,825,7,1,11,94,0,0,0,95,0,0,0,96,0,0,0,97,0,0,0,98,0,1,0,0,287,99,0,1,0,0,364,100,0,2,0,0,364,1,201,101,0,1,0,0,736,102,0,1,0,0,736,103,0,1,0,0,799,104,0,1,0,0,187,7,1,2,105,0,0,1,106,0,2,1,0,814,1,799,7,1,1,107,0,2,0,0,201,1,736,7,1,2,108,0,0,1,109,0,2,1,0,840,1,825,7,1,1,110,0,2,0,0,851,1,431,7,1,2,111,0,0,1,112,0,2,1,0,866,1,851,7,1,2,113,0,3,0,0,887,2,188,3,287,114,0,2,0,0,459,4,898,7,0,1,115,0,2,0,0,187,1,187,7,0,2,116,0,1,0,1,913,117,0,1,0,1,932,7,0,2,118,0,3,0,1,201,2,201,3,287,119,0,1,0,1,201,7,0,4,120,0,0,0,121,0,0,0,122,0,0,0,123,0,0,0,7,0,4,124,0,1,0,1,851,125,0,0,0,126,0,0,0,127,0,1,0,1,974,7,0,1,128,0,4,0,0,989,3,472,6,472,9,188,7,0,2,129,0,0,0,130,0,1,0,1,887],["Nil","Con","Item","Spawn","Insert","Failure","Foreign","LateMissing","Invalid","FailedInsert","FailedInvalid","../deferred-assembly-v1/fixture.FactoryRefused","../deferred-assembly-v1/fixture.Report","../deferred-assembly-v1/fixture.MailView","../../adoption-v1/observation.PayloadView","../../typed.Missing","../../typed.Null","../../typed.Number","../../typed.SignedInteger","../../typed.Float","../../typed.Binary64","../../typed.Text","../../typed.Utf16Text","../../typed.Boolean","../../typed.Handle","../../typed.Array","../../typed.Object","False","True","Nil","Con","Nil","Con","Nil","Con","../../typed.Field","Nil","Con","../generic-assembly-v1/observation.PayloadView","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Missing","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Null","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Number","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.SignedInteger","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Float","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Binary64","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Text","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Utf16Text","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Boolean","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Handle","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Array","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Object","Nil","Con","Nil","Con","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Field","Nil","Con","False","True","Nil","Con","../deferred-assembly-v1/fixture.PacketView","None","Some","../generic-assembly-v1/observation.PayloadView","Nil","Con","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.MissingEntity","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.CapacityExceeded","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.NamespaceExhausted","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.SystemIdExhausted","../deferred-assembly-v1/fixture.Snapshot","../generic-assembly-v1/observation.Meta","Nil","Con","Unit","Nil","Con","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.RegistrationMeta","Nil","Con","../generic-assembly-v1/observation.ColumnView","Nil","Con","None","Some","Nil","Con","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Entry","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/lifecycle.Stamp","None","Some","../deferred-assembly-v1/fixture.InstanceView","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.FiniteNumber","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Integer","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.StringValue","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.BoolValue","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Literal","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.LiteralValues","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.LiteralRendered","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Nullable","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.ArrayValue","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Struct","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.HandleValue","Nil","Con","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.NamedCodec","Nil","Con","../deferred-assembly-v1/fixture.RecoveryView","Nil","Con","../deferred-assembly-v1/fixture.AcceptedView","../deferred-assembly-v1/fixture.RefusedView","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.Handle","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Validation","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-requests.Entity","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.Invalid","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/decode-data.FuelExhausted","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.MissingEntity","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.CapacityExceeded","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.NamespaceExhausted","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/world.SystemIdExhausted","../deferred-assembly-v1/fixture.Completed","../deferred-assembly-v1/fixture.Failed","../deferred-assembly-v1/fixture.Refused","../deferred-assembly-v1/fixture.InvocationRefused","../deferred-assembly-v1/fixture.ArgsView","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-requests.Spawn","../../../../../../../../../../../ordinary-snapshot-integration/src/ecs/bundle-requests.Insert"]]);