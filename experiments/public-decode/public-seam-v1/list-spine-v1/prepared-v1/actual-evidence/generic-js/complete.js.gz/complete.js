function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $step_0$({$: "Nil"});
}

function $step_0$(_previous_0) {
  return $done_0$(_previous_0, {$: "Second", "label": {$: "Success"}, "value": ($$$$047generic$045assembly$045v1$047public$045fixture$058run$(false, true))});
}

function $done_0$(_previous_0, _value_0) {
  return $step_1$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058run$(_fail_0, _seed_0) {
  return $$$$047generic$045assembly$045v1$047public$045fixture$058created$(_fail_0, _seed_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(100)))));
}

function $step_1$(_previous_0) {
  return $done_1$(_previous_0, {$: "Second", "label": {$: "Failure"}, "value": ($$$$047generic$045assembly$045v1$047public$045fixture$058run$(true, true))});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058created$(_fail_0, _seed_0, _result_0) {
  if (!_seed_0) {
    if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
      const _world_0 = _result_0["world"];
      return $$$$047generic$045assembly$045v1$047public$045fixture$058registered$(_fail_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058define$(_world_0)));
    } else {
      return {$: "../generic-assembly-v1/public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/public-fixture.FactoryRefusedView"}};
    }
  } else {
    if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
      const _world_1 = _result_0["world"];
      return $$$$047generic$045assembly$045v1$047public$045fixture$058reserved$(_fail_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_1)));
    } else {
      return {$: "../generic-assembly-v1/public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/public-fixture.FactoryRefusedView"}};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(_value_0) {
  return {$: "../../../../../../bendvy/experiments/public-decode/complete-v1/controls.Owner", "value": {$: "../../../../../../bendvy/experiments/public-decode/typed.Number", "value": _value_0}, "sentinel": array_node([_value_0], [((_value_0 + 1) >>> 0)])};
}

function $done_1$(_previous_0, _value_0) {
  return $step_2$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058registered$(_fail_0, _value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/local.Registered") {
    const _world_0 = _value_0["world"];
    const _instance_0 = _value_0["instance"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058started$(_fail_0, _instance_0, ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_0)));
  } else {
    return {$: "../generic-assembly-v1/public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/public-fixture.RegistrationRefusedView"}};
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058define$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register$1261$(_world_0, "declared-owned-system", ($$$$047generic$045assembly$045v1$047declared$058access$1260$()), {$: "../generic-assembly-v1/public-fixture.State", "codec": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058constructed$1260$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Integer"})), "recovery": {$: "Nil"}});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058reserved$(_fail_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_0["handle"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058activated$(_fail_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _target_0)));
  } else {
    return {$: "../generic-assembly-v1/public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/public-fixture.FactoryRefusedView"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047generic$045assembly$045v1$047second$045owner$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $step_2$(_previous_0) {
  return $done_2$(_previous_0, {$: "Second", "label": {$: "NoMatch"}, "value": ($$$$047generic$045assembly$045v1$047public$045fixture$058run$(false, false))});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058started$(_fail_0, _instance_0, _value_0) {
  const _world_0 = _value_0["fst"];
  const _before_0 = _value_0["snd"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058ran$(_before_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058run$1261$(_instance_0, _world_0, {$: "../generic-assembly-v1/public-fixture.Args", "incoming": {$: "Some", "value": {$: "../generic-assembly-v1/public-fixture.IncomingPair", "first": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(11)), "second": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(22))}}, "operations": {$: "Nil"}, "writes": {$: "Nil"}, "fail": _fail_0})));
}

function $$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047generic$045assembly$045v1$047observation$058assembled$({$: "../generic-assembly-v1/observation.Meta", "namespace": _namespace_0, "nextId": _next_0, "highWater": _high_0, "capacity": _capacity_0, "depth": _depth_0, "events": _events_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047generic$045assembly$045v1$047observation$058bools$(_live_0)), ($$$$047generic$045assembly$045v1$047observation$058column$1260$(_store_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058payload$(_resource_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register$1261$(_world_0, _name_0, _access_0, _local_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_named$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0, _local_0);
}

function $$$$047generic$045assembly$045v1$047declared$058access$1260$() {
  return $List$append$(($$$$047generic$045assembly$045v1$047declared$058access_clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058clauses$1260$(($$$$047generic$045assembly$045v1$047declared$058query$1260$()))))), {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1261$("decoded-resource")))), "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058constructed$1260$(_codec_0) {
  return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/persistence-declaration.Constructed", "codec": _codec_0};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058activated$(_fail_0, _target_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Accepted") {
    return $$$$047generic$045assembly$045v1$047public$045fixture$058seeded$(_fail_0, ($$$$047generic$045assembly$045v1$047second$045owner$058install$(_world_0, _target_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet$(10)))));
  } else {
    return {$: "../generic-assembly-v1/public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/public-fixture.FactoryRefusedView"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047generic$045assembly$045v1$047second$045owner$058empty$(_unit_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1260$();
}

function $done_2$(_previous_0, _value_0) {
  return $step_3$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058ran$(_before_0, _value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/local.Completed") {
    const _world_0 = _value_0["world"];
    const _instance_0 = _value_0["instance"];
    const _result_0 = _value_0["result"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058report$(_before_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058result_view$(_result_0)), ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_0)), ($$$$047generic$045assembly$045v1$047public$045fixture$058instance_view$(_instance_0)));
  } else {
    const _world_1 = _value_0["world"];
    const _instance_1 = _value_0["instance"];
    const _args_0 = _value_0["args"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058report$(_before_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058refused_view$(($$$$047generic$045assembly$045v1$047public$045fixture$058args_view$(_args_0)))), ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_1)), ($$$$047generic$045assembly$045v1$047public$045fixture$058instance_view$(_instance_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058run$1261$(_instance_0, _world_0, _args_0) {
  const _namespace_0 = _instance_0["namespace"];
  const _id_0 = _instance_0["id"];
  const _name_0 = _instance_0["name"];
  const _access_0 = _instance_0["access"];
  const _local_0 = _instance_0["local"];
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058checked$1261$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _args_0);
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(_value_0) {
  return {$: "../generic-assembly-v1/second-owner.Owner", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number", "value": _value_0}, "words": array_node([_value_0], [((_value_0 + 10) >>> 0)]), "flags": array_node([true], [false])};
}

function $$$$047generic$045assembly$045v1$047observation$058assembled$(_meta_0, _live_0, _store_0, _resource_0, _pending_0) {
  const _namespace_0 = _meta_0["namespace"];
  const _next_0 = _meta_0["nextId"];
  const _high_0 = _meta_0["highWater"];
  const _capacity_0 = _meta_0["capacity"];
  const _depth_0 = _meta_0["depth"];
  const _events_0 = _meta_0["events"];
  const _registrations_0 = _meta_0["registrations"];
  const _nextSystem_0 = _meta_0["nextSystemId"];
  const _clock_0 = _meta_0["clock"];
  const _live_1 = _live_0["fst"];
  const _a_0 = _live_0["snd"];
  const _store_1 = _store_0["fst"];
  const _b_0 = _store_0["snd"];
  const _resource_1 = _resource_0["fst"];
  const _c_0 = _resource_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _count_0 = _pending_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _next_0, "highWater": _high_0, "live": _live_1, "capacity": _capacity_0, "depth": _depth_0, "store": _store_1, "resource": _resource_1, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": {$: "../generic-assembly-v1/observation.Snapshot", "meta": {$: "../generic-assembly-v1/observation.Meta", "namespace": _namespace_0, "nextId": _next_0, "highWater": _high_0, "capacity": _capacity_0, "depth": _depth_0, "events": _events_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "live": _a_0, "column": _b_0, "resource": _c_0, "pending": _count_0}};
}

function $$$$047generic$045assembly$045v1$047observation$058bools$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047observation$058bool_join$(($$$$047generic$045assembly$045v1$047observation$058bools$(_left_0)), ($$$$047generic$045assembly$045v1$047observation$058bools$(_right_0)));
  }
}

function $$$$047generic$045assembly$045v1$047observation$058column$1260$(_owner_0) {
  if (_owner_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return $$$$047generic$045assembly$045v1$047observation$058column_done$1260$(_stamps_0, ($$$$047generic$045assembly$045v1$047observation$058slots$(_values_0)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": {$: "../generic-assembly-v1/observation.ColumnView", "supported": false, "slots": {$: "Nil"}, "stamps": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058payload$(_owner_0) {
  const _raw_0 = _owner_0["value"];
  const _sentinel_0 = _owner_0["sentinel"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058payload_done$(_raw_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058array$(_sentinel_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_named$1261$(_named_0, _name_0, _access_0, _local_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0, _local_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047generic$045assembly$045v1$047declared$058access_clauses$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _values_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _values_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047generic$045assembly$045v1$047declared$058access_clauses$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058clauses$1260$(_declaration_0) {
  const _clauses_0 = _declaration_0["clauses"];
  return _clauses_0;
}

function $$$$047generic$045assembly$045v1$047declared$058query$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058write$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1261$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1261$(_key_0) {
  return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058seeded$(_fail_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Installed") {
    const _world_0 = _result_0["world"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058registered$(_fail_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058define$(_world_0)));
  } else {
    return {$: "../generic-assembly-v1/public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/public-fixture.FactoryRefusedView"}};
  }
}

function $$$$047generic$045assembly$045v1$047second$045owner$058install$(_world_0, _target_0, _packet_0) {
  const _owner_0 = _packet_0["owner"];
  const _original_0 = _packet_0["original"];
  const _canonical_0 = _packet_0["canonical"];
  return $$$$047generic$045assembly$045v1$047second$045owner$058installed$(_original_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058family$()), _world_0, {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": ($$$$047generic$045assembly$045v1$047second$045owner$058normalized$(_owner_0, _canonical_0))})));
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058packet$(_value_0) {
  return {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(_value_0))}, "original": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number", "value": _value_0}, "canonical": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number", "value": _value_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $step_3$(_previous_0) {
  return $done_3$(_previous_0, {$: "Second", "label": {$: "Skip"}, "value": ($$$$047generic$045assembly$045v1$047public$045fixture$058run_skip$())});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058report$(_before_0, _result_0, _world_0, _instance_0) {
  const _after_0 = _world_0["snd"];
  const _view_0 = _instance_0["snd"];
  return {$: "../generic-assembly-v1/public-fixture.Report", "before": _before_0, "after": _after_0, "instance": _view_0, "result": _result_0};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058result_view$(_value_0) {
  if (_value_0.$ === "Fail") {
    const _error_0 = _value_0["error"];
    return {$: "../generic-assembly-v1/public-fixture.FailedView", "error": _error_0};
  } else {
    const _t_0 = _value_0["value"];
    const _args_0 = _t_0["fst"];
    const _rows_0 = _t_0["snd"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058completed_view$(_rows_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058args_view$(_args_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058instance_view$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _state_0 = _value_0["local"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058instance_join$(_namespace_0, _id_0, _name_0, _access_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058state_view$(_state_0)));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058refused_view$(_result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "../generic-assembly-v1/public-fixture.InvocationRefusedView", "args": _view_0};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058args_view$(_value_0) {
  const _incoming_0 = _value_0["incoming"];
  const _operations_0 = _value_0["operations"];
  const _writes_0 = _value_0["writes"];
  const _fail_0 = _value_0["fail"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058args_join$(_fail_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058incoming_view$(_incoming_0)), ($$$$047generic$045assembly$045v1$047public$045fixture$058operations_view$(_operations_0)), ($$$$047generic$045assembly$045v1$047public$045fixture$058writes_view$(_writes_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058checked$1261$(_allowed_0, _instance_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/local.Refused", "world": _world_0, "instance": _instance_0, "args": _args_0};
  } else {
    const _namespace_0 = _instance_0["namespace"];
    const _id_0 = _instance_0["id"];
    const _name_0 = _instance_0["name"];
    const _access_0 = _instance_0["access"];
    const _local_0 = _instance_0["local"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058completed$1261$(_namespace_0, _id_0, _name_0, _access_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058runner$(_world_0, _local_0, _args_0)));
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047generic$045assembly$045v1$047observation$058bool_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047generic$045assembly$045v1$047observation$058column_done$1260$(_stamps_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _owner_0, "stamps": _stamps_0}, "snd": {$: "../generic-assembly-v1/observation.ColumnView", "supported": true, "slots": _view_0, "stamps": _stamps_0}};
}

function $$$$047generic$045assembly$045v1$047observation$058slots$(_owner_0) {
  if (_owner_0.length === 1) {
    const _owner_1 = _owner_0[0];
    return $$$$047generic$045assembly$045v1$047observation$058leaf$(($$$$047generic$045assembly$045v1$047observation$058option$(_owner_1)));
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047observation$058slot_join$(($$$$047generic$045assembly$045v1$047observation$058slots$(_left_0)), ($$$$047generic$045assembly$045v1$047observation$058slots$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058payload_done$(_raw_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _cells_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/experiments/public-decode/complete-v1/controls.Owner", "value": _raw_0, "sentinel": _owner_0}, "snd": {$: "../../../../../../bendvy/experiments/public-decode/adoption-v1/observation.PayloadView", "raw": _raw_0, "sentinel": _cells_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058array$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058joined$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058array$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058array$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_result$1261$(_registered_0, _namespace_0, _name_0, _access_0, _local_0) {
  const _world_0 = _registered_0["fst"];
  const _t_0 = _registered_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Registered") {
    const _id_0 = _t_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/local.Registered", "world": _world_0, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/local.RegistrationRejected", "world": _world_0, "local": _local_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058write$1260$() {
  return {$: "../../../../../../bendvy/experiments/public-inspect/debug-study-v1/production-adoption-v1/public-api-v1/docs/ordinary-v1/query-candidate-v1/declaration.Declaration", "grant": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058write_family$1260$()), "select": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058family_match$1260$(_x_0);
}), "clauses": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-inspect/debug-study-v1/production-adoption-v1/public-api-v1/docs/ordinary-v1/query-candidate-v1/declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$()))), "mode": {$: "../../../../../../bendvy/experiments/public-inspect/debug-study-v1/production-adoption-v1/public-api-v1/docs/ordinary-v1/query-candidate-v1/declaration.Write"}}, "tail": {$: "Nil"}}};
}

function $$$$047generic$045assembly$045v1$047second$045owner$058installed$(_original_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Installed") {
    const _world_0 = _result_0["world"];
    const _inverse_0 = _result_0["undo"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_0, "undo": run_clo((_x_0) => {
  return $$$$047generic$045assembly$045v1$047second$045owner$058restored$(_original_0, _canonical_0, _inverse_0(_x_0));
})};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_1, "payload": ($$$$047generic$045assembly$045v1$047second$045owner$058repair$(_original_0, _canonical_0, _owner_0)), "error": _error_0};
  } else {
    const _world_2 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_2, "recovery": _recovery_0, "error": _error_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1260$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1260$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0)));
}

function $$$$047generic$045assembly$045v1$047second$045owner$058family$() {
  return {$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$())))};
}

function $$$$047generic$045assembly$045v1$047second$045owner$058normalized$(_owner_0, _canonical_0) {
  if (_owner_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _owner_0["value"];
    const _words_0 = _t_0["words"];
    const _flags_0 = _t_0["flags"];
    return {$: "Some", "value": {$: "../generic-assembly-v1/second-owner.Owner", "raw": _canonical_0, "words": _words_0, "flags": _flags_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $done_3$(_previous_0, _value_0) {
  return $step_4$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058run_skip$() {
  return $$$$047generic$045assembly$045v1$047public$045fixture$058created_skip$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(100)))));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058completed_view$(_rows_0, _result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "../generic-assembly-v1/public-fixture.CompletedView", "args": _view_0, "rows": _rows_0};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058instance_join$(_namespace_0, _id_0, _name_0, _access_0, _result_0) {
  const _state_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _state_0}, "snd": {$: "../generic-assembly-v1/public-fixture.InstanceView", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "state": _view_0}};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058state_view$(_value_0) {
  const _codec_0 = _value_0["codec"];
  const _recovery_0 = _value_0["recovery"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058state_join$(_codec_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058recoveries_view$(_recovery_0)));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058args_join$(_fail_0, _incoming_0, _operations_0, _writes_0) {
  const _incoming_1 = _incoming_0["fst"];
  const _a_0 = _incoming_0["snd"];
  const _operations_1 = _operations_0["fst"];
  const _b_0 = _operations_0["snd"];
  const _writes_1 = _writes_0["fst"];
  const _c_0 = _writes_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/public-fixture.Args", "incoming": _incoming_1, "operations": _operations_1, "writes": _writes_1, "fail": _fail_0}, "snd": {$: "../generic-assembly-v1/public-fixture.ArgsView", "incoming": _a_0, "operations": _b_0, "writes": _c_0, "fail": _fail_0}};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058incoming_view$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _t_0 = _value_0["value"];
    const _first_0 = _t_0["first"];
    const _second_0 = _t_0["second"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058incoming_join$(($$$$047generic$045assembly$045v1$047observation$058payload$(_first_0)), ($$$$047generic$045assembly$045v1$047observation$058payload$(_second_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058operations_view$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058operations_join$(($$$$047generic$045assembly$045v1$047public$045fixture$058operation_view$(_head_0)), ($$$$047generic$045assembly$045v1$047public$045fixture$058operations_view$(_rest_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058writes_view$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058writes_join$(($$$$047generic$045assembly$045v1$047public$045fixture$058write_view$(_head_0)), ($$$$047generic$045assembly$045v1$047public$045fixture$058writes_view$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058completed$1261$(_namespace_0, _id_0, _name_0, _access_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/local.Succeeded") {
    const _world_0 = _outcome_0["world"];
    const _local_0 = _outcome_0["local"];
    const _out_0 = _outcome_0["output"];
    return {$: "../../../../../../bendvy/src/ecs/local.Completed", "world": _world_0, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, "result": {$: "Done", "value": _out_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _local_1 = _outcome_0["local"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/local.Completed", "world": _world_1, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_1}, "result": {$: "Fail", "error": _error_0}};
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058runner$(_world_0, _state_0, _args_0) {
  const _codec_0 = _state_0["codec"];
  const _previous_0 = _state_0["recovery"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058handles$(_codec_0, _previous_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047observation$058leaf$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": {$: "Con", "head": _view_0, "tail": {$: "Nil"}}};
}

function $$$$047generic$045assembly$045v1$047observation$058option$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047generic$045assembly$045v1$047observation$058some$(($$$$047generic$045assembly$045v1$047observation$058payload$(_owner_1)));
  }
}

function $$$$047generic$045assembly$045v1$047observation$058slot_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045decode$047adoption$045v1$047observation$058joined$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058write_family$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058set$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058family_match$1260$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_join$1260$({$: "../../../../../../bendvy/src/ecs/compose.Required"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1260$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047generic$045assembly$045v1$047second$045owner$058identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1260$("second-owner");
}

function $$$$047generic$045assembly$045v1$047second$045owner$058restored$(_original_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": _world_0, "payload": ($$$$047generic$045assembly$045v1$047second$045owner$058repair$(_original_0, _canonical_0, _owner_0))};
  } else {
    const _world_1 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": _recovery_0, "error": _error_0};
  }
}

function $$$$047generic$045assembly$045v1$047second$045owner$058repair$(_original_0, _canonical_0, _owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "../generic-assembly-v1/request.Packet", "owner": {$: "None"}, "original": _original_0, "canonical": _canonical_0};
  } else {
    const _t_0 = _owner_0["value"];
    const _words_0 = _t_0["words"];
    const _flags_0 = _t_0["flags"];
    return {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": {$: "../generic-assembly-v1/second-owner.Owner", "raw": _original_0, "words": _words_0, "flags": _flags_0}}, "original": _original_0, "canonical": _canonical_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1260$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $step_4$(_previous_0) {
  return $done_4$(_previous_0, {$: "First", "label": {$: "Success"}, "value": ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058run$(false, true))});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058created_skip$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058registered_skip$(($$$$047generic$045assembly$045v1$047public$045fixture$058define$(_world_0)));
  } else {
    return {$: "../generic-assembly-v1/public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/public-fixture.FactoryRefusedView"}};
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058state_join$(_codec_0, _result_0) {
  const _recovery_0 = _result_0["fst"];
  const _views_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/public-fixture.State", "codec": _codec_0, "recovery": _recovery_0}, "snd": {$: "../generic-assembly-v1/public-fixture.StateView", "codec": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058codec$1260$(_codec_0)), "recovery": _views_0}};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058recoveries_view$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058recoveries_join$(($$$$047generic$045assembly$045v1$047public$045fixture$058recovery_view$(_head_0)), ($$$$047generic$045assembly$045v1$047public$045fixture$058recoveries_view$(_rest_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058incoming_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": {$: "../generic-assembly-v1/public-fixture.IncomingPair", "first": _left_1, "second": _right_1}}, "snd": {$: "Some", "value": {$: "../generic-assembly-v1/public-fixture.IncomingView", "first": _a_0, "second": _b_0}}};
}

function $$$$047generic$045assembly$045v1$047observation$058payload$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _words_0 = _owner_0["words"];
  const _flags_0 = _owner_0["flags"];
  return $$$$047generic$045assembly$045v1$047observation$058payload_done$(_raw_0, ($$$$047generic$045assembly$045v1$047observation$058array$(_words_0)), ($$$$047generic$045assembly$045v1$047observation$058bools$(_flags_0)));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058operations_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _view_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _view_0, "tail": _views_0}};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058operation_view$(_value_0) {
  if (_value_0.$ === "../generic-assembly-v1/request.Accepted") {
    const _target_0 = _value_0["target"];
    const _spawned_0 = _value_0["spawned"];
    const _canonical_0 = _value_0["canonical"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": _spawned_0, "canonical": _canonical_0}, "snd": {$: "../generic-assembly-v1/public-fixture.AcceptedView", "target": _target_0, "spawned": _spawned_0, "canonical": _canonical_0}};
  } else {
    const _owner_0 = _value_0["owner"];
    const _error_0 = _value_0["error"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058operation_refused$(_error_0, ($$$$047generic$045assembly$045v1$047observation$058option$(_owner_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058writes_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _view_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _view_0, "tail": _views_0}};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058write_view$(_value_0) {
  if (_value_0.$ === "../generic-assembly-v1/owned-component.Written") {
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/owned-component.Written"}, "snd": {$: "../generic-assembly-v1/public-fixture.WrittenView"}};
  } else {
    const _owner_0 = _value_0["owner"];
    const _error_0 = _value_0["error"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058write_refused$(_error_0, ($$$$047generic$045assembly$045v1$047observation$058option$(_owner_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058handles$(_codec_0, _previous_0, _args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _handles_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058traversed$(_codec_0, _previous_0, run_loop($$$$047generic$045assembly$045v1$047assembly$045traversal$058run_rows$1260$(_handles_0, 0, {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058begin$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)))), "declaration": _codec_0}, "handle": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": 0, "id": 0}, "error": {$: "None"}, "cursor": 0, "receipts": {$: "Nil"}, "pending": {$: "Nil"}}, _args_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047generic$045assembly$045v1$047observation$058some$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _view_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get$1260$({$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$())))}, _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058set$1260$(_frame_0, _replacement_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1260$({$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$())))}, _tx_0, _handle_0, _replacement_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_join$1260$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1260$(_key_0) {
  return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1260$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1260$({$: "../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $done_4$(_previous_0, _value_0) {
  return $step_5$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058run$(_fail_0, _seed_0) {
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058created$(_fail_0, _seed_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(100)))));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058registered_skip$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/local.Registered") {
    const _world_0 = _result_0["world"];
    const _instance_0 = _result_0["instance"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058skipped_before$(_instance_0, ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_0)));
  } else {
    return {$: "../generic-assembly-v1/public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/public-fixture.RegistrationRefusedView"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058codec$1260$(_declaration_0) {
  const _codec_0 = _declaration_0["codec"];
  return _codec_0;
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058recoveries_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _view_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _view_0, "tail": _views_0}};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058recovery_view$(_value_0) {
  const _args_0 = _value_0["args"];
  const _owners_0 = _value_0["owners"];
  const _pending_0 = _value_0["pending"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058recovery_join$(($$$$047generic$045assembly$045v1$047public$045fixture$058args_view$(_args_0)), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_views$(_owners_0)), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_views$(_pending_0)));
}

function $$$$047generic$045assembly$045v1$047observation$058payload_done$(_raw_0, _result_0, _flagged_0) {
  const _owner_0 = _result_0["fst"];
  const _cells_0 = _result_0["snd"];
  const _flags_0 = _flagged_0["fst"];
  const _view_0 = _flagged_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/second-owner.Owner", "raw": _raw_0, "words": _owner_0, "flags": _flags_0}, "snd": {$: "../generic-assembly-v1/observation.PayloadView", "raw": _raw_0, "words": _cells_0, "flags": _view_0}};
}

function $$$$047generic$045assembly$045v1$047observation$058array$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047observation$058joined$(($$$$047generic$045assembly$045v1$047observation$058array$(_left_0)), ($$$$047generic$045assembly$045v1$047observation$058array$(_right_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058operation_refused$(_error_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Refused", "owner": _owner_0, "error": _error_0}, "snd": {$: "../generic-assembly-v1/public-fixture.RefusedView", "owner": _view_0, "error": _error_0}};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058write_refused$(_error_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/owned-component.Refused", "owner": _owner_0, "error": _error_0}, "snd": {$: "../generic-assembly-v1/public-fixture.WriteRefusedView", "owner": _view_0, "error": _error_0}};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058traversed$(_codec_0, _previous_0, _result_0) {
  const _frame_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _args_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _t_2 = _t_1["fst"];
  if (_t_2.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _rows_0 = _t_1["snd"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058success$(_codec_0, _previous_0, _args_0, _rows_0, _frame_0);
  } else {
    const _error_0 = _t_2["error"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058abort$(_error_0, _codec_0, _previous_0, _args_0, _frame_0);
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058run_rows$1260$(_handles_0, _cursor_0, _frame_0, _state_0, _values_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _frame_0, "snd": {$: "Tuple", "fst": _state_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": ($List$reverse$(_values_0))}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047generic$045assembly$045v1$047assembly$045traversal$058selected$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047generic$045assembly$045v1$047assembly$045traversal$058run_rows$1260$(_rest_0, _cursor_0, _x_0, _x_1, _x_2);
});
});
}), _state_0, _values_0, ($$$$047generic$045assembly$045v1$047public$045fixture$058selector$(($$$$047generic$045assembly$045v1$047assembly$045traversal$058at_handle$1260$(_frame_0, _handle_0, _cursor_0)))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058begin$1260$(_tx_0) {
  return {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get$1260$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058written$1260$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _reason_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Required") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Present") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../bendvy/src/ecs/compose.Absent") {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../../../bendvy/src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1260$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1260$({$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $step_5$(_previous_0) {
  return $done_5$(_previous_0, {$: "First", "label": {$: "Failure"}, "value": ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058run$(true, true))});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058created$(_fail_0, _seed_0, _result_0) {
  if (!_seed_0) {
    if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
      const _world_0 = _result_0["world"];
      return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058registered$(_fail_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058define$(_world_0)));
    } else {
      return {$: "../generic-assembly-v1/first-public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/first-public-fixture.FactoryRefusedView"}};
    }
  } else {
    if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
      const _world_1 = _result_0["world"];
      return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058reserved$(_fail_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_1)));
    } else {
      return {$: "../generic-assembly-v1/first-public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/first-public-fixture.FactoryRefusedView"}};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058skipped_before$(_instance_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058skipped_args$(_before_0, ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_0)), ($$$$047generic$045assembly$045v1$047public$045fixture$058instance_view$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058skip$1260$(_instance_0)))), ($$$$047generic$045assembly$045v1$047public$045fixture$058args_view$({$: "../generic-assembly-v1/public-fixture.Args", "incoming": {$: "Some", "value": {$: "../generic-assembly-v1/public-fixture.IncomingPair", "first": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(11)), "second": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(22))}}, "operations": {$: "Nil"}, "writes": {$: "Nil"}, "fail": false})));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058recovery_join$(_args_0, _owners_0, _pending_0) {
  const _args_1 = _args_0["fst"];
  const _a_0 = _args_0["snd"];
  const _owners_1 = _owners_0["fst"];
  const _b_0 = _owners_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _c_0 = _pending_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/public-fixture.Recovery", "args": _args_1, "owners": _owners_1, "pending": _pending_1}, "snd": {$: "../generic-assembly-v1/public-fixture.RecoveryView", "args": _a_0, "owners": _b_0, "pending": _c_0}};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_views$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_views_join$(($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_view$(_head_0)), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_views$(_rest_0)));
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_views$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_join$(($$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_view$(_head_0)), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_views$(_rest_0)));
  }
}

function $$$$047generic$045assembly$045v1$047observation$058joined$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058success$(_codec_0, _previous_0, _args_0, _rows_0, _frame_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _t_2 = _t_1["prepared"];
  if (_t_2.$ === "Nil") {
    const __0 = _t_0["declaration"];
    const __1 = _frame_0["handle"];
    const __2 = _frame_0["error"];
    const __3 = _frame_0["cursor"];
    const __4 = _frame_0["receipts"];
    const _t_3 = _frame_0["pending"];
    if (_t_3.$ === "Nil") {
      return $$$$047generic$045assembly$045v1$047public$045fixture$058committed$(_codec_0, _previous_0, _args_0, _rows_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../../../../../bendvy/src/ecs/transaction.Success"})));
    } else {
      return $$$$047generic$045assembly$045v1$047public$045fixture$058abort$({$: "../../../../../../bendvy/src/ecs/compose.UserError", "error": {$: "Unit"}}, _codec_0, _previous_0, _args_0, {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}}, "declaration": __0}, "handle": __1, "error": __2, "cursor": __3, "receipts": __4, "pending": _t_3});
    }
  } else {
    const __5 = _t_0["declaration"];
    const __6 = _frame_0["handle"];
    const __7 = _frame_0["error"];
    const __8 = _frame_0["cursor"];
    const __9 = _frame_0["receipts"];
    const _34_0 = _frame_0["pending"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058abort$({$: "../../../../../../bendvy/src/ecs/compose.UserError", "error": {$: "Unit"}}, _codec_0, _previous_0, _args_0, {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _t_2}, "declaration": __5}, "handle": __6, "error": __7, "cursor": __8, "receipts": __9, "pending": _34_0});
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058abort$(_error_0, _codec_0, _previous_0, _args_0, _frame_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058recovered$(_error_0, _codec_0, _previous_0, _args_0, _prepared_0, _pending_0, run_loop($$$$047generic$045assembly$045v1$047owned$045journal$058abort$1260$(_receipts_0, _tx_0)));
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058selected$1260$(_next_0, _state_0, _values_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_next_0(_frame_0)(_state_0), _values_0);
  } else {
    return $$$$047generic$045assembly$045v1$047assembly$045traversal$058returned$1260$(_next_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1260$(_state_0, _frame_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058selector$(_frame_0) {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058select$1260$(_frame_0);
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058at_handle$1260$(_frame_0, _handle_0, _cursor_0) {
  const _owner_0 = _frame_0["owner"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": _owner_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_previous_0, _error_0) {
  if (_previous_0.$ === "None") {
    return {$: "Some", "value": _error_0};
  } else {
    const _previous_1 = _previous_0["value"];
    return {$: "Some", "value": _previous_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}}, "snd": {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1260$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1260$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047generic$045assembly$045v1$047second$045owner$058take$(_column_0) {
  return {$: "Tuple", "fst": {$: "Unit"}, "snd": _column_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $done_5$(_previous_0, _value_0) {
  return $step_6$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058registered$(_fail_0, _value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/local.Registered") {
    const _world_0 = _value_0["world"];
    const _instance_0 = _value_0["instance"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058started$(_fail_0, _instance_0, ($$$$047generic$045assembly$045v1$047first$045observation$058snapshot$(_world_0)));
  } else {
    return {$: "../generic-assembly-v1/first-public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/first-public-fixture.RegistrationRefusedView"}};
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058define$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register$1262$(_world_0, "declared-owned-system", ($$$$047generic$045assembly$045v1$047declared$058access$1261$()), {$: "../generic-assembly-v1/first-public-fixture.State", "codec": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058constructed$1261$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Integer"})), "recovery": {$: "Nil"}});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058reserved$(_fail_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_0["handle"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058activated$(_fail_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _target_0)));
  } else {
    return {$: "../generic-assembly-v1/first-public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/first-public-fixture.FactoryRefusedView"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047generic$045assembly$045v1$047first$045owner$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058skipped_args$(_before_0, _world_0, _instance_0, _args_0) {
  const _view_0 = _args_0["snd"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058report$(_before_0, {$: "../generic-assembly-v1/public-fixture.SkippedView", "args": _view_0}, _world_0, _instance_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058skip$1260$(_instance_0) {
  return _instance_0;
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_views_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _a_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _b_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _a_0, "tail": _b_0}};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_view$(_value_0) {
  const _owner_0 = _value_0["owner"];
  const _original_0 = _value_0["original"];
  const _canonical_0 = _value_0["canonical"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_view_done$(_original_0, _canonical_0, ($$$$047generic$045assembly$045v1$047observation$058option$(_owner_0)));
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _view_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _view_0, "tail": _views_0}};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_view$(_value_0) {
  const _t_0 = _value_0["owner"];
  const _t_1 = _t_0["previous"];
  const _target_0 = _t_1["handle"];
  const _owner_0 = _t_1["owner"];
  const _stamp_0 = _t_0["stamp"];
  const _error_0 = _value_0["error"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_view_join$(_target_0, _stamp_0, _error_0, ($$$$047generic$045assembly$045v1$047observation$058option$(_owner_0)));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058committed$(_codec_0, _previous_0, _args_0, _rows_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../bendvy/src/ecs/local.Succeeded", "world": _world_0, "local": {$: "../generic-assembly-v1/public-fixture.State", "codec": _codec_0, "recovery": _previous_0}, "output": {$: "Tuple", "fst": _args_0, "snd": _rows_0}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_0, "local": {$: "../generic-assembly-v1/public-fixture.State", "codec": _codec_0, "recovery": {$: "Con", "head": {$: "../generic-assembly-v1/public-fixture.Recovery", "args": _args_0, "owners": {$: "Nil"}, "pending": {$: "Nil"}}, "tail": _previous_0}}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058recovered$(_error_0, _codec_0, _previous_0, _args_0, _prepared_0, _pending_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _owners_0 = _result_0["owners"];
  const _more_0 = _result_0["pending"];
  return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_0, "local": {$: "../generic-assembly-v1/public-fixture.State", "codec": _codec_0, "recovery": {$: "Con", "head": {$: "../generic-assembly-v1/public-fixture.Recovery", "args": _args_0, "owners": ($List$append$(_owners_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1260$(_prepared_0)))), "pending": ($List$append$(_pending_0, _more_0))}, "tail": _previous_0}}, "error": _error_0};
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058abort$1260$(_receipts_0, _tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  return $$$$047generic$045assembly$045v1$047owned$045journal$058counted$1260$(_receipts_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_undo_0)));
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058returned$1260$(_next_0, _values_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _owner_0 = _t_0["owner"];
  const _handle_0 = _t_0["handle"];
  const _error_0 = _t_0["error"];
  const _cursor_0 = _t_0["cursor"];
  const _receipts_0 = _t_0["receipts"];
  const _pending_0 = _t_0["pending"];
  const _t_1 = _observed_0["snd"];
  const _state_0 = _t_1["fst"];
  const _t_2 = _t_1["snd"];
  const _outcome_0 = _t_2["fst"];
  const _value_0 = _t_2["snd"];
  return $$$$047generic$045assembly$045v1$047assembly$045traversal$058completed$1260$(_next_0, {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": _owner_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, _state_0, {$: "Con", "head": _value_0, "tail": _values_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058outcome$1260$(_error_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, _ctx_0) {
  return $$$$047generic$045assembly$045v1$047public$045fixture$058body$1260$(_args_0, _ctx_0);
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058select$1260$(_frame_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058selected_join$1260$(_declaration_0, _prepared_0, _receipts_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058selector$1260$(($$$$047generic$045assembly$045v1$047public$045fixture$058query$())))({$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1260$(_id_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/component.Written", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../../../../bendvy/src/ecs/component.WriteRejected", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../../../../bendvy/src/ecs/component.WriteFailure", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_replaced$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1260$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1260$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $step_6$(_previous_0) {
  return $done_6$(_previous_0, {$: "First", "label": {$: "NoMatch"}, "value": ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058run$(false, false))});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058started$(_fail_0, _instance_0, _value_0) {
  const _world_0 = _value_0["fst"];
  const _before_0 = _value_0["snd"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058ran$(_before_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058run$1262$(_instance_0, _world_0, {$: "../generic-assembly-v1/first-public-fixture.Args", "incoming": {$: "Some", "value": {$: "../generic-assembly-v1/first-public-fixture.IncomingPair", "first": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(11)), "second": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(22))}}, "operations": {$: "Nil"}, "writes": {$: "Nil"}, "fail": _fail_0})));
}

function $$$$047generic$045assembly$045v1$047first$045observation$058snapshot$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystem_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047generic$045assembly$045v1$047first$045observation$058assembled$({$: "../generic-assembly-v1/first-observation.Meta", "namespace": _namespace_0, "nextId": _next_0, "highWater": _high_0, "capacity": _capacity_0, "depth": _depth_0, "events": _events_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, ($$$$047generic$045assembly$045v1$047first$045observation$058bools$(_live_0)), ($$$$047generic$045assembly$045v1$047first$045observation$058column$1260$(_store_0)), ($$$$047generic$045assembly$045v1$047observation$058payload$(_resource_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register$1262$(_world_0, _name_0, _access_0, _local_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_named$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0, _local_0);
}

function $$$$047generic$045assembly$045v1$047declared$058access$1261$() {
  return $List$append$(($$$$047generic$045assembly$045v1$047declared$058access_clauses$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058clauses$1261$(($$$$047generic$045assembly$045v1$047declared$058query$1261$()))))), {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1263$("decoded-resource")))), "tail": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058constructed$1261$(_codec_0) {
  return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/persistence-declaration.Constructed", "codec": _codec_0};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058activated$(_fail_0, _target_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Accepted") {
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058seeded$(_fail_0, ($$$$047generic$045assembly$045v1$047first$045owner$058install$(_world_0, _target_0, {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(10))}, "original": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number", "value": 10}, "canonical": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number", "value": 10}})));
  } else {
    return {$: "../generic-assembly-v1/first-public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/first-public-fixture.FactoryRefusedView"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047generic$045assembly$045v1$047first$045owner$058empty$(_unit_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1261$();
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_view_done$(_original_0, _canonical_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Packet", "owner": _owner_0, "original": _original_0, "canonical": _canonical_0}, "snd": {$: "../generic-assembly-v1/recovery-fixture.PacketView", "owner": _view_0, "original": _original_0, "canonical": _canonical_0}};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_view_join$(_target_0, _stamp_0, _error_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/owned-journal.Pending", "owner": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": _owner_0}, "stamp": _stamp_0}, "error": _error_0}, "snd": {$: "../generic-assembly-v1/recovery-fixture.PendingView", "target": _target_0, "owner": _view_0, "stamp": _stamp_0, "error": _error_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1260$($0) {
  for (;;) {
    {
      const _prepared_0 = $0;
      if (_prepared_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          continue;
        } else {
          const _payload_0 = _t_0["payload"];
          const _tail_1 = _prepared_0["tail"];
          return {$: "Con", "head": _payload_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1260$(_tail_1))};
        }
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058counted$1260$(_receipts_0, _world_0, _result_0) {
  const _undo_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047owned$045journal$058rollback$1260$(_receipts_0, _undo_0, _count_0, _world_0, {$: "Nil"}, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_tail_0)));
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058completed$1260$(_next_0, _frame_0, _state_0, _values_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/transaction.Failure") {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _frame_0, "snd": {$: "Tuple", "fst": _state_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}}};
  } else {
    return run_tail(_next_0(_frame_0)(_state_0), _values_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058outcome$1260$(_internal_0, _user_0) {
  if (_internal_0.$ === "Some") {
    const _error_0 = _internal_0["value"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": {$: "../../../../../../bendvy/src/ecs/compose.AccessError", "error": _error_0}};
  } else {
    if (_user_0.$ === "../../../../../../bendvy/src/ecs/transaction.Failure") {
      const _error_1 = _user_0["error"];
      return {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": {$: "../../../../../../bendvy/src/ecs/compose.UserError", "error": _error_1}};
    } else {
      return {$: "../../../../../../bendvy/src/ecs/transaction.Success"};
    }
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058body$1260$(_args_0, _ctx_0) {
  return $$$$047generic$045assembly$045v1$047public$045fixture$058read_before$1260$(_args_0, run_loop($$$$047generic$045assembly$045v1$047public$045fixture$058read$1260$(_ctx_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058selected_join$1260$(_declaration_0, _prepared_0, _receipts_0, _pending_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _handle_0 = _t_0["handle"];
  const _error_0 = _t_0["error"];
  const _cursor_0 = _t_0["cursor"];
  const _selected_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": _selected_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058selector$1260$(_declaration_0) {
  const _select_0 = _declaration_0["select"];
  return _select_0;
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058query$() {
  return $$$$047generic$045assembly$045v1$047declared$058query$1260$();
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_replaced$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1260$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0) {
  return _column_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $done_6$(_previous_0, _value_0) {
  return $step_7$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058ran$(_before_0, _value_0) {
  if (_value_0.$ === "../../../../../../bendvy/src/ecs/local.Completed") {
    const _world_0 = _value_0["world"];
    const _instance_0 = _value_0["instance"];
    const _result_0 = _value_0["result"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058report$(_before_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058result_view$(_result_0)), ($$$$047generic$045assembly$045v1$047first$045observation$058snapshot$(_world_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058instance_view$(_instance_0)));
  } else {
    const _world_1 = _value_0["world"];
    const _instance_1 = _value_0["instance"];
    const _args_0 = _value_0["args"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058report$(_before_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058refused_view$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058args_view$(_args_0)))), ($$$$047generic$045assembly$045v1$047first$045observation$058snapshot$(_world_1)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058instance_view$(_instance_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058run$1262$(_instance_0, _world_0, _args_0) {
  const _namespace_0 = _instance_0["namespace"];
  const _id_0 = _instance_0["id"];
  const _name_0 = _instance_0["name"];
  const _access_0 = _instance_0["access"];
  const _local_0 = _instance_0["local"];
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058checked$1262$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _args_0);
}

function $$$$047generic$045assembly$045v1$047first$045observation$058assembled$(_meta_0, _live_0, _store_0, _resource_0, _pending_0) {
  const _namespace_0 = _meta_0["namespace"];
  const _next_0 = _meta_0["nextId"];
  const _high_0 = _meta_0["highWater"];
  const _capacity_0 = _meta_0["capacity"];
  const _depth_0 = _meta_0["depth"];
  const _events_0 = _meta_0["events"];
  const _registrations_0 = _meta_0["registrations"];
  const _nextSystem_0 = _meta_0["nextSystemId"];
  const _clock_0 = _meta_0["clock"];
  const _live_1 = _live_0["fst"];
  const _a_0 = _live_0["snd"];
  const _store_1 = _store_0["fst"];
  const _b_0 = _store_0["snd"];
  const _resource_1 = _resource_0["fst"];
  const _c_0 = _resource_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _count_0 = _pending_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _next_0, "highWater": _high_0, "live": _live_1, "capacity": _capacity_0, "depth": _depth_0, "store": _store_1, "resource": _resource_1, "events": _events_0, "pending": _pending_1, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "snd": {$: "../generic-assembly-v1/first-observation.Snapshot", "meta": {$: "../generic-assembly-v1/first-observation.Meta", "namespace": _namespace_0, "nextId": _next_0, "highWater": _high_0, "capacity": _capacity_0, "depth": _depth_0, "events": _events_0, "registrations": _registrations_0, "nextSystemId": _nextSystem_0, "clock": _clock_0}, "live": _a_0, "column": _b_0, "resource": _c_0, "pending": _count_0}};
}

function $$$$047generic$045assembly$045v1$047first$045observation$058bools$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047first$045observation$058bool_join$(($$$$047generic$045assembly$045v1$047first$045observation$058bools$(_left_0)), ($$$$047generic$045assembly$045v1$047first$045observation$058bools$(_right_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045observation$058column$1260$(_owner_0) {
  if (_owner_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return $$$$047generic$045assembly$045v1$047first$045observation$058column_done$1260$(_stamps_0, ($$$$047generic$045assembly$045v1$047first$045observation$058slots$(_values_0)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": {$: "../generic-assembly-v1/first-observation.ColumnView", "supported": false, "slots": {$: "Nil"}, "stamps": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_named$1262$(_named_0, _name_0, _access_0, _local_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_result$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0, _local_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047generic$045assembly$045v1$047declared$058access_clauses$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _values_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _values_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047generic$045assembly$045v1$047declared$058access_clauses$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058clauses$1261$(_declaration_0) {
  const _clauses_0 = _declaration_0["clauses"];
  return _clauses_0;
}

function $$$$047generic$045assembly$045v1$047declared$058query$1261$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058write$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1263$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1263$(_key_0) {
  return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058seeded$(_fail_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Installed") {
    const _world_0 = _result_0["world"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058registered$(_fail_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058define$(_world_0)));
  } else {
    return {$: "../generic-assembly-v1/first-public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/first-public-fixture.FactoryRefusedView"}};
  }
}

function $$$$047generic$045assembly$045v1$047first$045owner$058install$(_world_0, _target_0, _packet_0) {
  const _owner_0 = _packet_0["owner"];
  const _original_0 = _packet_0["original"];
  const _canonical_0 = _packet_0["canonical"];
  return $$$$047generic$045assembly$045v1$047first$045owner$058installed$(_original_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1261$(($$$$047generic$045assembly$045v1$047first$045owner$058family$()), _world_0, {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": ($$$$047generic$045assembly$045v1$047first$045owner$058normalized$(_owner_0, _canonical_0))})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058rollback$1260$(_receipts_0, _undo_0, _count_0, _world_0, _owners_0, _pending_0) {
  if (_receipts_0.$ === "Nil") {
    return {$: "../generic-assembly-v1/owned-journal.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "owners": ($List$reverse$(_owners_0)), "pending": ($List$reverse$(_pending_0))};
  } else {
    const _t_0 = _receipts_0["head"];
    const _position_0 = _t_0["position"];
    const _inverse_0 = _t_0["inverse"];
    const _rest_0 = _receipts_0["tail"];
    return $$$$047generic$045assembly$045v1$047owned$045journal$058unwound$1260$(_inverse_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047generic$045assembly$045v1$047owned$045journal$058rollback$1260$(_rest_0, _x_0, _position_0, _x_1, _x_2, _x_3);
});
});
});
}), _owners_0, _pending_0, ($$$$047generic$045assembly$045v1$047owned$045journal$058stepped$1260$((_count_0 < _position_0 ? 0 : _count_0 - _position_0), _world_0, _undo_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1260$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058read_before$1260$(_args_0, _result_0) {
  const _t_0 = _args_0["incoming"];
  if (_t_0.$ === "None") {
    const _operations_0 = _args_0["operations"];
    const _writes_0 = _args_0["writes"];
    const _fail_0 = _args_0["fail"];
    const _ctx_0 = _result_0["fst"];
    const _view_0 = _result_0["snd"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../generic-assembly-v1/public-fixture.Args", "incoming": {$: "None"}, "operations": _operations_0, "writes": _writes_0, "fail": _fail_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": _view_0}}};
  } else {
    const _t_1 = _t_0["value"];
    const _first_0 = _t_1["first"];
    const _second_0 = _t_1["second"];
    const _operations_1 = _args_0["operations"];
    const _writes_1 = _args_0["writes"];
    const _fail_1 = _args_0["fail"];
    const _ctx_1 = _result_0["fst"];
    const _view_1 = _result_0["snd"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058resource_before$1260$(_first_0, _second_0, _operations_1, _writes_1, _fail_1, _view_1, run_loop($$$$047generic$045assembly$045v1$047public$045fixture$058resource$1260$(_ctx_1, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(200)))));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058read$1260$(_ctx_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read$1260$(_ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_observed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_1, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $step_7$(_previous_0) {
  return $done_7$(_previous_0, {$: "First", "label": {$: "Skip"}, "value": ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058run_skip$())});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058report$(_before_0, _result_0, _world_0, _instance_0) {
  const _after_0 = _world_0["snd"];
  const _view_0 = _instance_0["snd"];
  return {$: "../generic-assembly-v1/first-public-fixture.Report", "before": _before_0, "after": _after_0, "instance": _view_0, "result": _result_0};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058result_view$(_value_0) {
  if (_value_0.$ === "Fail") {
    const _error_0 = _value_0["error"];
    return {$: "../generic-assembly-v1/first-public-fixture.FailedView", "error": _error_0};
  } else {
    const _t_0 = _value_0["value"];
    const _args_0 = _t_0["fst"];
    const _rows_0 = _t_0["snd"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058completed_view$(_rows_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058args_view$(_args_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058instance_view$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _state_0 = _value_0["local"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058instance_join$(_namespace_0, _id_0, _name_0, _access_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058state_view$(_state_0)));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058refused_view$(_result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "../generic-assembly-v1/first-public-fixture.InvocationRefusedView", "args": _view_0};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058args_view$(_value_0) {
  const _incoming_0 = _value_0["incoming"];
  const _operations_0 = _value_0["operations"];
  const _writes_0 = _value_0["writes"];
  const _fail_0 = _value_0["fail"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058args_join$(_fail_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058incoming_view$(_incoming_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058operations_view$(_operations_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058writes_view$(_writes_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058checked$1262$(_allowed_0, _instance_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/local.Refused", "world": _world_0, "instance": _instance_0, "args": _args_0};
  } else {
    const _namespace_0 = _instance_0["namespace"];
    const _id_0 = _instance_0["id"];
    const _name_0 = _instance_0["name"];
    const _access_0 = _instance_0["access"];
    const _local_0 = _instance_0["local"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058completed$1262$(_namespace_0, _id_0, _name_0, _access_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058runner$(_world_0, _local_0, _args_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045observation$058bool_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047generic$045assembly$045v1$047first$045observation$058column_done$1260$(_stamps_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _owner_0, "stamps": _stamps_0}, "snd": {$: "../generic-assembly-v1/first-observation.ColumnView", "supported": true, "slots": _view_0, "stamps": _stamps_0}};
}

function $$$$047generic$045assembly$045v1$047first$045observation$058slots$(_owner_0) {
  if (_owner_0.length === 1) {
    const _owner_1 = _owner_0[0];
    return $$$$047generic$045assembly$045v1$047first$045observation$058leaf$(($$$$047generic$045assembly$045v1$047first$045observation$058option$(_owner_1)));
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047first$045observation$058slot_join$(($$$$047generic$045assembly$045v1$047first$045observation$058slots$(_left_0)), ($$$$047generic$045assembly$045v1$047first$045observation$058slots$(_right_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_result$1262$(_registered_0, _namespace_0, _name_0, _access_0, _local_0) {
  const _world_0 = _registered_0["fst"];
  const _t_0 = _registered_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Registered") {
    const _id_0 = _t_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/local.Registered", "world": _world_0, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/local.RegistrationRejected", "world": _world_0, "local": _local_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058write$1261$() {
  return {$: "../../../../../../bendvy/experiments/public-inspect/debug-study-v1/production-adoption-v1/public-api-v1/docs/ordinary-v1/query-candidate-v1/declaration.Declaration", "grant": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058write_family$1261$()), "select": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058family_match$1261$(_x_0);
}), "clauses": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-inspect/debug-study-v1/production-adoption-v1/public-api-v1/docs/ordinary-v1/query-candidate-v1/declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1262$(($$$$047generic$045assembly$045v1$047first$045owner$058identity$()))), "mode": {$: "../../../../../../bendvy/experiments/public-inspect/debug-study-v1/production-adoption-v1/public-api-v1/docs/ordinary-v1/query-candidate-v1/declaration.Write"}}, "tail": {$: "Nil"}}};
}

function $$$$047generic$045assembly$045v1$047first$045owner$058installed$(_original_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Installed") {
    const _world_0 = _result_0["world"];
    const _inverse_0 = _result_0["undo"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_0, "undo": run_clo((_x_0) => {
  return $$$$047generic$045assembly$045v1$047first$045owner$058restored$(_original_0, _canonical_0, _inverse_0(_x_0));
})};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_1, "payload": ($$$$047generic$045assembly$045v1$047first$045owner$058repair$(_original_0, _canonical_0, _owner_0)), "error": _error_0};
  } else {
    const _world_2 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_2, "recovery": _recovery_0, "error": _error_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1261$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1261$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1261$(_family_0, _world_0, _handle_0)));
}

function $$$$047generic$045assembly$045v1$047first$045owner$058family$() {
  return {$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1262$(($$$$047generic$045assembly$045v1$047first$045owner$058identity$())))};
}

function $$$$047generic$045assembly$045v1$047first$045owner$058normalized$(_owner_0, _canonical_0) {
  if (_owner_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _owner_0["value"];
    const _sentinel_0 = _t_0["sentinel"];
    return {$: "Some", "value": {$: "../../../../../../bendvy/experiments/public-decode/complete-v1/controls.Owner", "value": ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old$(_canonical_0)), "sentinel": _sentinel_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058unwound$1260$(_inverse_0, _next_0, _owners_0, _pending_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _undo_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047owned$045journal$058restored$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return run_tail(_next_0(_undo_0)(_x_0)(_x_1), _x_2);
});
});
}), _owners_0, _pending_0, _inverse_0(_world_0));
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058stepped$1260$($0, $1, $2) {
  for (;;) {
    {
      const _count_0 = $0;
      const _world_0 = $1;
      const _undo_0 = $2;
      if (_count_0 === 0) {
        return {$: "Tuple", "fst": _world_0, "snd": _undo_0};
      } else {
        const _rest_0 = (_count_0 - 1);
        if (_undo_0.$ === "Nil") {
          return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
        } else {
          const _inverse_0 = _undo_0["head"];
          const _tail_0 = _undo_0["tail"];
          $0 = _rest_0;
          $1 = _inverse_0(_world_0);
          $2 = _tail_0;
          continue;
        }
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058resource_before$1260$(_first_0, _second_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058spawned_first$1260$(_second_0, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047public$045fixture$058spawn$1260$(_ctx_0, _first_0)));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058resource$1260$(_ctx_0, _value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1260$(_ctx_0, _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1261$(($$$$047generic$045assembly$045v1$047public$045fixture$058read_field$1260$(($$$$047generic$045assembly$045v1$047public$045fixture$058grants$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../bendvy/src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../../../bendvy/src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, ($$$$047generic$045assembly$045v1$047second$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_1)), "snd": {$: "../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $done_7$(_previous_0, _value_0) {
  return $step_8$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058run_skip$() {
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058created_skip$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(100)))));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058completed_view$(_rows_0, _result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "../generic-assembly-v1/first-public-fixture.CompletedView", "args": _view_0, "rows": _rows_0};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058instance_join$(_namespace_0, _id_0, _name_0, _access_0, _result_0) {
  const _state_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _state_0}, "snd": {$: "../generic-assembly-v1/first-public-fixture.InstanceView", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "state": _view_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058state_view$(_value_0) {
  const _codec_0 = _value_0["codec"];
  const _recovery_0 = _value_0["recovery"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058state_join$(_codec_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058recoveries_view$(_recovery_0)));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058args_join$(_fail_0, _incoming_0, _operations_0, _writes_0) {
  const _incoming_1 = _incoming_0["fst"];
  const _a_0 = _incoming_0["snd"];
  const _operations_1 = _operations_0["fst"];
  const _b_0 = _operations_0["snd"];
  const _writes_1 = _writes_0["fst"];
  const _c_0 = _writes_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/first-public-fixture.Args", "incoming": _incoming_1, "operations": _operations_1, "writes": _writes_1, "fail": _fail_0}, "snd": {$: "../generic-assembly-v1/first-public-fixture.ArgsView", "incoming": _a_0, "operations": _b_0, "writes": _c_0, "fail": _fail_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058incoming_view$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _t_0 = _value_0["value"];
    const _first_0 = _t_0["first"];
    const _second_0 = _t_0["second"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058incoming_join$(($$$$047generic$045assembly$045v1$047first$045observation$058payload$(_first_0)), ($$$$047generic$045assembly$045v1$047first$045observation$058payload$(_second_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058operations_view$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058operations_join$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058operation_view$(_head_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058operations_view$(_rest_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058writes_view$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058writes_join$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058write_view$(_head_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058writes_view$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058completed$1262$(_namespace_0, _id_0, _name_0, _access_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/local.Succeeded") {
    const _world_0 = _outcome_0["world"];
    const _local_0 = _outcome_0["local"];
    const _out_0 = _outcome_0["output"];
    return {$: "../../../../../../bendvy/src/ecs/local.Completed", "world": _world_0, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, "result": {$: "Done", "value": _out_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _local_1 = _outcome_0["local"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/local.Completed", "world": _world_1, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_1}, "result": {$: "Fail", "error": _error_0}};
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058runner$(_world_0, _state_0, _args_0) {
  const _codec_0 = _state_0["codec"];
  const _previous_0 = _state_0["recovery"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058handles$(_codec_0, _previous_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1261$(_world_0)));
}

function $$$$047generic$045assembly$045v1$047first$045observation$058leaf$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": {$: "Con", "head": _view_0, "tail": {$: "Nil"}}};
}

function $$$$047generic$045assembly$045v1$047first$045observation$058option$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}};
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047generic$045assembly$045v1$047first$045observation$058some$(($$$$047generic$045assembly$045v1$047first$045observation$058payload$(_owner_1)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045observation$058slot_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058write_family$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.Write", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1261$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058set$1261$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058family_match$1261$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_join$1261$({$: "../../../../../../bendvy/src/ecs/compose.Required"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1261$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1262$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047generic$045assembly$045v1$047first$045owner$058identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1262$("first-owner");
}

function $$$$047generic$045assembly$045v1$047first$045owner$058restored$(_original_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": _world_0, "payload": ($$$$047generic$045assembly$045v1$047first$045owner$058repair$(_original_0, _canonical_0, _owner_0))};
  } else {
    const _world_1 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": _recovery_0, "error": _error_0};
  }
}

function $$$$047generic$045assembly$045v1$047first$045owner$058repair$(_original_0, _canonical_0, _owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "../generic-assembly-v1/request.Packet", "owner": {$: "None"}, "original": _original_0, "canonical": _canonical_0};
  } else {
    const _t_0 = _owner_0["value"];
    const _sentinel_0 = _t_0["sentinel"];
    return {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": {$: "../../../../../../bendvy/experiments/public-decode/complete-v1/controls.Owner", "value": ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old$(_original_0)), "sentinel": _sentinel_0}}, "original": _original_0, "canonical": _canonical_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1261$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1261$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0);
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old$(_raw_0) {
  return $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_raw$(($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_converted$(_raw_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058restored$1260$(_next_0, _owners_0, _pending_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _owner_0 = _result_0["payload"];
    return run_tail(_next_0(_world_0)({$: "Con", "head": _owner_0, "tail": _owners_0}), _pending_0);
  } else {
    const _world_1 = _result_0["world"];
    const _owner_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return run_tail(_next_0(_world_1)(_owners_0), {$: "Con", "head": {$: "../generic-assembly-v1/owned-journal.Pending", "owner": _owner_1, "error": _error_0}, "tail": _pending_0});
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058spawned_first$1260$(_second_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../generic-assembly-v1/request.Accepted") {
    const _target_0 = _t_0["target"];
    const _spawned_0 = _t_0["spawned"];
    const _canonical_0 = _t_0["canonical"];
    return $$$$047generic$045assembly$045v1$047public$045fixture$058written_first$1260$({$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": _spawned_0, "canonical": _canonical_0}, _second_0, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047public$045fixture$058write$1260$(_ctx_0, _target_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(99)))));
  } else {
    return $$$$047generic$045assembly$045v1$047public$045fixture$058spawned_second$1260$(_t_0, {$: "None"}, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047public$045fixture$058spawn$1260$(_ctx_0, _second_0)));
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058spawn$1260$(_ctx_0, _value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1261$(_ctx_0, _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1260$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1260$(($$$$047generic$045assembly$045v1$047public$045fixture$058resource_field$1260$(($$$$047generic$045assembly$045v1$047public$045fixture$058grants$())))))(_ctx_0), _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058read_field$1260$(_ops_0) {
  const _cap_0 = _ops_0["read"];
  return _cap_0;
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058grants$() {
  return $$$$047generic$045assembly$045v1$047declared$058grants$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_swap$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../../bendvy/src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $step_8$(_previous_0) {
  return $done_8$(_previous_0, {$: "Recovered", "label": {$: "RInterleaved"}, "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058run$({$: "../generic-assembly-v1/recovery-fixture.Interleaved"}))});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058created_skip$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058registered_skip$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058define$(_world_0)));
  } else {
    return {$: "../generic-assembly-v1/first-public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/first-public-fixture.FactoryRefusedView"}};
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058state_join$(_codec_0, _result_0) {
  const _recovery_0 = _result_0["fst"];
  const _views_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/first-public-fixture.State", "codec": _codec_0, "recovery": _recovery_0}, "snd": {$: "../generic-assembly-v1/first-public-fixture.StateView", "codec": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058codec$1261$(_codec_0)), "recovery": _views_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058recoveries_view$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058recoveries_join$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058recovery_view$(_head_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058recoveries_view$(_rest_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058incoming_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": {$: "../generic-assembly-v1/first-public-fixture.IncomingPair", "first": _left_1, "second": _right_1}}, "snd": {$: "Some", "value": {$: "../generic-assembly-v1/first-public-fixture.IncomingView", "first": _a_0, "second": _b_0}}};
}

function $$$$047generic$045assembly$045v1$047first$045observation$058payload$(_owner_0) {
  const _raw_0 = _owner_0["value"];
  const _sentinel_0 = _owner_0["sentinel"];
  return $$$$047generic$045assembly$045v1$047first$045observation$058payload_done$(_raw_0, ($$$$047generic$045assembly$045v1$047first$045observation$058array$(_sentinel_0)));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058operations_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _view_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _view_0, "tail": _views_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058operation_view$(_value_0) {
  if (_value_0.$ === "../generic-assembly-v1/request.Accepted") {
    const _target_0 = _value_0["target"];
    const _spawned_0 = _value_0["spawned"];
    const _canonical_0 = _value_0["canonical"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": _spawned_0, "canonical": _canonical_0}, "snd": {$: "../generic-assembly-v1/first-public-fixture.AcceptedView", "target": _target_0, "spawned": _spawned_0, "canonical": _canonical_0}};
  } else {
    const _owner_0 = _value_0["owner"];
    const _error_0 = _value_0["error"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058operation_refused$(_error_0, ($$$$047generic$045assembly$045v1$047first$045observation$058option$(_owner_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058writes_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _view_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _view_0, "tail": _views_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058write_view$(_value_0) {
  if (_value_0.$ === "../generic-assembly-v1/owned-component.Written") {
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/owned-component.Written"}, "snd": {$: "../generic-assembly-v1/first-public-fixture.WrittenView"}};
  } else {
    const _owner_0 = _value_0["owner"];
    const _error_0 = _value_0["error"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058write_refused$(_error_0, ($$$$047generic$045assembly$045v1$047first$045observation$058option$(_owner_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058handles$(_codec_0, _previous_0, _args_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _handles_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058traversed$(_codec_0, _previous_0, run_loop($$$$047generic$045assembly$045v1$047assembly$045traversal$058run_rows$1261$(_handles_0, 0, {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058begin$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0)))), "declaration": _codec_0}, "handle": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": 0, "id": 0}, "error": {$: "None"}, "cursor": 0, "receipts": {$: "Nil"}, "pending": {$: "Nil"}}, _args_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1261$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047generic$045assembly$045v1$047first$045observation$058some$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": {$: "Some", "value": _view_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058get$1261$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get$1261$({$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1262$(($$$$047generic$045assembly$045v1$047first$045owner$058identity$())))}, _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058set$1261$(_frame_0, _replacement_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058written$1261$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1261$({$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1262$(($$$$047generic$045assembly$045v1$047first$045owner$058identity$())))}, _tx_0, _handle_0, _replacement_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_join$1261$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1262$(_key_0) {
  return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1261$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1261$({$: "../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1261$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_raw$(_converted_0) {
  const _raw_0 = _converted_0["raw"];
  return _raw_0;
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_converted$(_raw_0) {
  if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Missing") {
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Missing"}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null") {
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Null"}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number") {
    const _value_0 = _raw_0["value"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Number", "value": _value_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.SignedInteger") {
    const _negative_0 = _raw_0["negative"];
    const _magnitude_0 = _raw_0["magnitude"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.SignedInteger", "negative": _negative_0, "magnitude": _magnitude_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Float") {
    const _value_1 = _raw_0["value"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Float", "value": _value_1}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Binary64") {
    const _high_0 = _raw_0["high"];
    const _low_0 = _raw_0["low"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Binary64", "high": _high_0, "low": _low_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Text") {
    const _value_2 = _raw_0["value"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Text", "value": _value_2}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text") {
    const _units_0 = _raw_0["units"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Utf16Text", "units": _units_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Boolean") {
    const _value_3 = _raw_0["value"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Boolean", "value": _value_3}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Handle") {
    const _namespace_0 = _raw_0["namespace"];
    const _id_0 = _raw_0["id"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Handle", "namespace": _namespace_0, "id": _id_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array") {
    const _t_0 = _raw_0["items"];
    if (_t_0.$ === "Nil") {
      return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Array", "items": {$: "Nil"}}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
    } else {
      const _head_0 = _t_0["head"];
      const _rest_0 = _t_0["tail"];
      return $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_array$(($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_converted$(_head_0)), ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_converted$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array", "items": _rest_0})));
    }
  } else {
    const _t_1 = _raw_0["fields"];
    if (_t_1.$ === "Nil") {
      return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Object", "fields": {$: "Nil"}}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
    } else {
      const _t_2 = _t_1["head"];
      const _name_0 = _t_2["name"];
      const _value_4 = _t_2["value"];
      const _rest_1 = _t_1["tail"];
      return $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_object$(_name_0, ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_converted$(_value_4)), ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_converted$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object", "fields": _rest_1})));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058written_first$1260$(_first_0, _second_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _written_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058spawned_second$1260$(_first_0, {$: "Some", "value": _written_0}, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047public$045fixture$058spawn$1260$(_ctx_0, _second_0)));
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058write$1260$(_ctx_0, _target_0, _value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1262$(_ctx_0, {$: "../../../../../../bendvy/src/ecs/compose.Insert", "target": _target_0, "value": _value_0});
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058spawned_second$1260$(_first_0, _written_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _second_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047public$045fixture$058resource_after$1260$(_first_0, _second_0, _written_0, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047public$045fixture$058resource$1260$(_ctx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(300)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1261$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1261$(($$$$047generic$045assembly$045v1$047public$045fixture$058spawn_field$1260$(($$$$047generic$045assembly$045v1$047public$045fixture$058grants$())))))(_ctx_0), _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1260$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058resource_field$1260$(_ops_0) {
  const _cap_0 = _ops_0["resource"];
  return _cap_0;
}

function $$$$047generic$045assembly$045v1$047declared$058grants$1260$() {
  return {$: "../generic-assembly-v1/declared.Ops", "read": ($$$$047generic$045assembly$045v1$047assembly$045frame$058read_grant$1260$()), "write": ($$$$047generic$045assembly$045v1$047owned$045component$058grant$1260$()), "spawn": ($$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_grant$1260$()), "decode": ($$$$047generic$045assembly$045v1$047assembly$045frame$058request_grant$1260$()), "resource": ($$$$047generic$045assembly$045v1$047assembly$045frame$058resource_grant$1260$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_swap$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047second$045owner$058put$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $done_8$(_previous_0, _value_0) {
  return $step_9$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058run$(_mode_0) {
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058created$(_mode_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058factory$()), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(100)))));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058registered_skip$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/local.Registered") {
    const _world_0 = _result_0["world"];
    const _instance_0 = _result_0["instance"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058skipped_before$(_instance_0, ($$$$047generic$045assembly$045v1$047first$045observation$058snapshot$(_world_0)));
  } else {
    return {$: "../generic-assembly-v1/first-public-fixture.Unavailable", "result": {$: "../generic-assembly-v1/first-public-fixture.RegistrationRefusedView"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058codec$1261$(_declaration_0) {
  const _codec_0 = _declaration_0["codec"];
  return _codec_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058recoveries_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _view_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _view_0, "tail": _views_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058recovery_view$(_value_0) {
  const _args_0 = _value_0["args"];
  const _owners_0 = _value_0["owners"];
  const _pending_0 = _value_0["pending"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058recovery_join$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058args_view$(_args_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_views$(_owners_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_views$(_pending_0)));
}

function $$$$047generic$045assembly$045v1$047first$045observation$058payload_done$(_raw_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _cells_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/experiments/public-decode/complete-v1/controls.Owner", "value": _raw_0, "sentinel": _owner_0}, "snd": {$: "../generic-assembly-v1/first-observation.PayloadView", "raw": _raw_0, "sentinel": _cells_0}};
}

function $$$$047generic$045assembly$045v1$047first$045observation$058array$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047generic$045assembly$045v1$047first$045observation$058joined$(($$$$047generic$045assembly$045v1$047first$045observation$058array$(_left_0)), ($$$$047generic$045assembly$045v1$047first$045observation$058array$(_right_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058operation_refused$(_error_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Refused", "owner": _owner_0, "error": _error_0}, "snd": {$: "../generic-assembly-v1/first-public-fixture.RefusedView", "owner": _view_0, "error": _error_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058write_refused$(_error_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/owned-component.Refused", "owner": _owner_0, "error": _error_0}, "snd": {$: "../generic-assembly-v1/first-public-fixture.WriteRefusedView", "owner": _view_0, "error": _error_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058traversed$(_codec_0, _previous_0, _result_0) {
  const _frame_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _args_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _t_2 = _t_1["fst"];
  if (_t_2.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _rows_0 = _t_1["snd"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058success$(_codec_0, _previous_0, _args_0, _rows_0, _frame_0);
  } else {
    const _error_0 = _t_2["error"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058abort$(_error_0, _codec_0, _previous_0, _args_0, _frame_0);
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058run_rows$1261$(_handles_0, _cursor_0, _frame_0, _state_0, _values_0) {
  if (_handles_0.$ === "Nil") {
    return {$: "Tuple", "fst": _frame_0, "snd": {$: "Tuple", "fst": _state_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": ($List$reverse$(_values_0))}}};
  } else {
    const _handle_0 = _handles_0["head"];
    const _rest_0 = _handles_0["tail"];
    return $$$$047generic$045assembly$045v1$047assembly$045traversal$058selected$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047generic$045assembly$045v1$047assembly$045traversal$058run_rows$1261$(_rest_0, _cursor_0, _x_0, _x_1, _x_2);
});
});
}), _state_0, _values_0, ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058selector$(($$$$047generic$045assembly$045v1$047assembly$045traversal$058at_handle$1261$(_frame_0, _handle_0, _cursor_0)))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058begin$1261$(_tx_0) {
  return {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058handles_tail_finish$1261$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail$1261$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1261$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058read_join$1261$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get$1261$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get_join$1261$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058written$1261$(_handle_0, _error_0, _cursor_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _reason_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_1, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_2, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1261$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1261$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1261$({$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, ($$$$047generic$045assembly$045v1$047first$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_array$(_head_0, _rest_0) {
  const _head_1 = _head_0["raw"];
  const _items_0 = _rest_0["items"];
  return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Array", "items": {$: "Con", "head": _head_1, "tail": _items_0}}, "items": {$: "Con", "head": _head_1, "tail": _items_0}, "fields": {$: "Nil"}};
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_old_object$(_name_0, _head_0, _rest_0) {
  const _head_1 = _head_0["raw"];
  const _fields_0 = _rest_0["fields"];
  return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedOld", "raw": {$: "../../../../../../bendvy/experiments/public-decode/typed.Object", "fields": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-decode/typed.Field", "name": _name_0, "value": _head_1}, "tail": _fields_0}}, "items": {$: "Nil"}, "fields": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-decode/typed.Field", "name": _name_0, "value": _head_1}, "tail": _fields_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1262$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1262$(($$$$047generic$045assembly$045v1$047public$045fixture$058write_field$1260$(($$$$047generic$045assembly$045v1$047public$045fixture$058grants$())))))(_ctx_0), _input_0);
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058resource_after$1260$(_first_0, _second_0, _written_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../generic-assembly-v1/public-fixture.Args", "incoming": {$: "None"}, "operations": {$: "Con", "head": _second_0, "tail": {$: "Con", "head": _first_0, "tail": _previous_0}}, "writes": ($$$$047generic$045assembly$045v1$047public$045fixture$058write_added$(_written_0, _writes_0)), "fail": _fail_0}, "snd": {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047public$045fixture$058user_outcome$(_fail_0)), "snd": _view_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1261$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058spawn_field$1260$(_ops_0) {
  const _cap_0 = _ops_0["spawn"];
  return _cap_0;
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058read_grant$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058read$1260$(_x_0);
})};
}

function $$$$047generic$045assembly$045v1$047owned$045component$058grant$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047generic$045assembly$045v1$047owned$045component$058set$1260$(_x_0, _x_1);
});
})};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_grant$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn$1260$(_x_0, _x_1);
});
})};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058request_grant$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058request$1260$(_x_0, _x_1);
});
})};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_grant$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_set$1260$(_x_0, _x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0) {
  const _raw_0 = _owner_0["raw"];
  const _words_0 = _owner_0["words"];
  const _flags_0 = _owner_0["flags"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/second-owner.Owner", "raw": _raw_0, "words": _words_0, "flags": _flags_0}, "snd": _raw_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../../../bendvy/src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $step_9$(_previous_0) {
  return $done_9$(_previous_0, {$: "Recovered", "label": {$: "REqualPosition"}, "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058run$({$: "../generic-assembly-v1/recovery-fixture.EqualPosition"}))});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058created$(_mode_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058setup$(_mode_0, _world_0);
  } else {
    return {$: "../generic-assembly-v1/recovery-fixture.CreationRejected"};
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058skipped_before$(_instance_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058skipped_args$(_before_0, ($$$$047generic$045assembly$045v1$047first$045observation$058snapshot$(_world_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058instance_view$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058skip$1261$(_instance_0)))), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058args_view$({$: "../generic-assembly-v1/first-public-fixture.Args", "incoming": {$: "Some", "value": {$: "../generic-assembly-v1/first-public-fixture.IncomingPair", "first": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(11)), "second": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(22))}}, "operations": {$: "Nil"}, "writes": {$: "Nil"}, "fail": false})));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058recovery_join$(_args_0, _owners_0, _pending_0) {
  const _args_1 = _args_0["fst"];
  const _a_0 = _args_0["snd"];
  const _owners_1 = _owners_0["fst"];
  const _b_0 = _owners_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _c_0 = _pending_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/first-public-fixture.Recovery", "args": _args_1, "owners": _owners_1, "pending": _pending_1}, "snd": {$: "../generic-assembly-v1/first-public-fixture.RecoveryView", "args": _a_0, "owners": _b_0, "pending": _c_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_views$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_views_join$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_view$(_head_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_views$(_rest_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_views$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_join$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_view$(_head_0)), ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_views$(_rest_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045observation$058joined$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_a_0, _b_0))};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058success$(_codec_0, _previous_0, _args_0, _rows_0, _frame_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _t_2 = _t_1["prepared"];
  if (_t_2.$ === "Nil") {
    const __0 = _t_0["declaration"];
    const __1 = _frame_0["handle"];
    const __2 = _frame_0["error"];
    const __3 = _frame_0["cursor"];
    const __4 = _frame_0["receipts"];
    const _t_3 = _frame_0["pending"];
    if (_t_3.$ === "Nil") {
      return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058committed$(_codec_0, _previous_0, _args_0, _rows_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1262$(_tx_0, {$: "../../../../../../bendvy/src/ecs/transaction.Success"})));
    } else {
      return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058abort$({$: "../../../../../../bendvy/src/ecs/compose.UserError", "error": {$: "Unit"}}, _codec_0, _previous_0, _args_0, {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}}, "declaration": __0}, "handle": __1, "error": __2, "cursor": __3, "receipts": __4, "pending": _t_3});
    }
  } else {
    const __5 = _t_0["declaration"];
    const __6 = _frame_0["handle"];
    const __7 = _frame_0["error"];
    const __8 = _frame_0["cursor"];
    const __9 = _frame_0["receipts"];
    const _32_0 = _frame_0["pending"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058abort$({$: "../../../../../../bendvy/src/ecs/compose.UserError", "error": {$: "Unit"}}, _codec_0, _previous_0, _args_0, {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _t_2}, "declaration": __5}, "handle": __6, "error": __7, "cursor": __8, "receipts": __9, "pending": _32_0});
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058abort$(_error_0, _codec_0, _previous_0, _args_0, _frame_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058recovered$(_error_0, _codec_0, _previous_0, _args_0, _prepared_0, _pending_0, run_loop($$$$047generic$045assembly$045v1$047owned$045journal$058abort$1261$(_receipts_0, _tx_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058selected$1261$(_next_0, _state_0, _values_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_next_0(_frame_0)(_state_0), _values_0);
  } else {
    return $$$$047generic$045assembly$045v1$047assembly$045traversal$058returned$1261$(_next_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1261$(_state_0, _frame_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058selector$(_frame_0) {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058select$1261$(_frame_0);
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058at_handle$1261$(_frame_0, _handle_0, _cursor_0) {
  const _owner_0 = _frame_0["owner"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": _owner_0, "handle": _handle_0, "error": {$: "None"}, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_tail_loop$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../../../bendvy/src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../../../bendvy/src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_get_join$1261$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_owned$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}}, "snd": {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1261$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1261$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1261$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047generic$045assembly$045v1$047first$045owner$058take$(_column_0) {
  return {$: "Tuple", "fst": {$: "Unit"}, "snd": _column_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1262$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058write_field$1260$(_ops_0) {
  const _cap_0 = _ops_0["write"];
  return _cap_0;
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058write_added$(_written_0, _previous_0) {
  if (_written_0.$ === "None") {
    return _previous_0;
  } else {
    const _written_1 = _written_0["value"];
    return {$: "Con", "head": _written_1, "tail": _previous_0};
  }
}

function $$$$047generic$045assembly$045v1$047public$045fixture$058user_outcome$(_fail_0) {
  if (!_fail_0) {
    return {$: "../../../../../../bendvy/src/ecs/transaction.Success"};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": {$: "Unit"}};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058read$1260$(_frame_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058read_join$1260$(_declaration_0, _prepared_0, _receipts_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1260$(($$$$047generic$045assembly$045v1$047declared$058read_grant$1260$())))({$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}));
}

function $$$$047generic$045assembly$045v1$047owned$045component$058set$1260$(_frame_0, _input_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  const _target_0 = _input_0["target"];
  const _owner_0 = _input_0["value"];
  return $$$$047generic$045assembly$045v1$047owned$045component$058written$1260$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1260$({$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$())))}, _tx_0, _target_0, _owner_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn$1260$(_frame_0, _owner_0) {
  const _t_0 = _frame_0["owner"];
  const _batch_0 = _t_0["batch"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_validated$1260$({$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_0, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058validate$1260$(_declaration_0, _owner_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058request$1260$(_frame_0, _input_0) {
  const _owner_0 = _frame_0["owner"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058request_join$1260$(_handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, ($$$$047generic$045assembly$045v1$047request$058request$1260$(_owner_0, _input_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_set$1260$(_frame_0, _replacement_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_join$1260$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_replace$1260$(_tx_0, _replacement_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $done_9$(_previous_0, _value_0) {
  return $step_10$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058setup$(_mode_0, _world_0) {
  if (_mode_0.$ === "../generic-assembly-v1/recovery-fixture.ReserveRefused") {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058provisioned$({$: "../generic-assembly-v1/recovery-fixture.ReserveRefused"}, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058exhausted$(_world_0)));
  } else {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058provisioned$(_mode_0, _world_0);
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058skipped_args$(_before_0, _world_0, _instance_0, _args_0) {
  const _view_0 = _args_0["snd"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058report$(_before_0, {$: "../generic-assembly-v1/first-public-fixture.SkippedView", "args": _view_0}, _world_0, _instance_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058skip$1261$(_instance_0) {
  return _instance_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_views_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _a_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _b_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _a_0, "tail": _b_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_view$(_value_0) {
  const _owner_0 = _value_0["owner"];
  const _original_0 = _value_0["original"];
  const _canonical_0 = _value_0["canonical"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_view_done$(_original_0, _canonical_0, ($$$$047generic$045assembly$045v1$047first$045observation$058option$(_owner_0)));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _view_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _views_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _rest_0}, "snd": {$: "Con", "head": _view_0, "tail": _views_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_view$(_value_0) {
  const _t_0 = _value_0["owner"];
  const _t_1 = _t_0["previous"];
  const _target_0 = _t_1["handle"];
  const _owner_0 = _t_1["owner"];
  const _stamp_0 = _t_0["stamp"];
  const _error_0 = _value_0["error"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_view_join$(_target_0, _stamp_0, _error_0, ($$$$047generic$045assembly$045v1$047first$045observation$058option$(_owner_0)));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058committed$(_codec_0, _previous_0, _args_0, _rows_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../bendvy/src/ecs/local.Succeeded", "world": _world_0, "local": {$: "../generic-assembly-v1/first-public-fixture.State", "codec": _codec_0, "recovery": _previous_0}, "output": {$: "Tuple", "fst": _args_0, "snd": _rows_0}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_0, "local": {$: "../generic-assembly-v1/first-public-fixture.State", "codec": _codec_0, "recovery": {$: "Con", "head": {$: "../generic-assembly-v1/first-public-fixture.Recovery", "args": _args_0, "owners": {$: "Nil"}, "pending": {$: "Nil"}}, "tail": _previous_0}}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1262$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1262$(_tx_0, _outcome_0);
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058recovered$(_error_0, _codec_0, _previous_0, _args_0, _prepared_0, _pending_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _owners_0 = _result_0["owners"];
  const _more_0 = _result_0["pending"];
  return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_0, "local": {$: "../generic-assembly-v1/first-public-fixture.State", "codec": _codec_0, "recovery": {$: "Con", "head": {$: "../generic-assembly-v1/first-public-fixture.Recovery", "args": _args_0, "owners": ($List$append$(_owners_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1261$(_prepared_0)))), "pending": ($List$append$(_pending_0, _more_0))}, "tail": _previous_0}}, "error": _error_0};
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058abort$1261$(_receipts_0, _tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  return $$$$047generic$045assembly$045v1$047owned$045journal$058counted$1261$(_receipts_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1263$(_undo_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058returned$1261$(_next_0, _values_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _owner_0 = _t_0["owner"];
  const _handle_0 = _t_0["handle"];
  const _error_0 = _t_0["error"];
  const _cursor_0 = _t_0["cursor"];
  const _receipts_0 = _t_0["receipts"];
  const _pending_0 = _t_0["pending"];
  const _t_1 = _observed_0["snd"];
  const _state_0 = _t_1["fst"];
  const _t_2 = _t_1["snd"];
  const _outcome_0 = _t_2["fst"];
  const _value_0 = _t_2["snd"];
  return $$$$047generic$045assembly$045v1$047assembly$045traversal$058completed$1261$(_next_0, {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": _owner_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, _state_0, {$: "Con", "head": _value_0, "tail": _values_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058outcome$1260$(_error_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, _ctx_0) {
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058body$1260$(_args_0, _ctx_0);
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058select$1261$(_frame_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058selected_join$1261$(_declaration_0, _prepared_0, _receipts_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058selector$1261$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058query$())))({$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058collect_checked$1261$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_live_owned$1261$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../bendvy/src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1268$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1261$(_id_0, ($$$$047generic$045assembly$045v1$047first$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/component.Written", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../../../../bendvy/src/ecs/component.WriteRejected", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../../../../bendvy/src/ecs/component.WriteFailure", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_replaced$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1269$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047generic$045assembly$045v1$047first$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1261$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1261$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058read_join$1260$(_declaration_0, _prepared_0, _receipts_0, _pending_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _handle_0 = _t_0["handle"];
  const _error_0 = _t_0["error"];
  const _cursor_0 = _t_0["cursor"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047generic$045assembly$045v1$047declared$058read_grant$1260$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.Read", "get": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058write_read_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058grant$1260$(($$$$047generic$045assembly$045v1$047declared$058query$1260$())))))};
}

function $$$$047generic$045assembly$045v1$047owned$045component$058written$1260$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": {$: "../generic-assembly-v1/owned-component.Written"}};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _owner_0 = _result_0["incoming"];
    const _reason_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_1, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": {$: "../generic-assembly-v1/owned-component.Refused", "owner": {$: "Some", "value": _owner_0}, "error": _reason_0}};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_2, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": {$: "../generic-assembly-v1/owned-component.Refused", "owner": {$: "None"}, "error": _reason_1}};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_validated$1260$(_frame_0, _receipt_0) {
  const _owner_0 = _receipt_0["owner"];
  const _t_0 = _receipt_0["checked"];
  if (_t_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected") {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": _frame_0, "snd": {$: "../generic-assembly-v1/request.Refused", "owner": {$: "Some", "value": _owner_0}, "error": {$: "../generic-assembly-v1/request.Validation", "error": _error_0}}};
  } else {
    const _canonical_0 = _t_0["value"];
    return $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_projected$1260$(_frame_0, _canonical_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058validate$1260$(_declaration_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_owner$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058codec$1260$(_declaration_0)), _owner_0);
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058request_join$1260$(_handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": _owner_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": _output_0};
}

function $$$$047generic$045assembly$045v1$047request$058request$1260$(_frame_0, _input_0) {
  const _batch_0 = _frame_0["batch"];
  const _declaration_0 = _frame_0["declaration"];
  const _operation_0 = _input_0["operation"];
  const _owner_0 = _input_0["owner"];
  return $$$$047generic$045assembly$045v1$047request$058validated$1260$(_declaration_0, _batch_0, _operation_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058validate$1260$(_declaration_0, _owner_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_join$1260$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _tx_0) {
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_replace$1260$(_tx_0, _replacement_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058replace_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058replace_resource$1260$(_world_0, _replacement_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $step_10$(_previous_0) {
  return $done_10$(_previous_0, {$: "Recovered", "label": {$: "RPending"}, "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058run$({$: "../generic-assembly-v1/recovery-fixture.PendingControl"}))});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058provisioned$(_mode_0, _world_0) {
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058registered$(_mode_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register$1260$(_world_0, "immediate-recovery", {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058identity$()))), "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058component$1261$("decoded-resource")))), "tail": {$: "Nil"}}}, {$: "../generic-assembly-v1/recovery-fixture.State", "owners": {$: "Nil"}, "pending": {$: "Nil"}, "during": {$: "None"}, "errors": {$: "Nil"}})));
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058exhausted$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 131073, "highWater": _high_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058packet_view_done$(_original_0, _canonical_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Packet", "owner": _owner_0, "original": _original_0, "canonical": _canonical_0}, "snd": {$: "../generic-assembly-v1/first-public-fixture.PacketView", "owner": _view_0, "original": _original_0, "canonical": _canonical_0}};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058pending_view_join$(_target_0, _stamp_0, _error_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/owned-journal.Pending", "owner": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": _owner_0}, "stamp": _stamp_0}, "error": _error_0}, "snd": {$: "../generic-assembly-v1/first-public-fixture.PendingView", "target": _target_0, "owner": _view_0, "stamp": _stamp_0, "error": _error_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1262$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1262$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1261$($0) {
  for (;;) {
    {
      const _prepared_0 = $0;
      if (_prepared_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          continue;
        } else {
          const _payload_0 = _t_0["payload"];
          const _tail_1 = _prepared_0["tail"];
          return {$: "Con", "head": _payload_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1261$(_tail_1))};
        }
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058counted$1261$(_receipts_0, _world_0, _result_0) {
  const _undo_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047owned$045journal$058rollback$1261$(_receipts_0, _undo_0, _count_0, _world_0, {$: "Nil"}, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1263$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1263$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1263$(_tail_0)));
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045traversal$058completed$1261$(_next_0, _frame_0, _state_0, _values_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/transaction.Failure") {
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": _frame_0, "snd": {$: "Tuple", "fst": _state_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}, "snd": {$: "Nil"}}}};
  } else {
    return run_tail(_next_0(_frame_0)(_state_0), _values_0);
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058body$1260$(_args_0, _ctx_0) {
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058read_before$1260$(_args_0, run_loop($$$$047generic$045assembly$045v1$047first$045public$045fixture$058read$1260$(_ctx_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058selected_join$1261$(_declaration_0, _prepared_0, _receipts_0, _pending_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _handle_0 = _t_0["handle"];
  const _error_0 = _t_0["error"];
  const _cursor_0 = _t_0["cursor"];
  const _selected_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": _selected_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058selector$1261$(_declaration_0) {
  const _select_0 = _declaration_0["select"];
  return _select_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058query$() {
  return $$$$047generic$045assembly$045v1$047declared$058query$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1261$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_replaced$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1261$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047generic$045assembly$045v1$047first$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, _column_0) {
  return _column_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058write_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058grant$1260$(_declaration_0) {
  const _grant_0 = _declaration_0["grant"];
  return _grant_0;
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_projected$1260$(_frame_0, _canonical_0, _result_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  const _owner_0 = _result_0["fst"];
  const _original_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058spawned$1260$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _canonical_0, ($$$$047generic$045assembly$045v1$047immediate$058spawn$1260$(_tx_0, {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _original_0, "canonical": _canonical_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_owner$1260$(_codec_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_projected$1260$(_codec_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
}

function $$$$047generic$045assembly$045v1$047request$058validated$1260$(_declaration_0, _batch_0, _operation_0, _receipt_0) {
  const _owner_0 = _receipt_0["owner"];
  const _t_0 = _receipt_0["checked"];
  if (_t_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected") {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Refused", "owner": {$: "Some", "value": _owner_0}, "error": {$: "../generic-assembly-v1/request.Validation", "error": _error_0}}};
  } else {
    const _canonical_0 = _t_0["value"];
    return $$$$047generic$045assembly$045v1$047request$058enqueue$1260$(_declaration_0, _batch_0, _operation_0, _canonical_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058replace_join$1260$(_replaced_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _replaced_0["fst"];
  const _old_0 = _replaced_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058restore$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058replace_resource$1260$(_world_0, _replacement_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _replacement_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _resource_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $done_10$(_previous_0, _value_0) {
  return $step_11$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058registered$(_mode_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/local.Registered") {
    const _world_0 = _result_0["world"];
    const _instance_0 = _result_0["instance"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058before$(_mode_0, _instance_0, ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_0)));
  } else {
    const _world_1 = _result_0["world"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected$(($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register$1260$(_world_0, _name_0, _access_0, _local_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_named$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0, _local_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1262$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1263$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058rollback$1261$(_receipts_0, _undo_0, _count_0, _world_0, _owners_0, _pending_0) {
  if (_receipts_0.$ === "Nil") {
    return {$: "../generic-assembly-v1/owned-journal.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1262$(_undo_0, _world_0)), "owners": ($List$reverse$(_owners_0)), "pending": ($List$reverse$(_pending_0))};
  } else {
    const _t_0 = _receipts_0["head"];
    const _position_0 = _t_0["position"];
    const _inverse_0 = _t_0["inverse"];
    const _rest_0 = _receipts_0["tail"];
    return $$$$047generic$045assembly$045v1$047owned$045journal$058unwound$1261$(_inverse_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047generic$045assembly$045v1$047owned$045journal$058rollback$1261$(_rest_0, _x_0, _position_0, _x_1, _x_2, _x_3);
});
});
});
}), _owners_0, _pending_0, ($$$$047generic$045assembly$045v1$047owned$045journal$058stepped$1261$((_count_0 < _position_0 ? 0 : _count_0 - _position_0), _world_0, _undo_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1263$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058read_before$1260$(_args_0, _result_0) {
  const _t_0 = _args_0["incoming"];
  if (_t_0.$ === "None") {
    const _operations_0 = _args_0["operations"];
    const _writes_0 = _args_0["writes"];
    const _fail_0 = _args_0["fail"];
    const _ctx_0 = _result_0["fst"];
    const _view_0 = _result_0["snd"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../generic-assembly-v1/first-public-fixture.Args", "incoming": {$: "None"}, "operations": _operations_0, "writes": _writes_0, "fail": _fail_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}, "snd": _view_0}}};
  } else {
    const _t_1 = _t_0["value"];
    const _first_0 = _t_1["first"];
    const _second_0 = _t_1["second"];
    const _operations_1 = _args_0["operations"];
    const _writes_1 = _args_0["writes"];
    const _fail_1 = _args_0["fail"];
    const _ctx_1 = _result_0["fst"];
    const _view_1 = _result_0["snd"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource_before$1260$(_first_0, _second_0, _operations_1, _writes_1, _fail_1, _view_1, run_loop($$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource$1260$(_ctx_1, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(200)))));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058read$1260$(_ctx_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read$1261$(_ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058get_projected$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, ($$$$047generic$045assembly$045v1$047first$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_observed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_1, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawned$1260$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _canonical_0, _result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _result_1 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _packet_0 = _t_1["fst"];
  const _t_2 = _t_1["snd"];
  const _receipt_0 = _t_2["fst"];
  const _next_0 = _t_2["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": ($$$$047generic$045assembly$045v1$047assembly$045frame$058receipt_added$1260$(_receipts_0, _receipt_0)), "pending": ($$$$047generic$045assembly$045v1$047assembly$045frame$058pending_added$1260$(_pending_0, _next_0))}, "snd": ($$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_output$1260$(_canonical_0, _result_1, _packet_0))};
}

function $$$$047generic$045assembly$045v1$047immediate$058spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047generic$045assembly$045v1$047immediate$058reserved$1260$(_payload_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_projected$1260$(_codec_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _raw_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_budget$1260$(_codec_0, _raw_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058budget$(_codec_0, _raw_0)), _owner_0);
}

function $$$$047generic$045assembly$045v1$047request$058enqueue$1260$(_declaration_0, _batch_0, _operation_0, _canonical_0, _projected_0) {
  const _owner_0 = _projected_0["fst"];
  const _original_0 = _projected_0["snd"];
  return $$$$047generic$045assembly$045v1$047request$058enqueue_packet$1260$(_declaration_0, _batch_0, _operation_0, _owner_0, _original_0, _canonical_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058restore$1260$(_world_0, _old_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058restore_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058replace_resource$1260$(_world_0, _old_0)));
}

function $step_11$(_previous_0) {
  return $done_11$(_previous_0, {$: "Recovered", "label": {$: "RSuccess"}, "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058run$({$: "../generic-assembly-v1/recovery-fixture.Success"}))});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058before$(_mode_0, _instance_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058ran$(_view_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058run$1260$(_instance_0, _world_0, _mode_0)));
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected$(_result_0) {
  const _view_0 = _result_0["snd"];
  return {$: "../generic-assembly-v1/recovery-fixture.Report", "before": _view_0, "after": _view_0, "local": {$: "../generic-assembly-v1/recovery-fixture.StateView", "owners": {$: "Nil"}, "pending": {$: "Nil"}, "during": {$: "None"}, "errors": {$: "Nil"}}, "result": {$: "Fail", "error": {$: "Unit"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_named$1260$(_named_0, _name_0, _access_0, _local_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0, _local_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1263$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1262$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058unwound$1261$(_inverse_0, _next_0, _owners_0, _pending_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _undo_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047owned$045journal$058restored$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return run_tail(_next_0(_undo_0)(_x_0)(_x_1), _x_2);
});
});
}), _owners_0, _pending_0, _inverse_0(_world_0));
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058stepped$1261$($0, $1, $2) {
  for (;;) {
    {
      const _count_0 = $0;
      const _world_0 = $1;
      const _undo_0 = $2;
      if (_count_0 === 0) {
        return {$: "Tuple", "fst": _world_0, "snd": _undo_0};
      } else {
        const _rest_0 = (_count_0 - 1);
        if (_undo_0.$ === "Nil") {
          return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
        } else {
          const _inverse_0 = _undo_0["head"];
          const _tail_0 = _undo_0["tail"];
          $0 = _rest_0;
          $1 = _inverse_0(_world_0);
          $2 = _tail_0;
          continue;
        }
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource_before$1260$(_first_0, _second_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawned_first$1260$(_second_0, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawn$1260$(_ctx_0, _first_0)));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource$1260$(_ctx_0, _value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1263$(_ctx_0, _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read$1261$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1263$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058read_field$1260$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058grants$()))))), _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, ($$$$047generic$045assembly$045v1$047first$045owner$058take$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, _column_1)), "snd": {$: "../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058receipt_added$1260$(_receipts_0, _receipt_0) {
  if (_receipt_0.$ === "None") {
    return _receipts_0;
  } else {
    const _receipt_1 = _receipt_0["value"];
    return {$: "Con", "head": _receipt_1, "tail": _receipts_0};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058pending_added$1260$(_pending_0, _next_0) {
  if (_next_0.$ === "None") {
    return _pending_0;
  } else {
    const _next_1 = _next_0["value"];
    return {$: "Con", "head": _next_1, "tail": _pending_0};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_output$1260$(_canonical_0, _result_0, _packet_0) {
  if (_result_0.$ === "Done") {
    const _target_0 = _result_0["value"];
    return {$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": true, "canonical": _canonical_0};
  } else {
    const _error_0 = _result_0["error"];
    if (_packet_0.$ === "None") {
      return {$: "../generic-assembly-v1/request.Refused", "owner": {$: "None"}, "error": {$: "../generic-assembly-v1/request.Entity", "error": _error_0}};
    } else {
      const _t_0 = _packet_0["value"];
      const _owner_0 = _t_0["owner"];
      return {$: "../generic-assembly-v1/request.Refused", "owner": _owner_0, "error": {$: "../generic-assembly-v1/request.Entity", "error": _error_0}};
    }
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058reserved$1260$(_payload_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_0["handle"];
    return $$$$047generic$045assembly$045v1$047immediate$058activated$1260$(_target_0, _payload_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _target_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_0}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_budget$1260$(_codec_0, _raw_0, _fuel_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalized$1260$(_fuel_0, _codec_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058owned$1260$(_fuel_0, _codec_0, {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Owned", "owner": _owner_0, "description": _raw_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058budget$(_codec_0, _raw_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058raw_size$(_raw_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058codec_size$(_codec_0));
  const _x_2 = nat_chk(_x_0 + 1);
  const _x_3 = nat_chk(_x_1 * _x_2);
  return nat_chk(4 * _x_3);
}

function $$$$047generic$045assembly$045v1$047request$058enqueue_packet$1260$(_declaration_0, _batch_0, _operation_0, _owner_0, _original_0, _canonical_0) {
  if (_operation_0.$ === "../../../../../../bendvy/src/ecs/bundle-requests.Insert") {
    const _target_0 = _operation_0["target"];
    return $$$$047generic$045assembly$045v1$047request$058inserted$1260$(_declaration_0, _target_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058insert$1260$(_batch_0, _target_0, {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _original_0, "canonical": _canonical_0})));
  } else {
    return $$$$047generic$045assembly$045v1$047request$058spawned$1260$(_declaration_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn$1260$(_batch_0, {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _original_0, "canonical": _canonical_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058restore_join$1260$(_replaced_0) {
  const _world_0 = _replaced_0["fst"];
  return _world_0;
}

function $done_11$(_previous_0, _value_0) {
  return $step_12$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058ran$(_before_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/local.Completed") {
    const _world_0 = _result_0["world"];
    const _instance_0 = _result_0["instance"];
    const _result_1 = _result_0["result"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058report$(_before_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058status$(_result_1)), ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058observe$1260$(_instance_0)));
  } else {
    const _world_1 = _result_0["world"];
    const _instance_1 = _result_0["instance"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058report$(_before_0, {$: "Fail", "error": {$: "Unit"}}, ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_1)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058observe$1260$(_instance_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058run$1260$(_instance_0, _world_0, _args_0) {
  const _namespace_0 = _instance_0["namespace"];
  const _id_0 = _instance_0["id"];
  const _name_0 = _instance_0["name"];
  const _access_0 = _instance_0["access"];
  const _local_0 = _instance_0["local"];
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058checked$1260$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058register_result$1260$(_registered_0, _namespace_0, _name_0, _access_0, _local_0) {
  const _world_0 = _registered_0["fst"];
  const _t_0 = _registered_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Registered") {
    const _id_0 = _t_0["id"];
    return {$: "../../../../../../bendvy/src/ecs/local.Registered", "world": _world_0, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/local.RegistrationRejected", "world": _world_0, "local": _local_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047generic$045assembly$045v1$047owned$045journal$058restored$1261$(_next_0, _owners_0, _pending_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _owner_0 = _result_0["payload"];
    return run_tail(_next_0(_world_0)({$: "Con", "head": _owner_0, "tail": _owners_0}), _pending_0);
  } else {
    const _world_1 = _result_0["world"];
    const _owner_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return run_tail(_next_0(_world_1)(_owners_0), {$: "Con", "head": {$: "../generic-assembly-v1/owned-journal.Pending", "owner": _owner_1, "error": _error_0}, "tail": _pending_0});
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawned_first$1260$(_second_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../generic-assembly-v1/request.Accepted") {
    const _target_0 = _t_0["target"];
    const _spawned_0 = _t_0["spawned"];
    const _canonical_0 = _t_0["canonical"];
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058written_first$1260$({$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": _spawned_0, "canonical": _canonical_0}, _second_0, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047first$045public$045fixture$058write$1260$(_ctx_0, _target_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(99)))));
  } else {
    return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawned_second$1260$(_t_0, {$: "None"}, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawn$1260$(_ctx_0, _second_0)));
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawn$1260$(_ctx_0, _value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1264$(_ctx_0, _value_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1263$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1263$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource_field$1260$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058grants$())))))(_ctx_0), _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1263$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058read_field$1260$(_ops_0) {
  const _cap_0 = _ops_0["read"];
  return _cap_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058grants$() {
  return $$$$047generic$045assembly$045v1$047declared$058grants$1261$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_swap$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../../bendvy/src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058activated$1260$(_target_0, _payload_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Accepted") {
    return $$$$047generic$045assembly$045v1$047immediate$058installed$1260$(_target_0, _undo_0, _commands_0, _events_0, ($$$$047generic$045assembly$045v1$047second$045owner$058install$(_world_0, _target_0, _payload_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_0}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalized$1260$(_fuel_0, _codec_0, _result_0) {
  const _owner_0 = _result_0["owner"];
  const _t_0 = _result_0["checked"];
  if (_t_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Accepted") {
    const _value_0 = _t_0["value"];
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Receipt", "owner": _owner_0, "checked": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Accepted", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical$(_fuel_0, _codec_0, _value_0))}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Receipt", "owner": _owner_0, "checked": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058owned$1260$(_fuel_0, _codec_0, _input_0) {
  const _owner_0 = _input_0["owner"];
  const _description_0 = _input_0["description"];
  return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Receipt", "owner": _owner_0, "checked": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058validate$(_fuel_0, {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Work", "codec": _codec_0, "raw": _description_0, "path": "$"}, "tail": {$: "Nil"}}}, _description_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058codec_size$(_codec_0) {
  if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Nullable") {
    const _inner_0 = _codec_0["inner"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058codec_size$(_inner_0));
    return nat_chk(1 + _x_0);
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.ArrayValue") {
    const _inner_1 = _codec_0["inner"];
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058codec_size$(_inner_1));
    return nat_chk(1 + _x_1);
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Struct") {
    const _t_0 = _codec_0["fields"];
    if (_t_0.$ === "Nil") {
      return 1;
    } else {
      const _t_1 = _t_0["head"];
      const _child_0 = _t_1["codec"];
      const _rest_0 = _t_0["tail"];
      const _x_2 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058codec_size$(_child_0));
      const _x_3 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058codec_size$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Struct", "fields": _rest_0}));
      const _x_4 = nat_chk(_x_2 + _x_3);
      return nat_chk(1 + _x_4);
    }
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058raw_size$(_raw_0) {
  if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array") {
    const _t_0 = _raw_0["items"];
    if (_t_0.$ === "Nil") {
      return 1;
    } else {
      const _head_0 = _t_0["head"];
      const _rest_0 = _t_0["tail"];
      const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058raw_size$(_head_0));
      const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058raw_size$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array", "items": _rest_0}));
      return nat_chk(_x_0 + _x_1);
    }
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object") {
    const _t_1 = _raw_0["fields"];
    if (_t_1.$ === "Nil") {
      return 1;
    } else {
      const _t_2 = _t_1["head"];
      const _child_0 = _t_2["value"];
      const _rest_1 = _t_1["tail"];
      const _x_2 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058raw_size$(_child_0));
      const _x_3 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058raw_size$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object", "fields": _rest_1}));
      return nat_chk(_x_2 + _x_3);
    }
  } else {
    return 1;
  }
}

function $$$$047generic$045assembly$045v1$047request$058inserted$1260$(_declaration_0, _target_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": false, "canonical": _canonical_0}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_1, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Refused", "owner": _owner_0, "error": {$: "../generic-assembly-v1/request.Entity", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058insert$1260$(_batch_0, _target_0, _payload_0) {
  const _t_0 = _batch_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058checked$1260$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047generic$045assembly$045v1$047request$058spawned$1260$(_declaration_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.Spawned") {
    const _batch_0 = _result_0["batch"];
    const _target_0 = _result_0["target"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": true, "canonical": _canonical_0}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_1, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Refused", "owner": _owner_0, "error": {$: "../generic-assembly-v1/request.Entity", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn$1260$(_batch_0, _payload_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_reserved$1260$(_prepared_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, {$: "Unit"})));
}

function $step_12$(_previous_0) {
  return $done_12$(_previous_0, {$: "Recovered", "label": {$: "RReserveRefused"}, "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058run$({$: "../generic-assembly-v1/recovery-fixture.ReserveRefused"}))});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058report$(_before_0, _result_0, _observed_0, _local_0) {
  const _after_0 = _observed_0["snd"];
  const _view_0 = _local_0["snd"];
  return {$: "../generic-assembly-v1/recovery-fixture.Report", "before": _before_0, "after": _after_0, "local": _view_0, "result": _result_0};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058status$(_result_0) {
  if (_result_0.$ === "Done") {
    const _value_0 = _result_0["value"];
    return {$: "Done", "value": _value_0};
  } else {
    const _error_0 = _result_0["error"];
    return {$: "Fail", "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058observe$1260$(_instance_0) {
  const _namespace_0 = _instance_0["namespace"];
  const _id_0 = _instance_0["id"];
  const _name_0 = _instance_0["name"];
  const _access_0 = _instance_0["access"];
  const _local_0 = _instance_0["local"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058observed$1260$(_namespace_0, _id_0, _name_0, _access_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058state_view$(_local_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058checked$1260$(_allowed_0, _instance_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../bendvy/src/ecs/local.Refused", "world": _world_0, "instance": _instance_0, "args": _args_0};
  } else {
    const _namespace_0 = _instance_0["namespace"];
    const _id_0 = _instance_0["id"];
    const _name_0 = _instance_0["name"];
    const _access_0 = _instance_0["access"];
    const _local_0 = _instance_0["local"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058completed$1260$(_namespace_0, _id_0, _name_0, _access_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058runner$(_world_0, _local_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058written_first$1260$(_first_0, _second_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _written_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawned_second$1260$(_first_0, {$: "Some", "value": _written_0}, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawn$1260$(_ctx_0, _second_0)));
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058write$1260$(_ctx_0, _target_0, _value_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1265$(_ctx_0, {$: "../../../../../../bendvy/src/ecs/compose.Insert", "target": _target_0, "value": _value_0});
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawned_second$1260$(_first_0, _written_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _second_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource_after$1260$(_first_0, _second_0, _written_0, _previous_0, _writes_0, _fail_0, _view_0, run_loop($$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource$1260$(_ctx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(300)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1264$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1264$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawn_field$1260$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058grants$())))))(_ctx_0), _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1263$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource_field$1260$(_ops_0) {
  const _cap_0 = _ops_0["resource"];
  return _cap_0;
}

function $$$$047generic$045assembly$045v1$047declared$058grants$1261$() {
  return {$: "../generic-assembly-v1/declared.Ops", "read": ($$$$047generic$045assembly$045v1$047assembly$045frame$058read_grant$1261$()), "write": ($$$$047generic$045assembly$045v1$047owned$045component$058grant$1261$()), "spawn": ($$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_grant$1261$()), "decode": ($$$$047generic$045assembly$045v1$047assembly$045frame$058request_grant$1261$()), "resource": ($$$$047generic$045assembly$045v1$047assembly$045frame$058resource_grant$1261$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_swap$1261$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045owner$058put$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047generic$045assembly$045v1$047immediate$058installed$1260$(_target_0, _undo_0, _commands_0, _events_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Installed") {
    const _world_0 = _result_0["world"];
    const _inverse_0 = _result_0["undo"];
    return $$$$047generic$045assembly$045v1$047immediate$058receipt$1260$(_target_0, _world_0, _inverse_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1261$(_undo_0)));
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047generic$045assembly$045v1$047immediate$058deactivated$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1260$(_world_1, _target_0)))), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_0}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}}}}};
  } else {
    const _world_2 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_2, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_1}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Some", "value": {$: "../generic-assembly-v1/owned-journal.Pending", "owner": _recovery_0, "error": _error_1}}}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical$($0, $1, $2) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _codec_0 = $1;
      const _raw_0 = $2;
      if (_fuel_0 === 0) {
        return _raw_0;
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Nullable") {
          const _inner_0 = _codec_0["inner"];
          if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null") {
            return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null"};
          } else {
            $0 = _more_0;
            $1 = _inner_0;
            $2 = _raw_0;
            continue;
          }
        } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.ArrayValue") {
          const __0 = _codec_0["inner"];
          if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array") {
            const _t_0 = _raw_0["items"];
            if (_t_0.$ === "Nil") {
              return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array", "items": {$: "Nil"}};
            } else {
              const _head_0 = _t_0["head"];
              const _tail_0 = _t_0["tail"];
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical_array_join$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical$(_more_0, __0, _head_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical$(_more_0, {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.ArrayValue", "inner": __0}, {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array", "items": _tail_0})));
            }
          } else {
            return _raw_0;
          }
        } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Struct") {
          const _t_1 = _codec_0["fields"];
          if (_t_1.$ === "Nil") {
            if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object") {
              return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object", "fields": {$: "Nil"}};
            } else {
              return _raw_0;
            }
          } else {
            const _t_2 = _t_1["head"];
            const _name_0 = _t_2["name"];
            const _codec_1 = _t_2["codec"];
            const _rest_0 = _t_1["tail"];
            if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object") {
              const _values_0 = _raw_0["fields"];
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical_struct_join$(_name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical$(_more_0, _codec_1, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058field$(_name_0, _values_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical$(_more_0, {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Struct", "fields": _rest_0}, {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object", "fields": _values_0})));
            } else {
              return _raw_0;
            }
          }
        } else {
          return _raw_0;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058validate$($0, $1, $2) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _step_0 = $1;
      const _original_0 = $2;
      if (_fuel_0 === 0) {
        if (_step_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop") {
          const _error_0 = _step_0["error"];
          return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected", "error": _error_0};
        } else {
          const _t_0 = _step_0["work"];
          if (_t_0.$ === "Nil") {
            return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Accepted", "value": _original_0};
          } else {
            const _t_1 = _t_0["head"];
            const _path_0 = _t_1["path"];
            return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.FuelExhausted", "path": _path_0}};
          }
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_step_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop") {
          const _error_1 = _step_0["error"];
          return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected", "error": _error_1};
        } else {
          const _t_2 = _step_0["work"];
          if (_t_2.$ === "Nil") {
            return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Accepted", "value": _original_0};
          } else {
            const _t_3 = _t_2["head"];
            const _codec_0 = _t_3["codec"];
            const _raw_0 = _t_3["raw"];
            const _path_1 = _t_3["path"];
            const _rest_0 = _t_2["tail"];
            $0 = _more_0;
            $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058expand$(_codec_0, _raw_0, _path_1, _rest_0));
            $2 = _original_0;
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058checked$1260$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_checked$1260$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_prepared_0, _target_0)));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1261$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_reserved$1260$(_prepared_0, _payload_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_1["handle"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_positioned$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1260$({$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt", "target": _target_0}, "tail": _prepared_0}, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1261$(_commands_0)))));
  } else {
    const _error_0 = _t_1["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-batch.SpawnRefused", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $done_12$(_previous_0, _value_0) {
  return $step_13$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058observed$1260$(_namespace_0, _id_0, _name_0, _access_0, _value_0) {
  const _local_0 = _value_0["fst"];
  const _value_1 = _value_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, "snd": _value_1};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058state_view$(_state_0) {
  const _owners_0 = _state_0["owners"];
  const _pending_0 = _state_0["pending"];
  const _during_0 = _state_0["during"];
  const _errors_0 = _state_0["errors"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058state_join$(_during_0, _errors_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet_views$(_owners_0)), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058pending_views$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047local$058completed$1260$(_namespace_0, _id_0, _name_0, _access_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/local.Succeeded") {
    const _world_0 = _outcome_0["world"];
    const _local_0 = _outcome_0["local"];
    const _out_0 = _outcome_0["output"];
    return {$: "../../../../../../bendvy/src/ecs/local.Completed", "world": _world_0, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, "result": {$: "Done", "value": _out_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _local_1 = _outcome_0["local"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/local.Completed", "world": _world_1, "instance": {$: "../../../../../../bendvy/src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_1}, "result": {$: "Fail", "error": _error_0}};
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058runner$(_world_0, _state_0, _args_0) {
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058selected_world$(_args_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1265$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1265$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058write_field$1260$(($$$$047generic$045assembly$045v1$047first$045public$045fixture$058grants$())))))(_ctx_0), _input_0);
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058resource_after$1260$(_first_0, _second_0, _written_0, _previous_0, _writes_0, _fail_0, _view_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Tuple", "fst": {$: "../generic-assembly-v1/first-public-fixture.Args", "incoming": {$: "None"}, "operations": {$: "Con", "head": _second_0, "tail": {$: "Con", "head": _first_0, "tail": _previous_0}}, "writes": ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058write_added$(_written_0, _writes_0)), "fail": _fail_0}, "snd": {$: "Tuple", "fst": ($$$$047generic$045assembly$045v1$047first$045public$045fixture$058user_outcome$(_fail_0)), "snd": _view_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1264$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058spawn_field$1260$(_ops_0) {
  const _cap_0 = _ops_0["spawn"];
  return _cap_0;
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058read_grant$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.Read", "get": run_clo((_x_0) => {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058read$1261$(_x_0);
})};
}

function $$$$047generic$045assembly$045v1$047owned$045component$058grant$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047generic$045assembly$045v1$047owned$045component$058set$1261$(_x_0, _x_1);
});
})};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_grant$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn$1261$(_x_0, _x_1);
});
})};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058request_grant$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058request$1261$(_x_0, _x_1);
});
})};
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_grant$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_set$1261$(_x_0, _x_1);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_0) {
  const _raw_0 = _owner_0["value"];
  const _sentinel_0 = _owner_0["sentinel"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/experiments/public-decode/complete-v1/controls.Owner", "value": _raw_0, "sentinel": _sentinel_0}, "snd": ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new$(_raw_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1261$(($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047generic$045assembly$045v1$047immediate$058receipt$1260$(_target_0, _world_0, _inverse_0, _commands_0, _events_0, _result_0) {
  const _undo_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Done", "value": _target_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": {$: "Some", "value": {$: "../generic-assembly-v1/owned-journal.Receipt", "position": _position_0, "inverse": run_clo((_x_0) => {
  return $$$$047generic$045assembly$045v1$047immediate$058restored$1260$(_target_0, _inverse_0(_x_0));
})}}, "snd": {$: "None"}}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1261$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1261$(_tail_0)));
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058deactivated$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(false, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical_array_join$(_head_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array") {
    const _values_0 = _tail_0["items"];
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array", "items": {$: "Con", "head": _head_0, "tail": _values_0}};
  } else {
    return _tail_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical_struct_join$(_name_0, _head_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object") {
    const _fields_0 = _tail_0["fields"];
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object", "fields": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Field", "name": _name_0, "value": _head_0}, "tail": _fields_0}};
  } else {
    return _tail_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058field$(_name_0, _fields_0) {
  if (_fields_0.$ === "Nil") {
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Missing"};
  } else {
    const _t_0 = _fields_0["head"];
    const _key_0 = _t_0["name"];
    const _value_0 = _t_0["value"];
    const _rest_0 = _fields_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058field_choose$(($String$eq$(_name_0, _key_0)), _value_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058field$(_name_0, _rest_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058expand$(_codec_0, _raw_0, _path_0, _rest_0) {
  if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Integer") {
    if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number") {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.SignedInteger") {
      const __1 = _raw_0["negative"];
      const _magnitude_0 = _raw_0["magnitude"];
      const _x_0 = ($Nat$div$(_magnitude_0, nat_chk(65536 * 65536)));
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$((_x_0 < 2097152), _path_0, "integer", {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.SignedInteger", "negative": __1, "magnitude": _magnitude_0}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Float") {
      const _value_0 = _raw_0["value"];
      const _x_1 = Math.fround(Math.floor(_value_0));
      const _x_2 = Math.fround(Math.abs(_value_0));
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$(($Bool$and$((_x_1 === _value_0), (_x_2 < 9007199254740992))), _path_0, "integer", {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Float", "value": _value_0}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Binary64") {
      const _high_0 = _raw_0["high"];
      const _low_0 = _raw_0["low"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_integer$(_high_0, _low_0)), _path_0, "integer", {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Binary64", "high": _high_0, "low": _low_0}, _rest_0);
    } else {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid", "path": _path_0, "expected": "integer", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.FiniteNumber") {
    if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number") {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.SignedInteger") {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Float") {
      const _value_1 = _raw_0["value"];
      const _x_3 = Math.fround(Math.abs(_value_1));
      const _x_4 = 3.4028234663852886e+38;
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$((_x_3 <= _x_4), _path_0, "finite number", {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Float", "value": _value_1}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Binary64") {
      const _high_1 = _raw_0["high"];
      const __5 = _raw_0["low"];
      const _x_5 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary64_exponent$(_high_1));
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$((_x_5 < 2047), _path_0, "finite number", {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Binary64", "high": _high_1, "low": __5}, _rest_0);
    } else {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid", "path": _path_0, "expected": "finite number", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.StringValue") {
    if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Text") {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text") {
      const _units_0 = _raw_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058valid$(_units_0)), _path_0, "string", {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text", "units": _units_0}, _rest_0);
    } else {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid", "path": _path_0, "expected": "string", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.BoolValue") {
    if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Boolean") {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": _rest_0};
    } else {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid", "path": _path_0, "expected": "boolean", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Literal") {
    const _value_2 = _codec_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058equal$(_value_2, _raw_0)), _path_0, "literal", _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.LiteralValues") {
    const _values_0 = _codec_0["values"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058alternatives$(_values_0, _raw_0)), _path_0, "literal", _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.LiteralRendered") {
    const _values_1 = _codec_0["values"];
    const _expected_0 = _codec_0["expected"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058alternatives$(_values_1, _raw_0)), _path_0, _expected_0, _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Nullable") {
    const __8 = _codec_0["inner"];
    if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null") {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": _rest_0};
    } else {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Work", "codec": __8, "raw": _raw_0, "path": _path_0}, "tail": _rest_0}};
    }
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.ArrayValue") {
    const _inner_0 = _codec_0["inner"];
    if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array") {
      const _items_0 = _raw_0["items"];
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058array_work$(_inner_0, _items_0, _path_0, 0, _rest_0))};
    } else {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid", "path": _path_0, "expected": "array", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Struct") {
    const _fields_0 = _codec_0["fields"];
    if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object") {
      const _values_2 = _raw_0["fields"];
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058struct_work$(_fields_0, _values_2, _path_0, _rest_0))};
    } else {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid", "path": _path_0, "expected": "object", "actual": _raw_0}};
    }
  } else {
    const _ns_0 = _codec_0["namespace"];
    if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Handle") {
      const _actual_0 = _raw_0["namespace"];
      const _id_0 = _raw_0["id"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$(($Bool$and$((_ns_0 === _actual_0), (_id_0 > 0))), _path_0, "same-world handle", {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Handle", "namespace": _actual_0, "id": _id_0}, _rest_0);
    } else {
      return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid", "path": _path_0, "expected": "same-world handle", "actual": _raw_0}};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_checked$1260$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _result_0) {
  const _prepared_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../bendvy/src/ecs/bundle-batch.Refused", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1261$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_prepared_0, _target_0) {
  if (_prepared_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": false};
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.Prepared") {
      const _handle_0 = _t_0["target"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _tail_0 = _prepared_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1260$({$: "../../../../../../bendvy/src/ecs/bundle-batch.Prepared", "target": _handle_0, "payload": _payload_0, "position": _position_0}, false, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_tail_0, _target_0)));
    } else {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _tail_1 = _prepared_0["tail"];
      const _otherNs_0 = _target_0["namespace"];
      const _otherId_0 = _target_0["id"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1260$({$: "../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt", "target": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}}, ($Bool$and$((_ns_0 === _otherNs_0), (_id_0 === _otherId_0))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_tail_1, {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _otherNs_0, "id": _otherId_0})));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/bundle-batch.Inserted", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Prepared", "target": _target_0, "payload": _payload_0, "position": _position_0}, "tail": _prepared_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_positioned$1260$(_target_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-batch.Spawned", "batch": _batch_0, "target": _target_0};
  } else {
    const _batch_1 = _result_0["batch"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-batch.SpawnRefused", "batch": _batch_1, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $step_13$(_previous_0) {
  return $done_13$(_previous_0, {$: "Recovered", "label": {$: "RInstallRefused"}, "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058run$({$: "../generic-assembly-v1/recovery-fixture.InstallRefused"}))});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058state_join$(_during_0, _errors_0, _owners_0, _pending_0) {
  const _owners_1 = _owners_0["fst"];
  const _views_0 = _owners_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _recoveries_0 = _pending_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": _owners_1, "pending": _pending_1, "during": _during_0, "errors": _errors_0}, "snd": {$: "../generic-assembly-v1/recovery-fixture.StateView", "owners": _views_0, "pending": _recoveries_0, "during": _during_0, "errors": _errors_0}};
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058selected_world$(_mode_0, _world_0) {
  if (_mode_0.$ === "../generic-assembly-v1/recovery-fixture.ReserveRefused") {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058start$({$: "../generic-assembly-v1/recovery-fixture.ReserveRefused"}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_replace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(200)))));
  } else {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058start$(_mode_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_replace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)), ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(200)))));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1265$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058write_field$1260$(_ops_0) {
  const _cap_0 = _ops_0["write"];
  return _cap_0;
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058write_added$(_written_0, _previous_0) {
  if (_written_0.$ === "None") {
    return _previous_0;
  } else {
    const _written_1 = _written_0["value"];
    return {$: "Con", "head": _written_1, "tail": _previous_0};
  }
}

function $$$$047generic$045assembly$045v1$047first$045public$045fixture$058user_outcome$(_fail_0) {
  if (!_fail_0) {
    return {$: "../../../../../../bendvy/src/ecs/transaction.Success"};
  } else {
    return {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": {$: "Unit"}};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058read$1261$(_frame_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058read_join$1261$(_declaration_0, _prepared_0, _receipts_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1262$(($$$$047generic$045assembly$045v1$047declared$058read_grant$1261$())))({$: "../../../../../../bendvy/src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}));
}

function $$$$047generic$045assembly$045v1$047owned$045component$058set$1261$(_frame_0, _input_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  const _target_0 = _input_0["target"];
  const _owner_0 = _input_0["value"];
  return $$$$047generic$045assembly$045v1$047owned$045component$058written$1261$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1261$({$: "../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047ordinary$045declaration$058key$1262$(($$$$047generic$045assembly$045v1$047first$045owner$058identity$())))}, _tx_0, _target_0, _owner_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn$1261$(_frame_0, _owner_0) {
  const _t_0 = _frame_0["owner"];
  const _batch_0 = _t_0["batch"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_validated$1261$({$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_0, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058validate$1261$(_declaration_0, _owner_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058request$1261$(_frame_0, _input_0) {
  const _owner_0 = _frame_0["owner"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058request_join$1261$(_handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, ($$$$047generic$045assembly$045v1$047request$058request$1261$(_owner_0, _input_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_set$1261$(_frame_0, _replacement_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_join$1261$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_replace$1261$(_tx_0, _replacement_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new$(_raw_0) {
  return $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_raw$(($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_converted$(_raw_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$({$: "../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$({$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058restored$1260$(_target_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": ($$$$047generic$045assembly$045v1$047immediate$058deactivated$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1260$(_world_0, _target_0)))), "payload": _payload_0};
  } else {
    const _world_1 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": _recovery_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1261$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058field_choose$(_equal_0, _value_0, _next_0) {
  if (_equal_0) {
    return _value_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058choose_checked$(_valid_0, _path_0, _expected_0, _raw_0, _rest_0) {
  if (_valid_0) {
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": _rest_0};
  } else {
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Stop", "error": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid", "path": _path_0, "expected": _expected_0, "actual": _raw_0}};
  }
}

function $Nat$div$(_a_0, _b_0) {
  return $Pair$fst$(nat_divmod(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_integer$(_high_0, _low_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary64_exponent$(_high_0));
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_integer_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_numeric$(_high_0, _low_0)), (_x_0 < 1076));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary64_exponent$(_high_0) {
  const _x_0 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  return (2048 === 0 ? _x_0 : _x_0 % 2048);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058valid$(_units_0) {
  if (_units_0.$ === "Nil") {
    return true;
  } else {
    const _unit_0 = _units_0["head"];
    const _tail_0 = _units_0["tail"];
    return $Bool$and$((_unit_0 <= 65535), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058valid$(_tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058equal$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null") {
    if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null") {
      return true;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null"})), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Text") {
    const _a_1 = _a_0["value"];
    if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Text") {
      const _b_1 = _b_0["value"];
      return $String$eq$(_a_1, _b_1);
    } else if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text") {
      const _b_2 = _b_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058checked$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058text$(_a_1)), _b_2);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Text", "value": _a_1})), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text") {
    const _a_2 = _a_0["units"];
    if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text") {
      const _b_3 = _b_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058checked$(_a_2, _b_3);
    } else if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Text") {
      const _b_4 = _b_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058checked$(_a_2, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058text$(_b_4)));
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text", "units": _a_2})), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Boolean") {
    const _a_3 = _a_0["value"];
    if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Boolean") {
      const _b_5 = _b_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_bool$(_a_3, _b_5);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$({$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Boolean", "value": _a_3})), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$(_b_0)));
    }
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$(_a_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$(_b_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058alternatives$(_values_0, _raw_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _value_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058equal$(_value_0, _raw_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058alternatives$(_tail_0, _raw_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058array_work$(_codec_0, _items_0, _path_0, _index_0, _rest_0) {
  if (_items_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _value_0 = _items_0["head"];
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($U32$show$(_index_0));
    const _x_1 = (_x_0 + "]");
    const _x_2 = ("[" + _x_1);
    return {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Work", "codec": _codec_0, "raw": _value_0, "path": (_path_0 + _x_2)}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058array_work$(_codec_0, _tail_0, _path_0, ((_index_0 + 1) >>> 0), _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058struct_work$(_fields_0, _values_0, _path_0, _rest_0) {
  if (_fields_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _t_0 = _fields_0["head"];
    const _name_0 = _t_0["name"];
    const _codec_0 = _t_0["codec"];
    const _tail_0 = _fields_0["tail"];
    const _x_0 = ("." + _name_0);
    return {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Work", "codec": _codec_0, "raw": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058field$(_name_0, _values_0)), "path": (_path_0 + _x_0)}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058struct_work$(_tail_0, _values_0, _path_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1260$(_entry_0, _seen_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _found_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _tail_0}, "snd": (_seen_0 || _found_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../../../../bendvy/src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $done_13$(_previous_0, _value_0) {
  return $step_14$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058start$(_mode_0, _tx_0) {
  if (_mode_0.$ === "../generic-assembly-v1/recovery-fixture.InstallRefused") {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058first_spawn$({$: "../generic-assembly-v1/recovery-fixture.InstallRefused"}, ($$$$047generic$045assembly$045v1$047immediate$058spawn$1261$(_tx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet$(11)))));
  } else if (_mode_0.$ === "../generic-assembly-v1/recovery-fixture.ActivationRefused") {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058activation_refused$(_tx_0);
  } else {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058first_spawn$(_mode_0, ($$$$047generic$045assembly$045v1$047immediate$058spawn$1260$(_tx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet$(11)))));
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058read_join$1261$(_declaration_0, _prepared_0, _receipts_0, _pending_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _tx_0 = _t_0["tx"];
  const _handle_0 = _t_0["handle"];
  const _error_0 = _t_0["error"];
  const _cursor_0 = _t_0["cursor"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058read_field$1262$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047generic$045assembly$045v1$047declared$058read_grant$1261$() {
  return {$: "../../../../../../bendvy/src/ecs/capabilities.Read", "get": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058write_read_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058grant$1261$(($$$$047generic$045assembly$045v1$047declared$058query$1261$())))))};
}

function $$$$047generic$045assembly$045v1$047owned$045component$058written$1261$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": {$: "../generic-assembly-v1/owned-component.Written"}};
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _owner_0 = _result_0["incoming"];
    const _reason_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_1, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_error_0, _reason_0)), "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": {$: "../generic-assembly-v1/owned-component.Refused", "owner": {$: "Some", "value": _owner_0}, "error": _reason_0}};
  } else {
    const _tx_2 = _result_0["tx"];
    const _reason_1 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_2, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047compose$058first_error$(_error_0, _reason_1)), "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": {$: "../generic-assembly-v1/owned-component.Refused", "owner": {$: "None"}, "error": _reason_1}};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_validated$1261$(_frame_0, _receipt_0) {
  const _owner_0 = _receipt_0["owner"];
  const _t_0 = _receipt_0["checked"];
  if (_t_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected") {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": _frame_0, "snd": {$: "../generic-assembly-v1/request.Refused", "owner": {$: "Some", "value": _owner_0}, "error": {$: "../generic-assembly-v1/request.Validation", "error": _error_0}}};
  } else {
    const _canonical_0 = _t_0["value"];
    return $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_projected$1261$(_frame_0, _canonical_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058validate$1261$(_declaration_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_owner$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058codec$1261$(_declaration_0)), _owner_0);
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058request_join$1261$(_handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": _owner_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": _output_0};
}

function $$$$047generic$045assembly$045v1$047request$058request$1261$(_frame_0, _input_0) {
  const _batch_0 = _frame_0["batch"];
  const _declaration_0 = _frame_0["declaration"];
  const _operation_0 = _input_0["operation"];
  const _owner_0 = _input_0["owner"];
  return $$$$047generic$045assembly$045v1$047request$058validated$1261$(_declaration_0, _batch_0, _operation_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047persistence$045declaration$058validate$1261$(_declaration_0, _owner_0)));
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058resource_join$1261$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _tx_0) {
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": _receipts_0, "pending": _pending_0}, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_replace$1261$(_tx_0, _replacement_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058replace_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058replace_resource$1261$(_world_0, _replacement_0)), _undo_0, _commands_0, _events_0);
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_raw$(_converted_0) {
  const _raw_0 = _converted_0["raw"];
  return _raw_0;
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_converted$(_raw_0) {
  if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Missing") {
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Missing"}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Null") {
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null"}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Number") {
    const _value_0 = _raw_0["value"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number", "value": _value_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.SignedInteger") {
    const _negative_0 = _raw_0["negative"];
    const _magnitude_0 = _raw_0["magnitude"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.SignedInteger", "negative": _negative_0, "magnitude": _magnitude_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Float") {
    const _value_1 = _raw_0["value"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Float", "value": _value_1}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Binary64") {
    const _high_0 = _raw_0["high"];
    const _low_0 = _raw_0["low"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Binary64", "high": _high_0, "low": _low_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Text") {
    const _value_2 = _raw_0["value"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Text", "value": _value_2}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Utf16Text") {
    const _units_0 = _raw_0["units"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text", "units": _units_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Boolean") {
    const _value_3 = _raw_0["value"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Boolean", "value": _value_3}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Handle") {
    const _namespace_0 = _raw_0["namespace"];
    const _id_0 = _raw_0["id"];
    return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Handle", "namespace": _namespace_0, "id": _id_0}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-decode/typed.Array") {
    const _t_0 = _raw_0["items"];
    if (_t_0.$ === "Nil") {
      return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array", "items": {$: "Nil"}}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
    } else {
      const _head_0 = _t_0["head"];
      const _rest_0 = _t_0["tail"];
      return $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_array$(($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_converted$(_head_0)), ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_converted$({$: "../../../../../../bendvy/experiments/public-decode/typed.Array", "items": _rest_0})));
    }
  } else {
    const _t_1 = _raw_0["fields"];
    if (_t_1.$ === "Nil") {
      return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object", "fields": {$: "Nil"}}, "items": {$: "Nil"}, "fields": {$: "Nil"}};
    } else {
      const _t_2 = _t_1["head"];
      const _name_0 = _t_2["name"];
      const _value_4 = _t_2["value"];
      const _rest_1 = _t_1["tail"];
      return $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_object$(_name_0, ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_converted$(_value_4)), ($$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_converted$({$: "../../../../../../bendvy/experiments/public-decode/typed.Object", "fields": _rest_1})));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $Pair$fst$(_p_0) {
  const _a_0 = _p_0["fst"];
  return _a_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_integer_checked$(_result_0, _small_0) {
  return $Bool$and$(_small_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_integer_normal$(_result_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_numeric$(_high_0, _low_0) {
  const _x_0 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_1 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_2 = (2048 === 0 ? _x_1 : _x_1 % 2048);
  const _x_3 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_4 = (2048 === 0 ? _x_3 : _x_3 % 2048);
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_parts$((_high_0 >= 2147483648), (2048 === 0 ? _x_0 : _x_0 % 2048), (1048576 === 0 ? _high_0 : _high_0 % 1048576), _low_0, (_x_2 === 2047), (_x_4 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_numeric$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Finite") {
    const _an_0 = _a_0["negative"];
    const _ah_0 = _a_0["high"];
    const _al_0 = _a_0["low"];
    const _ae_0 = _a_0["exponent"];
    if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Finite") {
      const _bn_0 = _b_0["negative"];
      const _bh_0 = _b_0["high"];
      const _bl_0 = _b_0["low"];
      const _be_0 = _b_0["exponent"];
      return $Bool$and$(($Bool$and$(($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_bool$(_an_0, _bn_0)), (_ah_0 === _bh_0))), (_al_0 === _bl_0))), (_ae_0 === _be_0));
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Infinity") {
    const _a_1 = _a_0["negative"];
    if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Infinity") {
      const _b_1 = _b_0["negative"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_bool$(_a_1, _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.NaN") {
    if (_b_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.NaN") {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric$(_raw_0) {
  if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number") {
    const _value_0 = _raw_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize$(64, false, 0, _value_0, 1074);
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.SignedInteger") {
    const _negative_0 = _raw_0["negative"];
    const _value_1 = _raw_0["magnitude"];
    const _x_0 = ($Nat$div$(_value_1, nat_chk(65536 * 65536)));
    const _x_1 = ($Nat$mod$(_value_1, nat_chk(65536 * 65536)));
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize$(64, _negative_0, (_x_0 >>> 0), (_x_1 >>> 0), 1074);
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Float") {
    const _value_2 = _raw_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058float_numeric$(f32_bits(_value_2));
  } else if (_raw_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Binary64") {
    const _high_0 = _raw_0["high"];
    const _low_0 = _raw_0["low"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_numeric$(_high_0, _low_0);
  } else {
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.NotNumber"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058checked$(_left_0, _right_0) {
  return $Bool$and$(($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058valid$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058valid$(_right_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058equal$(_left_0, _right_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058text$(_value_0) {
  if (_value_0 === "") {
    return {$: "Nil"};
  } else {
    const _t_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
    const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
    const _x_0 = _t_0.codePointAt(0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058scalar$(_t_0.codePointAt(0), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058text$(_tail_0)), (_x_0 < 65536));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058same_bool$(_a_0, _b_0) {
  if (_a_0) {
    if (_b_0) {
      return true;
    } else {
      return false;
    }
  } else {
    if (!_b_0) {
      return true;
    } else {
      return false;
    }
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $step_14$(_previous_0) {
  return $done_14$(_previous_0, {$: "Recovered", "label": {$: "RActivationRefused"}, "value": ($$$$047generic$045assembly$045v1$047recovery$045fixture$058run$({$: "../generic-assembly-v1/recovery-fixture.ActivationRefused"}))});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058first_spawn$(_mode_0, _result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "Done") {
    const _target_0 = _t_1["value"];
    const _t_2 = _t_0["snd"];
    const _t_3 = _t_2["fst"];
    if (_t_3.$ === "None") {
      const _t_4 = _t_2["snd"];
      const _t_5 = _t_4["fst"];
      if (_t_5.$ === "Some") {
        const _receipt_0 = _t_5["value"];
        const _t_6 = _t_4["snd"];
        if (_t_6.$ === "None") {
          return $$$$047generic$045assembly$045v1$047recovery$045fixture$058first_accepted$(_mode_0, _receipt_0, _target_0, _tx_0);
        } else {
          return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, {$: "Nil"}, {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "Done", "value": _target_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _receipt_0}, "snd": _t_6}}}});
        }
      } else {
        const _22_0 = _t_4["snd"];
        return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, {$: "Nil"}, {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "Done", "value": _target_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": _t_5, "snd": _22_0}}}});
      }
    } else {
      const _20_0 = _t_2["snd"];
      return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, {$: "Nil"}, {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "Done", "value": _target_0}, "snd": {$: "Tuple", "fst": _t_3, "snd": _20_0}}});
    }
  } else {
    const _18_0 = _t_0["snd"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, {$: "Nil"}, {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _t_1, "snd": _18_0}});
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058spawn$1261$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047generic$045assembly$045v1$047immediate$058reserved$1261$(_payload_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058activation_refused$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$({$: "../generic-assembly-v1/recovery-fixture.ActivationRefused"}, {$: "Nil"}, ($$$$047generic$045assembly$045v1$047immediate$058activated$1260$({$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": 0, "id": 1}, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet$(11)), _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": 0, "id": 1})))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058write_read_field$1261$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045inspect$047debug$045study$045v1$047production$045adoption$045v1$047public$045api$045v1$047docs$047ordinary$045v1$047query$045candidate$045v1$047declaration$058grant$1261$(_declaration_0) {
  const _grant_0 = _declaration_0["grant"];
  return _grant_0;
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_projected$1261$(_frame_0, _canonical_0, _result_0) {
  const _t_0 = _frame_0["owner"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _declaration_0 = _t_0["declaration"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  const _receipts_0 = _frame_0["receipts"];
  const _pending_0 = _frame_0["pending"];
  const _owner_0 = _result_0["fst"];
  const _original_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047assembly$045frame$058spawned$1261$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _canonical_0, ($$$$047generic$045assembly$045v1$047immediate$058spawn$1262$(_tx_0, {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _original_0, "canonical": _canonical_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_owner$1261$(_codec_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_projected$1261$(_codec_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_0)));
}

function $$$$047generic$045assembly$045v1$047request$058validated$1261$(_declaration_0, _batch_0, _operation_0, _receipt_0) {
  const _owner_0 = _receipt_0["owner"];
  const _t_0 = _receipt_0["checked"];
  if (_t_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected") {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Refused", "owner": {$: "Some", "value": _owner_0}, "error": {$: "../generic-assembly-v1/request.Validation", "error": _error_0}}};
  } else {
    const _canonical_0 = _t_0["value"];
    return $$$$047generic$045assembly$045v1$047request$058enqueue$1261$(_declaration_0, _batch_0, _operation_0, _canonical_0, ($$$$047generic$045assembly$045v1$047first$045owner$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058replace_join$1261$(_replaced_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _replaced_0["fst"];
  const _old_0 = _replaced_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058restore$1261$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058replace_resource$1261$(_world_0, _replacement_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _replacement_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _resource_0};
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_array$(_head_0, _rest_0) {
  const _head_1 = _head_0["raw"];
  const _items_0 = _rest_0["items"];
  return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array", "items": {$: "Con", "head": _head_1, "tail": _items_0}}, "items": {$: "Con", "head": _head_1, "tail": _items_0}, "fields": {$: "Nil"}};
}

function $$$$047generic$045assembly$045v1$047fixture$045raw$045boundary$058to_new_object$(_name_0, _head_0, _rest_0) {
  const _head_1 = _head_0["raw"];
  const _fields_0 = _rest_0["fields"];
  return {$: "../generic-assembly-v1/fixture-raw-boundary.ConvertedNew", "raw": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object", "fields": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Field", "name": _name_0, "value": _head_1}, "tail": _fields_0}}, "items": {$: "Nil"}, "fields": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Field", "name": _name_0, "value": _head_1}, "tail": _fields_0}};
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_integer_normal$(_result_0) {
  if (_result_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Finite") {
    const _high_0 = _result_0["high"];
    const _low_0 = _result_0["low"];
    const _exponent_0 = _result_0["exponent"];
    const _x_0 = ($Bool$and$((_high_0 === 0), (_low_0 === 0)));
    const _x_1 = ($Bool$and$((_exponent_0 >= 1074), (_exponent_0 <= 1126)));
    return (_x_0 || _x_1);
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058binary_parts$(_negative_0, _exponent_0, _high_0, _low_0, _special_0, _zero_0) {
  if (_special_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric_special$(_negative_0, ($Bool$and$((_high_0 === 0), (_low_0 === 0))));
  } else {
    if (_zero_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize$(64, _negative_0, _high_0, _low_0, 0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize$(64, _negative_0, ((_high_0 + 1048576) >>> 0), _low_0, ((_exponent_0 - 1) >>> 0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize$(_fuel_0, _negative_0, _high_0, _low_0, _exponent_0) {
  const _x_0 = (2 === 0 ? _low_0 : _low_0 % 2);
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize_checked$(_fuel_0, _negative_0, _high_0, _low_0, _exponent_0, ($Bool$and$((_high_0 === 0), (_low_0 === 0))), (_x_0 === 0));
}

function $Nat$mod$(_a_0, _b_0) {
  return $Pair$snd$(nat_divmod(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058float_numeric$(_bits_0) {
  const _x_0 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_1 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_2 = (256 === 0 ? _x_1 : _x_1 % 256);
  const _x_3 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_4 = (256 === 0 ? _x_3 : _x_3 % 256);
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058float_parts$(_bits_0, (256 === 0 ? _x_0 : _x_0 % 256), (8388608 === 0 ? _bits_0 : _bits_0 % 8388608), (_x_2 === 255), (_x_4 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058equal$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058empty$(_right_0);
  } else {
    const _head_0 = _left_0["head"];
    const _tail_0 = _left_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058compared$(_head_0, _right_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058equal$(_tail_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058scalar$(_code_0, _rest_0, _bmp_0) {
  if (_bmp_0) {
    return {$: "Con", "head": _code_0, "tail": _rest_0};
  } else {
    const _x_0 = ((_code_0 - 65536) >>> 0);
    const _x_1 = (1024 === 0 ? 0 : (_x_0 / 1024) >>> 0);
    const _x_2 = ((_code_0 - 65536) >>> 0);
    const _x_3 = (1024 === 0 ? _x_2 : _x_2 % 1024);
    return {$: "Con", "head": ((55296 + _x_1) >>> 0), "tail": {$: "Con", "head": ((56320 + _x_3) >>> 0), "tail": _rest_0}};
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Accepted") {
    return _world_0;
  } else {
    return _world_0;
  }
}

function $done_14$(_previous_0, _value_0) {
  return $List$reverse$({$: "Con", "head": _value_0, "tail": _previous_0});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058first_accepted$(_mode_0, _receipt_0, _target_0, _tx_0) {
  if (_mode_0.$ === "../generic-assembly-v1/recovery-fixture.EqualPosition") {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058second_spawn$({$: "../generic-assembly-v1/recovery-fixture.EqualPosition"}, {$: "Con", "head": _receipt_0, "tail": {$: "Nil"}}, ($$$$047generic$045assembly$045v1$047immediate$058spawn$1260$(_tx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet$(22)))));
  } else {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058written$(_mode_0, {$: "Con", "head": _receipt_0, "tail": {$: "Nil"}}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058tx_set$1260$(($$$$047generic$045assembly$045v1$047second$045owner$058family$()), _tx_0, _target_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058second$(99)))));
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, _receipts_0, _result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _status_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _owner_0 = _t_1["fst"];
  const _t_2 = _t_1["snd"];
  const _t_3 = _t_2["fst"];
  if (_t_3.$ === "None") {
    const _pending_0 = _t_2["snd"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_status$(_status_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_owner$(_owner_0, _pending_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058finish$(_mode_0, _receipts_0, _tx_0)))));
  } else {
    const _receipt_0 = _t_3["value"];
    const _pending_1 = _t_2["snd"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_status$(_status_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_owner$(_owner_0, _pending_1, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058finish$(_mode_0, {$: "Con", "head": _receipt_0, "tail": _receipts_0}, _tx_0)))));
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058reserved$1261$(_payload_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_0["handle"];
    return $$$$047generic$045assembly$045v1$047immediate$058activated$1261$(_target_0, _payload_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _target_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_0}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}}}}};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawned$1261$(_declaration_0, _prepared_0, _handle_0, _error_0, _cursor_0, _receipts_0, _pending_0, _canonical_0, _result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _result_1 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _packet_0 = _t_1["fst"];
  const _t_2 = _t_1["snd"];
  const _receipt_0 = _t_2["fst"];
  const _next_0 = _t_2["snd"];
  return {$: "Tuple", "fst": {$: "../generic-assembly-v1/assembly-frame.Frame", "owner": {$: "../generic-assembly-v1/request.Owner", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, "declaration": _declaration_0}, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0, "receipts": ($$$$047generic$045assembly$045v1$047assembly$045frame$058receipt_added$1261$(_receipts_0, _receipt_0)), "pending": ($$$$047generic$045assembly$045v1$047assembly$045frame$058pending_added$1261$(_pending_0, _next_0))}, "snd": ($$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_output$1261$(_canonical_0, _result_1, _packet_0))};
}

function $$$$047generic$045assembly$045v1$047immediate$058spawn$1262$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047generic$045assembly$045v1$047immediate$058reserved$1262$(_payload_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_projected$1261$(_codec_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _raw_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_budget$1261$(_codec_0, _raw_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045size$058budget$(_codec_0, _raw_0)), _owner_0);
}

function $$$$047generic$045assembly$045v1$047request$058enqueue$1261$(_declaration_0, _batch_0, _operation_0, _canonical_0, _projected_0) {
  const _owner_0 = _projected_0["fst"];
  const _original_0 = _projected_0["snd"];
  return $$$$047generic$045assembly$045v1$047request$058enqueue_packet$1261$(_declaration_0, _batch_0, _operation_0, _owner_0, _original_0, _canonical_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058restore$1261$(_world_0, _old_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058restore_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058replace_resource$1261$(_world_0, _old_0)));
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric_special$(_negative_0, _infinite_0) {
  if (_infinite_0) {
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Infinity", "negative": _negative_0};
  } else {
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.NaN"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize_checked$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _negative_0 = $1;
      const _high_0 = $2;
      const _low_0 = $3;
      const _exponent_0 = $4;
      const _zero_0 = $5;
      const _even_0 = $6;
      if (_fuel_0 === 0) {
        if (_zero_0) {
          return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Finite", "negative": false, "high": 0, "low": 0, "exponent": 0};
        } else {
          if (!_even_0) {
            return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          } else {
            return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          }
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_zero_0) {
          return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Finite", "negative": false, "high": 0, "low": 0, "exponent": 0};
        } else {
          if (!_even_0) {
            return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          } else {
            const _x_0 = (2 === 0 ? _high_0 : _high_0 % 2);
            const _x_1 = (2 === 0 ? 0 : (_low_0 / 2) >>> 0);
            const _x_2 = (Math.imul(_x_0, 2147483648) >>> 0);
            const _x_3 = (2 === 0 ? 0 : (_low_0 / 2) >>> 0);
            const _x_4 = (2 === 0 ? _x_3 : _x_3 % 2);
            $0 = _more_0;
            $1 = _negative_0;
            $2 = (2 === 0 ? 0 : (_high_0 / 2) >>> 0);
            $3 = ((_x_1 + _x_2) >>> 0);
            $4 = ((_exponent_0 + 1) >>> 0);
            $5 = false;
            $6 = (_x_4 === 0);
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058float_parts$(_bits_0, _exponent_0, _fraction_0, _special_0, _zero_0) {
  if (_special_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058numeric_special$((_bits_0 >= 2147483648), (_fraction_0 === 0));
  } else {
    if (_zero_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize$(64, (_bits_0 >= 2147483648), 0, _fraction_0, 925);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalize$(64, (_bits_0 >= 2147483648), 0, ((_fraction_0 + 8388608) >>> 0), ((_exponent_0 + 924) >>> 0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058empty$(_units_0) {
  if (_units_0.$ === "Nil") {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045utf16$058compared$(_head_0, _other_0, _next_0) {
  if (_other_0.$ === "Nil") {
    return false;
  } else {
    const _value_0 = _other_0["head"];
    const _tail_0 = _other_0["tail"];
    return $Bool$and$((_head_0 === _value_0), _next_0(_tail_0));
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058second_spawn$(_mode_0, _receipts_0, _result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "Done") {
    const _target_0 = _t_1["value"];
    const _t_2 = _t_0["snd"];
    const _t_3 = _t_2["fst"];
    if (_t_3.$ === "None") {
      const _t_4 = _t_2["snd"];
      const _t_5 = _t_4["fst"];
      if (_t_5.$ === "Some") {
        const _receipt_0 = _t_5["value"];
        const _t_6 = _t_4["snd"];
        if (_t_6.$ === "None") {
          return $$$$047generic$045assembly$045v1$047recovery$045fixture$058after_second$(_mode_0, _target_0, {$: "Con", "head": _receipt_0, "tail": _receipts_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058tx_replace$1260$(_tx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058first$(300)))));
        } else {
          return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, _receipts_0, {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "Done", "value": _target_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _receipt_0}, "snd": _t_6}}}});
        }
      } else {
        const _28_0 = _t_4["snd"];
        return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, _receipts_0, {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "Done", "value": _target_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": _t_5, "snd": _28_0}}}});
      }
    } else {
      const _26_0 = _t_2["snd"];
      return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, _receipts_0, {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": {$: "Done", "value": _target_0}, "snd": {$: "Tuple", "fst": _t_3, "snd": _26_0}}});
    }
  } else {
    const _24_0 = _t_0["snd"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_spawn$(_mode_0, _receipts_0, {$: "Tuple", "fst": _tx_0, "snd": {$: "Tuple", "fst": _t_1, "snd": _24_0}});
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058written$(_mode_0, _receipts_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058second_spawn$(_mode_0, _receipts_0, ($$$$047generic$045assembly$045v1$047immediate$058spawn$1260$(_tx_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058packet$(22)))));
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    const _owner_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058written_refused$(_mode_0, _receipts_0, _tx_1, _error_0, ($$$$047generic$045assembly$045v1$047second$045owner$058project$(_owner_0)));
  } else {
    const _tx_2 = _result_0["tx"];
    const _error_1 = _result_0["error"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_error$(_error_1, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058finish$(_mode_0, _receipts_0, _tx_2)));
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_status$(_status_0, _result_0) {
  if (_status_0.$ === "Done") {
    return _result_0;
  } else {
    const _error_0 = _status_0["error"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_error$(_error_0, _result_0);
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_owner$(_packet_0, _pending_0, _result_0) {
  if (_packet_0.$ === "None") {
    if (_pending_0.$ === "None") {
      return _result_0;
    } else {
      const _owner_0 = _pending_0["value"];
      if (_result_0.$ === "../../../../../../bendvy/src/ecs/local.Failed") {
        const _world_0 = _result_0["world"];
        const _t_0 = _result_0["local"];
        const _owners_0 = _t_0["owners"];
        const _pending_1 = _t_0["pending"];
        const _during_0 = _t_0["during"];
        const _errors_0 = _t_0["errors"];
        const _error_0 = _result_0["error"];
        return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_0, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": _owners_0, "pending": {$: "Con", "head": _owner_0, "tail": _pending_1}, "during": _during_0, "errors": _errors_0}, "error": _error_0};
      } else {
        const _world_1 = _result_0["world"];
        const _t_1 = _result_0["local"];
        const _owners_1 = _t_1["owners"];
        const _pending_2 = _t_1["pending"];
        const _during_1 = _t_1["during"];
        const _errors_1 = _t_1["errors"];
        const _output_0 = _result_0["output"];
        return {$: "../../../../../../bendvy/src/ecs/local.Succeeded", "world": _world_1, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": _owners_1, "pending": {$: "Con", "head": _owner_0, "tail": _pending_2}, "during": _during_1, "errors": _errors_1}, "output": _output_0};
      }
    }
  } else {
    const _owner_1 = _packet_0["value"];
    if (_pending_0.$ === "None") {
      if (_result_0.$ === "../../../../../../bendvy/src/ecs/local.Failed") {
        const _world_2 = _result_0["world"];
        const _t_2 = _result_0["local"];
        const _owners_2 = _t_2["owners"];
        const _pending_3 = _t_2["pending"];
        const _during_2 = _t_2["during"];
        const _errors_2 = _t_2["errors"];
        const _error_1 = _result_0["error"];
        return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_2, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": {$: "Con", "head": _owner_1, "tail": _owners_2}, "pending": _pending_3, "during": _during_2, "errors": _errors_2}, "error": _error_1};
      } else {
        const _world_3 = _result_0["world"];
        const _t_3 = _result_0["local"];
        const _owners_3 = _t_3["owners"];
        const _pending_4 = _t_3["pending"];
        const _during_3 = _t_3["during"];
        const _errors_3 = _t_3["errors"];
        const _output_1 = _result_0["output"];
        return {$: "../../../../../../bendvy/src/ecs/local.Succeeded", "world": _world_3, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": {$: "Con", "head": _owner_1, "tail": _owners_3}, "pending": _pending_4, "during": _during_3, "errors": _errors_3}, "output": _output_1};
      }
    } else {
      const _recovery_0 = _pending_0["value"];
      if (_result_0.$ === "../../../../../../bendvy/src/ecs/local.Failed") {
        const _world_4 = _result_0["world"];
        const _t_4 = _result_0["local"];
        const _owners_4 = _t_4["owners"];
        const _pending_5 = _t_4["pending"];
        const _during_4 = _t_4["during"];
        const _errors_4 = _t_4["errors"];
        const _error_2 = _result_0["error"];
        return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_4, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": {$: "Con", "head": _owner_1, "tail": _owners_4}, "pending": {$: "Con", "head": _recovery_0, "tail": _pending_5}, "during": _during_4, "errors": _errors_4}, "error": _error_2};
      } else {
        const _world_5 = _result_0["world"];
        const _t_5 = _result_0["local"];
        const _owners_5 = _t_5["owners"];
        const _pending_6 = _t_5["pending"];
        const _during_5 = _t_5["during"];
        const _errors_5 = _t_5["errors"];
        const _output_2 = _result_0["output"];
        return {$: "../../../../../../bendvy/src/ecs/local.Succeeded", "world": _world_5, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": {$: "Con", "head": _owner_1, "tail": _owners_5}, "pending": {$: "Con", "head": _recovery_0, "tail": _pending_6}, "during": _during_5, "errors": _errors_5}, "output": _output_2};
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058finish$(_mode_0, _receipts_0, _tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058snap_abort$(_mode_0, _receipts_0, _undo_0, _commands_0, _events_0, ($$$$047generic$045assembly$045v1$047observation$058snapshot$(_world_0)));
}

function $$$$047generic$045assembly$045v1$047immediate$058activated$1261$(_target_0, _payload_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Accepted") {
    return $$$$047generic$045assembly$045v1$047immediate$058installed$1260$(_target_0, _undo_0, _commands_0, _events_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058reject_install$(_world_0, _target_0, _payload_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_0}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}}}}};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058receipt_added$1261$(_receipts_0, _receipt_0) {
  if (_receipt_0.$ === "None") {
    return _receipts_0;
  } else {
    const _receipt_1 = _receipt_0["value"];
    return {$: "Con", "head": _receipt_1, "tail": _receipts_0};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058pending_added$1261$(_pending_0, _next_0) {
  if (_next_0.$ === "None") {
    return _pending_0;
  } else {
    const _next_1 = _next_0["value"];
    return {$: "Con", "head": _next_1, "tail": _pending_0};
  }
}

function $$$$047generic$045assembly$045v1$047assembly$045frame$058spawn_output$1261$(_canonical_0, _result_0, _packet_0) {
  if (_result_0.$ === "Done") {
    const _target_0 = _result_0["value"];
    return {$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": true, "canonical": _canonical_0};
  } else {
    const _error_0 = _result_0["error"];
    if (_packet_0.$ === "None") {
      return {$: "../generic-assembly-v1/request.Refused", "owner": {$: "None"}, "error": {$: "../generic-assembly-v1/request.Entity", "error": _error_0}};
    } else {
      const _t_0 = _packet_0["value"];
      const _owner_0 = _t_0["owner"];
      return {$: "../generic-assembly-v1/request.Refused", "owner": _owner_0, "error": {$: "../generic-assembly-v1/request.Entity", "error": _error_0}};
    }
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058reserved$1262$(_payload_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_0["handle"];
    return $$$$047generic$045assembly$045v1$047immediate$058activated$1262$(_target_0, _payload_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _target_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_0}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$058decode_budget$1261$(_codec_0, _raw_0, _fuel_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalized$1261$(_fuel_0, _codec_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058owned$1261$(_fuel_0, _codec_0, {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Owned", "owner": _owner_0, "description": _raw_0})));
}

function $$$$047generic$045assembly$045v1$047request$058enqueue_packet$1261$(_declaration_0, _batch_0, _operation_0, _owner_0, _original_0, _canonical_0) {
  if (_operation_0.$ === "../../../../../../bendvy/src/ecs/bundle-requests.Insert") {
    const _target_0 = _operation_0["target"];
    return $$$$047generic$045assembly$045v1$047request$058inserted$1261$(_declaration_0, _target_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058insert$1261$(_batch_0, _target_0, {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _original_0, "canonical": _canonical_0})));
  } else {
    return $$$$047generic$045assembly$045v1$047request$058spawned$1261$(_declaration_0, _canonical_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn$1261$(_batch_0, {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _original_0, "canonical": _canonical_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047resource$058restore_join$1261$(_replaced_0) {
  const _world_0 = _replaced_0["fst"];
  return _world_0;
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058after_second$(_mode_0, _target_0, _receipts_0, _tx_0) {
  if (_mode_0.$ === "../generic-assembly-v1/recovery-fixture.PendingControl") {
    const _world_0 = _tx_0["world"];
    const _undo_0 = _tx_0["undo"];
    const _commands_0 = _tx_0["commands"];
    const _events_0 = _tx_0["events"];
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058inactive$({$: "../generic-assembly-v1/recovery-fixture.PendingControl"}, _receipts_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1260$(_world_0, _target_0)));
  } else {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058finish$(_mode_0, _receipts_0, _tx_0);
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058written_refused$(_mode_0, _receipts_0, _tx_0, _error_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _raw_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_error$(_error_0, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_owner$({$: "Some", "value": {$: "../generic-assembly-v1/request.Packet", "owner": {$: "Some", "value": _owner_0}, "original": _raw_0, "canonical": _raw_0}}, {$: "None"}, ($$$$047generic$045assembly$045v1$047recovery$045fixture$058finish$(_mode_0, _receipts_0, _tx_0)))));
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058rejected_error$(_error_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/local.Failed") {
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["local"];
    const _owners_0 = _t_0["owners"];
    const _pending_0 = _t_0["pending"];
    const _during_0 = _t_0["during"];
    const _errors_0 = _t_0["errors"];
    const _failed_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_0, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": _owners_0, "pending": _pending_0, "during": _during_0, "errors": {$: "Con", "head": _error_0, "tail": _errors_0}}, "error": _failed_0};
  } else {
    const _world_1 = _result_0["world"];
    const _t_1 = _result_0["local"];
    const _owners_1 = _t_1["owners"];
    const _pending_1 = _t_1["pending"];
    const _during_1 = _t_1["during"];
    const _errors_1 = _t_1["errors"];
    const _output_0 = _result_0["output"];
    return {$: "../../../../../../bendvy/src/ecs/local.Succeeded", "world": _world_1, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": _owners_1, "pending": _pending_1, "during": _during_1, "errors": {$: "Con", "head": _error_0, "tail": _errors_1}}, "output": _output_0};
  }
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058snap_abort$(_mode_0, _receipts_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _during_0 = _result_0["snd"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058snap_finished$(_mode_0, _during_0, _receipts_0, {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058reject_install$(_world_0, _target_0, _packet_0) {
  return {$: "../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": _packet_0, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}};
}

function $$$$047generic$045assembly$045v1$047immediate$058activated$1262$(_target_0, _payload_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Accepted") {
    return $$$$047generic$045assembly$045v1$047immediate$058installed$1261$(_target_0, _undo_0, _commands_0, _events_0, ($$$$047generic$045assembly$045v1$047first$045owner$058install$(_world_0, _target_0, _payload_0)));
  } else {
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_0}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058normalized$1261$(_fuel_0, _codec_0, _result_0) {
  const _owner_0 = _result_0["owner"];
  const _t_0 = _result_0["checked"];
  if (_t_0.$ === "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Accepted") {
    const _value_0 = _t_0["value"];
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Receipt", "owner": _owner_0, "checked": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Accepted", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058canonical$(_fuel_0, _codec_0, _value_0))}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Receipt", "owner": _owner_0, "checked": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Rejected", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058owned$1261$(_fuel_0, _codec_0, _input_0) {
  const _owner_0 = _input_0["owner"];
  const _description_0 = _input_0["description"];
  return {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Receipt", "owner": _owner_0, "checked": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047experiments$047public$045snapshot$047persistence$045gate$045v1$047basic$045world$045v1$047public$045adoption$045v1$047core$045promotion$045v1$047library$047decode$045data$058validate$(_fuel_0, {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Continue", "work": {$: "Con", "head": {$: "../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Work", "codec": _codec_0, "raw": _description_0, "path": "$"}, "tail": {$: "Nil"}}}, _description_0))};
}

function $$$$047generic$045assembly$045v1$047request$058inserted$1261$(_declaration_0, _target_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": false, "canonical": _canonical_0}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_1, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Refused", "owner": _owner_0, "error": {$: "../generic-assembly-v1/request.Entity", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058insert$1261$(_batch_0, _target_0, _payload_0) {
  const _t_0 = _batch_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058checked$1261$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047generic$045assembly$045v1$047request$058spawned$1261$(_declaration_0, _canonical_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.Spawned") {
    const _batch_0 = _result_0["batch"];
    const _target_0 = _result_0["target"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_0, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Accepted", "target": _target_0, "spawned": true, "canonical": _canonical_0}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _t_0 = _result_0["payload"];
    const _owner_0 = _t_0["owner"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../generic-assembly-v1/request.Owner", "batch": _batch_1, "declaration": _declaration_0}, "snd": {$: "../generic-assembly-v1/request.Refused", "owner": _owner_0, "error": {$: "../generic-assembly-v1/request.Entity", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn$1261$(_batch_0, _payload_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_reserved$1261$(_prepared_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, {$: "Unit"})));
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058inactive$(_mode_0, _receipts_0, _undo_0, _commands_0, _events_0, _result_0) {
  const _world_0 = _result_0["fst"];
  return $$$$047generic$045assembly$045v1$047recovery$045fixture$058finish$(_mode_0, _receipts_0, {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0});
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058snap_finished$(_mode_0, _during_0, _receipts_0, _tx_0) {
  if (_mode_0.$ === "../generic-assembly-v1/recovery-fixture.Success") {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058commit_result$(_during_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../../../../bendvy/src/ecs/transaction.Success"})));
  } else {
    return $$$$047generic$045assembly$045v1$047recovery$045fixture$058aborted$(_during_0, run_loop($$$$047generic$045assembly$045v1$047owned$045journal$058abort$1260$(_receipts_0, _tx_0)));
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058installed$1261$(_target_0, _undo_0, _commands_0, _events_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Installed") {
    const _world_0 = _result_0["world"];
    const _inverse_0 = _result_0["undo"];
    return $$$$047generic$045assembly$045v1$047immediate$058receipt$1261$(_target_0, _world_0, _inverse_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1262$(_undo_0)));
  } else if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": ($$$$047generic$045assembly$045v1$047immediate$058deactivated$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1261$(_world_1, _target_0)))), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_0}, "snd": {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "None"}}}}};
  } else {
    const _world_2 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_2, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Fail", "error": _error_1}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Some", "value": {$: "../generic-assembly-v1/owned-journal.Pending", "owner": _recovery_0, "error": _error_1}}}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058checked$1261$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_checked$1261$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1261$(_prepared_0, _target_0)));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1262$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_reserved$1261$(_prepared_0, _payload_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_1["handle"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_positioned$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1261$({$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt", "target": _target_0}, "tail": _prepared_0}, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1262$(_commands_0)))));
  } else {
    const _error_0 = _t_1["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-batch.SpawnRefused", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058commit_result$(_during_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../bendvy/src/ecs/local.Succeeded", "world": _world_0, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": {$: "Nil"}, "pending": {$: "Nil"}, "during": {$: "Some", "value": _during_0}, "errors": {$: "Nil"}}, "output": {$: "Unit"}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_0, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": {$: "Nil"}, "pending": {$: "Nil"}, "during": {$: "Some", "value": _during_0}, "errors": {$: "Nil"}}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047generic$045assembly$045v1$047recovery$045fixture$058aborted$(_during_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _owners_0 = _result_0["owners"];
  const _pending_0 = _result_0["pending"];
  return {$: "../../../../../../bendvy/src/ecs/local.Failed", "world": _world_0, "local": {$: "../generic-assembly-v1/recovery-fixture.State", "owners": _owners_0, "pending": _pending_0, "during": {$: "Some", "value": _during_0}, "errors": {$: "Nil"}}, "error": {$: "Unit"}};
}

function $$$$047generic$045assembly$045v1$047immediate$058receipt$1261$(_target_0, _world_0, _inverse_0, _commands_0, _events_0, _result_0) {
  const _undo_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "Tuple", "fst": {$: "Done", "value": _target_0}, "snd": {$: "Tuple", "fst": {$: "None"}, "snd": {$: "Tuple", "fst": {$: "Some", "value": {$: "../generic-assembly-v1/owned-journal.Receipt", "position": _position_0, "inverse": run_clo((_x_0) => {
  return $$$$047generic$045assembly$045v1$047immediate$058restored$1261$(_target_0, _inverse_0(_x_0));
})}}, "snd": {$: "None"}}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1262$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1262$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1262$(_tail_0)));
  }
}

function $$$$047generic$045assembly$045v1$047immediate$058deactivated$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(false, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_checked$1261$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _result_0) {
  const _prepared_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../bendvy/src/ecs/bundle-batch.Refused", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": {$: "../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1262$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1261$(_prepared_0, _target_0) {
  if (_prepared_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": false};
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.Prepared") {
      const _handle_0 = _t_0["target"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _tail_0 = _prepared_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1261$({$: "../../../../../../bendvy/src/ecs/bundle-batch.Prepared", "target": _handle_0, "payload": _payload_0, "position": _position_0}, false, ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1261$(_tail_0, _target_0)));
    } else {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _tail_1 = _prepared_0["tail"];
      const _otherNs_0 = _target_0["namespace"];
      const _otherId_0 = _target_0["id"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1261$({$: "../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt", "target": {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}}, ($Bool$and$((_ns_0 === _otherNs_0), (_id_0 === _otherId_0))), ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1261$(_tail_1, {$: "../../../../../../bendvy/src/ecs/world.Handle", "namespace": _otherNs_0, "id": _otherId_0})));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "../../../../../../bendvy/src/ecs/bundle-batch.Inserted", "batch": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": {$: "Con", "head": {$: "../../../../../../bendvy/src/ecs/bundle-batch.Prepared", "target": _target_0, "payload": _payload_0, "position": _position_0}, "tail": _prepared_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_positioned$1261$(_target_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-batch.Spawned", "batch": _batch_0, "target": _target_0};
  } else {
    const _batch_1 = _result_0["batch"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-batch.SpawnRefused", "batch": _batch_1, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1261$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047generic$045assembly$045v1$047immediate$058restored$1261$(_target_0, _result_0) {
  if (_result_0.$ === "../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": ($$$$047generic$045assembly$045v1$047immediate$058deactivated$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1261$(_world_0, _target_0)))), "payload": _payload_0};
  } else {
    const _world_1 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": _recovery_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1262$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1261$(_entry_0, _seen_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _found_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _tail_0}, "snd": (_seen_0 || _found_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../../../../bendvy/src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1261$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../../../../bendvy/src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1261$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1261$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../../../../bendvy/src/ecs/world.Accepted") {
    return _world_0;
  } else {
    return _world_0;
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,1,2,0,0,0,1,1,0,2,1,0,15,1,0,7,1,3,2,0,2,0,0,42,1,61,3,0,2,0,0,42,1,1073,4,0,2,0,0,1479,1,1510,7,0,4,5,0,0,0,6,0,0,0,7,0,0,0,8,0,0,0,7,0,2,9,0,4,0,1,82,17,82,33,584,39,982,10,0,1,0,1,982,7,0,1,11,0,5,0,0,99,9,192,10,218,13,455,15,124,7,0,1,12,0,9,0,0,124,1,124,2,124,3,124,4,125,5,126,6,148,7,124,8,124,0,2,7,1,2,13,0,0,1,14,0,2,1,0,141,1,126,7,1,1,15,0,0,0,7,1,2,16,0,0,1,17,0,2,1,0,163,1,148,7,1,1,18,0,3,0,0,124,1,176,2,177,4,7,1,2,19,0,0,1,20,0,2,1,0,176,1,177,7,1,2,21,0,0,1,22,0,2,1,0,207,1,192,7,1,2,23,0,0,0,24,0,0,0,7,0,1,25,0,3,0,0,231,1,242,2,418,7,0,2,26,0,0,0,27,0,0,0,7,1,2,28,0,0,1,29,0,2,1,0,257,1,242,7,1,2,30,0,0,0,31,0,1,0,0,270,7,1,1,32,0,3,0,0,283,1,361,2,192,7,1,12,33,0,0,0,34,0,0,0,35,0,1,0,0,124,36,0,2,0,0,231,1,125,37,0,1,0,0,360,38,0,2,0,0,124,1,124,39,0,1,0,0,176,40,0,1,0,0,361,41,0,1,0,0,231,42,0,2,0,0,124,1,124,43,0,1,0,0,377,44,0,1,0,0,392,1,7,1,2,45,0,0,1,46,0,2,1,0,376,1,361,0,7,1,2,47,0,0,1,48,0,2,1,0,283,1,377,7,1,2,49,0,0,1,50,0,2,1,0,407,1,392,7,1,1,51,0,2,0,0,176,1,283,7,1,2,52,0,0,1,53,0,2,1,0,433,1,418,7,1,1,54,0,2,0,0,124,1,444,7,0,1,55,0,2,0,0,124,1,124,7,0,1,56,0,2,0,0,466,1,361,7,1,12,57,0,0,0,58,0,0,0,59,0,1,0,0,124,60,0,2,0,0,231,1,125,61,0,1,0,0,360,62,0,2,0,0,124,1,124,63,0,1,0,0,176,64,0,1,0,0,361,65,0,1,0,0,231,66,0,2,0,0,124,1,124,67,0,1,0,0,543,68,0,1,0,0,558,7,1,2,69,0,0,1,70,0,2,1,0,466,1,543,7,1,2,71,0,0,1,72,0,2,1,0,573,1,558,7,1,1,73,0,2,0,0,176,1,466,7,0,1,74,0,5,0,0,124,1,124,2,176,3,177,4,601,7,0,1,75,0,2,0,0,612,1,701,7,1,11,76,0,0,0,77,0,0,0,78,0,0,0,79,0,0,0,80,0,1,0,0,283,81,0,1,0,0,377,82,0,2,0,0,377,1,176,83,0,1,0,0,612,84,0,1,0,0,612,85,0,1,0,0,675,86,0,1,0,0,124,7,1,2,87,0,0,1,88,0,2,1,0,690,1,675,7,1,1,89,0,2,0,0,176,1,612,7,1,2,90,0,0,1,91,0,2,1,0,716,1,701,7,1,1,92,0,3,0,0,729,10,924,11,952,7,0,1,93,0,4,0,0,744,7,781,8,894,9,231,7,0,2,94,0,0,0,95,0,1,0,1,757,7,0,1,96,0,2,0,0,768,3,768,7,0,1,97,0,3,0,0,283,1,361,2,192,7,1,2,98,0,0,1,99,0,2,1,0,796,1,781,7,1,2,100,0,3,0,0,817,2,231,3,283,101,0,2,0,0,828,4,841,7,0,1,102,0,2,0,0,124,1,124,7,0,2,103,0,0,0,104,0,1,0,1,768,7,0,2,105,0,1,0,1,856,106,0,1,0,1,875,7,0,2,107,0,3,0,1,176,2,176,3,283,108,0,1,0,1,176,7,0,4,109,0,0,0,110,0,0,0,111,0,0,0,112,0,0,0,7,1,2,113,0,0,1,114,0,2,1,0,909,1,894,7,1,2,115,0,0,0,116,0,2,0,0,828,4,875,7,1,2,117,0,0,1,118,0,2,1,0,939,1,924,7,1,1,119,0,3,0,0,828,4,283,5,283,7,1,2,120,0,0,1,121,0,2,1,0,967,1,952,7,1,1,122,0,4,0,0,817,2,828,6,444,8,875,7,0,6,123,0,2,0,1,729,11,1019,124,0,1,0,1,1051,125,0,0,0,126,0,0,0,127,0,1,0,1,729,128,0,1,0,1,729,7,1,2,129,0,0,1,130,0,2,1,0,1034,1,1019,7,1,3,131,0,1,0,0,283,132,0,0,0,133,0,0,0,7,0,2,134,0,1,0,1,1066,135,0,1,0,1,875,7,0,1,136,0,0,0,7,0,2,137,0,4,0,1,1094,18,1094,35,1188,41,1442,138,0,1,0,1,1442,7,0,1,139,0,5,0,0,1111,9,192,10,1136,13,768,16,124,7,0,1,140,0,9,0,0,124,1,124,2,124,3,124,4,125,5,126,6,148,7,124,8,124,7,0,1,141,0,3,0,0,231,1,1149,2,418,7,1,2,142,0,0,1,143,0,2,1,0,1164,1,1149,7,1,2,144,0,0,0,145,0,1,0,0,1177,7,1,1,146,0,2,0,0,466,1,361,7,0,1,147,0,5,0,0,124,1,124,2,176,3,177,4,1205,7,0,1,148,0,2,0,0,612,1,1216,7,1,2,149,0,0,1,150,0,2,1,0,1231,1,1216,7,1,1,151,0,3,0,0,1244,8,1384,9,1412,7,0,1,152,0,4,0,0,1259,5,1294,6,1354,7,231,7,0,2,153,0,0,0,154,0,1,0,1,1272,7,0,1,155,0,2,0,0,1283,2,1283,7,0,1,156,0,2,0,0,466,1,361,7,1,2,157,0,0,1,158,0,2,1,0,1309,1,1294,7,1,2,159,0,3,0,0,1330,2,231,3,283,160,0,2,0,0,1341,3,841,7,0,1,161,0,2,0,0,124,1,124,7,0,2,162,0,0,0,163,0,1,0,1,1283,7,1,2,164,0,0,1,165,0,2,1,0,1369,1,1354,7,1,2,166,0,0,0,167,0,2,0,0,1341,3,875,7,1,2,168,0,0,1,169,0,2,1,0,1399,1,1384,7,1,1,170,0,3,0,0,1341,3,283,4,283,7,1,2,171,0,0,1,172,0,2,1,0,1427,1,1412,7,1,1,173,0,4,0,0,1330,2,1341,5,444,7,875,7,0,6,174,0,2,0,1,1244,9,1019,175,0,1,0,1,1051,176,0,0,0,177,0,0,0,178,0,1,0,1,1244,179,0,1,0,1,1244,7,0,7,180,0,0,0,181,0,0,0,182,0,0,0,183,0,0,0,184,0,0,0,185,0,0,0,186,0,0,0,7,0,2,187,0,0,0,188,0,4,0,1,82,17,82,33,1529,53,1591,7,0,1,189,0,4,0,0,924,1,952,2,1544,19,1557,7,0,2,190,0,0,0,191,0,1,0,1,82,7,1,2,192,0,0,1,193,0,2,1,0,1572,1,1557,7,1,4,194,0,0,0,195,0,0,0,196,0,0,0,197,0,0,0,7,0,2,198,0,1,0,1,1066,199,0,1,0,1,1066],["Nil","Con","Second","First","Recovered","Success","Failure","NoMatch","Skip","../generic-assembly-v1/public-fixture.Report","../generic-assembly-v1/public-fixture.Unavailable","../generic-assembly-v1/observation.Snapshot","../generic-assembly-v1/observation.Meta","Nil","Con","Unit","Nil","Con","../../../../../../bendvy/src/ecs/world.RegistrationMeta","Nil","Con","Nil","Con","False","True","../generic-assembly-v1/observation.ColumnView","False","True","Nil","Con","None","Some","../generic-assembly-v1/observation.PayloadView","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Missing","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Null","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Number","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.SignedInteger","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Float","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Binary64","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Text","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Utf16Text","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Boolean","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Handle","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Array","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Object","Nil","Con","Nil","Con","Nil","Con","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Field","Nil","Con","../../../../../../bendvy/src/ecs/lifecycle.Entry","../../../../../../bendvy/src/ecs/lifecycle.Stamp","../../../../../../bendvy/experiments/public-decode/adoption-v1/observation.PayloadView","../../../../../../bendvy/experiments/public-decode/typed.Missing","../../../../../../bendvy/experiments/public-decode/typed.Null","../../../../../../bendvy/experiments/public-decode/typed.Number","../../../../../../bendvy/experiments/public-decode/typed.SignedInteger","../../../../../../bendvy/experiments/public-decode/typed.Float","../../../../../../bendvy/experiments/public-decode/typed.Binary64","../../../../../../bendvy/experiments/public-decode/typed.Text","../../../../../../bendvy/experiments/public-decode/typed.Utf16Text","../../../../../../bendvy/experiments/public-decode/typed.Boolean","../../../../../../bendvy/experiments/public-decode/typed.Handle","../../../../../../bendvy/experiments/public-decode/typed.Array","../../../../../../bendvy/experiments/public-decode/typed.Object","Nil","Con","Nil","Con","../../../../../../bendvy/experiments/public-decode/typed.Field","../generic-assembly-v1/public-fixture.InstanceView","../generic-assembly-v1/public-fixture.StateView","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.FiniteNumber","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Integer","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.StringValue","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.BoolValue","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Literal","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.LiteralValues","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.LiteralRendered","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Nullable","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.ArrayValue","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Struct","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.HandleValue","Nil","Con","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.NamedCodec","Nil","Con","../generic-assembly-v1/public-fixture.RecoveryView","../generic-assembly-v1/public-fixture.ArgsView","None","Some","../generic-assembly-v1/public-fixture.IncomingView","../generic-assembly-v1/observation.PayloadView","Nil","Con","../generic-assembly-v1/public-fixture.AcceptedView","../generic-assembly-v1/public-fixture.RefusedView","../../../../../../bendvy/src/ecs/world.Handle","None","Some","../generic-assembly-v1/request.Validation","../generic-assembly-v1/request.Entity","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.Invalid","../../../../../../bendvy/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1/core-promotion-v1/library/decode-data.FuelExhausted","../../../../../../bendvy/src/ecs/world.MissingEntity","../../../../../../bendvy/src/ecs/world.CapacityExceeded","../../../../../../bendvy/src/ecs/world.NamespaceExhausted","../../../../../../bendvy/src/ecs/world.SystemIdExhausted","Nil","Con","../generic-assembly-v1/public-fixture.WrittenView","../generic-assembly-v1/public-fixture.WriteRefusedView","Nil","Con","../generic-assembly-v1/recovery-fixture.PacketView","Nil","Con","../generic-assembly-v1/recovery-fixture.PendingView","../generic-assembly-v1/public-fixture.CompletedView","../generic-assembly-v1/public-fixture.FailedView","../generic-assembly-v1/public-fixture.RegistrationRefusedView","../generic-assembly-v1/public-fixture.FactoryRefusedView","../generic-assembly-v1/public-fixture.InvocationRefusedView","../generic-assembly-v1/public-fixture.SkippedView","Nil","Con","../../../../../../bendvy/src/ecs/component.Found","../../../../../../bendvy/src/ecs/component.ComponentAbsent","../../../../../../bendvy/src/ecs/component.MissingEntity","../../../../../../bendvy/src/ecs/compose.UserError","../../../../../../bendvy/src/ecs/compose.AccessError","Unit","../generic-assembly-v1/first-public-fixture.Report","../generic-assembly-v1/first-public-fixture.Unavailable","../generic-assembly-v1/first-observation.Snapshot","../generic-assembly-v1/first-observation.Meta","../generic-assembly-v1/first-observation.ColumnView","Nil","Con","None","Some","../generic-assembly-v1/first-observation.PayloadView","../generic-assembly-v1/first-public-fixture.InstanceView","../generic-assembly-v1/first-public-fixture.StateView","Nil","Con","../generic-assembly-v1/first-public-fixture.RecoveryView","../generic-assembly-v1/first-public-fixture.ArgsView","None","Some","../generic-assembly-v1/first-public-fixture.IncomingView","../generic-assembly-v1/first-observation.PayloadView","Nil","Con","../generic-assembly-v1/first-public-fixture.AcceptedView","../generic-assembly-v1/first-public-fixture.RefusedView","../../../../../../bendvy/src/ecs/world.Handle","None","Some","Nil","Con","../generic-assembly-v1/first-public-fixture.WrittenView","../generic-assembly-v1/first-public-fixture.WriteRefusedView","Nil","Con","../generic-assembly-v1/first-public-fixture.PacketView","Nil","Con","../generic-assembly-v1/first-public-fixture.PendingView","../generic-assembly-v1/first-public-fixture.CompletedView","../generic-assembly-v1/first-public-fixture.FailedView","../generic-assembly-v1/first-public-fixture.RegistrationRefusedView","../generic-assembly-v1/first-public-fixture.FactoryRefusedView","../generic-assembly-v1/first-public-fixture.InvocationRefusedView","../generic-assembly-v1/first-public-fixture.SkippedView","RInterleaved","REqualPosition","RPending","RSuccess","RReserveRefused","RInstallRefused","RActivationRefused","../generic-assembly-v1/recovery-fixture.CreationRejected","../generic-assembly-v1/recovery-fixture.Report","../generic-assembly-v1/recovery-fixture.StateView","None","Some","Nil","Con","../../../../../../bendvy/src/ecs/world.MissingEntity","../../../../../../bendvy/src/ecs/world.CapacityExceeded","../../../../../../bendvy/src/ecs/world.NamespaceExhausted","../../../../../../bendvy/src/ecs/world.SystemIdExhausted","Fail","Done"]]);