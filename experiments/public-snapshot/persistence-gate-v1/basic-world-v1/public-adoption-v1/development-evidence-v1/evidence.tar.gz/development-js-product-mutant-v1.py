import fcntl,hashlib,importlib.util,json,os,shutil,sys
from pathlib import Path
root=Path('/workspace/formal-proofs/bendvy'); here=Path('/workspace/formal-proofs/bendvy-worktrees/parity-58-snapshot-research/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1')
sys.path.insert(0,str(root/'scripts'))
import task_runner
from evidence_boundary import ReceiptBoundary,GuardBoundary
spec=importlib.util.spec_from_file_location('stage',here.parent/'generated-js-stage.py'); stage=importlib.util.module_from_spec(spec);spec.loader.exec_module(stage)
out=here/'development/js-product-mutant-v1';out.mkdir(exist_ok=False)
entry=here/'consumer-io.bend';sources,edges=stage.consumed(entry)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
oracle=here/'oracle-review-v1/expected-product-mutant.json';assert sha(oracle)=='ea171b9285f89e468f9ca6cf8e4474de7249fc2f429bb1e674639f19c568a02b'
frozen=stage.stage(entry,out/'sources',{str(p):h for p,h in sources.items()})
target=next(row for row in frozen['sources'] if row['source']==str(here/'schema-product.bend'))
mutant=Path(target['copy']);before=mutant.read_text();old='List.append(&2,D.Field,fields,more)'
assert before.count(old)==1
mutant.write_text(before.replace(old,'more'))
mutation={'source':target['source'],'copy':target['copy'],'originalSHA256':target['copySHA256'],'mutantSHA256':sha(mutant),'old':old,'new':'more','scope':'single joined_components append removed; both Product owners unchanged'}
target['copySHA256']=sha(mutant);target['rewrite']='import paths plus single reviewed product mutant'
frozen['inventory'][mutant.name]=sha(mutant)
staged_sources,staged_edges=stage.consumed(Path(frozen['entry']))
tools={name:str(Path(shutil.which(name)).resolve()) for name in ('bend','node','taskset')}
pins={str(p):h for p,h in sources.items()};pins.update({str(out/'sources'/n):h for n,h in frozen['inventory'].items()})
for p in [oracle,here/'oracle-review-v1/expected.py',here/'oracle-review-v1/expected.json',here/'oracle-review-v1/expected-product-mutant.py',here/'oracle-review-v1/REVIEW.md',here.parent/'retained-codec-v1/independent-oracle-v2.json',Path(sys.executable).resolve(),Path(__file__),Path(stage.__file__),Path(task_runner.__file__),root/'scripts/evidence_boundary.py',Path.home()/'.bend/bend2/base.bend',*map(Path,tools.values())]:pins[str(p)]=sha(p)
env={k:os.environ[k] for k in ('HOME','PATH','LANG','LC_ALL','TZ') if k in os.environ};env['BEND_NO_TELEMETRY']='1'
generated=out/'consumer.js'
assert not generated.exists()
commands=[('source',[tools['taskset'],'-c','5',tools['bend'],frozen['entry'],'--check-only'],5),('emit',[tools['taskset'],'-c','5',tools['bend'],frozen['entry'],'-o',str(generated)],30),('consumer',[tools['taskset'],'-c','5',tools['node'],str(generated)],5)]
record={'scope':'direct development; NOT complete tool/resolver/frozen delivery qualification','sourceStage':frozen,'mutation':mutation,'pins':pins.copy(),'environment':env,'plannedCommands':commands,'commands':[]}
(out/'plan.json').write_text(json.dumps(record,indent=2)+'\n')
def guard():
 assert {p:sha(p) for p in pins}==pins
 assert stage.consumed(entry)==(sources,edges)
 assert stage.inventory(out/'sources')==frozen['inventory']
 assert stage.consumed(Path(frozen['entry']))==(staged_sources,staged_edges)
def compare(a,b):
 assert type(a) is type(b)
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  for k in a:compare(a[k],b[k])
 elif isinstance(a,list):
  assert len(a)==len(b)
  for x,y in zip(a,b):compare(x,y)
 else:assert a==b,(a,b)
with ReceiptBoundary(record,out/'receipt.json',[('source/oracle/tool binary pins',guard)]):
 for label,argv,cap in commands:
  guard()
  with GuardBoundary([('source/oracle/tool binary pins',guard)]):
   with open('/tmp/bendvy-parity-heavy.lock','a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    try:
     guard()
     if label=='emit':assert not generated.exists()
     result=task_runner.execute_result(argv,cap,env,str(here),'split')
    finally:fcntl.flock(lock,fcntl.LOCK_UN)
   row={'label':label,'argv':argv,'capSeconds':cap}
   for k,v in result.items():
    if isinstance(v,bytes):
     path=out/(label+'.'+k);path.write_bytes(v);row[k]={'path':str(path),'sha256':sha(path),'bytes':len(v)}
    else:row[k]=v
   record['commands'].append(row)
   assert result['exit']==0 and result['failure'] is None,row
   if label=='emit':
    assert generated.is_file();pins[str(generated)]=sha(generated);record['generatedSHA256']=sha(generated)
   elif label=='source':
    assert result['stdout']==b'ALL PROOFS CHECK\nUse --verdict for mathematical validity.\n' and result['stderr']==b''
   else:
    assert result['stderr']==b''
    compare(json.loads(result['stdout']),json.loads(oracle.read_bytes()))
    record['completeOracleSHA256']=sha(oracle)
    try:compare(json.loads(result['stdout']),json.loads((here/'oracle-review-v1/expected.json').read_bytes()))
    except AssertionError:record['positiveOracleRejected']=True
    else:raise AssertionError('Mutant escaped full positive oracle')
 record['status']='REACHED_PRODUCT_MUTANT_DETECTED'
print(record['status'])
