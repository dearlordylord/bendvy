import fcntl,hashlib,importlib.util,json,os,shutil,sys
from pathlib import Path
root=Path('/workspace/formal-proofs/bendvy');here=Path('/workspace/formal-proofs/bendvy-worktrees/parity-58-snapshot-research/experiments/public-snapshot/persistence-gate-v1/basic-world-v1/public-adoption-v1')
sys.path.insert(0,str(root/'scripts'));import task_runner
from evidence_boundary import ReceiptBoundary,GuardBoundary
spec=importlib.util.spec_from_file_location('stage',here.parent/'generated-js-stage.py');stage=importlib.util.module_from_spec(spec);spec.loader.exec_module(stage)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=here/'development/source-controls-v1';out.mkdir(exist_ok=False)
controls=[('negative-plain.bend',b'True{}',b'False{}'),('negative-plain-resource.bend',b'True{}',b'False{}'),('negative-cross-schema.bend',b'F.Workshop',b'F.Garden'),('negative-owner-duplication.bend',b'world',b'consumed more than once')]
closures={name:stage.consumed(here/name) for name,*_ in controls}
tools={name:str(Path(shutil.which(name)).resolve()) for name in ('bend','taskset')}
pins={str(p):h for sources,_ in closures.values() for p,h in sources.items()}
for p in [Path(__file__),Path(stage.__file__),Path(task_runner.__file__),root/'scripts/evidence_boundary.py',Path.home()/'.bend/bend2/base.bend',Path(sys.executable).resolve(),*map(Path,tools.values())]:pins[str(p)]=sha(p)
env={k:os.environ[k] for k in ('HOME','PATH','LANG','LC_ALL','TZ') if k in os.environ};env['BEND_NO_TELEMETRY']='1'
commands=[(name,[tools['taskset'],'-c','5',tools['bend'],str(here/name),'--check-only'],5) for name,*_ in controls]
record={'scope':'direct development source controls, not proof/delivery/tool qualification','pins':pins,'environment':env,'plannedCommands':commands,'sourceClosures':{name:{'pins':{str(p):h for p,h in sources.items()},'edges':edges} for name,(sources,edges) in closures.items()},'commands':[]}
def guard():
 assert {p:sha(p) for p in pins}==pins
 assert all(stage.consumed(here/name)==closure for name,closure in closures.items())
(out/'plan.json').write_text(json.dumps(record,indent=2)+'\n')
with ReceiptBoundary(record,out/'receipt.json',[('exact source/tool/oracle-independent control inputs',guard)]):
 for (name,argv,cap),(_,first,second) in zip(commands,controls):
  guard()
  with GuardBoundary([('exact source/tool inputs',guard)]):
   with open('/tmp/bendvy-parity-heavy.lock','a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    try:guard();result=task_runner.execute_result(argv,cap,env,str(here),'split')
    finally:fcntl.flock(lock,fcntl.LOCK_UN)
   row={'label':name,'argv':argv,'capSeconds':cap}
   for k,v in result.items():
    if isinstance(v,bytes):
     p=out/(name+'.'+k);p.write_bytes(v);row[k]={'path':str(p),'sha256':sha(p),'bytes':len(v)}
    else:row[k]=v
   record['commands'].append(row)
   assert result['exit']==1 and result['failure'] is None and result['stdout']==b''
   assert result['stderr'].count(b'Error:')==1 and first in result['stderr'] and second in result['stderr']
 record['status']='SOURCE_CONTROLS_PASS'
print(record['status'])
