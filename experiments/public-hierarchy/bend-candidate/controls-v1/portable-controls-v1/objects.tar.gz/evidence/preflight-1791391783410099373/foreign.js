function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  const _x_0 = ($run$1261$());
  const _x_1 = ($run$1260$());
  const _x_2 = ("\nHierarchyBeta\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return (_x_4) => $IO$print$(("HierarchyAlpha\n" + _x_3), _x_4);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $run$1260$() {
  return $created$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), 77)));
}

function $run$1261$() {
  return $created$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), 77)));
}

function $created$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _local_0 = _result_0["world"];
    return $first_spawned$1260$(($$$$047full$045v1$047application$058spawn$1260$(8, {$: "Tuple", "fst": _local_0, "snd": {$: "Nil"}})), _factory_0);
  } else {
    return "LOCAL_CREATE_FAILED";
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $created$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/world.Created") {
    const _factory_0 = _result_0["factory"];
    const _local_0 = _result_0["world"];
    return $first_spawned$1261$(($$$$047full$045v1$047application$058spawn$1261$(8, {$: "Tuple", "fst": _local_0, "snd": {$: "Nil"}})), _factory_0);
  } else {
    return "LOCAL_CREATE_FAILED";
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $first_spawned$1260$(_result_0, _factory_0) {
  const _local_0 = _result_0["fst"];
  const _handles_0 = _result_0["snd"];
  return $first_handles$1260$(_local_0, ($List$reverse$(_handles_0)), _factory_0);
}

function $$$$047full$045v1$047application$058spawn$1260$($0, $1) {
  for (;;) {
    {
      const _n_0 = $0;
      const _state_0 = $1;
      if (_n_0 === 0) {
        return _state_0;
      } else {
        const _rest_0 = (_n_0 - 1);
        const _world_0 = _state_0["fst"];
        const _handles_0 = _state_0["snd"];
        $0 = _rest_0;
        $1 = ($$$$047full$045v1$047application$058reserved$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _handles_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047full$045v1$047application$058empty$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $first_spawned$1261$(_result_0, _factory_0) {
  const _local_0 = _result_0["fst"];
  const _handles_0 = _result_0["snd"];
  return $first_handles$1261$(_local_0, ($List$reverse$(_handles_0)), _factory_0);
}

function $$$$047full$045v1$047application$058spawn$1261$($0, $1) {
  for (;;) {
    {
      const _n_0 = $0;
      const _state_0 = $1;
      if (_n_0 === 0) {
        return _state_0;
      } else {
        const _rest_0 = (_n_0 - 1);
        const _world_0 = _state_0["fst"];
        const _handles_0 = _state_0["snd"];
        $0 = _rest_0;
        $1 = ($$$$047full$045v1$047application$058reserved$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)), _handles_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047full$045v1$047application$058empty$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $first_handles$1260$(_local_0, _handles_0, _factory_0) {
  if (_handles_0.$ === "Con") {
    const _h1_0 = _handles_0["head"];
    const _t_0 = _handles_0["tail"];
    if (_t_0.$ === "Con") {
      const _h2_0 = _t_0["head"];
      return $second$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, 77)), _local_0, _h1_0, _h2_0);
    } else {
      return "LOCAL_RESERVATION_FAILED";
    }
  } else {
    return "LOCAL_RESERVATION_FAILED";
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047full$045v1$047application$058reserved$1260$(_result_0, _handles_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047full$045v1$047application$058prepared$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1265$(run_clo((_x_0) => {
  return $$$$047full$045v1$047application$058populate$1260$(_x_0, _handle_0);
}), _world_0)), _handle_0, _handles_0);
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047full$045v1$047application$058empty$1260$(__0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1260$({$: "../full-v1/owned-world.Components", "column": {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(3)), "stamps": {$: "Nil"}}});
}

function $first_handles$1261$(_local_0, _handles_0, _factory_0) {
  if (_handles_0.$ === "Con") {
    const _h1_0 = _handles_0["head"];
    const _t_0 = _handles_0["tail"];
    if (_t_0.$ === "Con") {
      const _h2_0 = _t_0["head"];
      return $second$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, 77)), _local_0, _h1_0, _h2_0);
    } else {
      return "LOCAL_RESERVATION_FAILED";
    }
  } else {
    return "LOCAL_RESERVATION_FAILED";
  }
}

function $$$$047full$045v1$047application$058reserved$1261$(_result_0, _handles_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047full$045v1$047application$058prepared$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12613$(run_clo((_x_0) => {
  return $$$$047full$045v1$047application$058populate$1261$(_x_0, _handle_0);
}), _world_0)), _handle_0, _handles_0);
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047full$045v1$047application$058empty$1261$(__0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1261$({$: "../full-v1/owned-world.Components", "column": {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(3)), "stamps": {$: "Nil"}}});
}

function $second$1260$(_result_0, _local_0, _h1_0, _h2_0) {
  if (_result_0.$ === "../../../../src/ecs/world.Created") {
    const _peer_0 = _result_0["world"];
    return $paired$1260$(($$$$047full$045v1$047application$058spawn$1260$(8, {$: "Tuple", "fst": _peer_0, "snd": {$: "Nil"}})), _local_0, _h1_0, _h2_0);
  } else {
    return "PEER_CREATE_FAILED";
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047full$045v1$047application$058prepared$1260$(_result_0, _handle_0, _handles_0) {
  const _world_0 = _result_0["fst"];
  return $$$$047full$045v1$047application$058activated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _handles_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1265$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047full$045v1$047application$058populate$1260$(_store_0, _handle_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _graph_0 = _store_0["graph"];
  const _id_0 = _handle_0["id"];
  return $$$$047full$045v1$047application$058populated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, {$: "Some", "value": {$: "../full-v1/owned-world.Payload", "cells": array_node([_id_0], [(Math.imul(_id_0, 10) >>> 0)]), "tag": _id_0}})), _graph_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1260$(_components_0) {
  return {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $second$1261$(_result_0, _local_0, _h1_0, _h2_0) {
  if (_result_0.$ === "../../../../src/ecs/world.Created") {
    const _peer_0 = _result_0["world"];
    return $paired$1261$(($$$$047full$045v1$047application$058spawn$1261$(8, {$: "Tuple", "fst": _peer_0, "snd": {$: "Nil"}})), _local_0, _h1_0, _h2_0);
  } else {
    return "PEER_CREATE_FAILED";
  }
}

function $$$$047full$045v1$047application$058prepared$1261$(_result_0, _handle_0, _handles_0) {
  const _world_0 = _result_0["fst"];
  return $$$$047full$045v1$047application$058activated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _handles_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12613$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12613$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047full$045v1$047application$058populate$1261$(_store_0, _handle_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _graph_0 = _store_0["graph"];
  const _id_0 = _handle_0["id"];
  return $$$$047full$045v1$047application$058populated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, {$: "Some", "value": {$: "../full-v1/owned-world.Payload", "cells": array_node([_id_0], [(Math.imul(_id_0, 10) >>> 0)]), "tag": _id_0}})), _graph_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1261$(_components_0) {
  return {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $paired$1260$(_result_0, _local_0, _h1_0, _h2_0) {
  const _peer_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Con") {
    const _t_1 = _t_0["tail"];
    if (_t_1.$ === "Con") {
      const _t_2 = _t_1["tail"];
      if (_t_2.$ === "Con") {
        const _t_3 = _t_2["tail"];
        if (_t_3.$ === "Con") {
          const _t_4 = _t_3["tail"];
          if (_t_4.$ === "Con") {
            const _t_5 = _t_4["tail"];
            if (_t_5.$ === "Con") {
              const _t_6 = _t_5["tail"];
              if (_t_6.$ === "Con") {
                const _t_7 = _t_6["tail"];
                if (_t_7.$ === "Con") {
                  const _ph_0 = _t_7["head"];
                  const _t_8 = _t_7["tail"];
                  if (_t_8.$ === "Nil") {
                    return $local_seen$1260$(($observe$1260$(_local_0)), _peer_0, _h1_0, _h2_0, _ph_0);
                  } else {
                    return "PEER_RESERVATION_FAILED";
                  }
                } else {
                  return "PEER_RESERVATION_FAILED";
                }
              } else {
                return "PEER_RESERVATION_FAILED";
              }
            } else {
              return "PEER_RESERVATION_FAILED";
            }
          } else {
            return "PEER_RESERVATION_FAILED";
          }
        } else {
          return "PEER_RESERVATION_FAILED";
        }
      } else {
        return "PEER_RESERVATION_FAILED";
      }
    } else {
      return "PEER_RESERVATION_FAILED";
    }
  } else {
    return "PEER_RESERVATION_FAILED";
  }
}

function $$$$047full$045v1$047application$058activated$1260$(_result_0, _handle_0, _handles_0) {
  const _world_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": _handle_0, "tail": _handles_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047full$045v1$047application$058populated$1260$(_outcome_0, _graph_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "../full-v1/owned-world.Components", "column": _column_0}, "graph": _graph_0}, "snd": {$: "Unit"}};
  } else {
    const _column_1 = _outcome_0["column"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "../full-v1/owned-world.Components", "column": _column_1}, "graph": _graph_0}, "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $paired$1261$(_result_0, _local_0, _h1_0, _h2_0) {
  const _peer_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Con") {
    const _t_1 = _t_0["tail"];
    if (_t_1.$ === "Con") {
      const _t_2 = _t_1["tail"];
      if (_t_2.$ === "Con") {
        const _t_3 = _t_2["tail"];
        if (_t_3.$ === "Con") {
          const _t_4 = _t_3["tail"];
          if (_t_4.$ === "Con") {
            const _t_5 = _t_4["tail"];
            if (_t_5.$ === "Con") {
              const _t_6 = _t_5["tail"];
              if (_t_6.$ === "Con") {
                const _t_7 = _t_6["tail"];
                if (_t_7.$ === "Con") {
                  const _ph_0 = _t_7["head"];
                  const _t_8 = _t_7["tail"];
                  if (_t_8.$ === "Nil") {
                    return $local_seen$1261$(($observe$1261$(_local_0)), _peer_0, _h1_0, _h2_0, _ph_0);
                  } else {
                    return "PEER_RESERVATION_FAILED";
                  }
                } else {
                  return "PEER_RESERVATION_FAILED";
                }
              } else {
                return "PEER_RESERVATION_FAILED";
              }
            } else {
              return "PEER_RESERVATION_FAILED";
            }
          } else {
            return "PEER_RESERVATION_FAILED";
          }
        } else {
          return "PEER_RESERVATION_FAILED";
        }
      } else {
        return "PEER_RESERVATION_FAILED";
      }
    } else {
      return "PEER_RESERVATION_FAILED";
    }
  } else {
    return "PEER_RESERVATION_FAILED";
  }
}

function $$$$047full$045v1$047application$058activated$1261$(_result_0, _handle_0, _handles_0) {
  const _world_0 = _result_0["fst"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": _handle_0, "tail": _handles_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12613$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047full$045v1$047application$058populated$1261$(_outcome_0, _graph_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "../full-v1/owned-world.Components", "column": _column_0}, "graph": _graph_0}, "snd": {$: "Unit"}};
  } else {
    const _column_1 = _outcome_0["column"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "../full-v1/owned-world.Components", "column": _column_1}, "graph": _graph_0}, "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $local_seen$1260$(_result_0, _peer_0, _h1_0, _h2_0, _ph_0) {
  const _local_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $peer_seen$1260$(($observe$1260$(_peer_0)), _local_0, _before_0, _h1_0, _h2_0, _ph_0);
}

function $observe$1260$(_world_0) {
  return $graph_seen$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $$$$047full$045v1$047cleanup$045client$058edge_observer$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $local_seen$1261$(_result_0, _peer_0, _h1_0, _h2_0, _ph_0) {
  const _local_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $peer_seen$1261$(($observe$1261$(_peer_0)), _local_0, _before_0, _h1_0, _h2_0, _ph_0);
}

function $observe$1261$(_world_0) {
  return $graph_seen$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1268$(run_clo((_x_0) => {
  return $$$$047full$045v1$047cleanup$045client$058edge_observer$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $peer_seen$1260$(_result_0, _local_0, _before_0, _h1_0, _h2_0, _ph_0) {
  const _peer_0 = _result_0["fst"];
  const _peerBefore_0 = _result_0["snd"];
  return $looked$1260$(($lookup_seen$1260$(run_loop($$$$047full$045v1$047provider$058grant$1260$(_ph_0, _local_0)))), _peer_0, _before_0, _peerBefore_0, _h1_0, _h2_0, _ph_0);
}

function $graph_seen$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _graph_0 = _result_0["snd"];
  return $graph_done$1260$(($$$$047full$045v1$047owned$045world$058observe_complete$1260$(_world_0)), _graph_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047full$045v1$047cleanup$045client$058edge_observer$1260$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": ($$$$047full$045v1$047cleanup$045client$058full_graph$1260$(_graph_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $peer_seen$1261$(_result_0, _local_0, _before_0, _h1_0, _h2_0, _ph_0) {
  const _peer_0 = _result_0["fst"];
  const _peerBefore_0 = _result_0["snd"];
  return $looked$1261$(($lookup_seen$1261$(run_loop($$$$047full$045v1$047provider$058grant$1261$(_ph_0, _local_0)))), _peer_0, _before_0, _peerBefore_0, _h1_0, _h2_0, _ph_0);
}

function $graph_seen$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _graph_0 = _result_0["snd"];
  return $graph_done$1261$(($$$$047full$045v1$047owned$045world$058observe_complete$1261$(_world_0)), _graph_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1268$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047full$045v1$047cleanup$045client$058edge_observer$1261$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": ($$$$047full$045v1$047cleanup$045client$058full_graph$1261$(_graph_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $looked$1260$(_result_0, _peer_0, _before_0, _peerBefore_0, _h1_0, _h2_0, _ph_0) {
  const _world_0 = _result_0["fst"];
  const _lookup_0 = _result_0["snd"];
  return $attempted$1260$(($attempts$1260$(($$$$047full$045v1$047application$058queue$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), _h2_0, _h1_0)), _h1_0, _h2_0, _ph_0)), _peer_0, _before_0, _peerBefore_0, _lookup_0);
}

function $lookup_seen$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _world_0, "snd": "lookup=MissingEntity"};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": "lookup=UnexpectedFrame"};
  }
}

function $$$$047full$045v1$047provider$058grant$1260$(_target_0, _world_0) {
  return $$$$047full$045v1$047application$058read_body$1260$({$: "../full-v1/provider.Read", "lookup": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047full$045v1$047provider$058lookup$1260$(_x_0, _x_1);
});
})}}, _target_0, _world_0);
}

function $graph_done$1260$(_result_0, _graph_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("|" + _graph_0);
  return $complete_live$1260$({$: "Tuple", "fst": _world_0, "snd": (_text_0 + _x_0)});
}

function $$$$047full$045v1$047owned$045world$058observe_complete$1260$(_world_0) {
  return $$$$047full$045v1$047owned$045world$058pending_join$1260$(($$$$047full$045v1$047owned$045world$058metadata$1260$(($$$$047full$045v1$047owned$045world$058observe_complete_join$1260$(($$$$047full$045v1$047owned$045world$058observe$1260$(_world_0)))))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047full$045v1$047cleanup$045client$058full_graph$1260$(_graph_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _x_0 = ($$$$047full$045v1$047cleanup$045client$058full_inverses$1260$(_inverses_0));
  const _x_1 = ($$$$047full$045v1$047cleanup$045client$058full_edges$1260$(_edges_0));
  const _x_2 = ("|graph-inverses=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("graph-edges=" + _x_3);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $looked$1261$(_result_0, _peer_0, _before_0, _peerBefore_0, _h1_0, _h2_0, _ph_0) {
  const _world_0 = _result_0["fst"];
  const _lookup_0 = _result_0["snd"];
  return $attempted$1261$(($attempts$1261$(($$$$047full$045v1$047application$058queue$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), _h2_0, _h1_0)), _h1_0, _h2_0, _ph_0)), _peer_0, _before_0, _peerBefore_0, _lookup_0);
}

function $lookup_seen$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": _world_0, "snd": "lookup=MissingEntity"};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": "lookup=UnexpectedFrame"};
  }
}

function $$$$047full$045v1$047provider$058grant$1261$(_target_0, _world_0) {
  return $$$$047full$045v1$047application$058read_body$1261$({$: "../full-v1/provider.Read", "lookup": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047full$045v1$047provider$058lookup$1261$(_x_0, _x_1);
});
})}}, _target_0, _world_0);
}

function $graph_done$1261$(_result_0, _graph_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("|" + _graph_0);
  return $complete_live$1261$({$: "Tuple", "fst": _world_0, "snd": (_text_0 + _x_0)});
}

function $$$$047full$045v1$047owned$045world$058observe_complete$1261$(_world_0) {
  return $$$$047full$045v1$047owned$045world$058pending_join$1261$(($$$$047full$045v1$047owned$045world$058metadata$1261$(($$$$047full$045v1$047owned$045world$058observe_complete_join$1261$(($$$$047full$045v1$047owned$045world$058observe$1261$(_world_0)))))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047full$045v1$047cleanup$045client$058full_graph$1261$(_graph_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _x_0 = ($$$$047full$045v1$047cleanup$045client$058full_inverses$1261$(_inverses_0));
  const _x_1 = ($$$$047full$045v1$047cleanup$045client$058full_edges$1261$(_edges_0));
  const _x_2 = ("|graph-inverses=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("graph-edges=" + _x_3);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $attempted$1260$(_result_0, _peer_0, _before_0, _peerBefore_0, _lookup_0) {
  const _tx_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("|" + _text_0);
  return $after_queued$1260$(($observe$1260$(($$$$047full$045v1$047owned$045world$058commit$1260$(_tx_0, {$: "../../../../src/ecs/transaction.Success"})))), _peer_0, _before_0, _peerBefore_0, (_lookup_0 + _x_0));
}

function $attempts$1260$(_tx_0, _h1_0, _h2_0, _peer_0) {
  return $attempt$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1260$({$: "../../../../src/ecs/relation-providers.Targets", "source": _h2_0, "target": _peer_0}, _tx_0)), "foreign-target", run_clo((_x_0) => {
  return $attempt$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1260$({$: "../../../../src/ecs/relation-providers.Targets", "source": _peer_0, "target": _h1_0}, _x_0)), "foreign-source", run_clo((_x_1) => {
  return $attempt$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058invoke$1260$({$: "../../../../src/ecs/relation-reorder.Args", "parent": _h1_0, "children": {$: "Con", "head": _peer_0, "tail": {$: "Nil"}}}, _x_1)), "foreign-child", run_clo((_x_2) => {
  return $attempt$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058invoke$1260$({$: "../../../../src/ecs/relation-reorder.Args", "parent": _peer_0, "children": {$: "Con", "head": _h2_0, "tail": {$: "Nil"}}}, _x_2)), "foreign-parent", run_clo((_x_3) => {
  return $attempt$1260$(run_loop($$$$047full$045v1$047cleanup$045client$058invoked$1260$(_x_3, _peer_0)), "foreign-despawn", run_clo((_x_4) => {
  return $done$1260$(_x_4);
}));
}));
}));
}));
}));
}

function $$$$047full$045v1$047application$058queue$1260$(_tx_0, _source_0, _target_0) {
  return $$$$047full$045v1$047owned$045world$058queue_done$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1260$({$: "../../../../src/ecs/relation-providers.Targets", "source": _source_0, "target": _target_0}, _tx_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047full$045v1$047application$058read_body$1260$(_caps_0, _target_0, _owner_0) {
  return $$$$047full$045v1$047provider$058read$(_caps_0, _owner_0, _target_0);
}

function $$$$047full$045v1$047provider$058lookup$1260$(_world_0, _target_0) {
  const _ns_0 = _target_0["namespace"];
  const _id_0 = _target_0["id"];
  return $$$$047full$045v1$047provider$058checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0});
}

function $complete_live$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _text_0 = _result_0["snd"];
  return $live_return$1260$(($live_cells$(16, _live_0, 0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _text_0);
}

function $$$$047full$045v1$047owned$045world$058pending_join$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058pending_observed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0)), _value_0);
}

function $$$$047full$045v1$047owned$045world$058metadata$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _cap_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSys_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = ($U32$show$(_nextSys_0));
  const _x_2 = ("," + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_resource_0));
  const _x_5 = ("," + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$((_depth_0 >>> 0)));
  const _x_8 = ("," + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_cap_0));
  const _x_11 = ("," + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($U32$show$(_high_0));
  const _x_14 = ("," + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($U32$show$(_next_0));
  const _x_17 = ("," + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($U32$show$(_ns_0));
  const _x_20 = ("," + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ("|meta=" + _x_21);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSys_0, "clock": _clock_0}, "snd": (_value_0 + _x_22)};
}

function $$$$047full$045v1$047owned$045world$058observe_complete_join$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _owners_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058observe_notices$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _owners_0);
}

function $$$$047full$045v1$047owned$045world$058observe$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $$$$047full$045v1$047owned$045world$058observe_store$1260$(_x_0);
}), _world_0);
}

function $$$$047full$045v1$047cleanup$045client$058full_edges$1260$(_edges_0) {
  if (_edges_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _edges_0["head"];
    const _d_0 = _t_0["relation"];
    const _source_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047full$045v1$047cleanup$045client$058full_edges$1260$(_rest_0));
    const _x_1 = ($U32$show$(_target_0));
    const _x_2 = (";" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_source_0));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($$$$047full$045v1$047cleanup$045client$058show_descriptor$1260$(_d_0));
    const _x_8 = (":" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $$$$047full$045v1$047cleanup$045client$058full_inverses$1260$(_inverses_0) {
  if (_inverses_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _inverses_0["head"];
    const _d_0 = _t_0["relation"];
    const _target_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _inverses_0["tail"];
    const _x_0 = ($$$$047full$045v1$047cleanup$045client$058full_inverses$1260$(_rest_0));
    const _x_1 = ($$$$047full$045v1$047owned$045world$058show_ids$(_sources_0));
    const _x_2 = ("];" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_target_0));
    const _x_5 = (":[" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($$$$047full$045v1$047cleanup$045client$058show_descriptor$1260$(_d_0));
    const _x_8 = (":" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../src/ecs/column.Indexed", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $attempted$1261$(_result_0, _peer_0, _before_0, _peerBefore_0, _lookup_0) {
  const _tx_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("|" + _text_0);
  return $after_queued$1261$(($observe$1261$(($$$$047full$045v1$047owned$045world$058commit$1261$(_tx_0, {$: "../../../../src/ecs/transaction.Success"})))), _peer_0, _before_0, _peerBefore_0, (_lookup_0 + _x_0));
}

function $attempts$1261$(_tx_0, _h1_0, _h2_0, _peer_0) {
  return $attempt$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1262$({$: "../../../../src/ecs/relation-providers.Targets", "source": _h2_0, "target": _peer_0}, _tx_0)), "foreign-target", run_clo((_x_0) => {
  return $attempt$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1262$({$: "../../../../src/ecs/relation-providers.Targets", "source": _peer_0, "target": _h1_0}, _x_0)), "foreign-source", run_clo((_x_1) => {
  return $attempt$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058invoke$1261$({$: "../../../../src/ecs/relation-reorder.Args", "parent": _h1_0, "children": {$: "Con", "head": _peer_0, "tail": {$: "Nil"}}}, _x_1)), "foreign-child", run_clo((_x_2) => {
  return $attempt$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058invoke$1261$({$: "../../../../src/ecs/relation-reorder.Args", "parent": _peer_0, "children": {$: "Con", "head": _h2_0, "tail": {$: "Nil"}}}, _x_2)), "foreign-parent", run_clo((_x_3) => {
  return $attempt$1261$(run_loop($$$$047full$045v1$047cleanup$045client$058invoked$1261$(_x_3, _peer_0)), "foreign-despawn", run_clo((_x_4) => {
  return $done$1261$(_x_4);
}));
}));
}));
}));
}));
}

function $$$$047full$045v1$047application$058queue$1262$(_tx_0, _source_0, _target_0) {
  return $$$$047full$045v1$047owned$045world$058queue_done$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1262$({$: "../../../../src/ecs/relation-providers.Targets", "source": _source_0, "target": _target_0}, _tx_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047full$045v1$047application$058read_body$1261$(_caps_0, _target_0, _owner_0) {
  return $$$$047full$045v1$047provider$058read$(_caps_0, _owner_0, _target_0);
}

function $$$$047full$045v1$047provider$058lookup$1261$(_world_0, _target_0) {
  const _ns_0 = _target_0["namespace"];
  const _id_0 = _target_0["id"];
  return $$$$047full$045v1$047provider$058checked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0});
}

function $complete_live$1261$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _text_0 = _result_0["snd"];
  return $live_return$1261$(($live_cells$(16, _live_0, 0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _text_0);
}

function $$$$047full$045v1$047owned$045world$058pending_join$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058pending_observed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0)), _value_0);
}

function $$$$047full$045v1$047owned$045world$058metadata$1261$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _cap_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSys_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = ($U32$show$(_nextSys_0));
  const _x_2 = ("," + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_resource_0));
  const _x_5 = ("," + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$((_depth_0 >>> 0)));
  const _x_8 = ("," + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_cap_0));
  const _x_11 = ("," + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($U32$show$(_high_0));
  const _x_14 = ("," + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($U32$show$(_next_0));
  const _x_17 = ("," + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($U32$show$(_ns_0));
  const _x_20 = ("," + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ("|meta=" + _x_21);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSys_0, "clock": _clock_0}, "snd": (_value_0 + _x_22)};
}

function $$$$047full$045v1$047owned$045world$058observe_complete_join$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _owners_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058observe_notices$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _owners_0);
}

function $$$$047full$045v1$047owned$045world$058observe$1261$(_world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1268$(run_clo((_x_0) => {
  return $$$$047full$045v1$047owned$045world$058observe_store$1261$(_x_0);
}), _world_0);
}

function $$$$047full$045v1$047cleanup$045client$058full_edges$1261$(_edges_0) {
  if (_edges_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _edges_0["head"];
    const _d_0 = _t_0["relation"];
    const _source_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047full$045v1$047cleanup$045client$058full_edges$1261$(_rest_0));
    const _x_1 = ($U32$show$(_target_0));
    const _x_2 = (";" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_source_0));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($$$$047full$045v1$047cleanup$045client$058show_descriptor$1261$(_d_0));
    const _x_8 = (":" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $$$$047full$045v1$047cleanup$045client$058full_inverses$1261$(_inverses_0) {
  if (_inverses_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _inverses_0["head"];
    const _d_0 = _t_0["relation"];
    const _target_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _inverses_0["tail"];
    const _x_0 = ($$$$047full$045v1$047cleanup$045client$058full_inverses$1261$(_rest_0));
    const _x_1 = ($$$$047full$045v1$047owned$045world$058show_ids$(_sources_0));
    const _x_2 = ("];" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_target_0));
    const _x_5 = (":[" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($$$$047full$045v1$047cleanup$045client$058show_descriptor$1261$(_d_0));
    const _x_8 = (":" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../../src/ecs/column.Indexed", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $after_queued$1260$(_result_0, _peer_0, _before_0, _peerBefore_0, _statuses_0) {
  const _world_0 = _result_0["fst"];
  const _queued_0 = _result_0["snd"];
  const _x_0 = ("\n" + _queued_0);
  return $local_after$1260$(($observe$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)))), _peer_0, _before_0, _peerBefore_0, (_statuses_0 + _x_0));
}

function $$$$047full$045v1$047owned$045world$058commit$1260$(_tx_0, _outcome_0) {
  return $$$$047full$045v1$047owned$045world$058finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0)));
}

function $attempt$1260$(_result_0, _label_0, _next_0) {
  const _tx_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($status$(_value_0));
  const _x_1 = (_x_0 + "|");
  const _x_2 = ("=" + _x_1);
  return $attempt_text$1260$(_next_0(_tx_0), (_label_0 + _x_2));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1260$(_args_0, _tx_0) {
  return $$$$047full$045v1$047application$058write_body$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058provide_write$1260$()), _args_0, _tx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058invoke$1260$(_args_0, _tx_0) {
  return $$$$047full$045v1$047application$058reorder_body$1260$({$: "../../../../src/ecs/relation-reorder.Writable", "reorder": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058queue$1260$(_x_0, _x_1);
});
})}}, _args_0, _tx_0);
}

function $$$$047full$045v1$047cleanup$045client$058invoked$1260$(_tx_0, _handle_0) {
  return $$$$047full$045v1$047cleanup$045client$058body$1260$({$: "../full-v1/cleanup-client.Writable", "despawn": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047full$045v1$047cleanup$045client$058queue$1260$(_x_0, _x_1);
});
})}}, _handle_0, _tx_0);
}

function $done$1260$(_tx_0) {
  return {$: "Tuple", "fst": _tx_0, "snd": ""};
}

function $$$$047full$045v1$047owned$045world$058queue_done$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  return _tx_0;
}

function $$$$047full$045v1$047provider$058read$(_caps_0, _owner_0, _target_0) {
  const _t_0 = _caps_0["lookup"];
  const _get_0 = _t_0["run"];
  return run_tail(_get_0(_owner_0), _target_0);
}

function $$$$047full$045v1$047provider$058checked$1260$(_observed_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "None"}};
  } else {
    return $$$$047full$045v1$047provider$058present$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $$$$047full$045v1$047provider$058store_snapshot$1260$(_x_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058descriptor$1260$(($$$$047full$045v1$047application$058hierarchy$1260$()))), _target_0);
}), _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $live_return$1260$(_result_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _text_0) {
  const _live_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  const _x_0 = ("|physical-live=" + _values_0);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": (_text_0 + _x_0)};
}

function $live_cells$(_n_0, _array_0, _index_0) {
  if (_n_0 === 0) {
    return {$: "Tuple", "fst": _array_0, "snd": ""};
  } else {
    const _rest_0 = (_n_0 - 1);
    return $live_got$({$: "Tuple", fst: _array_0, snd: _array_0[_index_0 % _array_0.length]}, run_clo((_x_0) => {
  return $live_cells$(_rest_0, _x_0, ((_index_0 + 1) >>> 0));
}));
  }
}

function $$$$047full$045v1$047owned$045world$058pending_observed$1260$(_result_0, _value_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_count_0));
  const _x_1 = ("|pending=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_value_0 + _x_1)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047full$045v1$047owned$045world$058observe_notices$1260$(_result_0, _owners_0) {
  const _world_0 = _result_0["fst"];
  const _notices_0 = _result_0["snd"];
  const _x_0 = ($$$$047full$045v1$047owned$045world$058show_notices$1260$(_notices_0));
  const _x_1 = ("|events=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_owners_0 + _x_1)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047full$045v1$047owned$045world$058observe_store$1260$(_store_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _graph_0 = _store_0["graph"];
  return $$$$047full$045v1$047owned$045world$058observe_store_done$1260$(($$$$047full$045v1$047owned$045world$058observe_column$1260$(8, _column_0, 1)), _graph_0);
}

function $$$$047full$045v1$047cleanup$045client$058show_descriptor$1260$(_d_0) {
  const _key_0 = _d_0["key"];
  const _name_0 = _d_0["name"];
  const _inverse_0 = _d_0["inverseName"];
  const _kind_0 = _d_0["kind"];
  const _x_0 = ($$$$047full$045v1$047owned$045world$058show_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverse_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $$$$047full$045v1$047owned$045world$058show_ids$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = ($$$$047full$045v1$047owned$045world$058show_ids$(_rest_0));
    const _x_2 = ($U32$show$(_x_0));
    const _x_3 = ("," + _x_1);
    return (_x_2 + _x_3);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $after_queued$1261$(_result_0, _peer_0, _before_0, _peerBefore_0, _statuses_0) {
  const _world_0 = _result_0["fst"];
  const _queued_0 = _result_0["snd"];
  const _x_0 = ("\n" + _queued_0);
  return $local_after$1261$(($observe$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0)))), _peer_0, _before_0, _peerBefore_0, (_statuses_0 + _x_0));
}

function $$$$047full$045v1$047owned$045world$058commit$1261$(_tx_0, _outcome_0) {
  return $$$$047full$045v1$047owned$045world$058finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0)));
}

function $attempt$1261$(_result_0, _label_0, _next_0) {
  const _tx_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($status$(_value_0));
  const _x_1 = (_x_0 + "|");
  const _x_2 = ("=" + _x_1);
  return $attempt_text$1261$(_next_0(_tx_0), (_label_0 + _x_2));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1262$(_args_0, _tx_0) {
  return $$$$047full$045v1$047application$058write_body$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058provide_write$1262$()), _args_0, _tx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058invoke$1261$(_args_0, _tx_0) {
  return $$$$047full$045v1$047application$058reorder_body$1261$({$: "../../../../src/ecs/relation-reorder.Writable", "reorder": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058queue$1261$(_x_0, _x_1);
});
})}}, _args_0, _tx_0);
}

function $$$$047full$045v1$047cleanup$045client$058invoked$1261$(_tx_0, _handle_0) {
  return $$$$047full$045v1$047cleanup$045client$058body$1261$({$: "../full-v1/cleanup-client.Writable", "despawn": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047full$045v1$047cleanup$045client$058queue$1261$(_x_0, _x_1);
});
})}}, _handle_0, _tx_0);
}

function $done$1261$(_tx_0) {
  return {$: "Tuple", "fst": _tx_0, "snd": ""};
}

function $$$$047full$045v1$047owned$045world$058queue_done$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  return _tx_0;
}

function $$$$047full$045v1$047provider$058checked$1261$(_observed_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "None"}};
  } else {
    return $$$$047full$045v1$047provider$058present$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12610$(run_clo((_x_0) => {
  return $$$$047full$045v1$047provider$058store_snapshot$1261$(_x_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058descriptor$1261$(($$$$047full$045v1$047application$058hierarchy$1261$()))), _target_0);
}), _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $live_return$1261$(_result_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _text_0) {
  const _live_0 = _result_0["fst"];
  const _values_0 = _result_0["snd"];
  const _x_0 = ("|physical-live=" + _values_0);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": (_text_0 + _x_0)};
}

function $$$$047full$045v1$047owned$045world$058pending_observed$1261$(_result_0, _value_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_count_0));
  const _x_1 = ("|pending=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_value_0 + _x_1)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $$$$047full$045v1$047owned$045world$058observe_notices$1261$(_result_0, _owners_0) {
  const _world_0 = _result_0["fst"];
  const _notices_0 = _result_0["snd"];
  const _x_0 = ($$$$047full$045v1$047owned$045world$058show_notices$1261$(_notices_0));
  const _x_1 = ("|events=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_owners_0 + _x_1)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047full$045v1$047owned$045world$058observe_store$1261$(_store_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _graph_0 = _store_0["graph"];
  return $$$$047full$045v1$047owned$045world$058observe_store_done$1261$(($$$$047full$045v1$047owned$045world$058observe_column$1261$(8, _column_0, 1)), _graph_0);
}

function $$$$047full$045v1$047cleanup$045client$058show_descriptor$1261$(_d_0) {
  const _key_0 = _d_0["key"];
  const _name_0 = _d_0["name"];
  const _inverse_0 = _d_0["inverseName"];
  const _kind_0 = _d_0["kind"];
  const _x_0 = ($$$$047full$045v1$047owned$045world$058show_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverse_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $local_after$1260$(_result_0, _peer_0, _before_0, _peerBefore_0, _statuses_0) {
  const _after_0 = _result_0["snd"];
  return $peer_after$1260$(($observe$1260$(_peer_0)), _before_0, _peerBefore_0, _statuses_0, _after_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047full$045v1$047owned$045world$058finish$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $attempt_text$1260$(_result_0, _head_0) {
  const _tx_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": (_head_0 + _text_0)};
}

function $status$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return "Queued";
  } else {
    return "MissingEntity";
  }
}

function $$$$047full$045v1$047application$058write_body$1260$(_caps_0, _targets_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_live$(_caps_0, _owner_0, _targets_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058provide_write$1260$() {
  return {$: "../../../../src/ecs/relation-providers.Writable", "inverse": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx$1260$(_x_0, _x_1);
});
})}, "relate": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_tx$1260$(_x_2, _x_3);
});
})}, "unrelate": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058clear_tx$1260$(_x_4, _x_5);
});
})}};
}

function $$$$047full$045v1$047application$058reorder_body$1260$(_caps_0, _args_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058body$1260$(_caps_0, _args_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058queue$1260$(_tx_0, _args_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespace_join$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _args_0);
}

function $$$$047full$045v1$047cleanup$045client$058body$1260$(_caps_0, _handle_0, _owner_0) {
  const _t_0 = _caps_0["despawn"];
  const _despawn_0 = _t_0["run"];
  return run_tail(_despawn_0(_owner_0), _handle_0);
}

function $$$$047full$045v1$047cleanup$045client$058queue$1260$(_tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047full$045v1$047cleanup$045client$058namespace_join$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _handle_0);
}

function $$$$047full$045v1$047provider$058present$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _frame_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Some", "value": _frame_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047full$045v1$047provider$058store_snapshot$1260$(_store_0, _descriptor_0, _target_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": ($$$$047full$045v1$047provider$058snapshot$1260$(_graph_0, _descriptor_0, _target_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058descriptor$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverse_0 = _value_0["inverseName"];
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": _key_0, "name": _name_0, "inverseName": _inverse_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
}

function $$$$047full$045v1$047application$058hierarchy$1260$() {
  return {$: "../../../../src/ecs/relation-types.HierarchyDescriptor", "key": 1, "name": "Parent", "inverseName": "Children"};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $live_got$(_result_0, _next_0) {
  const _array_0 = _result_0["fst"];
  const _b_0 = _result_0["snd"];
  return $live_join$(_next_0(_array_0), ($bool_text$(_b_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047full$045v1$047owned$045world$058show_notices$1260$(_notices_0) {
  if (_notices_0.$ === "Nil") {
    return "";
  } else {
    const _notice_0 = _notices_0["head"];
    const _rest_0 = _notices_0["tail"];
    const _x_0 = ($$$$047full$045v1$047owned$045world$058show_notices$1260$(_rest_0));
    const _x_1 = ($$$$047full$045v1$047owned$045world$058show_notice$1260$(_notice_0));
    const _x_2 = (";" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047full$045v1$047owned$045world$058observe_store_done$1260$(_result_0, _graph_0) {
  const _column_0 = _result_0["fst"];
  const _owners_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058observe_store_stamped$1260$(($$$$047full$045v1$047owned$045world$058column_stamps$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0)))), _graph_0, _owners_0);
}

function $$$$047full$045v1$047owned$045world$058observe_column$1260$(_n_0, _column_0, _id_0) {
  if (_n_0 === 0) {
    return {$: "Tuple", "fst": _column_0, "snd": ""};
  } else {
    const _rest_0 = (_n_0 - 1);
    return $$$$047full$045v1$047owned$045world$058observed_column$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0)), run_clo((_x_0) => {
  return $$$$047full$045v1$047owned$045world$058observe_column$1260$(_rest_0, _x_0, ((_id_0 + 1) >>> 0));
}));
  }
}

function $$$$047full$045v1$047owned$045world$058show_kind$(_kind_0) {
  if (_kind_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return "ordinary";
  } else {
    return "hierarchy";
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $local_after$1261$(_result_0, _peer_0, _before_0, _peerBefore_0, _statuses_0) {
  const _after_0 = _result_0["snd"];
  return $peer_after$1261$(($observe$1261$(_peer_0)), _before_0, _peerBefore_0, _statuses_0, _after_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047full$045v1$047owned$045world$058finish$1261$(_result_0) {
  const _world_0 = _result_0["world"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $attempt_text$1261$(_result_0, _head_0) {
  const _tx_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _tx_0, "snd": (_head_0 + _text_0)};
}

function $$$$047full$045v1$047application$058write_body$1261$(_caps_0, _targets_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_live$(_caps_0, _owner_0, _targets_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058provide_write$1262$() {
  return {$: "../../../../src/ecs/relation-providers.Writable", "inverse": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx$1262$(_x_0, _x_1);
});
})}, "relate": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_tx$1262$(_x_2, _x_3);
});
})}, "unrelate": {$: "../../../../src/ecs/capabilities.Request", "run": run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058clear_tx$1262$(_x_4, _x_5);
});
})}};
}

function $$$$047full$045v1$047application$058reorder_body$1261$(_caps_0, _args_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058body$1261$(_caps_0, _args_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058queue$1261$(_tx_0, _args_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespace_join$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _args_0);
}

function $$$$047full$045v1$047cleanup$045client$058body$1261$(_caps_0, _handle_0, _owner_0) {
  const _t_0 = _caps_0["despawn"];
  const _despawn_0 = _t_0["run"];
  return run_tail(_despawn_0(_owner_0), _handle_0);
}

function $$$$047full$045v1$047cleanup$045client$058queue$1261$(_tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047full$045v1$047cleanup$045client$058namespace_join$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _handle_0);
}

function $$$$047full$045v1$047provider$058present$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _frame_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Some", "value": _frame_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12610$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047full$045v1$047provider$058store_snapshot$1261$(_store_0, _descriptor_0, _target_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": ($$$$047full$045v1$047provider$058snapshot$1261$(_graph_0, _descriptor_0, _target_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058descriptor$1261$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverse_0 = _value_0["inverseName"];
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": _key_0, "name": _name_0, "inverseName": _inverse_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
}

function $$$$047full$045v1$047application$058hierarchy$1261$() {
  return {$: "../../../../src/ecs/relation-types.HierarchyDescriptor", "key": 1, "name": "Parent", "inverseName": "Children"};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $$$$047full$045v1$047owned$045world$058show_notices$1261$(_notices_0) {
  if (_notices_0.$ === "Nil") {
    return "";
  } else {
    const _notice_0 = _notices_0["head"];
    const _rest_0 = _notices_0["tail"];
    const _x_0 = ($$$$047full$045v1$047owned$045world$058show_notices$1261$(_rest_0));
    const _x_1 = ($$$$047full$045v1$047owned$045world$058show_notice$1261$(_notice_0));
    const _x_2 = (";" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047full$045v1$047owned$045world$058observe_store_done$1261$(_result_0, _graph_0) {
  const _column_0 = _result_0["fst"];
  const _owners_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058observe_store_stamped$1261$(($$$$047full$045v1$047owned$045world$058column_stamps$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0)))), _graph_0, _owners_0);
}

function $$$$047full$045v1$047owned$045world$058observe_column$1261$(_n_0, _column_0, _id_0) {
  if (_n_0 === 0) {
    return {$: "Tuple", "fst": _column_0, "snd": ""};
  } else {
    const _rest_0 = (_n_0 - 1);
    return $$$$047full$045v1$047owned$045world$058observed_column$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)), run_clo((_x_0) => {
  return $$$$047full$045v1$047owned$045world$058observe_column$1261$(_rest_0, _x_0, ((_id_0 + 1) >>> 0));
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $peer_after$1260$(_result_0, _before_0, _peerBefore_0, _statuses_0, _after_0) {
  const _peerAfter_0 = _result_0["snd"];
  const _x_0 = ("\n" + _peerAfter_0);
  const _x_1 = (_after_0 + _x_0);
  const _x_2 = ("\n" + _x_1);
  const _x_3 = (_statuses_0 + _x_2);
  const _x_4 = ("\n" + _x_3);
  const _x_5 = (_peerBefore_0 + _x_4);
  const _x_6 = ("\n" + _x_5);
  return (_before_0 + _x_6);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_live$(_caps_0, _owner_0, _args_0) {
  const _t_0 = _caps_0["relate"];
  const _relate_0 = _t_0["run"];
  return run_tail(_relate_0(_owner_0), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx$1260$(_tx_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  const _ns_0 = _target_0["namespace"];
  const _id_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx_done$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_handles$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse$1260$(_world_0, ($$$$047full$045v1$047application$058parent$1260$()), {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_tx$1260$(_tx_0, _targets_0) {
  const _source_0 = _targets_0["source"];
  const _target_0 = _targets_0["target"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, ($$$$047full$045v1$047application$058parent$1260$()), _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058clear_tx$1260$(_tx_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_unrelate$1260$(_tx_0, ($$$$047full$045v1$047application$058parent$1260$()), _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058body$1260$(_caps_0, _args_0, _owner_0) {
  const _t_0 = _caps_0["reorder"];
  const _reorder_0 = _t_0["run"];
  return run_tail(_reorder_0(_owner_0), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespace_join$1260$(_observed_0, _undo_0, _commands_0, _events_0, _args_0) {
  const _world_0 = _observed_0["fst"];
  const _namespace_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058queued$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058same_world$1260$(_args_0, _namespace_0)), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047full$045v1$047cleanup$045client$058namespace_join$1260$(_observed_0, _undo_0, _commands_0, _events_0, _handle_0) {
  const _world_0 = _observed_0["fst"];
  const _namespace_0 = _observed_0["snd"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047full$045v1$047cleanup$045client$058queued$1260$((_namespace_0 === _ns_0), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047full$045v1$047provider$058snapshot$1260$(_graph_0, _descriptor_0, _target_0) {
  const _namespace_0 = _target_0["namespace"];
  const _id_0 = _target_0["id"];
  return {$: "../full-v1/provider.Frame", "entity": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "parent": ($$$$047full$045v1$047provider$058handle$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0)), "children": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0)), "ancestors": ($$$$047full$045v1$047provider$058path$1260$(($$$$047full$045v1$047traversal$058ancestors$1260$(_graph_0, _descriptor_0, _id_0)), _namespace_0)), "root": ($$$$047full$045v1$047provider$058handle$1260$(($$$$047full$045v1$047traversal$058root$(($$$$047full$045v1$047traversal$058ancestors$1260$(_graph_0, _descriptor_0, _id_0)), _id_0)), _namespace_0)), "depth": ($$$$047full$045v1$047provider$058path$1260$(($$$$047full$045v1$047traversal$058descendants$1260$(_graph_0, _descriptor_0, _id_0, {$: "../full-v1/traversal.Depth"})), _namespace_0)), "breadth": ($$$$047full$045v1$047provider$058path$1260$(($$$$047full$045v1$047traversal$058descendants$1260$(_graph_0, _descriptor_0, _id_0, {$: "../full-v1/traversal.Breadth"})), _namespace_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $live_join$(_result_0, _head_0) {
  const _array_0 = _result_0["fst"];
  const _tail_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _array_0, "snd": (_head_0 + _tail_0)};
}

function $bool_text$(_b_0) {
  if (_b_0) {
    return "1,";
  } else {
    return "0,";
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047full$045v1$047owned$045world$058show_notice$1260$(_notice_0) {
  if (_notice_0.$ === "../../../../src/ecs/relation-commands.Original") {
    const _event_0 = _notice_0["event"];
    const _x_0 = ($U32$show$(_event_0));
    return ("Original:" + _x_0);
  } else if (_notice_0.$ === "../../../../src/ecs/relation-commands.CleanupPaused") {
    return "CLEANUP_INCOMPLETE";
  } else if (_notice_0.$ === "../../../../src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _notice_0["id"];
    const _x_1 = ($U32$show$(_id_0));
    return ("Removed:" + _x_1);
  } else {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    const _name_0 = _t_1["name"];
    const _inv_0 = _t_1["inverseName"];
    const _kind_0 = _t_1["kind"];
    const _operation_0 = _t_0["operation"];
    const _source_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _error_0 = _t_0["error"];
    const _x_2 = ($$$$047full$045v1$047owned$045world$058show_error$(_error_0));
    const _x_3 = ($U32$show$(_target_0));
    const _x_4 = (":" + _x_2);
    const _x_5 = (_x_3 + _x_4);
    const _x_6 = ($U32$show$(_source_0));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($$$$047full$045v1$047owned$045world$058show_operation$(_operation_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($$$$047full$045v1$047owned$045world$058show_kind$(_kind_0));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    const _x_15 = (":" + _x_14);
    const _x_16 = (_inv_0 + _x_15);
    const _x_17 = (":" + _x_16);
    const _x_18 = (_name_0 + _x_17);
    const _x_19 = ($U32$show$(_key_0));
    const _x_20 = (":" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    return ("Failure:" + _x_21);
  }
}

function $$$$047full$045v1$047owned$045world$058observe_store_stamped$1260$(_result_0, _graph_0, _owners_0) {
  const _column_0 = _result_0["fst"];
  const _stamps_0 = _result_0["snd"];
  const _x_0 = ($$$$047full$045v1$047owned$045world$058show_ids$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../src/ecs/relation-types.Ordinary"}}, 2))));
  const _x_1 = ($$$$047full$045v1$047owned$045world$058show_ids$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../src/ecs/relation-types.Ordinary"}}, 1))));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|" + _x_3);
  const _x_5 = (_stamps_0 + _x_4);
  const _x_6 = ("|stamps=" + _x_5);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "../full-v1/owned-world.Components", "column": _column_0}, "graph": _graph_0}, "snd": (_owners_0 + _x_6)};
}

function $$$$047full$045v1$047owned$045world$058column_stamps$1260$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047full$045v1$047owned$045world$058show_stamps$(_stamps_0))};
  } else {
    return {$: "Tuple", "fst": _column_0, "snd": "NON_PLAIN_COLUMN"};
  }
}

function $$$$047full$045v1$047owned$045world$058observed_column$1260$(_result_0, _next_0) {
  const _column_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058observed_tail$1260$(_next_0(_column_0), ($$$$047full$045v1$047owned$045world$058show_maybe$(_value_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $peer_after$1261$(_result_0, _before_0, _peerBefore_0, _statuses_0, _after_0) {
  const _peerAfter_0 = _result_0["snd"];
  const _x_0 = ("\n" + _peerAfter_0);
  const _x_1 = (_after_0 + _x_0);
  const _x_2 = ("\n" + _x_1);
  const _x_3 = (_statuses_0 + _x_2);
  const _x_4 = ("\n" + _x_3);
  const _x_5 = (_peerBefore_0 + _x_4);
  const _x_6 = ("\n" + _x_5);
  return (_before_0 + _x_6);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx$1262$(_tx_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  const _ns_0 = _target_0["namespace"];
  const _id_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx_done$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_handles$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse$1261$(_world_0, ($$$$047full$045v1$047application$058parent$1261$()), {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_tx$1262$(_tx_0, _targets_0) {
  const _source_0 = _targets_0["source"];
  const _target_0 = _targets_0["target"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_tx_0, ($$$$047full$045v1$047application$058parent$1261$()), _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058clear_tx$1262$(_tx_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_unrelate$1261$(_tx_0, ($$$$047full$045v1$047application$058parent$1261$()), _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058body$1261$(_caps_0, _args_0, _owner_0) {
  const _t_0 = _caps_0["reorder"];
  const _reorder_0 = _t_0["run"];
  return run_tail(_reorder_0(_owner_0), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespace_join$1261$(_observed_0, _undo_0, _commands_0, _events_0, _args_0) {
  const _world_0 = _observed_0["fst"];
  const _namespace_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058queued$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058same_world$1261$(_args_0, _namespace_0)), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047full$045v1$047cleanup$045client$058namespace_join$1261$(_observed_0, _undo_0, _commands_0, _events_0, _handle_0) {
  const _world_0 = _observed_0["fst"];
  const _namespace_0 = _observed_0["snd"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047full$045v1$047cleanup$045client$058queued$1261$((_namespace_0 === _ns_0), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047full$045v1$047provider$058snapshot$1261$(_graph_0, _descriptor_0, _target_0) {
  const _namespace_0 = _target_0["namespace"];
  const _id_0 = _target_0["id"];
  return {$: "../full-v1/provider.Frame", "entity": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "parent": ($$$$047full$045v1$047provider$058handle$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _id_0)), _namespace_0)), "children": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _id_0)), _namespace_0)), "ancestors": ($$$$047full$045v1$047provider$058path$1261$(($$$$047full$045v1$047traversal$058ancestors$1261$(_graph_0, _descriptor_0, _id_0)), _namespace_0)), "root": ($$$$047full$045v1$047provider$058handle$1261$(($$$$047full$045v1$047traversal$058root$(($$$$047full$045v1$047traversal$058ancestors$1261$(_graph_0, _descriptor_0, _id_0)), _id_0)), _namespace_0)), "depth": ($$$$047full$045v1$047provider$058path$1261$(($$$$047full$045v1$047traversal$058descendants$1261$(_graph_0, _descriptor_0, _id_0, {$: "../full-v1/traversal.Depth"})), _namespace_0)), "breadth": ($$$$047full$045v1$047provider$058path$1261$(($$$$047full$045v1$047traversal$058descendants$1261$(_graph_0, _descriptor_0, _id_0, {$: "../full-v1/traversal.Breadth"})), _namespace_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047full$045v1$047owned$045world$058show_notice$1261$(_notice_0) {
  if (_notice_0.$ === "../../../../src/ecs/relation-commands.Original") {
    const _event_0 = _notice_0["event"];
    const _x_0 = ($U32$show$(_event_0));
    return ("Original:" + _x_0);
  } else if (_notice_0.$ === "../../../../src/ecs/relation-commands.CleanupPaused") {
    return "CLEANUP_INCOMPLETE";
  } else if (_notice_0.$ === "../../../../src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _notice_0["id"];
    const _x_1 = ($U32$show$(_id_0));
    return ("Removed:" + _x_1);
  } else {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    const _name_0 = _t_1["name"];
    const _inv_0 = _t_1["inverseName"];
    const _kind_0 = _t_1["kind"];
    const _operation_0 = _t_0["operation"];
    const _source_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _error_0 = _t_0["error"];
    const _x_2 = ($$$$047full$045v1$047owned$045world$058show_error$(_error_0));
    const _x_3 = ($U32$show$(_target_0));
    const _x_4 = (":" + _x_2);
    const _x_5 = (_x_3 + _x_4);
    const _x_6 = ($U32$show$(_source_0));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($$$$047full$045v1$047owned$045world$058show_operation$(_operation_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($$$$047full$045v1$047owned$045world$058show_kind$(_kind_0));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    const _x_15 = (":" + _x_14);
    const _x_16 = (_inv_0 + _x_15);
    const _x_17 = (":" + _x_16);
    const _x_18 = (_name_0 + _x_17);
    const _x_19 = ($U32$show$(_key_0));
    const _x_20 = (":" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    return ("Failure:" + _x_21);
  }
}

function $$$$047full$045v1$047owned$045world$058observe_store_stamped$1261$(_result_0, _graph_0, _owners_0) {
  const _column_0 = _result_0["fst"];
  const _stamps_0 = _result_0["snd"];
  const _x_0 = ($$$$047full$045v1$047owned$045world$058show_ids$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../src/ecs/relation-types.Ordinary"}}, 2))));
  const _x_1 = ($$$$047full$045v1$047owned$045world$058show_ids$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../src/ecs/relation-types.Ordinary"}}, 1))));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|" + _x_3);
  const _x_5 = (_stamps_0 + _x_4);
  const _x_6 = ("|stamps=" + _x_5);
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "../full-v1/owned-world.Components", "column": _column_0}, "graph": _graph_0}, "snd": (_owners_0 + _x_6)};
}

function $$$$047full$045v1$047owned$045world$058column_stamps$1261$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047full$045v1$047owned$045world$058show_stamps$(_stamps_0))};
  } else {
    return {$: "Tuple", "fst": _column_0, "snd": "NON_PLAIN_COLUMN"};
  }
}

function $$$$047full$045v1$047owned$045world$058observed_column$1261$(_result_0, _next_0) {
  const _column_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058observed_tail$1261$(_next_0(_column_0), ($$$$047full$045v1$047owned$045world$058show_maybe$(_value_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx_done$1260$(_result_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_handles$1260$(_result_0, _target_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _ns_0 = _target_0["namespace"];
  return {$: "Tuple", "fst": _world_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_snapshot$1260$(_value_0, _ns_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse$1260$(_world_0, _descriptor_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)), _descriptor_0, _target_0);
}

function $$$$047full$045v1$047application$058parent$1260$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_unrelate$1260$(_tx_0, _descriptor_0, _source_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_namespaced$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058queued$1260$(_same_0, _tx_0, _args_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply$1260$(_x_0, _args_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058same_world$1260$(_args_0, _namespace_0) {
  const _t_0 = _args_0["parent"];
  const _ns_0 = _t_0["namespace"];
  const _children_0 = _args_0["children"];
  return $Bool$and$((_ns_0 === _namespace_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespaces$1260$(_children_0, _namespace_0)));
}

function $$$$047full$045v1$047cleanup$045client$058queued$1260$(_allowed_0, _tx_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047full$045v1$047cleanup$045client$058apply$1260$(_x_0, _handle_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047full$045v1$047provider$058handle$1260$(_id_0, _namespace_0) {
  if (_id_0.$ === "None") {
    return {$: "None"};
  } else {
    const _id_1 = _id_0["value"];
    return {$: "Some", "value": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_ids_0, _namespace_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_rest_0, _namespace_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047full$045v1$047provider$058path$1260$(_walk_0, _namespace_0) {
  if (_walk_0.$ === "../full-v1/traversal.Complete") {
    const _ids_0 = _walk_0["ids"];
    return {$: "../full-v1/provider.Complete", "handles": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_ids_0, _namespace_0))};
  } else {
    const _ids_1 = _walk_0["ids"];
    const _pending_0 = _walk_0["pending"];
    return {$: "../full-v1/provider.Incomplete", "handles": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_ids_1, _namespace_0)), "pending": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_pending_0, _namespace_0))};
  }
}

function $$$$047full$045v1$047traversal$058ancestors$1260$(_graph_0, _descriptor_0, _target_0) {
  return $$$$047full$045v1$047traversal$058ancestors_loop$1260$(($$$$047full$045v1$047traversal$058budget$1260$(_graph_0)), {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _target_0)), "snd": {$: "Nil"}}, _graph_0, _descriptor_0);
}

function $$$$047full$045v1$047traversal$058root$(_walk_0, _target_0) {
  if (_walk_0.$ === "../full-v1/traversal.Complete") {
    const _ids_0 = _walk_0["ids"];
    return {$: "Some", "value": ($$$$047full$045v1$047traversal$058root_ids$(_ids_0, _target_0))};
  } else {
    return {$: "None"};
  }
}

function $$$$047full$045v1$047traversal$058descendants$1260$(_graph_0, _descriptor_0, _target_0, _order_0) {
  return $$$$047full$045v1$047traversal$058descendants_loop$1260$(($$$$047full$045v1$047traversal$058budget$1260$(_graph_0)), {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0)), "snd": {$: "Nil"}}, _graph_0, _descriptor_0, _order_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047full$045v1$047owned$045world$058show_operation$(_operation_0) {
  if (_operation_0.$ === "../../../../src/ecs/relation-types.Relate") {
    return "relate";
  } else {
    return "reorderChildren";
  }
}

function $$$$047full$045v1$047owned$045world$058show_error$(_error_0) {
  if (_error_0.$ === "../../../../src/ecs/relation-types.MissingEntity") {
    const _source_0 = _error_0["source"];
    const _x_0 = ($U32$show$(_source_0));
    return ("MissingEntity:" + _x_0);
  } else if (_error_0.$ === "../../../../src/ecs/relation-types.MissingTargetEntity") {
    const _source_1 = _error_0["source"];
    const _target_0 = _error_0["target"];
    const _name_0 = _error_0["relation"];
    const _x_1 = ($U32$show$(_target_0));
    const _x_2 = (":" + _name_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_source_1));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return ("MissingTargetEntity:" + _x_6);
  } else if (_error_0.$ === "../../../../src/ecs/relation-types.SelfRelationNotAllowed") {
    const _source_2 = _error_0["source"];
    const _name_1 = _error_0["relation"];
    const _x_7 = ($U32$show$(_source_2));
    const _x_8 = (":" + _name_1);
    const _x_9 = (_x_7 + _x_8);
    return ("SelfRelationNotAllowed:" + _x_9);
  } else if (_error_0.$ === "../../../../src/ecs/relation-types.HierarchyCycle") {
    const _source_3 = _error_0["source"];
    const _target_1 = _error_0["target"];
    const _name_2 = _error_0["relation"];
    const _x_10 = ($U32$show$(_target_1));
    const _x_11 = (":" + _name_2);
    const _x_12 = (_x_10 + _x_11);
    const _x_13 = ($U32$show$(_source_3));
    const _x_14 = (":" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    return ("HierarchyCycle:" + _x_15);
  } else if (_error_0.$ === "../../../../src/ecs/relation-types.MissingChildEntity") {
    const _source_4 = _error_0["source"];
    const _child_0 = _error_0["child"];
    const _name_3 = _error_0["relation"];
    const _x_16 = ($U32$show$(_child_0));
    const _x_17 = (":" + _name_3);
    const _x_18 = (_x_16 + _x_17);
    const _x_19 = ($U32$show$(_source_4));
    const _x_20 = (":" + _x_18);
    const _x_21 = (_x_19 + _x_20);
    return ("MissingChildEntity:" + _x_21);
  } else if (_error_0.$ === "../../../../src/ecs/relation-types.DuplicateChild") {
    const _source_5 = _error_0["source"];
    const _child_1 = _error_0["child"];
    const _name_4 = _error_0["relation"];
    const _x_22 = ($U32$show$(_child_1));
    const _x_23 = (":" + _name_4);
    const _x_24 = (_x_22 + _x_23);
    const _x_25 = ($U32$show$(_source_5));
    const _x_26 = (":" + _x_24);
    const _x_27 = (_x_25 + _x_26);
    return ("DuplicateChild:" + _x_27);
  } else if (_error_0.$ === "../../../../src/ecs/relation-types.ChildNotRelatedToParent") {
    const _source_6 = _error_0["source"];
    const _child_2 = _error_0["child"];
    const _name_5 = _error_0["relation"];
    const _x_28 = ($U32$show$(_child_2));
    const _x_29 = (":" + _name_5);
    const _x_30 = (_x_28 + _x_29);
    const _x_31 = ($U32$show$(_source_6));
    const _x_32 = (":" + _x_30);
    const _x_33 = (_x_31 + _x_32);
    return ("ChildNotRelatedToParent:" + _x_33);
  } else {
    const _source_7 = _error_0["source"];
    const _name_6 = _error_0["relation"];
    const _x_34 = ($U32$show$(_source_7));
    const _x_35 = (":" + _name_6);
    const _x_36 = (_x_34 + _x_35);
    return ("ChildSetMismatch:" + _x_36);
  }
}

function $$$$047full$045v1$047owned$045world$058show_stamps$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return "";
  } else {
    const _t_0 = _entries_0["head"];
    const _id_0 = _t_0["id"];
    const _t_1 = _t_0["stamp"];
    const _added_0 = _t_1["added"];
    const _changed_0 = _t_1["changed"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047full$045v1$047owned$045world$058show_stamps$(_rest_0));
    const _x_1 = ($U32$show$(_changed_0));
    const _x_2 = (";" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_added_0));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($U32$show$(_id_0));
    const _x_8 = (":" + _x_6);
    return (_x_7 + _x_8);
  }
}

function $$$$047full$045v1$047owned$045world$058observed_tail$1260$(_result_0, _head_0) {
  const _column_0 = _result_0["fst"];
  const _tail_0 = _result_0["snd"];
  const _x_0 = (";" + _tail_0);
  return {$: "Tuple", "fst": _column_0, "snd": (_head_0 + _x_0)};
}

function $$$$047full$045v1$047owned$045world$058show_maybe$(_value_0) {
  if (_value_0.$ === "None") {
    return "absent";
  } else {
    const _xs_0 = _value_0["value"];
    return $$$$047full$045v1$047owned$045world$058show_ids$(_xs_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx_done$1261$(_result_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_handles$1261$(_result_0, _target_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _ns_0 = _target_0["namespace"];
  return {$: "Tuple", "fst": _world_0, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_snapshot$1261$(_value_0, _ns_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse$1261$(_world_0, _descriptor_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_checked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)), _descriptor_0, _target_0);
}

function $$$$047full$045v1$047application$058parent$1261$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_unrelate$1261$(_tx_0, _descriptor_0, _source_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_namespaced$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058queued$1261$(_same_0, _tx_0, _args_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply$1261$(_x_0, _args_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058same_world$1261$(_args_0, _namespace_0) {
  const _t_0 = _args_0["parent"];
  const _ns_0 = _t_0["namespace"];
  const _children_0 = _args_0["children"];
  return $Bool$and$((_ns_0 === _namespace_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespaces$1261$(_children_0, _namespace_0)));
}

function $$$$047full$045v1$047cleanup$045client$058queued$1261$(_allowed_0, _tx_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047full$045v1$047cleanup$045client$058apply$1261$(_x_0, _handle_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047full$045v1$047provider$058handle$1261$(_id_0, _namespace_0) {
  if (_id_0.$ === "None") {
    return {$: "None"};
  } else {
    const _id_1 = _id_0["value"];
    return {$: "Some", "value": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1261$(_ids_0, _namespace_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1261$(_rest_0, _namespace_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047full$045v1$047provider$058path$1261$(_walk_0, _namespace_0) {
  if (_walk_0.$ === "../full-v1/traversal.Complete") {
    const _ids_0 = _walk_0["ids"];
    return {$: "../full-v1/provider.Complete", "handles": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1261$(_ids_0, _namespace_0))};
  } else {
    const _ids_1 = _walk_0["ids"];
    const _pending_0 = _walk_0["pending"];
    return {$: "../full-v1/provider.Incomplete", "handles": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1261$(_ids_1, _namespace_0)), "pending": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1261$(_pending_0, _namespace_0))};
  }
}

function $$$$047full$045v1$047traversal$058ancestors$1261$(_graph_0, _descriptor_0, _target_0) {
  return $$$$047full$045v1$047traversal$058ancestors_loop$1261$(($$$$047full$045v1$047traversal$058budget$1261$(_graph_0)), {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _target_0)), "snd": {$: "Nil"}}, _graph_0, _descriptor_0);
}

function $$$$047full$045v1$047traversal$058descendants$1261$(_graph_0, _descriptor_0, _target_0, _order_0) {
  return $$$$047full$045v1$047traversal$058descendants_loop$1261$(($$$$047full$045v1$047traversal$058budget$1261$(_graph_0)), {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _target_0)), "snd": {$: "Nil"}}, _graph_0, _descriptor_0, _order_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047full$045v1$047owned$045world$058observed_tail$1261$(_result_0, _head_0) {
  const _column_0 = _result_0["fst"];
  const _tail_0 = _result_0["snd"];
  const _x_0 = (";" + _tail_0);
  return {$: "Tuple", "fst": _column_0, "snd": (_head_0 + _x_0)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_snapshot$1260$(_value_0, _namespace_0) {
  if (_value_0.$ === "None") {
    return {$: "None"};
  } else {
    const _ids_0 = _value_0["value"];
    return {$: "Some", "value": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_ids_0, _namespace_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_checked$1260$(_checked_0, _descriptor_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "None"}};
  } else {
    const _id_0 = _target_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_present$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_inverse$1260$(_x_0, _descriptor_0, _id_0);
}), _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_checked$1260$((_namespace_0 === _sn_0), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply$1260$(_world_0, _args_0) {
  const _t_0 = _args_0["parent"];
  const _ns_0 = _t_0["namespace"];
  const _parent_0 = _t_0["id"];
  const _children_0 = _args_0["children"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply_parent$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _parent_0})), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058descriptor$1260$(($$$$047full$045v1$047application$058hierarchy$1260$()))), _parent_0, _children_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespaces$1260$(_children_0, _namespace_0) {
  if (_children_0.$ === "Nil") {
    return true;
  } else {
    const _t_0 = _children_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _rest_0 = _children_0["tail"];
    return $Bool$and$((_namespace_0 === _ns_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespaces$1260$(_rest_0, _namespace_0)));
  }
}

function $$$$047full$045v1$047cleanup$045client$058apply$1260$(_world_0, _handle_0) {
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047full$045v1$047cleanup$045client$058result_world$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, {$: "Con", "head": ($$$$047full$045v1$047application$058parent$1260$()), "tail": {$: "Con", "head": ($$$$047full$045v1$047application$058link$1260$()), "tail": {$: "Nil"}}})), _namespace_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047full$045v1$047traversal$058ancestors_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _n_0 = $0;
      const _state_0 = $1;
      const _graph_0 = $2;
      const _descriptor_0 = $3;
      if (_n_0 === 0) {
        return $$$$047full$045v1$047traversal$058ancestor_finished$(_state_0);
      } else {
        const _rest_0 = (_n_0 - 1);
        const _t_0 = _state_0["fst"];
        if (_t_0.$ === "None") {
          const _acc_0 = _state_0["snd"];
          return {$: "../full-v1/traversal.Complete", "ids": ($List$reverse$(_acc_0))};
        } else {
          const _acc_1 = _state_0["snd"];
          $0 = _rest_0;
          $1 = ($$$$047full$045v1$047traversal$058next_ancestor$1260$(_graph_0, _descriptor_0, {$: "Tuple", "fst": _t_0, "snd": _acc_1}));
          $2 = _graph_0;
          $3 = _descriptor_0;
          continue;
        }
      }
    }
  }
}

function $$$$047full$045v1$047traversal$058budget$1260$(_graph_0) {
  const _edges_0 = _graph_0["edges"];
  return nat_chk(($List$length$(_edges_0)) + 1);
}

function $$$$047full$045v1$047traversal$058root_ids$($0, $1) {
  for (;;) {
    {
      const _ids_0 = $0;
      const _current_0 = $1;
      if (_ids_0.$ === "Nil") {
        return _current_0;
      } else {
        const _id_0 = _ids_0["head"];
        const _rest_0 = _ids_0["tail"];
        $0 = _rest_0;
        $1 = _id_0;
        continue;
      }
    }
  }
}

function $$$$047full$045v1$047traversal$058descendants_loop$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _n_0 = $0;
      const _state_0 = $1;
      const _graph_0 = $2;
      const _descriptor_0 = $3;
      const _order_0 = $4;
      if (_n_0 === 0) {
        const _pending_0 = _state_0["fst"];
        const _acc_0 = _state_0["snd"];
        return $$$$047full$045v1$047traversal$058finished$(_acc_0, _pending_0);
      } else {
        const _rest_0 = (_n_0 - 1);
        const _t_0 = _state_0["fst"];
        if (_t_0.$ === "Nil") {
          const _acc_1 = _state_0["snd"];
          return {$: "../full-v1/traversal.Complete", "ids": ($List$reverse$(_acc_1))};
        } else {
          const _acc_2 = _state_0["snd"];
          $0 = _rest_0;
          $1 = ($$$$047full$045v1$047traversal$058next_desc$1260$(_graph_0, _descriptor_0, _order_0, {$: "Tuple", "fst": _t_0, "snd": _acc_2}));
          $2 = _graph_0;
          $3 = _descriptor_0;
          $4 = _order_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_snapshot$1261$(_value_0, _namespace_0) {
  if (_value_0.$ === "None") {
    return {$: "None"};
  } else {
    const _ids_0 = _value_0["value"];
    return {$: "Some", "value": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1261$(_ids_0, _namespace_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_checked$1261$(_checked_0, _descriptor_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "None"}};
  } else {
    const _id_0 = _target_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_present$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12611$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_inverse$1261$(_x_0, _descriptor_0, _id_0);
}), _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_namespaced$1261$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_checked$1261$((_namespace_0 === _sn_0), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply$1261$(_world_0, _args_0) {
  const _t_0 = _args_0["parent"];
  const _ns_0 = _t_0["namespace"];
  const _parent_0 = _t_0["id"];
  const _children_0 = _args_0["children"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply_parent$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _parent_0})), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058descriptor$1261$(($$$$047full$045v1$047application$058hierarchy$1261$()))), _parent_0, _children_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespaces$1261$(_children_0, _namespace_0) {
  if (_children_0.$ === "Nil") {
    return true;
  } else {
    const _t_0 = _children_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _rest_0 = _children_0["tail"];
    return $Bool$and$((_namespace_0 === _ns_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058namespaces$1261$(_rest_0, _namespace_0)));
  }
}

function $$$$047full$045v1$047cleanup$045client$058apply$1261$(_world_0, _handle_0) {
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047full$045v1$047cleanup$045client$058result_world$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, {$: "Con", "head": ($$$$047full$045v1$047application$058parent$1261$()), "tail": {$: "Con", "head": ($$$$047full$045v1$047application$058link$1261$()), "tail": {$: "Nil"}}})), _namespace_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047full$045v1$047traversal$058ancestors_loop$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _n_0 = $0;
      const _state_0 = $1;
      const _graph_0 = $2;
      const _descriptor_0 = $3;
      if (_n_0 === 0) {
        return $$$$047full$045v1$047traversal$058ancestor_finished$(_state_0);
      } else {
        const _rest_0 = (_n_0 - 1);
        const _t_0 = _state_0["fst"];
        if (_t_0.$ === "None") {
          const _acc_0 = _state_0["snd"];
          return {$: "../full-v1/traversal.Complete", "ids": ($List$reverse$(_acc_0))};
        } else {
          const _acc_1 = _state_0["snd"];
          $0 = _rest_0;
          $1 = ($$$$047full$045v1$047traversal$058next_ancestor$1261$(_graph_0, _descriptor_0, {$: "Tuple", "fst": _t_0, "snd": _acc_1}));
          $2 = _graph_0;
          $3 = _descriptor_0;
          continue;
        }
      }
    }
  }
}

function $$$$047full$045v1$047traversal$058budget$1261$(_graph_0) {
  const _edges_0 = _graph_0["edges"];
  return nat_chk(($List$length$(_edges_0)) + 1);
}

function $$$$047full$045v1$047traversal$058descendants_loop$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _n_0 = $0;
      const _state_0 = $1;
      const _graph_0 = $2;
      const _descriptor_0 = $3;
      const _order_0 = $4;
      if (_n_0 === 0) {
        const _pending_0 = _state_0["fst"];
        const _acc_0 = _state_0["snd"];
        return $$$$047full$045v1$047traversal$058finished$(_acc_0, _pending_0);
      } else {
        const _rest_0 = (_n_0 - 1);
        const _t_0 = _state_0["fst"];
        if (_t_0.$ === "Nil") {
          const _acc_1 = _state_0["snd"];
          return {$: "../full-v1/traversal.Complete", "ids": ($List$reverse$(_acc_1))};
        } else {
          const _acc_2 = _state_0["snd"];
          $0 = _rest_0;
          $1 = ($$$$047full$045v1$047traversal$058next_desc$1261$(_graph_0, _descriptor_0, _order_0, {$: "Tuple", "fst": _t_0, "snd": _acc_2}));
          $2 = _graph_0;
          $3 = _descriptor_0;
          $4 = _order_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_present$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _sources_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Some", "value": _sources_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_inverse$1260$(_store_0, _descriptor_0, _target_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_x_0, _descriptor_0, _source_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply_parent$1260$(_checked_0, _d_0, _parent_0, _children_0) {
  const _world_0 = _checked_0["fst"];
  const _live_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply_children$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_statuses$1260$(_children_0, _world_0)), _d_0, _parent_0, _live_0);
}

function $$$$047full$045v1$047cleanup$045client$058result_world$1260$(_result_0, _namespace_0) {
  if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_1, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.CleanupPaused", "frames": _frames_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic$1260$(_world_0, _handle_0, _descriptors_0) {
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic_inventory$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1267$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058original_edges$1260$(_x_0);
}), _world_0)), _namespace_0, _id_0, _descriptors_0);
}

function $$$$047full$045v1$047application$058link$1260$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 2, "name": "Link", "inverseName": "Incoming", "kind": {$: "../../../../src/ecs/relation-types.Ordinary"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047full$045v1$047traversal$058ancestor_finished$(_state_0) {
  const _t_0 = _state_0["fst"];
  if (_t_0.$ === "None") {
    const _acc_0 = _state_0["snd"];
    return {$: "../full-v1/traversal.Complete", "ids": ($List$reverse$(_acc_0))};
  } else {
    const _id_0 = _t_0["value"];
    const _acc_1 = _state_0["snd"];
    return {$: "../full-v1/traversal.Incomplete", "ids": ($List$reverse$(_acc_1)), "pending": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}};
  }
}

function $$$$047full$045v1$047traversal$058next_ancestor$1260$(_graph_0, _descriptor_0, _state_0) {
  const _t_0 = _state_0["fst"];
  if (_t_0.$ === "None") {
    const _acc_0 = _state_0["snd"];
    return {$: "Tuple", "fst": {$: "None"}, "snd": _acc_0};
  } else {
    const _id_0 = _t_0["value"];
    const _acc_1 = _state_0["snd"];
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _id_0)), "snd": {$: "Con", "head": _id_0, "tail": _acc_1}};
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047full$045v1$047traversal$058finished$(_acc_0, _pending_0) {
  if (_pending_0.$ === "Nil") {
    return {$: "../full-v1/traversal.Complete", "ids": ($List$reverse$(_acc_0))};
  } else {
    return {$: "../full-v1/traversal.Incomplete", "ids": ($List$reverse$(_acc_0)), "pending": _pending_0};
  }
}

function $$$$047full$045v1$047traversal$058next_desc$1260$(_graph_0, _descriptor_0, _order_0, _state_0) {
  const _t_0 = _state_0["fst"];
  if (_t_0.$ === "Nil") {
    const _acc_0 = _state_0["snd"];
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": _acc_0};
  } else {
    const _id_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    const _acc_1 = _state_0["snd"];
    return {$: "Tuple", "fst": ($$$$047full$045v1$047traversal$058enqueue$(_order_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _id_0)), _rest_0)), "snd": {$: "Con", "head": _id_0, "tail": _acc_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_present$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _sources_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Some", "value": _sources_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12611$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12611$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_inverse$1261$(_store_0, _descriptor_0, _target_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _target_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_checked$1261$(_same_0, _tx_0, _descriptor_0, _source_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1261$(_x_0, _descriptor_0, _source_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply_parent$1261$(_checked_0, _d_0, _parent_0, _children_0) {
  const _world_0 = _checked_0["fst"];
  const _live_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply_children$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_statuses$1261$(_children_0, _world_0)), _d_0, _parent_0, _live_0);
}

function $$$$047full$045v1$047cleanup$045client$058result_world$1261$(_result_0, _namespace_0) {
  if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_1, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.CleanupPaused", "frames": _frames_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic$1261$(_world_0, _handle_0, _descriptors_0) {
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic_inventory$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12615$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058original_edges$1261$(_x_0);
}), _world_0)), _namespace_0, _id_0, _descriptors_0);
}

function $$$$047full$045v1$047application$058link$1261$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 2, "name": "Link", "inverseName": "Incoming", "kind": {$: "../../../../src/ecs/relation-types.Ordinary"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047full$045v1$047traversal$058next_ancestor$1261$(_graph_0, _descriptor_0, _state_0) {
  const _t_0 = _state_0["fst"];
  if (_t_0.$ === "None") {
    const _acc_0 = _state_0["snd"];
    return {$: "Tuple", "fst": {$: "None"}, "snd": _acc_0};
  } else {
    const _id_0 = _t_0["value"];
    const _acc_1 = _state_0["snd"];
    return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _id_0)), "snd": {$: "Con", "head": _id_0, "tail": _acc_1}};
  }
}

function $$$$047full$045v1$047traversal$058next_desc$1261$(_graph_0, _descriptor_0, _order_0, _state_0) {
  const _t_0 = _state_0["fst"];
  if (_t_0.$ === "Nil") {
    const _acc_0 = _state_0["snd"];
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": _acc_0};
  } else {
    const _id_0 = _t_0["head"];
    const _rest_0 = _t_0["tail"];
    const _acc_1 = _state_0["snd"];
    return {$: "Tuple", "fst": ($$$$047full$045v1$047traversal$058enqueue$(_order_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _id_0)), _rest_0)), "snd": {$: "Con", "head": _id_0, "tail": _acc_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_world_0, _descriptor_0, _source_0) {
  const _id_0 = _source_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058discard_unit$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1265$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_unrelate$1260$(_x_0, _descriptor_0, _id_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply_children$1260$(_observed_0, _d_0, _parent_0, _parentLive_0) {
  const _world_0 = _observed_0["fst"];
  const _children_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058publish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1264$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058store_reorder$1260$(_x_0, _d_0, _parent_0, _children_0, _parentLive_0);
}), _world_0)), _d_0, _parent_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_statuses$1260$(_children_0, _world_0) {
  if (_children_0.$ === "Nil") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _children_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _children_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_next$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), _id_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_statuses$1260$(_rest_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic_inventory$1260$(_observed_0, _namespace_0, _id_0, _descriptors_0) {
  const _t_0 = _observed_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _edges_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic_start$1260$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _highWater_0, _edges_0, _namespace_0, _id_0, _descriptors_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1267$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058original_edges$1260$(_store_0) {
  const _components_0 = _store_0["components"];
  const _t_0 = _store_0["graph"];
  const _edges_0 = _t_0["edges"];
  const _inverses_0 = _t_0["inverses"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}}, "snd": _edges_0};
}

function $$$$047full$045v1$047traversal$058enqueue$(_order_0, _children_0, _rest_0) {
  if (_order_0.$ === "../full-v1/traversal.Depth") {
    return $List$append$(_children_0, _rest_0);
  } else {
    return $List$append$(_rest_0, _children_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047full$045v1$047owned$045world$058project_payload$(_owner_0) {
  const _cells_0 = _owner_0["cells"];
  const _tag_0 = _owner_0["tag"];
  return $$$$047full$045v1$047owned$045world$058project_payload_sized$({$: "Tuple", fst: _cells_0, snd: _cells_0.length}, _tag_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(($$$$047full$045v1$047owned$045world$058project_payload$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12611$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1261$(_world_0, _descriptor_0, _source_0) {
  const _id_0 = _source_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058discard_unit$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12613$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_unrelate$1261$(_x_0, _descriptor_0, _id_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058apply_children$1261$(_observed_0, _d_0, _parent_0, _parentLive_0) {
  const _world_0 = _observed_0["fst"];
  const _children_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058publish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12612$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058store_reorder$1261$(_x_0, _d_0, _parent_0, _children_0, _parentLive_0);
}), _world_0)), _d_0, _parent_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_statuses$1261$(_children_0, _world_0) {
  if (_children_0.$ === "Nil") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _children_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _children_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_next$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), _id_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_statuses$1261$(_rest_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic_inventory$1261$(_observed_0, _namespace_0, _id_0, _descriptors_0) {
  const _t_0 = _observed_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _edges_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic_start$1261$({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _highWater_0, _edges_0, _namespace_0, _id_0, _descriptors_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12615$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12615$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058original_edges$1261$(_store_0) {
  const _components_0 = _store_0["components"];
  const _t_0 = _store_0["graph"];
  const _edges_0 = _t_0["edges"];
  const _inverses_0 = _t_0["inverses"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}}, "snd": _edges_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(($$$$047full$045v1$047owned$045world$058project_payload$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047full$045v1$047owned$045world$058project_payload$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058discard_unit$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_unrelate$1260$(_store_0, _descriptor_0, _source_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058unrelate$1260$(_graph_0, _descriptor_0, _source_0))}, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058publish$1260$(_observed_0, _d_0, _parent_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _d_0, "operation": {$: "../../../../src/ecs/relation-types.ReorderChildren"}, "source": _parent_0, "target": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058error_target$(_error_0, _parent_0)), "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1264$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058store_reorder$1260$(_store_0, _d_0, _parent_0, _children_0, _parentLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058reorder$1260$(_graph_0, _d_0, _parent_0, _children_0, _parentLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_next$1260$(_checked_0, _id_0, _next_0) {
  const _world_0 = _checked_0["fst"];
  const _live_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058children_prepend$1260$(_next_0(_world_0), _id_0, _live_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic_start$1260$(_world_0, _nodes_0, _edges_0, _namespace_0, _id_0, _descriptors_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058owner_blocks$1260$(_nodes_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058drive$1260$(1, {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupEnter", "id": _id_0}, "tail": {$: "Nil"}}, _world_0, _namespace_0, _descriptors_0)), _nodes_0, _edges_0, _namespace_0, _descriptors_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047full$045v1$047owned$045world$058project_payload_sized$(_result_0, _tag_0) {
  const _cells_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058project_payload_done$(($$$$047full$045v1$047owned$045world$058project_cells$(_size_0, _cells_0, 0)), _tag_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058discard_unit$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_unrelate$1261$(_store_0, _descriptor_0, _source_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058unrelate$1261$(_graph_0, _descriptor_0, _source_0))}, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058publish$1261$(_observed_0, _d_0, _parent_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _d_0, "operation": {$: "../../../../src/ecs/relation-types.ReorderChildren"}, "source": _parent_0, "target": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058error_target$(_error_0, _parent_0)), "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12612$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12612$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058store_reorder$1261$(_store_0, _d_0, _parent_0, _children_0, _parentLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058reorder$1261$(_graph_0, _d_0, _parent_0, _children_0, _parentLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058child_next$1261$(_checked_0, _id_0, _next_0) {
  const _world_0 = _checked_0["fst"];
  const _live_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058children_prepend$1261$(_next_0(_world_0), _id_0, _live_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058automatic_start$1261$(_world_0, _nodes_0, _edges_0, _namespace_0, _id_0, _descriptors_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058owner_blocks$1261$(_nodes_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058drive$1261$(1, {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupEnter", "id": _id_0}, "tail": {$: "Nil"}}, _world_0, _namespace_0, _descriptors_0)), _nodes_0, _edges_0, _namespace_0, _descriptors_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12615$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1264$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058unrelate$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058error_target$(_error_0, _parent_0) {
  if (_error_0.$ === "../../../../src/ecs/relation-types.MissingChildEntity") {
    const _child_0 = _error_0["child"];
    return _child_0;
  } else if (_error_0.$ === "../../../../src/ecs/relation-types.DuplicateChild") {
    const _child_1 = _error_0["child"];
    return _child_1;
  } else if (_error_0.$ === "../../../../src/ecs/relation-types.ChildNotRelatedToParent") {
    const _child_2 = _error_0["child"];
    return _child_2;
  } else {
    return _parent_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058reorder$1260$(_graph_0, _d_0, _parent_0, _children_0, _parentLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058validate$1260$(_parentLive_0, _graph_0, _d_0, _parent_0, _children_0)), _graph_0, _d_0, _parent_0, _children_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058children_prepend$1260$(_result_0, _id_0, _live_0) {
  const _world_0 = _result_0["fst"];
  const _rest_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.ChildStatus", "id": _id_0, "live": _live_0}, "tail": _rest_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058owner_blocks$1260$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _nodes_0 = $2;
      const _edges_0 = $3;
      const _namespace_0 = $4;
      const _descriptors_0 = $5;
      if (_remaining_0 === 0) {
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          return _result_0;
        }
      } else {
        const _rest_0 = (_remaining_0 - 1);
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_1 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_1};
        } else {
          $0 = _rest_0;
          $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058phase_blocks$1260$(_edges_0, _result_0, _nodes_0, _edges_0, _namespace_0, _descriptors_0));
          $2 = _nodes_0;
          $3 = _edges_0;
          $4 = _namespace_0;
          $5 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058drive$1260$(_fuel_0, _frames_0, _world_0, _namespace_0, _descriptors_0) {
  if (_fuel_0 === 0) {
    if (_frames_0.$ === "Nil") {
      return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
    } else {
      return {$: "../../../../src/ecs/relation-cleanup.Incomplete", "world": _world_0, "frames": _frames_0};
    }
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_frames_0.$ === "Nil") {
      return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
    } else {
      const _frame_0 = _frames_0["head"];
      const _frames_1 = _frames_0["tail"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058resumed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058step$1260$(_frame_0, _world_0, _namespace_0, _descriptors_0, _frames_1)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058drive$1260$(_rest_0, _x_1, _x_0, _namespace_0, _descriptors_0);
});
}));
    }
  }
}

function $$$$047full$045v1$047owned$045world$058project_payload_done$(_result_0, _tag_0) {
  const _cells_0 = _result_0["fst"];
  const _ids_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../full-v1/owned-world.Payload", "cells": _cells_0, "tag": _tag_0}, "snd": {$: "Con", "head": _tag_0, "tail": _ids_0}};
}

function $$$$047full$045v1$047owned$045world$058project_cells$(_n_0, _cells_0, _index_0) {
  if (_n_0 === 0) {
    return {$: "Tuple", "fst": _cells_0, "snd": {$: "Nil"}};
  } else {
    const _rest_0 = (_n_0 - 1);
    return $$$$047full$045v1$047owned$045world$058cells_done$({$: "Tuple", fst: _cells_0, snd: _cells_0[_index_0 % _cells_0.length]}, run_clo((_x_0) => {
  return $$$$047full$045v1$047owned$045world$058project_cells$(_rest_0, _x_0, ((_index_0 + 1) >>> 0));
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12612$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058unrelate$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12612$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058reorder$1261$(_graph_0, _d_0, _parent_0, _children_0, _parentLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058checked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058validate$1261$(_parentLive_0, _graph_0, _d_0, _parent_0, _children_0)), _graph_0, _d_0, _parent_0, _children_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$058children_prepend$1261$(_result_0, _id_0, _live_0) {
  const _world_0 = _result_0["fst"];
  const _rest_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.ChildStatus", "id": _id_0, "live": _live_0}, "tail": _rest_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058owner_blocks$1261$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _nodes_0 = $2;
      const _edges_0 = $3;
      const _namespace_0 = $4;
      const _descriptors_0 = $5;
      if (_remaining_0 === 0) {
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          return _result_0;
        }
      } else {
        const _rest_0 = (_remaining_0 - 1);
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_1 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_1};
        } else {
          $0 = _rest_0;
          $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058phase_blocks$1261$(_edges_0, _result_0, _nodes_0, _edges_0, _namespace_0, _descriptors_0));
          $2 = _nodes_0;
          $3 = _edges_0;
          $4 = _namespace_0;
          $5 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058drive$1261$(_fuel_0, _frames_0, _world_0, _namespace_0, _descriptors_0) {
  if (_fuel_0 === 0) {
    if (_frames_0.$ === "Nil") {
      return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
    } else {
      return {$: "../../../../src/ecs/relation-cleanup.Incomplete", "world": _world_0, "frames": _frames_0};
    }
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_frames_0.$ === "Nil") {
      return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
    } else {
      const _frame_0 = _frames_0["head"];
      const _frames_1 = _frames_0["tail"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058resumed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058step$1261$(_frame_0, _world_0, _namespace_0, _descriptors_0, _frames_1)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058drive$1261$(_rest_0, _x_1, _x_0, _namespace_0, _descriptors_0);
});
}));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058checked$1260$(_error_0, _graph_0, _d_0, _parent_0, _children_0) {
  if (_error_0.$ === "Some") {
    const _e_0 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _e_0}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replace_inverse$1260$(_inverses_0, _d_0, _parent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_ids$(_children_0))))}, "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058validate$1260$(_parentLive_0, _graph_0, _d_0, _parent_0, _children_0) {
  if (!_parentLive_0) {
    return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingEntity", "source": _parent_0}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058mismatch$(($Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058same_count$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _d_0, _parent_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_ids$(_children_0)))), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058subset$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _d_0, _parent_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_ids$(_children_0)))))), run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058children_checked$1260$(_children_0, _graph_0, _d_0, _parent_0, {$: "Nil"})), _parent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_d_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058phase_blocks$1260$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _nodes_0 = $2;
      const _edges_0 = $3;
      const _namespace_0 = $4;
      const _descriptors_0 = $5;
      if (_remaining_0.$ === "Nil") {
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058node_blocks$1260$(_nodes_0, _result_0, _edges_0, _namespace_0, _descriptors_0);
        }
      } else {
        const _rest_0 = _remaining_0["tail"];
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_1 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_1};
        } else {
          $0 = _rest_0;
          $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058block$1260$(_result_0, _edges_0, _namespace_0, _descriptors_0));
          $2 = _nodes_0;
          $3 = _edges_0;
          $4 = _namespace_0;
          $5 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058resumed$1260$(_observed_0, _next_0) {
  const _world_0 = _observed_0["fst"];
  const _frames_0 = _observed_0["snd"];
  return run_tail(_next_0(_world_0), _frames_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058step$1260$(_frame_0, _world_0, _namespace_0, _descriptors_0, _frames_0) {
  if (_frame_0.$ === "../../../../src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _frame_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058entered$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0})), _id_0, _descriptors_0, _frames_0);
  } else if (_frame_0.$ === "../../../../src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _frame_0["id"];
    const _t_0 = _frame_0["remaining"];
    if (_t_0.$ === "Nil") {
      return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupFinish", "id": _id_1}, "tail": _frames_0}};
    } else {
      const _d_0 = _t_0["head"];
      const _remaining_0 = _t_0["tail"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058children_start$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058snapshot$1260$(_x_0, _d_0, _id_1);
}), _world_0)), _id_1, _d_0, _remaining_0, _frames_0);
    }
  } else if (_frame_0.$ === "../../../../src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _frame_0["id"];
    const _d_1 = _frame_0["descriptor"];
    const _remaining_1 = _frame_0["remainingDescriptors"];
    const _t_1 = _frame_0["remainingChildren"];
    if (_t_1.$ === "Nil") {
      return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_world_0, _d_1, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_2})), "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupDescriptors", "id": _id_2, "remaining": _remaining_1}, "tail": _frames_0}};
    } else {
      const _child_0 = _t_1["head"];
      const _children_0 = _t_1["tail"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058child_step$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058kind$1260$(_d_1)), _world_0, _namespace_0, _id_2, _d_1, _remaining_1, _child_0, _children_0, _frames_0);
    }
  } else {
    const _id_3 = _frame_0["id"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058finish$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_3})), "snd": _frames_0};
  }
}

function $$$$047full$045v1$047owned$045world$058cells_done$(_result_0, _next_0) {
  const _cells_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return $$$$047full$045v1$047owned$045world$058cells_next$(_next_0(_cells_0), _id_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058checked$1261$(_error_0, _graph_0, _d_0, _parent_0, _children_0) {
  if (_error_0.$ === "Some") {
    const _e_0 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _e_0}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replace_inverse$1261$(_inverses_0, _d_0, _parent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_ids$(_children_0))))}, "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058validate$1261$(_parentLive_0, _graph_0, _d_0, _parent_0, _children_0) {
  if (!_parentLive_0) {
    return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingEntity", "source": _parent_0}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058mismatch$(($Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058same_count$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _d_0, _parent_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_ids$(_children_0)))), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058subset$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _d_0, _parent_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_ids$(_children_0)))))), run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058children_checked$1261$(_children_0, _graph_0, _d_0, _parent_0, {$: "Nil"})), _parent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_d_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058phase_blocks$1261$($0, $1, $2, $3, $4, $5) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _nodes_0 = $2;
      const _edges_0 = $3;
      const _namespace_0 = $4;
      const _descriptors_0 = $5;
      if (_remaining_0.$ === "Nil") {
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058node_blocks$1261$(_nodes_0, _result_0, _edges_0, _namespace_0, _descriptors_0);
        }
      } else {
        const _rest_0 = _remaining_0["tail"];
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_1 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_1};
        } else {
          $0 = _rest_0;
          $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058block$1261$(_result_0, _edges_0, _namespace_0, _descriptors_0));
          $2 = _nodes_0;
          $3 = _edges_0;
          $4 = _namespace_0;
          $5 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058resumed$1261$(_observed_0, _next_0) {
  const _world_0 = _observed_0["fst"];
  const _frames_0 = _observed_0["snd"];
  return run_tail(_next_0(_world_0), _frames_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058step$1261$(_frame_0, _world_0, _namespace_0, _descriptors_0, _frames_0) {
  if (_frame_0.$ === "../../../../src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _frame_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058entered$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0})), _id_0, _descriptors_0, _frames_0);
  } else if (_frame_0.$ === "../../../../src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _frame_0["id"];
    const _t_0 = _frame_0["remaining"];
    if (_t_0.$ === "Nil") {
      return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupFinish", "id": _id_1}, "tail": _frames_0}};
    } else {
      const _d_0 = _t_0["head"];
      const _remaining_0 = _t_0["tail"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058children_start$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12611$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058snapshot$1261$(_x_0, _d_0, _id_1);
}), _world_0)), _id_1, _d_0, _remaining_0, _frames_0);
    }
  } else if (_frame_0.$ === "../../../../src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _frame_0["id"];
    const _d_1 = _frame_0["descriptor"];
    const _remaining_1 = _frame_0["remainingDescriptors"];
    const _t_1 = _frame_0["remainingChildren"];
    if (_t_1.$ === "Nil") {
      return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1261$(_world_0, _d_1, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_2})), "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupDescriptors", "id": _id_2, "remaining": _remaining_1}, "tail": _frames_0}};
    } else {
      const _child_0 = _t_1["head"];
      const _children_0 = _t_1["tail"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058child_step$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058kind$1261$(_d_1)), _world_0, _namespace_0, _id_2, _d_1, _remaining_1, _child_0, _children_0, _frames_0);
    }
  } else {
    const _id_3 = _frame_0["id"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058finish$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_3})), "snd": _frames_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replace_inverse$1260$(_entries_0, _d_0, _parent_0, _sources_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _old_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_d_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replaced$1260$(($Bool$and$((_x_0 === _x_1), (_parent_0 === _id_0))), {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _old_0}, _sources_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replace_inverse$1260$(_rest_0, _d_0, _parent_0, _sources_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_ids$(_children_0) {
  if (_children_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _children_0["head"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _children_0["tail"];
    return {$: "Con", "head": _id_0, "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_ids$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058mismatch$(_same_0, _error_0, _parent_0, _name_0) {
  if (_same_0) {
    if (_error_0.$ === "Some") {
      const _e_0 = _error_0["value"];
      return {$: "Some", "value": _e_0};
    } else {
      return {$: "None"};
    }
  } else {
    if (_error_0.$ === "Some") {
      const _e_1 = _error_0["value"];
      return {$: "Some", "value": _e_1};
    } else {
      return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.ChildSetMismatch", "source": _parent_0, "relation": _name_0}};
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058same_count$($0, $1) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      if (_a_0.$ === "Nil") {
        if (_b_0.$ === "Nil") {
          return true;
        } else {
          return false;
        }
      } else {
        const _ar_0 = _a_0["tail"];
        if (_b_0.$ === "Con") {
          const _br_0 = _b_0["tail"];
          $0 = _ar_0;
          $1 = _br_0;
          continue;
        } else {
          return false;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058subset$(_a_0, _b_0) {
  if (_a_0.$ === "Nil") {
    return true;
  } else {
    const _x_0 = _a_0["head"];
    const _rest_0 = _a_0["tail"];
    return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_b_0, _x_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058subset$(_rest_0, _b_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058children_checked$1260$(_children_0, _graph_0, _d_0, _parent_0, _seen_0) {
  if (_children_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _children_0["head"];
    const _id_0 = _t_0["id"];
    const _live_0 = _t_0["live"];
    const _rest_0 = _children_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058first_error$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_error$(_live_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_seen_0, _id_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058parent_match$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _d_0, _id_0)), _parent_0)), _parent_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_d_0)))), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058children_checked$1260$(_rest_0, _graph_0, _d_0, _parent_0, {$: "Con", "head": _id_0, "tail": _seen_0});
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058node_blocks$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _edges_0 = $2;
      const _namespace_0 = $3;
      const _descriptors_0 = $4;
      if (_remaining_0 === 0) {
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058block$1260$(_result_0, _edges_0, _namespace_0, _descriptors_0);
        }
      } else {
        const _rest_0 = (_remaining_0 - 1);
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_1 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_1};
        } else {
          $0 = _rest_0;
          $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058block$1260$(_result_0, _edges_0, _namespace_0, _descriptors_0));
          $2 = _edges_0;
          $3 = _namespace_0;
          $4 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058block$1260$(_result_0, _edges_0, _namespace_0, _descriptors_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058descriptor_units$1260$(_descriptors_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058units$1260$(3, _result_0, _namespace_0, _descriptors_0)), _edges_0, _namespace_0, _descriptors_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058entered$1260$(_checked_0, _id_0, _descriptors_0, _frames_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": _frames_0};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupDescriptors", "id": _id_0, "remaining": _descriptors_0}, "tail": _frames_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058children_start$1260$(_observed_0, _id_0, _descriptor_0, _remaining_0, _frames_0) {
  const _world_0 = _observed_0["fst"];
  const _children_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058snapshot$1260$(_store_0, _descriptor_0, _id_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_inverse$1260$(_store_0, _descriptor_0, _id_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058child_step$1260$(_kind_0, _world_0, _namespace_0, _id_0, _descriptor_0, _remaining_0, _child_0, _children_0, _frames_0) {
  if (_kind_0.$ === "../../../../src/ecs/relation-types.Hierarchy") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupEnter", "id": _child_0}, "tail": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_world_0, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _child_0})), "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058kind$1260$(_d_0) {
  const _kind_0 = _d_0["kind"];
  return _kind_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058finish$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058finalized$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1266$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058clear_store$1260$(_x_0, _handle_0);
}), _world_0)), _handle_0);
}

function $$$$047full$045v1$047owned$045world$058cells_next$(_result_0, _id_0) {
  const _cells_0 = _result_0["fst"];
  const _ids_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _cells_0, "snd": {$: "Con", "head": _id_0, "tail": _ids_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replace_inverse$1261$(_entries_0, _d_0, _parent_0, _sources_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _old_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_d_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replaced$1261$(($Bool$and$((_x_0 === _x_1), (_parent_0 === _id_0))), {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _old_0}, _sources_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replace_inverse$1261$(_rest_0, _d_0, _parent_0, _sources_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058children_checked$1261$(_children_0, _graph_0, _d_0, _parent_0, _seen_0) {
  if (_children_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _children_0["head"];
    const _id_0 = _t_0["id"];
    const _live_0 = _t_0["live"];
    const _rest_0 = _children_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058first_error$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_error$(_live_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_seen_0, _id_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058parent_match$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _d_0, _id_0)), _parent_0)), _parent_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_d_0)))), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058children_checked$1261$(_rest_0, _graph_0, _d_0, _parent_0, {$: "Con", "head": _id_0, "tail": _seen_0});
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058node_blocks$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _edges_0 = $2;
      const _namespace_0 = $3;
      const _descriptors_0 = $4;
      if (_remaining_0 === 0) {
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058block$1261$(_result_0, _edges_0, _namespace_0, _descriptors_0);
        }
      } else {
        const _rest_0 = (_remaining_0 - 1);
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_1 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_1};
        } else {
          $0 = _rest_0;
          $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058block$1261$(_result_0, _edges_0, _namespace_0, _descriptors_0));
          $2 = _edges_0;
          $3 = _namespace_0;
          $4 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058block$1261$(_result_0, _edges_0, _namespace_0, _descriptors_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058descriptor_units$1261$(_descriptors_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058units$1261$(3, _result_0, _namespace_0, _descriptors_0)), _edges_0, _namespace_0, _descriptors_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058entered$1261$(_checked_0, _id_0, _descriptors_0, _frames_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": _frames_0};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupDescriptors", "id": _id_0, "remaining": _descriptors_0}, "tail": _frames_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058children_start$1261$(_observed_0, _id_0, _descriptor_0, _remaining_0, _frames_0) {
  const _world_0 = _observed_0["fst"];
  const _children_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058snapshot$1261$(_store_0, _descriptor_0, _id_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_inverse$1261$(_store_0, _descriptor_0, _id_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058child_step$1261$(_kind_0, _world_0, _namespace_0, _id_0, _descriptor_0, _remaining_0, _child_0, _children_0, _frames_0) {
  if (_kind_0.$ === "../../../../src/ecs/relation-types.Hierarchy") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupEnter", "id": _child_0}, "tail": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1261$(_world_0, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _child_0})), "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058kind$1261$(_d_0) {
  const _kind_0 = _d_0["kind"];
  return _kind_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058finish$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058finalized$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12614$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058clear_store$1261$(_x_0, _handle_0);
}), _world_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replaced$1260$(_found_0, _entry_0, _sources_0, _rest_0) {
  if (_found_0) {
    const _d_0 = _entry_0["relation"];
    const _parent_0 = _entry_0["target"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _d_0, "target": _parent_0, "sources": _sources_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058first_error$(_current_0, _next_0) {
  if (_current_0.$ === "Some") {
    const _e_0 = _current_0["value"];
    return {$: "Some", "value": _e_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058child_error$(_live_0, _duplicate_0, _related_0, _parent_0, _child_0, _name_0) {
  if (!_live_0) {
    return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingChildEntity", "source": _parent_0, "child": _child_0, "relation": _name_0}};
  } else {
    if (_duplicate_0) {
      return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.DuplicateChild", "source": _parent_0, "child": _child_0, "relation": _name_0}};
    } else {
      if (!_related_0) {
        return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.ChildNotRelatedToParent", "source": _parent_0, "child": _child_0, "relation": _name_0}};
      } else {
        return {$: "None"};
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058parent_match$(_value_0, _parent_0) {
  if (_value_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _value_0["value"];
    return (_id_0 === _parent_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058descriptor_units$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _edges_0 = $2;
      const _namespace_0 = $3;
      const _descriptors_0 = $4;
      if (_remaining_0.$ === "Nil") {
        return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058edge_units$1260$(_edges_0, _result_0, _namespace_0, _descriptors_0);
      } else {
        const _rest_0 = _remaining_0["tail"];
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          $0 = _rest_0;
          $1 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058units$1260$(2, _result_0, _namespace_0, _descriptors_0));
          $2 = _edges_0;
          $3 = _namespace_0;
          $4 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058units$1260$(_fuel_0, _result_0, _namespace_0, _descriptors_0) {
  if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058drive$1260$(_fuel_0, _frames_0, _world_1, _namespace_0, _descriptors_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058finalized$1260$(_cleared_0, _handle_0) {
  const _world_0 = _cleared_0["fst"];
  const _notices_0 = _cleared_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058publish_final$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0)), _notices_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1266$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058clear_store$1260$(_store_0, _handle_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058clear_join$1260$(($$$$047full$045v1$047cleanup$045client$058clear$1260$(_components_0, _handle_0)), _graph_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(($List$length$(_edges_0)), {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045reorder$045core$058replaced$1261$(_found_0, _entry_0, _sources_0, _rest_0) {
  if (_found_0) {
    const _d_0 = _entry_0["relation"];
    const _parent_0 = _entry_0["target"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _d_0, "target": _parent_0, "sources": _sources_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058descriptor_units$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _edges_0 = $2;
      const _namespace_0 = $3;
      const _descriptors_0 = $4;
      if (_remaining_0.$ === "Nil") {
        return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058edge_units$1261$(_edges_0, _result_0, _namespace_0, _descriptors_0);
      } else {
        const _rest_0 = _remaining_0["tail"];
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          $0 = _rest_0;
          $1 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058units$1261$(2, _result_0, _namespace_0, _descriptors_0));
          $2 = _edges_0;
          $3 = _namespace_0;
          $4 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058units$1261$(_fuel_0, _result_0, _namespace_0, _descriptors_0) {
  if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058drive$1261$(_fuel_0, _frames_0, _world_1, _namespace_0, _descriptors_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058finalized$1261$(_cleared_0, _handle_0) {
  const _world_0 = _cleared_0["fst"];
  const _notices_0 = _cleared_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058publish_final$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0)), _notices_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$12614$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12614$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058clear_store$1261$(_store_0, _handle_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058clear_join$1261$(($$$$047full$045v1$047cleanup$045client$058clear$1261$(_components_0, _handle_0)), _graph_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058edge_units$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _namespace_0 = $2;
      const _descriptors_0 = $3;
      if (_remaining_0.$ === "Nil") {
        return _result_0;
      } else {
        const _rest_0 = _remaining_0["tail"];
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          $0 = _rest_0;
          $1 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058units$1260$(2, _result_0, _namespace_0, _descriptors_0));
          $2 = _namespace_0;
          $3 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058publish_final$1260$(_deactivated_0, _notices_0, _handle_0) {
  const _world_0 = _deactivated_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, ($List$append$(_notices_0, {$: "Con", "head": ($$$$047full$045v1$047cleanup$045client$058despawn_notice$1260$(_handle_0)), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(false, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058clear_join$1260$(_cleared_0, _graph_0) {
  const _components_0 = _cleared_0["fst"];
  const _notices_0 = _cleared_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _notices_0};
}

function $$$$047full$045v1$047cleanup$045client$058clear$1260$(_components_0, _handle_0) {
  const _column_0 = _components_0["column"];
  const _id_0 = _handle_0["id"];
  return $$$$047full$045v1$047cleanup$045client$058removed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058clear$1260$(_column_0, _id_0)), _id_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058edge_units$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _result_0 = $1;
      const _namespace_0 = $2;
      const _descriptors_0 = $3;
      if (_remaining_0.$ === "Nil") {
        return _result_0;
      } else {
        const _rest_0 = _remaining_0["tail"];
        if (_result_0.$ === "../../../../src/ecs/relation-cleanup.Complete") {
          const _world_0 = _result_0["world"];
          return {$: "../../../../src/ecs/relation-cleanup.Complete", "world": _world_0};
        } else {
          $0 = _rest_0;
          $1 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058units$1261$(2, _result_0, _namespace_0, _descriptors_0));
          $2 = _namespace_0;
          $3 = _descriptors_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058publish_final$1261$(_deactivated_0, _notices_0, _handle_0) {
  const _world_0 = _deactivated_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, ($List$append$(_notices_0, {$: "Con", "head": ($$$$047full$045v1$047cleanup$045client$058despawn_notice$1261$(_handle_0)), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(false, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12614$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045cleanup$058clear_join$1261$(_cleared_0, _graph_0) {
  const _components_0 = _cleared_0["fst"];
  const _notices_0 = _cleared_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _notices_0};
}

function $$$$047full$045v1$047cleanup$045client$058clear$1261$(_components_0, _handle_0) {
  const _column_0 = _components_0["column"];
  const _id_0 = _handle_0["id"];
  return $$$$047full$045v1$047cleanup$045client$058removed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0)), _id_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((_x_0 === _id_0), _x_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_rest_0, _id_0)));
  }
}

function $$$$047full$045v1$047cleanup$045client$058despawn_notice$1260$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return {$: "../../../../src/ecs/relation-commands.Original", "event": ((1000 + _id_0) >>> 0)};
}

function $$$$047full$045v1$047cleanup$045client$058removed$1260$(_outcome_0, _id_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "../full-v1/owned-world.Components", "column": _column_0}, "snd": {$: "Nil"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047full$045v1$047cleanup$045client$058removed_projection$1260$(($$$$047full$045v1$047owned$045world$058project_payload$(_owner_0)), _column_0, _id_0);
    }
  } else {
    const _column_1 = _outcome_0["column"];
    return {$: "Tuple", "fst": {$: "../full-v1/owned-world.Components", "column": _column_1}, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear$1260$(_column_0, _id_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058cleared$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, {$: "None"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047full$045v1$047cleanup$045client$058despawn_notice$1261$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return {$: "../../../../src/ecs/relation-commands.Original", "event": ((1000 + _id_0) >>> 0)};
}

function $$$$047full$045v1$047cleanup$045client$058removed$1261$(_outcome_0, _id_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "../full-v1/owned-world.Components", "column": _column_0}, "snd": {$: "Nil"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047full$045v1$047cleanup$045client$058removed_projection$1261$(($$$$047full$045v1$047owned$045world$058project_payload$(_owner_0)), _column_0, _id_0);
    }
  } else {
    const _column_1 = _outcome_0["column"];
    return {$: "Tuple", "fst": {$: "../full-v1/owned-world.Components", "column": _column_1}, "snd": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058cleared$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, {$: "None"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047full$045v1$047cleanup$045client$058removed_projection$1260$(_result_0, _column_0, _id_0) {
  return {$: "Tuple", "fst": {$: "../full-v1/owned-world.Components", "column": _column_0}, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.ComponentRemoved", "id": _id_0}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058cleared$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047full$045v1$047cleanup$045client$058removed_projection$1261$(_result_0, _column_0, _id_0) {
  return {$: "Tuple", "fst": {$: "../full-v1/owned-world.Components", "column": _column_0}, "snd": {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.ComponentRemoved", "id": _id_0}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058cleared$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0});
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);