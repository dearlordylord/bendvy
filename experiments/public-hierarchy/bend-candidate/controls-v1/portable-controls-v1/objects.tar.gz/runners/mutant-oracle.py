"""Complete variant oracles retaining every unaffected physical constraint."""
import importlib.util,json
from pathlib import Path
HERE=Path(__file__).resolve().parent

def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
C=load(HERE.parent/'full-v1/compare.py','full_hierarchy_compare');M=load(HERE/'mutations.py','hierarchy_mutations')

def physical(point,name):
 result=point['physical']
 if name=='omit-component-clear':
  _,rest=result.split('|stamps=',1)
  result=''.join(f'{i},{i},{i*10},;' for i in range(1,9))+'|stamps='+rest
  import re
  result=re.sub(r'Removed:\d+;','',result)
 return result

def compare(text,reference,name):
 expected=M.expectations(reference,name);lines=text.splitlines();pos=0;actual=[];witnesses=[]
 for root in C.B.ROOTS:
  assert lines[pos]==root;pos+=1;records=[]
  for point in C.model():
   while pos<len(lines) and lines[pos]=='':pos+=1
   assert lines[pos]==point['phase'];pos+=1;rows=[];traversal=[]
   for i in range(1,9):
    row,own=C.parse_row(lines[pos],i);pos+=1;traversal.append(row);rows+=own
   raw=lines[pos];pos+=1;assert raw==physical(point,name),{'root':root,'phase':point['phase'],'expectedPhysical':physical(point,name),'observedPhysical':raw}
   removed=[] if name=='omit-component-clear' else point['notices']
   record={'phase':point['phase'],'rows':rows,'traversal':traversal,'failures':point['failures'],'removed':removed,'despawned':point['notices']};records.append(record)
   if point['phase']=='initial':
    if name=='depth-is-breadth':
     value=traversal[0]['depth']['value'];assert value==[2,3,4,5,6];witnesses.append({'root':root,'phase':'initial','entity':1,'field':'depth','normal':[2,4,5,3,6],'mutated':value})
    elif name=='reverse-child-view':
     value=traversal[0]['children']['value'];assert value==[3,2];witnesses.append({'root':root,'phase':'initial','entity':1,'field':'children','normal':[2,3],'mutated':value})
    elif name=='omit-component-clear':
     value=raw.split('|',1)[0].split(';')[7];assert value=='8,8,80,';assert removed==[];witnesses.append({'root':root,'phase':'initial','physicalOwner':8,'normal':'absent','mutated':value,'normalRemoved':[8],'mutatedRemoved':removed})
  actual.append({'root':root,'records':records})
 assert pos==len(lines);assert actual==expected,{'expected':expected,'actual':actual};assert len(witnesses)==2
 return {'status':'EXACT_COMPLETE_VARIANT_AND_NAMED_BOTH_SCHEMA_WITNESSES_PASS','mutant':name,'records':46,'witnesses':witnesses,'scope':'Compiling finite source mutation detection, not law/proof or full44 acceptance.'}
