"""Additive portable retained evidence: no ELF, cache or complete private environment."""
import hashlib,json,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3];OUT=HERE/'delivery-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
subjects=[HERE.parent/'full-v1/development/cheap-js-1791391000470966648',HERE/'development/native-full-1791392118170545046',HERE/'development/preflight-1791391783410099373',HERE/'development/mutants-1791392228539478538']
subjects += sorted(HERE.glob('development/resume-native-*/receipt.json'))+sorted(HERE.glob('development/refusal-controls-*/receipt.json'))
subjects=[p.parent if p.name=='receipt.json' else p for p in subjects]
manifest=[]
def retain(source,destination):
 raw=source.read_bytes();assert not raw.startswith(b'\x7fELF');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(raw);manifest.append({'path':str(destination.relative_to(OUT)),'sha256':sha(destination),'source':str(source.relative_to(ROOT)),'sourceSHA256':sha(source)})
def portable(value):
 if isinstance(value,dict):return {portable(k):portable(v) for k,v in value.items() if k!='environment'}
 if isinstance(value,list):return [portable(v) for v in value]
 if isinstance(value,str):return value.replace(str(ROOT),'${REPO_ROOT}')
 return value
for source in subjects:
 if not (source/'receipt.json').is_file():continue
 label=source.name;dest=OUT/'evidence'/label
 receipt=json.loads((source/'receipt.json').read_text())
 for product in receipt.get('generated',{}):
  p=Path(product)
  if p.suffix in ('.js','.c'):retain(p,dest/'generated'/p.relative_to(source))
 for p in source.iterdir():
  if p.is_file() and (p.suffix in ('.stdout','.stderr','.js','.c') or p.name.endswith('receipt.json')):retain(p,dest/p.name)
 for plan in source.glob('*plan.json'):
  data=json.loads(plan.read_text());clean=portable(data);clean['originalPlanSHA256']=sha(plan);clean['portableDerivation']='Absolute repository paths relocated; complete environment omitted. This derived plan is not the original admitted executable plan.';target=dest/('portable-'+plan.name);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(clean,indent=2)+'\n');manifest.append({'path':str(target.relative_to(OUT)),'sha256':sha(target),'source':str(plan.relative_to(ROOT)),'sourceSHA256':sha(plan),'derived':True})
 data=json.loads((source/'plan.json').read_text())
 stages=[Path(data['stage'])] if 'stage' in data else [Path(s['path']) for s in data.get('stages',{}).values()]
 for i,stage in enumerate(stages):
  for p in stage.rglob('*.bend'):retain(p,dest/'stages'/str(i)/p.relative_to(stage))
for p in HERE.glob('*.py'):retain(p,OUT/'runners'/p.name)
for p in [HERE.parent/'full-v1/compare.py',HERE.parent/'compare-v2.py',ROOT/'scripts/task_runner.py',ROOT/'scripts/receipt-logs.py',ROOT/'experiments/public-hierarchy/reference.mjs',ROOT/'experiments/public-hierarchy/evidence/reference-1791383596927418665/hierarchy.stdout',ROOT/'experiments/public-hierarchy/evidence/reference-1791383596927418665/receipt.json',ROOT/'.references/sources.json']:
 retain(p,OUT/'oracle-inputs'/p.relative_to(ROOT))
for p in [HERE/'development/resume-reconciliation.json',HERE/'NEGATIVES.json']:retain(p,OUT/'runners'/p.name)
result={'status':'PORTABLE_ADDITIVE_EVIDENCE_MANIFEST','files':manifest,'exclusions':['ELF executables','tool/library binaries','cache directories','complete private environment','original environment-bearing plans'],'scope':'Retained finite exact-source application semantic/raw receipts/oracles; per-probe tool receipt completeness UNMET. Portable copied reports do not grant fully qualified tool-cohort/full44/core/performance/proof approval.'}
OUT.mkdir(exist_ok=True);(OUT/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');print('portable files',len(manifest))
