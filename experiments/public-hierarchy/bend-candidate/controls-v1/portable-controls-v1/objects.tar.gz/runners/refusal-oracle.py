"""Independent complete six-record focused cycle/set observations, including fuel exhaustion."""
import importlib.util
from pathlib import Path
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('refusal_model',HERE.parent/'full-v1/compare.py');C=importlib.util.module_from_spec(s);s.loader.exec_module(C)
OPERATIONS='[Reorder{"reorder",h1,[h3,h2]},Relate{"reparent",h4,h3},Relate{"self",h1,h1},Relate{"cycle",h1,h4},Reorder{"missing-child",h1,[h8,h3,h2]},Reorder{"duplicate-child",h1,[h3,h3,h2]},Reorder{"unrelated-child",h1,[h7,h3,h2]},Reorder{"child-set",h1,[h3]},Despawn{"delete-subtree",h3},Despawn{"repeat-delete",h3},Despawn{"delete-root",h1}]'
MUTATIONS={
 'omit-cycle-refusal':{'file':'src/ecs/relation-graph.bend','old':'cycle_loop(~S,List.length(&2,T.Edge<S>,edges),T.Graph{edges,inverses},T.Descriptor{k,n,inv,T.Hierarchy{}},source,target)','new':'False{}','operations':'[Relate{"cycle",h1,h4}]'},
 'omit-set-refusal':{'file':'src/ecs/relation-reorder-core.bend','old':'case False{} None{}: Some{T.ChildSetMismatch{parent,name}}','new':'case False{} None{}: None{}','operations':'[Reorder{"child-set",h1,[h3]}]'}
}
def expected(name,mutated=True):
 edges=[(1,2,1),(1,3,1),(1,4,2),(1,5,2),(1,6,3),(2,7,3)];inv=[[1,1,[2,3]],[1,2,[4,5]],[1,3,[6]],[2,3,[7]]]
 def hs(ids):return ''.join(f'1:{i},' for i in ids)
 def ms(ids):return ''.join(f'1:{i}@{i},{i},{10*i},;' for i in ids)
 def target(i,k=1):return next((b for key,a,b in edges if key==k and a==i),None)
 def kids(i,k=1):return next((list(ids) for key,b,ids in inv if key==k and b==i),[])
 def walk(i,order):
  pending=kids(i);ids=[]
  for _ in range(len(edges)+1):
   if not pending:break
   x=pending.pop(0);ids.append(x);pending=kids(x)+pending if order=='depth' else pending+kids(x)
  return ('INCOMPLETE:'+hs(ids)+':'+hs(pending) if pending else hs(ids)),([] if pending else ids)
 def row(i):
  if i==8:return 'MissingEntity'
  ancestors=[];x=target(i)
  for _ in range(len(edges)+1):
   if x is None:break
   ancestors.append(x);x=target(x)
  ancestry='INCOMPLETE:'+hs(ancestors)+':'+hs([x]) if x is not None else hs(ancestors)
  root='absent' if x is not None else f'1:{ancestors[-1] if ancestors else i}'
  depth,di=walk(i,'depth');breadth,bi=walk(i,'breadth');p=target(i);link=target(i,2)
  return f'parent={"absent" if p is None else "1:"+str(p)}|children={hs(kids(i))}|ancestors={ancestry}|root={root}|depth={depth}|breadth={breadth}|childMatches={ms(kids(i))}|depthMatches={ms(di)}|breadthMatches={ms(bi)}|row={ms([i])}|link={"absent" if link is None else "1:"+str(link)}|incoming={hs(kids(i,2))}'
 initial=C.model()[0]['physical'];event='';records=[];op='cycle' if name=='omit-cycle-refusal' else 'child-set'
 for phase in ['initial',op+'-queued',op+'-applied']:
  if phase.endswith('-applied'):
   if mutated:
    if op=='cycle':edges.append((1,1,4));inv.append([1,4,[1]])
    else:inv[0][2]=[3]
   else:
    operation,targetid,error=C.ERRORS[op];raw=error['_tag']+':1'+(':4' if op=='cycle' else '')+':Parent';event=f'Failure:1:Parent:Children:hierarchy:{operation}:1:{targetid}:{raw};'
  physical=initial.split('|edges=',1)[0].replace('|pending=0','|pending='+('1' if phase.endswith('-queued') else '0'))
  physical=physical.replace('|2,3,:4,5,|','|'+hs(kids(1)).replace('1:','')+':'+hs(kids(2)).replace('1:','')+'|').replace('|events=Removed:8;Original:1008;','|events=Removed:8;Original:1008;'+event)
  physical+='|edges=graph-edges='+''.join(f'{C.DESCS[k]}:{a}:{b};' for k,a,b in edges)+'|graph-inverses='+''.join(f'{C.DESCS[k]}:{b}:['+''.join(f'{i},' for i in ids)+'];' for k,b,ids in inv)+initial[initial.index('|live='):]
  records.append(phase+'\n'+'\n'.join(row(i) for i in range(1,9))+'\n'+physical)
 # Actual application separates records with exactly one newline.
 body='\n'.join(records)
 return 'HierarchyAlpha\n'+body+'\nHierarchyBeta\n'+body+'\n'
def compare(text,name):
 assert text==expected(name),{'mutant':name,'expected':expected(name),'actual':text}
 assert text!=expected(name,False)
 return {'status':'COMPLETE_SIX_RECORD_BOTH_SCHEMA_REACHED_REFUSAL_MUTANT_PASS','mutant':name,'records':6,'schemas':2,'witnessPhase':('cycle' if name=='omit-cycle-refusal' else 'child-set')+'-applied','scope':'Focused actual registered consumer with complete rows, graph/inverse, owners/live cells, notices and queue; finite mutation control only.'}
