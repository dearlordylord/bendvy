"""Prospective focused actual cycle/set baseline and reached mutant, JS/Native."""
import hashlib,importlib.util,json,shutil,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
N=load(HERE/'native-full-v2.py','refusal_native_base');O=load(HERE/'refusal-oracle.py','refusal_oracle')
BASE=HERE/'development/native-full-1791392118170545046/plan.json';MP=HERE/'development/mutants-1791392228539478538/plan.json';FP=HERE/'development/preflight-1791391783410099373/plan.json'
def prepare():
 base=N.decode(json.loads(BASE.read_text()));mp=json.loads(MP.read_text());fp=json.loads(FP.read_text());current=N.P.snapshot();before=N.P.shared._verification_view(base['tools']);after=N.P.shared._verification_view(current);assert [k for k in before if before[k]!=after[k]]==['environment_sha256'];base['tools']=current;base['environmentSHA256']=hashlib.sha256(json.dumps(N.P.configuration()['env'],sort_keys=True).encode()).hexdigest()
 out=HERE/'development'/('refusal-controls-'+str(time.time_ns()));out.mkdir();stages={};commands=[]
 old=json.loads((N.OLD/'plan.json').read_text());source=Path(old['stage']);assert N.inventory(source)==old['inventory']
 for mutant,mutation in O.MUTATIONS.items():
  for mode in ('baseline','mutant'):
   name=mutant+'-'+mode;stage=out/name/'stage';stage.parent.mkdir();shutil.copytree(source,stage)
   entry=stage/'experiments/public-hierarchy/bend-candidate/full-v1/application.bend';text=entry.read_text();assert text.count(O.OPERATIONS)==1;entry.write_text(text.replace(O.OPERATIONS,mutation['operations']))
   expectedInventory=dict(old['inventory']);expectedInventory[str(entry.relative_to(stage))]=N.sha(entry)
   if mode=='mutant':
    subject=stage/mutation['file'];text=subject.read_text();assert text.count(mutation['old'])==1;subject.write_text(text.replace(mutation['old'],mutation['new']));expectedInventory[mutation['file']]=N.sha(subject)
   assert N.inventory(stage)==expectedInventory
   code=stage.parent/'application.c';binary=stage.parent/'application-native';js=stage.parent/'application.js'
   stages[name]={'path':str(stage),'inventory':expectedInventory,'configurationStates':N.configpaths(out,stage),'mutation':mutation,'mode':mode,'mutant':mutant,'baselineInventory':old['inventory']}
   prefix=base['commands'][0]['argv'][:3]
   for phase,argv,seconds in [('check',prefix+[shutil.which('bend'),str(entry),'--check-only'],5),('emit-js',prefix+[shutil.which('bend'),str(entry),'-o',str(js)],30),('run-js',prefix+[shutil.which('node'),str(js)],5),('emit-c',prefix+[shutil.which('bend'),str(entry),'-o',str(code)],30),('clang',prefix+['/tmp/bendvy-clang19-diagnostic/clang19','-O3',str(code),'-pthread','-lm','-o',str(binary)],120),('run-native',prefix+[str(binary),'--threads','1','--gpu','off'],5)]:commands.append({'label':name+'-'+phase,'subject':name,'phase':phase,'argv':argv,'seconds':seconds})
 pins=dict(base['pins'])
 for p in [Path(__file__),HERE/'resume-reconcile.py',HERE/'development/resume-reconciliation.json',HERE/'refusal-oracle.py',BASE,MP,FP]:pins[str(p.resolve())]=N.sha(p)
 plan={'status':'PREPARED_UNADMITTED_FOCUSED_REFUSAL_CONTROLS','pins':pins,'stages':stages,'tools':base['tools'],'environmentSHA256':base['environmentSHA256'],'commands':commands,'expected':mp['expected'],'scope':'Focused actual registered application cycle/set baselines and mutants with complete six records on two schemas per backend; no full46 mutant or performance acceptance.'}
 p=out/'plan.json';p.write_text(json.dumps(plan,indent=2,default=N.encode));print(p);print(N.sha(p))
def execute(p):
 plan=N.decode(json.loads(p.read_text()));out=p.parent;generated={};env=N.P.configuration()['env']
 def guard():
  assert all(N.sha(f)==h for f,h in plan['pins'].items())
  assert hashlib.sha256(json.dumps(env,sort_keys=True).encode()).hexdigest()==plan['environmentSHA256']
  for d in plan['stages'].values():assert N.inventory(Path(d['path']))==d['inventory'];assert N.configpaths(out,Path(d['path']))==d['configurationStates']
  assert all(N.sha(f)==h for f,h in generated.items());N.P.verify(plan['tools'])
 guard();dirs=[Path(d['path']) for d in plan['stages'].values()];logs=N.L.CommandLogs(out,[c['label'] for c in plan['commands']]);runner=N.T.Runner(logs,inputs=N.T.Inputs(files=[p,*plan['pins']],directories=dirs),env=env,cwd=ROOT,capture='merged-stdout');receipt={'status':'INCOMPLETE','planSHA256':N.sha(p),'commands':[],'comparisons':[],'scope':plan['scope']}
 try:
  for c in plan['commands']:
   guard()
   if '-o' in c['argv']:assert not Path(c['argv'][c['argv'].index('-o')+1]).exists()
   r=runner.run(c['label'],c['argv'],c['seconds']);receipt['commands'].append({'label':c['label'],'exit':r['exit']})
   if '-o' in c['argv']:
    f=c['argv'][c['argv'].index('-o')+1];generated[f]=N.sha(f);runner.inputs=N.T.Inputs(files=[p,*plan['pins'],*generated],directories=dirs)
   guard()
   if c['phase'] in ('run-js','run-native'):
    text=(out/(c['label']+'.stdout')).read_text();subject=plan['stages'][c['subject']];assert text==O.expected(subject['mutant'],subject['mode']=='mutant');receipt['comparisons'].append(O.compare(text,subject['mutant']) if subject['mode']=='mutant' else {'status':'COMPLETE_BOTH_SCHEMA_NORMAL_REFUSAL_ORACLE_PASS','subject':c['subject'],'records':6})
  receipt['status']='JS_NATIVE_FOCUSED_COMPLETE_BOTH_SCHEMA_CYCLE_SET_CONTROLS_PASS'
 except BaseException as e:receipt['status']='FAIL';receipt['error']=str(e);raise
 finally:receipt['generated']=generated;receipt['logs']=logs.hashes;(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
if __name__=='__main__':
 if len(sys.argv)==1:prepare()
 else:execute(Path(sys.argv[1]).resolve())
