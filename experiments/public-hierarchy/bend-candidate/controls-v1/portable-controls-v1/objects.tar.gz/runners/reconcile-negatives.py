"""No-child precise diagnostic reconciliation of previously executed checker probes."""
import hashlib,json,re,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
CASES={
'clone-owner':{'expected':'owner','observed':'owner (consumed more than once)','reportedLine':6,'reportedExpression':'def bad(-F:Type,owner:F) -> F & F:','caret':'  |                 ^^^^^','bodyLine':7,'bodyExpression':'(owner,owner)','context':'- F : Type'},
'cross-schema':{'expected':'H.Read<F, App.Beta>','observed':'H.Read<F, App.Alpha>','reportedLine':7,'reportedExpression':'H.read(F,App.Beta,caps,owner,target)','caret':'  |                     ^^^^','context':'- caps   : H.Read<F, App.Alpha>'},
'write-through-read':{'expected':'R.Writable<F, App.Alpha>','observed':'H.Read<F, App.Alpha>','reportedLine':8,'reportedExpression':'R.body(~App.Alpha,F,caps,args,owner)','caret':'  |                       ^^^^','context':'- caps  : H.Read<F, App.Alpha>'},
'undeclared-access':{'message':'a ../full-v1/provider.Read pattern with 1 field','reportedLine':8,'reportedExpression':'case H.Read{lookup,undeclared}: undeclared(owner,target)','caret':'  |          ^^^^^^^^^^^^^^^^^^^^^^^^^'}}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepare():
 old=HERE/'development/preflight-1791391783410099373';p=old/'negative-reconciliation-plan.json';sourcePlan=json.loads((old/'plan.json').read_text());files=[Path(__file__).resolve(),old/'plan.json',old/'receipt.json']
 for name in CASES:files += [old/(name+'.stdout'),old/(name+'.stderr'),Path(sourcePlan['stage'])/'experiments/public-hierarchy/bend-candidate/controls-v1'/(name+'.bend')]
 plan={'status':'PREPARED_UNADMITTED_NO_CHILD_DIAGNOSTIC_RECONCILIATION','pins':{str(f):sha(f) for f in files},'sourcePlan':str(old/'plan.json'),'cases':CASES,'scope':'Exact four originally executed checker refusals; clone caret is affine binder, independently bound duplicated use remains at body line7. No backend/source/general-authority transfer.'};assert not p.exists();p.write_text(json.dumps(plan,indent=2));print(p);print(sha(p))
def execute(p):
 plan=json.loads(p.read_text());sourcePlan=json.loads(Path(plan['sourcePlan']).read_text());stage=Path(sourcePlan['stage']);out=p.parent
 def guard():
  assert all(sha(f)==h for f,h in plan['pins'].items())
  assert all(sha(f)==h for f,h in sourcePlan['pins'].items())
  assert {str(f.relative_to(stage)):sha(f) for f in stage.rglob('*') if f.is_file()}==sourcePlan['inventory']
 guard();results=[]
 for name,c in plan['cases'].items():
  assert (out/(name+'.stdout')).read_bytes()==b''
  text=(out/(name+'.stderr')).read_text();lines=(stage/'experiments/public-hierarchy/bend-candidate/controls-v1'/(name+'.bend')).read_text().splitlines()
  assert lines[c['reportedLine']-1].strip()==c['reportedExpression'];assert f"{c['reportedLine']}>| " in text;assert c['reportedExpression'] in text;assert c['caret'] in text
  assert 'SOME PROOFS FAIL' in text
  if 'message' in c:assert '- message  : '+c['message'] in text
  else:
   assert '- expected : '+c['expected'] in text and '- observed : '+c['observed'] in text
   assert 'Location: bad' in text and c['context'] in text
  if 'bodyLine' in c:assert lines[c['bodyLine']-1].strip()==c['bodyExpression'];assert c['bodyExpression'] in text
  results.append({'case':name,'status':'EXACT_INTENDED_TYPE_SPAN_DIAGNOSTIC_RECONCILED','diagnosticSHA256':sha(out/(name+'.stderr')),'binding':c})
 guard();receipt={'status':'FOUR_EXACT_CHECKER_REFUSALS_RECONCILED','planSHA256':sha(p),'results':results,'subprocessCount':0,'scope':plan['scope']};dest=out/'negative-reconciliation-receipt.json';assert not dest.exists();dest.write_text(json.dumps(receipt,indent=2));print(dest);print(sha(dest))
if __name__=='__main__':
 if len(sys.argv)==1:prepare()
 else:execute(Path(sys.argv[1]).resolve())
