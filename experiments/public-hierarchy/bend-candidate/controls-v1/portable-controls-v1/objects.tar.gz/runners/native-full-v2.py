"""Prepare exact frozen46 consumer Native replay; independent admission before execution."""
import base64,hashlib,importlib.util,json,os,shutil,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4];HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'full-v1/development/cheap-js-1791391000470966648'
TOOL=ROOT/'experiments/public-relations/promotion-stage/application/next-version/v1/tool-pins.py'
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def encode(x):
 if isinstance(x,bytes):return {'rawBase64':base64.b64encode(x).decode()}
 raise TypeError(type(x))
def decode(x):
 if isinstance(x,dict):
  if set(x)=={'rawBase64'}:return base64.b64decode(x['rawBase64'])
  return {k:decode(v) for k,v in x.items()}
 if isinstance(x,list):return [decode(v) for v in x]
 return x
T=load(ROOT/'scripts/task_runner.py','task_runner');L=load(ROOT/'scripts/receipt-logs.py','receipt_logs');P=load(TOOL,'hierarchy_tools');C=load(HERE.parent/'full-v1/compare.py','hierarchy_full_compare')
def inventory(p):return {str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
def configpaths(out,stage):
 roots=[ROOT,Path.cwd(),out,stage,stage/"src/ecs",stage/"experiments/public-hierarchy/bend-candidate/full-v1"];paths=set()
 for root in roots:
  for ancestor in [root,*root.parents]:
   for n in ('check.json','bend.json','bender.json'):paths.add(ancestor/n)
 paths.add(Path('/home/node/.bend/check.json'))
 return {str(p):sha(p) if p.is_file() else None for p in paths}
def prepare():
 old=json.loads((OLD/'plan.json').read_text());baseline=Path(old['stage']);assert inventory(baseline)==old['inventory'];assert all(sha(f)==h for f,h in old['pins'].items())
 out=HERE/'development'/('native-full-'+str(time.time_ns()));out.mkdir(parents=True);stage=out/'stage';shutil.copytree(baseline,stage)
 # Delivered owned discovery: every ldd child is bounded5, descendant supervised.
 tools=P.snapshot();config=P.configuration();env=config['env'];files={Path(__file__).resolve(),TOOL,ROOT/'scripts/task_runner.py',ROOT/'scripts/receipt-logs.py',ROOT/'scripts/owned-tool-pins.py',HERE.parent/'full-v1/compare.py',HERE.parent/'compare-v2.py',OLD/'plan.json',OLD/'receipt.json',Path(old['expected'])}|{Path(p) for p in tools['pins']}
 files|=set((ROOT/'.references/bend2/bend2').rglob('*.ts'))
 entry=stage/'experiments/public-hierarchy/bend-candidate/full-v1/application.bend';code=out/'application.c';binary=out/'application-native';taskset=config['taskset'];prefix=[str(taskset),'-c','8']
 commands=[{'label':'check','argv':prefix+[shutil.which('bend'),str(entry),'--check-only'],'seconds':5},{'label':'emit-c','argv':prefix+[shutil.which('bend'),str(entry),'-o',str(code)],'seconds':30},{'label':'clang','argv':prefix+['/tmp/bendvy-clang19-diagnostic/clang19','-O3',str(code),'-pthread','-lm','-o',str(binary)],'seconds':120},{'label':'run-native','argv':prefix+[str(binary),'--threads','1','--gpu','off'],'seconds':5}]
 plan={'status':'PREPARED_UNADMITTED_EXACT_FROZEN_NATIVE46','pins':{str(p):sha(p) for p in sorted(files)},'tools':tools,'environmentSHA256':hashlib.sha256(json.dumps(env,sort_keys=True).encode()).hexdigest(),'stage':str(stage),'inventory':inventory(stage),'baselineInventory':old['inventory'],'configurationStates':configpaths(out,stage),'expected':old['expected'],'commands':commands,'scope':'Exactly accepted full46 consumer Bend-source bytes; actual source/tool/resource/config/generated/raw-log Native replay. No new feature or current-whole-core/foreign/mutant/performance approval.'}
 assert plan['inventory']==plan['baselineInventory'];p=out/'plan.json';p.write_text(json.dumps(plan,indent=2,default=encode));print(p);print(sha(p))
def execute(p):
 raw=json.loads(p.read_text());plan=decode(raw);out=p.parent;stage=Path(plan['stage']);generated={};env=P.configuration()['env']
 def guard():
  assert all(sha(f)==h for f,h in plan['pins'].items())
  assert inventory(stage)==plan['inventory']==plan['baselineInventory']
  assert configpaths(out,stage)==plan['configurationStates']
  assert hashlib.sha256(json.dumps(env,sort_keys=True).encode()).hexdigest()==plan['environmentSHA256']
  assert all(sha(f)==h for f,h in generated.items())
  P.verify(plan['tools'])
 guard();inputs=T.Inputs(files=[p,*plan['pins']],directories=[stage]);logs=L.CommandLogs(out,[c['label'] for c in plan['commands']]);runner=T.Runner(logs,inputs=inputs,env=env,cwd=ROOT,capture='merged-stdout');receipt={'status':'INCOMPLETE','planSHA256':sha(p),'commands':[],'scope':plan['scope']}
 try:
  for command in plan['commands']:
   guard()
   if '-o' in command['argv']:assert not Path(command['argv'][command['argv'].index('-o')+1]).exists()
   result=runner.run(command['label'],command['argv'],command['seconds']);receipt['commands'].append({'label':command['label'],'exit':result['exit']})
   if '-o' in command['argv']:
    f=command['argv'][command['argv'].index('-o')+1];generated[f]=sha(f);runner.inputs=T.Inputs(files=[p,*plan['pins'],*generated],directories=[stage])
   guard()
  receipt['comparison']=C.compare((out/'run-native.stdout').read_text(),json.loads(Path(plan['expected']).read_text()));receipt['status']='FROZEN_FULL46_NATIVE_PHYSICAL_EQUIVALENCE_PASS'
 except BaseException as e:receipt['status']='FAIL';receipt['error']=str(e);raise
 finally:
  receipt['generated']=generated;receipt['logs']=logs.hashes;(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
if __name__=='__main__':
 if len(sys.argv)==1:prepare()
 else:execute(Path(sys.argv[1]).resolve())
