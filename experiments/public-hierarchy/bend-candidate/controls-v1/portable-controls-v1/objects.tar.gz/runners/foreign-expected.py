"""Independent complete physical ownership/queue/frontend literals, no TS namespace fiction."""
import json

def physical(namespace,pending=0,applied=False):
 owners=''.join(f'{i},{i},{i*10},;' for i in range(1,9))
 live='0,'+'1,'*8+'0,'*7
 descriptor='1:Parent:Children:hierarchy'
 return owners+'|stamps=|'+('2,:' if applied else ':')+'|events=|meta='+f'{namespace},9,8,16,4,77,1,0|pending={pending}|graph-edges='+ (descriptor+':2:1;' if applied else '')+'|graph-inverses='+ (descriptor+':1:[2,];' if applied else '')+'|physical-live='+live

def expected():
 out=[]
 for root in ('HierarchyAlpha','HierarchyBeta'):
  out += [root,physical(1),physical(2),'lookup=MissingEntity|foreign-target=MissingEntity|foreign-source=MissingEntity|foreign-child=MissingEntity|foreign-parent=MissingEntity|foreign-despawn=MissingEntity|',physical(1,1),physical(1,0,True),physical(2)]
 return '\n'.join(out)+'\n'

def compare(text):
 assert text==expected(),{'expected':expected(),'actual':text}
 return {'status':'PAIRED_FACTORY_FOREIGN_HIERARCHY_FULL_OWNER_QUEUE_PASS','schemas':2,'actualWorldsPerSchema':2,'collidingEntityID':1,'namespaceOnlyFrontendRefusalsPerSchema':5,'lookupRefusalsPerSchema':1,'physicalPayloadOwnersPerWorld':8,'physicalLiveCellsPerWorld':16,'scope':'Shared-owned Factory actual worlds; not independent roots global authority or TS namespace behavior.'}
