"""Prepare narrow source-bound foreign/negative development probes; no delivery qualification."""
import hashlib,importlib.util,json,os,shutil,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4];HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
T=load(ROOT/'scripts/task_runner.py','task_runner');L=load(ROOT/'scripts/receipt-logs.py','receipt_logs');E=load(HERE/'foreign-expected.py','foreign_expected')
NEG=json.loads((HERE/'NEGATIVES.json').read_text())

def prepare():
 out=HERE/'development'/('preflight-'+str(time.time_ns()));out.mkdir(parents=True);stage=out/'stage'
 dst=stage/'experiments/public-hierarchy/bend-candidate'
 for folder in ('controls-v1','full-v1'):
  target=dst/folder;target.mkdir(parents=True)
  for p in (HERE.parent/folder).glob('*.bend'):shutil.copy2(p,target/p.name)
 shutil.copytree(ROOT/'src/ecs',stage/'src/ecs')
 files=[Path(__file__).resolve(),HERE/'NEGATIVES.json',HERE/'foreign-expected.py',ROOT/'scripts/task_runner.py',ROOT/'scripts/receipt-logs.py',Path(shutil.which('bend')).resolve(),Path(shutil.which('node')).resolve()]
 commands=[]
 for name in NEG:commands.append({'label':name,'argv':[shutil.which('bend'),str(dst/'controls-v1'/(name+'.bend')),'--check-only'],'seconds':5,'expectedExit':1})
 code=out/'foreign.js';commands += [{'label':'emit-foreign-js','argv':[shutil.which('bend'),str(dst/'controls-v1/foreign.bend'),'-o',str(code)],'seconds':30,'expectedExit':0},{'label':'run-foreign-js','argv':[shutil.which('node'),str(code)],'seconds':5,'expectedExit':0}]
 plan={'status':'PREPARED_UNADMITTED_DEVELOPMENT_PROBES','pins':{str(p):sha(p) for p in files},'stage':str(stage),'inventory':{str(p.relative_to(stage)):sha(p) for p in stage.rglob('*') if p.is_file()},'commands':commands,'environment':dict(os.environ,BEND_NO_TELEMETRY='1'),'negativeIntent':NEG,'negativeAcceptance':'Capture complete raw diagnostic only; exact intended type/span reconciliation required before any negative acceptance. No substring-only PASS.','scope':'Four exact narrow checker probes plus complete pairedFactory foreign JS control; development tool/config scope only, no Native/full44/delivery qualification.'}
 p=out/'plan.json';p.write_text(json.dumps(plan,indent=2));print(p);print(sha(p))

def execute(path):
 plan=json.loads(path.read_text());out=path.parent;stage=Path(plan['stage']);code=out/'foreign.js';assert not code.exists()
 inputs=T.Inputs(files=[path,*plan['pins']],directories=[stage]);logs=L.CommandLogs(out,[c['label'] for c in plan['commands']]);runner=T.Runner(logs,inputs=inputs,cwd=ROOT,env=plan['environment'],capture='split');receipt={'status':'INCOMPLETE','planSHA256':sha(path),'commands':[],'negativeResults':[],'scope':plan['scope']}
 try:
  for command in plan['commands']:
   if command['label']=='run-foreign-js':
    receipt['generatedSHA256']=sha(code);runner.inputs=T.Inputs(files=[path,*plan['pins'],code],directories=[stage])
   result=runner.run(command['label'],command['argv'],command['seconds'],expected=command['expectedExit']);receipt['commands'].append({'label':command['label'],'exit':result['exit']})
   if command['label'] in NEG:
    receipt['negativeResults'].append({'name':command['label'],'status':'DIAGNOSTIC_CAPTURED_PENDING_PRECISE_RECONCILIATION','completeStdoutSHA256':sha(out/(command['label']+'.stdout')),'completeStderrSHA256':sha(out/(command['label']+'.stderr')),'intended':plan['negativeIntent'][command['label']]})
  receipt['foreign']=E.compare((out/'run-foreign-js.stdout').read_text());receipt['status']='PAIRED_FACTORY_FOREIGN_DEVELOPMENT_JS_PASS_NEGATIVES_PENDING_RECONCILIATION'
 except BaseException as error:receipt['status']='FAIL';receipt['error']=str(error);raise
 finally:receipt['logs']=logs.hashes;(out/'receipt.json').write_text(json.dumps(receipt,indent=2))

if __name__=='__main__':
 if len(sys.argv)==1:prepare()
 else:execute(Path(sys.argv[1]).resolve())
