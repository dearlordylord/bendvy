"""Replay complete retained oracles and hash guards, without backend execution."""
import hashlib,importlib.util,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def inv(p):return {str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
C=load(HERE.parent/'full-v1/compare.py','resume_full');F=load(HERE/'foreign-expected.py','resume_foreign');M=load(HERE/'mutant-oracle.py','resume_mutants')
subjects=[HERE.parent/'full-v1/development/cheap-js-1791391000470966648',HERE/'development/native-full-1791392118170545046',HERE/'development/preflight-1791391783410099373',HERE/'development/mutants-1791392228539478538']
results=[]
for out in subjects:
 p=out/'plan.json';r=out/'receipt.json';plan=json.loads(p.read_text());receipt=json.loads(r.read_text());assert receipt['planSHA256']==sha(p)
 for f,h in plan['pins'].items():assert sha(f)==h, f
 for f,h in receipt['logs'].items():assert sha(out/f)==h, f
 if 'stage' in plan:assert inv(Path(plan['stage']))==plan['inventory']
 for stage in plan.get('stages',{}).values():assert inv(Path(stage['path']))==stage['derivedInventory']
 for f,h in receipt.get('generated',{}).items():assert sha(f)==h
 if out.name.startswith('cheap-js'):comparison=C.compare((out/'run-js.stdout').read_text(),json.loads(Path(plan['expected']).read_text()))
 elif out.name.startswith('native-full'):comparison=C.compare((out/'run-native.stdout').read_text(),json.loads(Path(plan['expected']).read_text()))
 elif out.name.startswith('preflight'):comparison=F.compare((out/'run-foreign-js.stdout').read_text())
 else:comparison=[M.compare((out/(name+'-run-js.stdout')).read_text(),json.loads(Path(plan['expected']).read_text()),name) for name in plan['stages']]
 results.append({'receipt':str(r.relative_to(ROOT)),'receiptSHA256':sha(r),'planSHA256':sha(p),'comparison':comparison})
negative=subjects[2]/'negative-reconciliation-plan.json';nr=subjects[2]/'negative-reconciliation-receipt.json';np=json.loads(negative.read_text());nreceipt=json.loads(nr.read_text());assert nreceipt['planSHA256']==sha(negative)
for f,h in np['pins'].items():assert sha(f)==h,f
assert nreceipt['status']=='FOUR_EXACT_CHECKER_REFUSALS_RECONCILED'
results.append({'receipt':str(nr.relative_to(ROOT)),'receiptSHA256':sha(nr),'planSHA256':sha(negative),'comparison':nreceipt['results']})
report={'status':'RETAINED_HASH_AND_COMPLETE_ORACLE_RECONCILIATION_PASS','backendReruns':0,'subjects':results,'limitations':'Retained finite source-bound scope only; missing cycle/set mutants, Native foreign/mutants, timing/scaling, core adoption and law approval remain.'}
(HERE/'development/resume-reconciliation.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'])
