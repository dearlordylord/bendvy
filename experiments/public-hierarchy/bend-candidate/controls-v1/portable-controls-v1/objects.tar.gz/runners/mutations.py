"""Prospective exact source mutations and independent complete variant expectations."""
import copy
MUTANTS={
 'depth-is-breadth':{'file':'experiments/public-hierarchy/bend-candidate/full-v1/traversal.bend','old':'case Depth{}: List.append(&2,U32,children,rest)','new':'case Depth{}: List.append(&2,U32,rest,children)','witness':{'phase':'initial','entity':1,'field':'depth','expected':[2,4,5,3,6],'mutated':[2,3,4,5,6]}},
 'reverse-child-view':{'file':'experiments/public-hierarchy/bend-candidate/full-v1/provider.bend','old':'Relations.handle_ids(~S,Graph.inverse(~S,graph,descriptor,id),namespace)','new':'Relations.handle_ids(~S,List.reverse(&2,U32,Graph.inverse(~S,graph,descriptor,id)),namespace)','witness':{'phase':'initial','entity':1,'field':'children','expected':[2,3],'mutated':[3,2]}},
 'omit-component-clear':{'file':'experiments/public-hierarchy/bend-candidate/full-v1/cleanup-client.bend','old':'case O.Components{column} W.Handle{_,+id}: removed(~S,Col.clear(~S,~O.Payload,column,id),id)','new':'case O.Components{column} W.Handle{_,+id}: (O.Components{column},[])','witness':{'phase':'initial','physicalOwner':8,'expected':'absent','mutated':[8,8,80]}},
}

def expectations(reference,name):
 result=copy.deepcopy(reference)
 for root in result:
  for checkpoint in root['records']:
   for row in checkpoint['traversal']:
    if name=='depth-is-breadth':
     row['depth']=copy.deepcopy(row['breadth']);row['depthMatches']=copy.deepcopy(row['breadthMatches'])
    elif name=='reverse-child-view':
     for field in ('children','childMatches'):
      if row[field]['ok']:row[field]['value'].reverse()
   if name=='omit-component-clear':checkpoint['removed']=[]
 return result
