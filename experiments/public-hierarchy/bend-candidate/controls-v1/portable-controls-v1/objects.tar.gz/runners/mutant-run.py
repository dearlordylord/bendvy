"""Prospective exact mutated55-file inventories and complete named variant oracle."""
import hashlib,importlib.util,json,os,shutil,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4];HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'full-v1/development/cheap-js-1791391000470966648'
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inv(p):return {str(f.relative_to(p)):sha(f) for f in p.rglob('*') if f.is_file()}
T=load(ROOT/'scripts/task_runner.py','task_runner');L=load(ROOT/'scripts/receipt-logs.py','receipt_logs');M=load(HERE/'mutations.py','mutations');O=load(HERE/'mutant-oracle.py','mutant_oracle')
def prepare():
 baseline=json.loads((OLD/'plan.json').read_text());source=Path(baseline['stage']);assert inv(source)==baseline['inventory'];assert all(sha(p)==h for p,h in baseline['pins'].items())
 out=HERE/'development'/('mutants-'+str(time.time_ns()));out.mkdir(parents=True);stages={};commands=[]
 for name,m in M.MUTANTS.items():
  original=(source/m['file']).read_text();assert original.count(m['old'])==1
  derived=original.replace(m['old'],m['new']);expected=dict(baseline['inventory']);expected[m['file']]=hashlib.sha256(derived.encode()).hexdigest()
  # Compute intentional inventory BEFORE copying/mutating any subject bytes.
  stage=out/name/'stage';stage.parent.mkdir();shutil.copytree(source,stage);(stage/m['file']).write_text(derived);assert inv(stage)==expected
  stages[name]={'path':str(stage),'originalInventory':baseline['inventory'],'derivedInventory':expected,'mutation':m,'originalFileSHA256':baseline['inventory'][m['file']],'mutatedFileSHA256':expected[m['file']]}
  entry=stage/'experiments/public-hierarchy/bend-candidate/full-v1/application.bend';code=stage.parent/'application.js'
  for phase,argv,seconds in [('check',[shutil.which('bend'),str(entry),'--check-only'],5),('emit-js',[shutil.which('bend'),str(entry),'-o',str(code)],30),('run-js',[shutil.which('node'),str(code)],5)]:commands.append({'label':name+'-'+phase,'subject':name,'phase':phase,'argv':argv,'seconds':seconds})
 files=[Path(__file__).resolve(),HERE/'mutations.py',HERE/'mutant-oracle.py',HERE.parent/'full-v1/compare.py',HERE.parent/'compare-v2.py',ROOT/'scripts/task_runner.py',ROOT/'scripts/receipt-logs.py',OLD/'plan.json',OLD/'receipt.json',Path(baseline['expected']),Path(shutil.which('bend')).resolve(),Path(shutil.which('node')).resolve()]
 plan={'status':'PREPARED_UNADMITTED_COMPLETE_MUTANT_DEVELOPMENT_PROBE','pins':{str(p):sha(p) for p in files},'stages':stages,'commands':commands,'environment':dict(os.environ,BEND_NO_TELEMETRY='1'),'expected':baseline['expected'],'scope':'Exact full46 compiling JS source variants; complete public and physical variant expectations, named both-schema witnesses. Cheap development tool/config scope; Native/cycle/set-mutants/full44 remain mandatory.'}
 p=out/'plan.json';p.write_text(json.dumps(plan,indent=2));print(p);print(sha(p))
def execute(p):
 plan=json.loads(p.read_text());out=p.parent;generated={}
 def guard():
  assert all(sha(f)==h for f,h in plan['pins'].items())
  for d in plan['stages'].values():assert inv(Path(d['path']))==d['derivedInventory']
  assert all(sha(f)==h for f,h in generated.items())
 guard();inputs=T.Inputs(files=[p,*plan['pins']],directories=[Path(d['path']) for d in plan['stages'].values()]);logs=L.CommandLogs(out,[c['label'] for c in plan['commands']]);runner=T.Runner(logs,inputs=inputs,cwd=ROOT,env=plan['environment'],capture='split');receipt={'status':'INCOMPLETE','planSHA256':sha(p),'commands':[],'results':[],'scope':plan['scope']}
 try:
  for c in plan['commands']:
   guard()
   if c['phase']=='emit-js':assert not Path(c['argv'][-1]).exists()
   result=runner.run(c['label'],c['argv'],c['seconds']);receipt['commands'].append({'label':c['label'],'exit':result['exit']})
   if c['phase']=='emit-js':generated[c['argv'][-1]]=sha(c['argv'][-1]);runner.inputs=T.Inputs(files=[p,*plan['pins'],*generated],directories=[Path(d['path']) for d in plan['stages'].values()])
   guard()
   if c['phase']=='run-js':receipt['results'].append(O.compare((out/(c['label']+'.stdout')).read_text(),json.loads(Path(plan['expected']).read_text()),c['subject']))
  receipt['status']='THREE_FULL46_DEVELOPMENT_JS_MUTANTS_NAMED_WITNESSES_PASS'
 except BaseException as e:receipt['status']='FAIL';receipt['error']=str(e);raise
 finally:receipt['generated']=generated;receipt['logs']=logs.hashes;(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
if __name__=='__main__':
 if len(sys.argv)==1:prepare()
 else:execute(Path(sys.argv[1]).resolve())
