"""Compress exact portable hierarchy objects; keep original development evidence untouched."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;SOURCE=HERE/'delivery-v1';OUT=HERE/'portable-controls-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((SOURCE/'manifest.json').read_text());buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for row in sorted(manifest['files'],key=lambda x:x['path']):
  raw=(SOURCE/row['path']).read_bytes();assert sha(raw)==row['sha256'];assert not raw.startswith(b'\x7fELF');info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(raw))
OUT.mkdir(exist_ok=True);(OUT/'objects.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0));manifest['archive']={'path':'objects.tar.gz','sha256':sha((OUT/'objects.tar.gz').read_bytes()),'decodedTarSHA256':sha(buffer.getvalue()),'format':'gzip lossless POSIX tar; exact object members'};manifest['developmentOnly']=True;manifest['acceptance']=False;manifest['completeIssue44']=False
manifest['files']=manifest.pop('files');manifest['packageFiles']={p.name:sha(p.read_bytes()) for p in OUT.iterdir() if p.is_file() and p.name!='manifest.json'};(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(OUT);print(manifest['archive']['sha256']);print(len(manifest['files']))
