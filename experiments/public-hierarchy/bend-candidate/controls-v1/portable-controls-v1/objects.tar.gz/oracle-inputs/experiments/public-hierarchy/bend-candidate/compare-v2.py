"""Complete initial-slice TS comparison plus independent physical inventory literals."""
import json
from pathlib import Path

ROOTS = ('HierarchyAlpha','HierarchyBeta')
PHASES = ('initial','queued','applied')
FIELDS = ('parent','children','ancestors','root','depth','breadth','link','incoming','childMatches','depthMatches','breadthMatches')

def nums(text):
    return [int(x) for x in text.split(',') if x]

def handle(text):
    ns, ident = map(int,text.split(':'))
    assert ns == 1, ('unexpected namespace',ns,ident)
    assert 1 <= ident <= 8
    return ident

def handles(text):
    assert not text.startswith('INCOMPLETE:'),text
    return [handle(x) for x in text.split(',') if x]

def matches(text):
    result=[]
    for part in text.split(';'):
        if not part: continue
        ident, raw = part.split('@')
        tag,*cells=nums(raw)
        assert len(cells)==2
        result.append({'id':handle(ident),'payload':{'label':tag,'cells':cells}})
    return result

def good(value): return {'ok':True,'value':value}
def missing(ident,relation=None):
    error={'_tag':'MissingEntity','entityId':ident} if relation is None else {'_tag':'MissingRelation','entityId':ident,'relation':relation}
    return {'ok':False,'error':error}

def physical(phase):
    # Independent chronological model: source reservations 1..8, six FIFO edges,
    # seed despawn8; later hierarchy subtree3 visits6 then3.
    gone={8} if phase!='applied' else {8,6,3}
    owners=''.join('absent;' if i in gone else f'{i},{i},{i*10},;' for i in range(1,9))
    edges=[(1,2,1),(1,3,1),(1,4,2),(1,5,2),(1,6,3),(2,7,3)]
    if phase=='applied': edges=[x for x in edges if x[1] not in gone and x[2] not in gone]
    inv=[]
    for key,source,target in edges:
        found=next((v for v in inv if v[0]==key and v[1]==target),None)
        if found is None: inv.append([key,target,[source]])
        else: found[2].append(source)
    desc={1:'1:Parent:Children:hierarchy',2:'2:Link:Incoming:ordinary'}
    graph=''.join(f'{desc[k]}:{s}:{t};' for k,s,t in edges)
    inverse=''.join(f'{desc[k]}:{t}:['+''.join(f'{i},' for i in ids)+'];' for k,t,ids in inv)
    compact=('2,' if phase=='applied' else '2,3,')+':4,5,'
    events='Removed:8;Original:1008;'
    if phase=='applied': events+='Removed:6;Original:1006;Removed:3;Original:1003;'
    live=''.join('1,' if i in range(1,9) and i not in gone else '0,' for i in range(16))
    return owners+'|stamps=|'+compact+'|events='+events+'|meta=1,9,8,16,4,77,1,0|pending='+('1' if phase=='queued' else '0')+'|edges=graph-edges='+graph+'|graph-inverses='+inverse+'|live='+live

def parse(text):
    lines=text.splitlines(); position=0; output=[]
    for root in ROOTS:
        assert lines[position]==root,(position,lines[position]);position+=1
        records=[]
        for phase in PHASES:
            assert lines[position]==phase.upper();position+=1
            rows=[];traversal=[]
            for ident in range(1,9):
                line=lines[position];position+=1
                if line=='MissingEntity':
                    item={'id':ident,**{k:missing(ident) for k in FIELDS}}
                else:
                    parts=dict(x.split('=',1) for x in line.split('|'))
                    assert set(parts)==set(FIELDS)|{'row'},set(parts)
                    item={'id':ident}
                    for key in FIELDS:
                        value=parts[key]
                        if key in ('parent','link'):
                            item[key]=missing(ident,'Parent' if key=='parent' else 'Link') if value=='absent' else good(handle(value))
                        elif key=='root': item[key]=good(handle(value))
                        elif key.endswith('Matches'):item[key]=good(matches(value))
                        else:item[key]=good(handles(value))
                    own=matches(parts['row']);assert len(own)==1 and own[0]['id']==ident
                    rows+=own
                traversal.append(item)
            raw=lines[position];position+=1
            assert raw==physical(phase),{'phase':phase,'expectedPhysical':physical(phase),'observedPhysical':raw}
            # The upstream first read includes seed8 cleanup. Its complete
            # raw publication remains checked above; only their actual starting
            # boundary is projected here: first read[8], next read[], later read[6,3]. This is not #43 cursor acceptance.
            notices={'initial':[8],'queued':[],'applied':[6,3]}[phase]
            records.append({'phase':{'initial':'initial','queued':'delete-subtree-queued','applied':'delete-subtree-applied'}[phase],'rows':rows,'traversal':traversal,'failures':[],'removed':notices,'despawned':notices})
        output.append({'root':root,'records':records})
    assert position==len(lines),lines[position:]
    return output

def compare(text, expected):
    actual=parse(text)
    assert actual==expected, {'expected':expected,'actual':actual}
    return {'status':'SIX_COMPLETE_RECORDS_AND_PHYSICAL_INVENTORIES_PASS','records':6,'traversalSubjects':48}

if __name__=='__main__':
    import sys
    print(json.dumps(compare(Path(sys.argv[1]).read_text(),json.loads(Path(sys.argv[2]).read_text())),indent=2))
