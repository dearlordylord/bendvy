"""Complete46 public fields plus independent chronological raw physical model."""
import importlib.util,json
from pathlib import Path
s=importlib.util.spec_from_file_location('initial_parser',Path(__file__).resolve().parent.parent/'compare-v2.py');B=importlib.util.module_from_spec(s);s.loader.exec_module(B)
OPS=['reorder','reparent','self','cycle','missing-child','duplicate-child','unrelated-child','child-set','delete-subtree','repeat-delete','delete-root']
DESCS={1:'1:Parent:Children:hierarchy',2:'2:Link:Incoming:ordinary'}
ERRORS={
 'self':('relate',1,{'_tag':'SelfRelationNotAllowed','entityId':1,'relation':'Parent'}),
 'cycle':('relate',4,{'_tag':'HierarchyCycle','entityId':1,'targetId':4,'relation':'Parent'}),
 'missing-child':('reorderChildren',8,{'_tag':'MissingChildEntity','entityId':1,'childId':8,'relation':'Parent'}),
 'duplicate-child':('reorderChildren',3,{'_tag':'DuplicateChild','entityId':1,'childId':3,'relation':'Parent'}),
 'unrelated-child':('reorderChildren',7,{'_tag':'ChildNotRelatedToParent','entityId':1,'childId':7,'relation':'Parent'}),
 'child-set':('reorderChildren',1,{'_tag':'ChildSetMismatch','entityId':1,'relation':'Parent'})}

def model():
 edges=[(1,2,1),(1,3,1),(1,4,2),(1,5,2),(1,6,3),(2,7,3)]
 inverses=[[1,1,[2,3]],[1,2,[4,5]],[1,3,[6]],[2,3,[7]]]
 gone={8};events='Removed:8;Original:1008;';points=[]
 def snapshot(phase,notices,failures):
  owners=''.join('absent;' if i in gone else f'{i},{i},{i*10},;' for i in range(1,9))
  children=lambda t:next((a for k,v,a in inverses if k==1 and v==t),[])
  compact=''.join(f'{i},' for i in children(1))+':'+''.join(f'{i},' for i in children(2))
  graph=''.join(f'{DESCS[k]}:{a}:{b};' for k,a,b in edges)
  inverse=''.join(f'{DESCS[k]}:{t}:['+''.join(f'{i},' for i in ids)+'];' for k,t,ids in inverses)
  live=''.join('1,' if i in range(1,9) and i not in gone else '0,' for i in range(16))
  physical=owners+'|stamps=|'+compact+'|events='+events+'|meta=1,9,8,16,4,77,2,0|pending='+('1' if phase.endswith('-queued') else '0')+'|edges=graph-edges='+graph+'|graph-inverses='+inverse+'|live='+live
  points.append({'phase':phase,'physical':physical,'notices':list(notices),'failures':failures})
 def remove_source(key,source):
  nonlocal edges,inverses
  edges=[e for e in edges if not(e[0]==key and e[1]==source)]
  updated=[]
  for k,t,ids in inverses:
   ids=[i for i in ids if not(k==key and i==source)]
   if ids:updated.append([k,t,ids])
  inverses=updated
 def destroy(ident):
  nonlocal edges,inverses,events
  gone.add(ident)
  # Cleanup detaches every incoming/outgoing edge in descriptor order;
  # complete residual graph/inverse order is retained.
  for key in (1,2):
   for _,source,_ in [e for e in edges if e[0]==key and e[2]==ident]:remove_source(key,source)
   remove_source(key,ident)
  events+=f'Removed:{ident};Original:{1000+ident};'
 snapshot('initial',[8],[])
 for op in OPS:
  snapshot(op+'-queued',[],[]);notices=[];failures=[]
  if op=='reorder':inverses[0][2]=[3,2]
  elif op=='reparent':
   remove_source(1,4);edges.append((1,4,3));next(v[2] for v in inverses if v[0]==1 and v[1]==3).append(4)
  elif op in ERRORS:
   operation,target,error=ERRORS[op]
   raw=error['_tag']+':1'+(':'+str(error.get('targetId',error.get('childId'))) if 'targetId' in error or 'childId' in error else '')+':Parent'
   events+=f'Failure:1:Parent:Children:hierarchy:{operation}:1:{target}:{raw};'
   failures=[{'operation':operation,'relation':'Parent','source':1,'target':target,'error':error}]
  elif op=='delete-subtree':
   notices=[6,4,3]
   for i in notices:destroy(i)
  elif op=='delete-root':
   notices=[5,2,1]
   for i in notices:destroy(i)
  snapshot(op+'-applied',notices,failures)
 return points

def parse_row(line,ident):
 if line=='MissingEntity':return {'id':ident,**{k:B.missing(ident) for k in B.FIELDS}},[]
 parts=dict(x.split('=',1) for x in line.split('|'));assert set(parts)==set(B.FIELDS)|{'row'}
 item={'id':ident}
 for key in B.FIELDS:
  value=parts[key]
  if key in ('parent','link'):item[key]=B.missing(ident,'Parent' if key=='parent' else 'Link') if value=='absent' else B.good(B.handle(value))
  elif key=='root':item[key]=B.good(B.handle(value))
  elif key.endswith('Matches'):item[key]=B.good(B.matches(value))
  else:item[key]=B.good(B.handles(value))
 own=B.matches(parts['row']);assert len(own)==1 and own[0]['id']==ident
 return item,own

def compare(text,expected):
 lines=text.splitlines();pos=0;actual=[]
 for root in B.ROOTS:
  assert lines[pos]==root;pos+=1;records=[]
  for point in model():
   while pos<len(lines) and lines[pos]=='':pos+=1
   assert lines[pos]==point['phase'],(pos,lines[pos],point['phase']);pos+=1
   traversal=[];rows=[]
   for i in range(1,9):
    row,own=parse_row(lines[pos],i);pos+=1;traversal.append(row);rows+=own
   assert lines[pos]==point['physical'],{'phase':point['phase'],'expected':point['physical'],'actual':lines[pos]};pos+=1
   records.append({'phase':point['phase'],'rows':rows,'traversal':traversal,'failures':point['failures'],'removed':point['notices'],'despawned':point['notices']})
  actual.append({'root':root,'records':records})
 assert pos==len(lines),lines[pos:]
 assert actual==expected,{'expected':expected,'actual':actual}
 return {'status':'FORTY_SIX_COMPLETE_HIERARCHY_AND_PHYSICAL_RECORDS_PASS','records':46,'publicSubjects':368,'scope':'Actual persistent registered observer + deferred mutations/cleanup; finite comparison, not full44/reader/proof/performance approval.'}
