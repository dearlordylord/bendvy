# Experiment-local production candidate — development only

No `src` mutation or backend source freeze. Root shared core batch is active. Current candidate relocates graph/types/commands/providers/reorder modules without semantic changes and adds automatic derived Nat completion to the cleanup interpreter. Clear callbacks receive only C:Type component pack plus Handle; outer graph/live World fields remain owned by the interpreter.

`cleanup-owned.bend` adopts automatic completion and adds the actual accepted219-step carrier under both nominal schemas, preserving original registered callback/clear/observer bodies. `automatic` still returns Complete/Incomplete with complete affine World+frames; the inherited adapter's paused notice is an explicit diagnostic for invalid premises/defects, not an adopted normal production cleanup policy. Proofs/laws remain unapproved.

Execution preflight, independent admission, complete JS/Native219 records, actual source-span access negatives and reached fixed128/owner/order mutants are pending. No passing old prototype receipt transfers to this candidate. `derivation-inputs.json` records relocation lineage; final output pins await development freeze after root release.
