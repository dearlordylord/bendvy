#!/usr/bin/env python3
"""Preflight first; executable finite graph falsification is a separate opt-in.
No proof, World/Commands/cleanup or relation-system acceptance is reported.
"""
import argparse, hashlib, json, os, pathlib, re, shutil, sys, time
HERE=pathlib.Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'experiments/s-prep/fivehour-connected-gates'));import supervisor
import importlib.util
spec=importlib.util.spec_from_file_location("relation_tool_pins",HERE/"tool-pins.py");tool_pins=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool_pins)
from validate import validate as validate_reference
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
MUTANTS={"overflowing-old-bound":("relation-cleanup.bend",'owner_blocks(~S,~C,~R,~E,~clear,~record,nodes,drive(~S,~C,~R,~E,~clear,~record,1n,[G.CleanupEnter{id}],world,namespace,descriptors),nodes,edges,namespace,descriptors)','drive(~S,~C,~R,~E,~clear,~record,Nat.add(1n,Nat.mul(nodes,Nat.mul(Nat.add(List.length(&2,G.Edge<S>,edges),Nat.add(nodes,1n)),Nat.add(3n,Nat.add(Nat.mul(2n,List.length(&2,G.Descriptor<S>,descriptors)),Nat.mul(2n,List.length(&2,G.Edge<S>,edges))))))),[G.CleanupEnter{id}],world,namespace,descriptors)')}
NEGATIVES={
 'negative-affine':'consumed more than once',
 'negative-cross-schema':'W.Handle<O.Other>',
 'negative-owner-inspect':'observed : H',
 'negative-undeclared':'observed : relation_write',
 'negative-write-through-read':'observed : P.ReadOnly',
 'negative-inverse-write':'observed : Cap.Request',
 'negative-cleanup-cross-schema':'observed : W.Handle<O.Other>',
 'negative-cleanup-write-through-read':'observed : P.ReadOnly',
 'negative-clear-graph':'observed : O.Components',
 'negative-clear-world':'observed : O.Components',
}
NEGATIVE_SPANS={'negative-affine': 'def bad(owner: O.Payload) -> O.Payload & O.Payload:', 'negative-cross-schema': 'P.relate_live(H,O.Workshop,caps,owner,P.Targets{foreign,target})', 'negative-owner-inspect': 'W.namespace(~O.Workshop,~A.Store<O.Workshop,O.Components<O.Workshop>>,~U32,~A.Notice<O.Workshop,U32>,owner)', 'negative-undeclared': 'P.relate_live(H,S,relation_write,owner,args)', 'negative-write-through-read': 'P.relate_live(H,S,caps,owner,args)', 'negative-inverse-write': 'case P.ReadOnly{inverse}: replace_inverse(H,S,inverse,owner)', 'negative-cleanup-cross-schema': 'C.body(~O.Workshop,H,caps,handle,owner)', 'negative-cleanup-write-through-read': 'C.body(~O.Workshop,H,caps,handle,owner)', 'negative-clear-graph': 'A.graph_read(~S,~O.Components<S>,components)', 'negative-clear-world': 'W.namespace(~S,~A.Store<S,O.Components<S>>,~U32,~A.Notice<S,U32>,components)'}
OWNERS={1:[100,10],2:[200,20,21],3:[300,30,31,32,33],4:[400,40,41,42,43,44,45,46,47]}
def expected():
 result=[]
 for root in ['Workshop','Other']:
  result.append(root)
  for phase in ['before','queued','after']:
   owners=''.join(('absent' if phase=='after' and id==1 else ''.join(str(x)+',' for x in OWNERS[id]))+';' for id in range(1,5))
   inverse=':' if phase=='after' else ':1,'
   events='Removed:1;Original:100100;Original:100010;Original:1001;' if phase=='after' else ''
   result.append(phase+'|'+owners+'|'+inverse+'|events='+events+'|meta=1,131073,131072,262144,18,77,2,0|pending='+('1' if phase=='queued' else '0')+'|all-live-shape=true|all-graph-fields=true')
 return result

def validate(out,mutant):
 assert not mutant
 assert out.splitlines()==expected(),(out.splitlines(),expected())
 return []
def portable(out):
 records=[];root=None
 for line in out.splitlines():
  if line in ['Workshop','Other']:root=line;continue
  fields=line.split('|');phase=fields[0]
  owners=[[id,[int(x) for x in owner.split(',') if x]] for id,owner in enumerate(fields[1].split(';')[:-1],1) if owner!='absent']
  records.append({'root':root,'phase':phase,'count':131072,'liveCount':131071 if phase=='after' else 131072,'owners':owners,'allLiveShape':fields[-2]=='all-live-shape=true','allGraphFields':fields[-1]=='all-graph-fields=true','removed':[1] if phase=='after' else [],'despawned':[1] if phase=='after' else []})
 return records

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');args=ap.parse_args()
 out=HERE/'evidence'/('large-'+str(time.time_ns()));out.mkdir(parents=True)
 files=set(HERE.glob('*.bend'))|set(HERE.glob('*.py'))|set(HERE.glob('*.mjs'))|{pathlib.Path(supervisor.__file__).resolve(),ROOT/'docs/parity/source-review.json'}
 files|=set((ROOT/'.references/bevy-ts/packages/core/src').rglob('*.ts'))
 files|=set((ROOT/'.references/bend2/bend2').rglob('*.ts'))
 files|={pathlib.Path('/home/node/.bend/check.json')}
 tools=tool_pins.snapshot();files|={pathlib.Path(p) for p in tools['pins']}
 for p in ROOT.joinpath('src/ecs').glob('*.bend'):files.add(p)
 pins={str(p):sha(p) for p in sorted(files)};stages={};generated={}
 receipt={'status':'INCOMPLETE','scope':'derivedNat candidate automatic cleanup, actual registered arbitrary-Type owner/adaptor; complete219-step subject, no production delivery/proofs/keyed retention acceptance','pins':pins,'tools':tools,'stages':stages,'commands':[],'limits':{'checker':5,'emission':30,'clang':120,'runtime':5}}
 def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 def inventory(stage):return {str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*.bend'))}
 def guard():
  tool_pins.verify(tools)
  assert all(sha(p)==h for p,h in pins.items()),'input source drift'
  assert all(inventory(pathlib.Path(d['path']))==d['derivedInventory'] for d in stages.values()),'stage drift'
  assert all(sha(p)==h for p,h in generated.items()),'generated drift'
 def run(argv,cap,expected=0):
  guard();argv=['taskset','-c','10',*map(str,argv)]
  try:code,text=supervisor.execute(argv,cap,env={**os.environ,'BENDVY_CLANG19_ROOT':'/tmp/bendvy-clang19-diagnostic/root','BEND_NO_TELEMETRY':'1'})
  except Exception as e:receipt['commands'].append({'argv':argv,'capSeconds':cap,'error':repr(e)});save();raise
  guard();log=out/('command-'+str(len(receipt['commands']))+'.txt');log.write_text(text)
  receipt['commands'].append({'argv':argv,'capSeconds':cap,'exit':code,'log':str(log),'sha256':sha(log)});save();assert code==expected,(code,text);return text
 try:
  normal={str(p.relative_to(ROOT)):sha(p) for p in list(HERE.glob('*.bend'))+list((ROOT/'src/ecs').glob('*.bend'))}
  for name in ['normal',*MUTANTS]:
   stage=out/name
   for path,h in normal.items():dst=stage/path;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/path,dst);assert sha(dst)==h
   assert inventory(stage)==normal
   if name in MUTANTS:
    filename,old,new=MUTANTS[name];file=stage/'experiments/public-relations/production-candidate-v2'/filename;text=file.read_text();assert text.count(old)==1,(name,text.count(old));file.write_text(text.replace(old,new))
   derived=inventory(stage);changes={k:{'original':normal[k],'intentional':v} for k,v in derived.items() if normal[k]!=v};assert len(changes)==(0 if name=='normal' else 1)
   stages[name]={'path':str(stage),'normalInventory':normal,'derivedInventory':derived,'intentionalChanges':changes}
  guard();save()
  # Preflight records deliberate mutant bytes, source closure, imported supervisor;
  # all operations below recheck both normal and every mutant stage.
  if not args.execute:receipt['status']='GUARDED_LARGE_STRUCTURAL_BUDGET_PREFLIGHT_ONLY';save();print(out,receipt['status']);return 0
  run(['bend','version'],5);run(['bend','guide'],5)
  for name,h in json.loads((ROOT/'docs/parity/source-review.json').read_text())['references'].items():assert run(['git','-C',ROOT/'.references'/name,'rev-parse','HEAD'],5).strip()==h
  reference=run(['node',HERE/'reference.mjs'],5);validate_reference([json.loads(line) for line in reference.splitlines()]);receipt['freshTSReferenceSHA256']=hashlib.sha256(reference.encode()).hexdigest()
  foreign=run(['node',HERE/'foreign-reference.mjs'],5);receipt['freshTSForeignSHA256']=hashlib.sha256(foreign.encode()).hexdigest()
  cleanupTS=run(['node',HERE/'large-reference.mjs'],5);tsExpected=[json.loads(line) for line in cleanupTS.splitlines()];assert portable('\n'.join(expected()))==tsExpected;receipt['actualCleanupTS']=tsExpected
  receipt['negativeResults']=[]
  for name,diagnostic in NEGATIVES.items():
   entry=pathlib.Path(stages['normal']['path'])/'experiments/public-relations/production-candidate-v2'/(name+'.bend');text=run(['bend',entry,'--check-only'],5,1);assert diagnostic in text;span=re.search(r'^\s*(\d+)>\|\s*(.*)$',text,re.M);assert span,(name,'missing diagnostic span');line=int(span.group(1));body=span.group(2).strip();assert entry.read_text().splitlines()[line-1].strip()==body==NEGATIVE_SPANS[name],(name,line,body);receipt['negativeResults'].append({'case':name,'intendedDiagnostic':diagnostic,'sourceSpan':{'line':line,'source':body,'inputSHA256':sha(entry)}})
  receipt['results']=[]
  for name,d in stages.items():
   stage=pathlib.Path(d['path']);entry=stage/'experiments/public-relations/production-candidate-v2/large-owned.bend';run(['bend',entry,'--check-only'],5)
   for backend in ['js','native']:
    code=stage/('world.js' if backend=='js' else 'world.c');assert not code.exists();run(['bend',entry,'-o',code],30);generated[str(code)]=sha(code)
    if backend=='native':
     binary=stage/'world-native';assert not binary.exists();run(['/tmp/bendvy-clang19-diagnostic/clang19','-O3',code,'-pthread','-lm','-o',binary],120);generated[str(binary)]=sha(binary);argv=[binary,'--threads','1','--gpu','off']
    else:argv=['node',code]
    if name!='normal':
     text=run(argv,5,1);assert 'a Nat past the largest immediate 2^48-1' in text,text
     receipt['results'].append({'case':name,'backend':backend,'observedFailStop':'Nat past 2^48-1','notSemanticCompletion':True});continue
    text=run(argv,5);witnesses=validate(text,False);
    if name=='normal':assert portable(text)==tsExpected
    receipt['results'].append({'case':name,'backend':backend,'witnesses':witnesses,'checkpointCount':6})
  guard();receipt['generatedPins']=generated;receipt['status']='FINITE_LARGE_STRUCTURAL_BUDGET_AND_OLD_OVERFLOW_FAILSTOP_PASS'
 except Exception as e:receipt['status']='FAIL';receipt['error']=repr(e)
 finally:save()
 print(out,receipt['status']);return 0 if receipt['status']=='FINITE_LARGE_STRUCTURAL_BUDGET_AND_OLD_OVERFLOW_FAILSTOP_PASS' else 1
if __name__=='__main__':sys.exit(main())
