import pathlib,re,json,hashlib
base=pathlib.Path('experiments/public-relations/production-candidate-v5/evidence/cleanup-1791366078591710869')
names='units|edge_units|descriptor_units|block|node_blocks|phase_blocks|owner_blocks|automatic_start|automatic_inventory|automatic'
results={}
for extension in ['js','c']:
 p=base/'normal'/('world.'+extension)
 if not p.exists():continue
 s=p.read_text();starts=list(re.finditer(r'^function ([^\n(]+)\(',s,re.M)) if extension=='js' else list(re.finditer(r'^  WL_CASE\(([^)]+)\)',s,re.M))
 selected=[]
 for i,m in enumerate(starts):
  symbol=m.group(1);matches=re.search(r'\$relation\$045cleanup\$058('+names+r')\$',symbol) if extension=='js' else re.match(r'FID_RELATION_CLEANUP_('+names.upper()+r')_(?:[01])(?:_K\d+)?$',symbol)
  if not matches:continue
  body=s[m.start():starts[i+1].start() if i+1<len(starts) else len(s)]
  forbidden=[x for x in ['nat_mul(', 'nat_add(', 'FID_NAT_MUL','FID_NAT_ADD'] if x in body];assert not forbidden,(symbol,forbidden)
  selected.append({'symbol':symbol,'line':s.count('\n',0,m.start())+1,'bodySHA256':hashlib.sha256(body.encode()).hexdigest(),'bytes':len(body),'forbiddenNatAggregateTokens':forbidden})
 assert selected
 results[extension]={'input':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'selectedBudgetFamilies':selected}
out=base/'generated-budget-inspection.json';out.write_text(json.dumps({'scope':'bounded exact emitted budget-family inspection, not compiler refinement/proof','checks':results},indent=2)+'\n');print({k:len(v['selectedBudgetFamilies']) for k,v in results.items()})
