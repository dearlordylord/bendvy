function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  const _x_0 = ($run$1261$());
  const _x_1 = ($run$1260$());
  const _x_2 = ("\n" + _x_0);
  return (_x_3) => $IO$print$((_x_1 + _x_2), _x_3);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $run$1260$() {
  return $created$1260$(($$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047src$047ecs$047world$058factory$()), 77)));
}

function $run$1261$() {
  return $created$1261$(($$$$047$$$047src$047ecs$047world$058create$1261$(($$$$047$$$047src$047ecs$047world$058factory$()), 77)));
}

function $created$1260$(_result_0) {
  if (_result_0.$ === "../../src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $initial$1260$(_world_0);
  } else {
    return "CREATE_REJECTED";
  }
}

function $$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $created$1261$(_result_0) {
  if (_result_0.$ === "../../src/ecs/world.Created") {
    const _world_0 = _result_0["world"];
    return $initial$1261$(_world_0);
  } else {
    return "CREATE_REJECTED";
  }
}

function $$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $initial$1260$(_world_0) {
  return $record$1260$(($observe_complete$1260$(($spawn$1260$(4, _world_0)))), run_clo((_x_0) => {
  return $successful_queue$1260$(_x_0);
}));
}

function $$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../src/ecs/world.CreateRejected", "factory": {$: "../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../src/ecs/world.Created", "factory": {$: "../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($empty$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $initial$1261$(_world_0) {
  return $record$1261$(($observe_complete$1261$(($spawn$1261$(4, _world_0)))), run_clo((_x_0) => {
  return $successful_queue$1261$(_x_0);
}));
}

function $$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../src/ecs/world.CreateRejected", "factory": {$: "../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../src/ecs/world.Created", "factory": {$: "../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($empty$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $record$1260$(_result_0, _next_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = _next_0(_world_0);
  const _x_1 = ("\n" + _x_0);
  return (_value_0 + _x_1);
}

function $observe_complete$1260$(_world_0) {
  return $pending_join$1260$(($metadata$1260$(($observe_complete_join$1260$(($observe$1260$(_world_0)))))));
}

function $spawn$1260$($0, $1) {
  for (;;) {
    {
      const _n_0 = $0;
      const _world_0 = $1;
      if (_n_0 === 0) {
        return _world_0;
      } else {
        const _rest_0 = (_n_0 - 1);
        $0 = _rest_0;
        $1 = ($reserved$1260$(($$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0))));
        continue;
      }
    }
  }
}

function $successful_queue$1260$(_world_0) {
  return $foreign_source_done$1260$(($world$045adapter$058queue_relate$1260$(($set$1260$(($set$1260$(($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), 3, 1)), 2, 1)), {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, {$: "../../src/ecs/world.Handle", "namespace": 2, "id": 3}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": 2})));
}

function $empty$1260$(__0) {
  return $world$045adapter$058empty$1260$({$: "Components", "column": {$: "../../src/ecs/column.Column", "values": array_node(array_node([{$: "Some", "value": {$: "Payload", "cells": [10], "tag": 100}}], [{$: "Some", "value": {$: "Payload", "cells": array_node([20], [21]), "tag": 200}}]), array_node([{$: "Some", "value": {$: "Payload", "cells": array_node(array_node([30], [31]), array_node([32], [33])), "tag": 300}}], [{$: "Some", "value": {$: "Payload", "cells": array_node(array_node(array_node([40], [41]), array_node([42], [43])), array_node(array_node([44], [45]), array_node([46], [47]))), "tag": 400}}])), "stamps": {$: "Nil"}}});
}

function $record$1261$(_result_0, _next_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = _next_0(_world_0);
  const _x_1 = ("\n" + _x_0);
  return (_value_0 + _x_1);
}

function $observe_complete$1261$(_world_0) {
  return $pending_join$1261$(($metadata$1261$(($observe_complete_join$1261$(($observe$1261$(_world_0)))))));
}

function $spawn$1261$($0, $1) {
  for (;;) {
    {
      const _n_0 = $0;
      const _world_0 = $1;
      if (_n_0 === 0) {
        return _world_0;
      } else {
        const _rest_0 = (_n_0 - 1);
        $0 = _rest_0;
        $1 = ($reserved$1261$(($$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0))));
        continue;
      }
    }
  }
}

function $successful_queue$1261$(_world_0) {
  return $foreign_source_done$1261$(($world$045adapter$058queue_relate$1261$(($set$1261$(($set$1261$(($$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), 3, 1)), 2, 1)), {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, {$: "../../src/ecs/world.Handle", "namespace": 2, "id": 3}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": 2})));
}

function $empty$1261$(__0) {
  return $world$045adapter$058empty$1261$({$: "Components", "column": {$: "../../src/ecs/column.Column", "values": array_node(array_node([{$: "Some", "value": {$: "Payload", "cells": [10], "tag": 100}}], [{$: "Some", "value": {$: "Payload", "cells": array_node([20], [21]), "tag": 200}}]), array_node([{$: "Some", "value": {$: "Payload", "cells": array_node(array_node([30], [31]), array_node([32], [33])), "tag": 300}}], [{$: "Some", "value": {$: "Payload", "cells": array_node(array_node(array_node([40], [41]), array_node([42], [43])), array_node(array_node([44], [45]), array_node([46], [47]))), "tag": 400}}])), "stamps": {$: "Nil"}}});
}

function $pending_join$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $pending_observed$1260$(($$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0)), _value_0);
}

function $metadata$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _cap_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSys_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = ($U32$show$(_nextSys_0));
  const _x_2 = ("," + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_resource_0));
  const _x_5 = ("," + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$((_depth_0 >>> 0)));
  const _x_8 = ("," + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_cap_0));
  const _x_11 = ("," + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($U32$show$(_high_0));
  const _x_14 = ("," + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($U32$show$(_next_0));
  const _x_17 = ("," + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($U32$show$(_ns_0));
  const _x_20 = ("," + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ("|meta=" + _x_21);
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSys_0, "clock": _clock_0}, "snd": (_value_0 + _x_22)};
}

function $observe_complete_join$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _owners_0 = _result_0["snd"];
  return $observe_notices$1260$(($$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _owners_0);
}

function $observe$1260$(_world_0) {
  return $$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $observe_store$1260$(_x_0);
}), _world_0);
}

function $reserved$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $activated$1260$(($$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return _world_0;
  }
}

function $$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $foreign_source_done$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "world-adapter.MissingEntity") {
    const _x_0 = ($foreign_done$1260$(($world$045adapter$058queue_relate$1260$(_tx_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": 3}, {$: "../../src/ecs/world.Handle", "namespace": 2, "id": 2}))));
    return ("foreign-source=MissingEntity\n" + _x_0);
  } else {
    const _x_1 = ($foreign_done$1260$(($world$045adapter$058queue_relate$1260$(_tx_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": 3}, {$: "../../src/ecs/world.Handle", "namespace": 2, "id": 2}))));
    return ("foreign-source=Queued\n" + _x_1);
  }
}

function $world$045adapter$058queue_relate$1260$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $world$045adapter$058queue_namespaced$1260$(($$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $set$1260$(_tx_0, _source_0, _target_0) {
  return $queue_done$1260$(($world$045adapter$058queue_relate$1260$(_tx_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": _source_0}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": _target_0})));
}

function $$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $world$045adapter$058empty$1260$(_components_0) {
  return {$: "world-adapter.Store", "components": _components_0, "graph": {$: "types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $pending_join$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $pending_observed$1261$(($$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0)), _value_0);
}

function $metadata$1261$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _ns_0 = _t_0["namespace"];
  const _next_0 = _t_0["nextId"];
  const _high_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _cap_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSys_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = ($U32$show$(_nextSys_0));
  const _x_2 = ("," + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_resource_0));
  const _x_5 = ("," + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$((_depth_0 >>> 0)));
  const _x_8 = ("," + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_cap_0));
  const _x_11 = ("," + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($U32$show$(_high_0));
  const _x_14 = ("," + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($U32$show$(_next_0));
  const _x_17 = ("," + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($U32$show$(_ns_0));
  const _x_20 = ("," + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ("|meta=" + _x_21);
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSys_0, "clock": _clock_0}, "snd": (_value_0 + _x_22)};
}

function $observe_complete_join$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _owners_0 = _result_0["snd"];
  return $observe_notices$1261$(($$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _owners_0);
}

function $observe$1261$(_world_0) {
  return $$$$047$$$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $observe_store$1261$(_x_0);
}), _world_0);
}

function $reserved$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $activated$1261$(($$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return _world_0;
  }
}

function $$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $foreign_source_done$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "world-adapter.MissingEntity") {
    const _x_0 = ($foreign_done$1261$(($world$045adapter$058queue_relate$1261$(_tx_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": 3}, {$: "../../src/ecs/world.Handle", "namespace": 2, "id": 2}))));
    return ("foreign-source=MissingEntity\n" + _x_0);
  } else {
    const _x_1 = ($foreign_done$1261$(($world$045adapter$058queue_relate$1261$(_tx_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": 3}, {$: "../../src/ecs/world.Handle", "namespace": 2, "id": 2}))));
    return ("foreign-source=Queued\n" + _x_1);
  }
}

function $world$045adapter$058queue_relate$1261$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $world$045adapter$058queue_namespaced$1261$(($$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $set$1261$(_tx_0, _source_0, _target_0) {
  return $queue_done$1261$(($world$045adapter$058queue_relate$1261$(_tx_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": _source_0}, {$: "../../src/ecs/world.Handle", "namespace": 1, "id": _target_0})));
}

function $$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $world$045adapter$058empty$1261$(_components_0) {
  return {$: "world-adapter.Store", "components": _components_0, "graph": {$: "types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $pending_observed$1260$(_result_0, _value_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_count_0));
  const _x_1 = ("|pending=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_value_0 + _x_1)};
}

function $$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $observe_notices$1260$(_result_0, _owners_0) {
  const _world_0 = _result_0["fst"];
  const _notices_0 = _result_0["snd"];
  const _x_0 = ($show_notices$1260$(_notices_0));
  const _x_1 = ("|events=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_owners_0 + _x_1)};
}

function $$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $observe_store$1260$(_store_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _graph_0 = _store_0["graph"];
  return $observe_store_done$1260$(($observe_column$1260$(4, _column_0, 1)), _graph_0);
}

function $activated$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.ReservationRejected", "error": {$: "../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $foreign_done$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "world-adapter.MissingEntity") {
    const _x_1 = ($record$1260$(($observe_complete$1260$(($commit$1260$(_tx_0, {$: "../../src/ecs/transaction.Success"})))), run_clo((_x_0) => {
  return $successful_barrier$1260$(_x_0);
})));
    return ("foreign-target=MissingEntity\n" + _x_1);
  } else {
    const _x_3 = ($record$1260$(($observe_complete$1260$(($commit$1260$(_tx_0, {$: "../../src/ecs/transaction.Success"})))), run_clo((_x_2) => {
  return $successful_barrier$1260$(_x_2);
})));
    return ("foreign-target=Queued\n" + _x_3);
  }
}

function $world$045adapter$058queue_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $world$045adapter$058queue_checked$1260$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $queue_done$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  return _tx_0;
}

function $pending_observed$1261$(_result_0, _value_0) {
  const _world_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_count_0));
  const _x_1 = ("|pending=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_value_0 + _x_1)};
}

function $$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $observe_notices$1261$(_result_0, _owners_0) {
  const _world_0 = _result_0["fst"];
  const _notices_0 = _result_0["snd"];
  const _x_0 = ($show_notices$1261$(_notices_0));
  const _x_1 = ("|events=" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_owners_0 + _x_1)};
}

function $$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $observe_store$1261$(_store_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _graph_0 = _store_0["graph"];
  return $observe_store_done$1261$(($observe_column$1261$(4, _column_0, 1)), _graph_0);
}

function $activated$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.ReservationRejected", "error": {$: "../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $foreign_done$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "world-adapter.MissingEntity") {
    const _x_1 = ($record$1261$(($observe_complete$1261$(($commit$1261$(_tx_0, {$: "../../src/ecs/transaction.Success"})))), run_clo((_x_0) => {
  return $successful_barrier$1261$(_x_0);
})));
    return ("foreign-target=MissingEntity\n" + _x_1);
  } else {
    const _x_3 = ($record$1261$(($observe_complete$1261$(($commit$1261$(_tx_0, {$: "../../src/ecs/transaction.Success"})))), run_clo((_x_2) => {
  return $successful_barrier$1261$(_x_2);
})));
    return ("foreign-target=Queued\n" + _x_3);
  }
}

function $world$045adapter$058queue_namespaced$1261$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $world$045adapter$058queue_checked$1261$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $queue_done$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  return _tx_0;
}

function $$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $show_notices$1260$(_notices_0) {
  if (_notices_0.$ === "Nil") {
    return "";
  } else {
    const _notice_0 = _notices_0["head"];
    const _rest_0 = _notices_0["tail"];
    const _x_0 = ($show_notices$1260$(_rest_0));
    const _x_1 = ($show_notice$1260$(_notice_0));
    const _x_2 = (";" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $observe_store_done$1260$(_result_0, _graph_0) {
  const _column_0 = _result_0["fst"];
  const _owners_0 = _result_0["snd"];
  const _x_0 = ($show_ids$(run_loop($graph$045core$058inverse$1260$(_graph_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, 2))));
  const _x_1 = ($show_ids$(run_loop($graph$045core$058inverse$1260$(_graph_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, 1))));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|" + _x_3);
  return {$: "Tuple", "fst": {$: "world-adapter.Store", "components": {$: "Components", "column": _column_0}, "graph": _graph_0}, "snd": (_owners_0 + _x_4)};
}

function $observe_column$1260$(_n_0, _column_0, _id_0) {
  if (_n_0 === 0) {
    return {$: "Tuple", "fst": _column_0, "snd": ""};
  } else {
    const _rest_0 = (_n_0 - 1);
    return $observed_column$1260$(($$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0)), run_clo((_x_0) => {
  return $observe_column$1260$(_rest_0, _x_0, ((_id_0 + 1) >>> 0));
}));
  }
}

function $$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Reserved", "handle": {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $commit$1260$(_tx_0, _outcome_0) {
  return $finish$1260$(($$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0)));
}

function $successful_barrier$1260$(_world_0) {
  return $record$1260$(($observe_complete$1260$(run_loop($$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)))), run_clo((_x_0) => {
  return $failed_system$1260$(_x_0);
}));
}

function $world$045adapter$058queue_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "world-adapter.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $world$045adapter$058apply_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "world-adapter.Queued"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $show_notices$1261$(_notices_0) {
  if (_notices_0.$ === "Nil") {
    return "";
  } else {
    const _notice_0 = _notices_0["head"];
    const _rest_0 = _notices_0["tail"];
    const _x_0 = ($show_notices$1261$(_rest_0));
    const _x_1 = ($show_notice$1261$(_notice_0));
    const _x_2 = (";" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $observe_store_done$1261$(_result_0, _graph_0) {
  const _column_0 = _result_0["fst"];
  const _owners_0 = _result_0["snd"];
  const _x_0 = ($show_ids$(run_loop($graph$045core$058inverse$1261$(_graph_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, 2))));
  const _x_1 = ($show_ids$(run_loop($graph$045core$058inverse$1261$(_graph_0, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "types.Ordinary"}}, 1))));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|" + _x_3);
  return {$: "Tuple", "fst": {$: "world-adapter.Store", "components": {$: "Components", "column": _column_0}, "graph": _graph_0}, "snd": (_owners_0 + _x_4)};
}

function $observe_column$1261$(_n_0, _column_0, _id_0) {
  if (_n_0 === 0) {
    return {$: "Tuple", "fst": _column_0, "snd": ""};
  } else {
    const _rest_0 = (_n_0 - 1);
    return $observed_column$1261$(($$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)), run_clo((_x_0) => {
  return $observe_column$1261$(_rest_0, _x_0, ((_id_0 + 1) >>> 0));
}));
  }
}

function $$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Reserved", "handle": {$: "../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $commit$1261$(_tx_0, _outcome_0) {
  return $finish$1261$(($$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0)));
}

function $successful_barrier$1261$(_world_0) {
  return $record$1261$(($observe_complete$1261$(run_loop($$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0)))), run_clo((_x_0) => {
  return $failed_system$1261$(_x_0);
}));
}

function $world$045adapter$058queue_checked$1261$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "world-adapter.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $world$045adapter$058apply_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "world-adapter.Queued"}};
  }
}

function $$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $show_notice$1260$(_notice_0) {
  if (_notice_0.$ === "world-adapter.Original") {
    const _event_0 = _notice_0["event"];
    const _x_0 = ($U32$show$(_event_0));
    return ("Original:" + _x_0);
  } else if (_notice_0.$ === "world-adapter.CleanupPaused") {
    return "CLEANUP_INCOMPLETE";
  } else if (_notice_0.$ === "world-adapter.ComponentRemoved") {
    const _id_0 = _notice_0["id"];
    const _x_1 = ($U32$show$(_id_0));
    return ("Removed:" + _x_1);
  } else {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    const _name_0 = _t_1["name"];
    const _inv_0 = _t_1["inverseName"];
    const _source_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _error_0 = _t_0["error"];
    const _x_2 = ($show_error$(_error_0));
    const _x_3 = ($U32$show$(_target_0));
    const _x_4 = (":" + _x_2);
    const _x_5 = (_x_3 + _x_4);
    const _x_6 = ($U32$show$(_source_0));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = (":" + _x_8);
    const _x_10 = (_inv_0 + _x_9);
    const _x_11 = (":" + _x_10);
    const _x_12 = (_name_0 + _x_11);
    const _x_13 = ($U32$show$(_key_0));
    const _x_14 = (":" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    return ("Failure:" + _x_15);
  }
}

function $show_ids$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = ($show_ids$(_rest_0));
    const _x_2 = ($U32$show$(_x_0));
    const _x_3 = ("," + _x_1);
    return (_x_2 + _x_3);
  }
}

function $graph$045core$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $graph$045core$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0);
}

function $observed_column$1260$(_result_0, _next_0) {
  const _column_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $observed_tail$1260$(_next_0(_column_0), ($show_maybe$(_value_0)));
}

function $$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.Rejected", "error": {$: "../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Accepted"}};
  }
}

function $finish$1260$(_result_0) {
  const _world_0 = _result_0["world"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $failed_system$1260$(_world_0) {
  return $record$1260$(($observe_complete$1260$(($commit$1260$(($set$1260$(($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), 1, 2)), {$: "../../src/ecs/transaction.Failure", "error": 99})))), run_clo((_x_0) => {
  return $failed_after$1260$(_x_0);
}));
}

function $$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $world$045adapter$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $world$045adapter$058apply_source$1260$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $show_notice$1261$(_notice_0) {
  if (_notice_0.$ === "world-adapter.Original") {
    const _event_0 = _notice_0["event"];
    const _x_0 = ($U32$show$(_event_0));
    return ("Original:" + _x_0);
  } else if (_notice_0.$ === "world-adapter.CleanupPaused") {
    return "CLEANUP_INCOMPLETE";
  } else if (_notice_0.$ === "world-adapter.ComponentRemoved") {
    const _id_0 = _notice_0["id"];
    const _x_1 = ($U32$show$(_id_0));
    return ("Removed:" + _x_1);
  } else {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    const _name_0 = _t_1["name"];
    const _inv_0 = _t_1["inverseName"];
    const _source_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _error_0 = _t_0["error"];
    const _x_2 = ($show_error$(_error_0));
    const _x_3 = ($U32$show$(_target_0));
    const _x_4 = (":" + _x_2);
    const _x_5 = (_x_3 + _x_4);
    const _x_6 = ($U32$show$(_source_0));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = (":" + _x_8);
    const _x_10 = (_inv_0 + _x_9);
    const _x_11 = (":" + _x_10);
    const _x_12 = (_name_0 + _x_11);
    const _x_13 = ($U32$show$(_key_0));
    const _x_14 = (":" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    return ("Failure:" + _x_15);
  }
}

function $graph$045core$058inverse$1261$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $graph$045core$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0);
}

function $observed_column$1261$(_result_0, _next_0) {
  const _column_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return $observed_tail$1261$(_next_0(_column_0), ($show_maybe$(_value_0)));
}

function $$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../src/ecs/world.Rejected", "error": {$: "../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../src/ecs/world.Accepted"}};
  }
}

function $finish$1261$(_result_0) {
  const _world_0 = _result_0["world"];
  return _world_0;
}

function $$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $failed_system$1261$(_world_0) {
  return $record$1261$(($observe_complete$1261$(($commit$1261$(($set$1261$(($$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), 1, 2)), {$: "../../src/ecs/transaction.Failure", "error": 99})))), run_clo((_x_0) => {
  return $failed_after$1261$(_x_0);
}));
}

function $$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $world$045adapter$058apply_relate$1261$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $world$045adapter$058apply_source$1261$(($$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $show_error$(_error_0) {
  if (_error_0.$ === "types.MissingEntity") {
    const _source_0 = _error_0["source"];
    const _x_0 = ($U32$show$(_source_0));
    return ("MissingEntity:" + _x_0);
  } else if (_error_0.$ === "types.MissingTargetEntity") {
    const _source_1 = _error_0["source"];
    const _target_0 = _error_0["target"];
    const _name_0 = _error_0["relation"];
    const _x_1 = ($U32$show$(_target_0));
    const _x_2 = (":" + _name_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_source_1));
    const _x_5 = (":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return ("MissingTargetEntity:" + _x_6);
  } else if (_error_0.$ === "types.SelfRelationNotAllowed") {
    const _source_2 = _error_0["source"];
    const _name_1 = _error_0["relation"];
    const _x_7 = ($U32$show$(_source_2));
    const _x_8 = (":" + _name_1);
    const _x_9 = (_x_7 + _x_8);
    return ("SelfRelationNotAllowed:" + _x_9);
  } else if (_error_0.$ === "types.HierarchyCycle") {
    const _source_3 = _error_0["source"];
    const _target_1 = _error_0["target"];
    const _name_2 = _error_0["relation"];
    const _x_10 = ($U32$show$(_target_1));
    const _x_11 = (":" + _name_2);
    const _x_12 = (_x_10 + _x_11);
    const _x_13 = ($U32$show$(_source_3));
    const _x_14 = (":" + _x_12);
    const _x_15 = (_x_13 + _x_14);
    return ("HierarchyCycle:" + _x_15);
  } else {
    return "UNEXPECTED";
  }
}

function $graph$045core$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1260$(_other_0));
    const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
    return $graph$045core$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $graph$045core$058inverse_entries$1260$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $observed_tail$1260$(_result_0, _head_0) {
  const _column_0 = _result_0["fst"];
  const _tail_0 = _result_0["snd"];
  const _x_0 = (";" + _tail_0);
  return {$: "Tuple", "fst": _column_0, "snd": (_head_0 + _x_0)};
}

function $show_maybe$(_value_0) {
  if (_value_0.$ === "None") {
    return "absent";
  } else {
    const _xs_0 = _value_0["value"];
    return $show_ids$(_xs_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $failed_after$1260$(_world_0) {
  return $record$1260$(($observe_complete$1260$(run_loop($$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)))), run_clo((_x_0) => {
  return $missing_before$1260$(_x_0);
}));
}

function $world$045adapter$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $world$045adapter$058apply_live$1260$(($$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $graph$045core$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1261$(_other_0));
    const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
    return $graph$045core$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $graph$045core$058inverse_entries$1261$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $observed_tail$1261$(_result_0, _head_0) {
  const _column_0 = _result_0["fst"];
  const _tail_0 = _result_0["snd"];
  const _x_0 = (";" + _tail_0);
  return {$: "Tuple", "fst": _column_0, "snd": (_head_0 + _x_0)};
}

function $$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $failed_after$1261$(_world_0) {
  return $record$1261$(($observe_complete$1261$(run_loop($$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0)))), run_clo((_x_0) => {
  return $missing_before$1261$(_x_0);
}));
}

function $world$045adapter$058apply_source$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $world$045adapter$058apply_live$1261$(($$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $graph$045core$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $graph$045core$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $missing_before$1260$(_world_0) {
  return $record$1260$(($observe_complete$1260$(($commit$1260$(($set$1260$(($$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), 9, 1)), {$: "../../src/ecs/transaction.Success"})))), run_clo((_x_0) => {
  return $missing_after$1260$(_x_0);
}));
}

function $world$045adapter$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $world$045adapter$058publish_relate$1260$(($$$$047$$$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $world$045adapter$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $graph$045core$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../src/ecs/transaction.Returned", "world": ($$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $missing_before$1261$(_world_0) {
  return $record$1261$(($observe_complete$1261$(($commit$1261$(($set$1261$(($$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), 9, 1)), {$: "../../src/ecs/transaction.Success"})))), run_clo((_x_0) => {
  return $missing_after$1261$(_x_0);
}));
}

function $world$045adapter$058apply_live$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $world$045adapter$058publish_relate$1261$(($$$$047$$$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $world$045adapter$058store_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($project_payload$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($project_payload$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($project_payload$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $missing_after$1260$(_world_0) {
  return $final$1260$(($observe_complete$1260$(run_loop($$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)))));
}

function $world$045adapter$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": {$: "world-adapter.RelationFailed", "failure": {$: "types.Failure", "relation": _descriptor_0, "operation": {$: "types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $world$045adapter$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $world$045adapter$058relate_result$1260$(($graph$045core$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($project_payload$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($project_payload$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($project_payload$(_owned_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $missing_after$1261$(_world_0) {
  return $final$1261$(($observe_complete$1261$(run_loop($$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0)))));
}

function $world$045adapter$058publish_relate$1261$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "world-adapter.RelationFailed", "failure": {$: "types.Failure", "relation": _descriptor_0, "operation": {$: "types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047src$047ecs$047world$058with_store$1263$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $world$045adapter$058store_relate$1261$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $world$045adapter$058relate_result$1261$(($graph$045core$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $project_payload$(_owner_0) {
  const _cells_0 = _owner_0["cells"];
  const _tag_0 = _owner_0["tag"];
  return $project_payload_sized$({$: "Tuple", fst: _cells_0, snd: _cells_0.length}, _tag_0);
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047src$047ecs$047column$058viewed$1260$(($project_payload$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($project_payload$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../src/ecs/column.Indexed", "state": {$: "../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($project_payload$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($project_payload$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $final$1260$(_result_0) {
  const _value_0 = _result_0["snd"];
  return _value_0;
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $world$045adapter$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "world-adapter.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $graph$045core$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $graph$045core$058checked$1260$(($graph$045core$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($graph$045core$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($graph$045core$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047src$047ecs$047column$058viewed$1261$(($project_payload$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../src/ecs/column.Column", "values": ($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($project_payload$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../src/ecs/column.Indexed", "state": {$: "../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($project_payload$(_owner_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($project_payload$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $final$1261$(_result_0) {
  const _value_0 = _result_0["snd"];
  return _value_0;
}

function $$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $world$045adapter$058relate_result$1261$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "world-adapter.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $graph$045core$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $graph$045core$058checked$1261$(($graph$045core$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($graph$045core$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($graph$045core$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $project_payload_sized$(_result_0, _tag_0) {
  const _cells_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $project_payload_done$(($project_cells$(_size_0, _cells_0, 0)), _tag_0);
}

function $$$$047$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $graph$045core$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "types.CoreResult", "graph": ($graph$045core$058updated$1260$(($graph$045core$058already$(run_loop($graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $graph$045core$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $graph$045core$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "types.Ordinary") {
    return false;
  } else {
    return $graph$045core$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $graph$045core$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $graph$045core$058checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "types.CoreResult", "graph": ($graph$045core$058updated$1261$(($graph$045core$058already$(run_loop($graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $graph$045core$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "types.Ordinary") {
    return false;
  } else {
    return $graph$045core$058cycle_loop$1261$(($List$length$(_edges_0)), {$: "types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $graph$045core$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $project_payload_done$(_result_0, _tag_0) {
  const _cells_0 = _result_0["fst"];
  const _ids_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Payload", "cells": _cells_0, "tag": _tag_0}, "snd": {$: "Con", "head": _tag_0, "tail": _ids_0}};
}

function $project_cells$(_n_0, _cells_0, _index_0) {
  if (_n_0 === 0) {
    return {$: "Tuple", "fst": _cells_0, "snd": {$: "Nil"}};
  } else {
    const _rest_0 = (_n_0 - 1);
    return $cells_done$({$: "Tuple", fst: _cells_0, snd: _cells_0[_index_0 % _cells_0.length]}, run_clo((_x_0) => {
  return $project_cells$(_rest_0, _x_0, ((_index_0 + 1) >>> 0));
}));
  }
}

function $$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $graph$045core$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "types.Graph", "edges": ($List$append$(($graph$045core$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($graph$045core$058inverse_add$1260$(($graph$045core$058remove_previous$1260$(run_loop($graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $graph$045core$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045core$058key$1260$(_other_0));
    const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
    return $graph$045core$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $graph$045core$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $graph$045core$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($graph$045core$058next_cycle$1260$(run_loop($graph$045core$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $graph$045core$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $graph$045core$058updated$1261$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "types.Graph", "edges": ($List$append$(($graph$045core$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($graph$045core$058inverse_add$1261$(($graph$045core$058remove_previous$1261$(run_loop($graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045core$058key$1261$(_other_0));
    const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
    return $graph$045core$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $graph$045core$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $graph$045core$058cycle_loop$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($graph$045core$058next_cycle$1261$(run_loop($graph$045core$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $graph$045core$058cycle_loop$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $cells_done$(_result_0, _next_0) {
  const _cells_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return $cells_next$(_next_0(_cells_0), _id_0);
}

function $$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $graph$045core$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _edge_0 = _edges_0["head"];
    const _rest_0 = _edges_0["tail"];
    return $graph$045core$058remove_edge_fields$1260$(_edge_0, _descriptor_0, _source_0, run_clo((_x_0) => {
  return $graph$045core$058remove_edge$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $graph$045core$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1260$(_other_0));
    const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
    return $graph$045core$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $graph$045core$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $graph$045core$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $graph$045core$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $graph$045core$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $graph$045core$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $graph$045core$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $graph$045core$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _edge_0 = _edges_0["head"];
    const _rest_0 = _edges_0["tail"];
    return $graph$045core$058remove_edge_fields$1261$(_edge_0, _descriptor_0, _source_0, run_clo((_x_0) => {
  return $graph$045core$058remove_edge$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $graph$045core$058inverse_add$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1261$(_other_0));
    const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
    return $graph$045core$058inverse_add_found$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $graph$045core$058inverse_add$1261$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $graph$045core$058remove_previous$1261$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $graph$045core$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $graph$045core$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $graph$045core$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $cells_next$(_result_0, _id_0) {
  const _cells_0 = _result_0["fst"];
  const _ids_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _cells_0, "snd": {$: "Con", "head": _id_0, "tail": _ids_0}};
}

function $$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $graph$045core$058remove_edge_fields$1260$(_edge_0, _descriptor_0, _source_0, _next_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($graph$045core$058key$1260$(_other_0));
  const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
  return $graph$045core$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _next_0({$: "Unit"}));
}

function $graph$045core$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($graph$045core$058appended_source$(($graph$045core$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $graph$045core$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1260$(_other_0));
    const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
    return $graph$045core$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, ($graph$045core$058inverse_remove$1260$(_rest_0, _descriptor_0, _target_0, _source_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../src/ecs/column.Accepted", "column": ($$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $graph$045core$058remove_edge_fields$1261$(_edge_0, _descriptor_0, _source_0, _next_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($graph$045core$058key$1261$(_other_0));
  const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
  return $graph$045core$058edge_removed$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _next_0({$: "Unit"}));
}

function $graph$045core$058inverse_add_found$1261$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($graph$045core$058appended_source$(($graph$045core$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $graph$045core$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1261$(_other_0));
    const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
    return $graph$045core$058inverse_remove_one$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, ($graph$045core$058inverse_remove$1261$(_rest_0, _descriptor_0, _target_0, _source_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $graph$045core$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $graph$045core$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $graph$045core$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($graph$045core$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

function $graph$045core$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $graph$045core$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($graph$045core$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.Prepared", "state": {$: "../../src/ecs/column.Owned", "state": {$: "../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../src/ecs/column.Rejected", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../src/ecs/column.Accepted", "column": {$: "../../src/ecs/column.PreparedIndexed", "state": {$: "../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $graph$045core$058edge_removed$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $graph$045core$058inverse_remove_one$1261$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $graph$045core$058nonempty_inverse$1261$(_descriptor_0, _target_0, ($graph$045core$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $graph$045core$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $graph$045core$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $graph$045core$058removed_id$((_x_0 === _id_0), _x_0, ($graph$045core$058remove_id$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $graph$045core$058nonempty_inverse$1261$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $graph$045core$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);