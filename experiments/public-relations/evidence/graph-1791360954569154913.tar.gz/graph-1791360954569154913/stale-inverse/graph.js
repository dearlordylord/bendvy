function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  const _x_0 = ($run$1261$({$: "types.Hierarchy"}));
  const _x_1 = ($run$1261$({$: "types.Ordinary"}));
  const _x_2 = ("\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($run$1260$({$: "types.Hierarchy"}));
  const _x_5 = ("\n" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($run$1260$({$: "types.Ordinary"}));
  const _x_8 = ("\n" + _x_6);
  return (_x_9) => $IO$print$((_x_7 + _x_8), _x_9);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $run$1260$(_kind_0) {
  return $trace$1260$(($sequence$1260$({$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": _kind_0})), {$: "types.SpecGraph", "edges": {$: "Nil"}}, {$: "types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": _kind_0});
}

function $run$1261$(_kind_0) {
  return $trace$1261$(($sequence$1261$({$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": _kind_0})), {$: "types.SpecGraph", "edges": {$: "Nil"}}, {$: "types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}, {$: "types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": _kind_0});
}

function $trace$1260$(_steps_0, _a_0, _b_0, _d_0) {
  if (_steps_0.$ === "Nil") {
    return "done";
  } else {
    const _step_0 = _steps_0["head"];
    const _rest_0 = _steps_0["tail"];
    return $continuation$1260$(($spec_step$1260$(_step_0, _a_0)), ($core_step$1260$(_step_0, _b_0)), _d_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $trace$1260$(_rest_0, _x_0, _x_1, _d_0);
});
}));
  }
}

function $sequence$1260$(_d_0) {
  return {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 2, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 3}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 3}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 999}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 1, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 2, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 999, "target": 998, "sourceLive": false, "targetLive": false}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 1, "target": 999, "sourceLive": true, "targetLive": false}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 1, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 1}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 2}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 3}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 1, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 2, "target": 3, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": {$: "types.Descriptor", "key": 2, "name": "OtherLink", "inverseName": "OtherLinkedBy", "kind": {$: "types.Ordinary"}}, "source": 3, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Clear", "relation": {$: "types.Descriptor", "key": 2, "name": "OtherLink", "inverseName": "OtherLinkedBy", "kind": {$: "types.Ordinary"}}, "source": 3}, "tail": {$: "Nil"}}}}}}}}}}}}}}}}}}}}}}}};
}

function $trace$1261$(_steps_0, _a_0, _b_0, _d_0) {
  if (_steps_0.$ === "Nil") {
    return "done";
  } else {
    const _step_0 = _steps_0["head"];
    const _rest_0 = _steps_0["tail"];
    return $continuation$1261$(($spec_step$1261$(_step_0, _a_0)), ($core_step$1261$(_step_0, _b_0)), _d_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $trace$1261$(_rest_0, _x_0, _x_1, _d_0);
});
}));
  }
}

function $sequence$1261$(_d_0) {
  return {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 2, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 3}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 3}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 999}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 1, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 2, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 999, "target": 998, "sourceLive": false, "targetLive": false}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 1, "target": 999, "sourceLive": true, "targetLive": false}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 1, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 1}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 2}, "tail": {$: "Con", "head": {$: "Clear", "relation": _d_0, "source": 3}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 1, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 2, "target": 3, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": _d_0, "source": 3, "target": 1, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Set", "relation": {$: "types.Descriptor", "key": 2, "name": "OtherLink", "inverseName": "OtherLinkedBy", "kind": {$: "types.Ordinary"}}, "source": 3, "target": 2, "sourceLive": true, "targetLive": true}, "tail": {$: "Con", "head": {$: "Clear", "relation": {$: "types.Descriptor", "key": 2, "name": "OtherLink", "inverseName": "OtherLinkedBy", "kind": {$: "types.Ordinary"}}, "source": 3}, "tail": {$: "Nil"}}}}}}}}}}}}}}}}}}}}}}}};
}

function $continuation$1260$(_a_0, _b_0, _d_0, _next_0) {
  const _x_0 = _next_0(($next_spec$1260$(_a_0)))(($next_core$1260$(_b_0)));
  const _x_1 = ($line$1260$(_a_0, _b_0, _d_0));
  const _x_2 = ("\n" + _x_0);
  return (_x_1 + _x_2);
}

function $spec_step$1260$(_step_0, _g_0) {
  if (_step_0.$ === "Set") {
    const _d_0 = _step_0["relation"];
    const _s_0 = _step_0["source"];
    const _t_0 = _step_0["target"];
    const _sl_0 = _step_0["sourceLive"];
    const _tl_0 = _step_0["targetLive"];
    return $graph$045spec$058relate$1260$(_g_0, _d_0, _s_0, _t_0, _sl_0, _tl_0);
  } else {
    const _d_1 = _step_0["relation"];
    const _s_1 = _step_0["source"];
    return {$: "types.SpecResult", "graph": ($graph$045spec$058unrelate$1260$(_g_0, _d_1, _s_1)), "error": {$: "None"}};
  }
}

function $core_step$1260$(_step_0, _g_0) {
  if (_step_0.$ === "Set") {
    const _d_0 = _step_0["relation"];
    const _s_0 = _step_0["source"];
    const _t_0 = _step_0["target"];
    const _sl_0 = _step_0["sourceLive"];
    const _tl_0 = _step_0["targetLive"];
    return $graph$045core$058relate$1260$(_g_0, _d_0, _s_0, _t_0, _sl_0, _tl_0);
  } else {
    const _d_1 = _step_0["relation"];
    const _s_1 = _step_0["source"];
    return {$: "types.CoreResult", "graph": ($graph$045core$058unrelate$1260$(_g_0, _d_1, _s_1)), "error": {$: "None"}};
  }
}

function $continuation$1261$(_a_0, _b_0, _d_0, _next_0) {
  const _x_0 = _next_0(($next_spec$1261$(_a_0)))(($next_core$1261$(_b_0)));
  const _x_1 = ($line$1261$(_a_0, _b_0, _d_0));
  const _x_2 = ("\n" + _x_0);
  return (_x_1 + _x_2);
}

function $spec_step$1261$(_step_0, _g_0) {
  if (_step_0.$ === "Set") {
    const _d_0 = _step_0["relation"];
    const _s_0 = _step_0["source"];
    const _t_0 = _step_0["target"];
    const _sl_0 = _step_0["sourceLive"];
    const _tl_0 = _step_0["targetLive"];
    return $graph$045spec$058relate$1261$(_g_0, _d_0, _s_0, _t_0, _sl_0, _tl_0);
  } else {
    const _d_1 = _step_0["relation"];
    const _s_1 = _step_0["source"];
    return {$: "types.SpecResult", "graph": ($graph$045spec$058unrelate$1261$(_g_0, _d_1, _s_1)), "error": {$: "None"}};
  }
}

function $core_step$1261$(_step_0, _g_0) {
  if (_step_0.$ === "Set") {
    const _d_0 = _step_0["relation"];
    const _s_0 = _step_0["source"];
    const _t_0 = _step_0["target"];
    const _sl_0 = _step_0["sourceLive"];
    const _tl_0 = _step_0["targetLive"];
    return $graph$045core$058relate$1261$(_g_0, _d_0, _s_0, _t_0, _sl_0, _tl_0);
  } else {
    const _d_1 = _step_0["relation"];
    const _s_1 = _step_0["source"];
    return {$: "types.CoreResult", "graph": ($graph$045core$058unrelate$1261$(_g_0, _d_1, _s_1)), "error": {$: "None"}};
  }
}

function $line$1260$(_a_0, _b_0, _d_0) {
  const _ga_0 = _a_0["graph"];
  const _ea_0 = _a_0["error"];
  const _gb_0 = _b_0["graph"];
  const _eb_0 = _b_0["error"];
  const _x_0 = ($observe_core$1260$(_gb_0, {$: "types.Descriptor", "key": 2, "name": "OtherLink", "inverseName": "OtherLinkedBy", "kind": {$: "types.Ordinary"}}));
  const _x_1 = ($observe_core$1260$(_gb_0, _d_0));
  const _x_2 = ("#" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($error$(_eb_0));
  const _x_5 = (";" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($observe_spec$1260$(_ga_0, {$: "types.Descriptor", "key": 2, "name": "OtherLink", "inverseName": "OtherLinkedBy", "kind": {$: "types.Ordinary"}}));
  const _x_8 = ("=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($observe_spec$1260$(_ga_0, _d_0));
  const _x_11 = ("#" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($error$(_ea_0));
  const _x_14 = (";" + _x_12);
  return (_x_13 + _x_14);
}

function $next_spec$1260$(_r_0) {
  const _g_0 = _r_0["graph"];
  return _g_0;
}

function $next_core$1260$(_r_0) {
  const _g_0 = _r_0["graph"];
  return _g_0;
}

function $graph$045spec$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $graph$045spec$058apply_checked$1260$(($graph$045spec$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($graph$045spec$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($graph$045spec$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $graph$045spec$058unrelate$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return {$: "types.SpecGraph", "edges": ($graph$045spec$058remove_source$1260$(_edges_0, _descriptor_0, _source_0))};
}

function $graph$045core$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $graph$045core$058checked$1260$(($graph$045core$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($graph$045core$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($graph$045core$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $graph$045core$058unrelate$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  return {$: "types.Graph", "edges": ($graph$045core$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), "inverses": ($graph$045core$058remove_previous$1260$(run_loop($graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0))};
}

function $line$1261$(_a_0, _b_0, _d_0) {
  const _ga_0 = _a_0["graph"];
  const _ea_0 = _a_0["error"];
  const _gb_0 = _b_0["graph"];
  const _eb_0 = _b_0["error"];
  const _x_0 = ($observe_core$1261$(_gb_0, {$: "types.Descriptor", "key": 2, "name": "OtherLink", "inverseName": "OtherLinkedBy", "kind": {$: "types.Ordinary"}}));
  const _x_1 = ($observe_core$1261$(_gb_0, _d_0));
  const _x_2 = ("#" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($error$(_eb_0));
  const _x_5 = (";" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($observe_spec$1261$(_ga_0, {$: "types.Descriptor", "key": 2, "name": "OtherLink", "inverseName": "OtherLinkedBy", "kind": {$: "types.Ordinary"}}));
  const _x_8 = ("=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($observe_spec$1261$(_ga_0, _d_0));
  const _x_11 = ("#" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($error$(_ea_0));
  const _x_14 = (";" + _x_12);
  return (_x_13 + _x_14);
}

function $next_spec$1261$(_r_0) {
  const _g_0 = _r_0["graph"];
  return _g_0;
}

function $next_core$1261$(_r_0) {
  const _g_0 = _r_0["graph"];
  return _g_0;
}

function $graph$045spec$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $graph$045spec$058apply_checked$1261$(($graph$045spec$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($graph$045spec$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($graph$045spec$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $graph$045spec$058unrelate$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return {$: "types.SpecGraph", "edges": ($graph$045spec$058remove_source$1261$(_edges_0, _descriptor_0, _source_0))};
}

function $graph$045core$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $graph$045core$058checked$1261$(($graph$045core$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($graph$045core$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($graph$045core$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $graph$045core$058unrelate$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  return {$: "types.Graph", "edges": ($graph$045core$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), "inverses": ($graph$045core$058remove_previous$1261$(run_loop($graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0))};
}

function $error$(_value_0) {
  if (_value_0.$ === "None") {
    return "ok";
  } else {
    const _t_0 = _value_0["value"];
    if (_t_0.$ === "types.MissingEntity") {
      const _source_0 = _t_0["source"];
      const _x_0 = ($U32$show$(_source_0));
      return ("MissingEntity:" + _x_0);
    } else if (_t_0.$ === "types.MissingTargetEntity") {
      const _source_1 = _t_0["source"];
      const _target_0 = _t_0["target"];
      const _name_0 = _t_0["relation"];
      const _x_1 = ($U32$show$(_target_0));
      const _x_2 = (":" + _name_0);
      const _x_3 = (_x_1 + _x_2);
      const _x_4 = ($U32$show$(_source_1));
      const _x_5 = (":" + _x_3);
      const _x_6 = (_x_4 + _x_5);
      return ("MissingTarget:" + _x_6);
    } else if (_t_0.$ === "types.SelfRelationNotAllowed") {
      const _source_2 = _t_0["source"];
      const _name_1 = _t_0["relation"];
      const _x_7 = ($U32$show$(_source_2));
      const _x_8 = (":" + _name_1);
      const _x_9 = (_x_7 + _x_8);
      return ("Self:" + _x_9);
    } else if (_t_0.$ === "types.HierarchyCycle") {
      const _source_3 = _t_0["source"];
      const _target_1 = _t_0["target"];
      const _name_2 = _t_0["relation"];
      const _x_10 = ($U32$show$(_target_1));
      const _x_11 = (":" + _name_2);
      const _x_12 = (_x_10 + _x_11);
      const _x_13 = ($U32$show$(_source_3));
      const _x_14 = (":" + _x_12);
      const _x_15 = (_x_13 + _x_14);
      return ("Cycle:" + _x_15);
    } else {
      return "UNEXPECTED";
    }
  }
}

function $observe_spec$1260$(_g_0, _d_0) {
  const _x_0 = ($ids$(($graph$045spec$058inverse$1260$(_g_0, _d_0, 3))));
  const _x_1 = ($ids$(($graph$045spec$058inverse$1260$(_g_0, _d_0, 2))));
  const _x_2 = ("|" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($ids$(($graph$045spec$058inverse$1260$(_g_0, _d_0, 1))));
  const _x_5 = ("|" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($maybe_id$(run_loop($graph$045spec$058target$1260$(_g_0, _d_0, 3))));
  const _x_8 = ("|" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($maybe_id$(run_loop($graph$045spec$058target$1260$(_g_0, _d_0, 2))));
  const _x_11 = ("," + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($maybe_id$(run_loop($graph$045spec$058target$1260$(_g_0, _d_0, 1))));
  const _x_14 = ("," + _x_12);
  return (_x_13 + _x_14);
}

function $observe_core$1260$(_g_0, _d_0) {
  const _x_0 = ($ids$(run_loop($graph$045core$058inverse$1260$(_g_0, _d_0, 3))));
  const _x_1 = ($ids$(run_loop($graph$045core$058inverse$1260$(_g_0, _d_0, 2))));
  const _x_2 = ("|" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($ids$(run_loop($graph$045core$058inverse$1260$(_g_0, _d_0, 1))));
  const _x_5 = ("|" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($maybe_id$(run_loop($graph$045core$058target$1260$(_g_0, _d_0, 3))));
  const _x_8 = ("|" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($maybe_id$(run_loop($graph$045core$058target$1260$(_g_0, _d_0, 2))));
  const _x_11 = ("," + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($maybe_id$(run_loop($graph$045core$058target$1260$(_g_0, _d_0, 1))));
  const _x_14 = ("," + _x_12);
  return (_x_13 + _x_14);
}

function $graph$045spec$058apply_checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "types.SpecResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    return {$: "types.SpecResult", "graph": ($graph$045spec$058success$1260$(($graph$045spec$058already$(run_loop($graph$045spec$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $graph$045spec$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $graph$045spec$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "types.Ordinary") {
    return false;
  } else {
    return $graph$045spec$058cycle_at$1260$(($List$length$(_edges_0)), {$: "types.SpecGraph", "edges": _edges_0}, {$: "types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $graph$045spec$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $graph$045spec$058remove_source$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045spec$058key$1260$(_descriptor_0));
    const _x_1 = ($graph$045spec$058key$1260$(_other_0));
    return $graph$045spec$058removed_selected$1260$(($Bool$and$((_x_0 === _x_1), (_source_0 === _id_0))), {$: "types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, ($graph$045spec$058remove_source$1260$(_rest_0, _descriptor_0, _source_0)));
  }
}

function $graph$045core$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "types.CoreResult", "graph": ($graph$045core$058updated$1260$(($graph$045core$058already$(run_loop($graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $graph$045core$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $graph$045core$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "types.Ordinary") {
    return false;
  } else {
    return $graph$045core$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $graph$045core$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $graph$045core$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _edge_0 = _edges_0["head"];
    const _rest_0 = _edges_0["tail"];
    return $graph$045core$058remove_edge_fields$1260$(_edge_0, _descriptor_0, _source_0, run_clo((_x_0) => {
  return $graph$045core$058remove_edge$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $graph$045core$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    return _entries_0;
  }
}

function $graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045core$058key$1260$(_other_0));
    const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
    return $graph$045core$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $graph$045core$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $observe_spec$1261$(_g_0, _d_0) {
  const _x_0 = ($ids$(($graph$045spec$058inverse$1261$(_g_0, _d_0, 3))));
  const _x_1 = ($ids$(($graph$045spec$058inverse$1261$(_g_0, _d_0, 2))));
  const _x_2 = ("|" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($ids$(($graph$045spec$058inverse$1261$(_g_0, _d_0, 1))));
  const _x_5 = ("|" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($maybe_id$(run_loop($graph$045spec$058target$1261$(_g_0, _d_0, 3))));
  const _x_8 = ("|" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($maybe_id$(run_loop($graph$045spec$058target$1261$(_g_0, _d_0, 2))));
  const _x_11 = ("," + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($maybe_id$(run_loop($graph$045spec$058target$1261$(_g_0, _d_0, 1))));
  const _x_14 = ("," + _x_12);
  return (_x_13 + _x_14);
}

function $observe_core$1261$(_g_0, _d_0) {
  const _x_0 = ($ids$(run_loop($graph$045core$058inverse$1261$(_g_0, _d_0, 3))));
  const _x_1 = ($ids$(run_loop($graph$045core$058inverse$1261$(_g_0, _d_0, 2))));
  const _x_2 = ("|" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($ids$(run_loop($graph$045core$058inverse$1261$(_g_0, _d_0, 1))));
  const _x_5 = ("|" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($maybe_id$(run_loop($graph$045core$058target$1261$(_g_0, _d_0, 3))));
  const _x_8 = ("|" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($maybe_id$(run_loop($graph$045core$058target$1261$(_g_0, _d_0, 2))));
  const _x_11 = ("," + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($maybe_id$(run_loop($graph$045core$058target$1261$(_g_0, _d_0, 1))));
  const _x_14 = ("," + _x_12);
  return (_x_13 + _x_14);
}

function $graph$045spec$058apply_checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "types.SpecResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    return {$: "types.SpecResult", "graph": ($graph$045spec$058success$1261$(($graph$045spec$058already$(run_loop($graph$045spec$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $graph$045spec$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "types.Ordinary") {
    return false;
  } else {
    return $graph$045spec$058cycle_at$1261$(($List$length$(_edges_0)), {$: "types.SpecGraph", "edges": _edges_0}, {$: "types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $graph$045spec$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $graph$045spec$058remove_source$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045spec$058key$1261$(_descriptor_0));
    const _x_1 = ($graph$045spec$058key$1261$(_other_0));
    return $graph$045spec$058removed_selected$1261$(($Bool$and$((_x_0 === _x_1), (_source_0 === _id_0))), {$: "types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, ($graph$045spec$058remove_source$1261$(_rest_0, _descriptor_0, _source_0)));
  }
}

function $graph$045core$058checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "types.CoreResult", "graph": ($graph$045core$058updated$1261$(($graph$045core$058already$(run_loop($graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $graph$045core$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "types.Ordinary") {
    return false;
  } else {
    return $graph$045core$058cycle_loop$1261$(($List$length$(_edges_0)), {$: "types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $graph$045core$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $graph$045core$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _edge_0 = _edges_0["head"];
    const _rest_0 = _edges_0["tail"];
    return $graph$045core$058remove_edge_fields$1261$(_edge_0, _descriptor_0, _source_0, run_clo((_x_0) => {
  return $graph$045core$058remove_edge$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $graph$045core$058remove_previous$1261$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    return _entries_0;
  }
}

function $graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045core$058key$1261$(_other_0));
    const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
    return $graph$045core$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $graph$045core$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $maybe_id$(_value_0) {
  if (_value_0.$ === "None") {
    return "none";
  } else {
    const _id_0 = _value_0["value"];
    return $U32$show$(_id_0);
  }
}

function $graph$045spec$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $graph$045spec$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $ids$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _id_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($ids$(_rest_0));
    const _x_1 = ($U32$show$(_id_0));
    const _x_2 = (":" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $graph$045spec$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  return $graph$045spec$058inverse_edges$1260$(_edges_0, _descriptor_0, _target_0);
}

function $graph$045core$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $graph$045core$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $graph$045core$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0);
}

function $graph$045spec$058success$1260$(_same_0, _edges_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "types.SpecGraph", "edges": _edges_0};
  } else {
    return {$: "types.SpecGraph", "edges": ($List$append$(($graph$045spec$058remove_source$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}}))};
  }
}

function $graph$045spec$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $graph$045spec$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045spec$058key$1260$(_descriptor_0));
    const _x_1 = ($graph$045spec$058key$1260$(_other_0));
    return $graph$045spec$058source_chosen$(($Bool$and$((_x_0 === _x_1), (_source_0 === _id_0))), _target_0, run_clo((_x_2) => {
  return $graph$045spec$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $graph$045spec$058cycle_at$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($graph$045spec$058next_cycle$1260$(run_loop($graph$045spec$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $graph$045spec$058cycle_at$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $graph$045spec$058removed_selected$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $graph$045spec$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $graph$045core$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "types.Graph", "edges": ($List$append$(($graph$045core$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($graph$045core$058inverse_add$1260$(($graph$045core$058remove_previous$1260$(run_loop($graph$045core$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $graph$045core$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $graph$045core$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($graph$045core$058next_cycle$1260$(run_loop($graph$045core$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $graph$045core$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $graph$045core$058remove_edge_fields$1260$(_edge_0, _descriptor_0, _source_0, _next_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($graph$045core$058key$1260$(_other_0));
  const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
  return $graph$045core$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _next_0({$: "Unit"}));
}

function $graph$045core$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $graph$045core$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $graph$045spec$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $graph$045spec$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $graph$045spec$058inverse$1261$(_graph_0, _descriptor_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  return $graph$045spec$058inverse_edges$1261$(_edges_0, _descriptor_0, _target_0);
}

function $graph$045core$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $graph$045core$058inverse$1261$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $graph$045core$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0);
}

function $graph$045spec$058success$1261$(_same_0, _edges_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "types.SpecGraph", "edges": _edges_0};
  } else {
    return {$: "types.SpecGraph", "edges": ($List$append$(($graph$045spec$058remove_source$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}}))};
  }
}

function $graph$045spec$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045spec$058key$1261$(_descriptor_0));
    const _x_1 = ($graph$045spec$058key$1261$(_other_0));
    return $graph$045spec$058source_chosen$(($Bool$and$((_x_0 === _x_1), (_source_0 === _id_0))), _target_0, run_clo((_x_2) => {
  return $graph$045spec$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $graph$045spec$058cycle_at$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($graph$045spec$058next_cycle$1261$(run_loop($graph$045spec$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $graph$045spec$058cycle_at$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $graph$045spec$058removed_selected$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $graph$045spec$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $graph$045core$058updated$1261$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "types.Graph", "edges": ($List$append$(($graph$045core$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($graph$045core$058inverse_add$1261$(($graph$045core$058remove_previous$1261$(run_loop($graph$045core$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $graph$045core$058cycle_loop$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($graph$045core$058next_cycle$1261$(run_loop($graph$045core$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $graph$045core$058cycle_loop$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $graph$045core$058remove_edge_fields$1261$(_edge_0, _descriptor_0, _source_0, _next_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($graph$045core$058key$1261$(_other_0));
  const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
  return $graph$045core$058edge_removed$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _next_0({$: "Unit"}));
}

function $graph$045core$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $graph$045spec$058inverse_edges$1260$(_edges_0, _descriptor_0, _target_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _source_0 = _t_0["source"];
    const _id_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045spec$058key$1260$(_descriptor_0));
    const _x_1 = ($graph$045spec$058key$1260$(_other_0));
    return $graph$045spec$058inverse_selected$(($Bool$and$((_x_0 === _x_1), (_target_0 === _id_0))), _source_0, ($graph$045spec$058inverse_edges$1260$(_rest_0, _descriptor_0, _target_0)));
  }
}

function $graph$045core$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1260$(_other_0));
    const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
    return $graph$045core$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $graph$045core$058inverse_entries$1260$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $graph$045spec$058source_chosen$(_same_0, _target_0, _rest_0) {
  if (_same_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_rest_0, {$: "Unit"});
  }
}

function $graph$045spec$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $graph$045core$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1260$(_other_0));
    const _x_1 = ($graph$045core$058key$1260$(_descriptor_0));
    return $graph$045core$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $graph$045core$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $graph$045core$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $graph$045core$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $graph$045spec$058inverse_edges$1261$(_edges_0, _descriptor_0, _target_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _source_0 = _t_0["source"];
    const _id_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($graph$045spec$058key$1261$(_descriptor_0));
    const _x_1 = ($graph$045spec$058key$1261$(_other_0));
    return $graph$045spec$058inverse_selected$(($Bool$and$((_x_0 === _x_1), (_target_0 === _id_0))), _source_0, ($graph$045spec$058inverse_edges$1261$(_rest_0, _descriptor_0, _target_0)));
  }
}

function $graph$045core$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1261$(_other_0));
    const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
    return $graph$045core$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $graph$045core$058inverse_entries$1261$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $graph$045spec$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $graph$045core$058inverse_add$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($graph$045core$058key$1261$(_other_0));
    const _x_1 = ($graph$045core$058key$1261$(_descriptor_0));
    return $graph$045core$058inverse_add_found$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $graph$045core$058inverse_add$1261$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $graph$045core$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $graph$045core$058edge_removed$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $graph$045spec$058inverse_selected$(_selected_0, _source_0, _rest_0) {
  if (_selected_0) {
    return {$: "Con", "head": _source_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $graph$045core$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $graph$045core$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($graph$045core$058appended_source$(($graph$045core$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $graph$045core$058inverse_add_found$1261$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($graph$045core$058appended_source$(($graph$045core$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $graph$045core$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $graph$045core$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($graph$045core$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);