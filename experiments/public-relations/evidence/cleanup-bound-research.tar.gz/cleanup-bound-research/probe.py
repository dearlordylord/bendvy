"""Finite falsification of a cleanup progress bound; no proof or source adoption."""
import itertools,json,sys,pathlib,importlib.util
p=pathlib.Path(__file__).resolve().parents[2]/'cleanup-model.py'
spec=importlib.util.spec_from_file_location('slow',p);slow=importlib.util.module_from_spec(spec);spec.loader.exec_module(slow)
def families(n,linked):
 for targets in itertools.product(range(n+1),repeat=n):
  if any(t==s for s,t in enumerate(targets,1)):continue
  if linked:
   valid=True
   for s in range(1,n+1):
    seen=set();t=s
    while t:
     if t in seen:valid=False;break
     seen.add(t);t=targets[t-1]
    if not valid:break
   if not valid:continue
  yield [(s,t) for s,t in enumerate(targets,1) if t]
def run(desc,initial,n,root):
 edges=list(initial);owners={i:(i,) for i in range(1,n+1)};live=set(owners);removed=[];despawned=[]
 stack=[('enter',root)];steps=0;phase=0;seen=set();enters=0;maxphase=0;counts={}
 def unlink(k,s):
  nonlocal phase,seen
  old=len(edges);edges[:]=[(a,b,c) for a,b,c in edges if (a,b)!=(k,s)]
  if len(edges)!=old:phase+=1;seen=set()
 while stack:
  steps+=1;f=stack.pop();kind,id=f[:2]
  if kind=='enter':
   if id not in live:continue
   assert id not in seen,('same-live-owner-entered-twice-without-progress',desc,initial,root,phase,id)
   seen.add(id);enters+=1;counts[phase]=counts.get(phase,0)+1;maxphase=max(maxphase,len(seen));stack.append(('descriptors',id,0))
  elif kind=='descriptors':
   ordinal=f[2]
   if ordinal==len(desc):stack.append(('finish',id));continue
   k,linked=desc[ordinal];kids=[s for a,s,t in edges if a==k and t==id]
   stack.append(('children',id,ordinal,tuple(kids)))
  elif kind=='children':
   ordinal,kids=f[2:];k,linked=desc[ordinal]
   if not kids:unlink(k,id);stack.append(('descriptors',id,ordinal+1));continue
   child,*rest=kids;stack.append(('children',id,ordinal,tuple(rest)))
   if linked:stack.append(('enter',child))
   else:unlink(k,child)
  else:
   old=owners.pop(id,None)
   if old is not None:removed.append((id,list(old)))
   if id in live:live.remove(id);phase+=1;seen=set()
   despawned.append(id)
 bound=1+n*(len(initial)+n+1)*(3+2*len(desc)+2*len(initial))
 assert steps<=bound,('bound-falsified',desc,initial,root,steps,bound)
 actual={'owners':sorted((i,list(v)) for i,v in owners.items()),'edges':edges,'removed':removed,'despawned':despawned}
 assert actual==slow.cleanup(desc,initial,{i:[i] for i in range(1,n+1)},root)
 return steps,bound,enters,maxphase
n=int(sys.argv[1]);d=int(sys.argv[2]);mixed=bool(int(sys.argv[3]));cases=0;maxsteps=0;maximum=None
for kinds in itertools.product([False,True] if mixed else [True],repeat=d):
 pools=[list(families(n,k)) for k in kinds]
 for graphs in itertools.product(*pools):
  desc=list(enumerate(kinds,1));edges=[(k,s,t) for k,g in enumerate(graphs,1) for s,t in g]
  for reverse in [False,True]:
   initial=list(reversed(edges)) if reverse else edges
   for root in range(1,n+1):
    result=run(desc,initial,n,root);cases+=1
    if result[0]>maxsteps:maxsteps=result[0];maximum={'descriptors':desc,'edges':initial,'root':root,'steps':result[0],'bound':result[1],'aliveEntries':result[2],'maxNoProgressPhaseEntries':result[3]}
print(json.dumps({'status':'FINITE_BOUND_FALSIFICATION_PASS','n':n,'descriptors':d,'mixed':mixed,'cases':cases,'maximum':maximum,'plantedBoundOneRejected':maxsteps>1},separators=(',',':')))
