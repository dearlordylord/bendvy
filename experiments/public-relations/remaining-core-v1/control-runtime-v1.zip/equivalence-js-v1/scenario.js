function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  const _x_0 = ($run$1261$(47));
  const _x_1 = ($run$1260$(31));
  const _x_2 = ("Garden\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("Workshop\n" + _x_3);
}

function $run$1260$(_namespace_0) {
  return $joined$(($consumer$058done$1260$(($consumer$058result_observe$1260$(run_loop($split_result$1260$(_namespace_0)))))), ($consumer$058done$1260$(($consumer$058result_observe$1260$(run_loop($uninterrupted_result$1260$(_namespace_0)))))));
}

function $run$1261$(_namespace_0) {
  return $joined$(($consumer$058done$1261$(($consumer$058result_observe$1261$(run_loop($split_result$1261$(_namespace_0)))))), ($consumer$058done$1261$(($consumer$058result_observe$1261$(run_loop($uninterrupted_result$1261$(_namespace_0)))))));
}

function $joined$(_split_0, _uninterrupted_0) {
  const _x_0 = ($Bool$show$(($String$eq$(_split_0, _uninterrupted_0))));
  const _x_1 = (_x_0 + "\n");
  const _x_2 = ("equal=" + _x_1);
  const _x_3 = (_uninterrupted_0 + _x_2);
  const _x_4 = ("uninterrupted\n" + _x_3);
  const _x_5 = (_split_0 + _x_4);
  return ("split\n" + _x_5);
}

function $consumer$058done$1260$(_observed_0) {
  const _result_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($consumer$058last$1260$(($consumer$058final_barrier$1260$(_result_0))));
  const _x_1 = ("\n" + _x_0);
  return (_text_0 + _x_1);
}

function $consumer$058result_observe$1260$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return $consumer$058complete_observed$1260$(($consumer$058observe$1260$(_world_0)));
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $consumer$058incomplete_observed$1260$(_frames_0, ($consumer$058observe$1260$(_world_1)));
  }
}

function $split_result$1260$(_namespace_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058units$1260$(32, run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058units$1260$(4, run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1260$(0, {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupEnter", "id": 1}, "tail": {$: "Nil"}}, ($consumer$058setup$1260$(_namespace_0)), _namespace_0, ($consumer$058descriptors$1260$()))), _namespace_0, ($consumer$058descriptors$1260$()))), _namespace_0, ($consumer$058descriptors$1260$()));
}

function $uninterrupted_result$1260$(_namespace_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1260$(36, {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupEnter", "id": 1}, "tail": {$: "Nil"}}, ($consumer$058setup$1260$(_namespace_0)), _namespace_0, ($consumer$058descriptors$1260$()));
}

function $consumer$058done$1261$(_observed_0) {
  const _result_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($consumer$058last$1261$(($consumer$058final_barrier$1261$(_result_0))));
  const _x_1 = ("\n" + _x_0);
  return (_text_0 + _x_1);
}

function $consumer$058result_observe$1261$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return $consumer$058complete_observed$1261$(($consumer$058observe$1261$(_world_0)));
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $consumer$058incomplete_observed$1261$(_frames_0, ($consumer$058observe$1261$(_world_1)));
  }
}

function $split_result$1261$(_namespace_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058units$1261$(32, run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058units$1261$(4, run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1261$(0, {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupEnter", "id": 1}, "tail": {$: "Nil"}}, ($consumer$058setup$1261$(_namespace_0)), _namespace_0, ($consumer$058descriptors$1261$()))), _namespace_0, ($consumer$058descriptors$1261$()))), _namespace_0, ($consumer$058descriptors$1261$()));
}

function $uninterrupted_result$1261$(_namespace_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1261$(36, {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupEnter", "id": 1}, "tail": {$: "Nil"}}, ($consumer$058setup$1261$(_namespace_0)), _namespace_0, ($consumer$058descriptors$1261$()));
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $consumer$058last$1260$(_observed_0) {
  const _text_0 = _observed_0["snd"];
  return (_text_0 + "\n");
}

function $consumer$058final_barrier$1260$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return $consumer$058complete_observed$1260$(($consumer$058observe$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0)))));
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $consumer$058incomplete_observed$1260$(_frames_0, ($consumer$058observe$1260$(_world_1)));
  }
}

function $consumer$058complete_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-cleanup.Complete", "world": _world_0}, "snd": ("complete/" + _text_0)};
}

function $consumer$058observe$1260$(_world_0) {
  return $consumer$058pending_observed$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0)));
}

function $consumer$058incomplete_observed$1260$(_frames_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($List$show$1266$(_frames_0));
  const _x_1 = ("/" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-cleanup.Incomplete", "world": _world_0, "frames": _frames_0}, "snd": ("incomplete/frames=" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058units$1260$(_fuel_0, _result_0, _namespace_0, _descriptors_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../bendvy/src/ecs/relation-cleanup.Complete", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1260$(_fuel_0, _frames_0, _world_1, _namespace_0, _descriptors_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1260$(_fuel_0, _frames_0, _world_0, _namespace_0, _descriptors_0) {
  if (_fuel_0 === 0) {
    if (_frames_0.$ === "Nil") {
      return {$: "../../../../../bendvy/src/ecs/relation-cleanup.Complete", "world": _world_0};
    } else {
      return {$: "../../../../../bendvy/src/ecs/relation-cleanup.Incomplete", "world": _world_0, "frames": _frames_0};
    }
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_frames_0.$ === "Nil") {
      return {$: "../../../../../bendvy/src/ecs/relation-cleanup.Complete", "world": _world_0};
    } else {
      const _frame_0 = _frames_0["head"];
      const _frames_1 = _frames_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058resumed$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058step$1260$(_frame_0, _world_0, _namespace_0, _descriptors_0, _frames_1)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1260$(_rest_0, _x_1, _x_0, _namespace_0, _descriptors_0);
});
}));
    }
  }
}

function $consumer$058setup$1260$(_namespace_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_relate$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_relate$1260$(($consumer$058fixture$1260$(_namespace_0)), ($consumer$058link$1260$()), {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": 3}, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": 1})), ($consumer$058parent$1260$()), {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": 2}, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
}

function $consumer$058descriptors$1260$() {
  return {$: "Con", "head": ($consumer$058link$1260$()), "tail": {$: "Con", "head": ($consumer$058parent$1260$()), "tail": {$: "Nil"}}};
}

function $consumer$058last$1261$(_observed_0) {
  const _text_0 = _observed_0["snd"];
  return (_text_0 + "\n");
}

function $consumer$058final_barrier$1261$(_result_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return $consumer$058complete_observed$1261$(($consumer$058observe$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1261$(_world_0)))));
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $consumer$058incomplete_observed$1261$(_frames_0, ($consumer$058observe$1261$(_world_1)));
  }
}

function $consumer$058complete_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-cleanup.Complete", "world": _world_0}, "snd": ("complete/" + _text_0)};
}

function $consumer$058observe$1261$(_world_0) {
  return $consumer$058pending_observed$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1261$(_world_0)));
}

function $consumer$058incomplete_observed$1261$(_frames_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($List$show$12611$(_frames_0));
  const _x_1 = ("/" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-cleanup.Incomplete", "world": _world_0, "frames": _frames_0}, "snd": ("incomplete/frames=" + _x_2)};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058units$1261$(_fuel_0, _result_0, _namespace_0, _descriptors_0) {
  if (_result_0.$ === "../../../../../bendvy/src/ecs/relation-cleanup.Complete") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../bendvy/src/ecs/relation-cleanup.Complete", "world": _world_0};
  } else {
    const _world_1 = _result_0["world"];
    const _frames_0 = _result_0["frames"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1261$(_fuel_0, _frames_0, _world_1, _namespace_0, _descriptors_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1261$(_fuel_0, _frames_0, _world_0, _namespace_0, _descriptors_0) {
  if (_fuel_0 === 0) {
    if (_frames_0.$ === "Nil") {
      return {$: "../../../../../bendvy/src/ecs/relation-cleanup.Complete", "world": _world_0};
    } else {
      return {$: "../../../../../bendvy/src/ecs/relation-cleanup.Incomplete", "world": _world_0, "frames": _frames_0};
    }
  } else {
    const _rest_0 = (_fuel_0 - 1);
    if (_frames_0.$ === "Nil") {
      return {$: "../../../../../bendvy/src/ecs/relation-cleanup.Complete", "world": _world_0};
    } else {
      const _frame_0 = _frames_0["head"];
      const _frames_1 = _frames_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058resumed$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058step$1261$(_frame_0, _world_0, _namespace_0, _descriptors_0, _frames_1)), run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058drive$1261$(_rest_0, _x_1, _x_0, _namespace_0, _descriptors_0);
});
}));
    }
  }
}

function $consumer$058setup$1261$(_namespace_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_relate$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_relate$1261$(($consumer$058fixture$1261$(_namespace_0)), ($consumer$058link$1261$()), {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": 3}, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": 1})), ($consumer$058parent$1261$()), {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": 2}, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
}

function $consumer$058descriptors$1261$() {
  return {$: "Con", "head": ($consumer$058link$1261$()), "tail": {$: "Con", "head": ($consumer$058parent$1261$()), "tail": {$: "Nil"}}};
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $consumer$058pending_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _count_0 = _observed_0["snd"];
  return $consumer$058store_observed$1260$(_count_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $consumer$058show_store$1260$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_frame$1260$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058resumed$1260$(_observed_0, _next_0) {
  const _world_0 = _observed_0["fst"];
  const _frames_0 = _observed_0["snd"];
  return run_tail(_next_0(_world_0), _frames_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058step$1260$(_frame_0, _world_0, _namespace_0, _descriptors_0, _frames_0) {
  if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _frame_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058entered$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0})), _id_0, _descriptors_0, _frames_0);
  } else if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _frame_0["id"];
    const _t_0 = _frame_0["remaining"];
    if (_t_0.$ === "Nil") {
      return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupFinish", "id": _id_1}, "tail": _frames_0}};
    } else {
      const _d_0 = _t_0["head"];
      const _remaining_0 = _t_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058children_start$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058snapshot$1260$(_x_0, _d_0, _id_1);
}), _world_0)), _id_1, _d_0, _remaining_0, _frames_0);
    }
  } else if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _frame_0["id"];
    const _d_1 = _frame_0["descriptor"];
    const _remaining_1 = _frame_0["remainingDescriptors"];
    const _t_1 = _frame_0["remainingChildren"];
    if (_t_1.$ === "Nil") {
      return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_world_0, _d_1, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_2})), "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors", "id": _id_2, "remaining": _remaining_1}, "tail": _frames_0}};
    } else {
      const _child_0 = _t_1["head"];
      const _children_0 = _t_1["tail"];
      return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058child_step$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058kind$1260$(_d_1)), _world_0, _namespace_0, _id_2, _d_1, _remaining_1, _child_0, _children_0, _frames_0);
    }
  } else {
    const _id_3 = _frame_0["id"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058finish$1260$(_world_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_3})), "snd": _frames_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_source$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $consumer$058fixture$1260$(_namespace_0) {
  return {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 4, "highWater": 3, "live": array_node(array_node([false], [true]), array_node([true], [true])), "capacity": 4, "depth": 2, "store": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": {$: "consumer.Components", "slots": array_node(array_node([{$: "None"}], [{$: "Some", "value": ($consumer$058payload$(1))}]), array_node([{$: "Some", "value": ($consumer$058payload$(2))}], [{$: "Some", "value": ($consumer$058payload$(3))}])), "removed": {$: "Nil"}}, "graph": {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}}, "resource": array_node([77], [88]), "events": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-commands.Original", "event": 99}, "tail": {$: "Nil"}}, "pending": {$: "Con", "head": run_clo((_x_0) => {
  return $consumer$058tick$1260$(_x_0);
}), "tail": {$: "Nil"}}, "registrations": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": 1, "name": "Existing", "access": {$: "Con", "head": "Link", "tail": {$: "Con", "head": "Parent", "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}, "nextSystemId": 2, "clock": 13};
}

function $consumer$058link$1260$() {
  return {$: "../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../../bendvy/src/ecs/relation-types.Ordinary"}};
}

function $consumer$058parent$1260$() {
  return {$: "../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 2, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../../bendvy/src/ecs/relation-types.Hierarchy"}};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $consumer$058pending_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _count_0 = _observed_0["snd"];
  return $consumer$058store_observed$1261$(_count_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1265$(run_clo((_x_0) => {
  return $consumer$058show_store$1261$(_x_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $List$show$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_frame$1261$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058resumed$1261$(_observed_0, _next_0) {
  const _world_0 = _observed_0["fst"];
  const _frames_0 = _observed_0["snd"];
  return run_tail(_next_0(_world_0), _frames_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058step$1261$(_frame_0, _world_0, _namespace_0, _descriptors_0, _frames_0) {
  if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _frame_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058entered$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0})), _id_0, _descriptors_0, _frames_0);
  } else if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _frame_0["id"];
    const _t_0 = _frame_0["remaining"];
    if (_t_0.$ === "Nil") {
      return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupFinish", "id": _id_1}, "tail": _frames_0}};
    } else {
      const _d_0 = _t_0["head"];
      const _remaining_0 = _t_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058children_start$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1266$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058snapshot$1261$(_x_0, _d_0, _id_1);
}), _world_0)), _id_1, _d_0, _remaining_0, _frames_0);
    }
  } else if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _frame_0["id"];
    const _d_1 = _frame_0["descriptor"];
    const _remaining_1 = _frame_0["remainingDescriptors"];
    const _t_1 = _frame_0["remainingChildren"];
    if (_t_1.$ === "Nil") {
      return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_unrelate$1261$(_world_0, _d_1, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_2})), "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors", "id": _id_2, "remaining": _remaining_1}, "tail": _frames_0}};
    } else {
      const _child_0 = _t_1["head"];
      const _children_0 = _t_1["tail"];
      return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058child_step$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058kind$1261$(_d_1)), _world_0, _namespace_0, _id_2, _d_1, _remaining_1, _child_0, _children_0, _frames_0);
    }
  } else {
    const _id_3 = _frame_0["id"];
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058finish$1261$(_world_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_3})), "snd": _frames_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_relate$1261$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_source$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $consumer$058fixture$1261$(_namespace_0) {
  return {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 4, "highWater": 3, "live": array_node(array_node([false], [true]), array_node([true], [true])), "capacity": 4, "depth": 2, "store": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": {$: "consumer.Components", "slots": array_node(array_node([{$: "None"}], [{$: "Some", "value": ($consumer$058payload$(1))}]), array_node([{$: "Some", "value": ($consumer$058payload$(2))}], [{$: "Some", "value": ($consumer$058payload$(3))}])), "removed": {$: "Nil"}}, "graph": {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}}, "resource": array_node([77], [88]), "events": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-commands.Original", "event": 99}, "tail": {$: "Nil"}}, "pending": {$: "Con", "head": run_clo((_x_0) => {
  return $consumer$058tick$1261$(_x_0);
}), "tail": {$: "Nil"}}, "registrations": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": 1, "name": "Existing", "access": {$: "Con", "head": "Link", "tail": {$: "Con", "head": "Parent", "tail": {$: "Nil"}}}}, "tail": {$: "Nil"}}, "nextSystemId": 2, "clock": 13};
}

function $consumer$058link$1261$() {
  return {$: "../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 1, "name": "Link", "inverseName": "LinkedBy", "kind": {$: "../../../../../bendvy/src/ecs/relation-types.Ordinary"}};
}

function $consumer$058parent$1261$() {
  return {$: "../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": 2, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../../bendvy/src/ecs/relation-types.Hierarchy"}};
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $consumer$058store_observed$1260$(_pendingCount_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058resource_observed$1260$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $consumer$058show_store$1260$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $consumer$058store_components$1260$(_graph_0, ($consumer$058show_components$(_components_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $consumer$058show_frame$1260$(_frame_0) {
  if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _frame_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("enter:" + _x_0);
  } else if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _frame_0["id"];
    const _remaining_0 = _frame_0["remaining"];
    const _x_1 = ($List$show$1267$(_remaining_0));
    const _x_2 = ($U32$show$(_id_1));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("descriptors:" + _x_4);
  } else if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _frame_0["id"];
    const _descriptor_0 = _frame_0["descriptor"];
    const _remaining_1 = _frame_0["remainingDescriptors"];
    const _children_0 = _frame_0["remainingChildren"];
    const _x_5 = ($List$show$1265$(_children_0));
    const _x_6 = ($List$show$1267$(_remaining_1));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($consumer$058show_descriptor$1260$(_descriptor_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($U32$show$(_id_2));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("children:" + _x_14);
  } else {
    const _id_3 = _frame_0["id"];
    const _x_15 = ($U32$show$(_id_3));
    return ("finish:" + _x_15);
  }
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_frame$1260$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058entered$1260$(_checked_0, _id_0, _descriptors_0, _frames_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": _frames_0};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors", "id": _id_0, "remaining": _descriptors_0}, "tail": _frames_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058children_start$1260$(_observed_0, _id_0, _descriptor_0, _remaining_0, _frames_0) {
  const _world_0 = _observed_0["fst"];
  const _children_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058snapshot$1260$(_store_0, _descriptor_0, _id_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_inverse$1260$(_store_0, _descriptor_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_world_0, _descriptor_0, _source_0) {
  const _id_0 = _source_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058discard_unit$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_unrelate$1260$(_x_0, _descriptor_0, _id_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058child_step$1260$(_kind_0, _world_0, _namespace_0, _id_0, _descriptor_0, _remaining_0, _child_0, _children_0, _frames_0) {
  if (_kind_0.$ === "../../../../../bendvy/src/ecs/relation-types.Hierarchy") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupEnter", "id": _child_0}, "tail": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_world_0, _descriptor_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _child_0})), "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058kind$1260$(_d_0) {
  const _kind_0 = _d_0["kind"];
  return _kind_0;
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058finish$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058finalized$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058clear_store$1260$(_x_0, _handle_0);
}), _world_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_live$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $consumer$058payload$(_id_0) {
  return {$: "consumer.Payload", "first": [_id_0], "second": array_node([((_id_0 + 10) >>> 0)], [((_id_0 + 20) >>> 0)])};
}

function $consumer$058tick$1260$(_world_0) {
  return $consumer$058ticked$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $consumer$058store_observed$1261$(_pendingCount_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058resource_observed$1261$(_pendingCount_0, _text_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1265$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $consumer$058show_store$1261$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $consumer$058store_components$1261$(_graph_0, ($consumer$058show_components$(_components_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $consumer$058show_frame$1261$(_frame_0) {
  if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _frame_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    return ("enter:" + _x_0);
  } else if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _frame_0["id"];
    const _remaining_0 = _frame_0["remaining"];
    const _x_1 = ($List$show$12612$(_remaining_0));
    const _x_2 = ($U32$show$(_id_1));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("descriptors:" + _x_4);
  } else if (_frame_0.$ === "../../../../../bendvy/src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _frame_0["id"];
    const _descriptor_0 = _frame_0["descriptor"];
    const _remaining_1 = _frame_0["remainingDescriptors"];
    const _children_0 = _frame_0["remainingChildren"];
    const _x_5 = ($List$show$1265$(_children_0));
    const _x_6 = ($List$show$12612$(_remaining_1));
    const _x_7 = (":" + _x_5);
    const _x_8 = (_x_6 + _x_7);
    const _x_9 = ($consumer$058show_descriptor$1261$(_descriptor_0));
    const _x_10 = (":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($U32$show$(_id_2));
    const _x_13 = (":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("children:" + _x_14);
  } else {
    const _id_3 = _frame_0["id"];
    const _x_15 = ($U32$show$(_id_3));
    return ("finish:" + _x_15);
  }
}

function $List$show$go$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_frame$1261$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058entered$1261$(_checked_0, _id_0, _descriptors_0, _frames_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": _frames_0};
  } else {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupDescriptors", "id": _id_0, "remaining": _descriptors_0}, "tail": _frames_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058children_start$1261$(_observed_0, _id_0, _descriptor_0, _remaining_0, _frames_0) {
  const _world_0 = _observed_0["fst"];
  const _children_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1266$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1266$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058snapshot$1261$(_store_0, _descriptor_0, _id_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_inverse$1261$(_store_0, _descriptor_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_unrelate$1261$(_world_0, _descriptor_0, _source_0) {
  const _id_0 = _source_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058discard_unit$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1267$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_unrelate$1261$(_x_0, _descriptor_0, _id_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058child_step$1261$(_kind_0, _world_0, _namespace_0, _id_0, _descriptor_0, _remaining_0, _child_0, _children_0, _frames_0) {
  if (_kind_0.$ === "../../../../../bendvy/src/ecs/relation-types.Hierarchy") {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupEnter", "id": _child_0}, "tail": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_unrelate$1261$(_world_0, _descriptor_0, {$: "../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _child_0})), "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.CleanupChildren", "id": _id_0, "descriptor": _descriptor_0, "remainingDescriptors": _remaining_0, "remainingChildren": _children_0}, "tail": _frames_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058kind$1261$(_d_0) {
  const _kind_0 = _d_0["kind"];
  return _kind_0;
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058finish$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058finalized$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1268$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058clear_store$1261$(_x_0, _handle_0);
}), _world_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_source$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_live$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1261$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $consumer$058tick$1261$(_world_0) {
  return $consumer$058ticked$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $consumer$058resource_observed$1260$(_pendingCount_0, _storeText_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058live_observe$1260$(_pendingCount_0, _storeText_0, _text_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(($consumer$058tree$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $consumer$058store_components$1260$(_graph_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($consumer$058show_graph$1260$(_graph_0));
  const _x_1 = ("/graph=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": (_text_0 + _x_1)};
}

function $consumer$058show_components$(_components_0) {
  const _slots_0 = _components_0["slots"];
  const _removed_0 = _components_0["removed"];
  return $consumer$058components_slots$(_removed_0, ($consumer$058tree$1261$(_slots_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_descriptor$1260$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058show_descriptor$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  const _inverse_0 = _descriptor_0["inverseName"];
  const _kind_0 = _descriptor_0["kind"];
  const _x_0 = ($consumer$058show_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverse_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_inverse$1260$(_store_0, _descriptor_0, _target_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058discard_unit$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_unrelate$1260$(_store_0, _descriptor_0, _source_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058unrelate$1260$(_graph_0, _descriptor_0, _source_0))}, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058finalized$1260$(_cleared_0, _handle_0) {
  const _world_0 = _cleared_0["fst"];
  const _notices_0 = _cleared_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058publish_final$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0)), _notices_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1263$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1263$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058clear_store$1260$(_store_0, _handle_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058clear_join$1260$(($consumer$058clear$1260$(_components_0, _handle_0)), _graph_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058publish_relate$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1264$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $consumer$058ticked$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $consumer$058resource_observed$1261$(_pendingCount_0, _storeText_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058live_observe$1261$(_pendingCount_0, _storeText_0, _text_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(($consumer$058tree$1260$(_resource_0)), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $consumer$058store_components$1261$(_graph_0, _observed_0) {
  const _components_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($consumer$058show_graph$1261$(_graph_0));
  const _x_1 = ("/graph=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": (_text_0 + _x_1)};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $List$show$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_descriptor$1261$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058show_descriptor$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  const _inverse_0 = _descriptor_0["inverseName"];
  const _kind_0 = _descriptor_0["kind"];
  const _x_0 = ($consumer$058show_kind$(_kind_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_inverse_0 + _x_1);
  const _x_3 = (":" + _x_2);
  const _x_4 = (_name_0 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (":" + _x_4);
  return (_x_5 + _x_6);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_inverse$1261$(_store_0, _descriptor_0, _target_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _target_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058discard_unit$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1267$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1267$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_unrelate$1261$(_store_0, _descriptor_0, _source_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058unrelate$1261$(_graph_0, _descriptor_0, _source_0))}, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058finalized$1261$(_cleared_0, _handle_0) {
  const _world_0 = _cleared_0["fst"];
  const _notices_0 = _cleared_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058publish_final$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0)), _notices_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1268$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1268$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058clear_store$1261$(_store_0, _handle_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058clear_join$1261$(($consumer$058clear$1261$(_components_0, _handle_0)), _graph_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058apply_live$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058publish_relate$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1269$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $consumer$058ticked$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $consumer$058live_observe$1260$(_pendingCount_0, _storeText_0, _resourceText_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $consumer$058live_done$1260$(_namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _pendingCount_0, _storeText_0, _resourceText_0, ($consumer$058tree$1262$(_live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $consumer$058tree$1260$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $consumer$058leaf$1260$(($consumer$058number$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $consumer$058tree_left$1260$(($consumer$058tree$1260$(_b_0)), ($consumer$058tree$1260$(_a_0)));
  }
}

function $consumer$058show_graph$1260$(_graph_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _x_0 = ($List$show$1264$(_inverses_0));
  const _x_1 = ($List$show$1263$(_edges_0));
  const _x_2 = ("/" + _x_0);
  return (_x_1 + _x_2);
}

function $consumer$058components_slots$(_removed_0, _observed_0) {
  const _slots_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058components_removed$(_slots_0, _text_0, ($consumer$058show_removed$(_removed_0)));
}

function $consumer$058tree$1261$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $consumer$058leaf$1261$(($consumer$058show_slot$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $consumer$058tree_left$1261$(($consumer$058tree$1261$(_b_0)), ($consumer$058tree$1261$(_a_0)));
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_descriptor$1260$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058show_kind$(_kind_0) {
  if (_kind_0.$ === "../../../../../bendvy/src/ecs/relation-types.Ordinary") {
    return "ordinary";
  } else {
    return "hierarchy";
  }
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058unrelate$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  return {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), "inverses": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058publish_final$1260$(_deactivated_0, _notices_0, _handle_0) {
  const _world_0 = _deactivated_0["fst"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, ($List$append$(_notices_0, {$: "Con", "head": ($consumer$058record$1260$(_handle_0)), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(false, _handle_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058clear_join$1260$(_cleared_0, _graph_0) {
  const _components_0 = _cleared_0["fst"];
  const _notices_0 = _cleared_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _notices_0};
}

function $consumer$058clear$1260$(_components_0, _handle_0) {
  const _slots_0 = _components_0["slots"];
  const _removed_0 = _components_0["removed"];
  const _id_0 = _handle_0["id"];
  const _x_0 = {$: "None"};
  return $consumer$058clear_found$1260$(_id_0, array_rmw(_slots_0, _id_0, () => _x_0), _removed_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../../bendvy/src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../../bendvy/src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1264$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1264$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $consumer$058live_observe$1261$(_pendingCount_0, _storeText_0, _resourceText_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $consumer$058live_done$1261$(_namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _pendingCount_0, _storeText_0, _resourceText_0, ($consumer$058tree$1262$(_live_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058observe_resource_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $consumer$058show_graph$1261$(_graph_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _x_0 = ($List$show$12610$(_inverses_0));
  const _x_1 = ($List$show$1269$(_edges_0));
  const _x_2 = ("/" + _x_0);
  return (_x_1 + _x_2);
}

function $List$show$go$12611$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_descriptor$1261$(_h_0));
    const _x_1 = ($List$show$go$12611$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse$1261$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058unrelate$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  return {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), "inverses": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_previous$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0))};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058publish_final$1261$(_deactivated_0, _notices_0, _handle_0) {
  const _world_0 = _deactivated_0["fst"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, ($List$append$(_notices_0, {$: "Con", "head": ($consumer$058record$1261$(_handle_0)), "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058deactivate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(false, _handle_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045cleanup$058clear_join$1261$(_cleared_0, _graph_0) {
  const _components_0 = _cleared_0["fst"];
  const _notices_0 = _cleared_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _notices_0};
}

function $consumer$058clear$1261$(_components_0, _handle_0) {
  const _slots_0 = _components_0["slots"];
  const _removed_0 = _components_0["removed"];
  const _id_0 = _handle_0["id"];
  const _x_0 = {$: "None"};
  return $consumer$058clear_found$1261$(_id_0, array_rmw(_slots_0, _id_0, () => _x_0), _removed_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058publish_relate$1261$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../../bendvy/src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../../bendvy/src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store$1269$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1269$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058store_relate$1261$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058relate_result$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $consumer$058live_done$1260$(_namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _pendingCount_0, _storeText_0, _resourceText_0, _observed_0) {
  const _live_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = ($U32$show$(_nextSystemId_0));
  const _x_2 = ("/clock=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1262$(_registrations_0));
  const _x_5 = ("/nextSystem=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(_pendingCount_0));
  const _x_8 = ("/regs=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($List$show$1261$(_events_0));
  const _x_11 = ("/pending=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ("/events=" + _x_12);
  const _x_14 = (_resourceText_0 + _x_13);
  const _x_15 = ("/resource=" + _x_14);
  const _x_16 = (_storeText_0 + _x_15);
  const _x_17 = ($Nat$show$(_depth_0));
  const _x_18 = ("/" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($U32$show$(_capacity_0));
  const _x_21 = ("," + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ("," + _x_22);
  const _x_24 = (_text_0 + _x_23);
  const _x_25 = ($U32$show$(_highWater_0));
  const _x_26 = ("," + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($U32$show$(_nextId_0));
  const _x_29 = ("," + _x_27);
  const _x_30 = (_x_28 + _x_29);
  const _x_31 = ($U32$show$(_namespace_0));
  const _x_32 = ("," + _x_30);
  const _x_33 = (_x_31 + _x_32);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ("world=" + _x_33)};
}

function $consumer$058tree$1262$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $consumer$058leaf$1262$(($consumer$058boolean$(_value_1)));
  } else {
    const _a_0 = _value_0.slice(0, _value_0.length >> 1);
    const _b_0 = _value_0.slice(_value_0.length >> 1);
    return $consumer$058tree_left$1262$(($consumer$058tree$1262$(_b_0)), ($consumer$058tree$1262$(_a_0)));
  }
}

function $consumer$058leaf$1260$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $consumer$058number$(_value_0) {
  return $consumer$058number_value$(_value_0);
}

function $consumer$058tree_left$1260$(_b_0, _observed_0) {
  const _a_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058tree_right$1260$(_a_0, _text_0, _b_0);
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_edge$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_inverse$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058components_removed$(_slots_0, _text_0, _observed_0) {
  const _removed_0 = _observed_0["fst"];
  const _other_0 = _observed_0["snd"];
  const _x_0 = ("/removed=" + _other_0);
  return {$: "Tuple", "fst": {$: "consumer.Components", "slots": _slots_0, "removed": _removed_0}, "snd": (_text_0 + _x_0)};
}

function $consumer$058show_removed$(_removed_0) {
  if (_removed_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": ""};
  } else {
    const _payload_0 = _removed_0["head"];
    const _rest_0 = _removed_0["tail"];
    return $consumer$058removed_join$(($consumer$058show_payload$(_payload_0)), ($consumer$058show_removed$(_rest_0)));
  }
}

function $consumer$058leaf$1261$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $consumer$058show_slot$(_slot_0) {
  if (_slot_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "absent"};
  } else {
    const _payload_0 = _slot_0["value"];
    return $consumer$058some_payload$(($consumer$058show_payload$(_payload_0)));
  }
}

function $consumer$058tree_left$1261$(_b_0, _observed_0) {
  const _a_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058tree_right$1261$(_a_0, _text_0, _b_0);
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $consumer$058record$1260$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return {$: "../../../../../bendvy/src/ecs/relation-commands.Original", "event": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $consumer$058clear_found$1260$(_id_0, _observed_0, _removed_0) {
  const _slots_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "consumer.Components", "slots": _slots_0, "removed": _removed_0}, "snd": {$: "Nil"}};
  } else {
    const _payload_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "consumer.Components", "slots": _slots_0, "removed": {$: "Con", "head": _payload_0, "tail": _removed_0}}, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved", "id": _id_0}, "tail": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058checked$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $consumer$058live_done$1261$(_namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0, _pendingCount_0, _storeText_0, _resourceText_0, _observed_0) {
  const _live_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = ($U32$show$(_nextSystemId_0));
  const _x_2 = ("/clock=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($List$show$1262$(_registrations_0));
  const _x_5 = ("/nextSystem=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(_pendingCount_0));
  const _x_8 = ("/regs=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($List$show$1268$(_events_0));
  const _x_11 = ("/pending=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ("/events=" + _x_12);
  const _x_14 = (_resourceText_0 + _x_13);
  const _x_15 = ("/resource=" + _x_14);
  const _x_16 = (_storeText_0 + _x_15);
  const _x_17 = ($Nat$show$(_depth_0));
  const _x_18 = ("/" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($U32$show$(_capacity_0));
  const _x_21 = ("," + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ("," + _x_22);
  const _x_24 = (_text_0 + _x_23);
  const _x_25 = ($U32$show$(_highWater_0));
  const _x_26 = ("," + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($U32$show$(_nextId_0));
  const _x_29 = ("," + _x_27);
  const _x_30 = (_x_28 + _x_29);
  const _x_31 = ($U32$show$(_namespace_0));
  const _x_32 = ("," + _x_30);
  const _x_33 = (_x_31 + _x_32);
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ("world=" + _x_33)};
}

function $List$show$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_edge$1261$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_inverse$1261$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_entries$1261$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_previous$1261$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $consumer$058record$1261$(_handle_0) {
  const _id_0 = _handle_0["id"];
  return {$: "../../../../../bendvy/src/ecs/relation-commands.Original", "event": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $consumer$058clear_found$1261$(_id_0, _observed_0, _removed_0) {
  const _slots_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "consumer.Components", "slots": _slots_0, "removed": _removed_0}, "snd": {$: "Nil"}};
  } else {
    const _payload_0 = _t_0["value"];
    return {$: "Tuple", "fst": {$: "consumer.Components", "slots": _slots_0, "removed": {$: "Con", "head": _payload_0, "tail": _removed_0}}, "snd": {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved", "id": _id_0}, "tail": {$: "Nil"}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045commands$058relate_result$1261$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058checked$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_notice$1260$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_registration$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058leaf$1262$(_observed_0) {
  const _value_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_0)};
}

function $consumer$058boolean$(_value_0) {
  return $consumer$058boolean_value$(_value_0);
}

function $consumer$058tree_left$1262$(_b_0, _observed_0) {
  const _a_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058tree_right$1262$(_a_0, _text_0, _b_0);
}

function $consumer$058number_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $consumer$058tree_right$1260$(_a_0, _text_0, _observed_0) {
  const _b_0 = _observed_0["fst"];
  const _other_0 = _observed_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $consumer$058show_edge$1260$(_edge_0) {
  const _descriptor_0 = _edge_0["relation"];
  const _source_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = ($U32$show$(_source_0));
  const _x_2 = (">" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($consumer$058show_descriptor$1260$(_descriptor_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_edge$1260$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058show_inverse$1260$(_inverse_0) {
  const _descriptor_0 = _inverse_0["relation"];
  const _target_0 = _inverse_0["target"];
  const _sources_0 = _inverse_0["sources"];
  const _x_0 = ($List$show$1265$(_sources_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($consumer$058show_descriptor$1260$(_descriptor_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_inverse$1260$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058removed_join$(_first_0, _rest_0) {
  const _payload_0 = _first_0["fst"];
  const _text_0 = _first_0["snd"];
  return $consumer$058removed_finish$(_payload_0, _text_0, _rest_0);
}

function $consumer$058show_payload$(_payload_0) {
  const _first_0 = _payload_0["first"];
  const _second_0 = _payload_0["second"];
  return $consumer$058payload_first$(_second_0, ($consumer$058tree$1260$(_first_0)));
}

function $consumer$058some_payload$(_observed_0) {
  const _payload_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _payload_0}, "snd": _text_0};
}

function $consumer$058tree_right$1261$(_a_0, _text_0, _observed_0) {
  const _b_0 = _observed_0["fst"];
  const _other_0 = _observed_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../../bendvy/src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../../bendvy/src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058updated$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "../../../../../bendvy/src/ecs/relation-types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "../../../../../bendvy/src/ecs/relation-types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "../../../../../bendvy/src/ecs/relation-types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "../../../../../bendvy/src/ecs/relation-types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../../bendvy/src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../../bendvy/src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $List$show$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_notice$1261$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $consumer$058show_edge$1261$(_edge_0) {
  const _descriptor_0 = _edge_0["relation"];
  const _source_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = ($U32$show$(_source_0));
  const _x_2 = (">" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($consumer$058show_descriptor$1261$(_descriptor_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1269$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_edge$1261$(_h_0));
    const _x_1 = ($List$show$go$1269$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058show_inverse$1261$(_inverse_0) {
  const _descriptor_0 = _inverse_0["relation"];
  const _target_0 = _inverse_0["target"];
  const _sources_0 = _inverse_0["sources"];
  const _x_0 = ($List$show$1265$(_sources_0));
  const _x_1 = ($U32$show$(_target_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($consumer$058show_descriptor$1261$(_descriptor_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$12610$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_inverse$1261$(_h_0));
    const _x_1 = ($List$show$go$12610$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../../bendvy/src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../../bendvy/src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058updated$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../../bendvy/src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1261$(($List$length$(_edges_0)), {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../../bendvy/src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../../bendvy/src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $consumer$058show_notice$1260$(_notice_0) {
  if (_notice_0.$ === "../../../../../bendvy/src/ecs/relation-commands.Original") {
    const _value_0 = _notice_0["event"];
    const _x_0 = ($U32$show$(_value_0));
    return ("original:" + _x_0);
  } else if (_notice_0.$ === "../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _notice_0["id"];
    const _x_1 = ($U32$show$(_id_0));
    return ("removed:" + _x_1);
  } else {
    return "UNEXPECTED_NOTICE";
  }
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_notice$1260$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058show_registration$(_registration_0) {
  const _id_0 = _registration_0["id"];
  const _name_0 = _registration_0["name"];
  const _access_0 = _registration_0["access"];
  const _x_0 = ($List$show$1260$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_registration$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $consumer$058boolean_value$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": ($Bool$show$(_value_0))};
}

function $consumer$058tree_right$1262$(_a_0, _text_0, _observed_0) {
  const _b_0 = _observed_0["fst"];
  const _other_0 = _observed_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_2)};
}

function $consumer$058removed_finish$(_payload_0, _text_0, _observed_0) {
  const _removed_0 = _observed_0["fst"];
  const _other_0 = _observed_0["snd"];
  const _x_0 = (";" + _other_0);
  return {$: "Tuple", "fst": {$: "Con", "head": _payload_0, "tail": _removed_0}, "snd": (_text_0 + _x_0)};
}

function $consumer$058payload_first$(_second_0, _observed_0) {
  const _first_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  return $consumer$058payload_second$(_first_0, _text_0, ($consumer$058tree$1260$(_second_0)));
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../../bendvy/src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1260$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058next_cycle$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $consumer$058show_notice$1261$(_notice_0) {
  if (_notice_0.$ === "../../../../../bendvy/src/ecs/relation-commands.Original") {
    const _value_0 = _notice_0["event"];
    const _x_0 = ($U32$show$(_value_0));
    return ("original:" + _x_0);
  } else if (_notice_0.$ === "../../../../../bendvy/src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _notice_0["id"];
    const _x_1 = ($U32$show$(_id_0));
    return ("removed:" + _x_1);
  } else {
    return "UNEXPECTED_NOTICE";
  }
}

function $List$show$go$1268$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($consumer$058show_notice$1261$(_h_0));
    const _x_1 = ($List$show$go$1268$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058edge_removed$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../../bendvy/src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058updated$1261$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../../bendvy/src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1261$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_previous$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058next_cycle$1261$(run_loop($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1260$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $consumer$058payload_second$(_first_0, _text_0, _observed_0) {
  const _second_0 = _observed_0["fst"];
  const _other_0 = _observed_0["snd"];
  const _x_0 = (_other_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_text_0 + _x_1);
  return {$: "Tuple", "fst": {$: "consumer.Payload", "first": _first_0, "second": _second_0}, "snd": ("P(" + _x_2)};
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058edge_removed$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add$1261$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1260$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058removed_id$((_x_0 === _id_0), _x_0, ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058remove_id$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../../bendvy/src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047relation$045graph$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[4],[]]);