
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_CHR 13
#define CID________________BENDVY_SRC_ECS_RELATION_CLEANUP_COMPLETE 14
#define CID________________BENDVY_SRC_ECS_RELATION_CLEANUP_INCOMPLETE 15
#define CID_CONSUMER_WORKSHOP 16
#define CID_CONSUMER_COMPONENTS 17
#define CID_NIL 18
#define CID_CON 19
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPENTER 20
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPDESCRIPTORS 21
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPCHILDREN 22
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPFINISH 23
#define CID________________BENDVY_SRC_ECS_WORLD_WORLD 24
#define CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE 25
#define CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL 26
#define CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED 27
#define CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED 28
#define CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_CLEANUPPAUSED 29
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_DESCRIPTOR 30
#define CID_CONSUMER_PAYLOAD 31
#define CID________________BENDVY_SRC_ECS_WORLD_REGISTRATIONMETA 32
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_GRAPH 33
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_FAILURE 34
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_ORDINARY 35
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_HIERARCHY 36
#define CID________________BENDVY_SRC_ECS_WORLD_HANDLE 37
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_EDGE 38
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_INVERSE 39
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_RELATE 40
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_REORDERCHILDREN 41
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGENTITY 42
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGTARGETENTITY 43
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_SELFRELATIONNOTALLOWED 44
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_HIERARCHYCYCLE 45
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGCHILDENTITY 46
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_DUPLICATECHILD 47
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_CHILDNOTRELATEDTOPARENT 48
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_CHILDSETMISMATCH 49
#define CID________________BENDVY_SRC_ECS_WORLD_ACCEPTED 50
#define CID________________BENDVY_SRC_ECS_WORLD_REJECTED 51
#define CID________________BENDVY_SRC_ECS_WORLD_MISSINGENTITY 52
#define CID________________BENDVY_SRC_ECS_WORLD_CAPACITYEXCEEDED 53
#define CID________________BENDVY_SRC_ECS_WORLD_NAMESPACEEXHAUSTED 54
#define CID________________BENDVY_SRC_ECS_WORLD_SYSTEMIDEXHAUSTED 55
#define CID________________BENDVY_SRC_ECS_RELATION_TYPES_CORERESULT 56
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS 0
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS_K1 1
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_APPENDED_SOURCE 2
#define FID_LIST_SHOW_GO_0 3
#define FID_LIST_SHOW_GO_0_K5 4
#define FID_LIST_SHOW_GO_0_K6 5
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID 6
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID_K12 7
#define FID_LIST_SHOW_0 8
#define FID_LIST_SHOW_0_K21 9
#define FID_LIST_SHOW_0_K22 10
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_0 11
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0 12
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0_K26 13
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0 14
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_C28 15
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K29 16
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K30 17
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K31 18
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0 19
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0_K34 20
#define FID_LIST_SHOW_GO_2 21
#define FID_LIST_SHOW_GO_2_K53 22
#define FID_LIST_SHOW_GO_2_K54 23
#define FID_LIST_SHOW_GO_2_K55 24
#define FID_CONSUMER_SHOW_REGISTRATION 25
#define FID_CONSUMER_SHOW_REGISTRATION_K57 26
#define FID_CONSUMER_SHOW_REGISTRATION_K58 27
#define FID_CONSUMER_SHOW_REGISTRATION_K59 28
#define FID_CONSUMER_SHOW_REGISTRATION_K60 29
#define FID_CONSUMER_SHOW_REGISTRATION_K61 30
#define FID_LIST_SHOW_GO_1 31
#define FID_LIST_SHOW_GO_1_K63 32
#define FID_LIST_SHOW_GO_1_K64 33
#define FID_LIST_SHOW_GO_1_K65 34
#define FID_CONSUMER_SHOW_NOTICE_0 35
#define FID_CONSUMER_SHOW_NOTICE_0_K67 36
#define FID_CONSUMER_SHOW_NOTICE_0_K68 37
#define FID_NAT_SHOW_FIN 38
#define FID_LIST_LENGTH 39
#define FID_LIST_LENGTH_K72 40
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0 41
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K74 42
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_C75 43
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K76 44
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K77 45
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0 46
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K80 47
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K81 48
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K82 49
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K83 50
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0 51
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0_K86 52
#define FID_CONSUMER_SHOW_PAYLOAD 53
#define FID_CONSUMER_SHOW_PAYLOAD_K97 54
#define FID_CONSUMER_SHOW_PAYLOAD_K98 55
#define FID_CONSUMER_SHOW_PAYLOAD_K99 56
#define FID_CONSUMER_SHOW_PAYLOAD_K100 57
#define FID_CONSUMER_SHOW_PAYLOAD_K101 58
#define FID_CONSUMER_SHOW_PAYLOAD_K102 59
#define FID_LIST_SHOW_GO_5 60
#define FID_LIST_SHOW_GO_5_K107 61
#define FID_LIST_SHOW_GO_5_K108 62
#define FID_LIST_SHOW_GO_5_K109 63
#define FID_CONSUMER_SHOW_INVERSE_0 64
#define FID_CONSUMER_SHOW_INVERSE_0_K111 65
#define FID_CONSUMER_SHOW_INVERSE_0_K112 66
#define FID_CONSUMER_SHOW_INVERSE_0_K113 67
#define FID_CONSUMER_SHOW_INVERSE_0_K114 68
#define FID_CONSUMER_SHOW_INVERSE_0_K115 69
#define FID_CONSUMER_SHOW_INVERSE_0_K116 70
#define FID_LIST_SHOW_GO_3 71
#define FID_LIST_SHOW_GO_3_K118 72
#define FID_LIST_SHOW_GO_3_K119 73
#define FID_LIST_SHOW_GO_3_K120 74
#define FID_CONSUMER_SHOW_EDGE_0 75
#define FID_CONSUMER_SHOW_EDGE_0_K122 76
#define FID_CONSUMER_SHOW_EDGE_0_K123 77
#define FID_CONSUMER_SHOW_EDGE_0_K124 78
#define FID_CONSUMER_SHOW_EDGE_0_K125 79
#define FID_CONSUMER_SHOW_EDGE_0_K126 80
#define FID_CONSUMER_SHOW_EDGE_0_K127 81
#define FID_LIST_SHOW_2 82
#define FID_LIST_SHOW_2_K145 83
#define FID_LIST_SHOW_2_K146 84
#define FID_LIST_SHOW_2_K147 85
#define FID_LIST_SHOW_1 86
#define FID_LIST_SHOW_1_K149 87
#define FID_LIST_SHOW_1_K150 88
#define FID_LIST_SHOW_1_K151 89
#define FID_NAT_SHOW 90
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0 91
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0_K155 92
#define FID_U32_SHOW_GO 93
#define FID_CONSUMER_SHOW_SLOT 94
#define FID_CONSUMER_SHOW_SLOT_K175 95
#define FID_CONSUMER_SHOW_REMOVED 96
#define FID_CONSUMER_SHOW_REMOVED_K180 97
#define FID_CONSUMER_SHOW_REMOVED_K181 98
#define FID_CONSUMER_SHOW_REMOVED_K182 99
#define FID_CONSUMER_SHOW_REMOVED_K183 100
#define FID_LIST_SHOW_4 101
#define FID_LIST_SHOW_4_K188 102
#define FID_LIST_SHOW_4_K189 103
#define FID_LIST_SHOW_4_K190 104
#define FID_LIST_SHOW_3 105
#define FID_LIST_SHOW_3_K192 106
#define FID_LIST_SHOW_3_K193 107
#define FID_LIST_SHOW_3_K194 108
#define FID_CONSUMER_NUMBER 109
#define FID_CONSUMER_NUMBER_K201 110
#define FID_CONSUMER_TREE_2 111
#define FID_CONSUMER_TREE_2_K206 112
#define FID_CONSUMER_TREE_2_K207 113
#define FID_CONSUMER_TREE_2_K208 114
#define FID_CONSUMER_TREE_2_K209 115
#define FID_CONSUMER_TREE_2_K210 116
#define FID_CONSUMER_TREE_2_K211 117
#define FID_CONSUMER_TREE_2_K212 118
#define FID_CONSUMER_TREE_2_K213 119
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0 120
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K251 121
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K252 122
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K253 123
#define FID_LIST_APPEND 124
#define FID_LIST_APPEND_K260 125
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0 126
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_C263 127
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K264 128
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K265 129
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0 130
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0 131
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0_C269 132
#define FID_LIST_SHOW_GO_4 133
#define FID_LIST_SHOW_GO_4_K272 134
#define FID_LIST_SHOW_GO_4_K273 135
#define FID_LIST_SHOW_GO_4_K274 136
#define FID_LIST_SHOW_GO_6 137
#define FID_LIST_SHOW_GO_6_K277 138
#define FID_LIST_SHOW_GO_6_K278 139
#define FID_LIST_SHOW_GO_6_K279 140
#define FID_CONSUMER_TREE_1 141
#define FID_CONSUMER_TREE_1_K282 142
#define FID_CONSUMER_TREE_1_K283 143
#define FID_CONSUMER_TREE_1_K284 144
#define FID_CONSUMER_TREE_1_K285 145
#define FID_CONSUMER_TREE_1_K286 146
#define FID_CONSUMER_TREE_1_K287 147
#define FID_CONSUMER_TREE_1_K288 148
#define FID_CONSUMER_TREE_1_K289 149
#define FID_CONSUMER_TREE_1_K290 150
#define FID_CONSUMER_SHOW_GRAPH_0 151
#define FID_CONSUMER_SHOW_GRAPH_0_K296 152
#define FID_CONSUMER_SHOW_GRAPH_0_K297 153
#define FID_CONSUMER_SHOW_GRAPH_0_K298 154
#define FID_CONSUMER_TREE_0 155
#define FID_CONSUMER_TREE_0_K300 156
#define FID_CONSUMER_TREE_0_K301 157
#define FID_CONSUMER_TREE_0_K302 158
#define FID_CONSUMER_TREE_0_K303 159
#define FID_CONSUMER_TREE_0_K304 160
#define FID_CONSUMER_TREE_0_K305 161
#define FID_CONSUMER_TREE_0_K306 162
#define FID_CONSUMER_TREE_0_K307 163
#define FID_CONSUMER_TREE_0_K308 164
#define FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0 165
#define FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K348 166
#define FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K349 167
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4 168
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4_K354 169
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0 170
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K363 171
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K364 172
#define FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_0 173
#define FID_LIST_SHOW_5 174
#define FID_LIST_SHOW_5_K370 175
#define FID_LIST_SHOW_5_K371 176
#define FID_LIST_SHOW_5_K372 177
#define FID_CONSUMER_SHOW_DESCRIPTOR_0 178
#define FID_CONSUMER_SHOW_DESCRIPTOR_0_K374 179
#define FID_CONSUMER_SHOW_DESCRIPTOR_0_K375 180
#define FID_CONSUMER_SHOW_DESCRIPTOR_0_K376 181
#define FID_CONSUMER_SHOW_DESCRIPTOR_0_K377 182
#define FID_CONSUMER_SHOW_DESCRIPTOR_0_K378 183
#define FID_CONSUMER_SHOW_DESCRIPTOR_0_K379 184
#define FID_LIST_SHOW_7 185
#define FID_LIST_SHOW_7_K381 186
#define FID_LIST_SHOW_7_K382 187
#define FID_LIST_SHOW_7_K383 188
#define FID_U32_SHOW 189
#define FID_CONSUMER_SHOW_COMPONENTS 190
#define FID_CONSUMER_SHOW_COMPONENTS_K387 191
#define FID_CONSUMER_SHOW_COMPONENTS_K388 192
#define FID_CONSUMER_SHOW_COMPONENTS_K389 193
#define FID_CONSUMER_SHOW_COMPONENTS_K390 194
#define FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0 195
#define FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K397 196
#define FID________________BENDVY_SRC_ECS_WORLD_BARRIER_0 197
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3 198
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3_K444 199
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2 200
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2_K450 201
#define FID_LIST_SHOW_GO_7 202
#define FID_LIST_SHOW_GO_7_K458 203
#define FID_LIST_SHOW_GO_7_K459 204
#define FID_LIST_SHOW_GO_7_K460 205
#define FID_CONSUMER_SHOW_FRAME_0 206
#define FID_CONSUMER_SHOW_FRAME_0_K462 207
#define FID_CONSUMER_SHOW_FRAME_0_K463 208
#define FID_CONSUMER_SHOW_FRAME_0_K464 209
#define FID_CONSUMER_SHOW_FRAME_0_K465 210
#define FID_CONSUMER_SHOW_FRAME_0_K466 211
#define FID_CONSUMER_SHOW_FRAME_0_K467 212
#define FID_CONSUMER_SHOW_FRAME_0_K468 213
#define FID_CONSUMER_SHOW_FRAME_0_K469 214
#define FID_CONSUMER_SHOW_FRAME_0_K470 215
#define FID_CONSUMER_SHOW_FRAME_0_K471 216
#define FID_CONSUMER_SHOW_FRAME_0_K472 217
#define FID_CONSUMER_SHOW_FRAME_0_K473 218
#define FID_CONSUMER_SHOW_FRAME_0_K474 219
#define FID_CONSUMER_SHOW_FRAME_0_K475 220
#define FID_CONSUMER_SHOW_FRAME_0_K476 221
#define FID_CONSUMER_SHOW_FRAME_0_K477 222
#define FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0 223
#define FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K479 224
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0 225
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0_K487 226
#define FID_CONSUMER_FINAL_BARRIER_0 227
#define FID_CONSUMER_FINAL_BARRIER_0_K527 228
#define FID_CONSUMER_FINAL_BARRIER_0_K528 229
#define FID_CONSUMER_FINAL_BARRIER_0_K529 230
#define FID_CONSUMER_LAST_0 231
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0 232
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_C538 233
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K539 234
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K540 235
#define FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0 236
#define FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_C545 237
#define FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K546 238
#define FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K547 239
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1 240
#define FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1_K551 241
#define FID_LIST_SHOW_6 242
#define FID_LIST_SHOW_6_K556 243
#define FID_LIST_SHOW_6_K557 244
#define FID_LIST_SHOW_6_K558 245
#define FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0 246
#define FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K560 247
#define FID_CONSUMER_DONE_0 248
#define FID_CONSUMER_DONE_0_K606 249
#define FID_CONSUMER_DONE_0_K607 250
#define FID_CONSUMER_DONE_0_K608 251
#define FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0 252
#define FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_C614 253
#define FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K615 254
#define FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K616 255
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0 256
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_C618 257
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K619 258
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K620 259
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K621 260
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K622 261
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K623 262
#define FID_CONSUMER_INCOMPLETE_OBSERVED_0 263
#define FID_CONSUMER_INCOMPLETE_OBSERVED_0_K628 264
#define FID_CONSUMER_INCOMPLETE_OBSERVED_0_K629 265
#define FID_CONSUMER_INCOMPLETE_OBSERVED_0_K630 266
#define FID_CONSUMER_INCOMPLETE_OBSERVED_0_K631 267
#define FID_CONSUMER_OBSERVE_0 268
#define FID_CONSUMER_OBSERVE_0_K633 269
#define FID_CONSUMER_OBSERVE_0_C634 270
#define FID_CONSUMER_OBSERVE_0_K635 271
#define FID_CONSUMER_OBSERVE_0_K636 272
#define FID_CONSUMER_OBSERVE_0_K637 273
#define FID_CONSUMER_OBSERVE_0_K638 274
#define FID_CONSUMER_OBSERVE_0_K639 275
#define FID_CONSUMER_OBSERVE_0_K640 276
#define FID_CONSUMER_OBSERVE_0_K641 277
#define FID_CONSUMER_OBSERVE_0_K642 278
#define FID_CONSUMER_OBSERVE_0_K643 279
#define FID_CONSUMER_OBSERVE_0_K644 280
#define FID_CONSUMER_OBSERVE_0_K645 281
#define FID_CONSUMER_OBSERVE_0_K646 282
#define FID_CONSUMER_OBSERVE_0_K647 283
#define FID_CONSUMER_OBSERVE_0_K648 284
#define FID_CONSUMER_OBSERVE_0_K649 285
#define FID_CONSUMER_OBSERVE_0_K650 286
#define FID_CONSUMER_OBSERVE_0_K651 287
#define FID_CONSUMER_OBSERVE_0_K652 288
#define FID_CONSUMER_OBSERVE_0_K653 289
#define FID_CONSUMER_OBSERVE_0_K654 290
#define FID_CONSUMER_OBSERVE_0_K655 291
#define FID_CONSUMER_OBSERVE_0_K656 292
#define FID_CONSUMER_OBSERVE_0_K657 293
#define FID_CONSUMER_OBSERVE_0_K658 294
#define FID_CONSUMER_OBSERVE_0_K659 295
#define FID_CONSUMER_OBSERVE_0_K660 296
#define FID_CONSUMER_OBSERVE_0_K661 297
#define FID_CONSUMER_OBSERVE_0_K662 298
#define FID_CONSUMER_OBSERVE_0_K663 299
#define FID_CONSUMER_OBSERVE_0_K664 300
#define FID_CONSUMER_OBSERVE_0_K665 301
#define FID_CONSUMER_OBSERVE_0_K666 302
#define FID_CONSUMER_OBSERVE_0_K667 303
#define FID_CONSUMER_OBSERVE_0_K668 304
#define FID_CONSUMER_OBSERVE_0_K669 305
#define FID_CONSUMER_OBSERVE_0_K670 306
#define FID_CONSUMER_OBSERVE_0_K671 307
#define FID_CONSUMER_OBSERVE_0_K672 308
#define FID_CONSUMER_OBSERVE_0_K673 309
#define FID_CONSUMER_OBSERVE_0_K674 310
#define FID_CONSUMER_OBSERVE_0_K675 311
#define FID_CONSUMER_OBSERVE_0_K676 312
#define FID_CONSUMER_COMPLETE_OBSERVED_0 313
#define FID_CONSUMER_COMPLETE_OBSERVED_0_K678 314
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0 315
#define FID_CONSUMER_RESUMED_ONCE_0 316
#define FID_CONSUMER_RESUMED_ONCE_0_K681 317
#define FID_CONSUMER_RESUMED_ONCE_0_K682 318
#define FID_CONSUMER_RESUMED_ONCE_0_K683 319
#define FID_CONSUMER_RESUMED_ONCE_0_K684 320
#define FID_STRING_APPEND 321
#define FID_STRING_APPEND_K686 322
#define FID_CONSUMER_SETUP_0 323
#define FID_CONSUMER_FIXTURE_0_C689 324
#define FID_CONSUMER_SETUP_0_K690 325
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0 326
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K692 327
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_C693 328
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_C694 329
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K695 330
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K696 331
#define FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K697 332
#define FID_CONSUMER_RESULT_OBSERVE_0 333
#define FID_CONSUMER_RESULT_OBSERVE_0_K699 334
#define FID_CONSUMER_RESULT_OBSERVE_0_K700 335
#define FID_MAIN 336
#define FID_MAIN_K715 337
#define FID_MAIN_K716 338
#define FID_MAIN_K717 339
#define FID_MAIN_K718 340
#define FID_MAIN_K719 341
#define FID_MAIN_K720 342
#define FID_MAIN_K721 343
#define FID_IO_EMIT 344
#define FID_CLO_APPLY 345
#define FID_EXIT 346
#define FID_ENTER 347
CONSTV u8 FID_T[][3] = { { 2, 0, 2 }, { 3, 1, 2 }, { 3, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 7, 0, 2 }, { 3, 0, 2 }, { 1, 1, 2 }, { 7, 0, 2 }, { 8, 0, 2 }, { 9, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 9, 0, 2 }, { 7, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 12, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 4, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 9, 0, 2 }, { 11, 2, 2 }, { 9, 0, 2 }, { 1, 1, 2 }, { 3, 1, 2 }, { 9, 0, 2 }, { 9, 1, 2 }, { 10, 2, 2 }, { 8, 1, 2 }, { 2, 1, 2 }, { 8, 0, 2 }, { 8, 1, 2 }, { 2, 0, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 6, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 6, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 8, 0, 2 }, { 8, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 3, 3, 2 }, { 1, 0, 2 }, { 4, 3, 2 }, { 5, 2, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 10, 0, 2 }, { 11, 1, 2 }, { 10, 2, 2 }, { 2, 2, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 6, 0, 2 }, { 7, 0, 2 }, { 2, 2, 2 }, { 1, 1, 2 }, { 8, 0, 2 }, { 6, 0, 2 }, { 7, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 4, 4, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 2, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 17, 0, 2 }, { 17, 16, 2 }, { 1, 1, 2 }, { 17, 0, 2 }, { 13, 1, 2 }, { 7, 0, 2 }, { 9, 2, 2 }, { 7, 1, 2 }, { 7, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 4, 0, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 16, 0, 2 }, { 17, 2, 2 }, { 16, 0, 2 }, { 17, 0, 2 }, { 13, 1, 2 }, { 17, 0, 2 }, { 13, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 8, 0, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 7, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 3, 2, 2 }, { 17, 0, 2 }, { 13, 1, 2 }, { 18, 0, 2 }, { 16, 16, 2 }, { 17, 17, 2 }, { 18, 17, 2 }, { 19, 0, 2 }, { 18, 0, 2 }, { 3, 0, 2 }, { 19, 17, 2 }, { 17, 1, 2 }, { 22, 0, 2 }, { 6, 0, 2 }, { 4, 2, 2 }, { 16, 16, 2 }, { 17, 0, 2 }, { 13, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 16, 0, 2 }, { 17, 2, 2 }, { 19, 0, 2 }, { 20, 19, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 24, 0, 2 }, { 9, 0, 2 }, { 9, 7, 2 }, { 27, 21, 2 }, { 27, 0, 2 }, { 6, 0, 2 }, { 5, 1, 2 }, { 24, 17, 2 }, { 19, 16, 2 }, { 24, 16, 2 }, { 17, 16, 2 }, { 18, 0, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 18, 1, 2 }, { 18, 1, 2 }, { 16, 0, 2 }, { 17, 17, 2 }, { 1, 0, 2 }, { 5, 3, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 18, 17, 2 }, { 19, 17, 2 }, { 20, 2, 2 }, { 21, 1, 2 }, { 22, 1, 2 }, { 23, 1, 2 }, { 24, 1, 2 }, { 25, 1, 2 }, { 26, 1, 2 }, { 26, 1, 2 }, { 27, 1, 2 }, { 28, 1, 2 }, { 29, 1, 2 }, { 29, 1, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 26, 1, 2 }, { 26, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 24, 1, 2 }, { 24, 1, 2 }, { 23, 1, 2 }, { 23, 1, 2 }, { 22, 1, 2 }, { 22, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 18, 1, 2 }, { 18, 1, 2 }, { 17, 1, 2 }, { 17, 1, 2 }, { 17, 0, 2 }, { 17, 1, 2 }, { 21, 0, 2 }, { 20, 0, 2 }, { 19, 18, 2 }, { 20, 19, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 17, 16, 2 }, { 20, 0, 2 }, { 20, 17, 2 }, { 4, 0, 2 }, { 20, 0, 2 }, { 18, 18, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 18, 0, 2 }, { 17, 17, 2 }, { 18, 17, 2 }, { 0, 0, 2 }, { 17, 16, 2 }, { 19, 18, 2 }, { 20, 19, 2 }, { 20, 18, 2 }, { 21, 19, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 15, 1 }, { 16, 1 }, { 0, 1 }, { 2, 1 }, { 0, 1 }, { 2, 1 }, { 1, 1 }, { 2, 1 }, { 7, 1 }, { 1, 1 }, { 13, 1 }, { 3, 1 }, { 1, 1 }, { 11, 1 }, { 1, 1 }, { 1, 1 }, { 4, 1 }, { 2, 1 }, { 3, 1 }, { 2, 1 }, { 11, 1 }, { 0, 1 }, { 0, 1 }, { 2, 1 }, { 6, 1 }, { 6, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 3, 1 }, { 2, 1 }, { 3, 1 }, { 3, 1 }, { 3, 1 }, { 3, 1 }, { 2, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 7, 1 } };
#define STAT_LEN 480

#define WL_RESW 21
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26

#define WL_TABLE WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS_K1) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_APPENDED_SOURCE) WL_X(FID_LIST_SHOW_GO_0) WL_X(FID_LIST_SHOW_GO_0_K5) WL_X(FID_LIST_SHOW_GO_0_K6) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID_K12) WL_X(FID_LIST_SHOW_0) WL_X(FID_LIST_SHOW_0_K21) WL_X(FID_LIST_SHOW_0_K22) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0_K26) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_C28) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K29) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K30) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K31) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0_K34) WL_X(FID_LIST_SHOW_GO_2) WL_X(FID_LIST_SHOW_GO_2_K53) WL_X(FID_LIST_SHOW_GO_2_K54) WL_X(FID_LIST_SHOW_GO_2_K55) WL_X(FID_CONSUMER_SHOW_REGISTRATION) WL_X(FID_CONSUMER_SHOW_REGISTRATION_K57) WL_X(FID_CONSUMER_SHOW_REGISTRATION_K58) WL_X(FID_CONSUMER_SHOW_REGISTRATION_K59) WL_X(FID_CONSUMER_SHOW_REGISTRATION_K60) WL_X(FID_CONSUMER_SHOW_REGISTRATION_K61) WL_X(FID_LIST_SHOW_GO_1) WL_X(FID_LIST_SHOW_GO_1_K63) WL_X(FID_LIST_SHOW_GO_1_K64) WL_X(FID_LIST_SHOW_GO_1_K65) WL_X(FID_CONSUMER_SHOW_NOTICE_0) WL_X(FID_CONSUMER_SHOW_NOTICE_0_K67) WL_X(FID_CONSUMER_SHOW_NOTICE_0_K68) WL_X(FID_NAT_SHOW_FIN) WL_X(FID_LIST_LENGTH) WL_X(FID_LIST_LENGTH_K72) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K74) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_C75) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K76) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K77) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K80) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K81) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K82) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K83) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0_K86) WL_X(FID_CONSUMER_SHOW_PAYLOAD) WL_X(FID_CONSUMER_SHOW_PAYLOAD_K97) WL_X(FID_CONSUMER_SHOW_PAYLOAD_K98) WL_X(FID_CONSUMER_SHOW_PAYLOAD_K99) WL_X(FID_CONSUMER_SHOW_PAYLOAD_K100) WL_X(FID_CONSUMER_SHOW_PAYLOAD_K101) WL_X(FID_CONSUMER_SHOW_PAYLOAD_K102) WL_X(FID_LIST_SHOW_GO_5) WL_X(FID_LIST_SHOW_GO_5_K107) WL_X(FID_LIST_SHOW_GO_5_K108) WL_X(FID_LIST_SHOW_GO_5_K109) WL_X(FID_CONSUMER_SHOW_INVERSE_0) WL_X(FID_CONSUMER_SHOW_INVERSE_0_K111) WL_X(FID_CONSUMER_SHOW_INVERSE_0_K112) WL_X(FID_CONSUMER_SHOW_INVERSE_0_K113) WL_X(FID_CONSUMER_SHOW_INVERSE_0_K114) WL_X(FID_CONSUMER_SHOW_INVERSE_0_K115) WL_X(FID_CONSUMER_SHOW_INVERSE_0_K116) WL_X(FID_LIST_SHOW_GO_3) WL_X(FID_LIST_SHOW_GO_3_K118) WL_X(FID_LIST_SHOW_GO_3_K119) WL_X(FID_LIST_SHOW_GO_3_K120) WL_X(FID_CONSUMER_SHOW_EDGE_0) WL_X(FID_CONSUMER_SHOW_EDGE_0_K122) WL_X(FID_CONSUMER_SHOW_EDGE_0_K123) WL_X(FID_CONSUMER_SHOW_EDGE_0_K124) WL_X(FID_CONSUMER_SHOW_EDGE_0_K125) WL_X(FID_CONSUMER_SHOW_EDGE_0_K126) WL_X(FID_CONSUMER_SHOW_EDGE_0_K127) WL_X(FID_LIST_SHOW_2) WL_X(FID_LIST_SHOW_2_K145) WL_X(FID_LIST_SHOW_2_K146) WL_X(FID_LIST_SHOW_2_K147) WL_X(FID_LIST_SHOW_1) WL_X(FID_LIST_SHOW_1_K149) WL_X(FID_LIST_SHOW_1_K150) WL_X(FID_LIST_SHOW_1_K151) WL_X(FID_NAT_SHOW) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0_K155) WL_X(FID_U32_SHOW_GO) WL_X(FID_CONSUMER_SHOW_SLOT) WL_X(FID_CONSUMER_SHOW_SLOT_K175) WL_X(FID_CONSUMER_SHOW_REMOVED) WL_X(FID_CONSUMER_SHOW_REMOVED_K180) WL_X(FID_CONSUMER_SHOW_REMOVED_K181) WL_X(FID_CONSUMER_SHOW_REMOVED_K182) WL_X(FID_CONSUMER_SHOW_REMOVED_K183) WL_X(FID_LIST_SHOW_4) WL_X(FID_LIST_SHOW_4_K188) WL_X(FID_LIST_SHOW_4_K189) WL_X(FID_LIST_SHOW_4_K190) WL_X(FID_LIST_SHOW_3) WL_X(FID_LIST_SHOW_3_K192) WL_X(FID_LIST_SHOW_3_K193) WL_X(FID_LIST_SHOW_3_K194) WL_X(FID_CONSUMER_NUMBER) WL_X(FID_CONSUMER_NUMBER_K201) WL_X(FID_CONSUMER_TREE_2) WL_X(FID_CONSUMER_TREE_2_K206) WL_X(FID_CONSUMER_TREE_2_K207) WL_X(FID_CONSUMER_TREE_2_K208) WL_X(FID_CONSUMER_TREE_2_K209) WL_X(FID_CONSUMER_TREE_2_K210) WL_X(FID_CONSUMER_TREE_2_K211) WL_X(FID_CONSUMER_TREE_2_K212) WL_X(FID_CONSUMER_TREE_2_K213) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K251) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K252) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K253) WL_X(FID_LIST_APPEND) WL_X(FID_LIST_APPEND_K260) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_C263) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K264) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K265) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0_C269) WL_X(FID_LIST_SHOW_GO_4) WL_X(FID_LIST_SHOW_GO_4_K272) WL_X(FID_LIST_SHOW_GO_4_K273) WL_X(FID_LIST_SHOW_GO_4_K274) WL_X(FID_LIST_SHOW_GO_6) WL_X(FID_LIST_SHOW_GO_6_K277) WL_X(FID_LIST_SHOW_GO_6_K278) WL_X(FID_LIST_SHOW_GO_6_K279) WL_X(FID_CONSUMER_TREE_1) WL_X(FID_CONSUMER_TREE_1_K282) WL_X(FID_CONSUMER_TREE_1_K283) WL_X(FID_CONSUMER_TREE_1_K284) WL_X(FID_CONSUMER_TREE_1_K285) WL_X(FID_CONSUMER_TREE_1_K286) WL_X(FID_CONSUMER_TREE_1_K287) WL_X(FID_CONSUMER_TREE_1_K288) WL_X(FID_CONSUMER_TREE_1_K289) WL_X(FID_CONSUMER_TREE_1_K290) WL_X(FID_CONSUMER_SHOW_GRAPH_0) WL_X(FID_CONSUMER_SHOW_GRAPH_0_K296) WL_X(FID_CONSUMER_SHOW_GRAPH_0_K297) WL_X(FID_CONSUMER_SHOW_GRAPH_0_K298) WL_X(FID_CONSUMER_TREE_0) WL_X(FID_CONSUMER_TREE_0_K300) WL_X(FID_CONSUMER_TREE_0_K301) WL_X(FID_CONSUMER_TREE_0_K302) WL_X(FID_CONSUMER_TREE_0_K303) WL_X(FID_CONSUMER_TREE_0_K304) WL_X(FID_CONSUMER_TREE_0_K305) WL_X(FID_CONSUMER_TREE_0_K306) WL_X(FID_CONSUMER_TREE_0_K307) WL_X(FID_CONSUMER_TREE_0_K308) WL_X(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0) WL_X(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K348) WL_X(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K349) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4_K354) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K363) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K364) WL_X(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_0) WL_X(FID_LIST_SHOW_5) WL_X(FID_LIST_SHOW_5_K370) WL_X(FID_LIST_SHOW_5_K371) WL_X(FID_LIST_SHOW_5_K372) WL_X(FID_CONSUMER_SHOW_DESCRIPTOR_0) WL_X(FID_CONSUMER_SHOW_DESCRIPTOR_0_K374) WL_X(FID_CONSUMER_SHOW_DESCRIPTOR_0_K375) WL_X(FID_CONSUMER_SHOW_DESCRIPTOR_0_K376) WL_X(FID_CONSUMER_SHOW_DESCRIPTOR_0_K377) WL_X(FID_CONSUMER_SHOW_DESCRIPTOR_0_K378) WL_X(FID_CONSUMER_SHOW_DESCRIPTOR_0_K379) WL_X(FID_LIST_SHOW_7) WL_X(FID_LIST_SHOW_7_K381) WL_X(FID_LIST_SHOW_7_K382) WL_X(FID_LIST_SHOW_7_K383) WL_X(FID_U32_SHOW) WL_X(FID_CONSUMER_SHOW_COMPONENTS) WL_X(FID_CONSUMER_SHOW_COMPONENTS_K387) WL_X(FID_CONSUMER_SHOW_COMPONENTS_K388) WL_X(FID_CONSUMER_SHOW_COMPONENTS_K389) WL_X(FID_CONSUMER_SHOW_COMPONENTS_K390) WL_X(FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0) WL_X(FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K397) WL_X(FID________________BENDVY_SRC_ECS_WORLD_BARRIER_0) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3_K444) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2_K450) WL_X(FID_LIST_SHOW_GO_7) WL_X(FID_LIST_SHOW_GO_7_K458) WL_X(FID_LIST_SHOW_GO_7_K459) WL_X(FID_LIST_SHOW_GO_7_K460) WL_X(FID_CONSUMER_SHOW_FRAME_0) WL_X(FID_CONSUMER_SHOW_FRAME_0_K462) WL_X(FID_CONSUMER_SHOW_FRAME_0_K463) WL_X(FID_CONSUMER_SHOW_FRAME_0_K464) WL_X(FID_CONSUMER_SHOW_FRAME_0_K465) WL_X(FID_CONSUMER_SHOW_FRAME_0_K466) WL_X(FID_CONSUMER_SHOW_FRAME_0_K467) WL_X(FID_CONSUMER_SHOW_FRAME_0_K468) WL_X(FID_CONSUMER_SHOW_FRAME_0_K469) WL_X(FID_CONSUMER_SHOW_FRAME_0_K470) WL_X(FID_CONSUMER_SHOW_FRAME_0_K471) WL_X(FID_CONSUMER_SHOW_FRAME_0_K472) WL_X(FID_CONSUMER_SHOW_FRAME_0_K473) WL_X(FID_CONSUMER_SHOW_FRAME_0_K474) WL_X(FID_CONSUMER_SHOW_FRAME_0_K475) WL_X(FID_CONSUMER_SHOW_FRAME_0_K476) WL_X(FID_CONSUMER_SHOW_FRAME_0_K477) WL_X(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0) WL_X(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K479) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0_K487) WL_X(FID_CONSUMER_FINAL_BARRIER_0) WL_X(FID_CONSUMER_FINAL_BARRIER_0_K527) WL_X(FID_CONSUMER_FINAL_BARRIER_0_K528) WL_X(FID_CONSUMER_FINAL_BARRIER_0_K529) WL_X(FID_CONSUMER_LAST_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_C538) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K539) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K540) WL_X(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_C545) WL_X(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K546) WL_X(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K547) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1) WL_X(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1_K551) WL_X(FID_LIST_SHOW_6) WL_X(FID_LIST_SHOW_6_K556) WL_X(FID_LIST_SHOW_6_K557) WL_X(FID_LIST_SHOW_6_K558) WL_X(FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0) WL_X(FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K560) WL_X(FID_CONSUMER_DONE_0) WL_X(FID_CONSUMER_DONE_0_K606) WL_X(FID_CONSUMER_DONE_0_K607) WL_X(FID_CONSUMER_DONE_0_K608) WL_X(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_C614) WL_X(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K615) WL_X(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K616) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_C618) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K619) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K620) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K621) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K622) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K623) WL_X(FID_CONSUMER_INCOMPLETE_OBSERVED_0) WL_X(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K628) WL_X(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K629) WL_X(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K630) WL_X(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K631) WL_X(FID_CONSUMER_OBSERVE_0) WL_X(FID_CONSUMER_OBSERVE_0_K633) WL_X(FID_CONSUMER_OBSERVE_0_C634) WL_X(FID_CONSUMER_OBSERVE_0_K635) WL_X(FID_CONSUMER_OBSERVE_0_K636) WL_X(FID_CONSUMER_OBSERVE_0_K637) WL_X(FID_CONSUMER_OBSERVE_0_K638) WL_X(FID_CONSUMER_OBSERVE_0_K639) WL_X(FID_CONSUMER_OBSERVE_0_K640) WL_X(FID_CONSUMER_OBSERVE_0_K641) WL_X(FID_CONSUMER_OBSERVE_0_K642) WL_X(FID_CONSUMER_OBSERVE_0_K643) WL_X(FID_CONSUMER_OBSERVE_0_K644) WL_X(FID_CONSUMER_OBSERVE_0_K645) WL_X(FID_CONSUMER_OBSERVE_0_K646) WL_X(FID_CONSUMER_OBSERVE_0_K647) WL_X(FID_CONSUMER_OBSERVE_0_K648) WL_X(FID_CONSUMER_OBSERVE_0_K649) WL_X(FID_CONSUMER_OBSERVE_0_K650) WL_X(FID_CONSUMER_OBSERVE_0_K651) WL_X(FID_CONSUMER_OBSERVE_0_K652) WL_X(FID_CONSUMER_OBSERVE_0_K653) WL_X(FID_CONSUMER_OBSERVE_0_K654) WL_X(FID_CONSUMER_OBSERVE_0_K655) WL_X(FID_CONSUMER_OBSERVE_0_K656) WL_X(FID_CONSUMER_OBSERVE_0_K657) WL_X(FID_CONSUMER_OBSERVE_0_K658) WL_X(FID_CONSUMER_OBSERVE_0_K659) WL_X(FID_CONSUMER_OBSERVE_0_K660) WL_X(FID_CONSUMER_OBSERVE_0_K661) WL_X(FID_CONSUMER_OBSERVE_0_K662) WL_X(FID_CONSUMER_OBSERVE_0_K663) WL_X(FID_CONSUMER_OBSERVE_0_K664) WL_X(FID_CONSUMER_OBSERVE_0_K665) WL_X(FID_CONSUMER_OBSERVE_0_K666) WL_X(FID_CONSUMER_OBSERVE_0_K667) WL_X(FID_CONSUMER_OBSERVE_0_K668) WL_X(FID_CONSUMER_OBSERVE_0_K669) WL_X(FID_CONSUMER_OBSERVE_0_K670) WL_X(FID_CONSUMER_OBSERVE_0_K671) WL_X(FID_CONSUMER_OBSERVE_0_K672) WL_X(FID_CONSUMER_OBSERVE_0_K673) WL_X(FID_CONSUMER_OBSERVE_0_K674) WL_X(FID_CONSUMER_OBSERVE_0_K675) WL_X(FID_CONSUMER_OBSERVE_0_K676) WL_X(FID_CONSUMER_COMPLETE_OBSERVED_0) WL_X(FID_CONSUMER_COMPLETE_OBSERVED_0_K678) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0) WL_X(FID_CONSUMER_RESUMED_ONCE_0) WL_X(FID_CONSUMER_RESUMED_ONCE_0_K681) WL_X(FID_CONSUMER_RESUMED_ONCE_0_K682) WL_X(FID_CONSUMER_RESUMED_ONCE_0_K683) WL_X(FID_CONSUMER_RESUMED_ONCE_0_K684) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K686) WL_X(FID_CONSUMER_SETUP_0) WL_X(FID_CONSUMER_FIXTURE_0_C689) WL_X(FID_CONSUMER_SETUP_0_K690) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K692) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_C693) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_C694) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K695) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K696) WL_X(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K697) WL_X(FID_CONSUMER_RESULT_OBSERVE_0) WL_X(FID_CONSUMER_RESULT_OBSERVE_0_K699) WL_X(FID_CONSUMER_RESULT_OBSERVE_0_K700) WL_X(FID_MAIN) WL_X(FID_MAIN_K715) WL_X(FID_MAIN_K716) WL_X(FID_MAIN_K717) WL_X(FID_MAIN_K718) WL_X(FID_MAIN_K719) WL_X(FID_MAIN_K720) WL_X(FID_MAIN_K721) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 1
#define BLK_SHR 1

#if !DEVICE

static const u32 SHOW_DESC[] = { 4 };

static const char* SHOW_NAMES[] = {  };

#endif

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 93ull, term_pak(CID_SNIL, 0), 32ull, term_pak(CID_SNIL, 0), 44ull, term_ctr(CID_SCON, STAT_OFF + 2), 41ull, term_pak(CID_SNIL, 0), 44ull, term_pak(CID_SNIL, 0), 40ull, term_pak(CID_SNIL, 0), 80ull, term_ctr(CID_SCON, STAT_OFF + 10), 101ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 14), 108ull, term_ctr(CID_SCON, STAT_OFF + 16), 97ull, term_ctr(CID_SCON, STAT_OFF + 18), 70ull, term_ctr(CID_SCON, STAT_OFF + 20), 117ull, term_ctr(CID_SCON, STAT_OFF + 14), 114ull, term_ctr(CID_SCON, STAT_OFF + 24), 84ull, term_ctr(CID_SCON, STAT_OFF + 26), 91ull, term_ctr(CID_SCON, STAT_OFF + 0), 91ull, term_pak(CID_SNIL, 0), 59ull, term_pak(CID_SNIL, 0), 78ull, term_ctr(CID_SCON, STAT_OFF + 10), 58ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 38), 97ull, term_ctr(CID_SCON, STAT_OFF + 40), 110ull, term_ctr(CID_SCON, STAT_OFF + 42), 105ull, term_ctr(CID_SCON, STAT_OFF + 44), 103ull, term_ctr(CID_SCON, STAT_OFF + 46), 105ull, term_ctr(CID_SCON, STAT_OFF + 48), 114ull, term_ctr(CID_SCON, STAT_OFF + 50), 111ull, term_ctr(CID_SCON, STAT_OFF + 52), 100ull, term_ctr(CID_SCON, STAT_OFF + 38), 101ull, term_ctr(CID_SCON, STAT_OFF + 56), 118ull, term_ctr(CID_SCON, STAT_OFF + 58), 111ull, term_ctr(CID_SCON, STAT_OFF + 60), 109ull, term_ctr(CID_SCON, STAT_OFF + 62), 101ull, term_ctr(CID_SCON, STAT_OFF + 64), 114ull, term_ctr(CID_SCON, STAT_OFF + 66), 69ull, term_pak(CID_SNIL, 0), 67ull, term_ctr(CID_SCON, STAT_OFF + 70), 73ull, term_ctr(CID_SCON, STAT_OFF + 72), 84ull, term_ctr(CID_SCON, STAT_OFF + 74), 79ull, term_ctr(CID_SCON, STAT_OFF + 76), 78ull, term_ctr(CID_SCON, STAT_OFF + 78), 95ull, term_ctr(CID_SCON, STAT_OFF + 80), 68ull, term_ctr(CID_SCON, STAT_OFF + 82), 69ull, term_ctr(CID_SCON, STAT_OFF + 84), 84ull, term_ctr(CID_SCON, STAT_OFF + 86), 67ull, term_ctr(CID_SCON, STAT_OFF + 88), 69ull, term_ctr(CID_SCON, STAT_OFF + 90), 80ull, term_ctr(CID_SCON, STAT_OFF + 92), 88ull, term_ctr(CID_SCON, STAT_OFF + 94), 69ull, term_ctr(CID_SCON, STAT_OFF + 96), 78ull, term_ctr(CID_SCON, STAT_OFF + 98), 85ull, term_ctr(CID_SCON, STAT_OFF + 100), 62ull, term_pak(CID_SNIL, 0), 76ull, term_ctr(CID_SCON, STAT_OFF + 10), 116ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 108), 101ull, term_ctr(CID_SCON, STAT_OFF + 110), 115ull, term_ctr(CID_SCON, STAT_OFF + 112), 98ull, term_ctr(CID_SCON, STAT_OFF + 114), 97ull, term_ctr(CID_SCON, STAT_OFF + 116), 61ull, term_pak(CID_SNIL, 0), 100ull, term_ctr(CID_SCON, STAT_OFF + 120), 101ull, term_ctr(CID_SCON, STAT_OFF + 122), 118ull, term_ctr(CID_SCON, STAT_OFF + 124), 111ull, term_ctr(CID_SCON, STAT_OFF + 126), 109ull, term_ctr(CID_SCON, STAT_OFF + 128), 101ull, term_ctr(CID_SCON, STAT_OFF + 130), 114ull, term_ctr(CID_SCON, STAT_OFF + 132), 47ull, term_ctr(CID_SCON, STAT_OFF + 134), 107ull, term_ctr(CID_SCON, STAT_OFF + 120), 99ull, term_ctr(CID_SCON, STAT_OFF + 138), 111ull, term_ctr(CID_SCON, STAT_OFF + 140), 108ull, term_ctr(CID_SCON, STAT_OFF + 142), 99ull, term_ctr(CID_SCON, STAT_OFF + 144), 47ull, term_ctr(CID_SCON, STAT_OFF + 146), 109ull, term_ctr(CID_SCON, STAT_OFF + 120), 101ull, term_ctr(CID_SCON, STAT_OFF + 150), 116ull, term_ctr(CID_SCON, STAT_OFF + 152), 115ull, term_ctr(CID_SCON, STAT_OFF + 154), 121ull, term_ctr(CID_SCON, STAT_OFF + 156), 83ull, term_ctr(CID_SCON, STAT_OFF + 158), 116ull, term_ctr(CID_SCON, STAT_OFF + 160), 120ull, term_ctr(CID_SCON, STAT_OFF + 162), 101ull, term_ctr(CID_SCON, STAT_OFF + 164), 110ull, term_ctr(CID_SCON, STAT_OFF + 166), 47ull, term_ctr(CID_SCON, STAT_OFF + 168), 115ull, term_ctr(CID_SCON, STAT_OFF + 120), 103ull, term_ctr(CID_SCON, STAT_OFF + 172), 101ull, term_ctr(CID_SCON, STAT_OFF + 174), 114ull, term_ctr(CID_SCON, STAT_OFF + 176), 47ull, term_ctr(CID_SCON, STAT_OFF + 178), 103ull, term_ctr(CID_SCON, STAT_OFF + 120), 110ull, term_ctr(CID_SCON, STAT_OFF + 182), 105ull, term_ctr(CID_SCON, STAT_OFF + 184), 100ull, term_ctr(CID_SCON, STAT_OFF + 186), 110ull, term_ctr(CID_SCON, STAT_OFF + 188), 101ull, term_ctr(CID_SCON, STAT_OFF + 190), 112ull, term_ctr(CID_SCON, STAT_OFF + 192), 47ull, term_ctr(CID_SCON, STAT_OFF + 194), 116ull, term_ctr(CID_SCON, STAT_OFF + 172), 110ull, term_ctr(CID_SCON, STAT_OFF + 198), 101ull, term_ctr(CID_SCON, STAT_OFF + 200), 118ull, term_ctr(CID_SCON, STAT_OFF + 202), 101ull, term_ctr(CID_SCON, STAT_OFF + 204), 47ull, term_ctr(CID_SCON, STAT_OFF + 206), 101ull, term_ctr(CID_SCON, STAT_OFF + 120), 99ull, term_ctr(CID_SCON, STAT_OFF + 210), 114ull, term_ctr(CID_SCON, STAT_OFF + 212), 117ull, term_ctr(CID_SCON, STAT_OFF + 214), 111ull, term_ctr(CID_SCON, STAT_OFF + 216), 115ull, term_ctr(CID_SCON, STAT_OFF + 218), 101ull, term_ctr(CID_SCON, STAT_OFF + 220), 114ull, term_ctr(CID_SCON, STAT_OFF + 222), 47ull, term_ctr(CID_SCON, STAT_OFF + 224), 47ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 122), 114ull, term_ctr(CID_SCON, STAT_OFF + 230), 111ull, term_ctr(CID_SCON, STAT_OFF + 232), 119ull, term_ctr(CID_SCON, STAT_OFF + 234), 121ull, term_pak(CID_SNIL, 0), 114ull, term_ctr(CID_SCON, STAT_OFF + 238), 97ull, term_ctr(CID_SCON, STAT_OFF + 240), 110ull, term_ctr(CID_SCON, STAT_OFF + 242), 105ull, term_ctr(CID_SCON, STAT_OFF + 244), 100ull, term_ctr(CID_SCON, STAT_OFF + 246), 114ull, term_ctr(CID_SCON, STAT_OFF + 248), 111ull, term_ctr(CID_SCON, STAT_OFF + 250), 104ull, term_ctr(CID_SCON, STAT_OFF + 238), 99ull, term_ctr(CID_SCON, STAT_OFF + 254), 114ull, term_ctr(CID_SCON, STAT_OFF + 256), 97ull, term_ctr(CID_SCON, STAT_OFF + 258), 114ull, term_ctr(CID_SCON, STAT_OFF + 260), 101ull, term_ctr(CID_SCON, STAT_OFF + 262), 105ull, term_ctr(CID_SCON, STAT_OFF + 264), 104ull, term_ctr(CID_SCON, STAT_OFF + 266), 48ull, term_pak(CID_SNIL, 0), 104ull, term_ctr(CID_SCON, STAT_OFF + 120), 112ull, term_ctr(CID_SCON, STAT_OFF + 272), 97ull, term_ctr(CID_SCON, STAT_OFF + 274), 114ull, term_ctr(CID_SCON, STAT_OFF + 276), 103ull, term_ctr(CID_SCON, STAT_OFF + 278), 47ull, term_ctr(CID_SCON, STAT_OFF + 280), 114ull, term_ctr(CID_SCON, STAT_OFF + 38), 101ull, term_ctr(CID_SCON, STAT_OFF + 284), 116ull, term_ctr(CID_SCON, STAT_OFF + 286), 110ull, term_ctr(CID_SCON, STAT_OFF + 288), 101ull, term_ctr(CID_SCON, STAT_OFF + 290), 115ull, term_ctr(CID_SCON, STAT_OFF + 38), 114ull, term_ctr(CID_SCON, STAT_OFF + 294), 111ull, term_ctr(CID_SCON, STAT_OFF + 296), 116ull, term_ctr(CID_SCON, STAT_OFF + 298), 112ull, term_ctr(CID_SCON, STAT_OFF + 300), 105ull, term_ctr(CID_SCON, STAT_OFF + 302), 114ull, term_ctr(CID_SCON, STAT_OFF + 304), 99ull, term_ctr(CID_SCON, STAT_OFF + 306), 115ull, term_ctr(CID_SCON, STAT_OFF + 308), 101ull, term_ctr(CID_SCON, STAT_OFF + 310), 100ull, term_ctr(CID_SCON, STAT_OFF + 312), 110ull, term_ctr(CID_SCON, STAT_OFF + 38), 101ull, term_ctr(CID_SCON, STAT_OFF + 316), 114ull, term_ctr(CID_SCON, STAT_OFF + 318), 100ull, term_ctr(CID_SCON, STAT_OFF + 320), 108ull, term_ctr(CID_SCON, STAT_OFF + 322), 105ull, term_ctr(CID_SCON, STAT_OFF + 324), 104ull, term_ctr(CID_SCON, STAT_OFF + 326), 99ull, term_ctr(CID_SCON, STAT_OFF + 328), 104ull, term_ctr(CID_SCON, STAT_OFF + 38), 115ull, term_ctr(CID_SCON, STAT_OFF + 332), 105ull, term_ctr(CID_SCON, STAT_OFF + 334), 110ull, term_ctr(CID_SCON, STAT_OFF + 336), 105ull, term_ctr(CID_SCON, STAT_OFF + 338), 102ull, term_ctr(CID_SCON, STAT_OFF + 340), 10ull, term_pak(CID_SNIL, 0), 114ull, term_ctr(CID_SCON, STAT_OFF + 112), 97ull, term_ctr(CID_SCON, STAT_OFF + 346), 80ull, term_ctr(CID_SCON, STAT_OFF + 348), 110ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 352), 114ull, term_ctr(CID_SCON, STAT_OFF + 354), 100ull, term_ctr(CID_SCON, STAT_OFF + 356), 108ull, term_ctr(CID_SCON, STAT_OFF + 358), 105ull, term_ctr(CID_SCON, STAT_OFF + 360), 104ull, term_ctr(CID_SCON, STAT_OFF + 362), 67ull, term_ctr(CID_SCON, STAT_OFF + 364), 107ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 368), 105ull, term_ctr(CID_SCON, STAT_OFF + 370), 76ull, term_ctr(CID_SCON, STAT_OFF + 372), 66ull, term_ctr(CID_SCON, STAT_OFF + 238), 100ull, term_ctr(CID_SCON, STAT_OFF + 376), 101ull, term_ctr(CID_SCON, STAT_OFF + 378), 107ull, term_ctr(CID_SCON, STAT_OFF + 380), 110ull, term_ctr(CID_SCON, STAT_OFF + 382), 105ull, term_ctr(CID_SCON, STAT_OFF + 384), 76ull, term_ctr(CID_SCON, STAT_OFF + 386), 99ull, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL, STAT_OFF + 390), term_pak(CID_NIL, 0), 103ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 393), 105ull, term_ctr(CID_SCON, STAT_OFF + 395), 116ull, term_ctr(CID_SCON, STAT_OFF + 397), 115ull, term_ctr(CID_SCON, STAT_OFF + 399), 105ull, term_ctr(CID_SCON, STAT_OFF + 401), 120ull, term_ctr(CID_SCON, STAT_OFF + 403), 69ull, term_ctr(CID_SCON, STAT_OFF + 405), term_ctr(CID_SCON, STAT_OFF + 350), term_pak(CID_NIL, 0), term_ctr(CID_SCON, STAT_OFF + 374), term_ctr(CID_CON, STAT_OFF + 409), 1ull, term_ctr(CID_SCON, STAT_OFF + 407), term_ctr(CID_CON, STAT_OFF + 411), term_ctr(CID________________BENDVY_SRC_ECS_WORLD_REGISTRATIONMETA, STAT_OFF + 413), term_pak(CID_NIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 172), 109ull, term_ctr(CID_SCON, STAT_OFF + 418), 97ull, term_ctr(CID_SCON, STAT_OFF + 420), 114ull, term_ctr(CID_SCON, STAT_OFF + 422), 102ull, term_ctr(CID_SCON, STAT_OFF + 424), 47ull, term_ctr(CID_SCON, STAT_OFF + 426), 101ull, term_ctr(CID_SCON, STAT_OFF + 428), 116ull, term_ctr(CID_SCON, STAT_OFF + 430), 101ull, term_ctr(CID_SCON, STAT_OFF + 432), 108ull, term_ctr(CID_SCON, STAT_OFF + 434), 112ull, term_ctr(CID_SCON, STAT_OFF + 436), 109ull, term_ctr(CID_SCON, STAT_OFF + 438), 111ull, term_ctr(CID_SCON, STAT_OFF + 440), 99ull, term_ctr(CID_SCON, STAT_OFF + 442), 110ull, term_ctr(CID_SCON, STAT_OFF + 444), 105ull, term_ctr(CID_SCON, STAT_OFF + 446), 101ull, term_ctr(CID_SCON, STAT_OFF + 228), 116ull, term_ctr(CID_SCON, STAT_OFF + 450), 101ull, term_ctr(CID_SCON, STAT_OFF + 452), 108ull, term_ctr(CID_SCON, STAT_OFF + 454), 112ull, term_ctr(CID_SCON, STAT_OFF + 456), 109ull, term_ctr(CID_SCON, STAT_OFF + 458), 111ull, term_ctr(CID_SCON, STAT_OFF + 460), 99ull, term_ctr(CID_SCON, STAT_OFF + 462), 1ull, term_ctr(CID_SCON, STAT_OFF + 374), term_ctr(CID_SCON, STAT_OFF + 388), 0, 2ull, term_ctr(CID_SCON, STAT_OFF + 350), term_ctr(CID_SCON, STAT_OFF + 366), 1, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_DESCRIPTOR, STAT_OFF + 470), term_pak(CID_NIL, 0), term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_DESCRIPTOR, STAT_OFF + 466), term_ctr(CID_CON, STAT_OFF + 474), term_pak(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPENTER, 1ull), term_pak(CID_NIL, 0) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_1 = 0;
  u32 _remove_0 = r0;
  u32 _id_2 = r1;
  Term _rest_0 = r2;
  WL_SPIN
    if (_remove_0 == 1) {
      _v_1 = _rest_0;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _id_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, _rest_0);
      _v_1 = term_ctr(CID_CON, _nd_0);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _qr_0 = r0;
  Term _qr_1 = r1;
  WL_SPIN
    _v_4 = ((u64)(u32)(nat_chk(e, 48ull + _qr_1)));
    _v_5 = _qr_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  u32 _v_3 = 0;
  u32 _descriptor_4 = r0;
  Term _descriptor_5 = r1;
  Term _descriptor_6 = r2;
  u32 _descriptor_7 = r3;
  WL_SPIN
    _v_3 = _descriptor_4;
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_7 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_7 = 0;
    } else {
      _v_7 = _b_0;
    }
  break;
  }
  o[0] = _v_7;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_1 = 0;
  u32 _descriptor_8 = r0;
  Term _descriptor_9 = r1;
  Term _descriptor_10 = r2;
  u32 _descriptor_11 = r3;
  u32 _target_2 = r4;
  Term _sources_1 = r5;
  Term _rest_2 = r6;
  WL_SPIN
    if (term_aux(_sources_1) == CID_NIL) {
      term_sink(e, _descriptor_9);
      term_sink(e, _descriptor_10);
      _v_1 = _rest_2;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _sources_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _descriptor_8);
      e.mem[_nd_1 + 1] = rfc_seal(e, _descriptor_9);
      e.mem[_nd_1 + 2] = rfc_seal(e, _descriptor_10);
      e.mem[_nd_1 + 3] = rfc_seal(e, _descriptor_11);
      e.mem[_nd_1 + 4] = rfc_seal(e, _target_2);
      e.mem[_nd_1 + 5] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_INVERSE, _nd_1));
      e.mem[_nd_2 + 1] = rfc_seal(e, _rest_2);
      _v_1 = term_ctr(CID_CON, _nd_2);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 22);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 28);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_8 = 0;
  Term _xs_1 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_8 = _acc_1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_9);
    }
  break;
  }
  o[0] = _v_8;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_6 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_7 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_9(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_7 = _o_0[0];
    _v_6 = _v_7;
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term _v_19 = 0;
  u32 _remove_0 = r0;
  u32 _edge_6 = r1;
  Term _edge_7 = r2;
  Term _edge_8 = r3;
  u32 _edge_9 = r4;
  u32 _edge_10 = r5;
  u32 _edge_11 = r6;
  Term _rest_0 = r7;
  WL_SPIN
    if (_remove_0 == 1) {
      term_sink(e, _edge_7);
      term_sink(e, _edge_8);
      _v_19 = _rest_0;
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _edge_6);
      e.mem[_nd_1 + 1] = rfc_seal(e, _edge_7);
      e.mem[_nd_1 + 2] = rfc_seal(e, _edge_8);
      e.mem[_nd_1 + 3] = rfc_seal(e, _edge_9);
      e.mem[_nd_1 + 4] = rfc_seal(e, _edge_10);
      e.mem[_nd_1 + 5] = rfc_seal(e, _edge_11);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_EDGE, _nd_1));
      e.mem[_nd_2 + 1] = rfc_seal(e, _rest_0);
      _v_19 = term_ctr(CID_CON, _nd_2);
    }
  break;
  }
  o[0] = _v_19;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  Term _v_11 = 0;
  u32 _edge_0 = r0;
  Term _edge_1 = r1;
  Term _edge_2 = r2;
  u32 _edge_3 = r3;
  u32 _edge_4 = r4;
  u32 _edge_5 = r5;
  u32 _descriptor_12 = r6;
  Term _descriptor_13 = r7;
  Term _descriptor_14 = r8;
  u32 _descriptor_15 = r9;
  u32 _source_3 = r10;
  Term _acc_2 = r11;
  WL_SPIN
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_2[1];
    if (spin_2(e, _o_2, _edge_0, _edge_1, _edge_1 == h1 ? q1 : blk_loc(e.mem, _edge_1), _edge_2, _edge_2 == h2 ? q2 : blk_loc(e.mem, _edge_2), _edge_3) == 0) {
      return 0;
    }
    _v_14 = _o_2[0];
    _v_13 = _v_14;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    Term _o_3[1];
    if (spin_2(e, _o_3, _descriptor_12, _descriptor_13, _descriptor_13 == h7 ? q7 : blk_loc(e.mem, _descriptor_13), _descriptor_14, _descriptor_14 == h8 ? q8 : blk_loc(e.mem, _descriptor_14), _descriptor_15) == 0) {
      return 0;
    }
    _v_16 = _o_3[0];
    _v_15 = _v_16;
    u32 _v_17 = 0;
    Term _o_4[1];
    if (spin_3(e, _o_4, U32_BIN(_v_13, ==, _v_15), U32_BIN(_edge_4, ==, _source_3)) == 0) {
      return 0;
    }
    _v_17 = _o_4[0];
    _v_12 = _v_17;
    Term _v_18 = 0;
    Term _o_5[1];
    if (spin_11(e, _o_5, _v_12, _edge_0, _edge_1, _edge_1 == h1 ? q1 : blk_loc(e.mem, _edge_1), _edge_2, _edge_2 == h2 ? q2 : blk_loc(e.mem, _edge_2), _edge_3, _edge_4, _edge_5, _acc_2, _acc_2 == h11 ? q11 : blk_loc(e.mem, _acc_2)) == 0) {
      return 0;
    }
    _v_18 = _o_5[0];
    _v_11 = _v_18;
  break;
  }
  o[0] = _v_11;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h6 = r6;
  Term _v_4 = 0;
  Term _edges_2 = r0;
  u32 _descriptor_8 = r1;
  Term _descriptor_9 = r2;
  Term _descriptor_10 = r3;
  u32 _descriptor_11 = r4;
  u32 _source_2 = r5;
  Term _acc_0 = r6;
  WL_SPIN
    if (term_aux(_edges_2) == CID_NIL) {
      Term _v_5 = 0;
      Term _o_1[1];
      if (spin_8(e, _o_1, _acc_0, _acc_0 == h6 ? q6 : blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_5 = _o_1[0];
      _v_4 = _v_5;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _edges_2, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _fb_2[6];
      u64 _sp_2 = ctr_take(e, _f_2, 6, _fb_2);
      u32 _f_4 = _fb_2[0];
      Term _f_5 = _fb_2[1];
      Term _f_6 = _fb_2[2];
      u32 _f_7 = _fb_2[3];
      u32 _f_8 = _fb_2[4];
      u32 _f_9 = _fb_2[5];
      spare_free(e, cls_fit(6), _sp_2);
      Term _v_9 = 0;
      Term _v_10 = 0;
      Term _o_6[1];
      if (spin_10(e, _o_6, _f_4, _f_5, _f_5 == h6 ? q6 : _f_5 == h3 ? q3 : _f_5 == h2 ? q2 : _f_5 == h0 ? q0 : blk_loc(e.mem, _f_5), _f_6, _f_6 == h6 ? q6 : _f_6 == h3 ? q3 : _f_6 == h2 ? q2 : _f_6 == h0 ? q0 : blk_loc(e.mem, _f_6), _f_7, _f_8, _f_9, _descriptor_8, _descriptor_9, _descriptor_9 == h2 ? q2 : blk_loc(e.mem, _descriptor_9), _descriptor_10, _descriptor_10 == h3 ? q3 : blk_loc(e.mem, _descriptor_10), _descriptor_11, _source_2, _acc_0, _acc_0 == h6 ? q6 : blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_10 = _o_6[0];
      _v_9 = _v_10;
      spare_free(e, cls_fit(2), _sp_1);
      r0 = _f_3;
      r1 = _descriptor_8;
      r2 = _descriptor_9;
      r3 = _descriptor_10;
      r4 = _descriptor_11;
      r5 = _source_2;
      r6 = _v_9;
      _edges_2 = r0;
      _descriptor_8 = r1;
      _descriptor_9 = r2;
      _descriptor_10 = r3;
      _descriptor_11 = r4;
      _source_2 = r5;
      _acc_0 = r6;
      WL_AGAIN(spin_7);
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_2 = 0;
  Term _edges_1 = r0;
  u32 _descriptor_4 = r1;
  Term _descriptor_5 = r2;
  Term _descriptor_6 = r3;
  u32 _descriptor_7 = r4;
  u32 _source_1 = r5;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_7[1];
    Term _a_1 = term_pak(CID_NIL, 0);
    if (spin_7(e, _o_7, _edges_1, _edges_1 == h0 ? q0 : blk_loc(e.mem, _edges_1), _descriptor_4, _descriptor_5, _descriptor_5 == h2 ? q2 : blk_loc(e.mem, _descriptor_5), _descriptor_6, _descriptor_6 == h3 ? q3 : blk_loc(e.mem, _descriptor_6), _descriptor_7, _source_1, _a_1, _a_1 == h3 ? q3 : _a_1 == h2 ? q2 : _a_1 == h0 ? q0 : blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_3 = _o_7[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_4 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_4 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_13);
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_13(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_6 = 0;
  Term _reversed_0 = r0;
  Term _output_0 = r1;
  WL_SPIN
    if (term_aux(_reversed_0) == CID_NIL) {
      _v_6 = _output_0;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _reversed_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u32 _o_2 = 0;
      Term _o_3 = 0;
      Term _o_4 = 0;
      Term _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      u32 _o_10 = 0;
      u32 _o_11 = 0;
      Term _o_12 = 0;
      Term _o_13 = 0;
      if (term_aux(_f_2) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL) {
        _o_2 = 0;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_2, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_3 = _f_4;
      } else if (term_aux(_f_2) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED) {
        _o_2 = 1;
        Term _fb_3[11];
        u64 _sp_3 = ctr_take(e, _f_2, 11, _fb_3);
        u32 _f_5 = _fb_3[0];
        Term _f_6 = _fb_3[1];
        Term _f_7 = _fb_3[2];
        u32 _f_8 = _fb_3[3];
        u32 _f_9 = _fb_3[4];
        u32 _f_10 = _fb_3[5];
        u32 _f_11 = _fb_3[6];
        u32 _f_12 = _fb_3[7];
        u32 _f_13 = _fb_3[8];
        Term _f_14 = _fb_3[9];
        Term _f_15 = _fb_3[10];
        spare_free(e, cls_fit(11), _sp_3);
        _o_3 = _f_5;
        _o_4 = _f_6;
        _o_5 = _f_7;
        _o_6 = _f_8;
        _o_7 = _f_9;
        _o_8 = _f_10;
        _o_9 = _f_11;
        _o_10 = _f_12;
        _o_11 = _f_13;
        _o_12 = _f_14;
        _o_13 = _f_15;
      } else if (term_aux(_f_2) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED) {
        _o_2 = 2;
        _o_3 = term_loc(_f_2);
      } else {
        _o_2 = 3;
        Term _fb_4[1];
        u64 _sp_4 = ctr_take(e, _f_2, 1, _fb_4);
        Term _f_16 = _fb_4[0];
        spare_free(e, cls_fit(1), _sp_4);
        _o_3 = _f_16;
      }
      Term _b_0 = 0;
      if (_o_2 == 0) {
        u64 _nd_1 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_1 + 0] = rfc_seal(e, _o_3);
        _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL, _nd_1);
      } else if (_o_2 == 1) {
        u64 _nd_2 = heap_alloc(e, cls_fit(11));
        e.mem[_nd_2 + 0] = rfc_seal(e, _o_3);
        e.mem[_nd_2 + 1] = rfc_seal(e, _o_4);
        e.mem[_nd_2 + 2] = rfc_seal(e, _o_5);
        e.mem[_nd_2 + 3] = rfc_seal(e, _o_6);
        e.mem[_nd_2 + 4] = rfc_seal(e, _o_7);
        e.mem[_nd_2 + 5] = rfc_seal(e, _o_8);
        e.mem[_nd_2 + 6] = rfc_seal(e, _o_9);
        e.mem[_nd_2 + 7] = rfc_seal(e, _o_10);
        e.mem[_nd_2 + 8] = rfc_seal(e, _o_11);
        e.mem[_nd_2 + 9] = rfc_seal(e, _o_12);
        e.mem[_nd_2 + 10] = rfc_seal(e, _o_13);
        _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED, _nd_2);
      } else if (_o_2 == 2) {
        _b_0 = term_pak(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED, _o_3);
      } else {
        u64 _nd_3 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_3 + 0] = rfc_seal(e, _o_3);
        _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_CLEANUPPAUSED, _nd_3);
      }
      u64 _nd_4 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_4 + 1] = rfc_seal(e, _output_0);
      r0 = _f_3;
      r1 = term_ctr(CID_CON, _nd_4);
      _reversed_0 = r0;
      _output_0 = r1;
      WL_AGAIN(spin_14);
    }
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_3 = 0;
  Term _xs_1 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_3 = _acc_1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_16);
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_1 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_2 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_16(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  Term _v_3 = 0;
  u32 _value_1 = r0;
  WL_SPIN
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_0[1];
    if (spin_5(e, _o_0, _value_1) == 0) {
      return 0;
    }
    _v_5 = _o_0[0];
    _v_4 = _v_5;
    _v_2 = _value_1;
    _v_3 = _v_4;
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, u32 r0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _previous_0 = r0;
  u32 _previous_1 = r1;
  u32 _target_2 = r2;
  WL_SPIN
    if (_previous_0 == 0) {
      _v_2 = 0;
    } else {
      _v_2 = U32_BIN(_previous_1, ==, _target_2);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_2 = 0;
  Term _left_0 = r0;
  Term _right_0 = r1;
  WL_SPIN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_0[1];
    if (spin_12(e, _o_0, _left_0, _left_0 == h0 ? q0 : blk_loc(e.mem, _left_0)) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_3 = _v_4;
    Term _v_5 = 0;
    Term _o_1[1];
    if (spin_14(e, _o_1, _v_3, _v_3 == h1 ? q1 : _v_3 == h0 ? q0 : blk_loc(e.mem, _v_3), _right_0, _right_0 == h1 ? q1 : blk_loc(e.mem, _right_0)) == 0) {
      return 0;
    }
    _v_5 = _o_1[0];
    _v_2 = _v_5;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _observed_0 = r0;
  Term _observed_1 = r1;
  Term _observed_2 = r2;
  WL_SPIN
    _v_4 = 1;
    _v_5 = _observed_0;
    _v_6 = _observed_1;
    _v_7 = _observed_2;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  u32 _value_1 = r0;
  WL_SPIN
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[2];
    if (spin_18(e, _o_0, _value_1) == 0) {
      return 0;
    }
    _v_6 = _o_0[0];
    _v_7 = _o_0[1];
    _v_4 = _v_6;
    _v_5 = _v_7;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_7 = 0;
  u32 _descriptor_8 = r0;
  Term _descriptor_9 = r1;
  Term _descriptor_10 = r2;
  u32 _descriptor_11 = r3;
  WL_SPIN
    term_sink(e, _descriptor_10);
    _v_7 = _descriptor_9;
  break;
  }
  o[0] = _v_7;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h6 = r6;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  u32 _sourceLive_2 = r0;
  u32 _targetLive_2 = r1;
  u32 _self_0 = r2;
  u32 _cyclic_0 = r3;
  u32 _source_2 = r4;
  u32 _target_2 = r5;
  Term _name_0 = r6;
  WL_SPIN
    if (_sourceLive_2 == 0) {
      term_sink(e, _name_0);
      _v_13 = 1;
      _v_14 = 0;
      _v_15 = _source_2;
      _v_16 = 0;
      _v_17 = 0;
    } else {
      if (_targetLive_2 == 0) {
        _v_13 = 1;
        _v_14 = 1;
        _v_15 = _source_2;
        _v_16 = _target_2;
        _v_17 = _name_0;
      } else {
        if (_self_0 == 1) {
          _v_13 = 1;
          _v_14 = 2;
          _v_15 = _source_2;
          _v_16 = _name_0;
          _v_17 = 0;
        } else {
          if (_cyclic_0 == 1) {
            _v_13 = 1;
            _v_14 = 3;
            _v_15 = _source_2;
            _v_16 = _target_2;
            _v_17 = _name_0;
          } else {
            term_sink(e, _name_0);
            _v_13 = 0;
            _v_14 = 0;
            _v_15 = 0;
            _v_16 = 0;
            _v_17 = 0;
          }
        }
      }
    }
  break;
  }
  o[0] = _v_13;
  o[1] = _v_14;
  o[2] = _v_15;
  o[3] = _v_16;
  o[4] = _v_17;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, u32 r16, u32 r17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _allowed_0 = r0;
  u32 _value_1 = r1;
  u32 _world_0 = r2;
  u32 _world_1 = r3;
  u32 _world_2 = r4;
  Term _world_3 = r5;
  u32 _world_4 = r6;
  Term _world_5 = r7;
  Term _world_6 = r8;
  Term _world_7 = r9;
  Term _world_8 = r10;
  Term _world_9 = r11;
  Term _world_10 = r12;
  Term _world_11 = r13;
  Term _world_12 = r14;
  Term _world_13 = r15;
  u32 _world_14 = r16;
  u32 _world_15 = r17;
  u32 _handle_2 = r18;
  u32 _handle_3 = r19;
  WL_SPIN
    if (_allowed_0 == 0) {
      _v_18 = _world_0;
      _v_19 = _world_1;
      _v_20 = _world_2;
      _v_21 = _world_3;
      _v_22 = _world_4;
      _v_23 = _world_5;
      _v_24 = _world_6;
      _v_25 = _world_7;
      _v_26 = _world_8;
      _v_27 = _world_9;
      _v_28 = _world_10;
      _v_29 = _world_11;
      _v_30 = _world_12;
      _v_31 = _world_13;
      _v_32 = _world_14;
      _v_33 = _world_15;
      _v_34 = 1;
      _v_35 = 0;
    } else {
      Term _at_0 = _world_3 == h5 ? q5 : blk_loc(e.mem, _world_3);
      Term _at_1 = blk_at(_world_3, _handle_3, 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      blk_write(e.mem, 0, _at_0, _at_1 + 0, _value_1);
      _v_18 = _world_0;
      _v_19 = _world_1;
      _v_20 = _world_2;
      _v_21 = _world_3;
      _v_22 = _world_4;
      _v_23 = _world_5;
      _v_24 = _world_6;
      _v_25 = _world_7;
      _v_26 = _world_8;
      _v_27 = _world_9;
      _v_28 = _world_10;
      _v_29 = _world_11;
      _v_30 = _world_12;
      _v_31 = _world_13;
      _v_32 = _world_14;
      _v_33 = _world_15;
      _v_34 = 0;
      _v_35 = 0;
    }
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  o[9] = _v_27;
  o[10] = _v_28;
  o[11] = _v_29;
  o[12] = _v_30;
  o[13] = _v_31;
  o[14] = _v_32;
  o[15] = _v_33;
  o[16] = _v_34;
  o[17] = _v_35;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h16 = r16;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _world_16 = r0;
  u32 _world_17 = r1;
  u32 _world_18 = r2;
  Term _world_19 = r3;
  u32 _world_20 = r4;
  Term _world_21 = r5;
  Term _world_22 = r6;
  Term _world_23 = r7;
  Term _world_24 = r8;
  Term _world_25 = r9;
  Term _world_26 = r10;
  Term _world_27 = r11;
  Term _world_28 = r12;
  Term _world_29 = r13;
  u32 _world_30 = r14;
  u32 _world_31 = r15;
  Term _published_1 = r16;
  WL_SPIN
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _o_12[1];
    if (spin_20(e, _o_12, _world_27, _world_27 == h11 ? q11 : blk_loc(e.mem, _world_27), _published_1, _published_1 == h16 ? q16 : blk_loc(e.mem, _published_1)) == 0) {
      return 0;
    }
    _v_33 = _o_12[0];
    _v_32 = _v_33;
    _v_16 = _world_16;
    _v_17 = _world_17;
    _v_18 = _world_18;
    _v_19 = _world_19;
    _v_20 = _world_20;
    _v_21 = _world_21;
    _v_22 = _world_22;
    _v_23 = _world_23;
    _v_24 = _world_24;
    _v_25 = _world_25;
    _v_26 = _world_26;
    _v_27 = _v_32;
    _v_28 = _world_28;
    _v_29 = _world_29;
    _v_30 = _world_30;
    _v_31 = _world_31;
  break;
  }
  o[0] = _v_16;
  o[1] = _v_17;
  o[2] = _v_18;
  o[3] = _v_19;
  o[4] = _v_20;
  o[5] = _v_21;
  o[6] = _v_22;
  o[7] = _v_23;
  o[8] = _v_24;
  o[9] = _v_25;
  o[10] = _v_26;
  o[11] = _v_27;
  o[12] = _v_28;
  o[13] = _v_29;
  o[14] = _v_30;
  o[15] = _v_31;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _result_0 = r0;
  Term _result_1 = r1;
  u32 _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _components_0 = r7;
  Term _components_1 = r8;
  WL_SPIN
    _v_9 = _components_0;
    _v_10 = _components_1;
    _v_11 = _result_0;
    _v_12 = _result_1;
    _v_13 = _result_2;
    _v_14 = _result_3;
    _v_15 = _result_4;
    _v_16 = _result_5;
    _v_17 = _result_6;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, Term r14, Term r15, u64 q15, Term r16, u64 q16, Term r17, u64 q17, Term r18, u64 q18, u32 r19, u32 r20) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h15 = r15;
  Term h16 = r16;
  Term h17 = r17;
  Term h18 = r18;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _observed_0 = r0;
  Term _observed_1 = r1;
  Term _observed_2 = r2;
  Term _observed_3 = r3;
  u32 _observed_4 = r4;
  u32 _observed_5 = r5;
  u32 _observed_6 = r6;
  Term _observed_7 = r7;
  Term _observed_8 = r8;
  u32 _namespace_0 = r9;
  u32 _nextId_0 = r10;
  u32 _highWater_0 = r11;
  Term _live_0 = r12;
  u32 _capacity_0 = r13;
  Term _depth_0 = r14;
  Term _resource_0 = r15;
  Term _events_0 = r16;
  Term _pending_0 = r17;
  Term _registrations_0 = r18;
  u32 _nextSystemId_0 = r19;
  u32 _clock_0 = r20;
  WL_SPIN
    _v_21 = _namespace_0;
    _v_22 = _nextId_0;
    _v_23 = _highWater_0;
    _v_24 = _live_0;
    _v_25 = _capacity_0;
    _v_26 = _depth_0;
    _v_27 = _observed_0;
    _v_28 = _observed_1;
    _v_29 = _observed_2;
    _v_30 = _observed_3;
    _v_31 = _resource_0;
    _v_32 = _events_0;
    _v_33 = _pending_0;
    _v_34 = _registrations_0;
    _v_35 = _nextSystemId_0;
    _v_36 = _clock_0;
    _v_37 = _observed_4;
    _v_38 = _observed_5;
    _v_39 = _observed_6;
    _v_40 = _observed_7;
    _v_41 = _observed_8;
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  o[4] = _v_25;
  o[5] = _v_26;
  o[6] = _v_27;
  o[7] = _v_28;
  o[8] = _v_29;
  o[9] = _v_30;
  o[10] = _v_31;
  o[11] = _v_32;
  o[12] = _v_33;
  o[13] = _v_34;
  o[14] = _v_35;
  o[15] = _v_36;
  o[16] = _v_37;
  o[17] = _v_38;
  o[18] = _v_39;
  o[19] = _v_40;
  o[20] = _v_41;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h16 = r16;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  Term _world_10 = r10;
  Term _world_11 = r11;
  Term _world_12 = r12;
  Term _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  Term _published_0 = r16;
  WL_SPIN
    if (term_aux(_published_0) == CID_NIL) {
      _v_16 = _world_0;
      _v_17 = _world_1;
      _v_18 = _world_2;
      _v_19 = _world_3;
      _v_20 = _world_4;
      _v_21 = _world_5;
      _v_22 = _world_6;
      _v_23 = _world_7;
      _v_24 = _world_8;
      _v_25 = _world_9;
      _v_26 = _world_10;
      _v_27 = _world_11;
      _v_28 = _world_12;
      _v_29 = _world_13;
      _v_30 = _world_14;
      _v_31 = _world_15;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _published_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      u32 _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      Term _o_11 = 0;
      if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL) {
        _o_0 = 0;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        _o_1 = _f_2;
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED) {
        _o_0 = 1;
        Term _fb_2[11];
        u64 _sp_2 = ctr_take(e, _f_0, 11, _fb_2);
        u32 _f_3 = _fb_2[0];
        Term _f_4 = _fb_2[1];
        Term _f_5 = _fb_2[2];
        u32 _f_6 = _fb_2[3];
        u32 _f_7 = _fb_2[4];
        u32 _f_8 = _fb_2[5];
        u32 _f_9 = _fb_2[6];
        u32 _f_10 = _fb_2[7];
        u32 _f_11 = _fb_2[8];
        Term _f_12 = _fb_2[9];
        Term _f_13 = _fb_2[10];
        spare_free(e, cls_fit(11), _sp_2);
        _o_1 = _f_3;
        _o_2 = _f_4;
        _o_3 = _f_5;
        _o_4 = _f_6;
        _o_5 = _f_7;
        _o_6 = _f_8;
        _o_7 = _f_9;
        _o_8 = _f_10;
        _o_9 = _f_11;
        _o_10 = _f_12;
        _o_11 = _f_13;
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED) {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 3;
        Term _fb_3[1];
        u64 _sp_3 = ctr_take(e, _f_0, 1, _fb_3);
        Term _f_14 = _fb_3[0];
        spare_free(e, cls_fit(1), _sp_3);
        _o_1 = _f_14;
      }
      Term _b_0 = 0;
      if (_o_0 == 0) {
        u64 _nd_2 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_2 + 0] = rfc_seal(e, _o_1);
        _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL, _nd_2);
      } else if (_o_0 == 1) {
        u64 _nd_3 = heap_alloc(e, cls_fit(11));
        e.mem[_nd_3 + 0] = rfc_seal(e, _o_1);
        e.mem[_nd_3 + 1] = rfc_seal(e, _o_2);
        e.mem[_nd_3 + 2] = rfc_seal(e, _o_3);
        e.mem[_nd_3 + 3] = rfc_seal(e, _o_4);
        e.mem[_nd_3 + 4] = rfc_seal(e, _o_5);
        e.mem[_nd_3 + 5] = rfc_seal(e, _o_6);
        e.mem[_nd_3 + 6] = rfc_seal(e, _o_7);
        e.mem[_nd_3 + 7] = rfc_seal(e, _o_8);
        e.mem[_nd_3 + 8] = rfc_seal(e, _o_9);
        e.mem[_nd_3 + 9] = rfc_seal(e, _o_10);
        e.mem[_nd_3 + 10] = rfc_seal(e, _o_11);
        _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED, _nd_3);
      } else if (_o_0 == 2) {
        _b_0 = term_pak(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED, _o_1);
      } else {
        u64 _nd_4 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_4 + 0] = rfc_seal(e, _o_1);
        _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_CLEANUPPAUSED, _nd_4);
      }
      u64 _nd_5 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_5 + 1] = rfc_seal(e, _f_1);
      u32 _v_32 = 0;
      u32 _v_33 = 0;
      u32 _v_34 = 0;
      Term _v_35 = 0;
      u32 _v_36 = 0;
      Term _v_37 = 0;
      Term _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      u32 _v_46 = 0;
      u32 _v_47 = 0;
      Term _o_12[16];
      Term _a_0 = term_ctr(CID_CON, _nd_5);
      if (spin_26(e, _o_12, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_10 == h10 ? q10 : blk_loc(e.mem, _world_10), _world_11, _world_11 == h11 ? q11 : blk_loc(e.mem, _world_11), _world_12, _world_12 == h12 ? q12 : blk_loc(e.mem, _world_12), _world_13, _world_13 == h13 ? q13 : blk_loc(e.mem, _world_13), _world_14, _world_15, _a_0, _a_0 == h16 ? q16 : _a_0 == h13 ? q13 : _a_0 == h12 ? q12 : _a_0 == h11 ? q11 : _a_0 == h10 ? q10 : _a_0 == h9 ? q9 : _a_0 == h8 ? q8 : _a_0 == h7 ? q7 : _a_0 == h6 ? q6 : _a_0 == h3 ? q3 : blk_loc(e.mem, _a_0)) == 0) {
        return 0;
      }
      _v_32 = _o_12[0];
      _v_33 = _o_12[1];
      _v_34 = _o_12[2];
      _v_35 = _o_12[3];
      _v_36 = _o_12[4];
      _v_37 = _o_12[5];
      _v_38 = _o_12[6];
      _v_39 = _o_12[7];
      _v_40 = _o_12[8];
      _v_41 = _o_12[9];
      _v_42 = _o_12[10];
      _v_43 = _o_12[11];
      _v_44 = _o_12[12];
      _v_45 = _o_12[13];
      _v_46 = _o_12[14];
      _v_47 = _o_12[15];
      _v_16 = _v_32;
      _v_17 = _v_33;
      _v_18 = _v_34;
      _v_19 = _v_35;
      _v_20 = _v_36;
      _v_21 = _v_37;
      _v_22 = _v_38;
      _v_23 = _v_39;
      _v_24 = _v_40;
      _v_25 = _v_41;
      _v_26 = _v_42;
      _v_27 = _v_43;
      _v_28 = _v_44;
      _v_29 = _v_45;
      _v_30 = _v_46;
      _v_31 = _v_47;
    }
  break;
  }
  o[0] = _v_16;
  o[1] = _v_17;
  o[2] = _v_18;
  o[3] = _v_19;
  o[4] = _v_20;
  o[5] = _v_21;
  o[6] = _v_22;
  o[7] = _v_23;
  o[8] = _v_24;
  o[9] = _v_25;
  o[10] = _v_26;
  o[11] = _v_27;
  o[12] = _v_28;
  o[13] = _v_29;
  o[14] = _v_30;
  o[15] = _v_31;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term _v_3 = 0;
  Term _v_4 = 0;
  Term _v_5 = 0;
  u32 _id_0 = r0;
  Term _observed_0 = r1;
  u32 _observed_1 = r2;
  Term _observed_2 = r3;
  Term _observed_3 = r4;
  Term _removed_0 = r5;
  WL_SPIN
    if (_observed_1 == 0) {
      _v_3 = _observed_0;
      _v_4 = _removed_0;
      _v_5 = term_pak(CID_NIL, 0);
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _observed_2);
      e.mem[_nd_1 + 1] = rfc_seal(e, _observed_3);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_PAYLOAD, _nd_1));
      e.mem[_nd_2 + 1] = rfc_seal(e, _removed_0);
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, term_pak(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED, _id_0));
      e.mem[_nd_3 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      _v_3 = _observed_0;
      _v_4 = term_ctr(CID_CON, _nd_2);
      _v_5 = term_ctr(CID_CON, _nd_3);
    }
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _world_16 = r0;
  u32 _world_17 = r1;
  u32 _world_18 = r2;
  Term _world_19 = r3;
  u32 _world_20 = r4;
  Term _world_21 = r5;
  Term _world_22 = r6;
  Term _world_23 = r7;
  Term _world_24 = r8;
  Term _world_25 = r9;
  Term _world_26 = r10;
  Term _world_27 = r11;
  Term _world_28 = r12;
  Term _world_29 = r13;
  u32 _world_30 = r14;
  u32 _world_31 = r15;
  u32 _handle_2 = r16;
  u32 _handle_3 = r17;
  WL_SPIN
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    Term _o_0[1];
    if (spin_3(e, _o_0, U32_BIN(0ull, <, _handle_3), U32_BIN(_handle_3, <, _world_17)) == 0) {
      return 0;
    }
    _v_53 = _o_0[0];
    _v_52 = _v_53;
    u32 _v_54 = 0;
    Term _o_1[1];
    if (spin_3(e, _o_1, U32_BIN(_world_16, ==, _handle_2), _v_52) == 0) {
      return 0;
    }
    _v_54 = _o_1[0];
    _v_51 = _v_54;
    _v_34 = _world_16;
    _v_35 = _world_17;
    _v_36 = _world_18;
    _v_37 = _world_19;
    _v_38 = _world_20;
    _v_39 = _world_21;
    _v_40 = _world_22;
    _v_41 = _world_23;
    _v_42 = _world_24;
    _v_43 = _world_25;
    _v_44 = _world_26;
    _v_45 = _world_27;
    _v_46 = _world_28;
    _v_47 = _world_29;
    _v_48 = _world_30;
    _v_49 = _world_31;
    _v_50 = _v_51;
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  o[7] = _v_41;
  o[8] = _v_42;
  o[9] = _v_43;
  o[10] = _v_44;
  o[11] = _v_45;
  o[12] = _v_46;
  o[13] = _v_47;
  o[14] = _v_48;
  o[15] = _v_49;
  o[16] = _v_50;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, u64 q6, u32 r7, Term r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, u32 r18, u32 r19) {
  u32 wpoll = 0;
  Term h6 = r6;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  u32 _v_73 = 0;
  u32 _v_74 = 0;
  u32 _v_75 = 0;
  Term _v_76 = 0;
  u32 _v_77 = 0;
  Term _v_78 = 0;
  Term _v_79 = 0;
  Term _v_80 = 0;
  Term _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  Term _v_85 = 0;
  Term _v_86 = 0;
  u32 _v_87 = 0;
  u32 _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  u32 _value_0 = r0;
  u32 _handle_4 = r1;
  u32 _handle_5 = r2;
  u32 _checked_0 = r3;
  u32 _checked_1 = r4;
  u32 _checked_2 = r5;
  Term _checked_3 = r6;
  u32 _checked_4 = r7;
  Term _checked_5 = r8;
  Term _checked_6 = r9;
  Term _checked_7 = r10;
  Term _checked_8 = r11;
  Term _checked_9 = r12;
  Term _checked_10 = r13;
  Term _checked_11 = r14;
  Term _checked_12 = r15;
  Term _checked_13 = r16;
  u32 _checked_14 = r17;
  u32 _checked_15 = r18;
  u32 _checked_16 = r19;
  WL_SPIN
    u32 _v_91 = 0;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    Term _v_94 = 0;
    u32 _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    Term _v_99 = 0;
    Term _v_100 = 0;
    Term _v_101 = 0;
    Term _v_102 = 0;
    Term _v_103 = 0;
    Term _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    Term _o_3[18];
    if (spin_25(e, _o_3, _checked_16, _value_0, _checked_0, _checked_1, _checked_2, _checked_3, _checked_3 == h6 ? q6 : blk_loc(e.mem, _checked_3), _checked_4, _checked_5, _checked_6, _checked_6 == h9 ? q9 : blk_loc(e.mem, _checked_6), _checked_7, _checked_7 == h10 ? q10 : blk_loc(e.mem, _checked_7), _checked_8, _checked_8 == h11 ? q11 : blk_loc(e.mem, _checked_8), _checked_9, _checked_9 == h12 ? q12 : blk_loc(e.mem, _checked_9), _checked_10, _checked_10 == h13 ? q13 : blk_loc(e.mem, _checked_10), _checked_11, _checked_11 == h14 ? q14 : blk_loc(e.mem, _checked_11), _checked_12, _checked_12 == h15 ? q15 : blk_loc(e.mem, _checked_12), _checked_13, _checked_13 == h16 ? q16 : blk_loc(e.mem, _checked_13), _checked_14, _checked_15, _handle_4, _handle_5) == 0) {
      return 0;
    }
    _v_91 = _o_3[0];
    _v_92 = _o_3[1];
    _v_93 = _o_3[2];
    _v_94 = _o_3[3];
    _v_95 = _o_3[4];
    _v_96 = _o_3[5];
    _v_97 = _o_3[6];
    _v_98 = _o_3[7];
    _v_99 = _o_3[8];
    _v_100 = _o_3[9];
    _v_101 = _o_3[10];
    _v_102 = _o_3[11];
    _v_103 = _o_3[12];
    _v_104 = _o_3[13];
    _v_105 = _o_3[14];
    _v_106 = _o_3[15];
    _v_107 = _o_3[16];
    _v_108 = _o_3[17];
    _v_73 = _v_91;
    _v_74 = _v_92;
    _v_75 = _v_93;
    _v_76 = _v_94;
    _v_77 = _v_95;
    _v_78 = _v_96;
    _v_79 = _v_97;
    _v_80 = _v_98;
    _v_81 = _v_99;
    _v_82 = _v_100;
    _v_83 = _v_101;
    _v_84 = _v_102;
    _v_85 = _v_103;
    _v_86 = _v_104;
    _v_87 = _v_105;
    _v_88 = _v_106;
    _v_89 = _v_107;
    _v_90 = _v_108;
  break;
  }
  o[0] = _v_73;
  o[1] = _v_74;
  o[2] = _v_75;
  o[3] = _v_76;
  o[4] = _v_77;
  o[5] = _v_78;
  o[6] = _v_79;
  o[7] = _v_80;
  o[8] = _v_81;
  o[9] = _v_82;
  o[10] = _v_83;
  o[11] = _v_84;
  o[12] = _v_85;
  o[13] = _v_86;
  o[14] = _v_87;
  o[15] = _v_88;
  o[16] = _v_89;
  o[17] = _v_90;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _handle_2 = r0;
  u32 _handle_3 = r1;
  WL_SPIN
    _v_24 = 0;
    _v_25 = _handle_3;
    _v_26 = 0;
    _v_27 = 0;
    _v_28 = 0;
    _v_29 = 0;
    _v_30 = 0;
    _v_31 = 0;
    _v_32 = 0;
    _v_33 = 0;
    _v_34 = 0;
    _v_35 = 0;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _checked_0 = r0;
  u32 _checked_1 = r1;
  u32 _namespace_0 = r2;
  u32 _nextId_0 = r3;
  u32 _highWater_0 = r4;
  u32 _capacity_0 = r5;
  Term _depth_0 = r6;
  Term _store_0 = r7;
  Term _store_1 = r8;
  Term _store_2 = r9;
  Term _store_3 = r10;
  Term _resource_0 = r11;
  Term _events_0 = r12;
  Term _pending_0 = r13;
  Term _registrations_0 = r14;
  u32 _nextSystemId_0 = r15;
  u32 _clock_0 = r16;
  WL_SPIN
    _v_17 = _namespace_0;
    _v_18 = _nextId_0;
    _v_19 = _highWater_0;
    _v_20 = _checked_0;
    _v_21 = _capacity_0;
    _v_22 = _depth_0;
    _v_23 = _store_0;
    _v_24 = _store_1;
    _v_25 = _store_2;
    _v_26 = _store_3;
    _v_27 = _resource_0;
    _v_28 = _events_0;
    _v_29 = _pending_0;
    _v_30 = _registrations_0;
    _v_31 = _nextSystemId_0;
    _v_32 = _clock_0;
    _v_33 = _checked_1;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _kind_0 = r0;
  WL_SPIN
    if (_kind_0 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 252);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 268);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h5 = r5;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _observed_0 = r0;
  Term _observed_1 = r1;
  u32 _namespace_0 = r2;
  u32 _nextId_0 = r3;
  u32 _highWater_0 = r4;
  Term _live_0 = r5;
  u32 _capacity_0 = r6;
  Term _depth_0 = r7;
  Term _store_0 = r8;
  Term _store_1 = r9;
  Term _store_2 = r10;
  Term _store_3 = r11;
  Term _events_0 = r12;
  Term _pending_0 = r13;
  Term _registrations_0 = r14;
  u32 _nextSystemId_0 = r15;
  u32 _clock_0 = r16;
  WL_SPIN
    _v_17 = _namespace_0;
    _v_18 = _nextId_0;
    _v_19 = _highWater_0;
    _v_20 = _live_0;
    _v_21 = _capacity_0;
    _v_22 = _depth_0;
    _v_23 = _store_0;
    _v_24 = _store_1;
    _v_25 = _store_2;
    _v_26 = _store_3;
    _v_27 = _observed_0;
    _v_28 = _events_0;
    _v_29 = _pending_0;
    _v_30 = _registrations_0;
    _v_31 = _nextSystemId_0;
    _v_32 = _clock_0;
    _v_33 = _observed_1;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _available_0 = r0;
  u32 _clock_0 = r1;
  WL_SPIN
    if (_available_0 == 0) {
      _v_2 = _clock_0;
    } else {
      _v_2 = U32_BIN(_clock_0, +, 1ull);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, u32 r21, Term r22, u64 q22, Term r23, u64 q23, u32 r24, u32 r25, u32 r26) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h19 = r19;
  Term h20 = r20;
  Term h22 = r22;
  Term h23 = r23;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _observed_0 = r0;
  u32 _observed_1 = r1;
  u32 _observed_2 = r2;
  Term _observed_3 = r3;
  u32 _observed_4 = r4;
  Term _observed_5 = r5;
  Term _observed_6 = r6;
  Term _observed_7 = r7;
  Term _observed_8 = r8;
  Term _observed_9 = r9;
  Term _observed_10 = r10;
  Term _observed_11 = r11;
  Term _observed_12 = r12;
  Term _observed_13 = r13;
  u32 _observed_14 = r14;
  u32 _observed_15 = r15;
  u32 _observed_16 = r16;
  u32 _observed_17 = r17;
  u32 _observed_18 = r18;
  Term _observed_19 = r19;
  Term _observed_20 = r20;
  u32 _descriptor_12 = r21;
  Term _descriptor_13 = r22;
  Term _descriptor_14 = r23;
  u32 _descriptor_15 = r24;
  u32 _source_3 = r25;
  u32 _target_3 = r26;
  WL_SPIN
    if (_observed_16 == 0) {
      term_sink(e, _descriptor_13);
      term_sink(e, _descriptor_14);
      _v_25 = _observed_0;
      _v_26 = _observed_1;
      _v_27 = _observed_2;
      _v_28 = _observed_3;
      _v_29 = _observed_4;
      _v_30 = _observed_5;
      _v_31 = _observed_6;
      _v_32 = _observed_7;
      _v_33 = _observed_8;
      _v_34 = _observed_9;
      _v_35 = _observed_10;
      _v_36 = _observed_11;
      _v_37 = _observed_12;
      _v_38 = _observed_13;
      _v_39 = _observed_14;
      _v_40 = _observed_15;
    } else {
      u64 _nd_12 = heap_alloc(e, cls_fit(11));
      e.mem[_nd_12 + 0] = rfc_seal(e, _descriptor_12);
      e.mem[_nd_12 + 1] = rfc_seal(e, _descriptor_13);
      e.mem[_nd_12 + 2] = rfc_seal(e, _descriptor_14);
      e.mem[_nd_12 + 3] = rfc_seal(e, _descriptor_15);
      e.mem[_nd_12 + 4] = rfc_seal(e, 0);
      e.mem[_nd_12 + 5] = rfc_seal(e, _source_3);
      e.mem[_nd_12 + 6] = rfc_seal(e, _target_3);
      e.mem[_nd_12 + 7] = rfc_seal(e, _observed_17);
      e.mem[_nd_12 + 8] = rfc_seal(e, _observed_18);
      e.mem[_nd_12 + 9] = rfc_seal(e, _observed_19);
      e.mem[_nd_12 + 10] = rfc_seal(e, _observed_20);
      u64 _nd_13 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_13 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED, _nd_12));
      e.mem[_nd_13 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u32 _v_41 = 0;
      u32 _v_42 = 0;
      u32 _v_43 = 0;
      Term _v_44 = 0;
      u32 _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      Term _v_48 = 0;
      Term _v_49 = 0;
      Term _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      Term _v_54 = 0;
      u32 _v_55 = 0;
      u32 _v_56 = 0;
      Term _o_1[16];
      Term _a_0 = term_ctr(CID_CON, _nd_13);
      if (spin_29(e, _o_1, _observed_0, _observed_1, _observed_2, _observed_3, _observed_3 == h3 ? q3 : blk_loc(e.mem, _observed_3), _observed_4, _observed_5, _observed_6, _observed_6 == h6 ? q6 : blk_loc(e.mem, _observed_6), _observed_7, _observed_7 == h7 ? q7 : blk_loc(e.mem, _observed_7), _observed_8, _observed_8 == h8 ? q8 : blk_loc(e.mem, _observed_8), _observed_9, _observed_9 == h9 ? q9 : blk_loc(e.mem, _observed_9), _observed_10, _observed_10 == h10 ? q10 : blk_loc(e.mem, _observed_10), _observed_11, _observed_11 == h11 ? q11 : blk_loc(e.mem, _observed_11), _observed_12, _observed_12 == h12 ? q12 : blk_loc(e.mem, _observed_12), _observed_13, _observed_13 == h13 ? q13 : blk_loc(e.mem, _observed_13), _observed_14, _observed_15, _a_0, _a_0 == h23 ? q23 : _a_0 == h22 ? q22 : _a_0 == h20 ? q20 : _a_0 == h19 ? q19 : _a_0 == h13 ? q13 : _a_0 == h12 ? q12 : _a_0 == h11 ? q11 : _a_0 == h10 ? q10 : _a_0 == h9 ? q9 : _a_0 == h8 ? q8 : _a_0 == h7 ? q7 : _a_0 == h6 ? q6 : _a_0 == h3 ? q3 : blk_loc(e.mem, _a_0)) == 0) {
        return 0;
      }
      _v_41 = _o_1[0];
      _v_42 = _o_1[1];
      _v_43 = _o_1[2];
      _v_44 = _o_1[3];
      _v_45 = _o_1[4];
      _v_46 = _o_1[5];
      _v_47 = _o_1[6];
      _v_48 = _o_1[7];
      _v_49 = _o_1[8];
      _v_50 = _o_1[9];
      _v_51 = _o_1[10];
      _v_52 = _o_1[11];
      _v_53 = _o_1[12];
      _v_54 = _o_1[13];
      _v_55 = _o_1[14];
      _v_56 = _o_1[15];
      _v_25 = _v_41;
      _v_26 = _v_42;
      _v_27 = _v_43;
      _v_28 = _v_44;
      _v_29 = _v_45;
      _v_30 = _v_46;
      _v_31 = _v_47;
      _v_32 = _v_48;
      _v_33 = _v_49;
      _v_34 = _v_50;
      _v_35 = _v_51;
      _v_36 = _v_52;
      _v_37 = _v_53;
      _v_38 = _v_54;
      _v_39 = _v_55;
      _v_40 = _v_56;
    }
  break;
  }
  o[0] = _v_25;
  o[1] = _v_26;
  o[2] = _v_27;
  o[3] = _v_28;
  o[4] = _v_29;
  o[5] = _v_30;
  o[6] = _v_31;
  o[7] = _v_32;
  o[8] = _v_33;
  o[9] = _v_34;
  o[10] = _v_35;
  o[11] = _v_36;
  o[12] = _v_37;
  o[13] = _v_38;
  o[14] = _v_39;
  o[15] = _v_40;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _components_0 = r0;
  Term _components_1 = r1;
  u32 _handle_2 = r2;
  u32 _handle_3 = r3;
  WL_SPIN
    Term _at_0 = _components_0 == h0 ? q0 : blk_loc(e.mem, _components_0);
    Term _at_1 = blk_at(_components_0, _handle_3, 1);
    u32 _c_0 = blk_read(e.mem, 1, _at_0, _at_1 + 0);
    Term _c_1 = e.mem[_at_0 + _at_1 + 1];
    u32 _o_0 = 0;
    Term _o_1 = 0;
    Term _t_0 = 0;
    if (_t_0 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, 0);
      e.mem[_nd_0 + 1] = rfc_seal(e, 0);
      _o_1 = term_ctr(CID_CONSUMER_PAYLOAD, _nd_0);
    }
    blk_write(e.mem, 1, _at_0, _at_1 + 0, _o_0);
    blk_write(e.mem, 1, _at_0, _at_1 + 1, _o_1);
    u32 _o_2 = 0;
    Term _o_3 = 0;
    Term _o_4 = 0;
    if (_c_0 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _c_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      _o_3 = _f_0;
      _o_4 = _f_1;
    }
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _o_5[3];
    if (spin_30(e, _o_5, _handle_3, _components_0, _components_0 == h0 ? q0 : blk_loc(e.mem, _components_0), _o_2, _o_3, _o_3 == h1 ? q1 : _o_3 == h0 ? q0 : blk_loc(e.mem, _o_3), _o_4, _o_4 == h1 ? q1 : _o_4 == h0 ? q0 : blk_loc(e.mem, _o_4), _components_1, _components_1 == h1 ? q1 : blk_loc(e.mem, _components_1)) == 0) {
      return 0;
    }
    _v_9 = _o_5[0];
    _v_10 = _o_5[1];
    _v_11 = _o_5[2];
    _v_6 = _v_9;
    _v_7 = _v_10;
    _v_8 = _v_11;
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _cleared_0 = r0;
  Term _cleared_1 = r1;
  Term _cleared_2 = r2;
  Term _graph_0 = r3;
  Term _graph_1 = r4;
  WL_SPIN
    _v_17 = _cleared_0;
    _v_18 = _cleared_1;
    _v_19 = _graph_0;
    _v_20 = _graph_1;
    _v_21 = _cleared_2;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _observed_0 = r0;
  Term _observed_1 = r1;
  Term _observed_2 = r2;
  Term _observed_3 = r3;
  Term _observed_4 = r4;
  u32 _namespace_0 = r5;
  u32 _nextId_0 = r6;
  u32 _highWater_0 = r7;
  Term _live_0 = r8;
  u32 _capacity_0 = r9;
  Term _depth_0 = r10;
  Term _resource_0 = r11;
  Term _events_0 = r12;
  Term _pending_0 = r13;
  Term _registrations_0 = r14;
  u32 _nextSystemId_0 = r15;
  u32 _clock_0 = r16;
  WL_SPIN
    _v_17 = _namespace_0;
    _v_18 = _nextId_0;
    _v_19 = _highWater_0;
    _v_20 = _live_0;
    _v_21 = _capacity_0;
    _v_22 = _depth_0;
    _v_23 = _observed_0;
    _v_24 = _observed_1;
    _v_25 = _observed_2;
    _v_26 = _observed_3;
    _v_27 = _resource_0;
    _v_28 = _events_0;
    _v_29 = _pending_0;
    _v_30 = _registrations_0;
    _v_31 = _nextSystemId_0;
    _v_32 = _clock_0;
    _v_33 = _observed_4;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  Term _world_10 = r10;
  Term _world_11 = r11;
  Term _world_12 = r12;
  Term _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  u32 _handle_2 = r16;
  u32 _handle_3 = r17;
  WL_SPIN
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    Term _o_0[17];
    if (spin_31(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_10 == h10 ? q10 : blk_loc(e.mem, _world_10), _world_11, _world_11 == h11 ? q11 : blk_loc(e.mem, _world_11), _world_12, _world_12 == h12 ? q12 : blk_loc(e.mem, _world_12), _world_13, _world_13 == h13 ? q13 : blk_loc(e.mem, _world_13), _world_14, _world_15, _handle_2, _handle_3) == 0) {
      return 0;
    }
    _v_71 = _o_0[0];
    _v_72 = _o_0[1];
    _v_73 = _o_0[2];
    _v_74 = _o_0[3];
    _v_75 = _o_0[4];
    _v_76 = _o_0[5];
    _v_77 = _o_0[6];
    _v_78 = _o_0[7];
    _v_79 = _o_0[8];
    _v_80 = _o_0[9];
    _v_81 = _o_0[10];
    _v_82 = _o_0[11];
    _v_83 = _o_0[12];
    _v_84 = _o_0[13];
    _v_85 = _o_0[14];
    _v_86 = _o_0[15];
    _v_87 = _o_0[16];
    _v_54 = _v_71;
    _v_55 = _v_72;
    _v_56 = _v_73;
    _v_57 = _v_74;
    _v_58 = _v_75;
    _v_59 = _v_76;
    _v_60 = _v_77;
    _v_61 = _v_78;
    _v_62 = _v_79;
    _v_63 = _v_80;
    _v_64 = _v_81;
    _v_65 = _v_82;
    _v_66 = _v_83;
    _v_67 = _v_84;
    _v_68 = _v_85;
    _v_69 = _v_86;
    _v_70 = _v_87;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    u32 _v_90 = 0;
    Term _v_91 = 0;
    u32 _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    Term _v_99 = 0;
    Term _v_100 = 0;
    Term _v_101 = 0;
    u32 _v_102 = 0;
    u32 _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    Term _o_1[18];
    if (spin_32(e, _o_1, 0, _handle_2, _handle_3, _v_54, _v_55, _v_56, _v_57, _v_57 == h13 ? q13 : _v_57 == h12 ? q12 : _v_57 == h11 ? q11 : _v_57 == h10 ? q10 : _v_57 == h9 ? q9 : _v_57 == h8 ? q8 : _v_57 == h7 ? q7 : _v_57 == h6 ? q6 : _v_57 == h3 ? q3 : blk_loc(e.mem, _v_57), _v_58, _v_59, _v_60, _v_60 == h13 ? q13 : _v_60 == h12 ? q12 : _v_60 == h11 ? q11 : _v_60 == h10 ? q10 : _v_60 == h9 ? q9 : _v_60 == h8 ? q8 : _v_60 == h7 ? q7 : _v_60 == h6 ? q6 : _v_60 == h3 ? q3 : blk_loc(e.mem, _v_60), _v_61, _v_61 == h13 ? q13 : _v_61 == h12 ? q12 : _v_61 == h11 ? q11 : _v_61 == h10 ? q10 : _v_61 == h9 ? q9 : _v_61 == h8 ? q8 : _v_61 == h7 ? q7 : _v_61 == h6 ? q6 : _v_61 == h3 ? q3 : blk_loc(e.mem, _v_61), _v_62, _v_62 == h13 ? q13 : _v_62 == h12 ? q12 : _v_62 == h11 ? q11 : _v_62 == h10 ? q10 : _v_62 == h9 ? q9 : _v_62 == h8 ? q8 : _v_62 == h7 ? q7 : _v_62 == h6 ? q6 : _v_62 == h3 ? q3 : blk_loc(e.mem, _v_62), _v_63, _v_63 == h13 ? q13 : _v_63 == h12 ? q12 : _v_63 == h11 ? q11 : _v_63 == h10 ? q10 : _v_63 == h9 ? q9 : _v_63 == h8 ? q8 : _v_63 == h7 ? q7 : _v_63 == h6 ? q6 : _v_63 == h3 ? q3 : blk_loc(e.mem, _v_63), _v_64, _v_64 == h13 ? q13 : _v_64 == h12 ? q12 : _v_64 == h11 ? q11 : _v_64 == h10 ? q10 : _v_64 == h9 ? q9 : _v_64 == h8 ? q8 : _v_64 == h7 ? q7 : _v_64 == h6 ? q6 : _v_64 == h3 ? q3 : blk_loc(e.mem, _v_64), _v_65, _v_65 == h13 ? q13 : _v_65 == h12 ? q12 : _v_65 == h11 ? q11 : _v_65 == h10 ? q10 : _v_65 == h9 ? q9 : _v_65 == h8 ? q8 : _v_65 == h7 ? q7 : _v_65 == h6 ? q6 : _v_65 == h3 ? q3 : blk_loc(e.mem, _v_65), _v_66, _v_66 == h13 ? q13 : _v_66 == h12 ? q12 : _v_66 == h11 ? q11 : _v_66 == h10 ? q10 : _v_66 == h9 ? q9 : _v_66 == h8 ? q8 : _v_66 == h7 ? q7 : _v_66 == h6 ? q6 : _v_66 == h3 ? q3 : blk_loc(e.mem, _v_66), _v_67, _v_67 == h13 ? q13 : _v_67 == h12 ? q12 : _v_67 == h11 ? q11 : _v_67 == h10 ? q10 : _v_67 == h9 ? q9 : _v_67 == h8 ? q8 : _v_67 == h7 ? q7 : _v_67 == h6 ? q6 : _v_67 == h3 ? q3 : blk_loc(e.mem, _v_67), _v_68, _v_69, _v_70) == 0) {
      return 0;
    }
    _v_88 = _o_1[0];
    _v_89 = _o_1[1];
    _v_90 = _o_1[2];
    _v_91 = _o_1[3];
    _v_92 = _o_1[4];
    _v_93 = _o_1[5];
    _v_94 = _o_1[6];
    _v_95 = _o_1[7];
    _v_96 = _o_1[8];
    _v_97 = _o_1[9];
    _v_98 = _o_1[10];
    _v_99 = _o_1[11];
    _v_100 = _o_1[12];
    _v_101 = _o_1[13];
    _v_102 = _o_1[14];
    _v_103 = _o_1[15];
    _v_104 = _o_1[16];
    _v_105 = _o_1[17];
    _v_36 = _v_88;
    _v_37 = _v_89;
    _v_38 = _v_90;
    _v_39 = _v_91;
    _v_40 = _v_92;
    _v_41 = _v_93;
    _v_42 = _v_94;
    _v_43 = _v_95;
    _v_44 = _v_96;
    _v_45 = _v_97;
    _v_46 = _v_98;
    _v_47 = _v_99;
    _v_48 = _v_100;
    _v_49 = _v_101;
    _v_50 = _v_102;
    _v_51 = _v_103;
    _v_52 = _v_104;
    _v_53 = _v_105;
  break;
  }
  o[0] = _v_36;
  o[1] = _v_37;
  o[2] = _v_38;
  o[3] = _v_39;
  o[4] = _v_40;
  o[5] = _v_41;
  o[6] = _v_42;
  o[7] = _v_43;
  o[8] = _v_44;
  o[9] = _v_45;
  o[10] = _v_46;
  o[11] = _v_47;
  o[12] = _v_48;
  o[13] = _v_49;
  o[14] = _v_50;
  o[15] = _v_51;
  o[16] = _v_52;
  o[17] = _v_53;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h7 = r7;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _observed_0 = r0;
  Term _observed_1 = r1;
  Term _observed_2 = r2;
  Term _observed_3 = r3;
  u32 _namespace_0 = r4;
  u32 _nextId_0 = r5;
  u32 _highWater_0 = r6;
  Term _live_0 = r7;
  u32 _capacity_0 = r8;
  Term _depth_0 = r9;
  Term _resource_0 = r10;
  Term _events_0 = r11;
  Term _pending_0 = r12;
  Term _registrations_0 = r13;
  u32 _nextSystemId_0 = r14;
  u32 _clock_0 = r15;
  WL_SPIN
    _v_16 = _namespace_0;
    _v_17 = _nextId_0;
    _v_18 = _highWater_0;
    _v_19 = _live_0;
    _v_20 = _capacity_0;
    _v_21 = _depth_0;
    _v_22 = _observed_0;
    _v_23 = _observed_1;
    _v_24 = _observed_2;
    _v_25 = _observed_3;
    _v_26 = _resource_0;
    _v_27 = _events_0;
    _v_28 = _pending_0;
    _v_29 = _registrations_0;
    _v_30 = _nextSystemId_0;
    _v_31 = _clock_0;
  break;
  }
  o[0] = _v_16;
  o[1] = _v_17;
  o[2] = _v_18;
  o[3] = _v_19;
  o[4] = _v_20;
  o[5] = _v_21;
  o[6] = _v_22;
  o[7] = _v_23;
  o[8] = _v_24;
  o[9] = _v_25;
  o[10] = _v_26;
  o[11] = _v_27;
  o[12] = _v_28;
  o[13] = _v_29;
  o[14] = _v_30;
  o[15] = _v_31;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _allowed_0 = r0;
  u32 _world_0 = r1;
  u32 _world_1 = r2;
  u32 _world_2 = r3;
  Term _world_3 = r4;
  u32 _world_4 = r5;
  Term _world_5 = r6;
  Term _world_6 = r7;
  Term _world_7 = r8;
  Term _world_8 = r9;
  Term _world_9 = r10;
  Term _world_10 = r11;
  Term _world_11 = r12;
  Term _world_12 = r13;
  Term _world_13 = r14;
  u32 _world_14 = r15;
  u32 _world_15 = r16;
  u32 _handle_2 = r17;
  u32 _handle_3 = r18;
  WL_SPIN
    if (_allowed_0 == 0) {
      _v_17 = _world_0;
      _v_18 = _world_1;
      _v_19 = _world_2;
      _v_20 = _world_3;
      _v_21 = _world_4;
      _v_22 = _world_5;
      _v_23 = _world_6;
      _v_24 = _world_7;
      _v_25 = _world_8;
      _v_26 = _world_9;
      _v_27 = _world_10;
      _v_28 = _world_11;
      _v_29 = _world_12;
      _v_30 = _world_13;
      _v_31 = _world_14;
      _v_32 = _world_15;
      _v_33 = 0;
    } else {
      Term _at_0 = _world_3 == h4 ? q4 : blk_loc(e.mem, _world_3);
      Term _at_1 = blk_at(_world_3, _handle_3, 0);
      u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
      u32 _v_34 = 0;
      u32 _v_35 = 0;
      u32 _v_36 = 0;
      Term _v_37 = 0;
      u32 _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      u32 _v_50 = 0;
      Term _o_0[17];
      if (spin_34(e, _o_0, _world_3, _world_3 == h4 ? q4 : blk_loc(e.mem, _world_3), _c_0, _world_0, _world_1, _world_2, _world_4, _world_5, _world_6, _world_6 == h7 ? q7 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h8 ? q8 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h9 ? q9 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h10 ? q10 : blk_loc(e.mem, _world_9), _world_10, _world_10 == h11 ? q11 : blk_loc(e.mem, _world_10), _world_11, _world_11 == h12 ? q12 : blk_loc(e.mem, _world_11), _world_12, _world_12 == h13 ? q13 : blk_loc(e.mem, _world_12), _world_13, _world_13 == h14 ? q14 : blk_loc(e.mem, _world_13), _world_14, _world_15) == 0) {
        return 0;
      }
      _v_34 = _o_0[0];
      _v_35 = _o_0[1];
      _v_36 = _o_0[2];
      _v_37 = _o_0[3];
      _v_38 = _o_0[4];
      _v_39 = _o_0[5];
      _v_40 = _o_0[6];
      _v_41 = _o_0[7];
      _v_42 = _o_0[8];
      _v_43 = _o_0[9];
      _v_44 = _o_0[10];
      _v_45 = _o_0[11];
      _v_46 = _o_0[12];
      _v_47 = _o_0[13];
      _v_48 = _o_0[14];
      _v_49 = _o_0[15];
      _v_50 = _o_0[16];
      _v_17 = _v_34;
      _v_18 = _v_35;
      _v_19 = _v_36;
      _v_20 = _v_37;
      _v_21 = _v_38;
      _v_22 = _v_39;
      _v_23 = _v_40;
      _v_24 = _v_41;
      _v_25 = _v_42;
      _v_26 = _v_43;
      _v_27 = _v_44;
      _v_28 = _v_45;
      _v_29 = _v_46;
      _v_30 = _v_47;
      _v_31 = _v_48;
      _v_32 = _v_49;
      _v_33 = _v_50;
    }
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_2 = 0;
  u32 _v_3 = 0;
  Term _command_0 = r0;
  Term _counted_0 = r1;
  u32 _counted_1 = r2;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _command_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _counted_0);
    _v_2 = term_ctr(CID_CON, _nd_0);
    _v_3 = U32_BIN(_counted_1, +, 1ull);
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _observed_0 = r0;
  Term _observed_1 = r1;
  Term _observed_2 = r2;
  Term _observed_3 = r3;
  Term _observed_4 = r4;
  u32 _namespace_0 = r5;
  u32 _nextId_0 = r6;
  u32 _highWater_0 = r7;
  Term _live_0 = r8;
  u32 _capacity_0 = r9;
  Term _depth_0 = r10;
  Term _resource_0 = r11;
  Term _events_0 = r12;
  Term _pending_0 = r13;
  Term _registrations_0 = r14;
  u32 _nextSystemId_0 = r15;
  u32 _clock_0 = r16;
  WL_SPIN
    _v_17 = _namespace_0;
    _v_18 = _nextId_0;
    _v_19 = _highWater_0;
    _v_20 = _live_0;
    _v_21 = _capacity_0;
    _v_22 = _depth_0;
    _v_23 = _observed_0;
    _v_24 = _observed_1;
    _v_25 = _observed_2;
    _v_26 = _observed_3;
    _v_27 = _resource_0;
    _v_28 = _events_0;
    _v_29 = _pending_0;
    _v_30 = _registrations_0;
    _v_31 = _nextSystemId_0;
    _v_32 = _clock_0;
    _v_33 = _observed_4;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _world_16 = r0;
  u32 _world_17 = r1;
  u32 _world_18 = r2;
  Term _world_19 = r3;
  u32 _world_20 = r4;
  Term _world_21 = r5;
  Term _world_22 = r6;
  Term _world_23 = r7;
  Term _world_24 = r8;
  Term _world_25 = r9;
  Term _world_26 = r10;
  Term _world_27 = r11;
  Term _world_28 = r12;
  Term _world_29 = r13;
  u32 _world_30 = r14;
  u32 _world_31 = r15;
  WL_SPIN
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    Term _o_0[1];
    if (spin_37(e, _o_0, U32_BIN(_world_31, <, 4294967295ull), _world_31) == 0) {
      return 0;
    }
    _v_52 = _o_0[0];
    _v_51 = _v_52;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    Term _o_1[1];
    if (spin_37(e, _o_1, U32_BIN(_world_31, <, 4294967295ull), _world_31) == 0) {
      return 0;
    }
    _v_54 = _o_1[0];
    _v_53 = _v_54;
    _v_34 = _world_16;
    _v_35 = _world_17;
    _v_36 = _world_18;
    _v_37 = _world_19;
    _v_38 = _world_20;
    _v_39 = _world_21;
    _v_40 = _world_22;
    _v_41 = _world_23;
    _v_42 = _world_24;
    _v_43 = _world_25;
    _v_44 = _world_26;
    _v_45 = _world_27;
    _v_46 = _world_28;
    _v_47 = _world_29;
    _v_48 = _world_30;
    _v_49 = _v_51;
    _v_50 = _v_53;
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  o[7] = _v_41;
  o[8] = _v_42;
  o[9] = _v_43;
  o[10] = _v_44;
  o[11] = _v_45;
  o[12] = _v_46;
  o[13] = _v_47;
  o[14] = _v_48;
  o[15] = _v_49;
  o[16] = _v_50;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_71 = 0;
  u32 _v_72 = 0;
  u32 _v_73 = 0;
  Term _v_74 = 0;
  u32 _v_75 = 0;
  Term _v_76 = 0;
  Term _v_77 = 0;
  Term _v_78 = 0;
  Term _v_79 = 0;
  Term _v_80 = 0;
  Term _v_81 = 0;
  Term _v_82 = 0;
  Term _v_83 = 0;
  Term _v_84 = 0;
  u32 _v_85 = 0;
  u32 _v_86 = 0;
  u32 _observed_0 = r0;
  u32 _observed_1 = r1;
  u32 _observed_2 = r2;
  Term _observed_3 = r3;
  u32 _observed_4 = r4;
  Term _observed_5 = r5;
  Term _observed_6 = r6;
  Term _observed_7 = r7;
  Term _observed_8 = r8;
  Term _observed_9 = r9;
  Term _observed_10 = r10;
  Term _observed_11 = r11;
  Term _observed_12 = r12;
  Term _observed_13 = r13;
  u32 _observed_14 = r14;
  u32 _observed_15 = r15;
  u32 _observed_16 = r16;
  WL_SPIN
    _v_71 = _observed_0;
    _v_72 = _observed_1;
    _v_73 = _observed_2;
    _v_74 = _observed_3;
    _v_75 = _observed_4;
    _v_76 = _observed_5;
    _v_77 = _observed_6;
    _v_78 = _observed_7;
    _v_79 = _observed_8;
    _v_80 = _observed_9;
    _v_81 = _observed_10;
    _v_82 = _observed_11;
    _v_83 = _observed_12;
    _v_84 = _observed_13;
    _v_85 = _observed_14;
    _v_86 = _observed_15;
  break;
  }
  o[0] = _v_71;
  o[1] = _v_72;
  o[2] = _v_73;
  o[3] = _v_74;
  o[4] = _v_75;
  o[5] = _v_76;
  o[6] = _v_77;
  o[7] = _v_78;
  o[8] = _v_79;
  o[9] = _v_80;
  o[10] = _v_81;
  o[11] = _v_82;
  o[12] = _v_83;
  o[13] = _v_84;
  o[14] = _v_85;
  o[15] = _v_86;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, u32 r16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_102 = 0;
  u32 _v_103 = 0;
  u32 _v_104 = 0;
  Term _v_105 = 0;
  u32 _v_106 = 0;
  Term _v_107 = 0;
  Term _v_108 = 0;
  Term _v_109 = 0;
  Term _v_110 = 0;
  Term _v_111 = 0;
  Term _v_112 = 0;
  Term _v_113 = 0;
  Term _v_114 = 0;
  Term _v_115 = 0;
  u32 _v_116 = 0;
  u32 _v_117 = 0;
  u32 _v_118 = 0;
  u32 _handle_2 = r0;
  u32 _handle_3 = r1;
  u32 _checked_17 = r2;
  u32 _checked_18 = r3;
  u32 _checked_19 = r4;
  Term _checked_20 = r5;
  u32 _checked_21 = r6;
  Term _checked_22 = r7;
  Term _checked_23 = r8;
  Term _checked_24 = r9;
  Term _checked_25 = r10;
  Term _checked_26 = r11;
  Term _checked_27 = r12;
  Term _checked_28 = r13;
  Term _checked_29 = r14;
  Term _checked_30 = r15;
  u32 _checked_31 = r16;
  u32 _checked_32 = r17;
  u32 _checked_33 = r18;
  WL_SPIN
    u32 _v_119 = 0;
    u32 _v_120 = 0;
    u32 _v_121 = 0;
    Term _v_122 = 0;
    u32 _v_123 = 0;
    Term _v_124 = 0;
    Term _v_125 = 0;
    Term _v_126 = 0;
    Term _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    Term _v_130 = 0;
    Term _v_131 = 0;
    Term _v_132 = 0;
    u32 _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    Term _o_1[17];
    if (spin_44(e, _o_1, _checked_33, _checked_17, _checked_18, _checked_19, _checked_20, _checked_20 == h5 ? q5 : blk_loc(e.mem, _checked_20), _checked_21, _checked_22, _checked_23, _checked_23 == h8 ? q8 : blk_loc(e.mem, _checked_23), _checked_24, _checked_24 == h9 ? q9 : blk_loc(e.mem, _checked_24), _checked_25, _checked_25 == h10 ? q10 : blk_loc(e.mem, _checked_25), _checked_26, _checked_26 == h11 ? q11 : blk_loc(e.mem, _checked_26), _checked_27, _checked_27 == h12 ? q12 : blk_loc(e.mem, _checked_27), _checked_28, _checked_28 == h13 ? q13 : blk_loc(e.mem, _checked_28), _checked_29, _checked_29 == h14 ? q14 : blk_loc(e.mem, _checked_29), _checked_30, _checked_30 == h15 ? q15 : blk_loc(e.mem, _checked_30), _checked_31, _checked_32, _handle_2, _handle_3) == 0) {
      return 0;
    }
    _v_119 = _o_1[0];
    _v_120 = _o_1[1];
    _v_121 = _o_1[2];
    _v_122 = _o_1[3];
    _v_123 = _o_1[4];
    _v_124 = _o_1[5];
    _v_125 = _o_1[6];
    _v_126 = _o_1[7];
    _v_127 = _o_1[8];
    _v_128 = _o_1[9];
    _v_129 = _o_1[10];
    _v_130 = _o_1[11];
    _v_131 = _o_1[12];
    _v_132 = _o_1[13];
    _v_133 = _o_1[14];
    _v_134 = _o_1[15];
    _v_135 = _o_1[16];
    _v_102 = _v_119;
    _v_103 = _v_120;
    _v_104 = _v_121;
    _v_105 = _v_122;
    _v_106 = _v_123;
    _v_107 = _v_124;
    _v_108 = _v_125;
    _v_109 = _v_126;
    _v_110 = _v_127;
    _v_111 = _v_128;
    _v_112 = _v_129;
    _v_113 = _v_130;
    _v_114 = _v_131;
    _v_115 = _v_132;
    _v_116 = _v_133;
    _v_117 = _v_134;
    _v_118 = _v_135;
  break;
  }
  o[0] = _v_102;
  o[1] = _v_103;
  o[2] = _v_104;
  o[3] = _v_105;
  o[4] = _v_106;
  o[5] = _v_107;
  o[6] = _v_108;
  o[7] = _v_109;
  o[8] = _v_110;
  o[9] = _v_111;
  o[10] = _v_112;
  o[11] = _v_113;
  o[12] = _v_114;
  o[13] = _v_115;
  o[14] = _v_116;
  o[15] = _v_117;
  o[16] = _v_118;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  Term _world_10 = r10;
  Term _world_11 = r11;
  Term _world_12 = r12;
  Term _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  u32 _handle_0 = r16;
  u32 _handle_1 = r17;
  WL_SPIN
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    Term _o_0[17];
    if (spin_31(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_10 == h10 ? q10 : blk_loc(e.mem, _world_10), _world_11, _world_11 == h11 ? q11 : blk_loc(e.mem, _world_11), _world_12, _world_12 == h12 ? q12 : blk_loc(e.mem, _world_12), _world_13, _world_13 == h13 ? q13 : blk_loc(e.mem, _world_13), _world_14, _world_15, _handle_0, _handle_1) == 0) {
      return 0;
    }
    _v_68 = _o_0[0];
    _v_69 = _o_0[1];
    _v_70 = _o_0[2];
    _v_71 = _o_0[3];
    _v_72 = _o_0[4];
    _v_73 = _o_0[5];
    _v_74 = _o_0[6];
    _v_75 = _o_0[7];
    _v_76 = _o_0[8];
    _v_77 = _o_0[9];
    _v_78 = _o_0[10];
    _v_79 = _o_0[11];
    _v_80 = _o_0[12];
    _v_81 = _o_0[13];
    _v_82 = _o_0[14];
    _v_83 = _o_0[15];
    _v_84 = _o_0[16];
    _v_51 = _v_68;
    _v_52 = _v_69;
    _v_53 = _v_70;
    _v_54 = _v_71;
    _v_55 = _v_72;
    _v_56 = _v_73;
    _v_57 = _v_74;
    _v_58 = _v_75;
    _v_59 = _v_76;
    _v_60 = _v_77;
    _v_61 = _v_78;
    _v_62 = _v_79;
    _v_63 = _v_80;
    _v_64 = _v_81;
    _v_65 = _v_82;
    _v_66 = _v_83;
    _v_67 = _v_84;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    Term _o_2[17];
    if (spin_50(e, _o_2, _handle_0, _handle_1, _v_51, _v_52, _v_53, _v_54, _v_54 == h13 ? q13 : _v_54 == h12 ? q12 : _v_54 == h11 ? q11 : _v_54 == h10 ? q10 : _v_54 == h9 ? q9 : _v_54 == h8 ? q8 : _v_54 == h7 ? q7 : _v_54 == h6 ? q6 : _v_54 == h3 ? q3 : blk_loc(e.mem, _v_54), _v_55, _v_56, _v_57, _v_57 == h13 ? q13 : _v_57 == h12 ? q12 : _v_57 == h11 ? q11 : _v_57 == h10 ? q10 : _v_57 == h9 ? q9 : _v_57 == h8 ? q8 : _v_57 == h7 ? q7 : _v_57 == h6 ? q6 : _v_57 == h3 ? q3 : blk_loc(e.mem, _v_57), _v_58, _v_58 == h13 ? q13 : _v_58 == h12 ? q12 : _v_58 == h11 ? q11 : _v_58 == h10 ? q10 : _v_58 == h9 ? q9 : _v_58 == h8 ? q8 : _v_58 == h7 ? q7 : _v_58 == h6 ? q6 : _v_58 == h3 ? q3 : blk_loc(e.mem, _v_58), _v_59, _v_59 == h13 ? q13 : _v_59 == h12 ? q12 : _v_59 == h11 ? q11 : _v_59 == h10 ? q10 : _v_59 == h9 ? q9 : _v_59 == h8 ? q8 : _v_59 == h7 ? q7 : _v_59 == h6 ? q6 : _v_59 == h3 ? q3 : blk_loc(e.mem, _v_59), _v_60, _v_60 == h13 ? q13 : _v_60 == h12 ? q12 : _v_60 == h11 ? q11 : _v_60 == h10 ? q10 : _v_60 == h9 ? q9 : _v_60 == h8 ? q8 : _v_60 == h7 ? q7 : _v_60 == h6 ? q6 : _v_60 == h3 ? q3 : blk_loc(e.mem, _v_60), _v_61, _v_61 == h13 ? q13 : _v_61 == h12 ? q12 : _v_61 == h11 ? q11 : _v_61 == h10 ? q10 : _v_61 == h9 ? q9 : _v_61 == h8 ? q8 : _v_61 == h7 ? q7 : _v_61 == h6 ? q6 : _v_61 == h3 ? q3 : blk_loc(e.mem, _v_61), _v_62, _v_62 == h13 ? q13 : _v_62 == h12 ? q12 : _v_62 == h11 ? q11 : _v_62 == h10 ? q10 : _v_62 == h9 ? q9 : _v_62 == h8 ? q8 : _v_62 == h7 ? q7 : _v_62 == h6 ? q6 : _v_62 == h3 ? q3 : blk_loc(e.mem, _v_62), _v_63, _v_63 == h13 ? q13 : _v_63 == h12 ? q12 : _v_63 == h11 ? q11 : _v_63 == h10 ? q10 : _v_63 == h9 ? q9 : _v_63 == h8 ? q8 : _v_63 == h7 ? q7 : _v_63 == h6 ? q6 : _v_63 == h3 ? q3 : blk_loc(e.mem, _v_63), _v_64, _v_64 == h13 ? q13 : _v_64 == h12 ? q12 : _v_64 == h11 ? q11 : _v_64 == h10 ? q10 : _v_64 == h9 ? q9 : _v_64 == h8 ? q8 : _v_64 == h7 ? q7 : _v_64 == h6 ? q6 : _v_64 == h3 ? q3 : blk_loc(e.mem, _v_64), _v_65, _v_66, _v_67) == 0) {
      return 0;
    }
    _v_85 = _o_2[0];
    _v_86 = _o_2[1];
    _v_87 = _o_2[2];
    _v_88 = _o_2[3];
    _v_89 = _o_2[4];
    _v_90 = _o_2[5];
    _v_91 = _o_2[6];
    _v_92 = _o_2[7];
    _v_93 = _o_2[8];
    _v_94 = _o_2[9];
    _v_95 = _o_2[10];
    _v_96 = _o_2[11];
    _v_97 = _o_2[12];
    _v_98 = _o_2[13];
    _v_99 = _o_2[14];
    _v_100 = _o_2[15];
    _v_101 = _o_2[16];
    _v_34 = _v_85;
    _v_35 = _v_86;
    _v_36 = _v_87;
    _v_37 = _v_88;
    _v_38 = _v_89;
    _v_39 = _v_90;
    _v_40 = _v_91;
    _v_41 = _v_92;
    _v_42 = _v_93;
    _v_43 = _v_94;
    _v_44 = _v_95;
    _v_45 = _v_96;
    _v_46 = _v_97;
    _v_47 = _v_98;
    _v_48 = _v_99;
    _v_49 = _v_100;
    _v_50 = _v_101;
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  o[7] = _v_41;
  o[8] = _v_42;
  o[9] = _v_43;
  o[10] = _v_44;
  o[11] = _v_45;
  o[12] = _v_46;
  o[13] = _v_47;
  o[14] = _v_48;
  o[15] = _v_49;
  o[16] = _v_50;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _store_0 = r0;
  Term _store_1 = r1;
  Term _store_2 = r2;
  Term _store_3 = r3;
  u32 _handle_4 = r4;
  u32 _handle_5 = r5;
  WL_SPIN
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _o_0[3];
    if (spin_39(e, _o_0, _store_0, _store_0 == h0 ? q0 : blk_loc(e.mem, _store_0), _store_1, _store_1 == h1 ? q1 : blk_loc(e.mem, _store_1), _handle_4, _handle_5) == 0) {
      return 0;
    }
    _v_13 = _o_0[0];
    _v_14 = _o_0[1];
    _v_15 = _o_0[2];
    _v_10 = _v_13;
    _v_11 = _v_14;
    _v_12 = _v_15;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _o_1[5];
    if (spin_40(e, _o_1, _v_10, _v_10 == h3 ? q3 : _v_10 == h2 ? q2 : _v_10 == h1 ? q1 : _v_10 == h0 ? q0 : blk_loc(e.mem, _v_10), _v_11, _v_11 == h3 ? q3 : _v_11 == h2 ? q2 : _v_11 == h1 ? q1 : _v_11 == h0 ? q0 : blk_loc(e.mem, _v_11), _v_12, _v_12 == h3 ? q3 : _v_12 == h2 ? q2 : _v_12 == h1 ? q1 : _v_12 == h0 ? q0 : blk_loc(e.mem, _v_12), _store_2, _store_2 == h2 ? q2 : blk_loc(e.mem, _store_2), _store_3, _store_3 == h3 ? q3 : blk_loc(e.mem, _store_3)) == 0) {
      return 0;
    }
    _v_16 = _o_1[0];
    _v_17 = _o_1[1];
    _v_18 = _o_1[2];
    _v_19 = _o_1[3];
    _v_20 = _o_1[4];
    _v_5 = _v_16;
    _v_6 = _v_17;
    _v_7 = _v_18;
    _v_8 = _v_19;
    _v_9 = _v_20;
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  u32 _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  Term _result_9 = r9;
  Term _result_10 = r10;
  Term _result_11 = r11;
  Term _result_12 = r12;
  Term _result_13 = r13;
  u32 _result_14 = r14;
  u32 _result_15 = r15;
  WL_SPIN
    _v_16 = _result_0;
    _v_17 = _result_1;
    _v_18 = _result_2;
    _v_19 = _result_3;
    _v_20 = _result_4;
    _v_21 = _result_5;
    _v_22 = _result_6;
    _v_23 = _result_7;
    _v_24 = _result_8;
    _v_25 = _result_9;
    _v_26 = _result_10;
    _v_27 = _result_11;
    _v_28 = _result_12;
    _v_29 = _result_13;
    _v_30 = _result_14;
    _v_31 = _result_15;
  break;
  }
  o[0] = _v_16;
  o[1] = _v_17;
  o[2] = _v_18;
  o[3] = _v_19;
  o[4] = _v_20;
  o[5] = _v_21;
  o[6] = _v_22;
  o[7] = _v_23;
  o[8] = _v_24;
  o[9] = _v_25;
  o[10] = _v_26;
  o[11] = _v_27;
  o[12] = _v_28;
  o[13] = _v_29;
  o[14] = _v_30;
  o[15] = _v_31;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _observed_0 = r0;
  Term _observed_1 = r1;
  Term _observed_2 = r2;
  Term _observed_3 = r3;
  Term _observed_4 = r4;
  u32 _namespace_0 = r5;
  u32 _nextId_0 = r6;
  u32 _highWater_0 = r7;
  Term _live_0 = r8;
  u32 _capacity_0 = r9;
  Term _depth_0 = r10;
  Term _resource_0 = r11;
  Term _events_0 = r12;
  Term _pending_0 = r13;
  Term _registrations_0 = r14;
  u32 _nextSystemId_0 = r15;
  u32 _clock_0 = r16;
  WL_SPIN
    _v_17 = _namespace_0;
    _v_18 = _nextId_0;
    _v_19 = _highWater_0;
    _v_20 = _live_0;
    _v_21 = _capacity_0;
    _v_22 = _depth_0;
    _v_23 = _observed_0;
    _v_24 = _observed_1;
    _v_25 = _observed_2;
    _v_26 = _observed_3;
    _v_27 = _resource_0;
    _v_28 = _events_0;
    _v_29 = _pending_0;
    _v_30 = _registrations_0;
    _v_31 = _nextSystemId_0;
    _v_32 = _clock_0;
    _v_33 = _observed_4;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, u32 r16) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h15 = r15;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _namespace_0 = r0;
  u32 _nextId_0 = r1;
  u32 _highWater_0 = r2;
  Term _live_0 = r3;
  u32 _capacity_0 = r4;
  Term _depth_0 = r5;
  Term _store_0 = r6;
  Term _store_1 = r7;
  Term _store_2 = r8;
  Term _store_3 = r9;
  Term _resource_0 = r10;
  Term _events_0 = r11;
  Term _registrations_0 = r12;
  u32 _nextSystemId_0 = r13;
  u32 _clock_0 = r14;
  Term _counted_0 = r15;
  u32 _counted_1 = r16;
  WL_SPIN
    _v_17 = _namespace_0;
    _v_18 = _nextId_0;
    _v_19 = _highWater_0;
    _v_20 = _live_0;
    _v_21 = _capacity_0;
    _v_22 = _depth_0;
    _v_23 = _store_0;
    _v_24 = _store_1;
    _v_25 = _store_2;
    _v_26 = _store_3;
    _v_27 = _resource_0;
    _v_28 = _events_0;
    _v_29 = _counted_0;
    _v_30 = _registrations_0;
    _v_31 = _nextSystemId_0;
    _v_32 = _clock_0;
    _v_33 = _counted_1;
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  Term _world_9 = r9;
  Term _world_10 = r10;
  Term _world_11 = r11;
  Term _world_12 = r12;
  Term _world_13 = r13;
  u32 _world_14 = r14;
  u32 _world_15 = r15;
  WL_SPIN
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _o_8[17];
    if (spin_47(e, _o_8, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_9 == h9 ? q9 : blk_loc(e.mem, _world_9), _world_10, _world_10 == h10 ? q10 : blk_loc(e.mem, _world_10), _world_11, _world_11 == h11 ? q11 : blk_loc(e.mem, _world_11), _world_12, _world_12 == h12 ? q12 : blk_loc(e.mem, _world_12), _world_13, _world_13 == h13 ? q13 : blk_loc(e.mem, _world_13), _world_14, _world_15) == 0) {
      return 0;
    }
    _v_49 = _o_8[0];
    _v_50 = _o_8[1];
    _v_51 = _o_8[2];
    _v_52 = _o_8[3];
    _v_53 = _o_8[4];
    _v_54 = _o_8[5];
    _v_55 = _o_8[6];
    _v_56 = _o_8[7];
    _v_57 = _o_8[8];
    _v_58 = _o_8[9];
    _v_59 = _o_8[10];
    _v_60 = _o_8[11];
    _v_61 = _o_8[12];
    _v_62 = _o_8[13];
    _v_63 = _o_8[14];
    _v_64 = _o_8[15];
    _v_65 = _o_8[16];
    _v_32 = _v_49;
    _v_33 = _v_50;
    _v_34 = _v_51;
    _v_35 = _v_52;
    _v_36 = _v_53;
    _v_37 = _v_54;
    _v_38 = _v_55;
    _v_39 = _v_56;
    _v_40 = _v_57;
    _v_41 = _v_58;
    _v_42 = _v_59;
    _v_43 = _v_60;
    _v_44 = _v_61;
    _v_45 = _v_62;
    _v_46 = _v_63;
    _v_47 = _v_64;
    _v_48 = _v_65;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _o_9[16];
    if (spin_48(e, _o_9, _v_32, _v_33, _v_34, _v_35, _v_35 == h13 ? q13 : _v_35 == h12 ? q12 : _v_35 == h11 ? q11 : _v_35 == h10 ? q10 : _v_35 == h9 ? q9 : _v_35 == h8 ? q8 : _v_35 == h7 ? q7 : _v_35 == h6 ? q6 : _v_35 == h3 ? q3 : blk_loc(e.mem, _v_35), _v_36, _v_37, _v_38, _v_38 == h13 ? q13 : _v_38 == h12 ? q12 : _v_38 == h11 ? q11 : _v_38 == h10 ? q10 : _v_38 == h9 ? q9 : _v_38 == h8 ? q8 : _v_38 == h7 ? q7 : _v_38 == h6 ? q6 : _v_38 == h3 ? q3 : blk_loc(e.mem, _v_38), _v_39, _v_39 == h13 ? q13 : _v_39 == h12 ? q12 : _v_39 == h11 ? q11 : _v_39 == h10 ? q10 : _v_39 == h9 ? q9 : _v_39 == h8 ? q8 : _v_39 == h7 ? q7 : _v_39 == h6 ? q6 : _v_39 == h3 ? q3 : blk_loc(e.mem, _v_39), _v_40, _v_40 == h13 ? q13 : _v_40 == h12 ? q12 : _v_40 == h11 ? q11 : _v_40 == h10 ? q10 : _v_40 == h9 ? q9 : _v_40 == h8 ? q8 : _v_40 == h7 ? q7 : _v_40 == h6 ? q6 : _v_40 == h3 ? q3 : blk_loc(e.mem, _v_40), _v_41, _v_41 == h13 ? q13 : _v_41 == h12 ? q12 : _v_41 == h11 ? q11 : _v_41 == h10 ? q10 : _v_41 == h9 ? q9 : _v_41 == h8 ? q8 : _v_41 == h7 ? q7 : _v_41 == h6 ? q6 : _v_41 == h3 ? q3 : blk_loc(e.mem, _v_41), _v_42, _v_42 == h13 ? q13 : _v_42 == h12 ? q12 : _v_42 == h11 ? q11 : _v_42 == h10 ? q10 : _v_42 == h9 ? q9 : _v_42 == h8 ? q8 : _v_42 == h7 ? q7 : _v_42 == h6 ? q6 : _v_42 == h3 ? q3 : blk_loc(e.mem, _v_42), _v_43, _v_43 == h13 ? q13 : _v_43 == h12 ? q12 : _v_43 == h11 ? q11 : _v_43 == h10 ? q10 : _v_43 == h9 ? q9 : _v_43 == h8 ? q8 : _v_43 == h7 ? q7 : _v_43 == h6 ? q6 : _v_43 == h3 ? q3 : blk_loc(e.mem, _v_43), _v_44, _v_44 == h13 ? q13 : _v_44 == h12 ? q12 : _v_44 == h11 ? q11 : _v_44 == h10 ? q10 : _v_44 == h9 ? q9 : _v_44 == h8 ? q8 : _v_44 == h7 ? q7 : _v_44 == h6 ? q6 : _v_44 == h3 ? q3 : blk_loc(e.mem, _v_44), _v_45, _v_45 == h13 ? q13 : _v_45 == h12 ? q12 : _v_45 == h11 ? q11 : _v_45 == h10 ? q10 : _v_45 == h9 ? q9 : _v_45 == h8 ? q8 : _v_45 == h7 ? q7 : _v_45 == h6 ? q6 : _v_45 == h3 ? q3 : blk_loc(e.mem, _v_45), _v_46, _v_47, _v_48) == 0) {
      return 0;
    }
    _v_66 = _o_9[0];
    _v_67 = _o_9[1];
    _v_68 = _o_9[2];
    _v_69 = _o_9[3];
    _v_70 = _o_9[4];
    _v_71 = _o_9[5];
    _v_72 = _o_9[6];
    _v_73 = _o_9[7];
    _v_74 = _o_9[8];
    _v_75 = _o_9[9];
    _v_76 = _o_9[10];
    _v_77 = _o_9[11];
    _v_78 = _o_9[12];
    _v_79 = _o_9[13];
    _v_80 = _o_9[14];
    _v_81 = _o_9[15];
    _v_16 = _v_66;
    _v_17 = _v_67;
    _v_18 = _v_68;
    _v_19 = _v_69;
    _v_20 = _v_70;
    _v_21 = _v_71;
    _v_22 = _v_72;
    _v_23 = _v_73;
    _v_24 = _v_74;
    _v_25 = _v_75;
    _v_26 = _v_76;
    _v_27 = _v_77;
    _v_28 = _v_78;
    _v_29 = _v_79;
    _v_30 = _v_80;
    _v_31 = _v_81;
  break;
  }
  o[0] = _v_16;
  o[1] = _v_17;
  o[2] = _v_18;
  o[3] = _v_19;
  o[4] = _v_20;
  o[5] = _v_21;
  o[6] = _v_22;
  o[7] = _v_23;
  o[8] = _v_24;
  o[9] = _v_25;
  o[10] = _v_26;
  o[11] = _v_27;
  o[12] = _v_28;
  o[13] = _v_29;
  o[14] = _v_30;
  o[15] = _v_31;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h18 = r18;
  Term h19 = r19;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  Term _v_54 = 0;
  u32 _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  u32 _checked_0 = r0;
  u32 _checked_1 = r1;
  u32 _checked_2 = r2;
  Term _checked_3 = r3;
  u32 _checked_4 = r4;
  Term _checked_5 = r5;
  Term _checked_6 = r6;
  Term _checked_7 = r7;
  Term _checked_8 = r8;
  Term _checked_9 = r9;
  Term _checked_10 = r10;
  Term _checked_11 = r11;
  Term _checked_12 = r12;
  Term _checked_13 = r13;
  u32 _checked_14 = r14;
  u32 _checked_15 = r15;
  u32 _checked_16 = r16;
  u32 _id_0 = r17;
  Term _descriptors_1 = r18;
  Term _frames_1 = r19;
  WL_SPIN
    if (_checked_16 == 0) {
      term_sink(e, _descriptors_1);
      _v_51 = _checked_0;
      _v_52 = _checked_1;
      _v_53 = _checked_2;
      _v_54 = _checked_3;
      _v_55 = _checked_4;
      _v_56 = _checked_5;
      _v_57 = _checked_6;
      _v_58 = _checked_7;
      _v_59 = _checked_8;
      _v_60 = _checked_9;
      _v_61 = _checked_10;
      _v_62 = _checked_11;
      _v_63 = _checked_12;
      _v_64 = _checked_13;
      _v_65 = _checked_14;
      _v_66 = _checked_15;
      _v_67 = _frames_1;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _id_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _descriptors_1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPDESCRIPTORS, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _frames_1);
      _v_51 = _checked_0;
      _v_52 = _checked_1;
      _v_53 = _checked_2;
      _v_54 = _checked_3;
      _v_55 = _checked_4;
      _v_56 = _checked_5;
      _v_57 = _checked_6;
      _v_58 = _checked_7;
      _v_59 = _checked_8;
      _v_60 = _checked_9;
      _v_61 = _checked_10;
      _v_62 = _checked_11;
      _v_63 = _checked_12;
      _v_64 = _checked_13;
      _v_65 = _checked_14;
      _v_66 = _checked_15;
      _v_67 = term_ctr(CID_CON, _nd_1);
    }
  break;
  }
  o[0] = _v_51;
  o[1] = _v_52;
  o[2] = _v_53;
  o[3] = _v_54;
  o[4] = _v_55;
  o[5] = _v_56;
  o[6] = _v_57;
  o[7] = _v_58;
  o[8] = _v_59;
  o[9] = _v_60;
  o[10] = _v_61;
  o[11] = _v_62;
  o[12] = _v_63;
  o[13] = _v_64;
  o[14] = _v_65;
  o[15] = _v_66;
  o[16] = _v_67;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, Term r16, u64 q16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, u32 r21, Term r22, u64 q22, Term r23, u64 q23) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h16 = r16;
  Term h19 = r19;
  Term h20 = r20;
  Term h22 = r22;
  Term h23 = r23;
  u32 _v_85 = 0;
  u32 _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  Term _v_90 = 0;
  Term _v_91 = 0;
  Term _v_92 = 0;
  Term _v_93 = 0;
  Term _v_94 = 0;
  Term _v_95 = 0;
  Term _v_96 = 0;
  Term _v_97 = 0;
  Term _v_98 = 0;
  u32 _v_99 = 0;
  u32 _v_100 = 0;
  Term _v_101 = 0;
  u32 _observed_0 = r0;
  u32 _observed_1 = r1;
  u32 _observed_2 = r2;
  Term _observed_3 = r3;
  u32 _observed_4 = r4;
  Term _observed_5 = r5;
  Term _observed_6 = r6;
  Term _observed_7 = r7;
  Term _observed_8 = r8;
  Term _observed_9 = r9;
  Term _observed_10 = r10;
  Term _observed_11 = r11;
  Term _observed_12 = r12;
  Term _observed_13 = r13;
  u32 _observed_14 = r14;
  u32 _observed_15 = r15;
  Term _observed_16 = r16;
  u32 _id_1 = r17;
  u32 _descriptor_0 = r18;
  Term _descriptor_1 = r19;
  Term _descriptor_2 = r20;
  u32 _descriptor_3 = r21;
  Term _remaining_0 = r22;
  Term _frames_3 = r23;
  WL_SPIN
    u64 _nd_7 = heap_alloc(e, cls_fit(7));
    e.mem[_nd_7 + 0] = rfc_seal(e, _id_1);
    e.mem[_nd_7 + 1] = rfc_seal(e, _descriptor_0);
    e.mem[_nd_7 + 2] = rfc_seal(e, _descriptor_1);
    e.mem[_nd_7 + 3] = rfc_seal(e, _descriptor_2);
    e.mem[_nd_7 + 4] = rfc_seal(e, _descriptor_3);
    e.mem[_nd_7 + 5] = rfc_seal(e, _remaining_0);
    e.mem[_nd_7 + 6] = rfc_seal(e, _observed_16);
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPCHILDREN, _nd_7));
    e.mem[_nd_8 + 1] = rfc_seal(e, _frames_3);
    _v_85 = _observed_0;
    _v_86 = _observed_1;
    _v_87 = _observed_2;
    _v_88 = _observed_3;
    _v_89 = _observed_4;
    _v_90 = _observed_5;
    _v_91 = _observed_6;
    _v_92 = _observed_7;
    _v_93 = _observed_8;
    _v_94 = _observed_9;
    _v_95 = _observed_10;
    _v_96 = _observed_11;
    _v_97 = _observed_12;
    _v_98 = _observed_13;
    _v_99 = _observed_14;
    _v_100 = _observed_15;
    _v_101 = term_ctr(CID_CON, _nd_8);
  break;
  }
  o[0] = _v_85;
  o[1] = _v_86;
  o[2] = _v_87;
  o[3] = _v_88;
  o[4] = _v_89;
  o[5] = _v_90;
  o[6] = _v_91;
  o[7] = _v_92;
  o[8] = _v_93;
  o[9] = _v_94;
  o[10] = _v_95;
  o[11] = _v_96;
  o[12] = _v_97;
  o[13] = _v_98;
  o[14] = _v_99;
  o[15] = _v_100;
  o[16] = _v_101;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  u32 _v_104 = 0;
  u32 _d_0 = r0;
  Term _d_1 = r1;
  Term _d_2 = r2;
  u32 _d_3 = r3;
  WL_SPIN
    _v_104 = _d_3;
  break;
  }
  o[0] = _v_104;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _namespace_1 = r0;
  WL_SPIN
    Term _fv_0[1];
    _fv_0[0] = 0;
    Term _fv_1[1];
    _fv_1[0] = 1;
    Term _fv_2[1];
    _fv_2[0] = 1;
    Term _fv_3[1];
    _fv_3[0] = 1;
    u32 _o_0 = 0;
    Term _o_1 = 0;
    Term _t_0 = 0;
    if (_t_0 == 0) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, 0);
      e.mem[_nd_0 + 1] = rfc_seal(e, 0);
      _o_1 = term_ctr(CID_CONSUMER_PAYLOAD, _nd_0);
    }
    Term _fv_4[2];
    _fv_4[0] = _o_0;
    _fv_4[1] = _o_1;
    Term _fv_5[1];
    _fv_5[0] = 1ull;
    Term _fv_6[1];
    _fv_6[0] = U32_BIN(1ull, +, 10ull);
    Term _fv_7[1];
    _fv_7[0] = U32_BIN(1ull, +, 20ull);
    u32 _o_2 = 0;
    Term _o_3 = 0;
    Term _t_1 = 1;
    if (_t_1 == 0) {
      _o_2 = 0;
    } else {
      _o_2 = 1;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_5));
      e.mem[_nd_1 + 1] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_6), blk_new(e, 0, 0, 0, 1, _fv_7)));
      _o_3 = term_ctr(CID_CONSUMER_PAYLOAD, _nd_1);
    }
    Term _fv_8[2];
    _fv_8[0] = _o_2;
    _fv_8[1] = _o_3;
    Term _fv_9[1];
    _fv_9[0] = 2ull;
    Term _fv_10[1];
    _fv_10[0] = U32_BIN(2ull, +, 10ull);
    Term _fv_11[1];
    _fv_11[0] = U32_BIN(2ull, +, 20ull);
    u32 _o_4 = 0;
    Term _o_5 = 0;
    Term _t_2 = 1;
    if (_t_2 == 0) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_9));
      e.mem[_nd_2 + 1] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_10), blk_new(e, 0, 0, 0, 1, _fv_11)));
      _o_5 = term_ctr(CID_CONSUMER_PAYLOAD, _nd_2);
    }
    Term _fv_12[2];
    _fv_12[0] = _o_4;
    _fv_12[1] = _o_5;
    Term _fv_13[1];
    _fv_13[0] = 3ull;
    Term _fv_14[1];
    _fv_14[0] = U32_BIN(3ull, +, 10ull);
    Term _fv_15[1];
    _fv_15[0] = U32_BIN(3ull, +, 20ull);
    u32 _o_6 = 0;
    Term _o_7 = 0;
    Term _t_3 = 1;
    if (_t_3 == 0) {
      _o_6 = 0;
    } else {
      _o_6 = 1;
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, blk_new(e, 0, 0, 0, 1, _fv_13));
      e.mem[_nd_3 + 1] = rfc_seal(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_14), blk_new(e, 0, 0, 0, 1, _fv_15)));
      _o_7 = term_ctr(CID_CONSUMER_PAYLOAD, _nd_3);
    }
    Term _fv_16[2];
    _fv_16[0] = _o_6;
    _fv_16[1] = _o_7;
    Term _fv_17[1];
    _fv_17[0] = 77ull;
    Term _fv_18[1];
    _fv_18[0] = 88ull;
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_clo(FID_CONSUMER_FIXTURE_0_C689, 0));
    e.mem[_nd_7 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    _v_32 = _namespace_1;
    _v_33 = 4ull;
    _v_34 = 3ull;
    _v_35 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_0), blk_new(e, 0, 0, 0, 1, _fv_1)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_2), blk_new(e, 0, 0, 0, 1, _fv_3)));
    _v_36 = 4ull;
    _v_37 = 2ull;
    _v_38 = blk_node(e, blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_4), blk_new(e, 1, 0, 1, 2, _fv_8)), blk_node(e, blk_new(e, 1, 0, 1, 2, _fv_12), blk_new(e, 1, 0, 1, 2, _fv_16)));
    _v_39 = term_pak(CID_NIL, 0);
    _v_40 = term_pak(CID_NIL, 0);
    _v_41 = term_pak(CID_NIL, 0);
    _v_42 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_17), blk_new(e, 0, 0, 0, 1, _fv_18));
    _v_43 = term_ctr(CID_CON, STAT_OFF + 391);
    _v_44 = term_ctr(CID_CON, _nd_7);
    _v_45 = term_ctr(CID_CON, STAT_OFF + 416);
    _v_46 = 2ull;
    _v_47 = 13ull;
  break;
  }
  o[0] = _v_32;
  o[1] = _v_33;
  o[2] = _v_34;
  o[3] = _v_35;
  o[4] = _v_36;
  o[5] = _v_37;
  o[6] = _v_38;
  o[7] = _v_39;
  o[8] = _v_40;
  o[9] = _v_41;
  o[10] = _v_42;
  o[11] = _v_43;
  o[12] = _v_44;
  o[13] = _v_45;
  o[14] = _v_46;
  o[15] = _v_47;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS)
  {
    Term _xs_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_0;
        STK(1) = _id_0;
        STK(2) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS_K1;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS_K1, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _id_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS_K1, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _id_0;
      _xs_0 = r0;
      _id_0 = r1;
      WL_AGAIN(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS_K1)
  {
    WL_POPN(2);
    u32 _f_2 = STK(0);
    u32 _id_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = ((U32_BIN(_f_2, ==, _id_1)) | (_h_0));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_APPENDED_SOURCE)
  {
    u32 _present_0 = r0;
    Term _sources_0 = r1;
    u32 _source_0 = r2;
    WL_OPEN
    if (_present_0 == 1) {
      r0 = _sources_0;
      WL_RETN(1);
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _source_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
        u64 _t_0 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _sources_0;
        e.mem[_t_0 + 1] = term_ctr(CID_CON, _nd_0);
        return term_tsk(FID_LIST_APPEND, _t_0);
      }
      r0 = _sources_0;
      r1 = term_ctr(CID_CON, _nd_0);
      WL_JMP(FID_LIST_APPEND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0)
  {
    Term _xs_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_SHOW_GO_0_K5;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_0_K5, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_0_K5, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _xs_0 = r0;
      WL_AGAIN(FID_LIST_SHOW_GO_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0_K5)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_0_K6;
      WL_PUSHN(1);
    } else {
      u64 _t_1 = task_node(e, FID_LIST_SHOW_GO_0_K6, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_0_K6, _t_1);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_2);
    }
    r0 = _f_2;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_0_K6)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID)
  {
    Term _xs_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_0;
        STK(1) = _id_0;
        STK(2) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID_K12;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID_K12, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _id_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID_K12, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _id_0;
      _xs_0 = r0;
      _id_0 = r1;
      WL_AGAIN(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID_K12)
  {
    WL_POPN(2);
    u32 _f_2 = STK(0);
    u32 _id_1 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_0(e, _o_0, U32_BIN(_f_2, ==, _id_1), _f_2, _h_0, blk_loc(e.mem, _h_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_SHOW_0_K21;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_0_K21, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_SHOW_0_K21, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_0)) {
        u64 _t_1 = task_node(e, FID_LIST_SHOW_GO_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_1;
        return term_tsk(FID_LIST_SHOW_GO_0, _t_1);
      }
      r0 = _f_1;
      WL_JMP(FID_LIST_SHOW_GO_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0_K21)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_0_K22;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_0_K22, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_0_K22, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _f_2;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_0_K22)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_0)
  {
    Term _graph_0 = r0;
    Term _graph_1 = r1;
    u32 _descriptor_0 = r2;
    Term _descriptor_1 = r3;
    Term _descriptor_2 = r4;
    u32 _descriptor_3 = r5;
    u32 _source_0 = r6;
    WL_OPEN
    term_sink(e, _graph_1);
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0)) {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _graph_0;
      e.mem[_t_0 + 1] = _descriptor_0;
      e.mem[_t_0 + 2] = _descriptor_1;
      e.mem[_t_0 + 3] = _descriptor_2;
      e.mem[_t_0 + 4] = _descriptor_3;
      e.mem[_t_0 + 5] = _source_0;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, _t_0);
    }
    r0 = _graph_0;
    r1 = _descriptor_0;
    r2 = _descriptor_1;
    r3 = _descriptor_2;
    r4 = _descriptor_3;
    r5 = _source_0;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0)
  {
    u32 _current_0 = r0;
    u32 _current_1 = r1;
    Term _next_0 = r2;
    WL_OPEN
    if (_current_0 == 0) {
      term_sink(e, _next_0);
      r0 = 0;
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0_K26;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0_K26, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0_K26, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _next_0;
        e.mem[_t_1 + 1] = _current_1;
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _next_0;
      r1 = _current_1;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0_K26)
  {
    Term _r_0 = r0;
    WL_OPEN
    u32 _o_0 = 0;
    if (term_aux(_r_0) == CID_FALSE) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
    }
    r0 = _o_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0)
  {
    Term _entries_0 = r0;
    u32 _descriptor_0 = r1;
    Term _descriptor_1 = r2;
    Term _descriptor_2 = r3;
    u32 _descriptor_3 = r4;
    u32 _target_0 = r5;
    u32 _source_0 = r6;
    WL_OPEN
    if (term_aux(_entries_0) == CID_NIL) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _source_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _descriptor_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _descriptor_1);
      e.mem[_nd_1 + 2] = rfc_seal(e, _descriptor_2);
      e.mem[_nd_1 + 3] = rfc_seal(e, _descriptor_3);
      e.mem[_nd_1 + 4] = rfc_seal(e, _target_0);
      e.mem[_nd_1 + 5] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_INVERSE, _nd_1));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      r0 = term_ctr(CID_CON, _nd_2);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _entries_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _o_0[1];
      if (spin_2(e, _o_0, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_5) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      _v_1 = _v_2;
      u32 _v_4 = 0;
      u32 _v_5 = 0;
      Term _o_1[1];
      if (spin_2(e, _o_1, _descriptor_0, _descriptor_1, blk_loc(e.mem, _descriptor_1), _descriptor_2, blk_loc(e.mem, _descriptor_2), _descriptor_3) == 0) {
        return 0;
      }
      _v_5 = _o_1[0];
      _v_4 = _v_5;
      u32 _v_6 = 0;
      Term _o_2[1];
      if (spin_3(e, _o_2, U32_BIN(_v_1, ==, _v_4), U32_BIN(_f_6, ==, _target_0)) == 0) {
        return 0;
      }
      _v_6 = _o_2[0];
      _v_0 = _v_6;
      _f_1 = term_keep(e, _f_1, 1);
      _descriptor_1 = term_keep(e, _descriptor_1, 1);
      _descriptor_2 = term_keep(e, _descriptor_2, 1);
      u64 _nd_3 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_3 + 0] = _f_1;
      e.mem[_nd_3 + 1] = _descriptor_0;
      e.mem[_nd_3 + 2] = _descriptor_1;
      e.mem[_nd_3 + 3] = _descriptor_2;
      e.mem[_nd_3 + 4] = _descriptor_3;
      e.mem[_nd_3 + 5] = _target_0;
      e.mem[_nd_3 + 6] = _source_0;
      if (_v_0 == 1) {
        term_sink(e, _descriptor_1);
        term_sink(e, _descriptor_2);
        Term _next_0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_C28, _nd_3);
        term_sink(e, _next_0);
        _f_7 = term_keep(e, _f_7, 1);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(9);
          STK(0) = _f_2;
          STK(1) = _f_3;
          STK(2) = _f_4;
          STK(3) = _f_5;
          STK(4) = _f_6;
          STK(5) = _f_7;
          STK(6) = _source_0;
          STK(7) = _f_1;
          STK(8) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K29;
          WL_PUSHN(9);
        } else {
          u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K29, WL_CONT, WL_IDX, 1);
          e.mem[_t_1 + 0] = _f_2;
          e.mem[_t_1 + 1] = _f_3;
          e.mem[_t_1 + 2] = _f_4;
          e.mem[_t_1 + 3] = _f_5;
          e.mem[_t_1 + 4] = _f_6;
          e.mem[_t_1 + 5] = _f_7;
          e.mem[_t_1 + 6] = _source_0;
          e.mem[_t_1 + 7] = _f_1;
          WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K29, _t_1);
          WL_IDX = 8;
        }
        if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS)) {
          u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS, WL_CONT, WL_IDX, 0);
          e.mem[_t_2 + 0] = _f_7;
          e.mem[_t_2 + 1] = _source_0;
          return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS, _t_2);
        }
        r0 = _f_7;
        r1 = _source_0;
        WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CONTAINS);
      } else {
        term_sink(e, _descriptor_1);
        term_sink(e, _descriptor_2);
        term_sink(e, _f_1);
        Term _next_1 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_C28, _nd_3);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(7);
          STK(0) = _f_2;
          STK(1) = _f_3;
          STK(2) = _f_4;
          STK(3) = _f_5;
          STK(4) = _f_6;
          STK(5) = _f_7;
          STK(6) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K31;
          WL_PUSHN(7);
        } else {
          u64 _t_5 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K31, WL_CONT, WL_IDX, 1);
          e.mem[_t_5 + 0] = _f_2;
          e.mem[_t_5 + 1] = _f_3;
          e.mem[_t_5 + 2] = _f_4;
          e.mem[_t_5 + 3] = _f_5;
          e.mem[_t_5 + 4] = _f_6;
          e.mem[_t_5 + 5] = _f_7;
          WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K31, _t_5);
          WL_IDX = 6;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_6 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_6 + 0] = _next_1;
          e.mem[_t_6 + 1] = term_pak(CID_UNIT, 0);
          return term_tsk(FID_CLO_APPLY, _t_6);
        }
        r0 = _next_1;
        r1 = term_pak(CID_UNIT, 0);
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_C28)
  {
    Term _f_8 = r0;
    u32 _descriptor_8 = r1;
    Term _descriptor_9 = r2;
    Term _descriptor_10 = r3;
    u32 _descriptor_11 = r4;
    u32 _target_1 = r5;
    u32 _source_1 = r6;
    Term _x_0 = r7;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0)) {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _f_8;
      e.mem[_t_0 + 1] = _descriptor_8;
      e.mem[_t_0 + 2] = _descriptor_9;
      e.mem[_t_0 + 3] = _descriptor_10;
      e.mem[_t_0 + 4] = _descriptor_11;
      e.mem[_t_0 + 5] = _target_1;
      e.mem[_t_0 + 6] = _source_1;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0, _t_0);
    }
    r0 = _f_8;
    r1 = _descriptor_8;
    r2 = _descriptor_9;
    r3 = _descriptor_10;
    r4 = _descriptor_11;
    r5 = _target_1;
    r6 = _source_1;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K29)
  {
    WL_POPN(8);
    u32 _f_9 = STK(0);
    Term _f_10 = STK(1);
    Term _f_11 = STK(2);
    u32 _f_12 = STK(3);
    u32 _f_13 = STK(4);
    Term _f_14 = STK(5);
    u32 _source_2 = STK(6);
    Term _f_15 = STK(7);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _f_9;
      STK(1) = _f_10;
      STK(2) = _f_11;
      STK(3) = _f_12;
      STK(4) = _f_13;
      STK(5) = _f_15;
      STK(6) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K30;
      WL_PUSHN(7);
    } else {
      u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K30, WL_CONT, WL_IDX, 1);
      e.mem[_t_3 + 0] = _f_9;
      e.mem[_t_3 + 1] = _f_10;
      e.mem[_t_3 + 2] = _f_11;
      e.mem[_t_3 + 3] = _f_12;
      e.mem[_t_3 + 4] = _f_13;
      e.mem[_t_3 + 5] = _f_15;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K30, _t_3);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_APPENDED_SOURCE)) {
      u64 _t_4 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_APPENDED_SOURCE, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _h_0;
      e.mem[_t_4 + 1] = _f_14;
      e.mem[_t_4 + 2] = _source_2;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_APPENDED_SOURCE, _t_4);
    }
    r0 = _h_0;
    r1 = _f_14;
    r2 = _source_2;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_APPENDED_SOURCE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K30)
  {
    WL_POPN(6);
    u32 _f_16 = STK(0);
    Term _f_17 = STK(1);
    Term _f_18 = STK(2);
    u32 _f_19 = STK(3);
    u32 _f_20 = STK(4);
    Term _f_21 = STK(5);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_4 + 0] = rfc_seal(e, _f_16);
    e.mem[_nd_4 + 1] = rfc_seal(e, _f_17);
    e.mem[_nd_4 + 2] = rfc_seal(e, _f_18);
    e.mem[_nd_4 + 3] = rfc_seal(e, _f_19);
    e.mem[_nd_4 + 4] = rfc_seal(e, _f_20);
    e.mem[_nd_4 + 5] = rfc_seal(e, _h_1);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_INVERSE, _nd_4));
    e.mem[_nd_5 + 1] = rfc_seal(e, _f_21);
    r0 = term_ctr(CID_CON, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0_K31)
  {
    WL_POPN(6);
    u32 _f_22 = STK(0);
    Term _f_23 = STK(1);
    Term _f_24 = STK(2);
    u32 _f_25 = STK(3);
    u32 _f_26 = STK(4);
    Term _f_27 = STK(5);
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_6 + 0] = rfc_seal(e, _f_22);
    e.mem[_nd_6 + 1] = rfc_seal(e, _f_23);
    e.mem[_nd_6 + 2] = rfc_seal(e, _f_24);
    e.mem[_nd_6 + 3] = rfc_seal(e, _f_25);
    e.mem[_nd_6 + 4] = rfc_seal(e, _f_26);
    e.mem[_nd_6 + 5] = rfc_seal(e, _f_27);
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_INVERSE, _nd_6));
    e.mem[_nd_7 + 1] = rfc_seal(e, _h_2);
    r0 = term_ctr(CID_CON, _nd_7);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0)
  {
    u32 _matched_0 = r0;
    u32 _descriptor_0 = r1;
    Term _descriptor_1 = r2;
    Term _descriptor_2 = r3;
    u32 _descriptor_3 = r4;
    u32 _target_0 = r5;
    Term _sources_0 = r6;
    u32 _source_0 = r7;
    Term _rest_0 = r8;
    WL_OPEN
    if (_matched_0 == 1) {
      if (seq) {
        WL_ROOM(7);
        STK(0) = _descriptor_0;
        STK(1) = _descriptor_1;
        STK(2) = _descriptor_2;
        STK(3) = _descriptor_3;
        STK(4) = _target_0;
        STK(5) = _rest_0;
        STK(6) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0_K34;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0_K34, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _descriptor_0;
        e.mem[_t_0 + 1] = _descriptor_1;
        e.mem[_t_0 + 2] = _descriptor_2;
        e.mem[_t_0 + 3] = _descriptor_3;
        e.mem[_t_0 + 4] = _target_0;
        e.mem[_t_0 + 5] = _rest_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0_K34, _t_0);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID)) {
        u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _sources_0;
        e.mem[_t_1 + 1] = _source_0;
        return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID, _t_1);
      }
      r0 = _sources_0;
      r1 = _source_0;
      WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_ID);
    } else {
      u64 _nd_3 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_3 + 0] = rfc_seal(e, _descriptor_0);
      e.mem[_nd_3 + 1] = rfc_seal(e, _descriptor_1);
      e.mem[_nd_3 + 2] = rfc_seal(e, _descriptor_2);
      e.mem[_nd_3 + 3] = rfc_seal(e, _descriptor_3);
      e.mem[_nd_3 + 4] = rfc_seal(e, _target_0);
      e.mem[_nd_3 + 5] = rfc_seal(e, _sources_0);
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_INVERSE, _nd_3));
      e.mem[_nd_4 + 1] = rfc_seal(e, _rest_0);
      r0 = term_ctr(CID_CON, _nd_4);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0_K34)
  {
    WL_POPN(6);
    u32 _descriptor_4 = STK(0);
    Term _descriptor_5 = STK(1);
    Term _descriptor_6 = STK(2);
    u32 _descriptor_7 = STK(3);
    u32 _target_1 = STK(4);
    Term _rest_1 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_4(e, _o_0, _descriptor_4, _descriptor_5, blk_loc(e.mem, _descriptor_5), _descriptor_6, blk_loc(e.mem, _descriptor_6), _descriptor_7, _target_1, _h_0, blk_loc(e.mem, _h_0), _rest_1, blk_loc(e.mem, _rest_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_2)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_2_K53;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_2_K53, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_2_K53, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_REGISTRATION)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_REGISTRATION, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        return term_tsk(FID_CONSUMER_SHOW_REGISTRATION, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      WL_JMP(FID_CONSUMER_SHOW_REGISTRATION);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_2_K53)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_2_K54;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_2_K54, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_2_K54, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_2)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      return term_tsk(FID_LIST_SHOW_GO_2, _t_3);
    }
    r0 = _f_5;
    WL_JMP(FID_LIST_SHOW_GO_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_2_K54)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_2_K55;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_2_K55, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_2_K55, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_2_K55)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REGISTRATION)
  {
    u32 _registration_0 = r0;
    Term _registration_1 = r1;
    Term _registration_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _registration_1;
      STK(1) = _registration_2;
      STK(2) = FID_CONSUMER_SHOW_REGISTRATION_K57;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_REGISTRATION_K57, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _registration_1;
      e.mem[_t_0 + 1] = _registration_2;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_REGISTRATION_K57, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _registration_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _registration_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REGISTRATION_K57)
  {
    WL_POPN(2);
    Term _registration_3 = STK(0);
    Term _registration_4 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _registration_3;
      STK(1) = _h_0;
      STK(2) = FID_CONSUMER_SHOW_REGISTRATION_K58;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_SHOW_REGISTRATION_K58, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _registration_3;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_REGISTRATION_K58, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_0)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _registration_4;
      return term_tsk(FID_LIST_SHOW_0, _t_3);
    }
    r0 = _registration_4;
    WL_JMP(FID_LIST_SHOW_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REGISTRATION_K58)
  {
    WL_POPN(2);
    Term _registration_5 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _registration_5;
      STK(1) = _h_2;
      STK(2) = FID_CONSUMER_SHOW_REGISTRATION_K59;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SHOW_REGISTRATION_K59, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _registration_5;
      e.mem[_t_4 + 1] = _h_2;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_REGISTRATION_K59, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REGISTRATION_K59)
  {
    WL_POPN(2);
    Term _registration_6 = STK(0);
    Term _h_4 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_4;
      STK(1) = FID_CONSUMER_SHOW_REGISTRATION_K60;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_SHOW_REGISTRATION_K60, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_REGISTRATION_K60, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _registration_6;
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _registration_6;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REGISTRATION_K60)
  {
    WL_POPN(1);
    Term _h_6 = STK(0);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_6;
      STK(1) = FID_CONSUMER_SHOW_REGISTRATION_K61;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_SHOW_REGISTRATION_K61, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_6;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_REGISTRATION_K61, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_9 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REGISTRATION_K61)
  {
    WL_POPN(1);
    Term _h_8 = STK(0);
    Term _h_7 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_8;
      e.mem[_t_10 + 1] = _h_7;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_8;
    r1 = _h_7;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      u32 _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      Term _o_11 = 0;
      if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL) {
        _o_0 = 0;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        _o_1 = _f_2;
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED) {
        _o_0 = 1;
        Term _fb_2[11];
        u64 _sp_2 = ctr_take(e, _f_0, 11, _fb_2);
        u32 _f_3 = _fb_2[0];
        Term _f_4 = _fb_2[1];
        Term _f_5 = _fb_2[2];
        u32 _f_6 = _fb_2[3];
        u32 _f_7 = _fb_2[4];
        u32 _f_8 = _fb_2[5];
        u32 _f_9 = _fb_2[6];
        u32 _f_10 = _fb_2[7];
        u32 _f_11 = _fb_2[8];
        Term _f_12 = _fb_2[9];
        Term _f_13 = _fb_2[10];
        spare_free(e, cls_fit(11), _sp_2);
        _o_1 = _f_3;
        _o_2 = _f_4;
        _o_3 = _f_5;
        _o_4 = _f_6;
        _o_5 = _f_7;
        _o_6 = _f_8;
        _o_7 = _f_9;
        _o_8 = _f_10;
        _o_9 = _f_11;
        _o_10 = _f_12;
        _o_11 = _f_13;
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED) {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 3;
        Term _fb_3[1];
        u64 _sp_3 = ctr_take(e, _f_0, 1, _fb_3);
        Term _f_14 = _fb_3[0];
        spare_free(e, cls_fit(1), _sp_3);
        _o_1 = _f_14;
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_1_K63;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_1_K63, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K63, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_NOTICE_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_NOTICE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        e.mem[_t_1 + 5] = _o_5;
        e.mem[_t_1 + 6] = _o_6;
        e.mem[_t_1 + 7] = _o_7;
        e.mem[_t_1 + 8] = _o_8;
        e.mem[_t_1 + 9] = _o_9;
        e.mem[_t_1 + 10] = _o_10;
        e.mem[_t_1 + 11] = _o_11;
        return term_tsk(FID_CONSUMER_SHOW_NOTICE_0, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      r5 = _o_5;
      r6 = _o_6;
      r7 = _o_7;
      r8 = _o_8;
      r9 = _o_9;
      r10 = _o_10;
      r11 = _o_11;
      WL_JMP(FID_CONSUMER_SHOW_NOTICE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K63)
  {
    WL_POPN(1);
    Term _f_15 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_1_K64;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_1_K64, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K64, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_1)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_15;
      return term_tsk(FID_LIST_SHOW_GO_1, _t_3);
    }
    r0 = _f_15;
    WL_JMP(FID_LIST_SHOW_GO_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K64)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_1_K65;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_1_K65, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K65, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K65)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_NOTICE_0)
  {
    u32 _notice_0 = r0;
    Term _notice_1 = r1;
    Term _notice_2 = r2;
    Term _notice_3 = r3;
    u32 _notice_4 = r4;
    u32 _notice_5 = r5;
    u32 _notice_6 = r6;
    u32 _notice_7 = r7;
    u32 _notice_8 = r8;
    u32 _notice_9 = r9;
    Term _notice_10 = r10;
    Term _notice_11 = r11;
    WL_OPEN
    if (_notice_0 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_SHOW_NOTICE_0_K67;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_NOTICE_0_K67, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_SHOW_NOTICE_0_K67, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _notice_1;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _notice_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_notice_0 == 2) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_SHOW_NOTICE_0_K68;
        WL_PUSHN(1);
      } else {
        u64 _t_3 = task_node(e, FID_CONSUMER_SHOW_NOTICE_0_K68, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_SHOW_NOTICE_0_K68, _t_3);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_4 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_4 + 0] = _notice_1;
        return term_tsk(FID_U32_SHOW, _t_4);
      }
      r0 = _notice_1;
      WL_JMP(FID_U32_SHOW);
    } else {
      term_sink(e, _notice_1);
      term_sink(e, _notice_2);
      term_sink(e, _notice_3);
      term_sink(e, _notice_10);
      term_sink(e, _notice_11);
      r0 = term_ctr(CID_SCON, STAT_OFF + 102);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_NOTICE_0_K67)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 54);
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_2);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 54);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_NOTICE_0_K68)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 68);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 68);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW_FIN)
  {
    Term _g_0 = r0;
    Term _acc_0 = r1;
    u32 _dq_0 = r2;
    Term _dq_1 = r3;
    WL_OPEN
    WL_SPIN
    if (_dq_1 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = term_ctr(CID_SCON, _nd_0);
      WL_RETN(1);
    } else {
      Term _p_0 = (_dq_1 - 1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      if (_g_0 == 0) {
        Term _n_0 = nat_chk(e, _p_0 + 1);
        Term _acc_1 = term_ctr(CID_SCON, _nd_1);
        r0 = _acc_1;
        WL_RETN(1);
      } else {
        Term _g_1 = (_g_0 - 1);
        Term _n_1 = nat_chk(e, _p_0 + 1);
        Term _acc_2 = term_ctr(CID_SCON, _nd_1);
        u32 _v_0 = 0;
        Term _v_1 = 0;
        Term _a_0 = 10ull;
        Term _a_1 = (_a_0 == 0 ? 0 : _n_1 / _a_0);
        Term _a_2 = (_a_0 == 0 ? _n_1 : _n_1 % _a_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _o_0[2];
        if (spin_1(e, _o_0, _a_1, _a_2) == 0) {
          return 0;
        }
        _v_2 = _o_0[0];
        _v_3 = _o_0[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        r0 = _g_1;
        r1 = _acc_2;
        r2 = _v_0;
        r3 = _v_1;
        _g_0 = r0;
        _acc_0 = r1;
        _dq_0 = r2;
        _dq_1 = r3;
        WL_AGAIN(FID_NAT_SHOW_FIN);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_LENGTH)
  {
    Term _xs_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _xs_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_LIST_LENGTH_K72;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_LENGTH_K72, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_LIST_LENGTH_K72, _t_0);
        WL_IDX = 0;
      }
      r0 = _f_1;
      _xs_0 = r0;
      WL_AGAIN(FID_LIST_LENGTH);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_LENGTH_K72)
  {
    Term _h_0 = r0;
    WL_OPEN
    r0 = nat_chk(e, _h_0 + 1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0)
  {
    Term _fuel_0 = r0;
    Term _graph_0 = r1;
    Term _graph_1 = r2;
    u32 _descriptor_0 = r3;
    Term _descriptor_1 = r4;
    Term _descriptor_2 = r5;
    u32 _descriptor_3 = r6;
    u32 _source_0 = r7;
    u32 _current_0 = r8;
    WL_OPEN
    if (_fuel_0 == 0) {
      term_sink(e, _graph_0);
      term_sink(e, _graph_1);
      term_sink(e, _descriptor_1);
      term_sink(e, _descriptor_2);
      r0 = U32_BIN(_source_0, ==, _current_0);
      WL_RETN(1);
    } else {
      Term _rest_0 = (_fuel_0 - 1);
      _graph_0 = term_keep(e, _graph_0, 1);
      _graph_1 = term_keep(e, _graph_1, 1);
      _descriptor_1 = term_keep(e, _descriptor_1, 1);
      _descriptor_2 = term_keep(e, _descriptor_2, 1);
      if (seq) {
        WL_ROOM(10);
        STK(0) = _rest_0;
        STK(1) = _graph_0;
        STK(2) = _graph_1;
        STK(3) = _descriptor_0;
        STK(4) = _descriptor_1;
        STK(5) = _descriptor_2;
        STK(6) = _descriptor_3;
        STK(7) = _source_0;
        STK(8) = _current_0;
        STK(9) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K74;
        WL_PUSHN(10);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K74, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _rest_0;
        e.mem[_t_0 + 1] = _graph_0;
        e.mem[_t_0 + 2] = _graph_1;
        e.mem[_t_0 + 3] = _descriptor_0;
        e.mem[_t_0 + 4] = _descriptor_1;
        e.mem[_t_0 + 5] = _descriptor_2;
        e.mem[_t_0 + 6] = _descriptor_3;
        e.mem[_t_0 + 7] = _source_0;
        e.mem[_t_0 + 8] = _current_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K74, _t_0);
        WL_IDX = 9;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_0)) {
        u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _graph_0;
        e.mem[_t_1 + 1] = _graph_1;
        e.mem[_t_1 + 2] = _descriptor_0;
        e.mem[_t_1 + 3] = _descriptor_1;
        e.mem[_t_1 + 4] = _descriptor_2;
        e.mem[_t_1 + 5] = _descriptor_3;
        e.mem[_t_1 + 6] = _current_0;
        return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_0, _t_1);
      }
      r0 = _graph_0;
      r1 = _graph_1;
      r2 = _descriptor_0;
      r3 = _descriptor_1;
      r4 = _descriptor_2;
      r5 = _descriptor_3;
      r6 = _current_0;
      WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K74)
  {
    WL_POPN(9);
    Term _rest_1 = STK(0);
    Term _graph_2 = STK(1);
    Term _graph_3 = STK(2);
    u32 _descriptor_4 = STK(3);
    Term _descriptor_5 = STK(4);
    Term _descriptor_6 = STK(5);
    u32 _descriptor_7 = STK(6);
    u32 _source_1 = STK(7);
    u32 _current_1 = STK(8);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(8));
    e.mem[_nd_0 + 0] = _rest_1;
    e.mem[_nd_0 + 1] = _graph_2;
    e.mem[_nd_0 + 2] = _graph_3;
    e.mem[_nd_0 + 3] = _descriptor_4;
    e.mem[_nd_0 + 4] = _descriptor_5;
    e.mem[_nd_0 + 5] = _descriptor_6;
    e.mem[_nd_0 + 6] = _descriptor_7;
    e.mem[_nd_0 + 7] = _source_1;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _source_1;
      STK(1) = _current_1;
      STK(2) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K77;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K77, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _source_1;
      e.mem[_t_4 + 1] = _current_1;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K77, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0)) {
      u64 _t_5 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_0;
      e.mem[_t_5 + 1] = _h_1;
      e.mem[_t_5 + 2] = term_clo(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_C75, _nd_0);
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0, _t_5);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_C75, _nd_0);
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_NEXT_CYCLE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_C75)
  {
    Term _rest_2 = r0;
    Term _graph_4 = r1;
    Term _graph_5 = r2;
    u32 _descriptor_8 = r3;
    Term _descriptor_9 = r4;
    Term _descriptor_10 = r5;
    u32 _descriptor_11 = r6;
    u32 _source_2 = r7;
    Term _x_0 = r8;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K76;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K76, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K76, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0)) {
      u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _rest_2;
      e.mem[_t_3 + 1] = _graph_4;
      e.mem[_t_3 + 2] = _graph_5;
      e.mem[_t_3 + 3] = _descriptor_8;
      e.mem[_t_3 + 4] = _descriptor_9;
      e.mem[_t_3 + 5] = _descriptor_10;
      e.mem[_t_3 + 6] = _descriptor_11;
      e.mem[_t_3 + 7] = _source_2;
      e.mem[_t_3 + 8] = _x_0;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0, _t_3);
    }
    r0 = _rest_2;
    r1 = _graph_4;
    r2 = _graph_5;
    r3 = _descriptor_8;
    r4 = _descriptor_9;
    r5 = _descriptor_10;
    r6 = _descriptor_11;
    r7 = _source_2;
    r8 = _x_0;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K76)
  {
    u32 _r_0 = r0;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      _b_0 = term_pak(CID_FALSE, 0);
    } else {
      _b_0 = term_pak(CID_TRUE, 0);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0_K77)
  {
    WL_POPN(2);
    u32 _source_3 = STK(0);
    u32 _current_2 = STK(1);
    u32 _h_2 = r0;
    WL_OPEN
    r0 = ((U32_BIN(_source_3, ==, _current_2)) | (_h_2));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0)
  {
    u32 _same_0 = r0;
    Term _edges_0 = r1;
    Term _inverses_0 = r2;
    u32 _descriptor_0 = r3;
    Term _descriptor_1 = r4;
    Term _descriptor_2 = r5;
    u32 _descriptor_3 = r6;
    u32 _source_0 = r7;
    u32 _target_0 = r8;
    WL_OPEN
    if (_same_0 == 1) {
      term_sink(e, _descriptor_1);
      term_sink(e, _descriptor_2);
      r0 = _edges_0;
      r1 = _inverses_0;
      WL_RETN(2);
    } else {
      Term _v_0 = 0;
      _edges_0 = term_keep(e, _edges_0, 1);
      Term _v_1 = 0;
      Term _o_8[1];
      if (spin_6(e, _o_8, _edges_0, blk_loc(e.mem, _edges_0), _descriptor_0, _descriptor_1, blk_loc(e.mem, _descriptor_1), _descriptor_2, blk_loc(e.mem, _descriptor_2), _descriptor_3, _source_0) == 0) {
        return 0;
      }
      _v_1 = _o_8[0];
      _v_0 = _v_1;
      _descriptor_1 = term_keep(e, _descriptor_1, 1);
      _descriptor_2 = term_keep(e, _descriptor_2, 1);
      u64 _nd_3 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_3 + 0] = rfc_seal(e, _descriptor_0);
      e.mem[_nd_3 + 1] = rfc_seal(e, _descriptor_1);
      e.mem[_nd_3 + 2] = rfc_seal(e, _descriptor_2);
      e.mem[_nd_3 + 3] = rfc_seal(e, _descriptor_3);
      e.mem[_nd_3 + 4] = rfc_seal(e, _source_0);
      e.mem[_nd_3 + 5] = rfc_seal(e, _target_0);
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_EDGE, _nd_3));
      e.mem[_nd_4 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      if (seq) {
        WL_ROOM(9);
        STK(0) = _edges_0;
        STK(1) = _inverses_0;
        STK(2) = _descriptor_0;
        STK(3) = _descriptor_1;
        STK(4) = _descriptor_2;
        STK(5) = _descriptor_3;
        STK(6) = _source_0;
        STK(7) = _target_0;
        STK(8) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K80;
        WL_PUSHN(9);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K80, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _edges_0;
        e.mem[_t_0 + 1] = _inverses_0;
        e.mem[_t_0 + 2] = _descriptor_0;
        e.mem[_t_0 + 3] = _descriptor_1;
        e.mem[_t_0 + 4] = _descriptor_2;
        e.mem[_t_0 + 5] = _descriptor_3;
        e.mem[_t_0 + 6] = _source_0;
        e.mem[_t_0 + 7] = _target_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K80, _t_0);
        WL_IDX = 8;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
        u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = term_ctr(CID_CON, _nd_4);
        return term_tsk(FID_LIST_APPEND, _t_1);
      }
      r0 = _v_0;
      r1 = term_ctr(CID_CON, _nd_4);
      WL_JMP(FID_LIST_APPEND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K80)
  {
    WL_POPN(8);
    Term _edges_3 = STK(0);
    Term _inverses_1 = STK(1);
    u32 _descriptor_16 = STK(2);
    Term _descriptor_17 = STK(3);
    Term _descriptor_18 = STK(4);
    u32 _descriptor_19 = STK(5);
    u32 _source_4 = STK(6);
    u32 _target_1 = STK(7);
    Term _h_0 = r0;
    WL_OPEN
    _descriptor_17 = term_keep(e, _descriptor_17, 1);
    _descriptor_18 = term_keep(e, _descriptor_18, 1);
    if (seq) {
      WL_ROOM(9);
      STK(0) = _inverses_1;
      STK(1) = _descriptor_16;
      STK(2) = _descriptor_17;
      STK(3) = _descriptor_18;
      STK(4) = _descriptor_19;
      STK(5) = _source_4;
      STK(6) = _target_1;
      STK(7) = _h_0;
      STK(8) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K81;
      WL_PUSHN(9);
    } else {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K81, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _inverses_1;
      e.mem[_t_2 + 1] = _descriptor_16;
      e.mem[_t_2 + 2] = _descriptor_17;
      e.mem[_t_2 + 3] = _descriptor_18;
      e.mem[_t_2 + 4] = _descriptor_19;
      e.mem[_t_2 + 5] = _source_4;
      e.mem[_t_2 + 6] = _target_1;
      e.mem[_t_2 + 7] = _h_0;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K81, _t_2);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0)) {
      u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _edges_3;
      e.mem[_t_3 + 1] = _descriptor_16;
      e.mem[_t_3 + 2] = _descriptor_17;
      e.mem[_t_3 + 3] = _descriptor_18;
      e.mem[_t_3 + 4] = _descriptor_19;
      e.mem[_t_3 + 5] = _source_4;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, _t_3);
    }
    r0 = _edges_3;
    r1 = _descriptor_16;
    r2 = _descriptor_17;
    r3 = _descriptor_18;
    r4 = _descriptor_19;
    r5 = _source_4;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K81)
  {
    WL_POPN(8);
    Term _inverses_2 = STK(0);
    u32 _descriptor_20 = STK(1);
    Term _descriptor_21 = STK(2);
    Term _descriptor_22 = STK(3);
    u32 _descriptor_23 = STK(4);
    u32 _source_5 = STK(5);
    u32 _target_2 = STK(6);
    Term _h_3 = STK(7);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _descriptor_20;
      STK(1) = _descriptor_21;
      STK(2) = _descriptor_22;
      STK(3) = _descriptor_23;
      STK(4) = _source_5;
      STK(5) = _target_2;
      STK(6) = _h_3;
      STK(7) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K82;
      WL_PUSHN(8);
    } else {
      u64 _t_4 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K82, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _descriptor_20;
      e.mem[_t_4 + 1] = _descriptor_21;
      e.mem[_t_4 + 2] = _descriptor_22;
      e.mem[_t_4 + 3] = _descriptor_23;
      e.mem[_t_4 + 4] = _source_5;
      e.mem[_t_4 + 5] = _target_2;
      e.mem[_t_4 + 6] = _h_3;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K82, _t_4);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0)) {
      u64 _t_5 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_1;
      e.mem[_t_5 + 1] = _h_2;
      e.mem[_t_5 + 2] = _inverses_2;
      e.mem[_t_5 + 3] = _descriptor_20;
      e.mem[_t_5 + 4] = _descriptor_21;
      e.mem[_t_5 + 5] = _descriptor_22;
      e.mem[_t_5 + 6] = _descriptor_23;
      e.mem[_t_5 + 7] = _source_5;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0, _t_5);
    }
    r0 = _h_1;
    r1 = _h_2;
    r2 = _inverses_2;
    r3 = _descriptor_20;
    r4 = _descriptor_21;
    r5 = _descriptor_22;
    r6 = _descriptor_23;
    r7 = _source_5;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K82)
  {
    WL_POPN(7);
    u32 _descriptor_24 = STK(0);
    Term _descriptor_25 = STK(1);
    Term _descriptor_26 = STK(2);
    u32 _descriptor_27 = STK(3);
    u32 _source_6 = STK(4);
    u32 _target_3 = STK(5);
    Term _h_5 = STK(6);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_5;
      STK(1) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K83;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K83, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_5;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K83, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0)) {
      u64 _t_7 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_4;
      e.mem[_t_7 + 1] = _descriptor_24;
      e.mem[_t_7 + 2] = _descriptor_25;
      e.mem[_t_7 + 3] = _descriptor_26;
      e.mem[_t_7 + 4] = _descriptor_27;
      e.mem[_t_7 + 5] = _target_3;
      e.mem[_t_7 + 6] = _source_6;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0, _t_7);
    }
    r0 = _h_4;
    r1 = _descriptor_24;
    r2 = _descriptor_25;
    r3 = _descriptor_26;
    r4 = _descriptor_27;
    r5 = _target_3;
    r6 = _source_6;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ADD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0_K83)
  {
    WL_POPN(1);
    Term _h_7 = STK(0);
    Term _h_6 = r0;
    WL_OPEN
    r0 = _h_7;
    r1 = _h_6;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0)
  {
    Term _entries_0 = r0;
    u32 _descriptor_0 = r1;
    Term _descriptor_1 = r2;
    Term _descriptor_2 = r3;
    u32 _descriptor_3 = r4;
    u32 _target_0 = r5;
    u32 _source_0 = r6;
    Term _acc_0 = r7;
    WL_OPEN
    if (term_aux(_entries_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _o_1[1];
      if (spin_15(e, _o_1, _acc_0, blk_loc(e.mem, _acc_0)) == 0) {
        return 0;
      }
      _v_0 = _o_1[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _entries_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _fb_2[6];
      u64 _sp_2 = ctr_take(e, _f_2, 6, _fb_2);
      u32 _f_4 = _fb_2[0];
      Term _f_5 = _fb_2[1];
      Term _f_6 = _fb_2[2];
      u32 _f_7 = _fb_2[3];
      u32 _f_8 = _fb_2[4];
      Term _f_9 = _fb_2[5];
      spare_free(e, cls_fit(6), _sp_2);
      u32 _v_4 = 0;
      u32 _v_5 = 0;
      u32 _v_6 = 0;
      Term _o_2[1];
      if (spin_2(e, _o_2, _f_4, _f_5, blk_loc(e.mem, _f_5), _f_6, blk_loc(e.mem, _f_6), _f_7) == 0) {
        return 0;
      }
      _v_6 = _o_2[0];
      _v_5 = _v_6;
      u32 _v_7 = 0;
      u32 _v_8 = 0;
      Term _o_3[1];
      if (spin_2(e, _o_3, _descriptor_0, _descriptor_1, blk_loc(e.mem, _descriptor_1), _descriptor_2, blk_loc(e.mem, _descriptor_2), _descriptor_3) == 0) {
        return 0;
      }
      _v_8 = _o_3[0];
      _v_7 = _v_8;
      u32 _v_9 = 0;
      Term _o_4[1];
      if (spin_3(e, _o_4, U32_BIN(_v_5, ==, _v_7), U32_BIN(_f_8, ==, _target_0)) == 0) {
        return 0;
      }
      _v_9 = _o_4[0];
      _v_4 = _v_9;
      spare_free(e, cls_fit(2), _sp_1);
      if (seq) {
        WL_ROOM(8);
        STK(0) = _f_3;
        STK(1) = _descriptor_0;
        STK(2) = _descriptor_1;
        STK(3) = _descriptor_2;
        STK(4) = _descriptor_3;
        STK(5) = _target_0;
        STK(6) = _source_0;
        STK(7) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0_K86;
        WL_PUSHN(8);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0_K86, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_3;
        e.mem[_t_0 + 1] = _descriptor_0;
        e.mem[_t_0 + 2] = _descriptor_1;
        e.mem[_t_0 + 3] = _descriptor_2;
        e.mem[_t_0 + 4] = _descriptor_3;
        e.mem[_t_0 + 5] = _target_0;
        e.mem[_t_0 + 6] = _source_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0_K86, _t_0);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0)) {
        u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_4;
        e.mem[_t_1 + 1] = _f_4;
        e.mem[_t_1 + 2] = _f_5;
        e.mem[_t_1 + 3] = _f_6;
        e.mem[_t_1 + 4] = _f_7;
        e.mem[_t_1 + 5] = _f_8;
        e.mem[_t_1 + 6] = _f_9;
        e.mem[_t_1 + 7] = _source_0;
        e.mem[_t_1 + 8] = _acc_0;
        return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0, _t_1);
      }
      r0 = _v_4;
      r1 = _f_4;
      r2 = _f_5;
      r3 = _f_6;
      r4 = _f_7;
      r5 = _f_8;
      r6 = _f_9;
      r7 = _source_0;
      r8 = _acc_0;
      WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ONE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0_K86)
  {
    WL_POPN(7);
    Term _f_10 = STK(0);
    u32 _descriptor_4 = STK(1);
    Term _descriptor_5 = STK(2);
    Term _descriptor_6 = STK(3);
    u32 _descriptor_7 = STK(4);
    u32 _target_1 = STK(5);
    u32 _source_1 = STK(6);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0)) {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_10;
      e.mem[_t_2 + 1] = _descriptor_4;
      e.mem[_t_2 + 2] = _descriptor_5;
      e.mem[_t_2 + 3] = _descriptor_6;
      e.mem[_t_2 + 4] = _descriptor_7;
      e.mem[_t_2 + 5] = _target_1;
      e.mem[_t_2 + 6] = _source_1;
      e.mem[_t_2 + 7] = _h_0;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0, _t_2);
    }
    r0 = _f_10;
    r1 = _descriptor_4;
    r2 = _descriptor_5;
    r3 = _descriptor_6;
    r4 = _descriptor_7;
    r5 = _target_1;
    r6 = _source_1;
    r7 = _h_0;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_PAYLOAD)
  {
    Term _payload_0 = r0;
    Term _payload_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _payload_1;
      STK(1) = FID_CONSUMER_SHOW_PAYLOAD_K97;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_PAYLOAD_K97, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _payload_1;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_PAYLOAD_K97, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_TREE_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_TREE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _payload_0;
      return term_tsk(FID_CONSUMER_TREE_0, _t_1);
    }
    r0 = _payload_0;
    WL_JMP(FID_CONSUMER_TREE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_PAYLOAD_K97)
  {
    WL_POPN(1);
    Term _payload_2 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = FID_CONSUMER_SHOW_PAYLOAD_K98;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_SHOW_PAYLOAD_K98, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_PAYLOAD_K98, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_TREE_0)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_TREE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _payload_2;
      return term_tsk(FID_CONSUMER_TREE_0, _t_3);
    }
    r0 = _payload_2;
    WL_JMP(FID_CONSUMER_TREE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_PAYLOAD_K98)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_2 = r0;
    Term _h_3 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_2;
      STK(3) = FID_CONSUMER_SHOW_PAYLOAD_K99;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SHOW_PAYLOAD_K99, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_4;
      e.mem[_t_4 + 1] = _h_5;
      e.mem[_t_4 + 2] = _h_2;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_PAYLOAD_K99, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_3;
      e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 6);
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_3;
    r1 = term_ctr(CID_SCON, STAT_OFF + 6);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_PAYLOAD_K99)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_7;
      STK(1) = _h_8;
      STK(2) = _h_9;
      STK(3) = FID_CONSUMER_SHOW_PAYLOAD_K100;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_SHOW_PAYLOAD_K100, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_7;
      e.mem[_t_6 + 1] = _h_8;
      e.mem[_t_6 + 2] = _h_9;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_PAYLOAD_K100, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_7 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_PAYLOAD_K100)
  {
    WL_POPN(3);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_11;
      STK(1) = _h_13;
      STK(2) = FID_CONSUMER_SHOW_PAYLOAD_K101;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_SHOW_PAYLOAD_K101, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_11;
      e.mem[_t_8 + 1] = _h_13;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_PAYLOAD_K101, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_12;
      e.mem[_t_9 + 1] = _h_10;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_12;
    r1 = _h_10;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_PAYLOAD_K101)
  {
    WL_POPN(2);
    Term _h_15 = STK(0);
    Term _h_16 = STK(1);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_15;
      STK(1) = _h_16;
      STK(2) = FID_CONSUMER_SHOW_PAYLOAD_K102;
      WL_PUSHN(3);
    } else {
      u64 _t_10 = task_node(e, FID_CONSUMER_SHOW_PAYLOAD_K102, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_15;
      e.mem[_t_10 + 1] = _h_16;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_PAYLOAD_K102, _t_10);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 12);
      e.mem[_t_11 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 12);
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_PAYLOAD_K102)
  {
    WL_POPN(2);
    Term _h_18 = STK(0);
    Term _h_19 = STK(1);
    Term _h_17 = r0;
    WL_OPEN
    r0 = _h_18;
    r1 = _h_19;
    r2 = _h_17;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_5)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_5_K107;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_5_K107, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_5_K107, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_INVERSE_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_INVERSE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _f_5;
        e.mem[_t_1 + 4] = _f_6;
        e.mem[_t_1 + 5] = _f_7;
        return term_tsk(FID_CONSUMER_SHOW_INVERSE_0, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _f_5;
      r4 = _f_6;
      r5 = _f_7;
      WL_JMP(FID_CONSUMER_SHOW_INVERSE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_5_K107)
  {
    WL_POPN(1);
    Term _f_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_5_K108;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_5_K108, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_5_K108, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_5)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_5, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_8;
      return term_tsk(FID_LIST_SHOW_GO_5, _t_3);
    }
    r0 = _f_8;
    WL_JMP(FID_LIST_SHOW_GO_5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_5_K108)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_5_K109;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_5_K109, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_5_K109, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_5_K109)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_INVERSE_0)
  {
    u32 _inverse_0 = r0;
    Term _inverse_1 = r1;
    Term _inverse_2 = r2;
    u32 _inverse_3 = r3;
    u32 _inverse_4 = r4;
    Term _inverse_5 = r5;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _inverse_4;
      STK(1) = _inverse_5;
      STK(2) = FID_CONSUMER_SHOW_INVERSE_0_K111;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_INVERSE_0_K111, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _inverse_4;
      e.mem[_t_0 + 1] = _inverse_5;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_INVERSE_0_K111, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_DESCRIPTOR_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _inverse_0;
      e.mem[_t_1 + 1] = _inverse_1;
      e.mem[_t_1 + 2] = _inverse_2;
      e.mem[_t_1 + 3] = _inverse_3;
      return term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0, _t_1);
    }
    r0 = _inverse_0;
    r1 = _inverse_1;
    r2 = _inverse_2;
    r3 = _inverse_3;
    WL_JMP(FID_CONSUMER_SHOW_DESCRIPTOR_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_INVERSE_0_K111)
  {
    WL_POPN(2);
    u32 _inverse_6 = STK(0);
    Term _inverse_7 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _inverse_7;
      STK(1) = _h_0;
      STK(2) = FID_CONSUMER_SHOW_INVERSE_0_K112;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_SHOW_INVERSE_0_K112, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _inverse_7;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_INVERSE_0_K112, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _inverse_6;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _inverse_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_INVERSE_0_K112)
  {
    WL_POPN(2);
    Term _inverse_8 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_CONSUMER_SHOW_INVERSE_0_K113;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SHOW_INVERSE_0_K113, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_INVERSE_0_K113, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_5)) {
      u64 _t_5 = task_node(e, FID_LIST_SHOW_5, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _inverse_8;
      return term_tsk(FID_LIST_SHOW_5, _t_5);
    }
    r0 = _inverse_8;
    WL_JMP(FID_LIST_SHOW_5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_INVERSE_0_K113)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_CONSUMER_SHOW_INVERSE_0_K114;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_SHOW_INVERSE_0_K114, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_INVERSE_0_K114, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_INVERSE_0_K114)
  {
    WL_POPN(2);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_7;
      STK(1) = FID_CONSUMER_SHOW_INVERSE_0_K115;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_SHOW_INVERSE_0_K115, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_INVERSE_0_K115, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_8;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_INVERSE_0_K115)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_10;
      STK(1) = FID_CONSUMER_SHOW_INVERSE_0_K116;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_CONSUMER_SHOW_INVERSE_0_K116, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_10;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_INVERSE_0_K116, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_INVERSE_0_K116)
  {
    WL_POPN(1);
    Term _h_12 = STK(0);
    Term _h_11 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_12;
      e.mem[_t_12 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _h_12;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_3)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      u32 _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_3_K118;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_3_K118, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_3_K118, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_EDGE_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_EDGE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _f_5;
        e.mem[_t_1 + 4] = _f_6;
        e.mem[_t_1 + 5] = _f_7;
        return term_tsk(FID_CONSUMER_SHOW_EDGE_0, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _f_5;
      r4 = _f_6;
      r5 = _f_7;
      WL_JMP(FID_CONSUMER_SHOW_EDGE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_3_K118)
  {
    WL_POPN(1);
    Term _f_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_3_K119;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_3_K119, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_3_K119, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_3)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_3, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_8;
      return term_tsk(FID_LIST_SHOW_GO_3, _t_3);
    }
    r0 = _f_8;
    WL_JMP(FID_LIST_SHOW_GO_3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_3_K119)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_3_K120;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_3_K120, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_3_K120, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_3_K120)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_EDGE_0)
  {
    u32 _edge_0 = r0;
    Term _edge_1 = r1;
    Term _edge_2 = r2;
    u32 _edge_3 = r3;
    u32 _edge_4 = r4;
    u32 _edge_5 = r5;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _edge_4;
      STK(1) = _edge_5;
      STK(2) = FID_CONSUMER_SHOW_EDGE_0_K122;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_EDGE_0_K122, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _edge_4;
      e.mem[_t_0 + 1] = _edge_5;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_EDGE_0_K122, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_DESCRIPTOR_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _edge_0;
      e.mem[_t_1 + 1] = _edge_1;
      e.mem[_t_1 + 2] = _edge_2;
      e.mem[_t_1 + 3] = _edge_3;
      return term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0, _t_1);
    }
    r0 = _edge_0;
    r1 = _edge_1;
    r2 = _edge_2;
    r3 = _edge_3;
    WL_JMP(FID_CONSUMER_SHOW_DESCRIPTOR_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_EDGE_0_K122)
  {
    WL_POPN(2);
    u32 _edge_6 = STK(0);
    u32 _edge_7 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _edge_7;
      STK(1) = _h_0;
      STK(2) = FID_CONSUMER_SHOW_EDGE_0_K123;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_SHOW_EDGE_0_K123, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _edge_7;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_EDGE_0_K123, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _edge_6;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _edge_6;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_EDGE_0_K123)
  {
    WL_POPN(2);
    u32 _edge_8 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_CONSUMER_SHOW_EDGE_0_K124;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SHOW_EDGE_0_K124, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_EDGE_0_K124, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_5 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _edge_8;
      return term_tsk(FID_U32_SHOW, _t_5);
    }
    r0 = _edge_8;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_EDGE_0_K124)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_CONSUMER_SHOW_EDGE_0_K125;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_SHOW_EDGE_0_K125, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_EDGE_0_K125, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 104);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 104);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_EDGE_0_K125)
  {
    WL_POPN(2);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_7;
      STK(1) = FID_CONSUMER_SHOW_EDGE_0_K126;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_SHOW_EDGE_0_K126, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_EDGE_0_K126, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_8;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_EDGE_0_K126)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_10;
      STK(1) = FID_CONSUMER_SHOW_EDGE_0_K127;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_CONSUMER_SHOW_EDGE_0_K127, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_10;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_EDGE_0_K127, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_EDGE_0_K127)
  {
    WL_POPN(1);
    Term _h_12 = STK(0);
    Term _h_11 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_12;
      e.mem[_t_12 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _h_12;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_2)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_2_K145;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_2_K145, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_2_K145, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_REGISTRATION)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_REGISTRATION, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        return term_tsk(FID_CONSUMER_SHOW_REGISTRATION, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      WL_JMP(FID_CONSUMER_SHOW_REGISTRATION);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_2_K145)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_2_K146;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_2_K146, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_2_K146, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_2)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      return term_tsk(FID_LIST_SHOW_GO_2, _t_3);
    }
    r0 = _f_5;
    WL_JMP(FID_LIST_SHOW_GO_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_2_K146)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_2_K147;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_2_K147, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_2_K147, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_2_K147)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      u32 _o_5 = 0;
      u32 _o_6 = 0;
      u32 _o_7 = 0;
      u32 _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      Term _o_11 = 0;
      if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL) {
        _o_0 = 0;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        _o_1 = _f_2;
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED) {
        _o_0 = 1;
        Term _fb_2[11];
        u64 _sp_2 = ctr_take(e, _f_0, 11, _fb_2);
        u32 _f_3 = _fb_2[0];
        Term _f_4 = _fb_2[1];
        Term _f_5 = _fb_2[2];
        u32 _f_6 = _fb_2[3];
        u32 _f_7 = _fb_2[4];
        u32 _f_8 = _fb_2[5];
        u32 _f_9 = _fb_2[6];
        u32 _f_10 = _fb_2[7];
        u32 _f_11 = _fb_2[8];
        Term _f_12 = _fb_2[9];
        Term _f_13 = _fb_2[10];
        spare_free(e, cls_fit(11), _sp_2);
        _o_1 = _f_3;
        _o_2 = _f_4;
        _o_3 = _f_5;
        _o_4 = _f_6;
        _o_5 = _f_7;
        _o_6 = _f_8;
        _o_7 = _f_9;
        _o_8 = _f_10;
        _o_9 = _f_11;
        _o_10 = _f_12;
        _o_11 = _f_13;
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED) {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 3;
        Term _fb_3[1];
        u64 _sp_3 = ctr_take(e, _f_0, 1, _fb_3);
        Term _f_14 = _fb_3[0];
        spare_free(e, cls_fit(1), _sp_3);
        _o_1 = _f_14;
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_1_K149;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_1_K149, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_1_K149, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_NOTICE_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_NOTICE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        e.mem[_t_1 + 5] = _o_5;
        e.mem[_t_1 + 6] = _o_6;
        e.mem[_t_1 + 7] = _o_7;
        e.mem[_t_1 + 8] = _o_8;
        e.mem[_t_1 + 9] = _o_9;
        e.mem[_t_1 + 10] = _o_10;
        e.mem[_t_1 + 11] = _o_11;
        return term_tsk(FID_CONSUMER_SHOW_NOTICE_0, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      r5 = _o_5;
      r6 = _o_6;
      r7 = _o_7;
      r8 = _o_8;
      r9 = _o_9;
      r10 = _o_10;
      r11 = _o_11;
      WL_JMP(FID_CONSUMER_SHOW_NOTICE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K149)
  {
    WL_POPN(1);
    Term _f_15 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_1_K150;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_1_K150, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_1_K150, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_1)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_15;
      return term_tsk(FID_LIST_SHOW_GO_1, _t_3);
    }
    r0 = _f_15;
    WL_JMP(FID_LIST_SHOW_GO_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K150)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_1_K151;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_1_K151, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_1_K151, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K151)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW)
  {
    Term _n_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _a_0 = 10ull;
    Term _a_1 = (_a_0 == 0 ? 0 : _n_0 / _a_0);
    Term _a_2 = (_a_0 == 0 ? _n_0 : _n_0 % _a_0);
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_1(e, _o_0, _a_1, _a_2) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW_FIN)) {
      u64 _t_0 = task_node(e, FID_NAT_SHOW_FIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _n_0;
      e.mem[_t_0 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      return term_tsk(FID_NAT_SHOW_FIN, _t_0);
    }
    r0 = _n_0;
    r1 = term_pak(CID_SNIL, 0);
    r2 = _v_0;
    r3 = _v_1;
    WL_JMP(FID_NAT_SHOW_FIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0)
  {
    Term _graph_0 = r0;
    Term _graph_1 = r1;
    u32 _descriptor_0 = r2;
    Term _descriptor_1 = r3;
    Term _descriptor_2 = r4;
    u32 _descriptor_3 = r5;
    u32 _source_0 = r6;
    u32 _target_0 = r7;
    WL_OPEN
    if (_descriptor_3 == 0) {
      term_sink(e, _graph_0);
      term_sink(e, _graph_1);
      term_sink(e, _descriptor_1);
      term_sink(e, _descriptor_2);
      r0 = 0;
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(8);
        STK(0) = _graph_0;
        STK(1) = _graph_1;
        STK(2) = _descriptor_0;
        STK(3) = _descriptor_1;
        STK(4) = _descriptor_2;
        STK(5) = _source_0;
        STK(6) = _target_0;
        STK(7) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0_K155;
        WL_PUSHN(8);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0_K155, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _graph_0;
        e.mem[_t_0 + 1] = _graph_1;
        e.mem[_t_0 + 2] = _descriptor_0;
        e.mem[_t_0 + 3] = _descriptor_1;
        e.mem[_t_0 + 4] = _descriptor_2;
        e.mem[_t_0 + 5] = _source_0;
        e.mem[_t_0 + 6] = _target_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0_K155, _t_0);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LIST_LENGTH)) {
        u64 _t_1 = task_node(e, FID_LIST_LENGTH, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _graph_0;
        return term_tsk(FID_LIST_LENGTH, _t_1);
      }
      r0 = _graph_0;
      WL_JMP(FID_LIST_LENGTH);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0_K155)
  {
    WL_POPN(7);
    Term _graph_2 = STK(0);
    Term _graph_3 = STK(1);
    u32 _descriptor_4 = STK(2);
    Term _descriptor_5 = STK(3);
    Term _descriptor_6 = STK(4);
    u32 _source_1 = STK(5);
    u32 _target_1 = STK(6);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0)) {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _graph_2;
      e.mem[_t_2 + 2] = _graph_3;
      e.mem[_t_2 + 3] = _descriptor_4;
      e.mem[_t_2 + 4] = _descriptor_5;
      e.mem[_t_2 + 5] = _descriptor_6;
      e.mem[_t_2 + 6] = 1;
      e.mem[_t_2 + 7] = _source_1;
      e.mem[_t_2 + 8] = _target_1;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0, _t_2);
    }
    r0 = _h_0;
    r1 = _graph_2;
    r2 = _graph_3;
    r3 = _descriptor_4;
    r4 = _descriptor_5;
    r5 = _descriptor_6;
    r6 = 1;
    r7 = _source_1;
    r8 = _target_1;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_SLOT)
  {
    u32 _slot_0 = r0;
    Term _slot_1 = r1;
    Term _slot_2 = r2;
    WL_OPEN
    if (_slot_0 == 0) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = term_ctr(CID_SCON, STAT_OFF + 118);
      WL_RETN(4);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_SHOW_SLOT_K175;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_SLOT_K175, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_SHOW_SLOT_K175, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_PAYLOAD)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_PAYLOAD, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _slot_1;
        e.mem[_t_1 + 1] = _slot_2;
        return term_tsk(FID_CONSUMER_SHOW_PAYLOAD, _t_1);
      }
      r0 = _slot_1;
      r1 = _slot_2;
      WL_JMP(FID_CONSUMER_SHOW_PAYLOAD);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_SLOT_K175)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[4];
    if (spin_21(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REMOVED)
  {
    Term _removed_0 = r0;
    WL_OPEN
    if (term_aux(_removed_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      r1 = term_pak(CID_SNIL, 0);
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _removed_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_CONSUMER_SHOW_REMOVED_K180;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_REMOVED_K180, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_CONSUMER_SHOW_REMOVED_K180, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_PAYLOAD)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_PAYLOAD, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        return term_tsk(FID_CONSUMER_SHOW_PAYLOAD, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      WL_JMP(FID_CONSUMER_SHOW_PAYLOAD);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REMOVED_K180)
  {
    WL_POPN(1);
    Term _f_4 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = FID_CONSUMER_SHOW_REMOVED_K181;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_SHOW_REMOVED_K181, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_REMOVED_K181, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_REMOVED)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_SHOW_REMOVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_4;
      return term_tsk(FID_CONSUMER_SHOW_REMOVED, _t_3);
    }
    r0 = _f_4;
    WL_JMP(FID_CONSUMER_SHOW_REMOVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REMOVED_K181)
  {
    WL_POPN(3);
    Term _h_5 = STK(0);
    Term _h_6 = STK(1);
    Term _h_7 = STK(2);
    Term _h_3 = r0;
    Term _h_4 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_5;
      STK(1) = _h_6;
      STK(2) = _h_7;
      STK(3) = _h_3;
      STK(4) = FID_CONSUMER_SHOW_REMOVED_K182;
      WL_PUSHN(5);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SHOW_REMOVED_K182, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_5;
      e.mem[_t_4 + 1] = _h_6;
      e.mem[_t_4 + 2] = _h_7;
      e.mem[_t_4 + 3] = _h_3;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_REMOVED_K182, _t_4);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 34);
      e.mem[_t_5 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 34);
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REMOVED_K182)
  {
    WL_POPN(4);
    Term _h_9 = STK(0);
    Term _h_10 = STK(1);
    Term _h_11 = STK(2);
    Term _h_12 = STK(3);
    Term _h_8 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_9;
      STK(1) = _h_10;
      STK(2) = _h_12;
      STK(3) = FID_CONSUMER_SHOW_REMOVED_K183;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_SHOW_REMOVED_K183, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_9;
      e.mem[_t_6 + 1] = _h_10;
      e.mem[_t_6 + 2] = _h_12;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_REMOVED_K183, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_11;
      e.mem[_t_7 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_11;
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_REMOVED_K183)
  {
    WL_POPN(3);
    Term _h_14 = STK(0);
    Term _h_15 = STK(1);
    Term _h_16 = STK(2);
    Term _h_13 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_14);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_15);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_PAYLOAD, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_16);
    r0 = term_ctr(CID_CON, _nd_1);
    r1 = _h_13;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_4)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_4_K188;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_4_K188, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_4_K188, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_INVERSE_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_INVERSE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _f_5;
        e.mem[_t_1 + 4] = _f_6;
        e.mem[_t_1 + 5] = _f_7;
        return term_tsk(FID_CONSUMER_SHOW_INVERSE_0, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _f_5;
      r4 = _f_6;
      r5 = _f_7;
      WL_JMP(FID_CONSUMER_SHOW_INVERSE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_4_K188)
  {
    WL_POPN(1);
    Term _f_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_4_K189;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_4_K189, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_4_K189, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_5)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_5, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_8;
      return term_tsk(FID_LIST_SHOW_GO_5, _t_3);
    }
    r0 = _f_8;
    WL_JMP(FID_LIST_SHOW_GO_5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_4_K189)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_4_K190;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_4_K190, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_4_K190, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_4_K190)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_3)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      u32 _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_3_K192;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_3_K192, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_3_K192, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_EDGE_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_EDGE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _f_5;
        e.mem[_t_1 + 4] = _f_6;
        e.mem[_t_1 + 5] = _f_7;
        return term_tsk(FID_CONSUMER_SHOW_EDGE_0, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _f_5;
      r4 = _f_6;
      r5 = _f_7;
      WL_JMP(FID_CONSUMER_SHOW_EDGE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_3_K192)
  {
    WL_POPN(1);
    Term _f_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_3_K193;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_3_K193, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_3_K193, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_3)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_3, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_8;
      return term_tsk(FID_LIST_SHOW_GO_3, _t_3);
    }
    r0 = _f_8;
    WL_JMP(FID_LIST_SHOW_GO_3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_3_K193)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_3_K194;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_3_K194, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_3_K194, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_3_K194)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_NUMBER)
  {
    u32 _value_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_0;
      STK(1) = FID_CONSUMER_NUMBER_K201;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_NUMBER_K201, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_0;
      WL_CONT = term_tsk(FID_CONSUMER_NUMBER_K201, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_NUMBER_K201)
  {
    WL_POPN(1);
    u32 _value_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    r0 = _value_1;
    r1 = _h_0;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2)
  {
    Term _value_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_value_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _value_0), 0 + 0);
      blk_free(e, _value_0);
      u32 _v_0 = 0;
      Term _v_1 = 0;
      u32 _v_2 = 0;
      Term _v_3 = 0;
      Term _o_1[2];
      if (spin_22(e, _o_1, _c_0) == 0) {
        return 0;
      }
      _v_2 = _o_1[0];
      _v_3 = _o_1[1];
      _v_0 = _v_2;
      _v_1 = _v_3;
      if (seq) {
        WL_ROOM(2);
        STK(0) = _v_0;
        STK(1) = FID_CONSUMER_TREE_2_K206;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_TREE_2_K206, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _v_0;
        WL_CONT = term_tsk(FID_CONSUMER_TREE_2_K206, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_1;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 6);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _v_1;
      r1 = term_ctr(CID_SCON, STAT_OFF + 6);
      WL_JMP(FID_STRING_APPEND);
    } else {
      Term _h_2 = blk_half(e, _value_0, 0);
      Term _h_3 = blk_half(e, _value_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_2;
        STK(1) = FID_CONSUMER_TREE_2_K208;
        WL_PUSHN(2);
      } else {
        u64 _t_4 = task_node(e, FID_CONSUMER_TREE_2_K208, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _h_2;
        WL_CONT = term_tsk(FID_CONSUMER_TREE_2_K208, _t_4);
        WL_IDX = 1;
      }
      r0 = _h_3;
      _value_0 = r0;
      WL_AGAIN(FID_CONSUMER_TREE_2);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2_K206)
  {
    WL_POPN(1);
    u32 _v_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _v_8;
      STK(1) = FID_CONSUMER_TREE_2_K207;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_TREE_2_K207, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _v_8;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_2_K207, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 106);
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 106);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2_K207)
  {
    WL_POPN(1);
    u32 _v_9 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _v_9;
    r0 = blk_new(e, 0, 0, 0, 1, _fv_0);
    r1 = _h_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2_K208)
  {
    WL_POPN(1);
    Term _h_6 = STK(0);
    Term _h_4 = r0;
    Term _h_5 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_CONSUMER_TREE_2_K209;
      WL_PUSHN(3);
    } else {
      u64 _t_5 = task_node(e, FID_CONSUMER_TREE_2_K209, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _h_4;
      e.mem[_t_5 + 1] = _h_5;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_2_K209, _t_5);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_TREE_2)) {
      u64 _t_6 = task_node(e, FID_CONSUMER_TREE_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_6;
      return term_tsk(FID_CONSUMER_TREE_2, _t_6);
    }
    r0 = _h_6;
    WL_JMP(FID_CONSUMER_TREE_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2_K209)
  {
    WL_POPN(2);
    Term _h_9 = STK(0);
    Term _h_10 = STK(1);
    Term _h_7 = r0;
    Term _h_8 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_7;
      STK(1) = _h_8;
      STK(2) = _h_9;
      STK(3) = FID_CONSUMER_TREE_2_K210;
      WL_PUSHN(4);
    } else {
      u64 _t_7 = task_node(e, FID_CONSUMER_TREE_2_K210, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_7;
      e.mem[_t_7 + 1] = _h_8;
      e.mem[_t_7 + 2] = _h_9;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_2_K210, _t_7);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_10;
      e.mem[_t_8 + 1] = term_ctr(CID_SCON, STAT_OFF + 6);
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _h_10;
    r1 = term_ctr(CID_SCON, STAT_OFF + 6);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2_K210)
  {
    WL_POPN(3);
    Term _h_12 = STK(0);
    Term _h_13 = STK(1);
    Term _h_14 = STK(2);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_12;
      STK(1) = _h_13;
      STK(2) = _h_14;
      STK(3) = FID_CONSUMER_TREE_2_K211;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_CONSUMER_TREE_2_K211, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_12;
      e.mem[_t_9 + 1] = _h_13;
      e.mem[_t_9 + 2] = _h_14;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_2_K211, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_10 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2_K211)
  {
    WL_POPN(3);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_16;
      STK(1) = _h_18;
      STK(2) = FID_CONSUMER_TREE_2_K212;
      WL_PUSHN(3);
    } else {
      u64 _t_11 = task_node(e, FID_CONSUMER_TREE_2_K212, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_16;
      e.mem[_t_11 + 1] = _h_18;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_2_K212, _t_11);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_17;
      e.mem[_t_12 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _h_17;
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2_K212)
  {
    WL_POPN(2);
    Term _h_20 = STK(0);
    Term _h_21 = STK(1);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_20;
      STK(1) = _h_21;
      STK(2) = FID_CONSUMER_TREE_2_K213;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_CONSUMER_TREE_2_K213, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_20;
      e.mem[_t_13 + 1] = _h_21;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_2_K213, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 36);
      e.mem[_t_14 + 1] = _h_19;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 36);
    r1 = _h_19;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_2_K213)
  {
    WL_POPN(2);
    Term _h_23 = STK(0);
    Term _h_24 = STK(1);
    Term _h_22 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_23, _h_24);
    r1 = _h_22;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0)
  {
    Term _graph_0 = r0;
    Term _graph_1 = r1;
    u32 _descriptor_0 = r2;
    Term _descriptor_1 = r3;
    Term _descriptor_2 = r4;
    u32 _descriptor_3 = r5;
    u32 _source_0 = r6;
    u32 _target_0 = r7;
    u32 _sourceLive_0 = r8;
    u32 _targetLive_0 = r9;
    WL_OPEN
    _graph_0 = term_keep(e, _graph_0, 1);
    _graph_1 = term_keep(e, _graph_1, 1);
    _descriptor_1 = term_keep(e, _descriptor_1, 1);
    _descriptor_2 = term_keep(e, _descriptor_2, 1);
    if (seq) {
      WL_ROOM(11);
      STK(0) = _graph_0;
      STK(1) = _graph_1;
      STK(2) = _descriptor_0;
      STK(3) = _descriptor_1;
      STK(4) = _descriptor_2;
      STK(5) = _descriptor_3;
      STK(6) = _source_0;
      STK(7) = _target_0;
      STK(8) = _sourceLive_0;
      STK(9) = _targetLive_0;
      STK(10) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K251;
      WL_PUSHN(11);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K251, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _graph_0;
      e.mem[_t_0 + 1] = _graph_1;
      e.mem[_t_0 + 2] = _descriptor_0;
      e.mem[_t_0 + 3] = _descriptor_1;
      e.mem[_t_0 + 4] = _descriptor_2;
      e.mem[_t_0 + 5] = _descriptor_3;
      e.mem[_t_0 + 6] = _source_0;
      e.mem[_t_0 + 7] = _target_0;
      e.mem[_t_0 + 8] = _sourceLive_0;
      e.mem[_t_0 + 9] = _targetLive_0;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K251, _t_0);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _graph_0;
      e.mem[_t_1 + 1] = _graph_1;
      e.mem[_t_1 + 2] = _descriptor_0;
      e.mem[_t_1 + 3] = _descriptor_1;
      e.mem[_t_1 + 4] = _descriptor_2;
      e.mem[_t_1 + 5] = _descriptor_3;
      e.mem[_t_1 + 6] = _source_0;
      e.mem[_t_1 + 7] = _target_0;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0, _t_1);
    }
    r0 = _graph_0;
    r1 = _graph_1;
    r2 = _descriptor_0;
    r3 = _descriptor_1;
    r4 = _descriptor_2;
    r5 = _descriptor_3;
    r6 = _source_0;
    r7 = _target_0;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_CYCLE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K251)
  {
    WL_POPN(10);
    Term _graph_2 = STK(0);
    Term _graph_3 = STK(1);
    u32 _descriptor_4 = STK(2);
    Term _descriptor_5 = STK(3);
    Term _descriptor_6 = STK(4);
    u32 _descriptor_7 = STK(5);
    u32 _source_1 = STK(6);
    u32 _target_1 = STK(7);
    u32 _sourceLive_1 = STK(8);
    u32 _targetLive_1 = STK(9);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    _descriptor_5 = term_keep(e, _descriptor_5, 1);
    _descriptor_6 = term_keep(e, _descriptor_6, 1);
    Term _v_6 = 0;
    Term _o_0[1];
    if (spin_23(e, _o_0, _descriptor_4, _descriptor_5, blk_loc(e.mem, _descriptor_5), _descriptor_6, blk_loc(e.mem, _descriptor_6), _descriptor_7) == 0) {
      return 0;
    }
    _v_6 = _o_0[0];
    _v_5 = _v_6;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _o_1[5];
    if (spin_24(e, _o_1, _sourceLive_1, _targetLive_1, U32_BIN(_source_1, ==, _target_1), _h_0, _source_1, _target_1, _v_5, blk_loc(e.mem, _v_5)) == 0) {
      return 0;
    }
    _v_8 = _o_1[0];
    _v_9 = _o_1[1];
    _v_10 = _o_1[2];
    _v_11 = _o_1[3];
    _v_12 = _o_1[4];
    _v_0 = _v_8;
    _v_1 = _v_9;
    _v_2 = _v_10;
    _v_3 = _v_11;
    _v_4 = _v_12;
    if (_v_0 == 1) {
      term_sink(e, _descriptor_5);
      term_sink(e, _descriptor_6);
      r0 = _graph_2;
      r1 = _graph_3;
      r2 = 1;
      r3 = _v_1;
      r4 = _v_2;
      r5 = _v_3;
      r6 = _v_4;
      WL_RETN(7);
    } else {
      _graph_2 = term_keep(e, _graph_2, 1);
      _descriptor_5 = term_keep(e, _descriptor_5, 1);
      _descriptor_6 = term_keep(e, _descriptor_6, 1);
      if (seq) {
        WL_ROOM(9);
        STK(0) = _graph_2;
        STK(1) = _graph_3;
        STK(2) = _descriptor_4;
        STK(3) = _descriptor_5;
        STK(4) = _descriptor_6;
        STK(5) = _descriptor_7;
        STK(6) = _source_1;
        STK(7) = _target_1;
        STK(8) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K252;
        WL_PUSHN(9);
      } else {
        u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K252, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _graph_2;
        e.mem[_t_2 + 1] = _graph_3;
        e.mem[_t_2 + 2] = _descriptor_4;
        e.mem[_t_2 + 3] = _descriptor_5;
        e.mem[_t_2 + 4] = _descriptor_6;
        e.mem[_t_2 + 5] = _descriptor_7;
        e.mem[_t_2 + 6] = _source_1;
        e.mem[_t_2 + 7] = _target_1;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K252, _t_2);
        WL_IDX = 8;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0)) {
        u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _graph_2;
        e.mem[_t_3 + 1] = _descriptor_4;
        e.mem[_t_3 + 2] = _descriptor_5;
        e.mem[_t_3 + 3] = _descriptor_6;
        e.mem[_t_3 + 4] = _descriptor_7;
        e.mem[_t_3 + 5] = _source_1;
        return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, _t_3);
      }
      r0 = _graph_2;
      r1 = _descriptor_4;
      r2 = _descriptor_5;
      r3 = _descriptor_6;
      r4 = _descriptor_7;
      r5 = _source_1;
      WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K252)
  {
    WL_POPN(8);
    Term _graph_4 = STK(0);
    Term _graph_5 = STK(1);
    u32 _descriptor_12 = STK(2);
    Term _descriptor_13 = STK(3);
    Term _descriptor_14 = STK(4);
    u32 _descriptor_15 = STK(5);
    u32 _source_3 = STK(6);
    u32 _target_3 = STK(7);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    WL_OPEN
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _o_2[1];
    if (spin_19(e, _o_2, _h_1, _h_2, _target_3) == 0) {
      return 0;
    }
    _v_19 = _o_2[0];
    _v_18 = _v_19;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K253;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K253, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K253, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0)) {
      u64 _t_5 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _v_18;
      e.mem[_t_5 + 1] = _graph_4;
      e.mem[_t_5 + 2] = _graph_5;
      e.mem[_t_5 + 3] = _descriptor_12;
      e.mem[_t_5 + 4] = _descriptor_13;
      e.mem[_t_5 + 5] = _descriptor_14;
      e.mem[_t_5 + 6] = _descriptor_15;
      e.mem[_t_5 + 7] = _source_3;
      e.mem[_t_5 + 8] = _target_3;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0, _t_5);
    }
    r0 = _v_18;
    r1 = _graph_4;
    r2 = _graph_5;
    r3 = _descriptor_12;
    r4 = _descriptor_13;
    r5 = _descriptor_14;
    r6 = _descriptor_15;
    r7 = _source_3;
    r8 = _target_3;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UPDATED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0_K253)
  {
    Term _h_3 = r0;
    Term _h_4 = r1;
    WL_OPEN
    r0 = _h_3;
    r1 = _h_4;
    r2 = 0;
    r3 = 0;
    r4 = 0;
    r5 = 0;
    r6 = 0;
    WL_RETN(7);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = _ys_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_APPEND_K260;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_APPEND_K260, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_APPEND_K260, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _ys_0;
      _xs_0 = r0;
      _ys_0 = r1;
      WL_AGAIN(FID_LIST_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND_K260)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0)
  {
    Term _edges_0 = r0;
    u32 _descriptor_0 = r1;
    Term _descriptor_1 = r2;
    Term _descriptor_2 = r3;
    u32 _descriptor_3 = r4;
    u32 _source_0 = r5;
    WL_OPEN
    if (term_aux(_edges_0) == CID_NIL) {
      term_sink(e, _descriptor_1);
      term_sink(e, _descriptor_2);
      r0 = 0;
      r1 = 0;
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _edges_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      u32 _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _o_0[1];
      if (spin_2(e, _o_0, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_5) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      term_sink(e, _f_3);
      term_sink(e, _f_4);
      _v_1 = _v_2;
      u32 _v_3 = 0;
      u32 _v_4 = 0;
      Term _o_1[1];
      if (spin_2(e, _o_1, _descriptor_0, _descriptor_1, blk_loc(e.mem, _descriptor_1), _descriptor_2, blk_loc(e.mem, _descriptor_2), _descriptor_3) == 0) {
        return 0;
      }
      _v_4 = _o_1[0];
      _v_3 = _v_4;
      u32 _v_5 = 0;
      Term _o_2[1];
      if (spin_3(e, _o_2, U32_BIN(_v_1, ==, _v_3), U32_BIN(_f_6, ==, _source_0)) == 0) {
        return 0;
      }
      _v_5 = _o_2[0];
      _v_0 = _v_5;
      u64 _nd_0 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_0 + 0] = _f_1;
      e.mem[_nd_0 + 1] = _descriptor_0;
      e.mem[_nd_0 + 2] = _descriptor_1;
      e.mem[_nd_0 + 3] = _descriptor_2;
      e.mem[_nd_0 + 4] = _descriptor_3;
      e.mem[_nd_0 + 5] = _source_0;
      if (_v_0 == 1) {
        Term _next_0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_C263, _nd_0);
        term_sink(e, _next_0);
        spare_free(e, cls_fit(2), _sp_0);
        r0 = 1;
        r1 = _f_7;
        WL_RETN(2);
      } else {
        Term _next_1 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_C263, _nd_0);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K265;
          WL_PUSHN(1);
        } else {
          u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K265, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K265, _t_2);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _next_1;
          e.mem[_t_3 + 1] = term_pak(CID_UNIT, 0);
          return term_tsk(FID_CLO_APPLY, _t_3);
        }
        r0 = _next_1;
        r1 = term_pak(CID_UNIT, 0);
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_C263)
  {
    Term _f_8 = r0;
    u32 _descriptor_4 = r1;
    Term _descriptor_5 = r2;
    Term _descriptor_6 = r3;
    u32 _descriptor_7 = r4;
    u32 _source_1 = r5;
    Term _x_0 = r6;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K264;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K264, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K264, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_8;
      e.mem[_t_1 + 1] = _descriptor_4;
      e.mem[_t_1 + 2] = _descriptor_5;
      e.mem[_t_1 + 3] = _descriptor_6;
      e.mem[_t_1 + 4] = _descriptor_7;
      e.mem[_t_1 + 5] = _source_1;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, _t_1);
    }
    r0 = _f_8;
    r1 = _descriptor_4;
    r2 = _descriptor_5;
    r3 = _descriptor_6;
    r4 = _descriptor_7;
    r5 = _source_1;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K264)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      _b_0 = term_pak(CID_NONE, 0);
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_1 + 0] = rfc_seal(e, _r_1);
      _b_0 = term_ctr(CID_SOME, _nd_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0_K265)
  {
    Term _r_2 = r0;
    WL_OPEN
    u32 _o_3 = 0;
    u32 _o_4 = 0;
    if (term_aux(_r_2) == CID_NONE) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      Term _fb_2[1];
      u64 _sp_2 = ctr_take(e, _r_2, 1, _fb_2);
      Term _f_9 = _fb_2[0];
      spare_free(e, cls_fit(1), _sp_2);
      _o_4 = _f_9;
    }
    r0 = _o_3;
    r1 = _o_4;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0)
  {
    u32 _previous_0 = r0;
    u32 _previous_1 = r1;
    Term _entries_0 = r2;
    u32 _descriptor_0 = r3;
    Term _descriptor_1 = r4;
    Term _descriptor_2 = r5;
    u32 _descriptor_3 = r6;
    u32 _source_0 = r7;
    WL_OPEN
    if (_previous_0 == 0) {
      r0 = _entries_0;
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0)) {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _entries_0;
        e.mem[_t_0 + 1] = _descriptor_0;
        e.mem[_t_0 + 2] = _descriptor_1;
        e.mem[_t_0 + 3] = _descriptor_2;
        e.mem[_t_0 + 4] = _descriptor_3;
        e.mem[_t_0 + 5] = _previous_1;
        e.mem[_t_0 + 6] = _source_0;
        e.mem[_t_0 + 7] = term_pak(CID_NIL, 0);
        return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0, _t_0);
      }
      r0 = _entries_0;
      r1 = _descriptor_0;
      r2 = _descriptor_1;
      r3 = _descriptor_2;
      r4 = _descriptor_3;
      r5 = _previous_1;
      r6 = _source_0;
      r7 = term_pak(CID_NIL, 0);
      WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_REMOVE_ACC_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0)
  {
    Term _entries_0 = r0;
    u32 _descriptor_0 = r1;
    Term _descriptor_1 = r2;
    Term _descriptor_2 = r3;
    u32 _descriptor_3 = r4;
    u32 _target_0 = r5;
    WL_OPEN
    if (term_aux(_entries_0) == CID_NIL) {
      term_sink(e, _descriptor_1);
      term_sink(e, _descriptor_2);
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _entries_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _o_0[1];
      if (spin_2(e, _o_0, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_5) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      term_sink(e, _f_3);
      term_sink(e, _f_4);
      _v_1 = _v_2;
      u32 _v_3 = 0;
      u32 _v_4 = 0;
      Term _o_1[1];
      if (spin_2(e, _o_1, _descriptor_0, _descriptor_1, blk_loc(e.mem, _descriptor_1), _descriptor_2, blk_loc(e.mem, _descriptor_2), _descriptor_3) == 0) {
        return 0;
      }
      _v_4 = _o_1[0];
      _v_3 = _v_4;
      u32 _v_5 = 0;
      Term _o_2[1];
      if (spin_3(e, _o_2, U32_BIN(_v_1, ==, _v_3), U32_BIN(_f_6, ==, _target_0)) == 0) {
        return 0;
      }
      _v_5 = _o_2[0];
      _v_0 = _v_5;
      u64 _nd_0 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_0 + 0] = _f_1;
      e.mem[_nd_0 + 1] = _descriptor_0;
      e.mem[_nd_0 + 2] = _descriptor_1;
      e.mem[_nd_0 + 3] = _descriptor_2;
      e.mem[_nd_0 + 4] = _descriptor_3;
      e.mem[_nd_0 + 5] = _target_0;
      if (_v_0 == 1) {
        Term _next_0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0_C269, _nd_0);
        term_sink(e, _next_0);
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _f_7;
        WL_RETN(1);
      } else {
        term_sink(e, _f_7);
        Term _next_1 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0_C269, _nd_0);
        spare_free(e, cls_fit(2), _sp_0);
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _next_1;
          e.mem[_t_1 + 1] = term_pak(CID_UNIT, 0);
          return term_tsk(FID_CLO_APPLY, _t_1);
        }
        r0 = _next_1;
        r1 = term_pak(CID_UNIT, 0);
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0_C269)
  {
    Term _f_8 = r0;
    u32 _descriptor_4 = r1;
    Term _descriptor_5 = r2;
    Term _descriptor_6 = r3;
    u32 _descriptor_7 = r4;
    u32 _target_1 = r5;
    Term _x_0 = r6;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0)) {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _f_8;
      e.mem[_t_0 + 1] = _descriptor_4;
      e.mem[_t_0 + 2] = _descriptor_5;
      e.mem[_t_0 + 3] = _descriptor_6;
      e.mem[_t_0 + 4] = _descriptor_7;
      e.mem[_t_0 + 5] = _target_1;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0, _t_0);
    }
    r0 = _f_8;
    r1 = _descriptor_4;
    r2 = _descriptor_5;
    r3 = _descriptor_6;
    r4 = _descriptor_7;
    r5 = _target_1;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_4)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_4_K272;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_4_K272, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_4_K272, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_4_K272)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_4_K273;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_4_K273, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_4_K273, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_4)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_4, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      return term_tsk(FID_LIST_SHOW_GO_4, _t_3);
    }
    r0 = _f_2;
    WL_JMP(FID_LIST_SHOW_GO_4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_4_K273)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_4_K274;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_4_K274, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_4_K274, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_4_K274)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_6)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[4];
      u64 _sp_1 = ctr_take(e, _f_0, 4, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      spare_free(e, cls_fit(4), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_6_K277;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_6_K277, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_6_K277, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_DESCRIPTOR_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _f_5;
        return term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _f_5;
      WL_JMP(FID_CONSUMER_SHOW_DESCRIPTOR_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_6_K277)
  {
    WL_POPN(1);
    Term _f_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_6_K278;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_6_K278, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_6_K278, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_6)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_6, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_6;
      return term_tsk(FID_LIST_SHOW_GO_6, _t_3);
    }
    r0 = _f_6;
    WL_JMP(FID_LIST_SHOW_GO_6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_6_K278)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_6_K279;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_6_K279, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_6_K279, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_6_K279)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1)
  {
    Term _value_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_value_0) == 1) {
      u32 _c_0 = blk_read(e.mem, 1, blk_loc(e.mem, _value_0), 0 + 0);
      Term _c_1 = blk_shr(_value_0) ? blk_keep(e, blk_loc(e.mem, _value_0) + 0 + 1) : e.mem[blk_loc(e.mem, _value_0) + 0 + 1];
      blk_free(e, _value_0);
      u32 _o_0 = 0;
      Term _o_1 = 0;
      Term _o_2 = 0;
      if (_c_0 == 0) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _c_1, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        spare_free(e, cls_fit(2), _sp_0);
        _o_1 = _f_0;
        _o_2 = _f_1;
      }
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_TREE_1_K282;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_TREE_1_K282, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K282, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_SLOT)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_SLOT, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        return term_tsk(FID_CONSUMER_SHOW_SLOT, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      WL_JMP(FID_CONSUMER_SHOW_SLOT);
    } else {
      Term _h_12 = blk_half(e, _value_0, 0);
      Term _h_13 = blk_half(e, _value_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_12;
        STK(1) = FID_CONSUMER_TREE_1_K285;
        WL_PUSHN(2);
      } else {
        u64 _t_6 = task_node(e, FID_CONSUMER_TREE_1_K285, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _h_12;
        WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K285, _t_6);
        WL_IDX = 1;
      }
      r0 = _h_13;
      _value_0 = r0;
      WL_AGAIN(FID_CONSUMER_TREE_1);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K282)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = FID_CONSUMER_TREE_1_K283;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_TREE_1_K283, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K283, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_3;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 6);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_3;
    r1 = term_ctr(CID_SCON, STAT_OFF + 6);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K283)
  {
    WL_POPN(3);
    u32 _h_5 = STK(0);
    Term _h_6 = STK(1);
    Term _h_7 = STK(2);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_5;
      STK(1) = _h_6;
      STK(2) = _h_7;
      STK(3) = FID_CONSUMER_TREE_1_K284;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_TREE_1_K284, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_5;
      e.mem[_t_4 + 1] = _h_6;
      e.mem[_t_4 + 2] = _h_7;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K284, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 106);
      e.mem[_t_5 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 106);
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K284)
  {
    WL_POPN(3);
    u32 _h_9 = STK(0);
    Term _h_10 = STK(1);
    Term _h_11 = STK(2);
    Term _h_8 = r0;
    WL_OPEN
    u32 _o_3 = 0;
    Term _o_4 = 0;
    if (_h_9 == 0) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _h_10);
      e.mem[_nd_0 + 1] = rfc_seal(e, _h_11);
      _o_4 = term_ctr(CID_CONSUMER_PAYLOAD, _nd_0);
    }
    Term _fv_0[2];
    _fv_0[0] = _o_3;
    _fv_0[1] = _o_4;
    r0 = blk_new(e, 1, 0, 1, 2, _fv_0);
    r1 = _h_8;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K285)
  {
    WL_POPN(1);
    Term _h_16 = STK(0);
    Term _h_14 = r0;
    Term _h_15 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_14;
      STK(1) = _h_15;
      STK(2) = FID_CONSUMER_TREE_1_K286;
      WL_PUSHN(3);
    } else {
      u64 _t_7 = task_node(e, FID_CONSUMER_TREE_1_K286, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_14;
      e.mem[_t_7 + 1] = _h_15;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K286, _t_7);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_TREE_1)) {
      u64 _t_8 = task_node(e, FID_CONSUMER_TREE_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_16;
      return term_tsk(FID_CONSUMER_TREE_1, _t_8);
    }
    r0 = _h_16;
    WL_JMP(FID_CONSUMER_TREE_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K286)
  {
    WL_POPN(2);
    Term _h_19 = STK(0);
    Term _h_20 = STK(1);
    Term _h_17 = r0;
    Term _h_18 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_17;
      STK(1) = _h_18;
      STK(2) = _h_19;
      STK(3) = FID_CONSUMER_TREE_1_K287;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_CONSUMER_TREE_1_K287, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_17;
      e.mem[_t_9 + 1] = _h_18;
      e.mem[_t_9 + 2] = _h_19;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K287, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_20;
      e.mem[_t_10 + 1] = term_ctr(CID_SCON, STAT_OFF + 6);
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_20;
    r1 = term_ctr(CID_SCON, STAT_OFF + 6);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K287)
  {
    WL_POPN(3);
    Term _h_22 = STK(0);
    Term _h_23 = STK(1);
    Term _h_24 = STK(2);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_22;
      STK(1) = _h_23;
      STK(2) = _h_24;
      STK(3) = FID_CONSUMER_TREE_1_K288;
      WL_PUSHN(4);
    } else {
      u64 _t_11 = task_node(e, FID_CONSUMER_TREE_1_K288, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_22;
      e.mem[_t_11 + 1] = _h_23;
      e.mem[_t_11 + 2] = _h_24;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K288, _t_11);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_12 + 1] = _h_21;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_21;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K288)
  {
    WL_POPN(3);
    Term _h_26 = STK(0);
    Term _h_27 = STK(1);
    Term _h_28 = STK(2);
    Term _h_25 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_26;
      STK(1) = _h_28;
      STK(2) = FID_CONSUMER_TREE_1_K289;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_CONSUMER_TREE_1_K289, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_26;
      e.mem[_t_13 + 1] = _h_28;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K289, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_27;
      e.mem[_t_14 + 1] = _h_25;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = _h_27;
    r1 = _h_25;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K289)
  {
    WL_POPN(2);
    Term _h_30 = STK(0);
    Term _h_31 = STK(1);
    Term _h_29 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_30;
      STK(1) = _h_31;
      STK(2) = FID_CONSUMER_TREE_1_K290;
      WL_PUSHN(3);
    } else {
      u64 _t_15 = task_node(e, FID_CONSUMER_TREE_1_K290, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _h_30;
      e.mem[_t_15 + 1] = _h_31;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_1_K290, _t_15);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 36);
      e.mem[_t_16 + 1] = _h_29;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 36);
    r1 = _h_29;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_1_K290)
  {
    WL_POPN(2);
    Term _h_33 = STK(0);
    Term _h_34 = STK(1);
    Term _h_32 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_33, _h_34);
    r1 = _h_32;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_GRAPH_0)
  {
    Term _graph_0 = r0;
    Term _graph_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _graph_1;
      STK(1) = FID_CONSUMER_SHOW_GRAPH_0_K296;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_GRAPH_0_K296, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _graph_1;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_GRAPH_0_K296, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_3)) {
      u64 _t_1 = task_node(e, FID_LIST_SHOW_3, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _graph_0;
      return term_tsk(FID_LIST_SHOW_3, _t_1);
    }
    r0 = _graph_0;
    WL_JMP(FID_LIST_SHOW_3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_GRAPH_0_K296)
  {
    WL_POPN(1);
    Term _graph_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_CONSUMER_SHOW_GRAPH_0_K297;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_SHOW_GRAPH_0_K297, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_GRAPH_0_K297, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_4)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_4, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _graph_2;
      return term_tsk(FID_LIST_SHOW_4, _t_3);
    }
    r0 = _graph_2;
    WL_JMP(FID_LIST_SHOW_4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_GRAPH_0_K297)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_CONSUMER_SHOW_GRAPH_0_K298;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SHOW_GRAPH_0_K298, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_GRAPH_0_K298, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 228);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 228);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_GRAPH_0_K298)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0)
  {
    Term _value_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_value_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _value_0), 0 + 0);
      blk_free(e, _value_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_TREE_0_K300;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_TREE_0_K300, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K300, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_NUMBER)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_NUMBER, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _c_0;
        return term_tsk(FID_CONSUMER_NUMBER, _t_1);
      }
      r0 = _c_0;
      WL_JMP(FID_CONSUMER_NUMBER);
    } else {
      Term _h_6 = blk_half(e, _value_0, 0);
      Term _h_7 = blk_half(e, _value_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_6;
        STK(1) = FID_CONSUMER_TREE_0_K303;
        WL_PUSHN(2);
      } else {
        u64 _t_6 = task_node(e, FID_CONSUMER_TREE_0_K303, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _h_6;
        WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K303, _t_6);
        WL_IDX = 1;
      }
      r0 = _h_7;
      _value_0 = r0;
      WL_AGAIN(FID_CONSUMER_TREE_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K300)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_CONSUMER_TREE_0_K301;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_TREE_0_K301, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K301, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_1;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 6);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_SCON, STAT_OFF + 6);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K301)
  {
    WL_POPN(1);
    u32 _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_3;
      STK(1) = FID_CONSUMER_TREE_0_K302;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_TREE_0_K302, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_3;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K302, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 106);
      e.mem[_t_5 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 106);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K302)
  {
    WL_POPN(1);
    u32 _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _h_5;
    r0 = blk_new(e, 0, 0, 0, 1, _fv_0);
    r1 = _h_4;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K303)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_8 = r0;
    Term _h_9 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_8;
      STK(1) = _h_9;
      STK(2) = FID_CONSUMER_TREE_0_K304;
      WL_PUSHN(3);
    } else {
      u64 _t_7 = task_node(e, FID_CONSUMER_TREE_0_K304, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_8;
      e.mem[_t_7 + 1] = _h_9;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K304, _t_7);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_TREE_0)) {
      u64 _t_8 = task_node(e, FID_CONSUMER_TREE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_10;
      return term_tsk(FID_CONSUMER_TREE_0, _t_8);
    }
    r0 = _h_10;
    WL_JMP(FID_CONSUMER_TREE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K304)
  {
    WL_POPN(2);
    Term _h_13 = STK(0);
    Term _h_14 = STK(1);
    Term _h_11 = r0;
    Term _h_12 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_13;
      STK(3) = FID_CONSUMER_TREE_0_K305;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_CONSUMER_TREE_0_K305, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_11;
      e.mem[_t_9 + 1] = _h_12;
      e.mem[_t_9 + 2] = _h_13;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K305, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_14;
      e.mem[_t_10 + 1] = term_ctr(CID_SCON, STAT_OFF + 6);
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_14;
    r1 = term_ctr(CID_SCON, STAT_OFF + 6);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K305)
  {
    WL_POPN(3);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_16;
      STK(1) = _h_17;
      STK(2) = _h_18;
      STK(3) = FID_CONSUMER_TREE_0_K306;
      WL_PUSHN(4);
    } else {
      u64 _t_11 = task_node(e, FID_CONSUMER_TREE_0_K306, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_16;
      e.mem[_t_11 + 1] = _h_17;
      e.mem[_t_11 + 2] = _h_18;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K306, _t_11);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_12 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K306)
  {
    WL_POPN(3);
    Term _h_20 = STK(0);
    Term _h_21 = STK(1);
    Term _h_22 = STK(2);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_20;
      STK(1) = _h_22;
      STK(2) = FID_CONSUMER_TREE_0_K307;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_CONSUMER_TREE_0_K307, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_20;
      e.mem[_t_13 + 1] = _h_22;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K307, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_21;
      e.mem[_t_14 + 1] = _h_19;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = _h_21;
    r1 = _h_19;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K307)
  {
    WL_POPN(2);
    Term _h_24 = STK(0);
    Term _h_25 = STK(1);
    Term _h_23 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_24;
      STK(1) = _h_25;
      STK(2) = FID_CONSUMER_TREE_0_K308;
      WL_PUSHN(3);
    } else {
      u64 _t_15 = task_node(e, FID_CONSUMER_TREE_0_K308, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _h_24;
      e.mem[_t_15 + 1] = _h_25;
      WL_CONT = term_tsk(FID_CONSUMER_TREE_0_K308, _t_15);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 36);
      e.mem[_t_16 + 1] = _h_23;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 36);
    r1 = _h_23;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_TREE_0_K308)
  {
    WL_POPN(2);
    Term _h_27 = STK(0);
    Term _h_28 = STK(1);
    Term _h_26 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_27, _h_28);
    r1 = _h_26;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0)
  {
    Term _commands_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    Term _world_8 = r9;
    Term _world_9 = r10;
    Term _world_10 = r11;
    Term _world_11 = r12;
    Term _world_12 = r13;
    Term _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    WL_OPEN
    WL_SPIN
    if (term_aux(_commands_0) == CID_NIL) {
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = _world_13;
      r14 = _world_14;
      r15 = _world_15;
      WL_RETN(16);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K348;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K348, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K348, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _world_0;
      r2 = _world_1;
      r3 = _world_2;
      r4 = _world_3;
      r5 = _world_4;
      r6 = _world_5;
      r7 = _world_6;
      r8 = _world_7;
      r9 = _world_8;
      r10 = _world_9;
      r11 = _world_10;
      r12 = _world_11;
      r13 = _world_12;
      r14 = _world_13;
      r15 = _world_14;
      r16 = _world_15;
      _commands_0 = r0;
      _world_0 = r1;
      _world_1 = r2;
      _world_2 = r3;
      _world_3 = r4;
      _world_4 = r5;
      _world_5 = r6;
      _world_6 = r7;
      _world_7 = r8;
      _world_8 = r9;
      _world_9 = r10;
      _world_10 = r11;
      _world_11 = r12;
      _world_12 = r13;
      _world_13 = r14;
      _world_14 = r15;
      _world_15 = r16;
      WL_AGAIN(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K348)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_7);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_8);
    e.mem[_nd_1 + 2] = rfc_seal(e, _h_9);
    u64 _nd_2 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_2 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_2 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_2 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_2 + 5] = rfc_seal(e, _h_5);
    e.mem[_nd_2 + 6] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1));
    e.mem[_nd_2 + 7] = rfc_seal(e, _h_10);
    e.mem[_nd_2 + 8] = rfc_seal(e, _h_11);
    e.mem[_nd_2 + 9] = rfc_seal(e, _h_12);
    e.mem[_nd_2 + 10] = rfc_seal(e, _h_13);
    e.mem[_nd_2 + 11] = rfc_seal(e, _h_14);
    e.mem[_nd_2 + 12] = rfc_seal(e, _h_15);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K349;
      WL_PUSHN(1);
    } else {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K349, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K349, _t_1);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _f_2;
    r1 = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0_K349)
  {
    Term _r_0 = r0;
    WL_OPEN
    Term _fb_1[13];
    u64 _sp_1 = ctr_take(e, _r_0, 13, _fb_1);
    u32 _f_3 = _fb_1[0];
    u32 _f_4 = _fb_1[1];
    u32 _f_5 = _fb_1[2];
    Term _f_6 = _fb_1[3];
    u32 _f_7 = _fb_1[4];
    Term _f_8 = _fb_1[5];
    Term _f_9 = _fb_1[6];
    Term _f_10 = _fb_1[7];
    Term _f_11 = _fb_1[8];
    Term _f_12 = _fb_1[9];
    Term _f_13 = _fb_1[10];
    u32 _f_14 = _fb_1[11];
    u32 _f_15 = _fb_1[12];
    spare_free(e, cls_fit(13), _sp_1);
    Term _fb_2[3];
    u64 _sp_2 = ctr_take(e, _f_9, 3, _fb_2);
    Term _f_16 = _fb_2[0];
    Term _f_17 = _fb_2[1];
    Term _f_18 = _fb_2[2];
    spare_free(e, cls_fit(3), _sp_2);
    Term _fb_3[2];
    u64 _sp_3 = ctr_take(e, _f_16, 2, _fb_3);
    Term _f_19 = _fb_3[0];
    Term _f_20 = _fb_3[1];
    spare_free(e, cls_fit(2), _sp_3);
    r0 = _f_3;
    r1 = _f_4;
    r2 = _f_5;
    r3 = _f_6;
    r4 = _f_7;
    r5 = _f_8;
    r6 = _f_19;
    r7 = _f_20;
    r8 = _f_17;
    r9 = _f_18;
    r10 = _f_10;
    r11 = _f_11;
    r12 = _f_12;
    r13 = _f_13;
    r14 = _f_14;
    r15 = _f_15;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4)
  {
    Term _effect_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    Term _world_8 = r9;
    Term _world_9 = r10;
    Term _world_10 = r11;
    Term _world_11 = r12;
    Term _world_12 = r13;
    Term _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _world_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, _world_7);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _world_8);
    e.mem[_nd_1 + 2] = rfc_seal(e, _world_9);
    if (seq) {
      WL_ROOM(13);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_10;
      STK(7) = _world_11;
      STK(8) = _world_12;
      STK(9) = _world_13;
      STK(10) = _world_14;
      STK(11) = _world_15;
      STK(12) = FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4_K354;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4_K354, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_10;
      e.mem[_t_0 + 7] = _world_11;
      e.mem[_t_0 + 8] = _world_12;
      e.mem[_t_0 + 9] = _world_13;
      e.mem[_t_0 + 10] = _world_14;
      e.mem[_t_0 + 11] = _world_15;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4_K354, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _effect_0;
      e.mem[_t_1 + 1] = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _effect_0;
    r1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4_K354)
  {
    WL_POPN(12);
    u32 _world_16 = STK(0);
    u32 _world_17 = STK(1);
    u32 _world_18 = STK(2);
    Term _world_19 = STK(3);
    u32 _world_20 = STK(4);
    Term _world_21 = STK(5);
    Term _world_22 = STK(6);
    Term _world_23 = STK(7);
    Term _world_24 = STK(8);
    Term _world_25 = STK(9);
    u32 _world_26 = STK(10);
    u32 _world_27 = STK(11);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[3];
    u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
    Term _f_2 = _fb_1[0];
    Term _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_1);
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _f_2, 2, _fb_2);
    Term _f_5 = _fb_2[0];
    Term _f_6 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    u32 _o_0 = 0;
    u32 _o_1 = 0;
    u32 _o_2 = 0;
    Term _o_3 = 0;
    Term _o_4 = 0;
    if (term_aux(_f_1) == CID_NONE) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      Term _fb_3[1];
      u64 _sp_3 = ctr_take(e, _f_1, 1, _fb_3);
      Term _f_7 = _fb_3[0];
      spare_free(e, cls_fit(1), _sp_3);
      u32 _o_5 = 0;
      u32 _o_6 = 0;
      Term _o_7 = 0;
      Term _o_8 = 0;
      if (term_aux(_f_7) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGENTITY) {
        _o_5 = 0;
        _o_6 = term_loc(_f_7);
      } else if (term_aux(_f_7) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGTARGETENTITY) {
        _o_5 = 1;
        Term _fb_4[3];
        u64 _sp_4 = ctr_take(e, _f_7, 3, _fb_4);
        u32 _f_8 = _fb_4[0];
        u32 _f_9 = _fb_4[1];
        Term _f_10 = _fb_4[2];
        spare_free(e, cls_fit(3), _sp_4);
        _o_6 = _f_8;
        _o_7 = _f_9;
        _o_8 = _f_10;
      } else if (term_aux(_f_7) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_SELFRELATIONNOTALLOWED) {
        _o_5 = 2;
        Term _fb_5[2];
        u64 _sp_5 = ctr_take(e, _f_7, 2, _fb_5);
        u32 _f_11 = _fb_5[0];
        Term _f_12 = _fb_5[1];
        spare_free(e, cls_fit(2), _sp_5);
        _o_6 = _f_11;
        _o_7 = _f_12;
      } else if (term_aux(_f_7) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_HIERARCHYCYCLE) {
        _o_5 = 3;
        Term _fb_6[3];
        u64 _sp_6 = ctr_take(e, _f_7, 3, _fb_6);
        u32 _f_13 = _fb_6[0];
        u32 _f_14 = _fb_6[1];
        Term _f_15 = _fb_6[2];
        spare_free(e, cls_fit(3), _sp_6);
        _o_6 = _f_13;
        _o_7 = _f_14;
        _o_8 = _f_15;
      } else if (term_aux(_f_7) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGCHILDENTITY) {
        _o_5 = 4;
        Term _fb_7[3];
        u64 _sp_7 = ctr_take(e, _f_7, 3, _fb_7);
        u32 _f_16 = _fb_7[0];
        u32 _f_17 = _fb_7[1];
        Term _f_18 = _fb_7[2];
        spare_free(e, cls_fit(3), _sp_7);
        _o_6 = _f_16;
        _o_7 = _f_17;
        _o_8 = _f_18;
      } else if (term_aux(_f_7) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_DUPLICATECHILD) {
        _o_5 = 5;
        Term _fb_8[3];
        u64 _sp_8 = ctr_take(e, _f_7, 3, _fb_8);
        u32 _f_19 = _fb_8[0];
        u32 _f_20 = _fb_8[1];
        Term _f_21 = _fb_8[2];
        spare_free(e, cls_fit(3), _sp_8);
        _o_6 = _f_19;
        _o_7 = _f_20;
        _o_8 = _f_21;
      } else if (term_aux(_f_7) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CHILDNOTRELATEDTOPARENT) {
        _o_5 = 6;
        Term _fb_9[3];
        u64 _sp_9 = ctr_take(e, _f_7, 3, _fb_9);
        u32 _f_22 = _fb_9[0];
        u32 _f_23 = _fb_9[1];
        Term _f_24 = _fb_9[2];
        spare_free(e, cls_fit(3), _sp_9);
        _o_6 = _f_22;
        _o_7 = _f_23;
        _o_8 = _f_24;
      } else {
        _o_5 = 7;
        Term _fb_10[2];
        u64 _sp_10 = ctr_take(e, _f_7, 2, _fb_10);
        u32 _f_25 = _fb_10[0];
        Term _f_26 = _fb_10[1];
        spare_free(e, cls_fit(2), _sp_10);
        _o_6 = _f_25;
        _o_7 = _f_26;
      }
      _o_1 = _o_5;
      _o_2 = _o_6;
      _o_3 = _o_7;
      _o_4 = _o_8;
    }
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _o_9[21];
    if (spin_28(e, _o_9, _f_5, blk_loc(e.mem, _f_5), _f_6, blk_loc(e.mem, _f_6), _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _o_0, _o_1, _o_2, _o_3, blk_loc(e.mem, _o_3), _o_4, blk_loc(e.mem, _o_4), _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, _world_21, _world_22, blk_loc(e.mem, _world_22), _world_23, blk_loc(e.mem, _world_23), _world_24, blk_loc(e.mem, _world_24), _world_25, blk_loc(e.mem, _world_25), _world_26, _world_27) == 0) {
      return 0;
    }
    _v_0 = _o_9[0];
    _v_1 = _o_9[1];
    _v_2 = _o_9[2];
    _v_3 = _o_9[3];
    _v_4 = _o_9[4];
    _v_5 = _o_9[5];
    _v_6 = _o_9[6];
    _v_7 = _o_9[7];
    _v_8 = _o_9[8];
    _v_9 = _o_9[9];
    _v_10 = _o_9[10];
    _v_11 = _o_9[11];
    _v_12 = _o_9[12];
    _v_13 = _o_9[13];
    _v_14 = _o_9[14];
    _v_15 = _o_9[15];
    _v_16 = _o_9[16];
    _v_17 = _o_9[17];
    _v_18 = _o_9[18];
    _v_19 = _o_9[19];
    _v_20 = _o_9[20];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    r19 = _v_19;
    r20 = _v_20;
    WL_RETN(21);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0)
  {
    Term _graph_0 = r0;
    Term _graph_1 = r1;
    u32 _descriptor_0 = r2;
    Term _descriptor_1 = r3;
    Term _descriptor_2 = r4;
    u32 _descriptor_3 = r5;
    u32 _source_0 = r6;
    WL_OPEN
    _graph_0 = term_keep(e, _graph_0, 1);
    _descriptor_1 = term_keep(e, _descriptor_1, 1);
    _descriptor_2 = term_keep(e, _descriptor_2, 1);
    if (seq) {
      WL_ROOM(8);
      STK(0) = _graph_0;
      STK(1) = _graph_1;
      STK(2) = _descriptor_0;
      STK(3) = _descriptor_1;
      STK(4) = _descriptor_2;
      STK(5) = _descriptor_3;
      STK(6) = _source_0;
      STK(7) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K363;
      WL_PUSHN(8);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K363, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _graph_0;
      e.mem[_t_0 + 1] = _graph_1;
      e.mem[_t_0 + 2] = _descriptor_0;
      e.mem[_t_0 + 3] = _descriptor_1;
      e.mem[_t_0 + 4] = _descriptor_2;
      e.mem[_t_0 + 5] = _descriptor_3;
      e.mem[_t_0 + 6] = _source_0;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K363, _t_0);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _graph_0;
      e.mem[_t_1 + 1] = _descriptor_0;
      e.mem[_t_1 + 2] = _descriptor_1;
      e.mem[_t_1 + 3] = _descriptor_2;
      e.mem[_t_1 + 4] = _descriptor_3;
      e.mem[_t_1 + 5] = _source_0;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0, _t_1);
    }
    r0 = _graph_0;
    r1 = _descriptor_0;
    r2 = _descriptor_1;
    r3 = _descriptor_2;
    r4 = _descriptor_3;
    r5 = _source_0;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_TARGET_EDGES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K363)
  {
    WL_POPN(7);
    Term _graph_2 = STK(0);
    Term _graph_3 = STK(1);
    u32 _descriptor_4 = STK(2);
    Term _descriptor_5 = STK(3);
    Term _descriptor_6 = STK(4);
    u32 _descriptor_7 = STK(5);
    u32 _source_1 = STK(6);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _graph_2;
      STK(1) = _descriptor_4;
      STK(2) = _descriptor_5;
      STK(3) = _descriptor_6;
      STK(4) = _descriptor_7;
      STK(5) = _source_1;
      STK(6) = FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K364;
      WL_PUSHN(7);
    } else {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K364, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _graph_2;
      e.mem[_t_2 + 1] = _descriptor_4;
      e.mem[_t_2 + 2] = _descriptor_5;
      e.mem[_t_2 + 3] = _descriptor_6;
      e.mem[_t_2 + 4] = _descriptor_7;
      e.mem[_t_2 + 5] = _source_1;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K364, _t_2);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0)) {
      u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _graph_3;
      e.mem[_t_3 + 3] = _descriptor_4;
      e.mem[_t_3 + 4] = _descriptor_5;
      e.mem[_t_3 + 5] = _descriptor_6;
      e.mem[_t_3 + 6] = _descriptor_7;
      e.mem[_t_3 + 7] = _source_1;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _graph_3;
    r3 = _descriptor_4;
    r4 = _descriptor_5;
    r5 = _descriptor_6;
    r6 = _descriptor_7;
    r7 = _source_1;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_REMOVE_PREVIOUS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0_K364)
  {
    WL_POPN(6);
    Term _graph_4 = STK(0);
    u32 _descriptor_8 = STK(1);
    Term _descriptor_9 = STK(2);
    Term _descriptor_10 = STK(3);
    u32 _descriptor_11 = STK(4);
    u32 _source_2 = STK(5);
    Term _h_2 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_6(e, _o_0, _graph_4, blk_loc(e.mem, _graph_4), _descriptor_8, _descriptor_9, blk_loc(e.mem, _descriptor_9), _descriptor_10, blk_loc(e.mem, _descriptor_10), _descriptor_11, _source_2) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    term_sink(e, _descriptor_9);
    term_sink(e, _descriptor_10);
    _v_0 = _v_1;
    r0 = _v_0;
    r1 = _h_2;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_0)
  {
    Term _graph_0 = r0;
    Term _graph_1 = r1;
    u32 _descriptor_0 = r2;
    Term _descriptor_1 = r3;
    Term _descriptor_2 = r4;
    u32 _descriptor_3 = r5;
    u32 _target_0 = r6;
    WL_OPEN
    term_sink(e, _graph_0);
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0)) {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _graph_1;
      e.mem[_t_0 + 1] = _descriptor_0;
      e.mem[_t_0 + 2] = _descriptor_1;
      e.mem[_t_0 + 3] = _descriptor_2;
      e.mem[_t_0 + 4] = _descriptor_3;
      e.mem[_t_0 + 5] = _target_0;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0, _t_0);
    }
    r0 = _graph_1;
    r1 = _descriptor_0;
    r2 = _descriptor_1;
    r3 = _descriptor_2;
    r4 = _descriptor_3;
    r5 = _target_0;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_ENTRIES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_5)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_5_K370;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_5_K370, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_5_K370, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_5_K370)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_5_K371;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_5_K371, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_5_K371, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_4)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_4, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      return term_tsk(FID_LIST_SHOW_GO_4, _t_3);
    }
    r0 = _f_2;
    WL_JMP(FID_LIST_SHOW_GO_4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_5_K371)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_5_K372;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_5_K372, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_5_K372, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_5_K372)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_DESCRIPTOR_0)
  {
    u32 _descriptor_0 = r0;
    Term _descriptor_1 = r1;
    Term _descriptor_2 = r2;
    u32 _descriptor_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _descriptor_1;
      STK(1) = _descriptor_2;
      STK(2) = _descriptor_3;
      STK(3) = FID_CONSUMER_SHOW_DESCRIPTOR_0_K374;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0_K374, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _descriptor_1;
      e.mem[_t_0 + 1] = _descriptor_2;
      e.mem[_t_0 + 2] = _descriptor_3;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0_K374, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _descriptor_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _descriptor_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_DESCRIPTOR_0_K374)
  {
    WL_POPN(3);
    Term _descriptor_4 = STK(0);
    Term _descriptor_5 = STK(1);
    u32 _descriptor_6 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_35(e, _o_0, _descriptor_6) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(4);
      STK(0) = _descriptor_4;
      STK(1) = _descriptor_5;
      STK(2) = _h_0;
      STK(3) = FID_CONSUMER_SHOW_DESCRIPTOR_0_K375;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0_K375, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _descriptor_4;
      e.mem[_t_2 + 1] = _descriptor_5;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0_K375, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_3 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_DESCRIPTOR_0_K375)
  {
    WL_POPN(3);
    Term _descriptor_7 = STK(0);
    Term _descriptor_8 = STK(1);
    Term _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _descriptor_7;
      STK(1) = _h_2;
      STK(2) = FID_CONSUMER_SHOW_DESCRIPTOR_0_K376;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0_K376, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _descriptor_7;
      e.mem[_t_4 + 1] = _h_2;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0_K376, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _descriptor_8;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _descriptor_8;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_DESCRIPTOR_0_K376)
  {
    WL_POPN(2);
    Term _descriptor_9 = STK(0);
    Term _h_4 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _descriptor_9;
      STK(1) = _h_4;
      STK(2) = FID_CONSUMER_SHOW_DESCRIPTOR_0_K377;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0_K377, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _descriptor_9;
      e.mem[_t_6 + 1] = _h_4;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0_K377, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_DESCRIPTOR_0_K377)
  {
    WL_POPN(2);
    Term _descriptor_10 = STK(0);
    Term _h_6 = STK(1);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_6;
      STK(1) = FID_CONSUMER_SHOW_DESCRIPTOR_0_K378;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0_K378, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_6;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0_K378, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _descriptor_10;
      e.mem[_t_9 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _descriptor_10;
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_DESCRIPTOR_0_K378)
  {
    WL_POPN(1);
    Term _h_8 = STK(0);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_8;
      STK(1) = FID_CONSUMER_SHOW_DESCRIPTOR_0_K379;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0_K379, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_8;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0_K379, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_11 + 1] = _h_7;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_7;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_DESCRIPTOR_0_K379)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_9 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_10;
      e.mem[_t_12 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _h_10;
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_7)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[4];
      u64 _sp_1 = ctr_take(e, _f_0, 4, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      u32 _f_5 = _fb_1[3];
      spare_free(e, cls_fit(4), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_7_K381;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_7_K381, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_7_K381, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_DESCRIPTOR_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _f_5;
        return term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _f_5;
      WL_JMP(FID_CONSUMER_SHOW_DESCRIPTOR_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_7_K381)
  {
    WL_POPN(1);
    Term _f_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_7_K382;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_7_K382, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_7_K382, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_6)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_6, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_6;
      return term_tsk(FID_LIST_SHOW_GO_6, _t_3);
    }
    r0 = _f_6;
    WL_JMP(FID_LIST_SHOW_GO_6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_7_K382)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_7_K383;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_7_K383, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_7_K383, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_7_K383)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 270);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_COMPONENTS)
  {
    Term _components_0 = r0;
    Term _components_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _components_1;
      STK(1) = FID_CONSUMER_SHOW_COMPONENTS_K387;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_COMPONENTS_K387, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _components_1;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_COMPONENTS_K387, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_TREE_1)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_TREE_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _components_0;
      return term_tsk(FID_CONSUMER_TREE_1, _t_1);
    }
    r0 = _components_0;
    WL_JMP(FID_CONSUMER_TREE_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_COMPONENTS_K387)
  {
    WL_POPN(1);
    Term _components_2 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = FID_CONSUMER_SHOW_COMPONENTS_K388;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_SHOW_COMPONENTS_K388, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_COMPONENTS_K388, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_REMOVED)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_SHOW_REMOVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _components_2;
      return term_tsk(FID_CONSUMER_SHOW_REMOVED, _t_3);
    }
    r0 = _components_2;
    WL_JMP(FID_CONSUMER_SHOW_REMOVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_COMPONENTS_K388)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_2 = r0;
    Term _h_3 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = _h_2;
      STK(3) = FID_CONSUMER_SHOW_COMPONENTS_K389;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SHOW_COMPONENTS_K389, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_4;
      e.mem[_t_4 + 1] = _h_5;
      e.mem[_t_4 + 2] = _h_2;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_COMPONENTS_K389, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 136);
      e.mem[_t_5 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 136);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_COMPONENTS_K389)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_7;
      STK(1) = _h_9;
      STK(2) = FID_CONSUMER_SHOW_COMPONENTS_K390;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_SHOW_COMPONENTS_K390, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_7;
      e.mem[_t_6 + 1] = _h_9;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_COMPONENTS_K390, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_8;
      e.mem[_t_7 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_COMPONENTS_K390)
  {
    WL_POPN(2);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    Term _h_10 = r0;
    WL_OPEN
    r0 = _h_11;
    r1 = _h_12;
    r2 = _h_10;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    Term _world_10 = r10;
    Term _world_11 = r11;
    Term _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_11;
      STK(11) = _world_12;
      STK(12) = _world_13;
      STK(13) = _world_14;
      STK(14) = _world_15;
      STK(15) = FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K397;
      WL_PUSHN(16);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K397, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_11;
      e.mem[_t_0 + 11] = _world_12;
      e.mem[_t_0 + 12] = _world_13;
      e.mem[_t_0 + 13] = _world_14;
      e.mem[_t_0 + 14] = _world_15;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K397, _t_0);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_TREE_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_TREE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_10;
      return term_tsk(FID_CONSUMER_TREE_0, _t_1);
    }
    r0 = _world_10;
    WL_JMP(FID_CONSUMER_TREE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0_K397)
  {
    WL_POPN(15);
    u32 _world_16 = STK(0);
    u32 _world_17 = STK(1);
    u32 _world_18 = STK(2);
    Term _world_19 = STK(3);
    u32 _world_20 = STK(4);
    Term _world_21 = STK(5);
    Term _world_22 = STK(6);
    Term _world_23 = STK(7);
    Term _world_24 = STK(8);
    Term _world_25 = STK(9);
    Term _world_26 = STK(10);
    Term _world_27 = STK(11);
    Term _world_28 = STK(12);
    u32 _world_29 = STK(13);
    u32 _world_30 = STK(14);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _o_0[17];
    if (spin_36(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, _world_21, _world_22, blk_loc(e.mem, _world_22), _world_23, blk_loc(e.mem, _world_23), _world_24, blk_loc(e.mem, _world_24), _world_25, blk_loc(e.mem, _world_25), _world_26, blk_loc(e.mem, _world_26), _world_27, blk_loc(e.mem, _world_27), _world_28, blk_loc(e.mem, _world_28), _world_29, _world_30) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_BARRIER_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    Term _world_10 = r10;
    Term _world_11 = r11;
    Term _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0)) {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _world_12;
      e.mem[_t_0 + 1] = _world_0;
      e.mem[_t_0 + 2] = _world_1;
      e.mem[_t_0 + 3] = _world_2;
      e.mem[_t_0 + 4] = _world_3;
      e.mem[_t_0 + 5] = _world_4;
      e.mem[_t_0 + 6] = _world_5;
      e.mem[_t_0 + 7] = _world_6;
      e.mem[_t_0 + 8] = _world_7;
      e.mem[_t_0 + 9] = _world_8;
      e.mem[_t_0 + 10] = _world_9;
      e.mem[_t_0 + 11] = _world_10;
      e.mem[_t_0 + 12] = _world_11;
      e.mem[_t_0 + 13] = term_pak(CID_NIL, 0);
      e.mem[_t_0 + 14] = _world_13;
      e.mem[_t_0 + 15] = _world_14;
      e.mem[_t_0 + 16] = _world_15;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0, _t_0);
    }
    r0 = _world_12;
    r1 = _world_0;
    r2 = _world_1;
    r3 = _world_2;
    r4 = _world_3;
    r5 = _world_4;
    r6 = _world_5;
    r7 = _world_6;
    r8 = _world_7;
    r9 = _world_8;
    r10 = _world_9;
    r11 = _world_10;
    r12 = _world_11;
    r13 = term_pak(CID_NIL, 0);
    r14 = _world_13;
    r15 = _world_14;
    r16 = _world_15;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_DRAIN_FIFO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3)
  {
    Term _effect_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    Term _world_8 = r9;
    Term _world_9 = r10;
    Term _world_10 = r11;
    Term _world_11 = r12;
    Term _world_12 = r13;
    Term _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _world_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, _world_7);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _world_8);
    e.mem[_nd_1 + 2] = rfc_seal(e, _world_9);
    if (seq) {
      WL_ROOM(13);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_10;
      STK(7) = _world_11;
      STK(8) = _world_12;
      STK(9) = _world_13;
      STK(10) = _world_14;
      STK(11) = _world_15;
      STK(12) = FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3_K444;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3_K444, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_10;
      e.mem[_t_0 + 7] = _world_11;
      e.mem[_t_0 + 8] = _world_12;
      e.mem[_t_0 + 9] = _world_13;
      e.mem[_t_0 + 10] = _world_14;
      e.mem[_t_0 + 11] = _world_15;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3_K444, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _effect_0;
      e.mem[_t_1 + 1] = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _effect_0;
    r1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3_K444)
  {
    WL_POPN(12);
    u32 _world_16 = STK(0);
    u32 _world_17 = STK(1);
    u32 _world_18 = STK(2);
    Term _world_19 = STK(3);
    u32 _world_20 = STK(4);
    Term _world_21 = STK(5);
    Term _world_22 = STK(6);
    Term _world_23 = STK(7);
    Term _world_24 = STK(8);
    Term _world_25 = STK(9);
    u32 _world_26 = STK(10);
    u32 _world_27 = STK(11);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[3];
    u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
    Term _f_2 = _fb_1[0];
    Term _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_1);
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _f_2, 2, _fb_2);
    Term _f_5 = _fb_2[0];
    Term _f_6 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _o_0[17];
    if (spin_41(e, _o_0, _f_5, blk_loc(e.mem, _f_5), _f_6, blk_loc(e.mem, _f_6), _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_1, blk_loc(e.mem, _f_1), _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, _world_21, _world_22, blk_loc(e.mem, _world_22), _world_23, blk_loc(e.mem, _world_23), _world_24, blk_loc(e.mem, _world_24), _world_25, blk_loc(e.mem, _world_25), _world_26, _world_27) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2)
  {
    Term _effect_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    Term _world_8 = r9;
    Term _world_9 = r10;
    Term _world_10 = r11;
    Term _world_11 = r12;
    Term _world_12 = r13;
    Term _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _world_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, _world_7);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _world_8);
    e.mem[_nd_1 + 2] = rfc_seal(e, _world_9);
    if (seq) {
      WL_ROOM(13);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_10;
      STK(7) = _world_11;
      STK(8) = _world_12;
      STK(9) = _world_13;
      STK(10) = _world_14;
      STK(11) = _world_15;
      STK(12) = FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2_K450;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2_K450, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_10;
      e.mem[_t_0 + 7] = _world_11;
      e.mem[_t_0 + 8] = _world_12;
      e.mem[_t_0 + 9] = _world_13;
      e.mem[_t_0 + 10] = _world_14;
      e.mem[_t_0 + 11] = _world_15;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2_K450, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _effect_0;
      e.mem[_t_1 + 1] = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _effect_0;
    r1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2_K450)
  {
    WL_POPN(12);
    u32 _world_16 = STK(0);
    u32 _world_17 = STK(1);
    u32 _world_18 = STK(2);
    Term _world_19 = STK(3);
    u32 _world_20 = STK(4);
    Term _world_21 = STK(5);
    Term _world_22 = STK(6);
    Term _world_23 = STK(7);
    Term _world_24 = STK(8);
    Term _world_25 = STK(9);
    u32 _world_26 = STK(10);
    u32 _world_27 = STK(11);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[3];
    u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
    Term _f_2 = _fb_1[0];
    Term _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_1);
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _f_2, 2, _fb_2);
    Term _f_5 = _fb_2[0];
    Term _f_6 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _o_0[16];
    if (spin_43(e, _o_0, _f_5, blk_loc(e.mem, _f_5), _f_6, blk_loc(e.mem, _f_6), _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, _world_21, _world_22, blk_loc(e.mem, _world_22), _world_23, blk_loc(e.mem, _world_23), _world_24, blk_loc(e.mem, _world_24), _world_25, blk_loc(e.mem, _world_25), _world_26, _world_27) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_7)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      Term _o_4 = 0;
      u32 _o_5 = 0;
      Term _o_6 = 0;
      Term _o_7 = 0;
      if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPENTER) {
        _o_0 = 0;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPDESCRIPTORS) {
        _o_0 = 1;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPCHILDREN) {
        _o_0 = 2;
        Term _fb_2[7];
        u64 _sp_2 = ctr_take(e, _f_0, 7, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        Term _f_6 = _fb_2[2];
        Term _f_7 = _fb_2[3];
        u32 _f_8 = _fb_2[4];
        Term _f_9 = _fb_2[5];
        Term _f_10 = _fb_2[6];
        spare_free(e, cls_fit(7), _sp_2);
        _o_1 = _f_4;
        _o_2 = _f_5;
        _o_3 = _f_6;
        _o_4 = _f_7;
        _o_5 = _f_8;
        _o_6 = _f_9;
        _o_7 = _f_10;
      } else {
        _o_0 = 3;
        _o_1 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_7_K458;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_7_K458, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_7_K458, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_FRAME_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_FRAME_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        e.mem[_t_1 + 5] = _o_5;
        e.mem[_t_1 + 6] = _o_6;
        e.mem[_t_1 + 7] = _o_7;
        return term_tsk(FID_CONSUMER_SHOW_FRAME_0, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      r5 = _o_5;
      r6 = _o_6;
      r7 = _o_7;
      WL_JMP(FID_CONSUMER_SHOW_FRAME_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_7_K458)
  {
    WL_POPN(1);
    Term _f_11 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_7_K459;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_7_K459, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_7_K459, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_7)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_7, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_11;
      return term_tsk(FID_LIST_SHOW_GO_7, _t_3);
    }
    r0 = _f_11;
    WL_JMP(FID_LIST_SHOW_GO_7);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_7_K459)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_7_K460;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_7_K460, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_7_K460, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_7_K460)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0)
  {
    u32 _frame_0 = r0;
    u32 _frame_1 = r1;
    Term _frame_2 = r2;
    Term _frame_3 = r3;
    Term _frame_4 = r4;
    u32 _frame_5 = r5;
    Term _frame_6 = r6;
    Term _frame_7 = r7;
    WL_OPEN
    if (_frame_0 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_SHOW_FRAME_0_K462;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K462, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K462, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _frame_1;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _frame_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_frame_0 == 1) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _frame_2;
        STK(1) = FID_CONSUMER_SHOW_FRAME_0_K463;
        WL_PUSHN(2);
      } else {
        u64 _t_3 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K463, WL_CONT, WL_IDX, 1);
        e.mem[_t_3 + 0] = _frame_2;
        WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K463, _t_3);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_4 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_4 + 0] = _frame_1;
        return term_tsk(FID_U32_SHOW, _t_4);
      }
      r0 = _frame_1;
      WL_JMP(FID_U32_SHOW);
    } else if (_frame_0 == 2) {
      if (seq) {
        WL_ROOM(7);
        STK(0) = _frame_2;
        STK(1) = _frame_3;
        STK(2) = _frame_4;
        STK(3) = _frame_5;
        STK(4) = _frame_6;
        STK(5) = _frame_7;
        STK(6) = FID_CONSUMER_SHOW_FRAME_0_K467;
        WL_PUSHN(7);
      } else {
        u64 _t_12 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K467, WL_CONT, WL_IDX, 1);
        e.mem[_t_12 + 0] = _frame_2;
        e.mem[_t_12 + 1] = _frame_3;
        e.mem[_t_12 + 2] = _frame_4;
        e.mem[_t_12 + 3] = _frame_5;
        e.mem[_t_12 + 4] = _frame_6;
        e.mem[_t_12 + 5] = _frame_7;
        WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K467, _t_12);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_13 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_13 + 0] = _frame_1;
        return term_tsk(FID_U32_SHOW, _t_13);
      }
      r0 = _frame_1;
      WL_JMP(FID_U32_SHOW);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_SHOW_FRAME_0_K477;
        WL_PUSHN(1);
      } else {
        u64 _t_33 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K477, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K477, _t_33);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_34 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_34 + 0] = _frame_1;
        return term_tsk(FID_U32_SHOW, _t_34);
      }
      r0 = _frame_1;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K462)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 292);
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_2);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 292);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K463)
  {
    WL_POPN(1);
    Term _frame_8 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_1;
      STK(1) = FID_CONSUMER_SHOW_FRAME_0_K464;
      WL_PUSHN(2);
    } else {
      u64 _t_5 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K464, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _h_1;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K464, _t_5);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_7)) {
      u64 _t_6 = task_node(e, FID_LIST_SHOW_7, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _frame_8;
      return term_tsk(FID_LIST_SHOW_7, _t_6);
    }
    r0 = _frame_8;
    WL_JMP(FID_LIST_SHOW_7);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K464)
  {
    WL_POPN(1);
    Term _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_3;
      STK(1) = FID_CONSUMER_SHOW_FRAME_0_K465;
      WL_PUSHN(2);
    } else {
      u64 _t_7 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K465, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_3;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K465, _t_7);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_8 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K465)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CONSUMER_SHOW_FRAME_0_K466;
      WL_PUSHN(1);
    } else {
      u64 _t_9 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K466, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K466, _t_9);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_5;
      e.mem[_t_10 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_5;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K466)
  {
    Term _h_6 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 314);
      e.mem[_t_11 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 314);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K467)
  {
    WL_POPN(6);
    u32 _frame_9 = STK(0);
    Term _frame_10 = STK(1);
    Term _frame_11 = STK(2);
    u32 _frame_12 = STK(3);
    Term _frame_13 = STK(4);
    Term _frame_14 = STK(5);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _frame_13;
      STK(1) = _frame_14;
      STK(2) = _h_7;
      STK(3) = FID_CONSUMER_SHOW_FRAME_0_K468;
      WL_PUSHN(4);
    } else {
      u64 _t_14 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K468, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _frame_13;
      e.mem[_t_14 + 1] = _frame_14;
      e.mem[_t_14 + 2] = _h_7;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K468, _t_14);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_DESCRIPTOR_0)) {
      u64 _t_15 = task_node(e, FID_CONSUMER_SHOW_DESCRIPTOR_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _frame_9;
      e.mem[_t_15 + 1] = _frame_10;
      e.mem[_t_15 + 2] = _frame_11;
      e.mem[_t_15 + 3] = _frame_12;
      return term_tsk(FID_CONSUMER_SHOW_DESCRIPTOR_0, _t_15);
    }
    r0 = _frame_9;
    r1 = _frame_10;
    r2 = _frame_11;
    r3 = _frame_12;
    WL_JMP(FID_CONSUMER_SHOW_DESCRIPTOR_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K468)
  {
    WL_POPN(3);
    Term _frame_15 = STK(0);
    Term _frame_16 = STK(1);
    Term _h_9 = STK(2);
    Term _h_8 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _frame_16;
      STK(1) = _h_9;
      STK(2) = _h_8;
      STK(3) = FID_CONSUMER_SHOW_FRAME_0_K469;
      WL_PUSHN(4);
    } else {
      u64 _t_16 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K469, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _frame_16;
      e.mem[_t_16 + 1] = _h_9;
      e.mem[_t_16 + 2] = _h_8;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K469, _t_16);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_7)) {
      u64 _t_17 = task_node(e, FID_LIST_SHOW_7, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _frame_15;
      return term_tsk(FID_LIST_SHOW_7, _t_17);
    }
    r0 = _frame_15;
    WL_JMP(FID_LIST_SHOW_7);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K469)
  {
    WL_POPN(3);
    Term _frame_17 = STK(0);
    Term _h_11 = STK(1);
    Term _h_12 = STK(2);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_10;
      STK(3) = FID_CONSUMER_SHOW_FRAME_0_K470;
      WL_PUSHN(4);
    } else {
      u64 _t_18 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K470, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_11;
      e.mem[_t_18 + 1] = _h_12;
      e.mem[_t_18 + 2] = _h_10;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K470, _t_18);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_5)) {
      u64 _t_19 = task_node(e, FID_LIST_SHOW_5, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _frame_17;
      return term_tsk(FID_LIST_SHOW_5, _t_19);
    }
    r0 = _frame_17;
    WL_JMP(FID_LIST_SHOW_5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K470)
  {
    WL_POPN(3);
    Term _h_14 = STK(0);
    Term _h_15 = STK(1);
    Term _h_16 = STK(2);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_14;
      STK(1) = _h_15;
      STK(2) = _h_16;
      STK(3) = FID_CONSUMER_SHOW_FRAME_0_K471;
      WL_PUSHN(4);
    } else {
      u64 _t_20 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K471, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _h_14;
      e.mem[_t_20 + 1] = _h_15;
      e.mem[_t_20 + 2] = _h_16;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K471, _t_20);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_21 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K471)
  {
    WL_POPN(3);
    Term _h_18 = STK(0);
    Term _h_19 = STK(1);
    Term _h_20 = STK(2);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_18;
      STK(1) = _h_19;
      STK(2) = FID_CONSUMER_SHOW_FRAME_0_K472;
      WL_PUSHN(3);
    } else {
      u64 _t_22 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K472, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _h_18;
      e.mem[_t_22 + 1] = _h_19;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K472, _t_22);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_20;
      e.mem[_t_23 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = _h_20;
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K472)
  {
    WL_POPN(2);
    Term _h_22 = STK(0);
    Term _h_23 = STK(1);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_22;
      STK(1) = _h_23;
      STK(2) = FID_CONSUMER_SHOW_FRAME_0_K473;
      WL_PUSHN(3);
    } else {
      u64 _t_24 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K473, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _h_22;
      e.mem[_t_24 + 1] = _h_23;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K473, _t_24);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_25 + 1] = _h_21;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_21;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K473)
  {
    WL_POPN(2);
    Term _h_25 = STK(0);
    Term _h_26 = STK(1);
    Term _h_24 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_25;
      STK(1) = FID_CONSUMER_SHOW_FRAME_0_K474;
      WL_PUSHN(2);
    } else {
      u64 _t_26 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K474, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _h_25;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K474, _t_26);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _h_26;
      e.mem[_t_27 + 1] = _h_24;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = _h_26;
    r1 = _h_24;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K474)
  {
    WL_POPN(1);
    Term _h_28 = STK(0);
    Term _h_27 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_28;
      STK(1) = FID_CONSUMER_SHOW_FRAME_0_K475;
      WL_PUSHN(2);
    } else {
      u64 _t_28 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K475, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _h_28;
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K475, _t_28);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_29 + 1] = _h_27;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_27;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K475)
  {
    WL_POPN(1);
    Term _h_30 = STK(0);
    Term _h_29 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CONSUMER_SHOW_FRAME_0_K476;
      WL_PUSHN(1);
    } else {
      u64 _t_30 = task_node(e, FID_CONSUMER_SHOW_FRAME_0_K476, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CONSUMER_SHOW_FRAME_0_K476, _t_30);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_31 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_30;
      e.mem[_t_31 + 1] = _h_29;
      return term_tsk(FID_STRING_APPEND, _t_31);
    }
    r0 = _h_30;
    r1 = _h_29;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K476)
  {
    Term _h_31 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_32 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_32 + 0] = term_ctr(CID_SCON, STAT_OFF + 330);
      e.mem[_t_32 + 1] = _h_31;
      return term_tsk(FID_STRING_APPEND, _t_32);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 330);
    r1 = _h_31;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SHOW_FRAME_0_K477)
  {
    Term _h_32 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_35 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 342);
      e.mem[_t_35 + 1] = _h_32;
      return term_tsk(FID_STRING_APPEND, _t_35);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 342);
    r1 = _h_32;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0)
  {
    Term _commands_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_commands_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      r1 = 0ull;
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K479;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K479, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K479, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _commands_0 = r0;
      WL_AGAIN(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0_K479)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[2];
    if (spin_45(e, _o_0, _f_2, blk_loc(e.mem, _f_2), _h_0, blk_loc(e.mem, _h_0), _h_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0)
  {
    Term _effect_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    Term _world_8 = r9;
    Term _world_9 = r10;
    Term _world_10 = r11;
    Term _world_11 = r12;
    Term _world_12 = r13;
    Term _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _world_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, _world_7);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _world_8);
    e.mem[_nd_1 + 2] = rfc_seal(e, _world_9);
    if (seq) {
      WL_ROOM(13);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_10;
      STK(7) = _world_11;
      STK(8) = _world_12;
      STK(9) = _world_13;
      STK(10) = _world_14;
      STK(11) = _world_15;
      STK(12) = FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0_K487;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0_K487, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_10;
      e.mem[_t_0 + 7] = _world_11;
      e.mem[_t_0 + 8] = _world_12;
      e.mem[_t_0 + 9] = _world_13;
      e.mem[_t_0 + 10] = _world_14;
      e.mem[_t_0 + 11] = _world_15;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0_K487, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _effect_0;
      e.mem[_t_1 + 1] = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _effect_0;
    r1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0_K487)
  {
    WL_POPN(12);
    u32 _world_16 = STK(0);
    u32 _world_17 = STK(1);
    u32 _world_18 = STK(2);
    Term _world_19 = STK(3);
    u32 _world_20 = STK(4);
    Term _world_21 = STK(5);
    Term _world_22 = STK(6);
    Term _world_23 = STK(7);
    Term _world_24 = STK(8);
    Term _world_25 = STK(9);
    u32 _world_26 = STK(10);
    u32 _world_27 = STK(11);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[3];
    u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
    Term _f_2 = _fb_1[0];
    Term _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_1);
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _f_2, 2, _fb_2);
    Term _f_5 = _fb_2[0];
    Term _f_6 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _o_0[17];
    if (spin_46(e, _o_0, _f_5, blk_loc(e.mem, _f_5), _f_6, blk_loc(e.mem, _f_6), _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_1, blk_loc(e.mem, _f_1), _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, _world_21, _world_22, blk_loc(e.mem, _world_22), _world_23, blk_loc(e.mem, _world_23), _world_24, blk_loc(e.mem, _world_24), _world_25, blk_loc(e.mem, _world_25), _world_26, _world_27) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_FINAL_BARRIER_0)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    u32 _result_2 = r2;
    u32 _result_3 = r3;
    Term _result_4 = r4;
    u32 _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    Term _result_8 = r8;
    Term _result_9 = r9;
    Term _result_10 = r10;
    Term _result_11 = r11;
    Term _result_12 = r12;
    Term _result_13 = r13;
    Term _result_14 = r14;
    u32 _result_15 = r15;
    u32 _result_16 = r16;
    Term _result_17 = r17;
    WL_OPEN
    if (_result_0 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_FINAL_BARRIER_0_K527;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_FINAL_BARRIER_0_K527, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_FINAL_BARRIER_0_K527, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_BARRIER_0)) {
        u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_BARRIER_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _result_1;
        e.mem[_t_1 + 1] = _result_2;
        e.mem[_t_1 + 2] = _result_3;
        e.mem[_t_1 + 3] = _result_4;
        e.mem[_t_1 + 4] = _result_5;
        e.mem[_t_1 + 5] = _result_6;
        e.mem[_t_1 + 6] = _result_7;
        e.mem[_t_1 + 7] = _result_8;
        e.mem[_t_1 + 8] = _result_9;
        e.mem[_t_1 + 9] = _result_10;
        e.mem[_t_1 + 10] = _result_11;
        e.mem[_t_1 + 11] = _result_12;
        e.mem[_t_1 + 12] = _result_13;
        e.mem[_t_1 + 13] = _result_14;
        e.mem[_t_1 + 14] = _result_15;
        e.mem[_t_1 + 15] = _result_16;
        return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_BARRIER_0, _t_1);
      }
      r0 = _result_1;
      r1 = _result_2;
      r2 = _result_3;
      r3 = _result_4;
      r4 = _result_5;
      r5 = _result_6;
      r6 = _result_7;
      r7 = _result_8;
      r8 = _result_9;
      r9 = _result_10;
      r10 = _result_11;
      r11 = _result_12;
      r12 = _result_13;
      r13 = _result_14;
      r14 = _result_15;
      r15 = _result_16;
      WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_BARRIER_0);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _result_17;
        STK(1) = FID_CONSUMER_FINAL_BARRIER_0_K529;
        WL_PUSHN(2);
      } else {
        u64 _t_5 = task_node(e, FID_CONSUMER_FINAL_BARRIER_0_K529, WL_CONT, WL_IDX, 1);
        e.mem[_t_5 + 0] = _result_17;
        WL_CONT = term_tsk(FID_CONSUMER_FINAL_BARRIER_0_K529, _t_5);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_OBSERVE_0)) {
        u64 _t_6 = task_node(e, FID_CONSUMER_OBSERVE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_6 + 0] = _result_1;
        e.mem[_t_6 + 1] = _result_2;
        e.mem[_t_6 + 2] = _result_3;
        e.mem[_t_6 + 3] = _result_4;
        e.mem[_t_6 + 4] = _result_5;
        e.mem[_t_6 + 5] = _result_6;
        e.mem[_t_6 + 6] = _result_7;
        e.mem[_t_6 + 7] = _result_8;
        e.mem[_t_6 + 8] = _result_9;
        e.mem[_t_6 + 9] = _result_10;
        e.mem[_t_6 + 10] = _result_11;
        e.mem[_t_6 + 11] = _result_12;
        e.mem[_t_6 + 12] = _result_13;
        e.mem[_t_6 + 13] = _result_14;
        e.mem[_t_6 + 14] = _result_15;
        e.mem[_t_6 + 15] = _result_16;
        return term_tsk(FID_CONSUMER_OBSERVE_0, _t_6);
      }
      r0 = _result_1;
      r1 = _result_2;
      r2 = _result_3;
      r3 = _result_4;
      r4 = _result_5;
      r5 = _result_6;
      r6 = _result_7;
      r7 = _result_8;
      r8 = _result_9;
      r9 = _result_10;
      r10 = _result_11;
      r11 = _result_12;
      r12 = _result_13;
      r13 = _result_14;
      r14 = _result_15;
      r15 = _result_16;
      WL_JMP(FID_CONSUMER_OBSERVE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_FINAL_BARRIER_0_K527)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CONSUMER_FINAL_BARRIER_0_K528;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_FINAL_BARRIER_0_K528, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CONSUMER_FINAL_BARRIER_0_K528, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_OBSERVE_0)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_OBSERVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      e.mem[_t_3 + 10] = _h_10;
      e.mem[_t_3 + 11] = _h_11;
      e.mem[_t_3 + 12] = _h_12;
      e.mem[_t_3 + 13] = _h_13;
      e.mem[_t_3 + 14] = _h_14;
      e.mem[_t_3 + 15] = _h_15;
      return term_tsk(FID_CONSUMER_OBSERVE_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    WL_JMP(FID_CONSUMER_OBSERVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_FINAL_BARRIER_0_K528)
  {
    u32 _h_16 = r0;
    u32 _h_17 = r1;
    u32 _h_18 = r2;
    Term _h_19 = r3;
    u32 _h_20 = r4;
    Term _h_21 = r5;
    Term _h_22 = r6;
    Term _h_23 = r7;
    Term _h_24 = r8;
    Term _h_25 = r9;
    Term _h_26 = r10;
    Term _h_27 = r11;
    Term _h_28 = r12;
    Term _h_29 = r13;
    u32 _h_30 = r14;
    u32 _h_31 = r15;
    Term _h_32 = r16;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_COMPLETE_OBSERVED_0)) {
      u64 _t_4 = task_node(e, FID_CONSUMER_COMPLETE_OBSERVED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _h_16;
      e.mem[_t_4 + 1] = _h_17;
      e.mem[_t_4 + 2] = _h_18;
      e.mem[_t_4 + 3] = _h_19;
      e.mem[_t_4 + 4] = _h_20;
      e.mem[_t_4 + 5] = _h_21;
      e.mem[_t_4 + 6] = _h_22;
      e.mem[_t_4 + 7] = _h_23;
      e.mem[_t_4 + 8] = _h_24;
      e.mem[_t_4 + 9] = _h_25;
      e.mem[_t_4 + 10] = _h_26;
      e.mem[_t_4 + 11] = _h_27;
      e.mem[_t_4 + 12] = _h_28;
      e.mem[_t_4 + 13] = _h_29;
      e.mem[_t_4 + 14] = _h_30;
      e.mem[_t_4 + 15] = _h_31;
      e.mem[_t_4 + 16] = _h_32;
      return term_tsk(FID_CONSUMER_COMPLETE_OBSERVED_0, _t_4);
    }
    r0 = _h_16;
    r1 = _h_17;
    r2 = _h_18;
    r3 = _h_19;
    r4 = _h_20;
    r5 = _h_21;
    r6 = _h_22;
    r7 = _h_23;
    r8 = _h_24;
    r9 = _h_25;
    r10 = _h_26;
    r11 = _h_27;
    r12 = _h_28;
    r13 = _h_29;
    r14 = _h_30;
    r15 = _h_31;
    r16 = _h_32;
    WL_JMP(FID_CONSUMER_COMPLETE_OBSERVED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_FINAL_BARRIER_0_K529)
  {
    WL_POPN(1);
    Term _result_18 = STK(0);
    u32 _h_33 = r0;
    u32 _h_34 = r1;
    u32 _h_35 = r2;
    Term _h_36 = r3;
    u32 _h_37 = r4;
    Term _h_38 = r5;
    Term _h_39 = r6;
    Term _h_40 = r7;
    Term _h_41 = r8;
    Term _h_42 = r9;
    Term _h_43 = r10;
    Term _h_44 = r11;
    Term _h_45 = r12;
    Term _h_46 = r13;
    u32 _h_47 = r14;
    u32 _h_48 = r15;
    Term _h_49 = r16;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_INCOMPLETE_OBSERVED_0)) {
      u64 _t_7 = task_node(e, FID_CONSUMER_INCOMPLETE_OBSERVED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _result_18;
      e.mem[_t_7 + 1] = _h_33;
      e.mem[_t_7 + 2] = _h_34;
      e.mem[_t_7 + 3] = _h_35;
      e.mem[_t_7 + 4] = _h_36;
      e.mem[_t_7 + 5] = _h_37;
      e.mem[_t_7 + 6] = _h_38;
      e.mem[_t_7 + 7] = _h_39;
      e.mem[_t_7 + 8] = _h_40;
      e.mem[_t_7 + 9] = _h_41;
      e.mem[_t_7 + 10] = _h_42;
      e.mem[_t_7 + 11] = _h_43;
      e.mem[_t_7 + 12] = _h_44;
      e.mem[_t_7 + 13] = _h_45;
      e.mem[_t_7 + 14] = _h_46;
      e.mem[_t_7 + 15] = _h_47;
      e.mem[_t_7 + 16] = _h_48;
      e.mem[_t_7 + 17] = _h_49;
      return term_tsk(FID_CONSUMER_INCOMPLETE_OBSERVED_0, _t_7);
    }
    r0 = _result_18;
    r1 = _h_33;
    r2 = _h_34;
    r3 = _h_35;
    r4 = _h_36;
    r5 = _h_37;
    r6 = _h_38;
    r7 = _h_39;
    r8 = _h_40;
    r9 = _h_41;
    r10 = _h_42;
    r11 = _h_43;
    r12 = _h_44;
    r13 = _h_45;
    r14 = _h_46;
    r15 = _h_47;
    r16 = _h_48;
    r17 = _h_49;
    WL_JMP(FID_CONSUMER_INCOMPLETE_OBSERVED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_LAST_0)
  {
    u32 _observed_0 = r0;
    u32 _observed_1 = r1;
    u32 _observed_2 = r2;
    u32 _observed_3 = r3;
    Term _observed_4 = r4;
    u32 _observed_5 = r5;
    Term _observed_6 = r6;
    Term _observed_7 = r7;
    Term _observed_8 = r8;
    Term _observed_9 = r9;
    Term _observed_10 = r10;
    Term _observed_11 = r11;
    Term _observed_12 = r12;
    Term _observed_13 = r13;
    Term _observed_14 = r14;
    u32 _observed_15 = r15;
    u32 _observed_16 = r16;
    Term _observed_17 = r17;
    Term _observed_18 = r18;
    WL_OPEN
    term_sink(e, _observed_4);
    term_sink(e, _observed_7);
    term_sink(e, _observed_8);
    term_sink(e, _observed_9);
    term_sink(e, _observed_10);
    term_sink(e, _observed_11);
    term_sink(e, _observed_12);
    term_sink(e, _observed_13);
    term_sink(e, _observed_14);
    term_sink(e, _observed_17);
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_0 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _observed_18;
      e.mem[_t_0 + 1] = term_ctr(CID_SCON, STAT_OFF + 344);
      return term_tsk(FID_STRING_APPEND, _t_0);
    }
    r0 = _observed_18;
    r1 = term_ctr(CID_SCON, STAT_OFF + 344);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    Term _world_10 = r10;
    Term _world_11 = r11;
    Term _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _handle_0 = r16;
    u32 _handle_1 = r17;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _handle_0;
    e.mem[_nd_0 + 1] = _handle_1;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _handle_0;
      STK(1) = _handle_1;
      STK(2) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K539;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K539, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _handle_0;
      e.mem[_t_0 + 1] = _handle_1;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K539, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_clo(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_C538, _nd_0);
      e.mem[_t_1 + 1] = _world_0;
      e.mem[_t_1 + 2] = _world_1;
      e.mem[_t_1 + 3] = _world_2;
      e.mem[_t_1 + 4] = _world_3;
      e.mem[_t_1 + 5] = _world_4;
      e.mem[_t_1 + 6] = _world_5;
      e.mem[_t_1 + 7] = _world_6;
      e.mem[_t_1 + 8] = _world_7;
      e.mem[_t_1 + 9] = _world_8;
      e.mem[_t_1 + 10] = _world_9;
      e.mem[_t_1 + 11] = _world_10;
      e.mem[_t_1 + 12] = _world_11;
      e.mem[_t_1 + 13] = _world_12;
      e.mem[_t_1 + 14] = _world_13;
      e.mem[_t_1 + 15] = _world_14;
      e.mem[_t_1 + 16] = _world_15;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3, _t_1);
    }
    r0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_C538, _nd_0);
    r1 = _world_0;
    r2 = _world_1;
    r3 = _world_2;
    r4 = _world_3;
    r5 = _world_4;
    r6 = _world_5;
    r7 = _world_6;
    r8 = _world_7;
    r9 = _world_8;
    r10 = _world_9;
    r11 = _world_10;
    r12 = _world_11;
    r13 = _world_12;
    r14 = _world_13;
    r15 = _world_14;
    r16 = _world_15;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_C538)
  {
    u32 _handle_2 = r0;
    u32 _handle_3 = r1;
    Term _x_0 = r2;
    WL_OPEN
    Term _fb_0[3];
    u64 _sp_0 = ctr_take(e, _x_0, 3, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    spare_free(e, cls_fit(3), _sp_0);
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
    Term _f_3 = _fb_1[0];
    Term _f_4 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_2[5];
    if (spin_51(e, _o_2, _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_1, blk_loc(e.mem, _f_1), _f_2, blk_loc(e.mem, _f_2), _handle_2, _handle_3) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    _v_1 = _o_2[1];
    _v_2 = _o_2[2];
    _v_3 = _o_2[3];
    _v_4 = _o_2[4];
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_1);
    u64 _nd_2 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_2);
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_3);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_2));
    e.mem[_nd_3 + 1] = rfc_seal(e, _v_4);
    r0 = term_ctr(CID_TUPLE, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K539)
  {
    WL_POPN(2);
    u32 _handle_6 = STK(0);
    u32 _handle_7 = STK(1);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    WL_OPEN
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    u32 _v_56 = 0;
    Term _o_3[18];
    if (spin_42(e, _o_3, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, _h_5, _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, blk_loc(e.mem, _h_11), _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, _h_15, _handle_6, _handle_7) == 0) {
      return 0;
    }
    _v_39 = _o_3[0];
    _v_40 = _o_3[1];
    _v_41 = _o_3[2];
    _v_42 = _o_3[3];
    _v_43 = _o_3[4];
    _v_44 = _o_3[5];
    _v_45 = _o_3[6];
    _v_46 = _o_3[7];
    _v_47 = _o_3[8];
    _v_48 = _o_3[9];
    _v_49 = _o_3[10];
    _v_50 = _o_3[11];
    _v_51 = _o_3[12];
    _v_52 = _o_3[13];
    _v_53 = _o_3[14];
    _v_54 = _o_3[15];
    _v_55 = _o_3[16];
    _v_56 = _o_3[17];
    _v_21 = _v_39;
    _v_22 = _v_40;
    _v_23 = _v_41;
    _v_24 = _v_42;
    _v_25 = _v_43;
    _v_26 = _v_44;
    _v_27 = _v_45;
    _v_28 = _v_46;
    _v_29 = _v_47;
    _v_30 = _v_48;
    _v_31 = _v_49;
    _v_32 = _v_50;
    _v_33 = _v_51;
    _v_34 = _v_52;
    _v_35 = _v_53;
    _v_36 = _v_54;
    _v_37 = _v_55;
    _v_38 = _v_56;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _o_4[12];
    if (spin_33(e, _o_4, _handle_6, _handle_7) == 0) {
      return 0;
    }
    _v_69 = _o_4[0];
    _v_70 = _o_4[1];
    _v_71 = _o_4[2];
    _v_72 = _o_4[3];
    _v_73 = _o_4[4];
    _v_74 = _o_4[5];
    _v_75 = _o_4[6];
    _v_76 = _o_4[7];
    _v_77 = _o_4[8];
    _v_78 = _o_4[9];
    _v_79 = _o_4[10];
    _v_80 = _o_4[11];
    _v_57 = _v_69;
    _v_58 = _v_70;
    _v_59 = _v_71;
    _v_60 = _v_72;
    _v_61 = _v_73;
    _v_62 = _v_74;
    _v_63 = _v_75;
    _v_64 = _v_76;
    _v_65 = _v_77;
    _v_66 = _v_78;
    _v_67 = _v_79;
    _v_68 = _v_80;
    Term _b_0 = 0;
    if (_v_57 == 0) {
      u64 _nd_4 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_4 + 0] = rfc_seal(e, _v_58);
      _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_ORIGINAL, _nd_4);
    } else if (_v_57 == 1) {
      u64 _nd_5 = heap_alloc(e, cls_fit(11));
      e.mem[_nd_5 + 0] = rfc_seal(e, _v_58);
      e.mem[_nd_5 + 1] = rfc_seal(e, _v_59);
      e.mem[_nd_5 + 2] = rfc_seal(e, _v_60);
      e.mem[_nd_5 + 3] = rfc_seal(e, _v_61);
      e.mem[_nd_5 + 4] = rfc_seal(e, _v_62);
      e.mem[_nd_5 + 5] = rfc_seal(e, _v_63);
      e.mem[_nd_5 + 6] = rfc_seal(e, _v_64);
      e.mem[_nd_5 + 7] = rfc_seal(e, _v_65);
      e.mem[_nd_5 + 8] = rfc_seal(e, _v_66);
      e.mem[_nd_5 + 9] = rfc_seal(e, _v_67);
      e.mem[_nd_5 + 10] = rfc_seal(e, _v_68);
      _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_RELATIONFAILED, _nd_5);
    } else if (_v_57 == 2) {
      _b_0 = term_pak(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_COMPONENTREMOVED, _v_58);
    } else {
      u64 _nd_6 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_6 + 0] = rfc_seal(e, _v_58);
      _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_CLEANUPPAUSED, _nd_6);
    }
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_7 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(17);
      STK(0) = _v_21;
      STK(1) = _v_22;
      STK(2) = _v_23;
      STK(3) = _v_24;
      STK(4) = _v_25;
      STK(5) = _v_26;
      STK(6) = _v_27;
      STK(7) = _v_28;
      STK(8) = _v_29;
      STK(9) = _v_30;
      STK(10) = _v_31;
      STK(11) = _v_32;
      STK(12) = _v_33;
      STK(13) = _v_34;
      STK(14) = _v_35;
      STK(15) = _v_36;
      STK(16) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K540;
      WL_PUSHN(17);
    } else {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K540, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _v_21;
      e.mem[_t_2 + 1] = _v_22;
      e.mem[_t_2 + 2] = _v_23;
      e.mem[_t_2 + 3] = _v_24;
      e.mem[_t_2 + 4] = _v_25;
      e.mem[_t_2 + 5] = _v_26;
      e.mem[_t_2 + 6] = _v_27;
      e.mem[_t_2 + 7] = _v_28;
      e.mem[_t_2 + 8] = _v_29;
      e.mem[_t_2 + 9] = _v_30;
      e.mem[_t_2 + 10] = _v_31;
      e.mem[_t_2 + 11] = _v_32;
      e.mem[_t_2 + 12] = _v_33;
      e.mem[_t_2 + 13] = _v_34;
      e.mem[_t_2 + 14] = _v_35;
      e.mem[_t_2 + 15] = _v_36;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K540, _t_2);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_3 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_16;
      e.mem[_t_3 + 1] = term_ctr(CID_CON, _nd_7);
      return term_tsk(FID_LIST_APPEND, _t_3);
    }
    r0 = _h_16;
    r1 = term_ctr(CID_CON, _nd_7);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0_K540)
  {
    WL_POPN(16);
    u32 _v_81 = STK(0);
    u32 _v_82 = STK(1);
    u32 _v_83 = STK(2);
    Term _v_84 = STK(3);
    u32 _v_85 = STK(4);
    Term _v_86 = STK(5);
    Term _v_87 = STK(6);
    Term _v_88 = STK(7);
    Term _v_89 = STK(8);
    Term _v_90 = STK(9);
    Term _v_91 = STK(10);
    Term _v_92 = STK(11);
    Term _v_93 = STK(12);
    Term _v_94 = STK(13);
    u32 _v_95 = STK(14);
    u32 _v_96 = STK(15);
    Term _h_17 = r0;
    WL_OPEN
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    Term _v_100 = 0;
    u32 _v_101 = 0;
    Term _v_102 = 0;
    Term _v_103 = 0;
    Term _v_104 = 0;
    Term _v_105 = 0;
    Term _v_106 = 0;
    Term _v_107 = 0;
    Term _v_108 = 0;
    Term _v_109 = 0;
    Term _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    Term _o_5[16];
    if (spin_29(e, _o_5, _v_81, _v_82, _v_83, _v_84, blk_loc(e.mem, _v_84), _v_85, _v_86, _v_87, blk_loc(e.mem, _v_87), _v_88, blk_loc(e.mem, _v_88), _v_89, blk_loc(e.mem, _v_89), _v_90, blk_loc(e.mem, _v_90), _v_91, blk_loc(e.mem, _v_91), _v_92, blk_loc(e.mem, _v_92), _v_93, blk_loc(e.mem, _v_93), _v_94, blk_loc(e.mem, _v_94), _v_95, _v_96, _h_17, blk_loc(e.mem, _h_17)) == 0) {
      return 0;
    }
    _v_97 = _o_5[0];
    _v_98 = _o_5[1];
    _v_99 = _o_5[2];
    _v_100 = _o_5[3];
    _v_101 = _o_5[4];
    _v_102 = _o_5[5];
    _v_103 = _o_5[6];
    _v_104 = _o_5[7];
    _v_105 = _o_5[8];
    _v_106 = _o_5[9];
    _v_107 = _o_5[10];
    _v_108 = _o_5[11];
    _v_109 = _o_5[12];
    _v_110 = _o_5[13];
    _v_111 = _o_5[14];
    _v_112 = _o_5[15];
    r0 = _v_97;
    r1 = _v_98;
    r2 = _v_99;
    r3 = _v_100;
    r4 = _v_101;
    r5 = _v_102;
    r6 = _v_103;
    r7 = _v_104;
    r8 = _v_105;
    r9 = _v_106;
    r10 = _v_107;
    r11 = _v_108;
    r12 = _v_109;
    r13 = _v_110;
    r14 = _v_111;
    r15 = _v_112;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    Term _world_10 = r10;
    Term _world_11 = r11;
    Term _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _descriptor_0 = r16;
    Term _descriptor_1 = r17;
    Term _descriptor_2 = r18;
    u32 _descriptor_3 = r19;
    u32 _source_0 = r20;
    u32 _source_1 = r21;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_0 + 0] = _descriptor_0;
    e.mem[_nd_0 + 1] = _descriptor_1;
    e.mem[_nd_0 + 2] = _descriptor_2;
    e.mem[_nd_0 + 3] = _descriptor_3;
    e.mem[_nd_0 + 4] = _source_1;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K547;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K547, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K547, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2)) {
      u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_C545, _nd_0);
      e.mem[_t_3 + 1] = _world_0;
      e.mem[_t_3 + 2] = _world_1;
      e.mem[_t_3 + 3] = _world_2;
      e.mem[_t_3 + 4] = _world_3;
      e.mem[_t_3 + 5] = _world_4;
      e.mem[_t_3 + 6] = _world_5;
      e.mem[_t_3 + 7] = _world_6;
      e.mem[_t_3 + 8] = _world_7;
      e.mem[_t_3 + 9] = _world_8;
      e.mem[_t_3 + 10] = _world_9;
      e.mem[_t_3 + 11] = _world_10;
      e.mem[_t_3 + 12] = _world_11;
      e.mem[_t_3 + 13] = _world_12;
      e.mem[_t_3 + 14] = _world_13;
      e.mem[_t_3 + 15] = _world_14;
      e.mem[_t_3 + 16] = _world_15;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2, _t_3);
    }
    r0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_C545, _nd_0);
    r1 = _world_0;
    r2 = _world_1;
    r3 = _world_2;
    r4 = _world_3;
    r5 = _world_4;
    r6 = _world_5;
    r7 = _world_6;
    r8 = _world_7;
    r9 = _world_8;
    r10 = _world_9;
    r11 = _world_10;
    r12 = _world_11;
    r13 = _world_12;
    r14 = _world_13;
    r15 = _world_14;
    r16 = _world_15;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_C545)
  {
    u32 _descriptor_4 = r0;
    Term _descriptor_5 = r1;
    Term _descriptor_6 = r2;
    u32 _descriptor_7 = r3;
    u32 _source_2 = r4;
    Term _x_0 = r5;
    WL_OPEN
    Term _fb_0[3];
    u64 _sp_0 = ctr_take(e, _x_0, 3, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    spare_free(e, cls_fit(3), _sp_0);
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
    Term _f_3 = _fb_1[0];
    Term _f_4 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _f_3;
      STK(1) = _f_4;
      STK(2) = FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K546;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K546, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _f_3;
      e.mem[_t_0 + 1] = _f_4;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K546, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _f_2;
      e.mem[_t_1 + 2] = _descriptor_4;
      e.mem[_t_1 + 3] = _descriptor_5;
      e.mem[_t_1 + 4] = _descriptor_6;
      e.mem[_t_1 + 5] = _descriptor_7;
      e.mem[_t_1 + 6] = _source_2;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0, _t_1);
    }
    r0 = _f_1;
    r1 = _f_2;
    r2 = _descriptor_4;
    r3 = _descriptor_5;
    r4 = _descriptor_6;
    r5 = _descriptor_7;
    r6 = _source_2;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_UNRELATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K546)
  {
    WL_POPN(2);
    Term _f_5 = STK(0);
    Term _f_6 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _f_5);
    e.mem[_nd_1 + 1] = rfc_seal(e, _f_6);
    u64 _nd_2 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, _h_0);
    e.mem[_nd_2 + 2] = rfc_seal(e, _h_1);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_2));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_pak(CID_UNIT, 0));
    r0 = term_ctr(CID_TUPLE, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0_K547)
  {
    u32 _h_2 = r0;
    u32 _h_3 = r1;
    u32 _h_4 = r2;
    Term _h_5 = r3;
    u32 _h_6 = r4;
    Term _h_7 = r5;
    Term _h_8 = r6;
    Term _h_9 = r7;
    Term _h_10 = r8;
    Term _h_11 = r9;
    Term _h_12 = r10;
    Term _h_13 = r11;
    Term _h_14 = r12;
    Term _h_15 = r13;
    u32 _h_16 = r14;
    u32 _h_17 = r15;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _o_0[16];
    if (spin_52(e, _o_0, _h_2, _h_3, _h_4, _h_5, blk_loc(e.mem, _h_5), _h_6, _h_7, _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, blk_loc(e.mem, _h_11), _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, blk_loc(e.mem, _h_15), _h_16, _h_17) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1)
  {
    Term _effect_0 = r0;
    u32 _world_0 = r1;
    u32 _world_1 = r2;
    u32 _world_2 = r3;
    Term _world_3 = r4;
    u32 _world_4 = r5;
    Term _world_5 = r6;
    Term _world_6 = r7;
    Term _world_7 = r8;
    Term _world_8 = r9;
    Term _world_9 = r10;
    Term _world_10 = r11;
    Term _world_11 = r12;
    Term _world_12 = r13;
    Term _world_13 = r14;
    u32 _world_14 = r15;
    u32 _world_15 = r16;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _world_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, _world_7);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _world_8);
    e.mem[_nd_1 + 2] = rfc_seal(e, _world_9);
    if (seq) {
      WL_ROOM(13);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_10;
      STK(7) = _world_11;
      STK(8) = _world_12;
      STK(9) = _world_13;
      STK(10) = _world_14;
      STK(11) = _world_15;
      STK(12) = FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1_K551;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1_K551, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_10;
      e.mem[_t_0 + 7] = _world_11;
      e.mem[_t_0 + 8] = _world_12;
      e.mem[_t_0 + 9] = _world_13;
      e.mem[_t_0 + 10] = _world_14;
      e.mem[_t_0 + 11] = _world_15;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1_K551, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _effect_0;
      e.mem[_t_1 + 1] = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _effect_0;
    r1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1_K551)
  {
    WL_POPN(12);
    u32 _world_16 = STK(0);
    u32 _world_17 = STK(1);
    u32 _world_18 = STK(2);
    Term _world_19 = STK(3);
    u32 _world_20 = STK(4);
    Term _world_21 = STK(5);
    Term _world_22 = STK(6);
    Term _world_23 = STK(7);
    Term _world_24 = STK(8);
    Term _world_25 = STK(9);
    u32 _world_26 = STK(10);
    u32 _world_27 = STK(11);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[3];
    u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
    Term _f_2 = _fb_1[0];
    Term _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_1);
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _f_2, 2, _fb_2);
    Term _f_5 = _fb_2[0];
    Term _f_6 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _o_0[17];
    if (spin_53(e, _o_0, _f_5, blk_loc(e.mem, _f_5), _f_6, blk_loc(e.mem, _f_6), _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_1, blk_loc(e.mem, _f_1), _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, _world_21, _world_22, blk_loc(e.mem, _world_22), _world_23, blk_loc(e.mem, _world_23), _world_24, blk_loc(e.mem, _world_24), _world_25, blk_loc(e.mem, _world_25), _world_26, _world_27) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_6)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      Term _o_4 = 0;
      u32 _o_5 = 0;
      Term _o_6 = 0;
      Term _o_7 = 0;
      if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPENTER) {
        _o_0 = 0;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPDESCRIPTORS) {
        _o_0 = 1;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPCHILDREN) {
        _o_0 = 2;
        Term _fb_2[7];
        u64 _sp_2 = ctr_take(e, _f_0, 7, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        Term _f_6 = _fb_2[2];
        Term _f_7 = _fb_2[3];
        u32 _f_8 = _fb_2[4];
        Term _f_9 = _fb_2[5];
        Term _f_10 = _fb_2[6];
        spare_free(e, cls_fit(7), _sp_2);
        _o_1 = _f_4;
        _o_2 = _f_5;
        _o_3 = _f_6;
        _o_4 = _f_7;
        _o_5 = _f_8;
        _o_6 = _f_9;
        _o_7 = _f_10;
      } else {
        _o_0 = 3;
        _o_1 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_6_K556;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_6_K556, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_6_K556, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_FRAME_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_SHOW_FRAME_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        e.mem[_t_1 + 5] = _o_5;
        e.mem[_t_1 + 6] = _o_6;
        e.mem[_t_1 + 7] = _o_7;
        return term_tsk(FID_CONSUMER_SHOW_FRAME_0, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      r5 = _o_5;
      r6 = _o_6;
      r7 = _o_7;
      WL_JMP(FID_CONSUMER_SHOW_FRAME_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_6_K556)
  {
    WL_POPN(1);
    Term _f_11 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_6_K557;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_6_K557, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_6_K557, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_7)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_7, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_11;
      return term_tsk(FID_LIST_SHOW_GO_7, _t_3);
    }
    r0 = _f_11;
    WL_JMP(FID_LIST_SHOW_GO_7);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_6_K557)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_6_K558;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_6_K558, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_6_K558, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_6_K558)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 32);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    Term _world_10 = r10;
    Term _world_11 = r11;
    Term _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_10;
      STK(11) = _world_11;
      STK(12) = _world_13;
      STK(13) = _world_14;
      STK(14) = _world_15;
      STK(15) = FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K560;
      WL_PUSHN(16);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K560, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _world_11;
      e.mem[_t_0 + 12] = _world_13;
      e.mem[_t_0 + 13] = _world_14;
      e.mem[_t_0 + 14] = _world_15;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K560, _t_0);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_12;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0, _t_1);
    }
    r0 = _world_12;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_PENDING_LENGTH_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0_K560)
  {
    WL_POPN(15);
    u32 _world_16 = STK(0);
    u32 _world_17 = STK(1);
    u32 _world_18 = STK(2);
    Term _world_19 = STK(3);
    u32 _world_20 = STK(4);
    Term _world_21 = STK(5);
    Term _world_22 = STK(6);
    Term _world_23 = STK(7);
    Term _world_24 = STK(8);
    Term _world_25 = STK(9);
    Term _world_26 = STK(10);
    Term _world_27 = STK(11);
    Term _world_28 = STK(12);
    u32 _world_29 = STK(13);
    u32 _world_30 = STK(14);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    Term _o_0[17];
    if (spin_54(e, _o_0, _world_16, _world_17, _world_18, _world_19, blk_loc(e.mem, _world_19), _world_20, _world_21, _world_22, blk_loc(e.mem, _world_22), _world_23, blk_loc(e.mem, _world_23), _world_24, blk_loc(e.mem, _world_24), _world_25, blk_loc(e.mem, _world_25), _world_26, blk_loc(e.mem, _world_26), _world_27, blk_loc(e.mem, _world_27), _world_28, blk_loc(e.mem, _world_28), _world_29, _world_30, _h_0, blk_loc(e.mem, _h_0), _h_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_DONE_0)
  {
    u32 _observed_0 = r0;
    u32 _observed_1 = r1;
    u32 _observed_2 = r2;
    u32 _observed_3 = r3;
    Term _observed_4 = r4;
    u32 _observed_5 = r5;
    Term _observed_6 = r6;
    Term _observed_7 = r7;
    Term _observed_8 = r8;
    Term _observed_9 = r9;
    Term _observed_10 = r10;
    Term _observed_11 = r11;
    Term _observed_12 = r12;
    Term _observed_13 = r13;
    Term _observed_14 = r14;
    u32 _observed_15 = r15;
    u32 _observed_16 = r16;
    Term _observed_17 = r17;
    Term _observed_18 = r18;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _observed_18;
      STK(1) = FID_CONSUMER_DONE_0_K606;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_DONE_0_K606, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _observed_18;
      WL_CONT = term_tsk(FID_CONSUMER_DONE_0_K606, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_FINAL_BARRIER_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_FINAL_BARRIER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _observed_0;
      e.mem[_t_1 + 1] = _observed_1;
      e.mem[_t_1 + 2] = _observed_2;
      e.mem[_t_1 + 3] = _observed_3;
      e.mem[_t_1 + 4] = _observed_4;
      e.mem[_t_1 + 5] = _observed_5;
      e.mem[_t_1 + 6] = _observed_6;
      e.mem[_t_1 + 7] = _observed_7;
      e.mem[_t_1 + 8] = _observed_8;
      e.mem[_t_1 + 9] = _observed_9;
      e.mem[_t_1 + 10] = _observed_10;
      e.mem[_t_1 + 11] = _observed_11;
      e.mem[_t_1 + 12] = _observed_12;
      e.mem[_t_1 + 13] = _observed_13;
      e.mem[_t_1 + 14] = _observed_14;
      e.mem[_t_1 + 15] = _observed_15;
      e.mem[_t_1 + 16] = _observed_16;
      e.mem[_t_1 + 17] = _observed_17;
      return term_tsk(FID_CONSUMER_FINAL_BARRIER_0, _t_1);
    }
    r0 = _observed_0;
    r1 = _observed_1;
    r2 = _observed_2;
    r3 = _observed_3;
    r4 = _observed_4;
    r5 = _observed_5;
    r6 = _observed_6;
    r7 = _observed_7;
    r8 = _observed_8;
    r9 = _observed_9;
    r10 = _observed_10;
    r11 = _observed_11;
    r12 = _observed_12;
    r13 = _observed_13;
    r14 = _observed_14;
    r15 = _observed_15;
    r16 = _observed_16;
    r17 = _observed_17;
    WL_JMP(FID_CONSUMER_FINAL_BARRIER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_DONE_0_K606)
  {
    WL_POPN(1);
    Term _observed_19 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    Term _h_17 = r17;
    Term _h_18 = r18;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _observed_19;
      STK(1) = FID_CONSUMER_DONE_0_K607;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_DONE_0_K607, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _observed_19;
      WL_CONT = term_tsk(FID_CONSUMER_DONE_0_K607, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_LAST_0)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_LAST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      e.mem[_t_3 + 10] = _h_10;
      e.mem[_t_3 + 11] = _h_11;
      e.mem[_t_3 + 12] = _h_12;
      e.mem[_t_3 + 13] = _h_13;
      e.mem[_t_3 + 14] = _h_14;
      e.mem[_t_3 + 15] = _h_15;
      e.mem[_t_3 + 16] = _h_16;
      e.mem[_t_3 + 17] = _h_17;
      e.mem[_t_3 + 18] = _h_18;
      return term_tsk(FID_CONSUMER_LAST_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = _h_16;
    r17 = _h_17;
    r18 = _h_18;
    WL_JMP(FID_CONSUMER_LAST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_DONE_0_K607)
  {
    WL_POPN(1);
    Term _observed_20 = STK(0);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _observed_20;
      STK(1) = FID_CONSUMER_DONE_0_K608;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_DONE_0_K608, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _observed_20;
      WL_CONT = term_tsk(FID_CONSUMER_DONE_0_K608, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 344);
      e.mem[_t_5 + 1] = _h_19;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 344);
    r1 = _h_19;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_DONE_0_K608)
  {
    WL_POPN(1);
    Term _observed_21 = STK(0);
    Term _h_20 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _observed_21;
      e.mem[_t_6 + 1] = _h_20;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = _observed_21;
    r1 = _h_20;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    Term _world_10 = r10;
    Term _world_11 = r11;
    Term _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    u32 _descriptor_0 = r16;
    Term _descriptor_1 = r17;
    Term _descriptor_2 = r18;
    u32 _descriptor_3 = r19;
    u32 _source_0 = r20;
    u32 _source_1 = r21;
    u32 _target_0 = r22;
    u32 _target_1 = r23;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _o_0[17];
    if (spin_49(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, blk_loc(e.mem, _world_10), _world_11, blk_loc(e.mem, _world_11), _world_12, blk_loc(e.mem, _world_12), _world_13, blk_loc(e.mem, _world_13), _world_14, _world_15, _source_0, _source_1) == 0) {
      return 0;
    }
    _v_17 = _o_0[0];
    _v_18 = _o_0[1];
    _v_19 = _o_0[2];
    _v_20 = _o_0[3];
    _v_21 = _o_0[4];
    _v_22 = _o_0[5];
    _v_23 = _o_0[6];
    _v_24 = _o_0[7];
    _v_25 = _o_0[8];
    _v_26 = _o_0[9];
    _v_27 = _o_0[10];
    _v_28 = _o_0[11];
    _v_29 = _o_0[12];
    _v_30 = _o_0[13];
    _v_31 = _o_0[14];
    _v_32 = _o_0[15];
    _v_33 = _o_0[16];
    _v_0 = _v_17;
    _v_1 = _v_18;
    _v_2 = _v_19;
    _v_3 = _v_20;
    _v_4 = _v_21;
    _v_5 = _v_22;
    _v_6 = _v_23;
    _v_7 = _v_24;
    _v_8 = _v_25;
    _v_9 = _v_26;
    _v_10 = _v_27;
    _v_11 = _v_28;
    _v_12 = _v_29;
    _v_13 = _v_30;
    _v_14 = _v_31;
    _v_15 = _v_32;
    _v_16 = _v_33;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    u32 _v_66 = 0;
    u32 _v_67 = 0;
    Term _o_1[17];
    if (spin_49(e, _o_1, _v_0, _v_1, _v_2, _v_3, blk_loc(e.mem, _v_3), _v_4, _v_5, _v_6, blk_loc(e.mem, _v_6), _v_7, blk_loc(e.mem, _v_7), _v_8, blk_loc(e.mem, _v_8), _v_9, blk_loc(e.mem, _v_9), _v_10, blk_loc(e.mem, _v_10), _v_11, blk_loc(e.mem, _v_11), _v_12, blk_loc(e.mem, _v_12), _v_13, blk_loc(e.mem, _v_13), _v_14, _v_15, _target_0, _target_1) == 0) {
      return 0;
    }
    _v_51 = _o_1[0];
    _v_52 = _o_1[1];
    _v_53 = _o_1[2];
    _v_54 = _o_1[3];
    _v_55 = _o_1[4];
    _v_56 = _o_1[5];
    _v_57 = _o_1[6];
    _v_58 = _o_1[7];
    _v_59 = _o_1[8];
    _v_60 = _o_1[9];
    _v_61 = _o_1[10];
    _v_62 = _o_1[11];
    _v_63 = _o_1[12];
    _v_64 = _o_1[13];
    _v_65 = _o_1[14];
    _v_66 = _o_1[15];
    _v_67 = _o_1[16];
    _v_34 = _v_51;
    _v_35 = _v_52;
    _v_36 = _v_53;
    _v_37 = _v_54;
    _v_38 = _v_55;
    _v_39 = _v_56;
    _v_40 = _v_57;
    _v_41 = _v_58;
    _v_42 = _v_59;
    _v_43 = _v_60;
    _v_44 = _v_61;
    _v_45 = _v_62;
    _v_46 = _v_63;
    _v_47 = _v_64;
    _v_48 = _v_65;
    _v_49 = _v_66;
    _v_50 = _v_67;
    _descriptor_1 = term_keep(e, _descriptor_1, 1);
    _descriptor_2 = term_keep(e, _descriptor_2, 1);
    u64 _nd_0 = heap_alloc(e, cls_fit(8));
    e.mem[_nd_0 + 0] = _v_50;
    e.mem[_nd_0 + 1] = _descriptor_0;
    e.mem[_nd_0 + 2] = _descriptor_1;
    e.mem[_nd_0 + 3] = _descriptor_2;
    e.mem[_nd_0 + 4] = _descriptor_3;
    e.mem[_nd_0 + 5] = _source_1;
    e.mem[_nd_0 + 6] = _target_1;
    e.mem[_nd_0 + 7] = _v_16;
    if (seq) {
      WL_ROOM(7);
      STK(0) = _descriptor_0;
      STK(1) = _descriptor_1;
      STK(2) = _descriptor_2;
      STK(3) = _descriptor_3;
      STK(4) = _source_1;
      STK(5) = _target_1;
      STK(6) = FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K616;
      WL_PUSHN(7);
    } else {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K616, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _descriptor_0;
      e.mem[_t_2 + 1] = _descriptor_1;
      e.mem[_t_2 + 2] = _descriptor_2;
      e.mem[_t_2 + 3] = _descriptor_3;
      e.mem[_t_2 + 4] = _source_1;
      e.mem[_t_2 + 5] = _target_1;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K616, _t_2);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4)) {
      u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_C614, _nd_0);
      e.mem[_t_3 + 1] = _v_34;
      e.mem[_t_3 + 2] = _v_35;
      e.mem[_t_3 + 3] = _v_36;
      e.mem[_t_3 + 4] = _v_37;
      e.mem[_t_3 + 5] = _v_38;
      e.mem[_t_3 + 6] = _v_39;
      e.mem[_t_3 + 7] = _v_40;
      e.mem[_t_3 + 8] = _v_41;
      e.mem[_t_3 + 9] = _v_42;
      e.mem[_t_3 + 10] = _v_43;
      e.mem[_t_3 + 11] = _v_44;
      e.mem[_t_3 + 12] = _v_45;
      e.mem[_t_3 + 13] = _v_46;
      e.mem[_t_3 + 14] = _v_47;
      e.mem[_t_3 + 15] = _v_48;
      e.mem[_t_3 + 16] = _v_49;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4, _t_3);
    }
    r0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_C614, _nd_0);
    r1 = _v_34;
    r2 = _v_35;
    r3 = _v_36;
    r4 = _v_37;
    r5 = _v_38;
    r6 = _v_39;
    r7 = _v_40;
    r8 = _v_41;
    r9 = _v_42;
    r10 = _v_43;
    r11 = _v_44;
    r12 = _v_45;
    r13 = _v_46;
    r14 = _v_47;
    r15 = _v_48;
    r16 = _v_49;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_C614)
  {
    u32 _v_68 = r0;
    u32 _descriptor_4 = r1;
    Term _descriptor_5 = r2;
    Term _descriptor_6 = r3;
    u32 _descriptor_7 = r4;
    u32 _source_2 = r5;
    u32 _target_2 = r6;
    u32 _v_69 = r7;
    Term _x_0 = r8;
    WL_OPEN
    Term _fb_0[3];
    u64 _sp_0 = ctr_take(e, _x_0, 3, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    spare_free(e, cls_fit(3), _sp_0);
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
    Term _f_3 = _fb_1[0];
    Term _f_4 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _f_3;
      STK(1) = _f_4;
      STK(2) = FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K615;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K615, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _f_3;
      e.mem[_t_0 + 1] = _f_4;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K615, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _f_2;
      e.mem[_t_1 + 2] = _descriptor_4;
      e.mem[_t_1 + 3] = _descriptor_5;
      e.mem[_t_1 + 4] = _descriptor_6;
      e.mem[_t_1 + 5] = _descriptor_7;
      e.mem[_t_1 + 6] = _source_2;
      e.mem[_t_1 + 7] = _target_2;
      e.mem[_t_1 + 8] = _v_69;
      e.mem[_t_1 + 9] = _v_68;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0, _t_1);
    }
    r0 = _f_1;
    r1 = _f_2;
    r2 = _descriptor_4;
    r3 = _descriptor_5;
    r4 = _descriptor_6;
    r5 = _descriptor_7;
    r6 = _source_2;
    r7 = _target_2;
    r8 = _v_69;
    r9 = _v_68;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_RELATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K615)
  {
    WL_POPN(2);
    Term _f_5 = STK(0);
    Term _f_6 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    WL_OPEN
    Term _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    Term _o_2[9];
    if (spin_27(e, _o_2, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, _h_3, _h_4, _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _f_5, blk_loc(e.mem, _f_5), _f_6, blk_loc(e.mem, _f_6)) == 0) {
      return 0;
    }
    _v_70 = _o_2[0];
    _v_71 = _o_2[1];
    _v_72 = _o_2[2];
    _v_73 = _o_2[3];
    _v_74 = _o_2[4];
    _v_75 = _o_2[5];
    _v_76 = _o_2[6];
    _v_77 = _o_2[7];
    _v_78 = _o_2[8];
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_70);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_71);
    u64 _nd_2 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_72);
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_73);
    Term _b_0 = 0;
    if (_v_74 == 0) {
      _b_0 = term_pak(CID_NONE, 0);
    } else {
      Term _b_1 = 0;
      if (_v_75 == 0) {
        _b_1 = term_pak(CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGENTITY, _v_76);
      } else if (_v_75 == 1) {
        u64 _nd_3 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_3 + 0] = rfc_seal(e, _v_76);
        e.mem[_nd_3 + 1] = rfc_seal(e, _v_77);
        e.mem[_nd_3 + 2] = rfc_seal(e, _v_78);
        _b_1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGTARGETENTITY, _nd_3);
      } else if (_v_75 == 2) {
        u64 _nd_4 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_4 + 0] = rfc_seal(e, _v_76);
        e.mem[_nd_4 + 1] = rfc_seal(e, _v_77);
        _b_1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_SELFRELATIONNOTALLOWED, _nd_4);
      } else if (_v_75 == 3) {
        u64 _nd_5 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_5 + 0] = rfc_seal(e, _v_76);
        e.mem[_nd_5 + 1] = rfc_seal(e, _v_77);
        e.mem[_nd_5 + 2] = rfc_seal(e, _v_78);
        _b_1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_HIERARCHYCYCLE, _nd_5);
      } else if (_v_75 == 4) {
        u64 _nd_6 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_6 + 0] = rfc_seal(e, _v_76);
        e.mem[_nd_6 + 1] = rfc_seal(e, _v_77);
        e.mem[_nd_6 + 2] = rfc_seal(e, _v_78);
        _b_1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_MISSINGCHILDENTITY, _nd_6);
      } else if (_v_75 == 5) {
        u64 _nd_7 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_7 + 0] = rfc_seal(e, _v_76);
        e.mem[_nd_7 + 1] = rfc_seal(e, _v_77);
        e.mem[_nd_7 + 2] = rfc_seal(e, _v_78);
        _b_1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_DUPLICATECHILD, _nd_7);
      } else if (_v_75 == 6) {
        u64 _nd_8 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_8 + 0] = rfc_seal(e, _v_76);
        e.mem[_nd_8 + 1] = rfc_seal(e, _v_77);
        e.mem[_nd_8 + 2] = rfc_seal(e, _v_78);
        _b_1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CHILDNOTRELATEDTOPARENT, _nd_8);
      } else {
        u64 _nd_9 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_9 + 0] = rfc_seal(e, _v_76);
        e.mem[_nd_9 + 1] = rfc_seal(e, _v_77);
        _b_1 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CHILDSETMISMATCH, _nd_9);
      }
      u64 _nd_10 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_10 + 0] = rfc_seal(e, _b_1);
      _b_0 = term_ctr(CID_SOME, _nd_10);
    }
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_2));
    e.mem[_nd_11 + 1] = rfc_seal(e, _b_0);
    r0 = term_ctr(CID_TUPLE, _nd_11);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0_K616)
  {
    WL_POPN(6);
    u32 _descriptor_8 = STK(0);
    Term _descriptor_9 = STK(1);
    Term _descriptor_10 = STK(2);
    u32 _descriptor_11 = STK(3);
    u32 _source_3 = STK(4);
    u32 _target_3 = STK(5);
    u32 _h_7 = r0;
    u32 _h_8 = r1;
    u32 _h_9 = r2;
    Term _h_10 = r3;
    u32 _h_11 = r4;
    Term _h_12 = r5;
    Term _h_13 = r6;
    Term _h_14 = r7;
    Term _h_15 = r8;
    Term _h_16 = r9;
    Term _h_17 = r10;
    Term _h_18 = r11;
    Term _h_19 = r12;
    Term _h_20 = r13;
    u32 _h_21 = r14;
    u32 _h_22 = r15;
    u32 _h_23 = r16;
    u32 _h_24 = r17;
    u32 _h_25 = r18;
    Term _h_26 = r19;
    Term _h_27 = r20;
    WL_OPEN
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _v_82 = 0;
    u32 _v_83 = 0;
    Term _v_84 = 0;
    Term _v_85 = 0;
    Term _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    Term _o_3[16];
    if (spin_38(e, _o_3, _h_7, _h_8, _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, blk_loc(e.mem, _h_15), _h_16, blk_loc(e.mem, _h_16), _h_17, blk_loc(e.mem, _h_17), _h_18, blk_loc(e.mem, _h_18), _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20), _h_21, _h_22, _h_23, _h_24, _h_25, _h_26, blk_loc(e.mem, _h_26), _h_27, blk_loc(e.mem, _h_27), _descriptor_8, _descriptor_9, blk_loc(e.mem, _descriptor_9), _descriptor_10, blk_loc(e.mem, _descriptor_10), _descriptor_11, _source_3, _target_3) == 0) {
      return 0;
    }
    _v_79 = _o_3[0];
    _v_80 = _o_3[1];
    _v_81 = _o_3[2];
    _v_82 = _o_3[3];
    _v_83 = _o_3[4];
    _v_84 = _o_3[5];
    _v_85 = _o_3[6];
    _v_86 = _o_3[7];
    _v_87 = _o_3[8];
    _v_88 = _o_3[9];
    _v_89 = _o_3[10];
    _v_90 = _o_3[11];
    _v_91 = _o_3[12];
    _v_92 = _o_3[13];
    _v_93 = _o_3[14];
    _v_94 = _o_3[15];
    r0 = _v_79;
    r1 = _v_80;
    r2 = _v_81;
    r3 = _v_82;
    r4 = _v_83;
    r5 = _v_84;
    r6 = _v_85;
    r7 = _v_86;
    r8 = _v_87;
    r9 = _v_88;
    r10 = _v_89;
    r11 = _v_90;
    r12 = _v_91;
    r13 = _v_92;
    r14 = _v_93;
    r15 = _v_94;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0)
  {
    u32 _frame_0 = r0;
    u32 _frame_1 = r1;
    Term _frame_2 = r2;
    Term _frame_3 = r3;
    Term _frame_4 = r4;
    u32 _frame_5 = r5;
    Term _frame_6 = r6;
    Term _frame_7 = r7;
    u32 _world_0 = r8;
    u32 _world_1 = r9;
    u32 _world_2 = r10;
    Term _world_3 = r11;
    u32 _world_4 = r12;
    Term _world_5 = r13;
    Term _world_6 = r14;
    Term _world_7 = r15;
    Term _world_8 = r16;
    Term _world_9 = r17;
    Term _world_10 = r18;
    Term _world_11 = r19;
    Term _world_12 = r20;
    Term _world_13 = r21;
    u32 _world_14 = r22;
    u32 _world_15 = r23;
    u32 _namespace_0 = r24;
    Term _descriptors_0 = r25;
    Term _frames_0 = r26;
    WL_OPEN
    if (_frame_0 == 0) {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      Term _v_3 = 0;
      u32 _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _v_7 = 0;
      Term _v_8 = 0;
      Term _v_9 = 0;
      Term _v_10 = 0;
      Term _v_11 = 0;
      Term _v_12 = 0;
      Term _v_13 = 0;
      u32 _v_14 = 0;
      u32 _v_15 = 0;
      u32 _v_16 = 0;
      u32 _v_17 = 0;
      u32 _v_18 = 0;
      u32 _v_19 = 0;
      Term _v_20 = 0;
      u32 _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _v_26 = 0;
      Term _v_27 = 0;
      Term _v_28 = 0;
      Term _v_29 = 0;
      Term _v_30 = 0;
      u32 _v_31 = 0;
      u32 _v_32 = 0;
      u32 _v_33 = 0;
      Term _o_0[17];
      if (spin_49(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, blk_loc(e.mem, _world_9), _world_10, blk_loc(e.mem, _world_10), _world_11, blk_loc(e.mem, _world_11), _world_12, blk_loc(e.mem, _world_12), _world_13, blk_loc(e.mem, _world_13), _world_14, _world_15, _namespace_0, _frame_1) == 0) {
        return 0;
      }
      _v_17 = _o_0[0];
      _v_18 = _o_0[1];
      _v_19 = _o_0[2];
      _v_20 = _o_0[3];
      _v_21 = _o_0[4];
      _v_22 = _o_0[5];
      _v_23 = _o_0[6];
      _v_24 = _o_0[7];
      _v_25 = _o_0[8];
      _v_26 = _o_0[9];
      _v_27 = _o_0[10];
      _v_28 = _o_0[11];
      _v_29 = _o_0[12];
      _v_30 = _o_0[13];
      _v_31 = _o_0[14];
      _v_32 = _o_0[15];
      _v_33 = _o_0[16];
      _v_0 = _v_17;
      _v_1 = _v_18;
      _v_2 = _v_19;
      _v_3 = _v_20;
      _v_4 = _v_21;
      _v_5 = _v_22;
      _v_6 = _v_23;
      _v_7 = _v_24;
      _v_8 = _v_25;
      _v_9 = _v_26;
      _v_10 = _v_27;
      _v_11 = _v_28;
      _v_12 = _v_29;
      _v_13 = _v_30;
      _v_14 = _v_31;
      _v_15 = _v_32;
      _v_16 = _v_33;
      u32 _v_34 = 0;
      u32 _v_35 = 0;
      u32 _v_36 = 0;
      Term _v_37 = 0;
      u32 _v_38 = 0;
      Term _v_39 = 0;
      Term _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      Term _v_50 = 0;
      Term _o_1[17];
      if (spin_56(e, _o_1, _v_0, _v_1, _v_2, _v_3, blk_loc(e.mem, _v_3), _v_4, _v_5, _v_6, blk_loc(e.mem, _v_6), _v_7, blk_loc(e.mem, _v_7), _v_8, blk_loc(e.mem, _v_8), _v_9, blk_loc(e.mem, _v_9), _v_10, blk_loc(e.mem, _v_10), _v_11, blk_loc(e.mem, _v_11), _v_12, blk_loc(e.mem, _v_12), _v_13, blk_loc(e.mem, _v_13), _v_14, _v_15, _v_16, _frame_1, _descriptors_0, blk_loc(e.mem, _descriptors_0), _frames_0, blk_loc(e.mem, _frames_0)) == 0) {
        return 0;
      }
      _v_34 = _o_1[0];
      _v_35 = _o_1[1];
      _v_36 = _o_1[2];
      _v_37 = _o_1[3];
      _v_38 = _o_1[4];
      _v_39 = _o_1[5];
      _v_40 = _o_1[6];
      _v_41 = _o_1[7];
      _v_42 = _o_1[8];
      _v_43 = _o_1[9];
      _v_44 = _o_1[10];
      _v_45 = _o_1[11];
      _v_46 = _o_1[12];
      _v_47 = _o_1[13];
      _v_48 = _o_1[14];
      _v_49 = _o_1[15];
      _v_50 = _o_1[16];
      r0 = _v_34;
      r1 = _v_35;
      r2 = _v_36;
      r3 = _v_37;
      r4 = _v_38;
      r5 = _v_39;
      r6 = _v_40;
      r7 = _v_41;
      r8 = _v_42;
      r9 = _v_43;
      r10 = _v_44;
      r11 = _v_45;
      r12 = _v_46;
      r13 = _v_47;
      r14 = _v_48;
      r15 = _v_49;
      r16 = _v_50;
      WL_RETN(17);
    } else if (_frame_0 == 1) {
      if (term_aux(_frame_2) == CID_NIL) {
        term_sink(e, _descriptors_0);
        u64 _nd_2 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, term_pak(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPFINISH, _frame_1));
        e.mem[_nd_2 + 1] = rfc_seal(e, _frames_0);
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = _world_15;
        r16 = term_ctr(CID_CON, _nd_2);
        WL_RETN(17);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _frame_2, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        Term _fb_1[4];
        u64 _sp_1 = ctr_take(e, _f_0, 4, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        u32 _f_5 = _fb_1[3];
        spare_free(e, cls_fit(4), _sp_1);
        term_sink(e, _descriptors_0);
        _f_3 = term_keep(e, _f_3, 1);
        _f_4 = term_keep(e, _f_4, 1);
        u64 _nd_3 = heap_alloc(e, cls_fit(5));
        e.mem[_nd_3 + 0] = _frame_1;
        e.mem[_nd_3 + 1] = _f_2;
        e.mem[_nd_3 + 2] = _f_3;
        e.mem[_nd_3 + 3] = _f_4;
        e.mem[_nd_3 + 4] = _f_5;
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(8);
          STK(0) = _frame_1;
          STK(1) = _f_2;
          STK(2) = _f_3;
          STK(3) = _f_4;
          STK(4) = _f_5;
          STK(5) = _f_1;
          STK(6) = _frames_0;
          STK(7) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K620;
          WL_PUSHN(8);
        } else {
          u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K620, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _frame_1;
          e.mem[_t_2 + 1] = _f_2;
          e.mem[_t_2 + 2] = _f_3;
          e.mem[_t_2 + 3] = _f_4;
          e.mem[_t_2 + 4] = _f_5;
          e.mem[_t_2 + 5] = _f_1;
          e.mem[_t_2 + 6] = _frames_0;
          WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K620, _t_2);
          WL_IDX = 7;
        }
        if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1)) {
          u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = term_clo(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_C618, _nd_3);
          e.mem[_t_3 + 1] = _world_0;
          e.mem[_t_3 + 2] = _world_1;
          e.mem[_t_3 + 3] = _world_2;
          e.mem[_t_3 + 4] = _world_3;
          e.mem[_t_3 + 5] = _world_4;
          e.mem[_t_3 + 6] = _world_5;
          e.mem[_t_3 + 7] = _world_6;
          e.mem[_t_3 + 8] = _world_7;
          e.mem[_t_3 + 9] = _world_8;
          e.mem[_t_3 + 10] = _world_9;
          e.mem[_t_3 + 11] = _world_10;
          e.mem[_t_3 + 12] = _world_11;
          e.mem[_t_3 + 13] = _world_12;
          e.mem[_t_3 + 14] = _world_13;
          e.mem[_t_3 + 15] = _world_14;
          e.mem[_t_3 + 16] = _world_15;
          return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1, _t_3);
        }
        r0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_C618, _nd_3);
        r1 = _world_0;
        r2 = _world_1;
        r3 = _world_2;
        r4 = _world_3;
        r5 = _world_4;
        r6 = _world_5;
        r7 = _world_6;
        r8 = _world_7;
        r9 = _world_8;
        r10 = _world_9;
        r11 = _world_10;
        r12 = _world_11;
        r13 = _world_12;
        r14 = _world_13;
        r15 = _world_14;
        r16 = _world_15;
        WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_1);
      }
    } else if (_frame_0 == 2) {
      if (term_aux(_frame_7) == CID_NIL) {
        term_sink(e, _descriptors_0);
        if (seq) {
          WL_ROOM(4);
          STK(0) = _frame_1;
          STK(1) = _frame_6;
          STK(2) = _frames_0;
          STK(3) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K621;
          WL_PUSHN(4);
        } else {
          u64 _t_4 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K621, WL_CONT, WL_IDX, 1);
          e.mem[_t_4 + 0] = _frame_1;
          e.mem[_t_4 + 1] = _frame_6;
          e.mem[_t_4 + 2] = _frames_0;
          WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K621, _t_4);
          WL_IDX = 3;
        }
        if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0)) {
          u64 _t_5 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_5 + 0] = _world_0;
          e.mem[_t_5 + 1] = _world_1;
          e.mem[_t_5 + 2] = _world_2;
          e.mem[_t_5 + 3] = _world_3;
          e.mem[_t_5 + 4] = _world_4;
          e.mem[_t_5 + 5] = _world_5;
          e.mem[_t_5 + 6] = _world_6;
          e.mem[_t_5 + 7] = _world_7;
          e.mem[_t_5 + 8] = _world_8;
          e.mem[_t_5 + 9] = _world_9;
          e.mem[_t_5 + 10] = _world_10;
          e.mem[_t_5 + 11] = _world_11;
          e.mem[_t_5 + 12] = _world_12;
          e.mem[_t_5 + 13] = _world_13;
          e.mem[_t_5 + 14] = _world_14;
          e.mem[_t_5 + 15] = _world_15;
          e.mem[_t_5 + 16] = _frame_2;
          e.mem[_t_5 + 17] = _frame_3;
          e.mem[_t_5 + 18] = _frame_4;
          e.mem[_t_5 + 19] = _frame_5;
          e.mem[_t_5 + 20] = _namespace_0;
          e.mem[_t_5 + 21] = _frame_1;
          return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0, _t_5);
        }
        r0 = _world_0;
        r1 = _world_1;
        r2 = _world_2;
        r3 = _world_3;
        r4 = _world_4;
        r5 = _world_5;
        r6 = _world_6;
        r7 = _world_7;
        r8 = _world_8;
        r9 = _world_9;
        r10 = _world_10;
        r11 = _world_11;
        r12 = _world_12;
        r13 = _world_13;
        r14 = _world_14;
        r15 = _world_15;
        r16 = _frame_2;
        r17 = _frame_3;
        r18 = _frame_4;
        r19 = _frame_5;
        r20 = _namespace_0;
        r21 = _frame_1;
        WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0);
      } else {
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _frame_7, 2, _fb_4);
        Term _f_24 = _fb_4[0];
        Term _f_25 = _fb_4[1];
        term_sink(e, _descriptors_0);
        u32 _v_102 = 0;
        u32 _v_103 = 0;
        Term _o_3[1];
        if (spin_58(e, _o_3, _frame_2, _frame_3, blk_loc(e.mem, _frame_3), _frame_4, blk_loc(e.mem, _frame_4), _frame_5) == 0) {
          return 0;
        }
        _v_103 = _o_3[0];
        _v_102 = _v_103;
        if (_v_102 == 1) {
          u64 _nd_11 = heap_alloc(e, cls_fit(7));
          e.mem[_nd_11 + 0] = rfc_seal(e, _frame_1);
          e.mem[_nd_11 + 1] = rfc_seal(e, _frame_2);
          e.mem[_nd_11 + 2] = rfc_seal(e, _frame_3);
          e.mem[_nd_11 + 3] = rfc_seal(e, _frame_4);
          e.mem[_nd_11 + 4] = rfc_seal(e, _frame_5);
          e.mem[_nd_11 + 5] = rfc_seal(e, _frame_6);
          e.mem[_nd_11 + 6] = rfc_seal(e, _f_25);
          u64 _nd_12 = _sp_4 >= HEAP_OFF ? _sp_4 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_12 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPCHILDREN, _nd_11));
          e.mem[_nd_12 + 1] = rfc_seal(e, _frames_0);
          u64 _nd_13 = heap_alloc(e, cls_fit(2));
          e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPENTER, _f_24));
          e.mem[_nd_13 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_12));
          r0 = _world_0;
          r1 = _world_1;
          r2 = _world_2;
          r3 = _world_3;
          r4 = _world_4;
          r5 = _world_5;
          r6 = _world_6;
          r7 = _world_7;
          r8 = _world_8;
          r9 = _world_9;
          r10 = _world_10;
          r11 = _world_11;
          r12 = _world_12;
          r13 = _world_13;
          r14 = _world_14;
          r15 = _world_15;
          r16 = term_ctr(CID_CON, _nd_13);
          WL_RETN(17);
        } else {
          _frame_3 = term_keep(e, _frame_3, 1);
          _frame_4 = term_keep(e, _frame_4, 1);
          spare_free(e, cls_fit(2), _sp_4);
          if (seq) {
            WL_ROOM(9);
            STK(0) = _frame_1;
            STK(1) = _frame_2;
            STK(2) = _frame_3;
            STK(3) = _frame_4;
            STK(4) = _frame_5;
            STK(5) = _frame_6;
            STK(6) = _f_25;
            STK(7) = _frames_0;
            STK(8) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K622;
            WL_PUSHN(9);
          } else {
            u64 _t_6 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K622, WL_CONT, WL_IDX, 1);
            e.mem[_t_6 + 0] = _frame_1;
            e.mem[_t_6 + 1] = _frame_2;
            e.mem[_t_6 + 2] = _frame_3;
            e.mem[_t_6 + 3] = _frame_4;
            e.mem[_t_6 + 4] = _frame_5;
            e.mem[_t_6 + 5] = _frame_6;
            e.mem[_t_6 + 6] = _f_25;
            e.mem[_t_6 + 7] = _frames_0;
            WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K622, _t_6);
            WL_IDX = 8;
          }
          if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0)) {
            u64 _t_7 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0, WL_CONT, WL_IDX, 0);
            e.mem[_t_7 + 0] = _world_0;
            e.mem[_t_7 + 1] = _world_1;
            e.mem[_t_7 + 2] = _world_2;
            e.mem[_t_7 + 3] = _world_3;
            e.mem[_t_7 + 4] = _world_4;
            e.mem[_t_7 + 5] = _world_5;
            e.mem[_t_7 + 6] = _world_6;
            e.mem[_t_7 + 7] = _world_7;
            e.mem[_t_7 + 8] = _world_8;
            e.mem[_t_7 + 9] = _world_9;
            e.mem[_t_7 + 10] = _world_10;
            e.mem[_t_7 + 11] = _world_11;
            e.mem[_t_7 + 12] = _world_12;
            e.mem[_t_7 + 13] = _world_13;
            e.mem[_t_7 + 14] = _world_14;
            e.mem[_t_7 + 15] = _world_15;
            e.mem[_t_7 + 16] = _frame_2;
            e.mem[_t_7 + 17] = _frame_3;
            e.mem[_t_7 + 18] = _frame_4;
            e.mem[_t_7 + 19] = _frame_5;
            e.mem[_t_7 + 20] = _namespace_0;
            e.mem[_t_7 + 21] = _f_24;
            return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0, _t_7);
          }
          r0 = _world_0;
          r1 = _world_1;
          r2 = _world_2;
          r3 = _world_3;
          r4 = _world_4;
          r5 = _world_5;
          r6 = _world_6;
          r7 = _world_7;
          r8 = _world_8;
          r9 = _world_9;
          r10 = _world_10;
          r11 = _world_11;
          r12 = _world_12;
          r13 = _world_13;
          r14 = _world_14;
          r15 = _world_15;
          r16 = _frame_2;
          r17 = _frame_3;
          r18 = _frame_4;
          r19 = _frame_5;
          r20 = _namespace_0;
          r21 = _f_24;
          WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_UNRELATE_0);
        }
      }
    } else {
      term_sink(e, _descriptors_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _frames_0;
        STK(1) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K623;
        WL_PUSHN(2);
      } else {
        u64 _t_8 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K623, WL_CONT, WL_IDX, 1);
        e.mem[_t_8 + 0] = _frames_0;
        WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K623, _t_8);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0)) {
        u64 _t_9 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_9 + 0] = _world_0;
        e.mem[_t_9 + 1] = _world_1;
        e.mem[_t_9 + 2] = _world_2;
        e.mem[_t_9 + 3] = _world_3;
        e.mem[_t_9 + 4] = _world_4;
        e.mem[_t_9 + 5] = _world_5;
        e.mem[_t_9 + 6] = _world_6;
        e.mem[_t_9 + 7] = _world_7;
        e.mem[_t_9 + 8] = _world_8;
        e.mem[_t_9 + 9] = _world_9;
        e.mem[_t_9 + 10] = _world_10;
        e.mem[_t_9 + 11] = _world_11;
        e.mem[_t_9 + 12] = _world_12;
        e.mem[_t_9 + 13] = _world_13;
        e.mem[_t_9 + 14] = _world_14;
        e.mem[_t_9 + 15] = _world_15;
        e.mem[_t_9 + 16] = _namespace_0;
        e.mem[_t_9 + 17] = _frame_1;
        return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0, _t_9);
      }
      r0 = _world_0;
      r1 = _world_1;
      r2 = _world_2;
      r3 = _world_3;
      r4 = _world_4;
      r5 = _world_5;
      r6 = _world_6;
      r7 = _world_7;
      r8 = _world_8;
      r9 = _world_9;
      r10 = _world_10;
      r11 = _world_11;
      r12 = _world_12;
      r13 = _world_13;
      r14 = _world_14;
      r15 = _world_15;
      r16 = _namespace_0;
      r17 = _frame_1;
      WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_FINISH_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_C618)
  {
    u32 _frame_8 = r0;
    u32 _f_6 = r1;
    Term _f_7 = r2;
    Term _f_8 = r3;
    u32 _f_9 = r4;
    Term _x_0 = r5;
    WL_OPEN
    Term _fb_2[3];
    u64 _sp_2 = ctr_take(e, _x_0, 3, _fb_2);
    Term _f_10 = _fb_2[0];
    Term _f_11 = _fb_2[1];
    Term _f_12 = _fb_2[2];
    spare_free(e, cls_fit(3), _sp_2);
    Term _fb_3[2];
    u64 _sp_3 = ctr_take(e, _f_10, 2, _fb_3);
    Term _f_13 = _fb_3[0];
    Term _f_14 = _fb_3[1];
    spare_free(e, cls_fit(2), _sp_3);
    _f_11 = term_keep(e, _f_11, 1);
    _f_12 = term_keep(e, _f_12, 1);
    if (seq) {
      WL_ROOM(5);
      STK(0) = _f_13;
      STK(1) = _f_14;
      STK(2) = _f_11;
      STK(3) = _f_12;
      STK(4) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K619;
      WL_PUSHN(5);
    } else {
      u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K619, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _f_13;
      e.mem[_t_0 + 1] = _f_14;
      e.mem[_t_0 + 2] = _f_11;
      e.mem[_t_0 + 3] = _f_12;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K619, _t_0);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_11;
      e.mem[_t_1 + 1] = _f_12;
      e.mem[_t_1 + 2] = _f_6;
      e.mem[_t_1 + 3] = _f_7;
      e.mem[_t_1 + 4] = _f_8;
      e.mem[_t_1 + 5] = _f_9;
      e.mem[_t_1 + 6] = _frame_8;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_0, _t_1);
    }
    r0 = _f_11;
    r1 = _f_12;
    r2 = _f_6;
    r3 = _f_7;
    r4 = _f_8;
    r5 = _f_9;
    r6 = _frame_8;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_GRAPH_INVERSE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K619)
  {
    WL_POPN(4);
    Term _f_15 = STK(0);
    Term _f_16 = STK(1);
    Term _f_17 = STK(2);
    Term _f_18 = STK(3);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _f_15);
    e.mem[_nd_4 + 1] = rfc_seal(e, _f_16);
    u64 _nd_5 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_4));
    e.mem[_nd_5 + 1] = rfc_seal(e, _f_17);
    e.mem[_nd_5 + 2] = rfc_seal(e, _f_18);
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_5));
    e.mem[_nd_6 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_TUPLE, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K620)
  {
    WL_POPN(7);
    u32 _frame_9 = STK(0);
    u32 _f_19 = STK(1);
    Term _f_20 = STK(2);
    Term _f_21 = STK(3);
    u32 _f_22 = STK(4);
    Term _f_23 = STK(5);
    Term _frames_2 = STK(6);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    u32 _h_3 = r2;
    Term _h_4 = r3;
    u32 _h_5 = r4;
    Term _h_6 = r5;
    Term _h_7 = r6;
    Term _h_8 = r7;
    Term _h_9 = r8;
    Term _h_10 = r9;
    Term _h_11 = r10;
    Term _h_12 = r11;
    Term _h_13 = r12;
    Term _h_14 = r13;
    u32 _h_15 = r14;
    u32 _h_16 = r15;
    Term _h_17 = r16;
    WL_OPEN
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    Term _v_84 = 0;
    Term _o_2[17];
    if (spin_57(e, _o_2, _h_1, _h_2, _h_3, _h_4, blk_loc(e.mem, _h_4), _h_5, _h_6, _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, blk_loc(e.mem, _h_11), _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, _h_17, blk_loc(e.mem, _h_17), _frame_9, _f_19, _f_20, blk_loc(e.mem, _f_20), _f_21, blk_loc(e.mem, _f_21), _f_22, _f_23, blk_loc(e.mem, _f_23), _frames_2, blk_loc(e.mem, _frames_2)) == 0) {
      return 0;
    }
    _v_68 = _o_2[0];
    _v_69 = _o_2[1];
    _v_70 = _o_2[2];
    _v_71 = _o_2[3];
    _v_72 = _o_2[4];
    _v_73 = _o_2[5];
    _v_74 = _o_2[6];
    _v_75 = _o_2[7];
    _v_76 = _o_2[8];
    _v_77 = _o_2[9];
    _v_78 = _o_2[10];
    _v_79 = _o_2[11];
    _v_80 = _o_2[12];
    _v_81 = _o_2[13];
    _v_82 = _o_2[14];
    _v_83 = _o_2[15];
    _v_84 = _o_2[16];
    r0 = _v_68;
    r1 = _v_69;
    r2 = _v_70;
    r3 = _v_71;
    r4 = _v_72;
    r5 = _v_73;
    r6 = _v_74;
    r7 = _v_75;
    r8 = _v_76;
    r9 = _v_77;
    r10 = _v_78;
    r11 = _v_79;
    r12 = _v_80;
    r13 = _v_81;
    r14 = _v_82;
    r15 = _v_83;
    r16 = _v_84;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K621)
  {
    WL_POPN(3);
    u32 _frame_10 = STK(0);
    Term _frame_11 = STK(1);
    Term _frames_4 = STK(2);
    u32 _h_18 = r0;
    u32 _h_19 = r1;
    u32 _h_20 = r2;
    Term _h_21 = r3;
    u32 _h_22 = r4;
    Term _h_23 = r5;
    Term _h_24 = r6;
    Term _h_25 = r7;
    Term _h_26 = r8;
    Term _h_27 = r9;
    Term _h_28 = r10;
    Term _h_29 = r11;
    Term _h_30 = r12;
    Term _h_31 = r13;
    u32 _h_32 = r14;
    u32 _h_33 = r15;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, _frame_10);
    e.mem[_nd_9 + 1] = rfc_seal(e, _frame_11);
    u64 _nd_10 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_10 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPDESCRIPTORS, _nd_9));
    e.mem[_nd_10 + 1] = rfc_seal(e, _frames_4);
    r0 = _h_18;
    r1 = _h_19;
    r2 = _h_20;
    r3 = _h_21;
    r4 = _h_22;
    r5 = _h_23;
    r6 = _h_24;
    r7 = _h_25;
    r8 = _h_26;
    r9 = _h_27;
    r10 = _h_28;
    r11 = _h_29;
    r12 = _h_30;
    r13 = _h_31;
    r14 = _h_32;
    r15 = _h_33;
    r16 = term_ctr(CID_CON, _nd_10);
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K622)
  {
    WL_POPN(8);
    u32 _frame_12 = STK(0);
    u32 _frame_13 = STK(1);
    Term _frame_14 = STK(2);
    Term _frame_15 = STK(3);
    u32 _frame_16 = STK(4);
    Term _frame_17 = STK(5);
    Term _f_26 = STK(6);
    Term _frames_5 = STK(7);
    u32 _h_34 = r0;
    u32 _h_35 = r1;
    u32 _h_36 = r2;
    Term _h_37 = r3;
    u32 _h_38 = r4;
    Term _h_39 = r5;
    Term _h_40 = r6;
    Term _h_41 = r7;
    Term _h_42 = r8;
    Term _h_43 = r9;
    Term _h_44 = r10;
    Term _h_45 = r11;
    Term _h_46 = r12;
    Term _h_47 = r13;
    u32 _h_48 = r14;
    u32 _h_49 = r15;
    WL_OPEN
    u64 _nd_14 = heap_alloc(e, cls_fit(7));
    e.mem[_nd_14 + 0] = rfc_seal(e, _frame_12);
    e.mem[_nd_14 + 1] = rfc_seal(e, _frame_13);
    e.mem[_nd_14 + 2] = rfc_seal(e, _frame_14);
    e.mem[_nd_14 + 3] = rfc_seal(e, _frame_15);
    e.mem[_nd_14 + 4] = rfc_seal(e, _frame_16);
    e.mem[_nd_14 + 5] = rfc_seal(e, _frame_17);
    e.mem[_nd_14 + 6] = rfc_seal(e, _f_26);
    u64 _nd_15 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_15 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPCHILDREN, _nd_14));
    e.mem[_nd_15 + 1] = rfc_seal(e, _frames_5);
    r0 = _h_34;
    r1 = _h_35;
    r2 = _h_36;
    r3 = _h_37;
    r4 = _h_38;
    r5 = _h_39;
    r6 = _h_40;
    r7 = _h_41;
    r8 = _h_42;
    r9 = _h_43;
    r10 = _h_44;
    r11 = _h_45;
    r12 = _h_46;
    r13 = _h_47;
    r14 = _h_48;
    r15 = _h_49;
    r16 = term_ctr(CID_CON, _nd_15);
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0_K623)
  {
    WL_POPN(1);
    Term _frames_6 = STK(0);
    u32 _h_50 = r0;
    u32 _h_51 = r1;
    u32 _h_52 = r2;
    Term _h_53 = r3;
    u32 _h_54 = r4;
    Term _h_55 = r5;
    Term _h_56 = r6;
    Term _h_57 = r7;
    Term _h_58 = r8;
    Term _h_59 = r9;
    Term _h_60 = r10;
    Term _h_61 = r11;
    Term _h_62 = r12;
    Term _h_63 = r13;
    u32 _h_64 = r14;
    u32 _h_65 = r15;
    WL_OPEN
    r0 = _h_50;
    r1 = _h_51;
    r2 = _h_52;
    r3 = _h_53;
    r4 = _h_54;
    r5 = _h_55;
    r6 = _h_56;
    r7 = _h_57;
    r8 = _h_58;
    r9 = _h_59;
    r10 = _h_60;
    r11 = _h_61;
    r12 = _h_62;
    r13 = _h_63;
    r14 = _h_64;
    r15 = _h_65;
    r16 = _frames_6;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_INCOMPLETE_OBSERVED_0)
  {
    Term _frames_0 = r0;
    u32 _observed_0 = r1;
    u32 _observed_1 = r2;
    u32 _observed_2 = r3;
    Term _observed_3 = r4;
    u32 _observed_4 = r5;
    Term _observed_5 = r6;
    Term _observed_6 = r7;
    Term _observed_7 = r8;
    Term _observed_8 = r9;
    Term _observed_9 = r10;
    Term _observed_10 = r11;
    Term _observed_11 = r12;
    Term _observed_12 = r13;
    Term _observed_13 = r14;
    u32 _observed_14 = r15;
    u32 _observed_15 = r16;
    Term _observed_16 = r17;
    WL_OPEN
    _frames_0 = term_keep(e, _frames_0, 1);
    if (seq) {
      WL_ROOM(19);
      STK(0) = _frames_0;
      STK(1) = _observed_0;
      STK(2) = _observed_1;
      STK(3) = _observed_2;
      STK(4) = _observed_3;
      STK(5) = _observed_4;
      STK(6) = _observed_5;
      STK(7) = _observed_6;
      STK(8) = _observed_7;
      STK(9) = _observed_8;
      STK(10) = _observed_9;
      STK(11) = _observed_10;
      STK(12) = _observed_11;
      STK(13) = _observed_12;
      STK(14) = _observed_13;
      STK(15) = _observed_14;
      STK(16) = _observed_15;
      STK(17) = _observed_16;
      STK(18) = FID_CONSUMER_INCOMPLETE_OBSERVED_0_K628;
      WL_PUSHN(19);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_INCOMPLETE_OBSERVED_0_K628, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _frames_0;
      e.mem[_t_0 + 1] = _observed_0;
      e.mem[_t_0 + 2] = _observed_1;
      e.mem[_t_0 + 3] = _observed_2;
      e.mem[_t_0 + 4] = _observed_3;
      e.mem[_t_0 + 5] = _observed_4;
      e.mem[_t_0 + 6] = _observed_5;
      e.mem[_t_0 + 7] = _observed_6;
      e.mem[_t_0 + 8] = _observed_7;
      e.mem[_t_0 + 9] = _observed_8;
      e.mem[_t_0 + 10] = _observed_9;
      e.mem[_t_0 + 11] = _observed_10;
      e.mem[_t_0 + 12] = _observed_11;
      e.mem[_t_0 + 13] = _observed_12;
      e.mem[_t_0 + 14] = _observed_13;
      e.mem[_t_0 + 15] = _observed_14;
      e.mem[_t_0 + 16] = _observed_15;
      e.mem[_t_0 + 17] = _observed_16;
      WL_CONT = term_tsk(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K628, _t_0);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_6)) {
      u64 _t_1 = task_node(e, FID_LIST_SHOW_6, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _frames_0;
      return term_tsk(FID_LIST_SHOW_6, _t_1);
    }
    r0 = _frames_0;
    WL_JMP(FID_LIST_SHOW_6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K628)
  {
    WL_POPN(18);
    Term _frames_1 = STK(0);
    u32 _observed_17 = STK(1);
    u32 _observed_18 = STK(2);
    u32 _observed_19 = STK(3);
    Term _observed_20 = STK(4);
    u32 _observed_21 = STK(5);
    Term _observed_22 = STK(6);
    Term _observed_23 = STK(7);
    Term _observed_24 = STK(8);
    Term _observed_25 = STK(9);
    Term _observed_26 = STK(10);
    Term _observed_27 = STK(11);
    Term _observed_28 = STK(12);
    Term _observed_29 = STK(13);
    Term _observed_30 = STK(14);
    u32 _observed_31 = STK(15);
    u32 _observed_32 = STK(16);
    Term _observed_33 = STK(17);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _frames_1;
      STK(1) = _observed_17;
      STK(2) = _observed_18;
      STK(3) = _observed_19;
      STK(4) = _observed_20;
      STK(5) = _observed_21;
      STK(6) = _observed_22;
      STK(7) = _observed_23;
      STK(8) = _observed_24;
      STK(9) = _observed_25;
      STK(10) = _observed_26;
      STK(11) = _observed_27;
      STK(12) = _observed_28;
      STK(13) = _observed_29;
      STK(14) = _observed_30;
      STK(15) = _observed_31;
      STK(16) = _observed_32;
      STK(17) = _h_0;
      STK(18) = FID_CONSUMER_INCOMPLETE_OBSERVED_0_K629;
      WL_PUSHN(19);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_INCOMPLETE_OBSERVED_0_K629, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _frames_1;
      e.mem[_t_2 + 1] = _observed_17;
      e.mem[_t_2 + 2] = _observed_18;
      e.mem[_t_2 + 3] = _observed_19;
      e.mem[_t_2 + 4] = _observed_20;
      e.mem[_t_2 + 5] = _observed_21;
      e.mem[_t_2 + 6] = _observed_22;
      e.mem[_t_2 + 7] = _observed_23;
      e.mem[_t_2 + 8] = _observed_24;
      e.mem[_t_2 + 9] = _observed_25;
      e.mem[_t_2 + 10] = _observed_26;
      e.mem[_t_2 + 11] = _observed_27;
      e.mem[_t_2 + 12] = _observed_28;
      e.mem[_t_2 + 13] = _observed_29;
      e.mem[_t_2 + 14] = _observed_30;
      e.mem[_t_2 + 15] = _observed_31;
      e.mem[_t_2 + 16] = _observed_32;
      e.mem[_t_2 + 17] = _h_0;
      WL_CONT = term_tsk(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K629, _t_2);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 228);
      e.mem[_t_3 + 1] = _observed_33;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 228);
    r1 = _observed_33;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K629)
  {
    WL_POPN(18);
    Term _frames_2 = STK(0);
    u32 _observed_34 = STK(1);
    u32 _observed_35 = STK(2);
    u32 _observed_36 = STK(3);
    Term _observed_37 = STK(4);
    u32 _observed_38 = STK(5);
    Term _observed_39 = STK(6);
    Term _observed_40 = STK(7);
    Term _observed_41 = STK(8);
    Term _observed_42 = STK(9);
    Term _observed_43 = STK(10);
    Term _observed_44 = STK(11);
    Term _observed_45 = STK(12);
    Term _observed_46 = STK(13);
    Term _observed_47 = STK(14);
    u32 _observed_48 = STK(15);
    u32 _observed_49 = STK(16);
    Term _h_2 = STK(17);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _frames_2;
      STK(1) = _observed_34;
      STK(2) = _observed_35;
      STK(3) = _observed_36;
      STK(4) = _observed_37;
      STK(5) = _observed_38;
      STK(6) = _observed_39;
      STK(7) = _observed_40;
      STK(8) = _observed_41;
      STK(9) = _observed_42;
      STK(10) = _observed_43;
      STK(11) = _observed_44;
      STK(12) = _observed_45;
      STK(13) = _observed_46;
      STK(14) = _observed_47;
      STK(15) = _observed_48;
      STK(16) = _observed_49;
      STK(17) = FID_CONSUMER_INCOMPLETE_OBSERVED_0_K630;
      WL_PUSHN(18);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_INCOMPLETE_OBSERVED_0_K630, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _frames_2;
      e.mem[_t_4 + 1] = _observed_34;
      e.mem[_t_4 + 2] = _observed_35;
      e.mem[_t_4 + 3] = _observed_36;
      e.mem[_t_4 + 4] = _observed_37;
      e.mem[_t_4 + 5] = _observed_38;
      e.mem[_t_4 + 6] = _observed_39;
      e.mem[_t_4 + 7] = _observed_40;
      e.mem[_t_4 + 8] = _observed_41;
      e.mem[_t_4 + 9] = _observed_42;
      e.mem[_t_4 + 10] = _observed_43;
      e.mem[_t_4 + 11] = _observed_44;
      e.mem[_t_4 + 12] = _observed_45;
      e.mem[_t_4 + 13] = _observed_46;
      e.mem[_t_4 + 14] = _observed_47;
      e.mem[_t_4 + 15] = _observed_48;
      e.mem[_t_4 + 16] = _observed_49;
      WL_CONT = term_tsk(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K630, _t_4);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K630)
  {
    WL_POPN(17);
    Term _frames_3 = STK(0);
    u32 _observed_50 = STK(1);
    u32 _observed_51 = STK(2);
    u32 _observed_52 = STK(3);
    Term _observed_53 = STK(4);
    u32 _observed_54 = STK(5);
    Term _observed_55 = STK(6);
    Term _observed_56 = STK(7);
    Term _observed_57 = STK(8);
    Term _observed_58 = STK(9);
    Term _observed_59 = STK(10);
    Term _observed_60 = STK(11);
    Term _observed_61 = STK(12);
    Term _observed_62 = STK(13);
    Term _observed_63 = STK(14);
    u32 _observed_64 = STK(15);
    u32 _observed_65 = STK(16);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _frames_3;
      STK(1) = _observed_50;
      STK(2) = _observed_51;
      STK(3) = _observed_52;
      STK(4) = _observed_53;
      STK(5) = _observed_54;
      STK(6) = _observed_55;
      STK(7) = _observed_56;
      STK(8) = _observed_57;
      STK(9) = _observed_58;
      STK(10) = _observed_59;
      STK(11) = _observed_60;
      STK(12) = _observed_61;
      STK(13) = _observed_62;
      STK(14) = _observed_63;
      STK(15) = _observed_64;
      STK(16) = _observed_65;
      STK(17) = FID_CONSUMER_INCOMPLETE_OBSERVED_0_K631;
      WL_PUSHN(18);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_INCOMPLETE_OBSERVED_0_K631, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _frames_3;
      e.mem[_t_6 + 1] = _observed_50;
      e.mem[_t_6 + 2] = _observed_51;
      e.mem[_t_6 + 3] = _observed_52;
      e.mem[_t_6 + 4] = _observed_53;
      e.mem[_t_6 + 5] = _observed_54;
      e.mem[_t_6 + 6] = _observed_55;
      e.mem[_t_6 + 7] = _observed_56;
      e.mem[_t_6 + 8] = _observed_57;
      e.mem[_t_6 + 9] = _observed_58;
      e.mem[_t_6 + 10] = _observed_59;
      e.mem[_t_6 + 11] = _observed_60;
      e.mem[_t_6 + 12] = _observed_61;
      e.mem[_t_6 + 13] = _observed_62;
      e.mem[_t_6 + 14] = _observed_63;
      e.mem[_t_6 + 15] = _observed_64;
      e.mem[_t_6 + 16] = _observed_65;
      WL_CONT = term_tsk(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K631, _t_6);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 448);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 448);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_INCOMPLETE_OBSERVED_0_K631)
  {
    WL_POPN(17);
    Term _frames_4 = STK(0);
    u32 _observed_66 = STK(1);
    u32 _observed_67 = STK(2);
    u32 _observed_68 = STK(3);
    Term _observed_69 = STK(4);
    u32 _observed_70 = STK(5);
    Term _observed_71 = STK(6);
    Term _observed_72 = STK(7);
    Term _observed_73 = STK(8);
    Term _observed_74 = STK(9);
    Term _observed_75 = STK(10);
    Term _observed_76 = STK(11);
    Term _observed_77 = STK(12);
    Term _observed_78 = STK(13);
    Term _observed_79 = STK(14);
    u32 _observed_80 = STK(15);
    u32 _observed_81 = STK(16);
    Term _h_4 = r0;
    WL_OPEN
    r0 = 1;
    r1 = _observed_66;
    r2 = _observed_67;
    r3 = _observed_68;
    r4 = _observed_69;
    r5 = _observed_70;
    r6 = _observed_71;
    r7 = _observed_72;
    r8 = _observed_73;
    r9 = _observed_74;
    r10 = _observed_75;
    r11 = _observed_76;
    r12 = _observed_77;
    r13 = _observed_78;
    r14 = _observed_79;
    r15 = _observed_80;
    r16 = _observed_81;
    r17 = _frames_4;
    r18 = _h_4;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    Term _world_9 = r9;
    Term _world_10 = r10;
    Term _world_11 = r11;
    Term _world_12 = r12;
    Term _world_13 = r13;
    u32 _world_14 = r14;
    u32 _world_15 = r15;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CONSUMER_OBSERVE_0_K633;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_OBSERVE_0_K633, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K633, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _world_11;
      e.mem[_t_1 + 12] = _world_12;
      e.mem[_t_1 + 13] = _world_13;
      e.mem[_t_1 + 14] = _world_14;
      e.mem[_t_1 + 15] = _world_15;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _world_11;
    r12 = _world_12;
    r13 = _world_13;
    r14 = _world_14;
    r15 = _world_15;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_PENDING_COUNT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K633)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_16;
      STK(1) = FID_CONSUMER_OBSERVE_0_K639;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_CONSUMER_OBSERVE_0_K639, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_16;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K639, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0)) {
      u64 _t_11 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_clo(FID_CONSUMER_OBSERVE_0_C634, 0);
      e.mem[_t_11 + 1] = _h_0;
      e.mem[_t_11 + 2] = _h_1;
      e.mem[_t_11 + 3] = _h_2;
      e.mem[_t_11 + 4] = _h_3;
      e.mem[_t_11 + 5] = _h_4;
      e.mem[_t_11 + 6] = _h_5;
      e.mem[_t_11 + 7] = _h_6;
      e.mem[_t_11 + 8] = _h_7;
      e.mem[_t_11 + 9] = _h_8;
      e.mem[_t_11 + 10] = _h_9;
      e.mem[_t_11 + 11] = _h_10;
      e.mem[_t_11 + 12] = _h_11;
      e.mem[_t_11 + 13] = _h_12;
      e.mem[_t_11 + 14] = _h_13;
      e.mem[_t_11 + 15] = _h_14;
      e.mem[_t_11 + 16] = _h_15;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0, _t_11);
    }
    r0 = term_clo(FID_CONSUMER_OBSERVE_0_C634, 0);
    r1 = _h_0;
    r2 = _h_1;
    r3 = _h_2;
    r4 = _h_3;
    r5 = _h_4;
    r6 = _h_5;
    r7 = _h_6;
    r8 = _h_7;
    r9 = _h_8;
    r10 = _h_9;
    r11 = _h_10;
    r12 = _h_11;
    r13 = _h_12;
    r14 = _h_13;
    r15 = _h_14;
    r16 = _h_15;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_WITH_STORE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_C634)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[3];
    u64 _sp_0 = ctr_take(e, _x_0, 3, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    spare_free(e, cls_fit(3), _sp_0);
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
    Term _f_3 = _fb_1[0];
    Term _f_4 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _f_1;
      STK(1) = _f_2;
      STK(2) = FID_CONSUMER_OBSERVE_0_K635;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_OBSERVE_0_K635, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_1;
      e.mem[_t_2 + 1] = _f_2;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K635, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_COMPONENTS)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_SHOW_COMPONENTS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_3;
      e.mem[_t_3 + 1] = _f_4;
      return term_tsk(FID_CONSUMER_SHOW_COMPONENTS, _t_3);
    }
    r0 = _f_3;
    r1 = _f_4;
    WL_JMP(FID_CONSUMER_SHOW_COMPONENTS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K635)
  {
    WL_POPN(2);
    Term _f_5 = STK(0);
    Term _f_6 = STK(1);
    Term _h_17 = r0;
    Term _h_18 = r1;
    Term _h_19 = r2;
    WL_OPEN
    _f_5 = term_keep(e, _f_5, 1);
    _f_6 = term_keep(e, _f_6, 1);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _f_5;
      STK(1) = _f_6;
      STK(2) = _h_17;
      STK(3) = _h_18;
      STK(4) = _h_19;
      STK(5) = FID_CONSUMER_OBSERVE_0_K636;
      WL_PUSHN(6);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_OBSERVE_0_K636, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _f_5;
      e.mem[_t_4 + 1] = _f_6;
      e.mem[_t_4 + 2] = _h_17;
      e.mem[_t_4 + 3] = _h_18;
      e.mem[_t_4 + 4] = _h_19;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K636, _t_4);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SHOW_GRAPH_0)) {
      u64 _t_5 = task_node(e, FID_CONSUMER_SHOW_GRAPH_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_5;
      e.mem[_t_5 + 1] = _f_6;
      return term_tsk(FID_CONSUMER_SHOW_GRAPH_0, _t_5);
    }
    r0 = _f_5;
    r1 = _f_6;
    WL_JMP(FID_CONSUMER_SHOW_GRAPH_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K636)
  {
    WL_POPN(5);
    Term _f_7 = STK(0);
    Term _f_8 = STK(1);
    Term _h_21 = STK(2);
    Term _h_22 = STK(3);
    Term _h_23 = STK(4);
    Term _h_20 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _f_7;
      STK(1) = _f_8;
      STK(2) = _h_21;
      STK(3) = _h_22;
      STK(4) = _h_23;
      STK(5) = FID_CONSUMER_OBSERVE_0_K637;
      WL_PUSHN(6);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_OBSERVE_0_K637, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _f_7;
      e.mem[_t_6 + 1] = _f_8;
      e.mem[_t_6 + 2] = _h_21;
      e.mem[_t_6 + 3] = _h_22;
      e.mem[_t_6 + 4] = _h_23;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K637, _t_6);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 282);
      e.mem[_t_7 + 1] = _h_20;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 282);
    r1 = _h_20;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K637)
  {
    WL_POPN(5);
    Term _f_9 = STK(0);
    Term _f_10 = STK(1);
    Term _h_25 = STK(2);
    Term _h_26 = STK(3);
    Term _h_27 = STK(4);
    Term _h_24 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _f_9;
      STK(1) = _f_10;
      STK(2) = _h_25;
      STK(3) = _h_26;
      STK(4) = FID_CONSUMER_OBSERVE_0_K638;
      WL_PUSHN(5);
    } else {
      u64 _t_8 = task_node(e, FID_CONSUMER_OBSERVE_0_K638, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _f_9;
      e.mem[_t_8 + 1] = _f_10;
      e.mem[_t_8 + 2] = _h_25;
      e.mem[_t_8 + 3] = _h_26;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K638, _t_8);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_27;
      e.mem[_t_9 + 1] = _h_24;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_27;
    r1 = _h_24;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K638)
  {
    WL_POPN(4);
    Term _f_11 = STK(0);
    Term _f_12 = STK(1);
    Term _h_29 = STK(2);
    Term _h_30 = STK(3);
    Term _h_28 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_29);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_30);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _f_11);
    e.mem[_nd_1 + 2] = rfc_seal(e, _f_12);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, _h_28);
    r0 = term_ctr(CID_TUPLE, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K639)
  {
    WL_POPN(1);
    u32 _h_48 = STK(0);
    u32 _h_31 = r0;
    u32 _h_32 = r1;
    u32 _h_33 = r2;
    Term _h_34 = r3;
    u32 _h_35 = r4;
    Term _h_36 = r5;
    Term _h_37 = r6;
    Term _h_38 = r7;
    Term _h_39 = r8;
    Term _h_40 = r9;
    Term _h_41 = r10;
    Term _h_42 = r11;
    Term _h_43 = r12;
    Term _h_44 = r13;
    u32 _h_45 = r14;
    u32 _h_46 = r15;
    Term _h_47 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_48;
      STK(1) = _h_47;
      STK(2) = FID_CONSUMER_OBSERVE_0_K640;
      WL_PUSHN(3);
    } else {
      u64 _t_12 = task_node(e, FID_CONSUMER_OBSERVE_0_K640, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_48;
      e.mem[_t_12 + 1] = _h_47;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K640, _t_12);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0)) {
      u64 _t_13 = task_node(e, FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_31;
      e.mem[_t_13 + 1] = _h_32;
      e.mem[_t_13 + 2] = _h_33;
      e.mem[_t_13 + 3] = _h_34;
      e.mem[_t_13 + 4] = _h_35;
      e.mem[_t_13 + 5] = _h_36;
      e.mem[_t_13 + 6] = _h_37;
      e.mem[_t_13 + 7] = _h_38;
      e.mem[_t_13 + 8] = _h_39;
      e.mem[_t_13 + 9] = _h_40;
      e.mem[_t_13 + 10] = _h_41;
      e.mem[_t_13 + 11] = _h_42;
      e.mem[_t_13 + 12] = _h_43;
      e.mem[_t_13 + 13] = _h_44;
      e.mem[_t_13 + 14] = _h_45;
      e.mem[_t_13 + 15] = _h_46;
      return term_tsk(FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0, _t_13);
    }
    r0 = _h_31;
    r1 = _h_32;
    r2 = _h_33;
    r3 = _h_34;
    r4 = _h_35;
    r5 = _h_36;
    r6 = _h_37;
    r7 = _h_38;
    r8 = _h_39;
    r9 = _h_40;
    r10 = _h_41;
    r11 = _h_42;
    r12 = _h_43;
    r13 = _h_44;
    r14 = _h_45;
    r15 = _h_46;
    WL_JMP(FID________________BENDVY_SRC_ECS_WORLD_OBSERVE_RESOURCE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K640)
  {
    WL_POPN(2);
    u32 _h_66 = STK(0);
    Term _h_67 = STK(1);
    u32 _h_49 = r0;
    u32 _h_50 = r1;
    u32 _h_51 = r2;
    Term _h_52 = r3;
    u32 _h_53 = r4;
    Term _h_54 = r5;
    Term _h_55 = r6;
    Term _h_56 = r7;
    Term _h_57 = r8;
    Term _h_58 = r9;
    Term _h_59 = r10;
    Term _h_60 = r11;
    Term _h_61 = r12;
    Term _h_62 = r13;
    u32 _h_63 = r14;
    u32 _h_64 = r15;
    Term _h_65 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_66;
      STK(1) = _h_67;
      STK(2) = _h_65;
      STK(3) = _h_49;
      STK(4) = _h_50;
      STK(5) = _h_51;
      STK(6) = _h_53;
      STK(7) = _h_54;
      STK(8) = _h_55;
      STK(9) = _h_56;
      STK(10) = _h_57;
      STK(11) = _h_58;
      STK(12) = _h_59;
      STK(13) = _h_60;
      STK(14) = _h_61;
      STK(15) = _h_62;
      STK(16) = _h_63;
      STK(17) = _h_64;
      STK(18) = FID_CONSUMER_OBSERVE_0_K641;
      WL_PUSHN(19);
    } else {
      u64 _t_14 = task_node(e, FID_CONSUMER_OBSERVE_0_K641, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_66;
      e.mem[_t_14 + 1] = _h_67;
      e.mem[_t_14 + 2] = _h_65;
      e.mem[_t_14 + 3] = _h_49;
      e.mem[_t_14 + 4] = _h_50;
      e.mem[_t_14 + 5] = _h_51;
      e.mem[_t_14 + 6] = _h_53;
      e.mem[_t_14 + 7] = _h_54;
      e.mem[_t_14 + 8] = _h_55;
      e.mem[_t_14 + 9] = _h_56;
      e.mem[_t_14 + 10] = _h_57;
      e.mem[_t_14 + 11] = _h_58;
      e.mem[_t_14 + 12] = _h_59;
      e.mem[_t_14 + 13] = _h_60;
      e.mem[_t_14 + 14] = _h_61;
      e.mem[_t_14 + 15] = _h_62;
      e.mem[_t_14 + 16] = _h_63;
      e.mem[_t_14 + 17] = _h_64;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K641, _t_14);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_TREE_2)) {
      u64 _t_15 = task_node(e, FID_CONSUMER_TREE_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_52;
      return term_tsk(FID_CONSUMER_TREE_2, _t_15);
    }
    r0 = _h_52;
    WL_JMP(FID_CONSUMER_TREE_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K641)
  {
    WL_POPN(18);
    u32 _h_70 = STK(0);
    Term _h_71 = STK(1);
    Term _h_72 = STK(2);
    u32 _h_73 = STK(3);
    u32 _h_74 = STK(4);
    u32 _h_75 = STK(5);
    u32 _h_76 = STK(6);
    Term _h_77 = STK(7);
    Term _h_78 = STK(8);
    Term _h_79 = STK(9);
    Term _h_80 = STK(10);
    Term _h_81 = STK(11);
    Term _h_82 = STK(12);
    Term _h_83 = STK(13);
    Term _h_84 = STK(14);
    Term _h_85 = STK(15);
    u32 _h_86 = STK(16);
    u32 _h_87 = STK(17);
    Term _h_68 = r0;
    Term _h_69 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_73;
      STK(1) = _h_74;
      STK(2) = _h_75;
      STK(3) = _h_76;
      STK(4) = _h_77;
      STK(5) = _h_78;
      STK(6) = _h_79;
      STK(7) = _h_80;
      STK(8) = _h_81;
      STK(9) = _h_82;
      STK(10) = _h_83;
      STK(11) = _h_84;
      STK(12) = _h_85;
      STK(13) = _h_86;
      STK(14) = _h_87;
      STK(15) = _h_70;
      STK(16) = _h_71;
      STK(17) = _h_72;
      STK(18) = _h_68;
      STK(19) = _h_69;
      STK(20) = FID_CONSUMER_OBSERVE_0_K642;
      WL_PUSHN(21);
    } else {
      u64 _t_16 = task_node(e, FID_CONSUMER_OBSERVE_0_K642, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_73;
      e.mem[_t_16 + 1] = _h_74;
      e.mem[_t_16 + 2] = _h_75;
      e.mem[_t_16 + 3] = _h_76;
      e.mem[_t_16 + 4] = _h_77;
      e.mem[_t_16 + 5] = _h_78;
      e.mem[_t_16 + 6] = _h_79;
      e.mem[_t_16 + 7] = _h_80;
      e.mem[_t_16 + 8] = _h_81;
      e.mem[_t_16 + 9] = _h_82;
      e.mem[_t_16 + 10] = _h_83;
      e.mem[_t_16 + 11] = _h_84;
      e.mem[_t_16 + 12] = _h_85;
      e.mem[_t_16 + 13] = _h_86;
      e.mem[_t_16 + 14] = _h_87;
      e.mem[_t_16 + 15] = _h_70;
      e.mem[_t_16 + 16] = _h_71;
      e.mem[_t_16 + 17] = _h_72;
      e.mem[_t_16 + 18] = _h_68;
      e.mem[_t_16 + 19] = _h_69;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K642, _t_16);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_17 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_73;
      return term_tsk(FID_U32_SHOW, _t_17);
    }
    r0 = _h_73;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K642)
  {
    WL_POPN(20);
    u32 _h_89 = STK(0);
    u32 _h_90 = STK(1);
    u32 _h_91 = STK(2);
    u32 _h_92 = STK(3);
    Term _h_93 = STK(4);
    Term _h_94 = STK(5);
    Term _h_95 = STK(6);
    Term _h_96 = STK(7);
    Term _h_97 = STK(8);
    Term _h_98 = STK(9);
    Term _h_99 = STK(10);
    Term _h_100 = STK(11);
    Term _h_101 = STK(12);
    u32 _h_102 = STK(13);
    u32 _h_103 = STK(14);
    u32 _h_104 = STK(15);
    Term _h_105 = STK(16);
    Term _h_106 = STK(17);
    Term _h_107 = STK(18);
    Term _h_108 = STK(19);
    Term _h_88 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_89;
      STK(1) = _h_90;
      STK(2) = _h_91;
      STK(3) = _h_92;
      STK(4) = _h_93;
      STK(5) = _h_94;
      STK(6) = _h_95;
      STK(7) = _h_96;
      STK(8) = _h_97;
      STK(9) = _h_98;
      STK(10) = _h_99;
      STK(11) = _h_100;
      STK(12) = _h_101;
      STK(13) = _h_102;
      STK(14) = _h_103;
      STK(15) = _h_104;
      STK(16) = _h_105;
      STK(17) = _h_106;
      STK(18) = _h_107;
      STK(19) = _h_108;
      STK(20) = _h_88;
      STK(21) = FID_CONSUMER_OBSERVE_0_K643;
      WL_PUSHN(22);
    } else {
      u64 _t_18 = task_node(e, FID_CONSUMER_OBSERVE_0_K643, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_89;
      e.mem[_t_18 + 1] = _h_90;
      e.mem[_t_18 + 2] = _h_91;
      e.mem[_t_18 + 3] = _h_92;
      e.mem[_t_18 + 4] = _h_93;
      e.mem[_t_18 + 5] = _h_94;
      e.mem[_t_18 + 6] = _h_95;
      e.mem[_t_18 + 7] = _h_96;
      e.mem[_t_18 + 8] = _h_97;
      e.mem[_t_18 + 9] = _h_98;
      e.mem[_t_18 + 10] = _h_99;
      e.mem[_t_18 + 11] = _h_100;
      e.mem[_t_18 + 12] = _h_101;
      e.mem[_t_18 + 13] = _h_102;
      e.mem[_t_18 + 14] = _h_103;
      e.mem[_t_18 + 15] = _h_104;
      e.mem[_t_18 + 16] = _h_105;
      e.mem[_t_18 + 17] = _h_106;
      e.mem[_t_18 + 18] = _h_107;
      e.mem[_t_18 + 19] = _h_108;
      e.mem[_t_18 + 20] = _h_88;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K643, _t_18);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_19 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_90;
      return term_tsk(FID_U32_SHOW, _t_19);
    }
    r0 = _h_90;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K643)
  {
    WL_POPN(21);
    u32 _h_110 = STK(0);
    u32 _h_111 = STK(1);
    u32 _h_112 = STK(2);
    u32 _h_113 = STK(3);
    Term _h_114 = STK(4);
    Term _h_115 = STK(5);
    Term _h_116 = STK(6);
    Term _h_117 = STK(7);
    Term _h_118 = STK(8);
    Term _h_119 = STK(9);
    Term _h_120 = STK(10);
    Term _h_121 = STK(11);
    Term _h_122 = STK(12);
    u32 _h_123 = STK(13);
    u32 _h_124 = STK(14);
    u32 _h_125 = STK(15);
    Term _h_126 = STK(16);
    Term _h_127 = STK(17);
    Term _h_128 = STK(18);
    Term _h_129 = STK(19);
    Term _h_130 = STK(20);
    Term _h_109 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_110;
      STK(1) = _h_111;
      STK(2) = _h_112;
      STK(3) = _h_113;
      STK(4) = _h_114;
      STK(5) = _h_115;
      STK(6) = _h_116;
      STK(7) = _h_117;
      STK(8) = _h_118;
      STK(9) = _h_119;
      STK(10) = _h_120;
      STK(11) = _h_121;
      STK(12) = _h_122;
      STK(13) = _h_123;
      STK(14) = _h_124;
      STK(15) = _h_125;
      STK(16) = _h_126;
      STK(17) = _h_127;
      STK(18) = _h_128;
      STK(19) = _h_129;
      STK(20) = _h_130;
      STK(21) = _h_109;
      STK(22) = FID_CONSUMER_OBSERVE_0_K644;
      WL_PUSHN(23);
    } else {
      u64 _t_20 = task_node(e, FID_CONSUMER_OBSERVE_0_K644, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _h_110;
      e.mem[_t_20 + 1] = _h_111;
      e.mem[_t_20 + 2] = _h_112;
      e.mem[_t_20 + 3] = _h_113;
      e.mem[_t_20 + 4] = _h_114;
      e.mem[_t_20 + 5] = _h_115;
      e.mem[_t_20 + 6] = _h_116;
      e.mem[_t_20 + 7] = _h_117;
      e.mem[_t_20 + 8] = _h_118;
      e.mem[_t_20 + 9] = _h_119;
      e.mem[_t_20 + 10] = _h_120;
      e.mem[_t_20 + 11] = _h_121;
      e.mem[_t_20 + 12] = _h_122;
      e.mem[_t_20 + 13] = _h_123;
      e.mem[_t_20 + 14] = _h_124;
      e.mem[_t_20 + 15] = _h_125;
      e.mem[_t_20 + 16] = _h_126;
      e.mem[_t_20 + 17] = _h_127;
      e.mem[_t_20 + 18] = _h_128;
      e.mem[_t_20 + 19] = _h_129;
      e.mem[_t_20 + 20] = _h_130;
      e.mem[_t_20 + 21] = _h_109;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K644, _t_20);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_21 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_112;
      return term_tsk(FID_U32_SHOW, _t_21);
    }
    r0 = _h_112;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K644)
  {
    WL_POPN(22);
    u32 _h_132 = STK(0);
    u32 _h_133 = STK(1);
    u32 _h_134 = STK(2);
    u32 _h_135 = STK(3);
    Term _h_136 = STK(4);
    Term _h_137 = STK(5);
    Term _h_138 = STK(6);
    Term _h_139 = STK(7);
    Term _h_140 = STK(8);
    Term _h_141 = STK(9);
    Term _h_142 = STK(10);
    Term _h_143 = STK(11);
    Term _h_144 = STK(12);
    u32 _h_145 = STK(13);
    u32 _h_146 = STK(14);
    u32 _h_147 = STK(15);
    Term _h_148 = STK(16);
    Term _h_149 = STK(17);
    Term _h_150 = STK(18);
    Term _h_151 = STK(19);
    Term _h_152 = STK(20);
    Term _h_153 = STK(21);
    Term _h_131 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_132;
      STK(1) = _h_133;
      STK(2) = _h_134;
      STK(3) = _h_135;
      STK(4) = _h_136;
      STK(5) = _h_137;
      STK(6) = _h_138;
      STK(7) = _h_139;
      STK(8) = _h_140;
      STK(9) = _h_141;
      STK(10) = _h_142;
      STK(11) = _h_143;
      STK(12) = _h_144;
      STK(13) = _h_145;
      STK(14) = _h_146;
      STK(15) = _h_147;
      STK(16) = _h_148;
      STK(17) = _h_149;
      STK(18) = _h_150;
      STK(19) = _h_151;
      STK(20) = _h_152;
      STK(21) = _h_153;
      STK(22) = _h_131;
      STK(23) = FID_CONSUMER_OBSERVE_0_K645;
      WL_PUSHN(24);
    } else {
      u64 _t_22 = task_node(e, FID_CONSUMER_OBSERVE_0_K645, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _h_132;
      e.mem[_t_22 + 1] = _h_133;
      e.mem[_t_22 + 2] = _h_134;
      e.mem[_t_22 + 3] = _h_135;
      e.mem[_t_22 + 4] = _h_136;
      e.mem[_t_22 + 5] = _h_137;
      e.mem[_t_22 + 6] = _h_138;
      e.mem[_t_22 + 7] = _h_139;
      e.mem[_t_22 + 8] = _h_140;
      e.mem[_t_22 + 9] = _h_141;
      e.mem[_t_22 + 10] = _h_142;
      e.mem[_t_22 + 11] = _h_143;
      e.mem[_t_22 + 12] = _h_144;
      e.mem[_t_22 + 13] = _h_145;
      e.mem[_t_22 + 14] = _h_146;
      e.mem[_t_22 + 15] = _h_147;
      e.mem[_t_22 + 16] = _h_148;
      e.mem[_t_22 + 17] = _h_149;
      e.mem[_t_22 + 18] = _h_150;
      e.mem[_t_22 + 19] = _h_151;
      e.mem[_t_22 + 20] = _h_152;
      e.mem[_t_22 + 21] = _h_153;
      e.mem[_t_22 + 22] = _h_131;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K645, _t_22);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_23 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_135;
      return term_tsk(FID_U32_SHOW, _t_23);
    }
    r0 = _h_135;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K645)
  {
    WL_POPN(23);
    u32 _h_155 = STK(0);
    u32 _h_156 = STK(1);
    u32 _h_157 = STK(2);
    u32 _h_158 = STK(3);
    Term _h_159 = STK(4);
    Term _h_160 = STK(5);
    Term _h_161 = STK(6);
    Term _h_162 = STK(7);
    Term _h_163 = STK(8);
    Term _h_164 = STK(9);
    Term _h_165 = STK(10);
    Term _h_166 = STK(11);
    Term _h_167 = STK(12);
    u32 _h_168 = STK(13);
    u32 _h_169 = STK(14);
    u32 _h_170 = STK(15);
    Term _h_171 = STK(16);
    Term _h_172 = STK(17);
    Term _h_173 = STK(18);
    Term _h_174 = STK(19);
    Term _h_175 = STK(20);
    Term _h_176 = STK(21);
    Term _h_177 = STK(22);
    Term _h_154 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _h_155;
      STK(1) = _h_156;
      STK(2) = _h_157;
      STK(3) = _h_158;
      STK(4) = _h_159;
      STK(5) = _h_160;
      STK(6) = _h_161;
      STK(7) = _h_162;
      STK(8) = _h_163;
      STK(9) = _h_164;
      STK(10) = _h_165;
      STK(11) = _h_166;
      STK(12) = _h_167;
      STK(13) = _h_168;
      STK(14) = _h_169;
      STK(15) = _h_170;
      STK(16) = _h_171;
      STK(17) = _h_172;
      STK(18) = _h_173;
      STK(19) = _h_174;
      STK(20) = _h_175;
      STK(21) = _h_176;
      STK(22) = _h_177;
      STK(23) = _h_154;
      STK(24) = FID_CONSUMER_OBSERVE_0_K646;
      WL_PUSHN(25);
    } else {
      u64 _t_24 = task_node(e, FID_CONSUMER_OBSERVE_0_K646, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _h_155;
      e.mem[_t_24 + 1] = _h_156;
      e.mem[_t_24 + 2] = _h_157;
      e.mem[_t_24 + 3] = _h_158;
      e.mem[_t_24 + 4] = _h_159;
      e.mem[_t_24 + 5] = _h_160;
      e.mem[_t_24 + 6] = _h_161;
      e.mem[_t_24 + 7] = _h_162;
      e.mem[_t_24 + 8] = _h_163;
      e.mem[_t_24 + 9] = _h_164;
      e.mem[_t_24 + 10] = _h_165;
      e.mem[_t_24 + 11] = _h_166;
      e.mem[_t_24 + 12] = _h_167;
      e.mem[_t_24 + 13] = _h_168;
      e.mem[_t_24 + 14] = _h_169;
      e.mem[_t_24 + 15] = _h_170;
      e.mem[_t_24 + 16] = _h_171;
      e.mem[_t_24 + 17] = _h_172;
      e.mem[_t_24 + 18] = _h_173;
      e.mem[_t_24 + 19] = _h_174;
      e.mem[_t_24 + 20] = _h_175;
      e.mem[_t_24 + 21] = _h_176;
      e.mem[_t_24 + 22] = _h_177;
      e.mem[_t_24 + 23] = _h_154;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K646, _t_24);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_25 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _h_159;
      return term_tsk(FID_NAT_SHOW, _t_25);
    }
    r0 = _h_159;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K646)
  {
    WL_POPN(24);
    u32 _h_179 = STK(0);
    u32 _h_180 = STK(1);
    u32 _h_181 = STK(2);
    u32 _h_182 = STK(3);
    Term _h_183 = STK(4);
    Term _h_184 = STK(5);
    Term _h_185 = STK(6);
    Term _h_186 = STK(7);
    Term _h_187 = STK(8);
    Term _h_188 = STK(9);
    Term _h_189 = STK(10);
    Term _h_190 = STK(11);
    Term _h_191 = STK(12);
    u32 _h_192 = STK(13);
    u32 _h_193 = STK(14);
    u32 _h_194 = STK(15);
    Term _h_195 = STK(16);
    Term _h_196 = STK(17);
    Term _h_197 = STK(18);
    Term _h_198 = STK(19);
    Term _h_199 = STK(20);
    Term _h_200 = STK(21);
    Term _h_201 = STK(22);
    Term _h_202 = STK(23);
    Term _h_178 = r0;
    WL_OPEN
    _h_189 = term_keep(e, _h_189, 1);
    if (seq) {
      WL_ROOM(26);
      STK(0) = _h_179;
      STK(1) = _h_180;
      STK(2) = _h_181;
      STK(3) = _h_182;
      STK(4) = _h_183;
      STK(5) = _h_184;
      STK(6) = _h_185;
      STK(7) = _h_186;
      STK(8) = _h_187;
      STK(9) = _h_188;
      STK(10) = _h_189;
      STK(11) = _h_190;
      STK(12) = _h_191;
      STK(13) = _h_192;
      STK(14) = _h_193;
      STK(15) = _h_194;
      STK(16) = _h_195;
      STK(17) = _h_196;
      STK(18) = _h_197;
      STK(19) = _h_198;
      STK(20) = _h_199;
      STK(21) = _h_200;
      STK(22) = _h_201;
      STK(23) = _h_202;
      STK(24) = _h_178;
      STK(25) = FID_CONSUMER_OBSERVE_0_K647;
      WL_PUSHN(26);
    } else {
      u64 _t_26 = task_node(e, FID_CONSUMER_OBSERVE_0_K647, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _h_179;
      e.mem[_t_26 + 1] = _h_180;
      e.mem[_t_26 + 2] = _h_181;
      e.mem[_t_26 + 3] = _h_182;
      e.mem[_t_26 + 4] = _h_183;
      e.mem[_t_26 + 5] = _h_184;
      e.mem[_t_26 + 6] = _h_185;
      e.mem[_t_26 + 7] = _h_186;
      e.mem[_t_26 + 8] = _h_187;
      e.mem[_t_26 + 9] = _h_188;
      e.mem[_t_26 + 10] = _h_189;
      e.mem[_t_26 + 11] = _h_190;
      e.mem[_t_26 + 12] = _h_191;
      e.mem[_t_26 + 13] = _h_192;
      e.mem[_t_26 + 14] = _h_193;
      e.mem[_t_26 + 15] = _h_194;
      e.mem[_t_26 + 16] = _h_195;
      e.mem[_t_26 + 17] = _h_196;
      e.mem[_t_26 + 18] = _h_197;
      e.mem[_t_26 + 19] = _h_198;
      e.mem[_t_26 + 20] = _h_199;
      e.mem[_t_26 + 21] = _h_200;
      e.mem[_t_26 + 22] = _h_201;
      e.mem[_t_26 + 23] = _h_202;
      e.mem[_t_26 + 24] = _h_178;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K647, _t_26);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_1)) {
      u64 _t_27 = task_node(e, FID_LIST_SHOW_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _h_189;
      return term_tsk(FID_LIST_SHOW_1, _t_27);
    }
    r0 = _h_189;
    WL_JMP(FID_LIST_SHOW_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K647)
  {
    WL_POPN(25);
    u32 _h_204 = STK(0);
    u32 _h_205 = STK(1);
    u32 _h_206 = STK(2);
    u32 _h_207 = STK(3);
    Term _h_208 = STK(4);
    Term _h_209 = STK(5);
    Term _h_210 = STK(6);
    Term _h_211 = STK(7);
    Term _h_212 = STK(8);
    Term _h_213 = STK(9);
    Term _h_214 = STK(10);
    Term _h_215 = STK(11);
    Term _h_216 = STK(12);
    u32 _h_217 = STK(13);
    u32 _h_218 = STK(14);
    u32 _h_219 = STK(15);
    Term _h_220 = STK(16);
    Term _h_221 = STK(17);
    Term _h_222 = STK(18);
    Term _h_223 = STK(19);
    Term _h_224 = STK(20);
    Term _h_225 = STK(21);
    Term _h_226 = STK(22);
    Term _h_227 = STK(23);
    Term _h_228 = STK(24);
    Term _h_203 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _h_204;
      STK(1) = _h_205;
      STK(2) = _h_206;
      STK(3) = _h_207;
      STK(4) = _h_208;
      STK(5) = _h_209;
      STK(6) = _h_210;
      STK(7) = _h_211;
      STK(8) = _h_212;
      STK(9) = _h_213;
      STK(10) = _h_214;
      STK(11) = _h_215;
      STK(12) = _h_216;
      STK(13) = _h_217;
      STK(14) = _h_218;
      STK(15) = _h_220;
      STK(16) = _h_221;
      STK(17) = _h_222;
      STK(18) = _h_223;
      STK(19) = _h_224;
      STK(20) = _h_225;
      STK(21) = _h_226;
      STK(22) = _h_227;
      STK(23) = _h_228;
      STK(24) = _h_203;
      STK(25) = FID_CONSUMER_OBSERVE_0_K648;
      WL_PUSHN(26);
    } else {
      u64 _t_28 = task_node(e, FID_CONSUMER_OBSERVE_0_K648, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _h_204;
      e.mem[_t_28 + 1] = _h_205;
      e.mem[_t_28 + 2] = _h_206;
      e.mem[_t_28 + 3] = _h_207;
      e.mem[_t_28 + 4] = _h_208;
      e.mem[_t_28 + 5] = _h_209;
      e.mem[_t_28 + 6] = _h_210;
      e.mem[_t_28 + 7] = _h_211;
      e.mem[_t_28 + 8] = _h_212;
      e.mem[_t_28 + 9] = _h_213;
      e.mem[_t_28 + 10] = _h_214;
      e.mem[_t_28 + 11] = _h_215;
      e.mem[_t_28 + 12] = _h_216;
      e.mem[_t_28 + 13] = _h_217;
      e.mem[_t_28 + 14] = _h_218;
      e.mem[_t_28 + 15] = _h_220;
      e.mem[_t_28 + 16] = _h_221;
      e.mem[_t_28 + 17] = _h_222;
      e.mem[_t_28 + 18] = _h_223;
      e.mem[_t_28 + 19] = _h_224;
      e.mem[_t_28 + 20] = _h_225;
      e.mem[_t_28 + 21] = _h_226;
      e.mem[_t_28 + 22] = _h_227;
      e.mem[_t_28 + 23] = _h_228;
      e.mem[_t_28 + 24] = _h_203;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K648, _t_28);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_29 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _h_219;
      return term_tsk(FID_U32_SHOW, _t_29);
    }
    r0 = _h_219;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K648)
  {
    WL_POPN(25);
    u32 _h_230 = STK(0);
    u32 _h_231 = STK(1);
    u32 _h_232 = STK(2);
    u32 _h_233 = STK(3);
    Term _h_234 = STK(4);
    Term _h_235 = STK(5);
    Term _h_236 = STK(6);
    Term _h_237 = STK(7);
    Term _h_238 = STK(8);
    Term _h_239 = STK(9);
    Term _h_240 = STK(10);
    Term _h_241 = STK(11);
    Term _h_242 = STK(12);
    u32 _h_243 = STK(13);
    u32 _h_244 = STK(14);
    Term _h_245 = STK(15);
    Term _h_246 = STK(16);
    Term _h_247 = STK(17);
    Term _h_248 = STK(18);
    Term _h_249 = STK(19);
    Term _h_250 = STK(20);
    Term _h_251 = STK(21);
    Term _h_252 = STK(22);
    Term _h_253 = STK(23);
    Term _h_254 = STK(24);
    Term _h_229 = r0;
    WL_OPEN
    _h_242 = term_keep(e, _h_242, 1);
    if (seq) {
      WL_ROOM(27);
      STK(0) = _h_230;
      STK(1) = _h_231;
      STK(2) = _h_232;
      STK(3) = _h_233;
      STK(4) = _h_234;
      STK(5) = _h_235;
      STK(6) = _h_236;
      STK(7) = _h_237;
      STK(8) = _h_238;
      STK(9) = _h_239;
      STK(10) = _h_240;
      STK(11) = _h_241;
      STK(12) = _h_242;
      STK(13) = _h_243;
      STK(14) = _h_244;
      STK(15) = _h_245;
      STK(16) = _h_246;
      STK(17) = _h_247;
      STK(18) = _h_248;
      STK(19) = _h_249;
      STK(20) = _h_250;
      STK(21) = _h_251;
      STK(22) = _h_252;
      STK(23) = _h_253;
      STK(24) = _h_254;
      STK(25) = _h_229;
      STK(26) = FID_CONSUMER_OBSERVE_0_K649;
      WL_PUSHN(27);
    } else {
      u64 _t_30 = task_node(e, FID_CONSUMER_OBSERVE_0_K649, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _h_230;
      e.mem[_t_30 + 1] = _h_231;
      e.mem[_t_30 + 2] = _h_232;
      e.mem[_t_30 + 3] = _h_233;
      e.mem[_t_30 + 4] = _h_234;
      e.mem[_t_30 + 5] = _h_235;
      e.mem[_t_30 + 6] = _h_236;
      e.mem[_t_30 + 7] = _h_237;
      e.mem[_t_30 + 8] = _h_238;
      e.mem[_t_30 + 9] = _h_239;
      e.mem[_t_30 + 10] = _h_240;
      e.mem[_t_30 + 11] = _h_241;
      e.mem[_t_30 + 12] = _h_242;
      e.mem[_t_30 + 13] = _h_243;
      e.mem[_t_30 + 14] = _h_244;
      e.mem[_t_30 + 15] = _h_245;
      e.mem[_t_30 + 16] = _h_246;
      e.mem[_t_30 + 17] = _h_247;
      e.mem[_t_30 + 18] = _h_248;
      e.mem[_t_30 + 19] = _h_249;
      e.mem[_t_30 + 20] = _h_250;
      e.mem[_t_30 + 21] = _h_251;
      e.mem[_t_30 + 22] = _h_252;
      e.mem[_t_30 + 23] = _h_253;
      e.mem[_t_30 + 24] = _h_254;
      e.mem[_t_30 + 25] = _h_229;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K649, _t_30);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_2)) {
      u64 _t_31 = task_node(e, FID_LIST_SHOW_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_242;
      return term_tsk(FID_LIST_SHOW_2, _t_31);
    }
    r0 = _h_242;
    WL_JMP(FID_LIST_SHOW_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K649)
  {
    WL_POPN(26);
    u32 _h_256 = STK(0);
    u32 _h_257 = STK(1);
    u32 _h_258 = STK(2);
    u32 _h_259 = STK(3);
    Term _h_260 = STK(4);
    Term _h_261 = STK(5);
    Term _h_262 = STK(6);
    Term _h_263 = STK(7);
    Term _h_264 = STK(8);
    Term _h_265 = STK(9);
    Term _h_266 = STK(10);
    Term _h_267 = STK(11);
    Term _h_268 = STK(12);
    u32 _h_269 = STK(13);
    u32 _h_270 = STK(14);
    Term _h_271 = STK(15);
    Term _h_272 = STK(16);
    Term _h_273 = STK(17);
    Term _h_274 = STK(18);
    Term _h_275 = STK(19);
    Term _h_276 = STK(20);
    Term _h_277 = STK(21);
    Term _h_278 = STK(22);
    Term _h_279 = STK(23);
    Term _h_280 = STK(24);
    Term _h_281 = STK(25);
    Term _h_255 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_256;
      STK(1) = _h_257;
      STK(2) = _h_258;
      STK(3) = _h_259;
      STK(4) = _h_260;
      STK(5) = _h_261;
      STK(6) = _h_262;
      STK(7) = _h_263;
      STK(8) = _h_264;
      STK(9) = _h_265;
      STK(10) = _h_266;
      STK(11) = _h_267;
      STK(12) = _h_268;
      STK(13) = _h_269;
      STK(14) = _h_270;
      STK(15) = _h_271;
      STK(16) = _h_272;
      STK(17) = _h_273;
      STK(18) = _h_274;
      STK(19) = _h_275;
      STK(20) = _h_276;
      STK(21) = _h_277;
      STK(22) = _h_278;
      STK(23) = _h_279;
      STK(24) = _h_280;
      STK(25) = _h_281;
      STK(26) = _h_255;
      STK(27) = FID_CONSUMER_OBSERVE_0_K650;
      WL_PUSHN(28);
    } else {
      u64 _t_32 = task_node(e, FID_CONSUMER_OBSERVE_0_K650, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _h_256;
      e.mem[_t_32 + 1] = _h_257;
      e.mem[_t_32 + 2] = _h_258;
      e.mem[_t_32 + 3] = _h_259;
      e.mem[_t_32 + 4] = _h_260;
      e.mem[_t_32 + 5] = _h_261;
      e.mem[_t_32 + 6] = _h_262;
      e.mem[_t_32 + 7] = _h_263;
      e.mem[_t_32 + 8] = _h_264;
      e.mem[_t_32 + 9] = _h_265;
      e.mem[_t_32 + 10] = _h_266;
      e.mem[_t_32 + 11] = _h_267;
      e.mem[_t_32 + 12] = _h_268;
      e.mem[_t_32 + 13] = _h_269;
      e.mem[_t_32 + 14] = _h_270;
      e.mem[_t_32 + 15] = _h_271;
      e.mem[_t_32 + 16] = _h_272;
      e.mem[_t_32 + 17] = _h_273;
      e.mem[_t_32 + 18] = _h_274;
      e.mem[_t_32 + 19] = _h_275;
      e.mem[_t_32 + 20] = _h_276;
      e.mem[_t_32 + 21] = _h_277;
      e.mem[_t_32 + 22] = _h_278;
      e.mem[_t_32 + 23] = _h_279;
      e.mem[_t_32 + 24] = _h_280;
      e.mem[_t_32 + 25] = _h_281;
      e.mem[_t_32 + 26] = _h_255;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K650, _t_32);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_33 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = _h_269;
      return term_tsk(FID_U32_SHOW, _t_33);
    }
    r0 = _h_269;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K650)
  {
    WL_POPN(27);
    u32 _h_283 = STK(0);
    u32 _h_284 = STK(1);
    u32 _h_285 = STK(2);
    u32 _h_286 = STK(3);
    Term _h_287 = STK(4);
    Term _h_288 = STK(5);
    Term _h_289 = STK(6);
    Term _h_290 = STK(7);
    Term _h_291 = STK(8);
    Term _h_292 = STK(9);
    Term _h_293 = STK(10);
    Term _h_294 = STK(11);
    Term _h_295 = STK(12);
    u32 _h_296 = STK(13);
    u32 _h_297 = STK(14);
    Term _h_298 = STK(15);
    Term _h_299 = STK(16);
    Term _h_300 = STK(17);
    Term _h_301 = STK(18);
    Term _h_302 = STK(19);
    Term _h_303 = STK(20);
    Term _h_304 = STK(21);
    Term _h_305 = STK(22);
    Term _h_306 = STK(23);
    Term _h_307 = STK(24);
    Term _h_308 = STK(25);
    Term _h_309 = STK(26);
    Term _h_282 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_283;
      STK(1) = _h_284;
      STK(2) = _h_285;
      STK(3) = _h_286;
      STK(4) = _h_287;
      STK(5) = _h_288;
      STK(6) = _h_289;
      STK(7) = _h_290;
      STK(8) = _h_291;
      STK(9) = _h_292;
      STK(10) = _h_293;
      STK(11) = _h_294;
      STK(12) = _h_295;
      STK(13) = _h_296;
      STK(14) = _h_297;
      STK(15) = _h_298;
      STK(16) = _h_299;
      STK(17) = _h_300;
      STK(18) = _h_301;
      STK(19) = _h_302;
      STK(20) = _h_303;
      STK(21) = _h_304;
      STK(22) = _h_305;
      STK(23) = _h_306;
      STK(24) = _h_307;
      STK(25) = _h_308;
      STK(26) = _h_309;
      STK(27) = _h_282;
      STK(28) = FID_CONSUMER_OBSERVE_0_K651;
      WL_PUSHN(29);
    } else {
      u64 _t_34 = task_node(e, FID_CONSUMER_OBSERVE_0_K651, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _h_283;
      e.mem[_t_34 + 1] = _h_284;
      e.mem[_t_34 + 2] = _h_285;
      e.mem[_t_34 + 3] = _h_286;
      e.mem[_t_34 + 4] = _h_287;
      e.mem[_t_34 + 5] = _h_288;
      e.mem[_t_34 + 6] = _h_289;
      e.mem[_t_34 + 7] = _h_290;
      e.mem[_t_34 + 8] = _h_291;
      e.mem[_t_34 + 9] = _h_292;
      e.mem[_t_34 + 10] = _h_293;
      e.mem[_t_34 + 11] = _h_294;
      e.mem[_t_34 + 12] = _h_295;
      e.mem[_t_34 + 13] = _h_296;
      e.mem[_t_34 + 14] = _h_297;
      e.mem[_t_34 + 15] = _h_298;
      e.mem[_t_34 + 16] = _h_299;
      e.mem[_t_34 + 17] = _h_300;
      e.mem[_t_34 + 18] = _h_301;
      e.mem[_t_34 + 19] = _h_302;
      e.mem[_t_34 + 20] = _h_303;
      e.mem[_t_34 + 21] = _h_304;
      e.mem[_t_34 + 22] = _h_305;
      e.mem[_t_34 + 23] = _h_306;
      e.mem[_t_34 + 24] = _h_307;
      e.mem[_t_34 + 25] = _h_308;
      e.mem[_t_34 + 26] = _h_309;
      e.mem[_t_34 + 27] = _h_282;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K651, _t_34);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_35 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _h_297;
      return term_tsk(FID_U32_SHOW, _t_35);
    }
    r0 = _h_297;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K651)
  {
    WL_POPN(28);
    u32 _h_311 = STK(0);
    u32 _h_312 = STK(1);
    u32 _h_313 = STK(2);
    u32 _h_314 = STK(3);
    Term _h_315 = STK(4);
    Term _h_316 = STK(5);
    Term _h_317 = STK(6);
    Term _h_318 = STK(7);
    Term _h_319 = STK(8);
    Term _h_320 = STK(9);
    Term _h_321 = STK(10);
    Term _h_322 = STK(11);
    Term _h_323 = STK(12);
    u32 _h_324 = STK(13);
    u32 _h_325 = STK(14);
    Term _h_326 = STK(15);
    Term _h_327 = STK(16);
    Term _h_328 = STK(17);
    Term _h_329 = STK(18);
    Term _h_330 = STK(19);
    Term _h_331 = STK(20);
    Term _h_332 = STK(21);
    Term _h_333 = STK(22);
    Term _h_334 = STK(23);
    Term _h_335 = STK(24);
    Term _h_336 = STK(25);
    Term _h_337 = STK(26);
    Term _h_338 = STK(27);
    Term _h_310 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_311;
      STK(1) = _h_312;
      STK(2) = _h_313;
      STK(3) = _h_314;
      STK(4) = _h_315;
      STK(5) = _h_316;
      STK(6) = _h_317;
      STK(7) = _h_318;
      STK(8) = _h_319;
      STK(9) = _h_320;
      STK(10) = _h_321;
      STK(11) = _h_322;
      STK(12) = _h_323;
      STK(13) = _h_324;
      STK(14) = _h_325;
      STK(15) = _h_326;
      STK(16) = _h_327;
      STK(17) = _h_328;
      STK(18) = _h_329;
      STK(19) = _h_330;
      STK(20) = _h_331;
      STK(21) = _h_332;
      STK(22) = _h_333;
      STK(23) = _h_334;
      STK(24) = _h_335;
      STK(25) = _h_336;
      STK(26) = _h_337;
      STK(27) = _h_338;
      STK(28) = FID_CONSUMER_OBSERVE_0_K652;
      WL_PUSHN(29);
    } else {
      u64 _t_36 = task_node(e, FID_CONSUMER_OBSERVE_0_K652, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _h_311;
      e.mem[_t_36 + 1] = _h_312;
      e.mem[_t_36 + 2] = _h_313;
      e.mem[_t_36 + 3] = _h_314;
      e.mem[_t_36 + 4] = _h_315;
      e.mem[_t_36 + 5] = _h_316;
      e.mem[_t_36 + 6] = _h_317;
      e.mem[_t_36 + 7] = _h_318;
      e.mem[_t_36 + 8] = _h_319;
      e.mem[_t_36 + 9] = _h_320;
      e.mem[_t_36 + 10] = _h_321;
      e.mem[_t_36 + 11] = _h_322;
      e.mem[_t_36 + 12] = _h_323;
      e.mem[_t_36 + 13] = _h_324;
      e.mem[_t_36 + 14] = _h_325;
      e.mem[_t_36 + 15] = _h_326;
      e.mem[_t_36 + 16] = _h_327;
      e.mem[_t_36 + 17] = _h_328;
      e.mem[_t_36 + 18] = _h_329;
      e.mem[_t_36 + 19] = _h_330;
      e.mem[_t_36 + 20] = _h_331;
      e.mem[_t_36 + 21] = _h_332;
      e.mem[_t_36 + 22] = _h_333;
      e.mem[_t_36 + 23] = _h_334;
      e.mem[_t_36 + 24] = _h_335;
      e.mem[_t_36 + 25] = _h_336;
      e.mem[_t_36 + 26] = _h_337;
      e.mem[_t_36 + 27] = _h_338;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K652, _t_36);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_37 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = term_ctr(CID_SCON, STAT_OFF + 148);
      e.mem[_t_37 + 1] = _h_310;
      return term_tsk(FID_STRING_APPEND, _t_37);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 148);
    r1 = _h_310;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K652)
  {
    WL_POPN(28);
    u32 _h_340 = STK(0);
    u32 _h_341 = STK(1);
    u32 _h_342 = STK(2);
    u32 _h_343 = STK(3);
    Term _h_344 = STK(4);
    Term _h_345 = STK(5);
    Term _h_346 = STK(6);
    Term _h_347 = STK(7);
    Term _h_348 = STK(8);
    Term _h_349 = STK(9);
    Term _h_350 = STK(10);
    Term _h_351 = STK(11);
    Term _h_352 = STK(12);
    u32 _h_353 = STK(13);
    u32 _h_354 = STK(14);
    Term _h_355 = STK(15);
    Term _h_356 = STK(16);
    Term _h_357 = STK(17);
    Term _h_358 = STK(18);
    Term _h_359 = STK(19);
    Term _h_360 = STK(20);
    Term _h_361 = STK(21);
    Term _h_362 = STK(22);
    Term _h_363 = STK(23);
    Term _h_364 = STK(24);
    Term _h_365 = STK(25);
    Term _h_366 = STK(26);
    Term _h_367 = STK(27);
    Term _h_339 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_340;
      STK(1) = _h_341;
      STK(2) = _h_342;
      STK(3) = _h_343;
      STK(4) = _h_344;
      STK(5) = _h_345;
      STK(6) = _h_346;
      STK(7) = _h_347;
      STK(8) = _h_348;
      STK(9) = _h_349;
      STK(10) = _h_350;
      STK(11) = _h_351;
      STK(12) = _h_352;
      STK(13) = _h_353;
      STK(14) = _h_354;
      STK(15) = _h_355;
      STK(16) = _h_356;
      STK(17) = _h_357;
      STK(18) = _h_358;
      STK(19) = _h_359;
      STK(20) = _h_360;
      STK(21) = _h_361;
      STK(22) = _h_362;
      STK(23) = _h_363;
      STK(24) = _h_364;
      STK(25) = _h_365;
      STK(26) = _h_366;
      STK(27) = FID_CONSUMER_OBSERVE_0_K653;
      WL_PUSHN(28);
    } else {
      u64 _t_38 = task_node(e, FID_CONSUMER_OBSERVE_0_K653, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _h_340;
      e.mem[_t_38 + 1] = _h_341;
      e.mem[_t_38 + 2] = _h_342;
      e.mem[_t_38 + 3] = _h_343;
      e.mem[_t_38 + 4] = _h_344;
      e.mem[_t_38 + 5] = _h_345;
      e.mem[_t_38 + 6] = _h_346;
      e.mem[_t_38 + 7] = _h_347;
      e.mem[_t_38 + 8] = _h_348;
      e.mem[_t_38 + 9] = _h_349;
      e.mem[_t_38 + 10] = _h_350;
      e.mem[_t_38 + 11] = _h_351;
      e.mem[_t_38 + 12] = _h_352;
      e.mem[_t_38 + 13] = _h_353;
      e.mem[_t_38 + 14] = _h_354;
      e.mem[_t_38 + 15] = _h_355;
      e.mem[_t_38 + 16] = _h_356;
      e.mem[_t_38 + 17] = _h_357;
      e.mem[_t_38 + 18] = _h_358;
      e.mem[_t_38 + 19] = _h_359;
      e.mem[_t_38 + 20] = _h_360;
      e.mem[_t_38 + 21] = _h_361;
      e.mem[_t_38 + 22] = _h_362;
      e.mem[_t_38 + 23] = _h_363;
      e.mem[_t_38 + 24] = _h_364;
      e.mem[_t_38 + 25] = _h_365;
      e.mem[_t_38 + 26] = _h_366;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K653, _t_38);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_39 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _h_367;
      e.mem[_t_39 + 1] = _h_339;
      return term_tsk(FID_STRING_APPEND, _t_39);
    }
    r0 = _h_367;
    r1 = _h_339;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K653)
  {
    WL_POPN(27);
    u32 _h_369 = STK(0);
    u32 _h_370 = STK(1);
    u32 _h_371 = STK(2);
    u32 _h_372 = STK(3);
    Term _h_373 = STK(4);
    Term _h_374 = STK(5);
    Term _h_375 = STK(6);
    Term _h_376 = STK(7);
    Term _h_377 = STK(8);
    Term _h_378 = STK(9);
    Term _h_379 = STK(10);
    Term _h_380 = STK(11);
    Term _h_381 = STK(12);
    u32 _h_382 = STK(13);
    u32 _h_383 = STK(14);
    Term _h_384 = STK(15);
    Term _h_385 = STK(16);
    Term _h_386 = STK(17);
    Term _h_387 = STK(18);
    Term _h_388 = STK(19);
    Term _h_389 = STK(20);
    Term _h_390 = STK(21);
    Term _h_391 = STK(22);
    Term _h_392 = STK(23);
    Term _h_393 = STK(24);
    Term _h_394 = STK(25);
    Term _h_395 = STK(26);
    Term _h_368 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_369;
      STK(1) = _h_370;
      STK(2) = _h_371;
      STK(3) = _h_372;
      STK(4) = _h_373;
      STK(5) = _h_374;
      STK(6) = _h_375;
      STK(7) = _h_376;
      STK(8) = _h_377;
      STK(9) = _h_378;
      STK(10) = _h_379;
      STK(11) = _h_380;
      STK(12) = _h_381;
      STK(13) = _h_382;
      STK(14) = _h_383;
      STK(15) = _h_384;
      STK(16) = _h_385;
      STK(17) = _h_386;
      STK(18) = _h_387;
      STK(19) = _h_388;
      STK(20) = _h_389;
      STK(21) = _h_390;
      STK(22) = _h_391;
      STK(23) = _h_392;
      STK(24) = _h_393;
      STK(25) = _h_394;
      STK(26) = _h_395;
      STK(27) = FID_CONSUMER_OBSERVE_0_K654;
      WL_PUSHN(28);
    } else {
      u64 _t_40 = task_node(e, FID_CONSUMER_OBSERVE_0_K654, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _h_369;
      e.mem[_t_40 + 1] = _h_370;
      e.mem[_t_40 + 2] = _h_371;
      e.mem[_t_40 + 3] = _h_372;
      e.mem[_t_40 + 4] = _h_373;
      e.mem[_t_40 + 5] = _h_374;
      e.mem[_t_40 + 6] = _h_375;
      e.mem[_t_40 + 7] = _h_376;
      e.mem[_t_40 + 8] = _h_377;
      e.mem[_t_40 + 9] = _h_378;
      e.mem[_t_40 + 10] = _h_379;
      e.mem[_t_40 + 11] = _h_380;
      e.mem[_t_40 + 12] = _h_381;
      e.mem[_t_40 + 13] = _h_382;
      e.mem[_t_40 + 14] = _h_383;
      e.mem[_t_40 + 15] = _h_384;
      e.mem[_t_40 + 16] = _h_385;
      e.mem[_t_40 + 17] = _h_386;
      e.mem[_t_40 + 18] = _h_387;
      e.mem[_t_40 + 19] = _h_388;
      e.mem[_t_40 + 20] = _h_389;
      e.mem[_t_40 + 21] = _h_390;
      e.mem[_t_40 + 22] = _h_391;
      e.mem[_t_40 + 23] = _h_392;
      e.mem[_t_40 + 24] = _h_393;
      e.mem[_t_40 + 25] = _h_394;
      e.mem[_t_40 + 26] = _h_395;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K654, _t_40);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_41 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 170);
      e.mem[_t_41 + 1] = _h_368;
      return term_tsk(FID_STRING_APPEND, _t_41);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 170);
    r1 = _h_368;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K654)
  {
    WL_POPN(27);
    u32 _h_397 = STK(0);
    u32 _h_398 = STK(1);
    u32 _h_399 = STK(2);
    u32 _h_400 = STK(3);
    Term _h_401 = STK(4);
    Term _h_402 = STK(5);
    Term _h_403 = STK(6);
    Term _h_404 = STK(7);
    Term _h_405 = STK(8);
    Term _h_406 = STK(9);
    Term _h_407 = STK(10);
    Term _h_408 = STK(11);
    Term _h_409 = STK(12);
    u32 _h_410 = STK(13);
    u32 _h_411 = STK(14);
    Term _h_412 = STK(15);
    Term _h_413 = STK(16);
    Term _h_414 = STK(17);
    Term _h_415 = STK(18);
    Term _h_416 = STK(19);
    Term _h_417 = STK(20);
    Term _h_418 = STK(21);
    Term _h_419 = STK(22);
    Term _h_420 = STK(23);
    Term _h_421 = STK(24);
    Term _h_422 = STK(25);
    Term _h_423 = STK(26);
    Term _h_396 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _h_397;
      STK(1) = _h_398;
      STK(2) = _h_399;
      STK(3) = _h_400;
      STK(4) = _h_401;
      STK(5) = _h_402;
      STK(6) = _h_403;
      STK(7) = _h_404;
      STK(8) = _h_405;
      STK(9) = _h_406;
      STK(10) = _h_407;
      STK(11) = _h_408;
      STK(12) = _h_409;
      STK(13) = _h_410;
      STK(14) = _h_411;
      STK(15) = _h_412;
      STK(16) = _h_413;
      STK(17) = _h_414;
      STK(18) = _h_415;
      STK(19) = _h_416;
      STK(20) = _h_417;
      STK(21) = _h_418;
      STK(22) = _h_419;
      STK(23) = _h_420;
      STK(24) = _h_421;
      STK(25) = _h_422;
      STK(26) = FID_CONSUMER_OBSERVE_0_K655;
      WL_PUSHN(27);
    } else {
      u64 _t_42 = task_node(e, FID_CONSUMER_OBSERVE_0_K655, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _h_397;
      e.mem[_t_42 + 1] = _h_398;
      e.mem[_t_42 + 2] = _h_399;
      e.mem[_t_42 + 3] = _h_400;
      e.mem[_t_42 + 4] = _h_401;
      e.mem[_t_42 + 5] = _h_402;
      e.mem[_t_42 + 6] = _h_403;
      e.mem[_t_42 + 7] = _h_404;
      e.mem[_t_42 + 8] = _h_405;
      e.mem[_t_42 + 9] = _h_406;
      e.mem[_t_42 + 10] = _h_407;
      e.mem[_t_42 + 11] = _h_408;
      e.mem[_t_42 + 12] = _h_409;
      e.mem[_t_42 + 13] = _h_410;
      e.mem[_t_42 + 14] = _h_411;
      e.mem[_t_42 + 15] = _h_412;
      e.mem[_t_42 + 16] = _h_413;
      e.mem[_t_42 + 17] = _h_414;
      e.mem[_t_42 + 18] = _h_415;
      e.mem[_t_42 + 19] = _h_416;
      e.mem[_t_42 + 20] = _h_417;
      e.mem[_t_42 + 21] = _h_418;
      e.mem[_t_42 + 22] = _h_419;
      e.mem[_t_42 + 23] = _h_420;
      e.mem[_t_42 + 24] = _h_421;
      e.mem[_t_42 + 25] = _h_422;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K655, _t_42);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_43 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _h_423;
      e.mem[_t_43 + 1] = _h_396;
      return term_tsk(FID_STRING_APPEND, _t_43);
    }
    r0 = _h_423;
    r1 = _h_396;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K655)
  {
    WL_POPN(26);
    u32 _h_425 = STK(0);
    u32 _h_426 = STK(1);
    u32 _h_427 = STK(2);
    u32 _h_428 = STK(3);
    Term _h_429 = STK(4);
    Term _h_430 = STK(5);
    Term _h_431 = STK(6);
    Term _h_432 = STK(7);
    Term _h_433 = STK(8);
    Term _h_434 = STK(9);
    Term _h_435 = STK(10);
    Term _h_436 = STK(11);
    Term _h_437 = STK(12);
    u32 _h_438 = STK(13);
    u32 _h_439 = STK(14);
    Term _h_440 = STK(15);
    Term _h_441 = STK(16);
    Term _h_442 = STK(17);
    Term _h_443 = STK(18);
    Term _h_444 = STK(19);
    Term _h_445 = STK(20);
    Term _h_446 = STK(21);
    Term _h_447 = STK(22);
    Term _h_448 = STK(23);
    Term _h_449 = STK(24);
    Term _h_450 = STK(25);
    Term _h_424 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _h_425;
      STK(1) = _h_426;
      STK(2) = _h_427;
      STK(3) = _h_428;
      STK(4) = _h_429;
      STK(5) = _h_430;
      STK(6) = _h_431;
      STK(7) = _h_432;
      STK(8) = _h_433;
      STK(9) = _h_434;
      STK(10) = _h_435;
      STK(11) = _h_436;
      STK(12) = _h_437;
      STK(13) = _h_438;
      STK(14) = _h_439;
      STK(15) = _h_440;
      STK(16) = _h_441;
      STK(17) = _h_442;
      STK(18) = _h_443;
      STK(19) = _h_444;
      STK(20) = _h_445;
      STK(21) = _h_446;
      STK(22) = _h_447;
      STK(23) = _h_448;
      STK(24) = _h_449;
      STK(25) = _h_450;
      STK(26) = FID_CONSUMER_OBSERVE_0_K656;
      WL_PUSHN(27);
    } else {
      u64 _t_44 = task_node(e, FID_CONSUMER_OBSERVE_0_K656, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _h_425;
      e.mem[_t_44 + 1] = _h_426;
      e.mem[_t_44 + 2] = _h_427;
      e.mem[_t_44 + 3] = _h_428;
      e.mem[_t_44 + 4] = _h_429;
      e.mem[_t_44 + 5] = _h_430;
      e.mem[_t_44 + 6] = _h_431;
      e.mem[_t_44 + 7] = _h_432;
      e.mem[_t_44 + 8] = _h_433;
      e.mem[_t_44 + 9] = _h_434;
      e.mem[_t_44 + 10] = _h_435;
      e.mem[_t_44 + 11] = _h_436;
      e.mem[_t_44 + 12] = _h_437;
      e.mem[_t_44 + 13] = _h_438;
      e.mem[_t_44 + 14] = _h_439;
      e.mem[_t_44 + 15] = _h_440;
      e.mem[_t_44 + 16] = _h_441;
      e.mem[_t_44 + 17] = _h_442;
      e.mem[_t_44 + 18] = _h_443;
      e.mem[_t_44 + 19] = _h_444;
      e.mem[_t_44 + 20] = _h_445;
      e.mem[_t_44 + 21] = _h_446;
      e.mem[_t_44 + 22] = _h_447;
      e.mem[_t_44 + 23] = _h_448;
      e.mem[_t_44 + 24] = _h_449;
      e.mem[_t_44 + 25] = _h_450;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K656, _t_44);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_45 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = term_ctr(CID_SCON, STAT_OFF + 180);
      e.mem[_t_45 + 1] = _h_424;
      return term_tsk(FID_STRING_APPEND, _t_45);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 180);
    r1 = _h_424;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K656)
  {
    WL_POPN(26);
    u32 _h_452 = STK(0);
    u32 _h_453 = STK(1);
    u32 _h_454 = STK(2);
    u32 _h_455 = STK(3);
    Term _h_456 = STK(4);
    Term _h_457 = STK(5);
    Term _h_458 = STK(6);
    Term _h_459 = STK(7);
    Term _h_460 = STK(8);
    Term _h_461 = STK(9);
    Term _h_462 = STK(10);
    Term _h_463 = STK(11);
    Term _h_464 = STK(12);
    u32 _h_465 = STK(13);
    u32 _h_466 = STK(14);
    Term _h_467 = STK(15);
    Term _h_468 = STK(16);
    Term _h_469 = STK(17);
    Term _h_470 = STK(18);
    Term _h_471 = STK(19);
    Term _h_472 = STK(20);
    Term _h_473 = STK(21);
    Term _h_474 = STK(22);
    Term _h_475 = STK(23);
    Term _h_476 = STK(24);
    Term _h_477 = STK(25);
    Term _h_451 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _h_452;
      STK(1) = _h_453;
      STK(2) = _h_454;
      STK(3) = _h_455;
      STK(4) = _h_456;
      STK(5) = _h_457;
      STK(6) = _h_458;
      STK(7) = _h_459;
      STK(8) = _h_460;
      STK(9) = _h_461;
      STK(10) = _h_462;
      STK(11) = _h_463;
      STK(12) = _h_464;
      STK(13) = _h_465;
      STK(14) = _h_466;
      STK(15) = _h_467;
      STK(16) = _h_468;
      STK(17) = _h_469;
      STK(18) = _h_470;
      STK(19) = _h_471;
      STK(20) = _h_472;
      STK(21) = _h_473;
      STK(22) = _h_474;
      STK(23) = _h_475;
      STK(24) = _h_476;
      STK(25) = FID_CONSUMER_OBSERVE_0_K657;
      WL_PUSHN(26);
    } else {
      u64 _t_46 = task_node(e, FID_CONSUMER_OBSERVE_0_K657, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _h_452;
      e.mem[_t_46 + 1] = _h_453;
      e.mem[_t_46 + 2] = _h_454;
      e.mem[_t_46 + 3] = _h_455;
      e.mem[_t_46 + 4] = _h_456;
      e.mem[_t_46 + 5] = _h_457;
      e.mem[_t_46 + 6] = _h_458;
      e.mem[_t_46 + 7] = _h_459;
      e.mem[_t_46 + 8] = _h_460;
      e.mem[_t_46 + 9] = _h_461;
      e.mem[_t_46 + 10] = _h_462;
      e.mem[_t_46 + 11] = _h_463;
      e.mem[_t_46 + 12] = _h_464;
      e.mem[_t_46 + 13] = _h_465;
      e.mem[_t_46 + 14] = _h_466;
      e.mem[_t_46 + 15] = _h_467;
      e.mem[_t_46 + 16] = _h_468;
      e.mem[_t_46 + 17] = _h_469;
      e.mem[_t_46 + 18] = _h_470;
      e.mem[_t_46 + 19] = _h_471;
      e.mem[_t_46 + 20] = _h_472;
      e.mem[_t_46 + 21] = _h_473;
      e.mem[_t_46 + 22] = _h_474;
      e.mem[_t_46 + 23] = _h_475;
      e.mem[_t_46 + 24] = _h_476;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K657, _t_46);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_47 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = _h_477;
      e.mem[_t_47 + 1] = _h_451;
      return term_tsk(FID_STRING_APPEND, _t_47);
    }
    r0 = _h_477;
    r1 = _h_451;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K657)
  {
    WL_POPN(25);
    u32 _h_479 = STK(0);
    u32 _h_480 = STK(1);
    u32 _h_481 = STK(2);
    u32 _h_482 = STK(3);
    Term _h_483 = STK(4);
    Term _h_484 = STK(5);
    Term _h_485 = STK(6);
    Term _h_486 = STK(7);
    Term _h_487 = STK(8);
    Term _h_488 = STK(9);
    Term _h_489 = STK(10);
    Term _h_490 = STK(11);
    Term _h_491 = STK(12);
    u32 _h_492 = STK(13);
    u32 _h_493 = STK(14);
    Term _h_494 = STK(15);
    Term _h_495 = STK(16);
    Term _h_496 = STK(17);
    Term _h_497 = STK(18);
    Term _h_498 = STK(19);
    Term _h_499 = STK(20);
    Term _h_500 = STK(21);
    Term _h_501 = STK(22);
    Term _h_502 = STK(23);
    Term _h_503 = STK(24);
    Term _h_478 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _h_479;
      STK(1) = _h_480;
      STK(2) = _h_481;
      STK(3) = _h_482;
      STK(4) = _h_483;
      STK(5) = _h_484;
      STK(6) = _h_485;
      STK(7) = _h_486;
      STK(8) = _h_487;
      STK(9) = _h_488;
      STK(10) = _h_489;
      STK(11) = _h_490;
      STK(12) = _h_491;
      STK(13) = _h_492;
      STK(14) = _h_493;
      STK(15) = _h_494;
      STK(16) = _h_495;
      STK(17) = _h_496;
      STK(18) = _h_497;
      STK(19) = _h_498;
      STK(20) = _h_499;
      STK(21) = _h_500;
      STK(22) = _h_501;
      STK(23) = _h_502;
      STK(24) = _h_503;
      STK(25) = FID_CONSUMER_OBSERVE_0_K658;
      WL_PUSHN(26);
    } else {
      u64 _t_48 = task_node(e, FID_CONSUMER_OBSERVE_0_K658, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _h_479;
      e.mem[_t_48 + 1] = _h_480;
      e.mem[_t_48 + 2] = _h_481;
      e.mem[_t_48 + 3] = _h_482;
      e.mem[_t_48 + 4] = _h_483;
      e.mem[_t_48 + 5] = _h_484;
      e.mem[_t_48 + 6] = _h_485;
      e.mem[_t_48 + 7] = _h_486;
      e.mem[_t_48 + 8] = _h_487;
      e.mem[_t_48 + 9] = _h_488;
      e.mem[_t_48 + 10] = _h_489;
      e.mem[_t_48 + 11] = _h_490;
      e.mem[_t_48 + 12] = _h_491;
      e.mem[_t_48 + 13] = _h_492;
      e.mem[_t_48 + 14] = _h_493;
      e.mem[_t_48 + 15] = _h_494;
      e.mem[_t_48 + 16] = _h_495;
      e.mem[_t_48 + 17] = _h_496;
      e.mem[_t_48 + 18] = _h_497;
      e.mem[_t_48 + 19] = _h_498;
      e.mem[_t_48 + 20] = _h_499;
      e.mem[_t_48 + 21] = _h_500;
      e.mem[_t_48 + 22] = _h_501;
      e.mem[_t_48 + 23] = _h_502;
      e.mem[_t_48 + 24] = _h_503;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K658, _t_48);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_49 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = term_ctr(CID_SCON, STAT_OFF + 196);
      e.mem[_t_49 + 1] = _h_478;
      return term_tsk(FID_STRING_APPEND, _t_49);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 196);
    r1 = _h_478;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K658)
  {
    WL_POPN(25);
    u32 _h_505 = STK(0);
    u32 _h_506 = STK(1);
    u32 _h_507 = STK(2);
    u32 _h_508 = STK(3);
    Term _h_509 = STK(4);
    Term _h_510 = STK(5);
    Term _h_511 = STK(6);
    Term _h_512 = STK(7);
    Term _h_513 = STK(8);
    Term _h_514 = STK(9);
    Term _h_515 = STK(10);
    Term _h_516 = STK(11);
    Term _h_517 = STK(12);
    u32 _h_518 = STK(13);
    u32 _h_519 = STK(14);
    Term _h_520 = STK(15);
    Term _h_521 = STK(16);
    Term _h_522 = STK(17);
    Term _h_523 = STK(18);
    Term _h_524 = STK(19);
    Term _h_525 = STK(20);
    Term _h_526 = STK(21);
    Term _h_527 = STK(22);
    Term _h_528 = STK(23);
    Term _h_529 = STK(24);
    Term _h_504 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _h_505;
      STK(1) = _h_506;
      STK(2) = _h_507;
      STK(3) = _h_508;
      STK(4) = _h_509;
      STK(5) = _h_510;
      STK(6) = _h_511;
      STK(7) = _h_512;
      STK(8) = _h_513;
      STK(9) = _h_514;
      STK(10) = _h_515;
      STK(11) = _h_516;
      STK(12) = _h_517;
      STK(13) = _h_518;
      STK(14) = _h_519;
      STK(15) = _h_520;
      STK(16) = _h_521;
      STK(17) = _h_522;
      STK(18) = _h_523;
      STK(19) = _h_524;
      STK(20) = _h_525;
      STK(21) = _h_526;
      STK(22) = _h_527;
      STK(23) = _h_528;
      STK(24) = FID_CONSUMER_OBSERVE_0_K659;
      WL_PUSHN(25);
    } else {
      u64 _t_50 = task_node(e, FID_CONSUMER_OBSERVE_0_K659, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _h_505;
      e.mem[_t_50 + 1] = _h_506;
      e.mem[_t_50 + 2] = _h_507;
      e.mem[_t_50 + 3] = _h_508;
      e.mem[_t_50 + 4] = _h_509;
      e.mem[_t_50 + 5] = _h_510;
      e.mem[_t_50 + 6] = _h_511;
      e.mem[_t_50 + 7] = _h_512;
      e.mem[_t_50 + 8] = _h_513;
      e.mem[_t_50 + 9] = _h_514;
      e.mem[_t_50 + 10] = _h_515;
      e.mem[_t_50 + 11] = _h_516;
      e.mem[_t_50 + 12] = _h_517;
      e.mem[_t_50 + 13] = _h_518;
      e.mem[_t_50 + 14] = _h_519;
      e.mem[_t_50 + 15] = _h_520;
      e.mem[_t_50 + 16] = _h_521;
      e.mem[_t_50 + 17] = _h_522;
      e.mem[_t_50 + 18] = _h_523;
      e.mem[_t_50 + 19] = _h_524;
      e.mem[_t_50 + 20] = _h_525;
      e.mem[_t_50 + 21] = _h_526;
      e.mem[_t_50 + 22] = _h_527;
      e.mem[_t_50 + 23] = _h_528;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K659, _t_50);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_51 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = _h_529;
      e.mem[_t_51 + 1] = _h_504;
      return term_tsk(FID_STRING_APPEND, _t_51);
    }
    r0 = _h_529;
    r1 = _h_504;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K659)
  {
    WL_POPN(24);
    u32 _h_531 = STK(0);
    u32 _h_532 = STK(1);
    u32 _h_533 = STK(2);
    u32 _h_534 = STK(3);
    Term _h_535 = STK(4);
    Term _h_536 = STK(5);
    Term _h_537 = STK(6);
    Term _h_538 = STK(7);
    Term _h_539 = STK(8);
    Term _h_540 = STK(9);
    Term _h_541 = STK(10);
    Term _h_542 = STK(11);
    Term _h_543 = STK(12);
    u32 _h_544 = STK(13);
    u32 _h_545 = STK(14);
    Term _h_546 = STK(15);
    Term _h_547 = STK(16);
    Term _h_548 = STK(17);
    Term _h_549 = STK(18);
    Term _h_550 = STK(19);
    Term _h_551 = STK(20);
    Term _h_552 = STK(21);
    Term _h_553 = STK(22);
    Term _h_554 = STK(23);
    Term _h_530 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _h_531;
      STK(1) = _h_532;
      STK(2) = _h_533;
      STK(3) = _h_534;
      STK(4) = _h_535;
      STK(5) = _h_536;
      STK(6) = _h_537;
      STK(7) = _h_538;
      STK(8) = _h_539;
      STK(9) = _h_540;
      STK(10) = _h_541;
      STK(11) = _h_542;
      STK(12) = _h_543;
      STK(13) = _h_544;
      STK(14) = _h_545;
      STK(15) = _h_546;
      STK(16) = _h_547;
      STK(17) = _h_548;
      STK(18) = _h_549;
      STK(19) = _h_550;
      STK(20) = _h_551;
      STK(21) = _h_552;
      STK(22) = _h_553;
      STK(23) = _h_554;
      STK(24) = FID_CONSUMER_OBSERVE_0_K660;
      WL_PUSHN(25);
    } else {
      u64 _t_52 = task_node(e, FID_CONSUMER_OBSERVE_0_K660, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _h_531;
      e.mem[_t_52 + 1] = _h_532;
      e.mem[_t_52 + 2] = _h_533;
      e.mem[_t_52 + 3] = _h_534;
      e.mem[_t_52 + 4] = _h_535;
      e.mem[_t_52 + 5] = _h_536;
      e.mem[_t_52 + 6] = _h_537;
      e.mem[_t_52 + 7] = _h_538;
      e.mem[_t_52 + 8] = _h_539;
      e.mem[_t_52 + 9] = _h_540;
      e.mem[_t_52 + 10] = _h_541;
      e.mem[_t_52 + 11] = _h_542;
      e.mem[_t_52 + 12] = _h_543;
      e.mem[_t_52 + 13] = _h_544;
      e.mem[_t_52 + 14] = _h_545;
      e.mem[_t_52 + 15] = _h_546;
      e.mem[_t_52 + 16] = _h_547;
      e.mem[_t_52 + 17] = _h_548;
      e.mem[_t_52 + 18] = _h_549;
      e.mem[_t_52 + 19] = _h_550;
      e.mem[_t_52 + 20] = _h_551;
      e.mem[_t_52 + 21] = _h_552;
      e.mem[_t_52 + 22] = _h_553;
      e.mem[_t_52 + 23] = _h_554;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K660, _t_52);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = term_ctr(CID_SCON, STAT_OFF + 208);
      e.mem[_t_53 + 1] = _h_530;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 208);
    r1 = _h_530;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K660)
  {
    WL_POPN(24);
    u32 _h_556 = STK(0);
    u32 _h_557 = STK(1);
    u32 _h_558 = STK(2);
    u32 _h_559 = STK(3);
    Term _h_560 = STK(4);
    Term _h_561 = STK(5);
    Term _h_562 = STK(6);
    Term _h_563 = STK(7);
    Term _h_564 = STK(8);
    Term _h_565 = STK(9);
    Term _h_566 = STK(10);
    Term _h_567 = STK(11);
    Term _h_568 = STK(12);
    u32 _h_569 = STK(13);
    u32 _h_570 = STK(14);
    Term _h_571 = STK(15);
    Term _h_572 = STK(16);
    Term _h_573 = STK(17);
    Term _h_574 = STK(18);
    Term _h_575 = STK(19);
    Term _h_576 = STK(20);
    Term _h_577 = STK(21);
    Term _h_578 = STK(22);
    Term _h_579 = STK(23);
    Term _h_555 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_556;
      STK(1) = _h_557;
      STK(2) = _h_558;
      STK(3) = _h_559;
      STK(4) = _h_560;
      STK(5) = _h_561;
      STK(6) = _h_562;
      STK(7) = _h_563;
      STK(8) = _h_564;
      STK(9) = _h_565;
      STK(10) = _h_566;
      STK(11) = _h_567;
      STK(12) = _h_568;
      STK(13) = _h_569;
      STK(14) = _h_570;
      STK(15) = _h_571;
      STK(16) = _h_573;
      STK(17) = _h_574;
      STK(18) = _h_575;
      STK(19) = _h_576;
      STK(20) = _h_577;
      STK(21) = _h_578;
      STK(22) = _h_579;
      STK(23) = FID_CONSUMER_OBSERVE_0_K661;
      WL_PUSHN(24);
    } else {
      u64 _t_54 = task_node(e, FID_CONSUMER_OBSERVE_0_K661, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _h_556;
      e.mem[_t_54 + 1] = _h_557;
      e.mem[_t_54 + 2] = _h_558;
      e.mem[_t_54 + 3] = _h_559;
      e.mem[_t_54 + 4] = _h_560;
      e.mem[_t_54 + 5] = _h_561;
      e.mem[_t_54 + 6] = _h_562;
      e.mem[_t_54 + 7] = _h_563;
      e.mem[_t_54 + 8] = _h_564;
      e.mem[_t_54 + 9] = _h_565;
      e.mem[_t_54 + 10] = _h_566;
      e.mem[_t_54 + 11] = _h_567;
      e.mem[_t_54 + 12] = _h_568;
      e.mem[_t_54 + 13] = _h_569;
      e.mem[_t_54 + 14] = _h_570;
      e.mem[_t_54 + 15] = _h_571;
      e.mem[_t_54 + 16] = _h_573;
      e.mem[_t_54 + 17] = _h_574;
      e.mem[_t_54 + 18] = _h_575;
      e.mem[_t_54 + 19] = _h_576;
      e.mem[_t_54 + 20] = _h_577;
      e.mem[_t_54 + 21] = _h_578;
      e.mem[_t_54 + 22] = _h_579;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K661, _t_54);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_55 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = _h_572;
      e.mem[_t_55 + 1] = _h_555;
      return term_tsk(FID_STRING_APPEND, _t_55);
    }
    r0 = _h_572;
    r1 = _h_555;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K661)
  {
    WL_POPN(23);
    u32 _h_581 = STK(0);
    u32 _h_582 = STK(1);
    u32 _h_583 = STK(2);
    u32 _h_584 = STK(3);
    Term _h_585 = STK(4);
    Term _h_586 = STK(5);
    Term _h_587 = STK(6);
    Term _h_588 = STK(7);
    Term _h_589 = STK(8);
    Term _h_590 = STK(9);
    Term _h_591 = STK(10);
    Term _h_592 = STK(11);
    Term _h_593 = STK(12);
    u32 _h_594 = STK(13);
    u32 _h_595 = STK(14);
    Term _h_596 = STK(15);
    Term _h_597 = STK(16);
    Term _h_598 = STK(17);
    Term _h_599 = STK(18);
    Term _h_600 = STK(19);
    Term _h_601 = STK(20);
    Term _h_602 = STK(21);
    Term _h_603 = STK(22);
    Term _h_580 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_581;
      STK(1) = _h_582;
      STK(2) = _h_583;
      STK(3) = _h_584;
      STK(4) = _h_585;
      STK(5) = _h_586;
      STK(6) = _h_587;
      STK(7) = _h_588;
      STK(8) = _h_589;
      STK(9) = _h_590;
      STK(10) = _h_591;
      STK(11) = _h_592;
      STK(12) = _h_593;
      STK(13) = _h_594;
      STK(14) = _h_595;
      STK(15) = _h_596;
      STK(16) = _h_597;
      STK(17) = _h_598;
      STK(18) = _h_599;
      STK(19) = _h_600;
      STK(20) = _h_601;
      STK(21) = _h_602;
      STK(22) = _h_603;
      STK(23) = FID_CONSUMER_OBSERVE_0_K662;
      WL_PUSHN(24);
    } else {
      u64 _t_56 = task_node(e, FID_CONSUMER_OBSERVE_0_K662, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_581;
      e.mem[_t_56 + 1] = _h_582;
      e.mem[_t_56 + 2] = _h_583;
      e.mem[_t_56 + 3] = _h_584;
      e.mem[_t_56 + 4] = _h_585;
      e.mem[_t_56 + 5] = _h_586;
      e.mem[_t_56 + 6] = _h_587;
      e.mem[_t_56 + 7] = _h_588;
      e.mem[_t_56 + 8] = _h_589;
      e.mem[_t_56 + 9] = _h_590;
      e.mem[_t_56 + 10] = _h_591;
      e.mem[_t_56 + 11] = _h_592;
      e.mem[_t_56 + 12] = _h_593;
      e.mem[_t_56 + 13] = _h_594;
      e.mem[_t_56 + 14] = _h_595;
      e.mem[_t_56 + 15] = _h_596;
      e.mem[_t_56 + 16] = _h_597;
      e.mem[_t_56 + 17] = _h_598;
      e.mem[_t_56 + 18] = _h_599;
      e.mem[_t_56 + 19] = _h_600;
      e.mem[_t_56 + 20] = _h_601;
      e.mem[_t_56 + 21] = _h_602;
      e.mem[_t_56 + 22] = _h_603;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K662, _t_56);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = term_ctr(CID_SCON, STAT_OFF + 226);
      e.mem[_t_57 + 1] = _h_580;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 226);
    r1 = _h_580;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K662)
  {
    WL_POPN(23);
    u32 _h_605 = STK(0);
    u32 _h_606 = STK(1);
    u32 _h_607 = STK(2);
    u32 _h_608 = STK(3);
    Term _h_609 = STK(4);
    Term _h_610 = STK(5);
    Term _h_611 = STK(6);
    Term _h_612 = STK(7);
    Term _h_613 = STK(8);
    Term _h_614 = STK(9);
    Term _h_615 = STK(10);
    Term _h_616 = STK(11);
    Term _h_617 = STK(12);
    u32 _h_618 = STK(13);
    u32 _h_619 = STK(14);
    Term _h_620 = STK(15);
    Term _h_621 = STK(16);
    Term _h_622 = STK(17);
    Term _h_623 = STK(18);
    Term _h_624 = STK(19);
    Term _h_625 = STK(20);
    Term _h_626 = STK(21);
    Term _h_627 = STK(22);
    Term _h_604 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_605;
      STK(1) = _h_606;
      STK(2) = _h_607;
      STK(3) = _h_608;
      STK(4) = _h_609;
      STK(5) = _h_610;
      STK(6) = _h_611;
      STK(7) = _h_612;
      STK(8) = _h_613;
      STK(9) = _h_614;
      STK(10) = _h_615;
      STK(11) = _h_616;
      STK(12) = _h_617;
      STK(13) = _h_618;
      STK(14) = _h_619;
      STK(15) = _h_621;
      STK(16) = _h_622;
      STK(17) = _h_623;
      STK(18) = _h_624;
      STK(19) = _h_625;
      STK(20) = _h_626;
      STK(21) = _h_627;
      STK(22) = FID_CONSUMER_OBSERVE_0_K663;
      WL_PUSHN(23);
    } else {
      u64 _t_58 = task_node(e, FID_CONSUMER_OBSERVE_0_K663, WL_CONT, WL_IDX, 1);
      e.mem[_t_58 + 0] = _h_605;
      e.mem[_t_58 + 1] = _h_606;
      e.mem[_t_58 + 2] = _h_607;
      e.mem[_t_58 + 3] = _h_608;
      e.mem[_t_58 + 4] = _h_609;
      e.mem[_t_58 + 5] = _h_610;
      e.mem[_t_58 + 6] = _h_611;
      e.mem[_t_58 + 7] = _h_612;
      e.mem[_t_58 + 8] = _h_613;
      e.mem[_t_58 + 9] = _h_614;
      e.mem[_t_58 + 10] = _h_615;
      e.mem[_t_58 + 11] = _h_616;
      e.mem[_t_58 + 12] = _h_617;
      e.mem[_t_58 + 13] = _h_618;
      e.mem[_t_58 + 14] = _h_619;
      e.mem[_t_58 + 15] = _h_621;
      e.mem[_t_58 + 16] = _h_622;
      e.mem[_t_58 + 17] = _h_623;
      e.mem[_t_58 + 18] = _h_624;
      e.mem[_t_58 + 19] = _h_625;
      e.mem[_t_58 + 20] = _h_626;
      e.mem[_t_58 + 21] = _h_627;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K663, _t_58);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_59 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = _h_620;
      e.mem[_t_59 + 1] = _h_604;
      return term_tsk(FID_STRING_APPEND, _t_59);
    }
    r0 = _h_620;
    r1 = _h_604;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K663)
  {
    WL_POPN(22);
    u32 _h_629 = STK(0);
    u32 _h_630 = STK(1);
    u32 _h_631 = STK(2);
    u32 _h_632 = STK(3);
    Term _h_633 = STK(4);
    Term _h_634 = STK(5);
    Term _h_635 = STK(6);
    Term _h_636 = STK(7);
    Term _h_637 = STK(8);
    Term _h_638 = STK(9);
    Term _h_639 = STK(10);
    Term _h_640 = STK(11);
    Term _h_641 = STK(12);
    u32 _h_642 = STK(13);
    u32 _h_643 = STK(14);
    Term _h_644 = STK(15);
    Term _h_645 = STK(16);
    Term _h_646 = STK(17);
    Term _h_647 = STK(18);
    Term _h_648 = STK(19);
    Term _h_649 = STK(20);
    Term _h_650 = STK(21);
    Term _h_628 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_629;
      STK(1) = _h_630;
      STK(2) = _h_631;
      STK(3) = _h_632;
      STK(4) = _h_633;
      STK(5) = _h_634;
      STK(6) = _h_635;
      STK(7) = _h_636;
      STK(8) = _h_637;
      STK(9) = _h_638;
      STK(10) = _h_639;
      STK(11) = _h_640;
      STK(12) = _h_641;
      STK(13) = _h_642;
      STK(14) = _h_643;
      STK(15) = _h_644;
      STK(16) = _h_645;
      STK(17) = _h_646;
      STK(18) = _h_647;
      STK(19) = _h_648;
      STK(20) = _h_649;
      STK(21) = _h_650;
      STK(22) = FID_CONSUMER_OBSERVE_0_K664;
      WL_PUSHN(23);
    } else {
      u64 _t_60 = task_node(e, FID_CONSUMER_OBSERVE_0_K664, WL_CONT, WL_IDX, 1);
      e.mem[_t_60 + 0] = _h_629;
      e.mem[_t_60 + 1] = _h_630;
      e.mem[_t_60 + 2] = _h_631;
      e.mem[_t_60 + 3] = _h_632;
      e.mem[_t_60 + 4] = _h_633;
      e.mem[_t_60 + 5] = _h_634;
      e.mem[_t_60 + 6] = _h_635;
      e.mem[_t_60 + 7] = _h_636;
      e.mem[_t_60 + 8] = _h_637;
      e.mem[_t_60 + 9] = _h_638;
      e.mem[_t_60 + 10] = _h_639;
      e.mem[_t_60 + 11] = _h_640;
      e.mem[_t_60 + 12] = _h_641;
      e.mem[_t_60 + 13] = _h_642;
      e.mem[_t_60 + 14] = _h_643;
      e.mem[_t_60 + 15] = _h_644;
      e.mem[_t_60 + 16] = _h_645;
      e.mem[_t_60 + 17] = _h_646;
      e.mem[_t_60 + 18] = _h_647;
      e.mem[_t_60 + 19] = _h_648;
      e.mem[_t_60 + 20] = _h_649;
      e.mem[_t_60 + 21] = _h_650;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K664, _t_60);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_61 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = term_ctr(CID_SCON, STAT_OFF + 228);
      e.mem[_t_61 + 1] = _h_628;
      return term_tsk(FID_STRING_APPEND, _t_61);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 228);
    r1 = _h_628;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K664)
  {
    WL_POPN(22);
    u32 _h_652 = STK(0);
    u32 _h_653 = STK(1);
    u32 _h_654 = STK(2);
    u32 _h_655 = STK(3);
    Term _h_656 = STK(4);
    Term _h_657 = STK(5);
    Term _h_658 = STK(6);
    Term _h_659 = STK(7);
    Term _h_660 = STK(8);
    Term _h_661 = STK(9);
    Term _h_662 = STK(10);
    Term _h_663 = STK(11);
    Term _h_664 = STK(12);
    u32 _h_665 = STK(13);
    u32 _h_666 = STK(14);
    Term _h_667 = STK(15);
    Term _h_668 = STK(16);
    Term _h_669 = STK(17);
    Term _h_670 = STK(18);
    Term _h_671 = STK(19);
    Term _h_672 = STK(20);
    Term _h_673 = STK(21);
    Term _h_651 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_652;
      STK(1) = _h_653;
      STK(2) = _h_654;
      STK(3) = _h_655;
      STK(4) = _h_656;
      STK(5) = _h_657;
      STK(6) = _h_658;
      STK(7) = _h_659;
      STK(8) = _h_660;
      STK(9) = _h_661;
      STK(10) = _h_662;
      STK(11) = _h_663;
      STK(12) = _h_664;
      STK(13) = _h_665;
      STK(14) = _h_666;
      STK(15) = _h_667;
      STK(16) = _h_668;
      STK(17) = _h_669;
      STK(18) = _h_670;
      STK(19) = _h_671;
      STK(20) = _h_672;
      STK(21) = FID_CONSUMER_OBSERVE_0_K665;
      WL_PUSHN(22);
    } else {
      u64 _t_62 = task_node(e, FID_CONSUMER_OBSERVE_0_K665, WL_CONT, WL_IDX, 1);
      e.mem[_t_62 + 0] = _h_652;
      e.mem[_t_62 + 1] = _h_653;
      e.mem[_t_62 + 2] = _h_654;
      e.mem[_t_62 + 3] = _h_655;
      e.mem[_t_62 + 4] = _h_656;
      e.mem[_t_62 + 5] = _h_657;
      e.mem[_t_62 + 6] = _h_658;
      e.mem[_t_62 + 7] = _h_659;
      e.mem[_t_62 + 8] = _h_660;
      e.mem[_t_62 + 9] = _h_661;
      e.mem[_t_62 + 10] = _h_662;
      e.mem[_t_62 + 11] = _h_663;
      e.mem[_t_62 + 12] = _h_664;
      e.mem[_t_62 + 13] = _h_665;
      e.mem[_t_62 + 14] = _h_666;
      e.mem[_t_62 + 15] = _h_667;
      e.mem[_t_62 + 16] = _h_668;
      e.mem[_t_62 + 17] = _h_669;
      e.mem[_t_62 + 18] = _h_670;
      e.mem[_t_62 + 19] = _h_671;
      e.mem[_t_62 + 20] = _h_672;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K665, _t_62);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_63 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = _h_673;
      e.mem[_t_63 + 1] = _h_651;
      return term_tsk(FID_STRING_APPEND, _t_63);
    }
    r0 = _h_673;
    r1 = _h_651;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K665)
  {
    WL_POPN(21);
    u32 _h_675 = STK(0);
    u32 _h_676 = STK(1);
    u32 _h_677 = STK(2);
    u32 _h_678 = STK(3);
    Term _h_679 = STK(4);
    Term _h_680 = STK(5);
    Term _h_681 = STK(6);
    Term _h_682 = STK(7);
    Term _h_683 = STK(8);
    Term _h_684 = STK(9);
    Term _h_685 = STK(10);
    Term _h_686 = STK(11);
    Term _h_687 = STK(12);
    u32 _h_688 = STK(13);
    u32 _h_689 = STK(14);
    Term _h_690 = STK(15);
    Term _h_691 = STK(16);
    Term _h_692 = STK(17);
    Term _h_693 = STK(18);
    Term _h_694 = STK(19);
    Term _h_695 = STK(20);
    Term _h_674 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_675;
      STK(1) = _h_676;
      STK(2) = _h_677;
      STK(3) = _h_678;
      STK(4) = _h_679;
      STK(5) = _h_680;
      STK(6) = _h_681;
      STK(7) = _h_682;
      STK(8) = _h_683;
      STK(9) = _h_684;
      STK(10) = _h_685;
      STK(11) = _h_686;
      STK(12) = _h_687;
      STK(13) = _h_688;
      STK(14) = _h_689;
      STK(15) = _h_690;
      STK(16) = _h_691;
      STK(17) = _h_692;
      STK(18) = _h_693;
      STK(19) = _h_694;
      STK(20) = _h_695;
      STK(21) = FID_CONSUMER_OBSERVE_0_K666;
      WL_PUSHN(22);
    } else {
      u64 _t_64 = task_node(e, FID_CONSUMER_OBSERVE_0_K666, WL_CONT, WL_IDX, 1);
      e.mem[_t_64 + 0] = _h_675;
      e.mem[_t_64 + 1] = _h_676;
      e.mem[_t_64 + 2] = _h_677;
      e.mem[_t_64 + 3] = _h_678;
      e.mem[_t_64 + 4] = _h_679;
      e.mem[_t_64 + 5] = _h_680;
      e.mem[_t_64 + 6] = _h_681;
      e.mem[_t_64 + 7] = _h_682;
      e.mem[_t_64 + 8] = _h_683;
      e.mem[_t_64 + 9] = _h_684;
      e.mem[_t_64 + 10] = _h_685;
      e.mem[_t_64 + 11] = _h_686;
      e.mem[_t_64 + 12] = _h_687;
      e.mem[_t_64 + 13] = _h_688;
      e.mem[_t_64 + 14] = _h_689;
      e.mem[_t_64 + 15] = _h_690;
      e.mem[_t_64 + 16] = _h_691;
      e.mem[_t_64 + 17] = _h_692;
      e.mem[_t_64 + 18] = _h_693;
      e.mem[_t_64 + 19] = _h_694;
      e.mem[_t_64 + 20] = _h_695;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K666, _t_64);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_65 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_65 + 1] = _h_674;
      return term_tsk(FID_STRING_APPEND, _t_65);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_674;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K666)
  {
    WL_POPN(21);
    u32 _h_697 = STK(0);
    u32 _h_698 = STK(1);
    u32 _h_699 = STK(2);
    u32 _h_700 = STK(3);
    Term _h_701 = STK(4);
    Term _h_702 = STK(5);
    Term _h_703 = STK(6);
    Term _h_704 = STK(7);
    Term _h_705 = STK(8);
    Term _h_706 = STK(9);
    Term _h_707 = STK(10);
    Term _h_708 = STK(11);
    Term _h_709 = STK(12);
    u32 _h_710 = STK(13);
    u32 _h_711 = STK(14);
    Term _h_712 = STK(15);
    Term _h_713 = STK(16);
    Term _h_714 = STK(17);
    Term _h_715 = STK(18);
    Term _h_716 = STK(19);
    Term _h_717 = STK(20);
    Term _h_696 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_697;
      STK(1) = _h_698;
      STK(2) = _h_699;
      STK(3) = _h_700;
      STK(4) = _h_701;
      STK(5) = _h_702;
      STK(6) = _h_703;
      STK(7) = _h_704;
      STK(8) = _h_705;
      STK(9) = _h_706;
      STK(10) = _h_707;
      STK(11) = _h_708;
      STK(12) = _h_709;
      STK(13) = _h_710;
      STK(14) = _h_711;
      STK(15) = _h_712;
      STK(16) = _h_713;
      STK(17) = _h_714;
      STK(18) = _h_715;
      STK(19) = _h_716;
      STK(20) = FID_CONSUMER_OBSERVE_0_K667;
      WL_PUSHN(21);
    } else {
      u64 _t_66 = task_node(e, FID_CONSUMER_OBSERVE_0_K667, WL_CONT, WL_IDX, 1);
      e.mem[_t_66 + 0] = _h_697;
      e.mem[_t_66 + 1] = _h_698;
      e.mem[_t_66 + 2] = _h_699;
      e.mem[_t_66 + 3] = _h_700;
      e.mem[_t_66 + 4] = _h_701;
      e.mem[_t_66 + 5] = _h_702;
      e.mem[_t_66 + 6] = _h_703;
      e.mem[_t_66 + 7] = _h_704;
      e.mem[_t_66 + 8] = _h_705;
      e.mem[_t_66 + 9] = _h_706;
      e.mem[_t_66 + 10] = _h_707;
      e.mem[_t_66 + 11] = _h_708;
      e.mem[_t_66 + 12] = _h_709;
      e.mem[_t_66 + 13] = _h_710;
      e.mem[_t_66 + 14] = _h_711;
      e.mem[_t_66 + 15] = _h_712;
      e.mem[_t_66 + 16] = _h_713;
      e.mem[_t_66 + 17] = _h_714;
      e.mem[_t_66 + 18] = _h_715;
      e.mem[_t_66 + 19] = _h_716;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K667, _t_66);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_67 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = _h_717;
      e.mem[_t_67 + 1] = _h_696;
      return term_tsk(FID_STRING_APPEND, _t_67);
    }
    r0 = _h_717;
    r1 = _h_696;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K667)
  {
    WL_POPN(20);
    u32 _h_719 = STK(0);
    u32 _h_720 = STK(1);
    u32 _h_721 = STK(2);
    u32 _h_722 = STK(3);
    Term _h_723 = STK(4);
    Term _h_724 = STK(5);
    Term _h_725 = STK(6);
    Term _h_726 = STK(7);
    Term _h_727 = STK(8);
    Term _h_728 = STK(9);
    Term _h_729 = STK(10);
    Term _h_730 = STK(11);
    Term _h_731 = STK(12);
    u32 _h_732 = STK(13);
    u32 _h_733 = STK(14);
    Term _h_734 = STK(15);
    Term _h_735 = STK(16);
    Term _h_736 = STK(17);
    Term _h_737 = STK(18);
    Term _h_738 = STK(19);
    Term _h_718 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_719;
      STK(1) = _h_720;
      STK(2) = _h_721;
      STK(3) = _h_722;
      STK(4) = _h_723;
      STK(5) = _h_724;
      STK(6) = _h_725;
      STK(7) = _h_726;
      STK(8) = _h_727;
      STK(9) = _h_728;
      STK(10) = _h_729;
      STK(11) = _h_730;
      STK(12) = _h_731;
      STK(13) = _h_732;
      STK(14) = _h_733;
      STK(15) = _h_734;
      STK(16) = _h_735;
      STK(17) = _h_736;
      STK(18) = _h_737;
      STK(19) = _h_738;
      STK(20) = FID_CONSUMER_OBSERVE_0_K668;
      WL_PUSHN(21);
    } else {
      u64 _t_68 = task_node(e, FID_CONSUMER_OBSERVE_0_K668, WL_CONT, WL_IDX, 1);
      e.mem[_t_68 + 0] = _h_719;
      e.mem[_t_68 + 1] = _h_720;
      e.mem[_t_68 + 2] = _h_721;
      e.mem[_t_68 + 3] = _h_722;
      e.mem[_t_68 + 4] = _h_723;
      e.mem[_t_68 + 5] = _h_724;
      e.mem[_t_68 + 6] = _h_725;
      e.mem[_t_68 + 7] = _h_726;
      e.mem[_t_68 + 8] = _h_727;
      e.mem[_t_68 + 9] = _h_728;
      e.mem[_t_68 + 10] = _h_729;
      e.mem[_t_68 + 11] = _h_730;
      e.mem[_t_68 + 12] = _h_731;
      e.mem[_t_68 + 13] = _h_732;
      e.mem[_t_68 + 14] = _h_733;
      e.mem[_t_68 + 15] = _h_734;
      e.mem[_t_68 + 16] = _h_735;
      e.mem[_t_68 + 17] = _h_736;
      e.mem[_t_68 + 18] = _h_737;
      e.mem[_t_68 + 19] = _h_738;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K668, _t_68);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_69 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_69 + 1] = _h_718;
      return term_tsk(FID_STRING_APPEND, _t_69);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_718;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K668)
  {
    WL_POPN(20);
    u32 _h_740 = STK(0);
    u32 _h_741 = STK(1);
    u32 _h_742 = STK(2);
    u32 _h_743 = STK(3);
    Term _h_744 = STK(4);
    Term _h_745 = STK(5);
    Term _h_746 = STK(6);
    Term _h_747 = STK(7);
    Term _h_748 = STK(8);
    Term _h_749 = STK(9);
    Term _h_750 = STK(10);
    Term _h_751 = STK(11);
    Term _h_752 = STK(12);
    u32 _h_753 = STK(13);
    u32 _h_754 = STK(14);
    Term _h_755 = STK(15);
    Term _h_756 = STK(16);
    Term _h_757 = STK(17);
    Term _h_758 = STK(18);
    Term _h_759 = STK(19);
    Term _h_739 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_740;
      STK(1) = _h_741;
      STK(2) = _h_742;
      STK(3) = _h_743;
      STK(4) = _h_744;
      STK(5) = _h_745;
      STK(6) = _h_746;
      STK(7) = _h_747;
      STK(8) = _h_748;
      STK(9) = _h_749;
      STK(10) = _h_750;
      STK(11) = _h_751;
      STK(12) = _h_752;
      STK(13) = _h_753;
      STK(14) = _h_754;
      STK(15) = _h_755;
      STK(16) = _h_757;
      STK(17) = _h_758;
      STK(18) = _h_759;
      STK(19) = FID_CONSUMER_OBSERVE_0_K669;
      WL_PUSHN(20);
    } else {
      u64 _t_70 = task_node(e, FID_CONSUMER_OBSERVE_0_K669, WL_CONT, WL_IDX, 1);
      e.mem[_t_70 + 0] = _h_740;
      e.mem[_t_70 + 1] = _h_741;
      e.mem[_t_70 + 2] = _h_742;
      e.mem[_t_70 + 3] = _h_743;
      e.mem[_t_70 + 4] = _h_744;
      e.mem[_t_70 + 5] = _h_745;
      e.mem[_t_70 + 6] = _h_746;
      e.mem[_t_70 + 7] = _h_747;
      e.mem[_t_70 + 8] = _h_748;
      e.mem[_t_70 + 9] = _h_749;
      e.mem[_t_70 + 10] = _h_750;
      e.mem[_t_70 + 11] = _h_751;
      e.mem[_t_70 + 12] = _h_752;
      e.mem[_t_70 + 13] = _h_753;
      e.mem[_t_70 + 14] = _h_754;
      e.mem[_t_70 + 15] = _h_755;
      e.mem[_t_70 + 16] = _h_757;
      e.mem[_t_70 + 17] = _h_758;
      e.mem[_t_70 + 18] = _h_759;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K669, _t_70);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_71 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = _h_756;
      e.mem[_t_71 + 1] = _h_739;
      return term_tsk(FID_STRING_APPEND, _t_71);
    }
    r0 = _h_756;
    r1 = _h_739;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K669)
  {
    WL_POPN(19);
    u32 _h_761 = STK(0);
    u32 _h_762 = STK(1);
    u32 _h_763 = STK(2);
    u32 _h_764 = STK(3);
    Term _h_765 = STK(4);
    Term _h_766 = STK(5);
    Term _h_767 = STK(6);
    Term _h_768 = STK(7);
    Term _h_769 = STK(8);
    Term _h_770 = STK(9);
    Term _h_771 = STK(10);
    Term _h_772 = STK(11);
    Term _h_773 = STK(12);
    u32 _h_774 = STK(13);
    u32 _h_775 = STK(14);
    Term _h_776 = STK(15);
    Term _h_777 = STK(16);
    Term _h_778 = STK(17);
    Term _h_779 = STK(18);
    Term _h_760 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_761;
      STK(1) = _h_762;
      STK(2) = _h_763;
      STK(3) = _h_764;
      STK(4) = _h_765;
      STK(5) = _h_766;
      STK(6) = _h_767;
      STK(7) = _h_768;
      STK(8) = _h_769;
      STK(9) = _h_770;
      STK(10) = _h_771;
      STK(11) = _h_772;
      STK(12) = _h_773;
      STK(13) = _h_774;
      STK(14) = _h_775;
      STK(15) = _h_776;
      STK(16) = _h_777;
      STK(17) = _h_778;
      STK(18) = _h_779;
      STK(19) = FID_CONSUMER_OBSERVE_0_K670;
      WL_PUSHN(20);
    } else {
      u64 _t_72 = task_node(e, FID_CONSUMER_OBSERVE_0_K670, WL_CONT, WL_IDX, 1);
      e.mem[_t_72 + 0] = _h_761;
      e.mem[_t_72 + 1] = _h_762;
      e.mem[_t_72 + 2] = _h_763;
      e.mem[_t_72 + 3] = _h_764;
      e.mem[_t_72 + 4] = _h_765;
      e.mem[_t_72 + 5] = _h_766;
      e.mem[_t_72 + 6] = _h_767;
      e.mem[_t_72 + 7] = _h_768;
      e.mem[_t_72 + 8] = _h_769;
      e.mem[_t_72 + 9] = _h_770;
      e.mem[_t_72 + 10] = _h_771;
      e.mem[_t_72 + 11] = _h_772;
      e.mem[_t_72 + 12] = _h_773;
      e.mem[_t_72 + 13] = _h_774;
      e.mem[_t_72 + 14] = _h_775;
      e.mem[_t_72 + 15] = _h_776;
      e.mem[_t_72 + 16] = _h_777;
      e.mem[_t_72 + 17] = _h_778;
      e.mem[_t_72 + 18] = _h_779;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K670, _t_72);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_73 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_73 + 1] = _h_760;
      return term_tsk(FID_STRING_APPEND, _t_73);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_760;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K670)
  {
    WL_POPN(19);
    u32 _h_781 = STK(0);
    u32 _h_782 = STK(1);
    u32 _h_783 = STK(2);
    u32 _h_784 = STK(3);
    Term _h_785 = STK(4);
    Term _h_786 = STK(5);
    Term _h_787 = STK(6);
    Term _h_788 = STK(7);
    Term _h_789 = STK(8);
    Term _h_790 = STK(9);
    Term _h_791 = STK(10);
    Term _h_792 = STK(11);
    Term _h_793 = STK(12);
    u32 _h_794 = STK(13);
    u32 _h_795 = STK(14);
    Term _h_796 = STK(15);
    Term _h_797 = STK(16);
    Term _h_798 = STK(17);
    Term _h_799 = STK(18);
    Term _h_780 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_781;
      STK(1) = _h_782;
      STK(2) = _h_783;
      STK(3) = _h_784;
      STK(4) = _h_785;
      STK(5) = _h_786;
      STK(6) = _h_787;
      STK(7) = _h_788;
      STK(8) = _h_789;
      STK(9) = _h_790;
      STK(10) = _h_791;
      STK(11) = _h_792;
      STK(12) = _h_793;
      STK(13) = _h_794;
      STK(14) = _h_795;
      STK(15) = _h_796;
      STK(16) = _h_797;
      STK(17) = _h_798;
      STK(18) = FID_CONSUMER_OBSERVE_0_K671;
      WL_PUSHN(19);
    } else {
      u64 _t_74 = task_node(e, FID_CONSUMER_OBSERVE_0_K671, WL_CONT, WL_IDX, 1);
      e.mem[_t_74 + 0] = _h_781;
      e.mem[_t_74 + 1] = _h_782;
      e.mem[_t_74 + 2] = _h_783;
      e.mem[_t_74 + 3] = _h_784;
      e.mem[_t_74 + 4] = _h_785;
      e.mem[_t_74 + 5] = _h_786;
      e.mem[_t_74 + 6] = _h_787;
      e.mem[_t_74 + 7] = _h_788;
      e.mem[_t_74 + 8] = _h_789;
      e.mem[_t_74 + 9] = _h_790;
      e.mem[_t_74 + 10] = _h_791;
      e.mem[_t_74 + 11] = _h_792;
      e.mem[_t_74 + 12] = _h_793;
      e.mem[_t_74 + 13] = _h_794;
      e.mem[_t_74 + 14] = _h_795;
      e.mem[_t_74 + 15] = _h_796;
      e.mem[_t_74 + 16] = _h_797;
      e.mem[_t_74 + 17] = _h_798;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K671, _t_74);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_75 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = _h_799;
      e.mem[_t_75 + 1] = _h_780;
      return term_tsk(FID_STRING_APPEND, _t_75);
    }
    r0 = _h_799;
    r1 = _h_780;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K671)
  {
    WL_POPN(18);
    u32 _h_801 = STK(0);
    u32 _h_802 = STK(1);
    u32 _h_803 = STK(2);
    u32 _h_804 = STK(3);
    Term _h_805 = STK(4);
    Term _h_806 = STK(5);
    Term _h_807 = STK(6);
    Term _h_808 = STK(7);
    Term _h_809 = STK(8);
    Term _h_810 = STK(9);
    Term _h_811 = STK(10);
    Term _h_812 = STK(11);
    Term _h_813 = STK(12);
    u32 _h_814 = STK(13);
    u32 _h_815 = STK(14);
    Term _h_816 = STK(15);
    Term _h_817 = STK(16);
    Term _h_818 = STK(17);
    Term _h_800 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_801;
      STK(1) = _h_802;
      STK(2) = _h_803;
      STK(3) = _h_804;
      STK(4) = _h_805;
      STK(5) = _h_806;
      STK(6) = _h_807;
      STK(7) = _h_808;
      STK(8) = _h_809;
      STK(9) = _h_810;
      STK(10) = _h_811;
      STK(11) = _h_812;
      STK(12) = _h_813;
      STK(13) = _h_814;
      STK(14) = _h_815;
      STK(15) = _h_816;
      STK(16) = _h_817;
      STK(17) = _h_818;
      STK(18) = FID_CONSUMER_OBSERVE_0_K672;
      WL_PUSHN(19);
    } else {
      u64 _t_76 = task_node(e, FID_CONSUMER_OBSERVE_0_K672, WL_CONT, WL_IDX, 1);
      e.mem[_t_76 + 0] = _h_801;
      e.mem[_t_76 + 1] = _h_802;
      e.mem[_t_76 + 2] = _h_803;
      e.mem[_t_76 + 3] = _h_804;
      e.mem[_t_76 + 4] = _h_805;
      e.mem[_t_76 + 5] = _h_806;
      e.mem[_t_76 + 6] = _h_807;
      e.mem[_t_76 + 7] = _h_808;
      e.mem[_t_76 + 8] = _h_809;
      e.mem[_t_76 + 9] = _h_810;
      e.mem[_t_76 + 10] = _h_811;
      e.mem[_t_76 + 11] = _h_812;
      e.mem[_t_76 + 12] = _h_813;
      e.mem[_t_76 + 13] = _h_814;
      e.mem[_t_76 + 14] = _h_815;
      e.mem[_t_76 + 15] = _h_816;
      e.mem[_t_76 + 16] = _h_817;
      e.mem[_t_76 + 17] = _h_818;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K672, _t_76);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_77 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_77 + 1] = _h_800;
      return term_tsk(FID_STRING_APPEND, _t_77);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_800;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K672)
  {
    WL_POPN(18);
    u32 _h_820 = STK(0);
    u32 _h_821 = STK(1);
    u32 _h_822 = STK(2);
    u32 _h_823 = STK(3);
    Term _h_824 = STK(4);
    Term _h_825 = STK(5);
    Term _h_826 = STK(6);
    Term _h_827 = STK(7);
    Term _h_828 = STK(8);
    Term _h_829 = STK(9);
    Term _h_830 = STK(10);
    Term _h_831 = STK(11);
    Term _h_832 = STK(12);
    u32 _h_833 = STK(13);
    u32 _h_834 = STK(14);
    Term _h_835 = STK(15);
    Term _h_836 = STK(16);
    Term _h_837 = STK(17);
    Term _h_819 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_820;
      STK(1) = _h_821;
      STK(2) = _h_822;
      STK(3) = _h_823;
      STK(4) = _h_824;
      STK(5) = _h_825;
      STK(6) = _h_826;
      STK(7) = _h_827;
      STK(8) = _h_828;
      STK(9) = _h_829;
      STK(10) = _h_830;
      STK(11) = _h_831;
      STK(12) = _h_832;
      STK(13) = _h_833;
      STK(14) = _h_834;
      STK(15) = _h_835;
      STK(16) = _h_836;
      STK(17) = FID_CONSUMER_OBSERVE_0_K673;
      WL_PUSHN(18);
    } else {
      u64 _t_78 = task_node(e, FID_CONSUMER_OBSERVE_0_K673, WL_CONT, WL_IDX, 1);
      e.mem[_t_78 + 0] = _h_820;
      e.mem[_t_78 + 1] = _h_821;
      e.mem[_t_78 + 2] = _h_822;
      e.mem[_t_78 + 3] = _h_823;
      e.mem[_t_78 + 4] = _h_824;
      e.mem[_t_78 + 5] = _h_825;
      e.mem[_t_78 + 6] = _h_826;
      e.mem[_t_78 + 7] = _h_827;
      e.mem[_t_78 + 8] = _h_828;
      e.mem[_t_78 + 9] = _h_829;
      e.mem[_t_78 + 10] = _h_830;
      e.mem[_t_78 + 11] = _h_831;
      e.mem[_t_78 + 12] = _h_832;
      e.mem[_t_78 + 13] = _h_833;
      e.mem[_t_78 + 14] = _h_834;
      e.mem[_t_78 + 15] = _h_835;
      e.mem[_t_78 + 16] = _h_836;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K673, _t_78);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_79 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_79 + 0] = _h_837;
      e.mem[_t_79 + 1] = _h_819;
      return term_tsk(FID_STRING_APPEND, _t_79);
    }
    r0 = _h_837;
    r1 = _h_819;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K673)
  {
    WL_POPN(17);
    u32 _h_839 = STK(0);
    u32 _h_840 = STK(1);
    u32 _h_841 = STK(2);
    u32 _h_842 = STK(3);
    Term _h_843 = STK(4);
    Term _h_844 = STK(5);
    Term _h_845 = STK(6);
    Term _h_846 = STK(7);
    Term _h_847 = STK(8);
    Term _h_848 = STK(9);
    Term _h_849 = STK(10);
    Term _h_850 = STK(11);
    Term _h_851 = STK(12);
    u32 _h_852 = STK(13);
    u32 _h_853 = STK(14);
    Term _h_854 = STK(15);
    Term _h_855 = STK(16);
    Term _h_838 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_839;
      STK(1) = _h_840;
      STK(2) = _h_841;
      STK(3) = _h_842;
      STK(4) = _h_843;
      STK(5) = _h_844;
      STK(6) = _h_845;
      STK(7) = _h_846;
      STK(8) = _h_847;
      STK(9) = _h_848;
      STK(10) = _h_849;
      STK(11) = _h_850;
      STK(12) = _h_851;
      STK(13) = _h_852;
      STK(14) = _h_853;
      STK(15) = _h_854;
      STK(16) = _h_855;
      STK(17) = FID_CONSUMER_OBSERVE_0_K674;
      WL_PUSHN(18);
    } else {
      u64 _t_80 = task_node(e, FID_CONSUMER_OBSERVE_0_K674, WL_CONT, WL_IDX, 1);
      e.mem[_t_80 + 0] = _h_839;
      e.mem[_t_80 + 1] = _h_840;
      e.mem[_t_80 + 2] = _h_841;
      e.mem[_t_80 + 3] = _h_842;
      e.mem[_t_80 + 4] = _h_843;
      e.mem[_t_80 + 5] = _h_844;
      e.mem[_t_80 + 6] = _h_845;
      e.mem[_t_80 + 7] = _h_846;
      e.mem[_t_80 + 8] = _h_847;
      e.mem[_t_80 + 9] = _h_848;
      e.mem[_t_80 + 10] = _h_849;
      e.mem[_t_80 + 11] = _h_850;
      e.mem[_t_80 + 12] = _h_851;
      e.mem[_t_80 + 13] = _h_852;
      e.mem[_t_80 + 14] = _h_853;
      e.mem[_t_80 + 15] = _h_854;
      e.mem[_t_80 + 16] = _h_855;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K674, _t_80);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_81 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = term_ctr(CID_SCON, STAT_OFF + 8);
      e.mem[_t_81 + 1] = _h_838;
      return term_tsk(FID_STRING_APPEND, _t_81);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 8);
    r1 = _h_838;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K674)
  {
    WL_POPN(17);
    u32 _h_857 = STK(0);
    u32 _h_858 = STK(1);
    u32 _h_859 = STK(2);
    u32 _h_860 = STK(3);
    Term _h_861 = STK(4);
    Term _h_862 = STK(5);
    Term _h_863 = STK(6);
    Term _h_864 = STK(7);
    Term _h_865 = STK(8);
    Term _h_866 = STK(9);
    Term _h_867 = STK(10);
    Term _h_868 = STK(11);
    Term _h_869 = STK(12);
    u32 _h_870 = STK(13);
    u32 _h_871 = STK(14);
    Term _h_872 = STK(15);
    Term _h_873 = STK(16);
    Term _h_856 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_857;
      STK(1) = _h_858;
      STK(2) = _h_859;
      STK(3) = _h_860;
      STK(4) = _h_861;
      STK(5) = _h_862;
      STK(6) = _h_863;
      STK(7) = _h_864;
      STK(8) = _h_865;
      STK(9) = _h_866;
      STK(10) = _h_867;
      STK(11) = _h_868;
      STK(12) = _h_869;
      STK(13) = _h_870;
      STK(14) = _h_871;
      STK(15) = _h_872;
      STK(16) = FID_CONSUMER_OBSERVE_0_K675;
      WL_PUSHN(17);
    } else {
      u64 _t_82 = task_node(e, FID_CONSUMER_OBSERVE_0_K675, WL_CONT, WL_IDX, 1);
      e.mem[_t_82 + 0] = _h_857;
      e.mem[_t_82 + 1] = _h_858;
      e.mem[_t_82 + 2] = _h_859;
      e.mem[_t_82 + 3] = _h_860;
      e.mem[_t_82 + 4] = _h_861;
      e.mem[_t_82 + 5] = _h_862;
      e.mem[_t_82 + 6] = _h_863;
      e.mem[_t_82 + 7] = _h_864;
      e.mem[_t_82 + 8] = _h_865;
      e.mem[_t_82 + 9] = _h_866;
      e.mem[_t_82 + 10] = _h_867;
      e.mem[_t_82 + 11] = _h_868;
      e.mem[_t_82 + 12] = _h_869;
      e.mem[_t_82 + 13] = _h_870;
      e.mem[_t_82 + 14] = _h_871;
      e.mem[_t_82 + 15] = _h_872;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K675, _t_82);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_83 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = _h_873;
      e.mem[_t_83 + 1] = _h_856;
      return term_tsk(FID_STRING_APPEND, _t_83);
    }
    r0 = _h_873;
    r1 = _h_856;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K675)
  {
    WL_POPN(16);
    u32 _h_875 = STK(0);
    u32 _h_876 = STK(1);
    u32 _h_877 = STK(2);
    u32 _h_878 = STK(3);
    Term _h_879 = STK(4);
    Term _h_880 = STK(5);
    Term _h_881 = STK(6);
    Term _h_882 = STK(7);
    Term _h_883 = STK(8);
    Term _h_884 = STK(9);
    Term _h_885 = STK(10);
    Term _h_886 = STK(11);
    Term _h_887 = STK(12);
    u32 _h_888 = STK(13);
    u32 _h_889 = STK(14);
    Term _h_890 = STK(15);
    Term _h_874 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_875;
      STK(1) = _h_876;
      STK(2) = _h_877;
      STK(3) = _h_878;
      STK(4) = _h_879;
      STK(5) = _h_880;
      STK(6) = _h_881;
      STK(7) = _h_882;
      STK(8) = _h_883;
      STK(9) = _h_884;
      STK(10) = _h_885;
      STK(11) = _h_886;
      STK(12) = _h_887;
      STK(13) = _h_888;
      STK(14) = _h_889;
      STK(15) = _h_890;
      STK(16) = FID_CONSUMER_OBSERVE_0_K676;
      WL_PUSHN(17);
    } else {
      u64 _t_84 = task_node(e, FID_CONSUMER_OBSERVE_0_K676, WL_CONT, WL_IDX, 1);
      e.mem[_t_84 + 0] = _h_875;
      e.mem[_t_84 + 1] = _h_876;
      e.mem[_t_84 + 2] = _h_877;
      e.mem[_t_84 + 3] = _h_878;
      e.mem[_t_84 + 4] = _h_879;
      e.mem[_t_84 + 5] = _h_880;
      e.mem[_t_84 + 6] = _h_881;
      e.mem[_t_84 + 7] = _h_882;
      e.mem[_t_84 + 8] = _h_883;
      e.mem[_t_84 + 9] = _h_884;
      e.mem[_t_84 + 10] = _h_885;
      e.mem[_t_84 + 11] = _h_886;
      e.mem[_t_84 + 12] = _h_887;
      e.mem[_t_84 + 13] = _h_888;
      e.mem[_t_84 + 14] = _h_889;
      e.mem[_t_84 + 15] = _h_890;
      WL_CONT = term_tsk(FID_CONSUMER_OBSERVE_0_K676, _t_84);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_85 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_85 + 0] = term_ctr(CID_SCON, STAT_OFF + 236);
      e.mem[_t_85 + 1] = _h_874;
      return term_tsk(FID_STRING_APPEND, _t_85);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 236);
    r1 = _h_874;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_OBSERVE_0_K676)
  {
    WL_POPN(16);
    u32 _h_892 = STK(0);
    u32 _h_893 = STK(1);
    u32 _h_894 = STK(2);
    u32 _h_895 = STK(3);
    Term _h_896 = STK(4);
    Term _h_897 = STK(5);
    Term _h_898 = STK(6);
    Term _h_899 = STK(7);
    Term _h_900 = STK(8);
    Term _h_901 = STK(9);
    Term _h_902 = STK(10);
    Term _h_903 = STK(11);
    Term _h_904 = STK(12);
    u32 _h_905 = STK(13);
    u32 _h_906 = STK(14);
    Term _h_907 = STK(15);
    Term _h_891 = r0;
    WL_OPEN
    r0 = _h_892;
    r1 = _h_893;
    r2 = _h_894;
    r3 = _h_907;
    r4 = _h_895;
    r5 = _h_896;
    r6 = _h_897;
    r7 = _h_898;
    r8 = _h_899;
    r9 = _h_900;
    r10 = _h_901;
    r11 = _h_902;
    r12 = _h_903;
    r13 = _h_904;
    r14 = _h_905;
    r15 = _h_906;
    r16 = _h_891;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_COMPLETE_OBSERVED_0)
  {
    u32 _observed_0 = r0;
    u32 _observed_1 = r1;
    u32 _observed_2 = r2;
    Term _observed_3 = r3;
    u32 _observed_4 = r4;
    Term _observed_5 = r5;
    Term _observed_6 = r6;
    Term _observed_7 = r7;
    Term _observed_8 = r8;
    Term _observed_9 = r9;
    Term _observed_10 = r10;
    Term _observed_11 = r11;
    Term _observed_12 = r12;
    Term _observed_13 = r13;
    u32 _observed_14 = r14;
    u32 _observed_15 = r15;
    Term _observed_16 = r16;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _observed_0;
      STK(1) = _observed_1;
      STK(2) = _observed_2;
      STK(3) = _observed_3;
      STK(4) = _observed_4;
      STK(5) = _observed_5;
      STK(6) = _observed_6;
      STK(7) = _observed_7;
      STK(8) = _observed_8;
      STK(9) = _observed_9;
      STK(10) = _observed_10;
      STK(11) = _observed_11;
      STK(12) = _observed_12;
      STK(13) = _observed_13;
      STK(14) = _observed_14;
      STK(15) = _observed_15;
      STK(16) = FID_CONSUMER_COMPLETE_OBSERVED_0_K678;
      WL_PUSHN(17);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_COMPLETE_OBSERVED_0_K678, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _observed_0;
      e.mem[_t_0 + 1] = _observed_1;
      e.mem[_t_0 + 2] = _observed_2;
      e.mem[_t_0 + 3] = _observed_3;
      e.mem[_t_0 + 4] = _observed_4;
      e.mem[_t_0 + 5] = _observed_5;
      e.mem[_t_0 + 6] = _observed_6;
      e.mem[_t_0 + 7] = _observed_7;
      e.mem[_t_0 + 8] = _observed_8;
      e.mem[_t_0 + 9] = _observed_9;
      e.mem[_t_0 + 10] = _observed_10;
      e.mem[_t_0 + 11] = _observed_11;
      e.mem[_t_0 + 12] = _observed_12;
      e.mem[_t_0 + 13] = _observed_13;
      e.mem[_t_0 + 14] = _observed_14;
      e.mem[_t_0 + 15] = _observed_15;
      WL_CONT = term_tsk(FID_CONSUMER_COMPLETE_OBSERVED_0_K678, _t_0);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 464);
      e.mem[_t_1 + 1] = _observed_16;
      return term_tsk(FID_STRING_APPEND, _t_1);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 464);
    r1 = _observed_16;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_COMPLETE_OBSERVED_0_K678)
  {
    WL_POPN(16);
    u32 _observed_17 = STK(0);
    u32 _observed_18 = STK(1);
    u32 _observed_19 = STK(2);
    Term _observed_20 = STK(3);
    u32 _observed_21 = STK(4);
    Term _observed_22 = STK(5);
    Term _observed_23 = STK(6);
    Term _observed_24 = STK(7);
    Term _observed_25 = STK(8);
    Term _observed_26 = STK(9);
    Term _observed_27 = STK(10);
    Term _observed_28 = STK(11);
    Term _observed_29 = STK(12);
    Term _observed_30 = STK(13);
    u32 _observed_31 = STK(14);
    u32 _observed_32 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    r0 = 0;
    r1 = _observed_17;
    r2 = _observed_18;
    r3 = _observed_19;
    r4 = _observed_20;
    r5 = _observed_21;
    r6 = _observed_22;
    r7 = _observed_23;
    r8 = _observed_24;
    r9 = _observed_25;
    r10 = _observed_26;
    r11 = _observed_27;
    r12 = _observed_28;
    r13 = _observed_29;
    r14 = _observed_30;
    r15 = _observed_31;
    r16 = _observed_32;
    r17 = 0;
    r18 = _h_0;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0)
  {
    Term _fuel_0 = r0;
    u32 _result_0 = r1;
    u32 _result_1 = r2;
    u32 _result_2 = r3;
    u32 _result_3 = r4;
    Term _result_4 = r5;
    u32 _result_5 = r6;
    Term _result_6 = r7;
    Term _result_7 = r8;
    Term _result_8 = r9;
    Term _result_9 = r10;
    Term _result_10 = r11;
    Term _result_11 = r12;
    Term _result_12 = r13;
    Term _result_13 = r14;
    Term _result_14 = r15;
    u32 _result_15 = r16;
    u32 _result_16 = r17;
    Term _result_17 = r18;
    u32 _namespace_0 = r19;
    Term _descriptors_0 = r20;
    WL_OPEN
    if (_result_0 == 0) {
      term_sink(e, _descriptors_0);
      r0 = 0;
      r1 = _result_1;
      r2 = _result_2;
      r3 = _result_3;
      r4 = _result_4;
      r5 = _result_5;
      r6 = _result_6;
      r7 = _result_7;
      r8 = _result_8;
      r9 = _result_9;
      r10 = _result_10;
      r11 = _result_11;
      r12 = _result_12;
      r13 = _result_13;
      r14 = _result_14;
      r15 = _result_15;
      r16 = _result_16;
      r17 = 0;
      WL_RETN(18);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0)) {
        u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _fuel_0;
        e.mem[_t_0 + 1] = _result_17;
        e.mem[_t_0 + 2] = _result_1;
        e.mem[_t_0 + 3] = _result_2;
        e.mem[_t_0 + 4] = _result_3;
        e.mem[_t_0 + 5] = _result_4;
        e.mem[_t_0 + 6] = _result_5;
        e.mem[_t_0 + 7] = _result_6;
        e.mem[_t_0 + 8] = _result_7;
        e.mem[_t_0 + 9] = _result_8;
        e.mem[_t_0 + 10] = _result_9;
        e.mem[_t_0 + 11] = _result_10;
        e.mem[_t_0 + 12] = _result_11;
        e.mem[_t_0 + 13] = _result_12;
        e.mem[_t_0 + 14] = _result_13;
        e.mem[_t_0 + 15] = _result_14;
        e.mem[_t_0 + 16] = _result_15;
        e.mem[_t_0 + 17] = _result_16;
        e.mem[_t_0 + 18] = _namespace_0;
        e.mem[_t_0 + 19] = _descriptors_0;
        return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0, _t_0);
      }
      r0 = _fuel_0;
      r1 = _result_17;
      r2 = _result_1;
      r3 = _result_2;
      r4 = _result_3;
      r5 = _result_4;
      r6 = _result_5;
      r7 = _result_6;
      r8 = _result_7;
      r9 = _result_8;
      r10 = _result_9;
      r11 = _result_10;
      r12 = _result_11;
      r13 = _result_12;
      r14 = _result_13;
      r15 = _result_14;
      r16 = _result_15;
      r17 = _result_16;
      r18 = _namespace_0;
      r19 = _descriptors_0;
      WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_RESUMED_ONCE_0)
  {
    u32 _namespace_0 = r0;
    u32 _observed_0 = r1;
    u32 _observed_1 = r2;
    u32 _observed_2 = r3;
    u32 _observed_3 = r4;
    Term _observed_4 = r5;
    u32 _observed_5 = r6;
    Term _observed_6 = r7;
    Term _observed_7 = r8;
    Term _observed_8 = r9;
    Term _observed_9 = r10;
    Term _observed_10 = r11;
    Term _observed_11 = r12;
    Term _observed_12 = r13;
    Term _observed_13 = r14;
    Term _observed_14 = r15;
    u32 _observed_15 = r16;
    u32 _observed_16 = r17;
    Term _observed_17 = r18;
    Term _observed_18 = r19;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _observed_18;
      STK(1) = FID_CONSUMER_RESUMED_ONCE_0_K681;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CONSUMER_RESUMED_ONCE_0_K681, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _observed_18;
      WL_CONT = term_tsk(FID_CONSUMER_RESUMED_ONCE_0_K681, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0)) {
      u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = 32ull;
      e.mem[_t_1 + 1] = _observed_0;
      e.mem[_t_1 + 2] = _observed_1;
      e.mem[_t_1 + 3] = _observed_2;
      e.mem[_t_1 + 4] = _observed_3;
      e.mem[_t_1 + 5] = _observed_4;
      e.mem[_t_1 + 6] = _observed_5;
      e.mem[_t_1 + 7] = _observed_6;
      e.mem[_t_1 + 8] = _observed_7;
      e.mem[_t_1 + 9] = _observed_8;
      e.mem[_t_1 + 10] = _observed_9;
      e.mem[_t_1 + 11] = _observed_10;
      e.mem[_t_1 + 12] = _observed_11;
      e.mem[_t_1 + 13] = _observed_12;
      e.mem[_t_1 + 14] = _observed_13;
      e.mem[_t_1 + 15] = _observed_14;
      e.mem[_t_1 + 16] = _observed_15;
      e.mem[_t_1 + 17] = _observed_16;
      e.mem[_t_1 + 18] = _observed_17;
      e.mem[_t_1 + 19] = _namespace_0;
      e.mem[_t_1 + 20] = term_ctr(CID_CON, STAT_OFF + 476);
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0, _t_1);
    }
    r0 = 32ull;
    r1 = _observed_0;
    r2 = _observed_1;
    r3 = _observed_2;
    r4 = _observed_3;
    r5 = _observed_4;
    r6 = _observed_5;
    r7 = _observed_6;
    r8 = _observed_7;
    r9 = _observed_8;
    r10 = _observed_9;
    r11 = _observed_10;
    r12 = _observed_11;
    r13 = _observed_12;
    r14 = _observed_13;
    r15 = _observed_14;
    r16 = _observed_15;
    r17 = _observed_16;
    r18 = _observed_17;
    r19 = _namespace_0;
    r20 = term_ctr(CID_CON, STAT_OFF + 476);
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_RESUMED_ONCE_0_K681)
  {
    WL_POPN(1);
    Term _observed_19 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    u32 _h_16 = r16;
    Term _h_17 = r17;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _observed_19;
      STK(1) = FID_CONSUMER_RESUMED_ONCE_0_K682;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CONSUMER_RESUMED_ONCE_0_K682, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _observed_19;
      WL_CONT = term_tsk(FID_CONSUMER_RESUMED_ONCE_0_K682, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_RESULT_OBSERVE_0)) {
      u64 _t_3 = task_node(e, FID_CONSUMER_RESULT_OBSERVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      e.mem[_t_3 + 10] = _h_10;
      e.mem[_t_3 + 11] = _h_11;
      e.mem[_t_3 + 12] = _h_12;
      e.mem[_t_3 + 13] = _h_13;
      e.mem[_t_3 + 14] = _h_14;
      e.mem[_t_3 + 15] = _h_15;
      e.mem[_t_3 + 16] = _h_16;
      e.mem[_t_3 + 17] = _h_17;
      return term_tsk(FID_CONSUMER_RESULT_OBSERVE_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = _h_16;
    r17 = _h_17;
    WL_JMP(FID_CONSUMER_RESULT_OBSERVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_RESUMED_ONCE_0_K682)
  {
    WL_POPN(1);
    Term _observed_20 = STK(0);
    u32 _h_18 = r0;
    u32 _h_19 = r1;
    u32 _h_20 = r2;
    u32 _h_21 = r3;
    Term _h_22 = r4;
    u32 _h_23 = r5;
    Term _h_24 = r6;
    Term _h_25 = r7;
    Term _h_26 = r8;
    Term _h_27 = r9;
    Term _h_28 = r10;
    Term _h_29 = r11;
    Term _h_30 = r12;
    Term _h_31 = r13;
    Term _h_32 = r14;
    u32 _h_33 = r15;
    u32 _h_34 = r16;
    Term _h_35 = r17;
    Term _h_36 = r18;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _observed_20;
      STK(1) = FID_CONSUMER_RESUMED_ONCE_0_K683;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_RESUMED_ONCE_0_K683, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _observed_20;
      WL_CONT = term_tsk(FID_CONSUMER_RESUMED_ONCE_0_K683, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_DONE_0)) {
      u64 _t_5 = task_node(e, FID_CONSUMER_DONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_18;
      e.mem[_t_5 + 1] = _h_19;
      e.mem[_t_5 + 2] = _h_20;
      e.mem[_t_5 + 3] = _h_21;
      e.mem[_t_5 + 4] = _h_22;
      e.mem[_t_5 + 5] = _h_23;
      e.mem[_t_5 + 6] = _h_24;
      e.mem[_t_5 + 7] = _h_25;
      e.mem[_t_5 + 8] = _h_26;
      e.mem[_t_5 + 9] = _h_27;
      e.mem[_t_5 + 10] = _h_28;
      e.mem[_t_5 + 11] = _h_29;
      e.mem[_t_5 + 12] = _h_30;
      e.mem[_t_5 + 13] = _h_31;
      e.mem[_t_5 + 14] = _h_32;
      e.mem[_t_5 + 15] = _h_33;
      e.mem[_t_5 + 16] = _h_34;
      e.mem[_t_5 + 17] = _h_35;
      e.mem[_t_5 + 18] = _h_36;
      return term_tsk(FID_CONSUMER_DONE_0, _t_5);
    }
    r0 = _h_18;
    r1 = _h_19;
    r2 = _h_20;
    r3 = _h_21;
    r4 = _h_22;
    r5 = _h_23;
    r6 = _h_24;
    r7 = _h_25;
    r8 = _h_26;
    r9 = _h_27;
    r10 = _h_28;
    r11 = _h_29;
    r12 = _h_30;
    r13 = _h_31;
    r14 = _h_32;
    r15 = _h_33;
    r16 = _h_34;
    r17 = _h_35;
    r18 = _h_36;
    WL_JMP(FID_CONSUMER_DONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_RESUMED_ONCE_0_K683)
  {
    WL_POPN(1);
    Term _observed_21 = STK(0);
    Term _h_37 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _observed_21;
      STK(1) = FID_CONSUMER_RESUMED_ONCE_0_K684;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_CONSUMER_RESUMED_ONCE_0_K684, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _observed_21;
      WL_CONT = term_tsk(FID_CONSUMER_RESUMED_ONCE_0_K684, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 344);
      e.mem[_t_7 + 1] = _h_37;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 344);
    r1 = _h_37;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_RESUMED_ONCE_0_K684)
  {
    WL_POPN(1);
    Term _observed_22 = STK(0);
    Term _h_38 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _observed_22;
      e.mem[_t_8 + 1] = _h_38;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _observed_22;
    r1 = _h_38;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K686;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K686, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K686, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K686)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SETUP_0)
  {
    u32 _namespace_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_9[16];
    if (spin_59(e, _o_9, _namespace_0) == 0) {
      return 0;
    }
    _v_16 = _o_9[0];
    _v_17 = _o_9[1];
    _v_18 = _o_9[2];
    _v_19 = _o_9[3];
    _v_20 = _o_9[4];
    _v_21 = _o_9[5];
    _v_22 = _o_9[6];
    _v_23 = _o_9[7];
    _v_24 = _o_9[8];
    _v_25 = _o_9[9];
    _v_26 = _o_9[10];
    _v_27 = _o_9[11];
    _v_28 = _o_9[12];
    _v_29 = _o_9[13];
    _v_30 = _o_9[14];
    _v_31 = _o_9[15];
    _v_0 = _v_16;
    _v_1 = _v_17;
    _v_2 = _v_18;
    _v_3 = _v_19;
    _v_4 = _v_20;
    _v_5 = _v_21;
    _v_6 = _v_22;
    _v_7 = _v_23;
    _v_8 = _v_24;
    _v_9 = _v_25;
    _v_10 = _v_26;
    _v_11 = _v_27;
    _v_12 = _v_28;
    _v_13 = _v_29;
    _v_14 = _v_30;
    _v_15 = _v_31;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _namespace_0;
      STK(1) = FID_CONSUMER_SETUP_0_K690;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_CONSUMER_SETUP_0_K690, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _namespace_0;
      WL_CONT = term_tsk(FID_CONSUMER_SETUP_0_K690, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0)) {
      u64 _t_5 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _v_0;
      e.mem[_t_5 + 1] = _v_1;
      e.mem[_t_5 + 2] = _v_2;
      e.mem[_t_5 + 3] = _v_3;
      e.mem[_t_5 + 4] = _v_4;
      e.mem[_t_5 + 5] = _v_5;
      e.mem[_t_5 + 6] = _v_6;
      e.mem[_t_5 + 7] = _v_7;
      e.mem[_t_5 + 8] = _v_8;
      e.mem[_t_5 + 9] = _v_9;
      e.mem[_t_5 + 10] = _v_10;
      e.mem[_t_5 + 11] = _v_11;
      e.mem[_t_5 + 12] = _v_12;
      e.mem[_t_5 + 13] = _v_13;
      e.mem[_t_5 + 14] = _v_14;
      e.mem[_t_5 + 15] = _v_15;
      e.mem[_t_5 + 16] = 1ull;
      e.mem[_t_5 + 17] = term_ctr(CID_SCON, STAT_OFF + 374);
      e.mem[_t_5 + 18] = term_ctr(CID_SCON, STAT_OFF + 388);
      e.mem[_t_5 + 19] = 0;
      e.mem[_t_5 + 20] = _namespace_0;
      e.mem[_t_5 + 21] = 3ull;
      e.mem[_t_5 + 22] = _namespace_0;
      e.mem[_t_5 + 23] = 1ull;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0, _t_5);
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = 1ull;
    r17 = term_ctr(CID_SCON, STAT_OFF + 374);
    r18 = term_ctr(CID_SCON, STAT_OFF + 388);
    r19 = 0;
    r20 = _namespace_0;
    r21 = 3ull;
    r22 = _namespace_0;
    r23 = 1ull;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_FIXTURE_0_C689)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[13];
    u64 _sp_0 = ctr_take(e, _x_0, 13, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    u32 _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    spare_free(e, cls_fit(13), _sp_0);
    Term _fb_1[3];
    u64 _sp_1 = ctr_take(e, _f_6, 3, _fb_1);
    Term _f_13 = _fb_1[0];
    Term _f_14 = _fb_1[1];
    Term _f_15 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_1);
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _f_13, 2, _fb_2);
    Term _f_16 = _fb_2[0];
    Term _f_17 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    Term _v_51 = 0;
    u32 _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    Term _o_8[16];
    if (spin_55(e, _o_8, _f_0, _f_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, _f_16, blk_loc(e.mem, _f_16), _f_17, blk_loc(e.mem, _f_17), _f_14, blk_loc(e.mem, _f_14), _f_15, blk_loc(e.mem, _f_15), _f_7, blk_loc(e.mem, _f_7), _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, _f_12) == 0) {
      return 0;
    }
    _v_48 = _o_8[0];
    _v_49 = _o_8[1];
    _v_50 = _o_8[2];
    _v_51 = _o_8[3];
    _v_52 = _o_8[4];
    _v_53 = _o_8[5];
    _v_54 = _o_8[6];
    _v_55 = _o_8[7];
    _v_56 = _o_8[8];
    _v_57 = _o_8[9];
    _v_58 = _o_8[10];
    _v_59 = _o_8[11];
    _v_60 = _o_8[12];
    _v_61 = _o_8[13];
    _v_62 = _o_8[14];
    _v_63 = _o_8[15];
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _v_54);
    e.mem[_nd_4 + 1] = rfc_seal(e, _v_55);
    u64 _nd_5 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_4));
    e.mem[_nd_5 + 1] = rfc_seal(e, _v_56);
    e.mem[_nd_5 + 2] = rfc_seal(e, _v_57);
    u64 _nd_6 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_6 + 0] = rfc_seal(e, _v_48);
    e.mem[_nd_6 + 1] = rfc_seal(e, _v_49);
    e.mem[_nd_6 + 2] = rfc_seal(e, _v_50);
    e.mem[_nd_6 + 3] = rfc_seal(e, _v_51);
    e.mem[_nd_6 + 4] = rfc_seal(e, _v_52);
    e.mem[_nd_6 + 5] = rfc_seal(e, _v_53);
    e.mem[_nd_6 + 6] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_5));
    e.mem[_nd_6 + 7] = rfc_seal(e, _v_58);
    e.mem[_nd_6 + 8] = rfc_seal(e, _v_59);
    e.mem[_nd_6 + 9] = rfc_seal(e, _v_60);
    e.mem[_nd_6 + 10] = rfc_seal(e, _v_61);
    e.mem[_nd_6 + 11] = rfc_seal(e, _v_62);
    e.mem[_nd_6 + 12] = rfc_seal(e, _v_63);
    r0 = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_SETUP_0_K690)
  {
    WL_POPN(1);
    u32 _namespace_2 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0)) {
      u64 _t_6 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_0;
      e.mem[_t_6 + 1] = _h_1;
      e.mem[_t_6 + 2] = _h_2;
      e.mem[_t_6 + 3] = _h_3;
      e.mem[_t_6 + 4] = _h_4;
      e.mem[_t_6 + 5] = _h_5;
      e.mem[_t_6 + 6] = _h_6;
      e.mem[_t_6 + 7] = _h_7;
      e.mem[_t_6 + 8] = _h_8;
      e.mem[_t_6 + 9] = _h_9;
      e.mem[_t_6 + 10] = _h_10;
      e.mem[_t_6 + 11] = _h_11;
      e.mem[_t_6 + 12] = _h_12;
      e.mem[_t_6 + 13] = _h_13;
      e.mem[_t_6 + 14] = _h_14;
      e.mem[_t_6 + 15] = _h_15;
      e.mem[_t_6 + 16] = 2ull;
      e.mem[_t_6 + 17] = term_ctr(CID_SCON, STAT_OFF + 350);
      e.mem[_t_6 + 18] = term_ctr(CID_SCON, STAT_OFF + 366);
      e.mem[_t_6 + 19] = 1;
      e.mem[_t_6 + 20] = _namespace_2;
      e.mem[_t_6 + 21] = 2ull;
      e.mem[_t_6 + 22] = _namespace_2;
      e.mem[_t_6 + 23] = 1ull;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0, _t_6);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = 2ull;
    r17 = term_ctr(CID_SCON, STAT_OFF + 350);
    r18 = term_ctr(CID_SCON, STAT_OFF + 366);
    r19 = 1;
    r20 = _namespace_2;
    r21 = 2ull;
    r22 = _namespace_2;
    r23 = 1ull;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_COMMANDS_APPLY_RELATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0)
  {
    Term _fuel_0 = r0;
    Term _frames_0 = r1;
    u32 _world_0 = r2;
    u32 _world_1 = r3;
    u32 _world_2 = r4;
    Term _world_3 = r5;
    u32 _world_4 = r6;
    Term _world_5 = r7;
    Term _world_6 = r8;
    Term _world_7 = r9;
    Term _world_8 = r10;
    Term _world_9 = r11;
    Term _world_10 = r12;
    Term _world_11 = r13;
    Term _world_12 = r14;
    Term _world_13 = r15;
    u32 _world_14 = r16;
    u32 _world_15 = r17;
    u32 _namespace_0 = r18;
    Term _descriptors_0 = r19;
    WL_OPEN
    if (_fuel_0 == 0) {
      if (term_aux(_frames_0) == CID_NIL) {
        term_sink(e, _descriptors_0);
        r0 = 0;
        r1 = _world_0;
        r2 = _world_1;
        r3 = _world_2;
        r4 = _world_3;
        r5 = _world_4;
        r6 = _world_5;
        r7 = _world_6;
        r8 = _world_7;
        r9 = _world_8;
        r10 = _world_9;
        r11 = _world_10;
        r12 = _world_11;
        r13 = _world_12;
        r14 = _world_13;
        r15 = _world_14;
        r16 = _world_15;
        r17 = 0;
        WL_RETN(18);
      } else {
        term_sink(e, _descriptors_0);
        r0 = 1;
        r1 = _world_0;
        r2 = _world_1;
        r3 = _world_2;
        r4 = _world_3;
        r5 = _world_4;
        r6 = _world_5;
        r7 = _world_6;
        r8 = _world_7;
        r9 = _world_8;
        r10 = _world_9;
        r11 = _world_10;
        r12 = _world_11;
        r13 = _world_12;
        r14 = _world_13;
        r15 = _world_14;
        r16 = _world_15;
        r17 = _frames_0;
        WL_RETN(18);
      }
    } else {
      Term _rest_0 = (_fuel_0 - 1);
      if (term_aux(_frames_0) == CID_NIL) {
        term_sink(e, _descriptors_0);
        r0 = 0;
        r1 = _world_0;
        r2 = _world_1;
        r3 = _world_2;
        r4 = _world_3;
        r5 = _world_4;
        r6 = _world_5;
        r7 = _world_6;
        r8 = _world_7;
        r9 = _world_8;
        r10 = _world_9;
        r11 = _world_10;
        r12 = _world_11;
        r13 = _world_12;
        r14 = _world_13;
        r15 = _world_14;
        r16 = _world_15;
        r17 = 0;
        WL_RETN(18);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _frames_0, 2, _fb_0);
        Term _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        u32 _o_0 = 0;
        u32 _o_1 = 0;
        Term _o_2 = 0;
        Term _o_3 = 0;
        Term _o_4 = 0;
        u32 _o_5 = 0;
        Term _o_6 = 0;
        Term _o_7 = 0;
        if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPENTER) {
          _o_0 = 0;
          _o_1 = term_loc(_f_0);
        } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPDESCRIPTORS) {
          _o_0 = 1;
          Term _fb_1[2];
          u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
          u32 _f_2 = _fb_1[0];
          Term _f_3 = _fb_1[1];
          spare_free(e, cls_fit(2), _sp_1);
          _o_1 = _f_2;
          _o_2 = _f_3;
        } else if (term_aux(_f_0) == CID________________BENDVY_SRC_ECS_RELATION_TYPES_CLEANUPCHILDREN) {
          _o_0 = 2;
          Term _fb_2[7];
          u64 _sp_2 = ctr_take(e, _f_0, 7, _fb_2);
          u32 _f_4 = _fb_2[0];
          u32 _f_5 = _fb_2[1];
          Term _f_6 = _fb_2[2];
          Term _f_7 = _fb_2[3];
          u32 _f_8 = _fb_2[4];
          Term _f_9 = _fb_2[5];
          Term _f_10 = _fb_2[6];
          spare_free(e, cls_fit(7), _sp_2);
          _o_1 = _f_4;
          _o_2 = _f_5;
          _o_3 = _f_6;
          _o_4 = _f_7;
          _o_5 = _f_8;
          _o_6 = _f_9;
          _o_7 = _f_10;
        } else {
          _o_0 = 3;
          _o_1 = term_loc(_f_0);
        }
        _descriptors_0 = term_keep(e, _descriptors_0, 1);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(4);
          STK(0) = _rest_0;
          STK(1) = _namespace_0;
          STK(2) = _descriptors_0;
          STK(3) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K692;
          WL_PUSHN(4);
        } else {
          u64 _t_0 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K692, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _rest_0;
          e.mem[_t_0 + 1] = _namespace_0;
          e.mem[_t_0 + 2] = _descriptors_0;
          WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K692, _t_0);
          WL_IDX = 3;
        }
        if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0)) {
          u64 _t_1 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _o_0;
          e.mem[_t_1 + 1] = _o_1;
          e.mem[_t_1 + 2] = _o_2;
          e.mem[_t_1 + 3] = _o_3;
          e.mem[_t_1 + 4] = _o_4;
          e.mem[_t_1 + 5] = _o_5;
          e.mem[_t_1 + 6] = _o_6;
          e.mem[_t_1 + 7] = _o_7;
          e.mem[_t_1 + 8] = _world_0;
          e.mem[_t_1 + 9] = _world_1;
          e.mem[_t_1 + 10] = _world_2;
          e.mem[_t_1 + 11] = _world_3;
          e.mem[_t_1 + 12] = _world_4;
          e.mem[_t_1 + 13] = _world_5;
          e.mem[_t_1 + 14] = _world_6;
          e.mem[_t_1 + 15] = _world_7;
          e.mem[_t_1 + 16] = _world_8;
          e.mem[_t_1 + 17] = _world_9;
          e.mem[_t_1 + 18] = _world_10;
          e.mem[_t_1 + 19] = _world_11;
          e.mem[_t_1 + 20] = _world_12;
          e.mem[_t_1 + 21] = _world_13;
          e.mem[_t_1 + 22] = _world_14;
          e.mem[_t_1 + 23] = _world_15;
          e.mem[_t_1 + 24] = _namespace_0;
          e.mem[_t_1 + 25] = _descriptors_0;
          e.mem[_t_1 + 26] = _f_1;
          return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0, _t_1);
        }
        r0 = _o_0;
        r1 = _o_1;
        r2 = _o_2;
        r3 = _o_3;
        r4 = _o_4;
        r5 = _o_5;
        r6 = _o_6;
        r7 = _o_7;
        r8 = _world_0;
        r9 = _world_1;
        r10 = _world_2;
        r11 = _world_3;
        r12 = _world_4;
        r13 = _world_5;
        r14 = _world_6;
        r15 = _world_7;
        r16 = _world_8;
        r17 = _world_9;
        r18 = _world_10;
        r19 = _world_11;
        r20 = _world_12;
        r21 = _world_13;
        r22 = _world_14;
        r23 = _world_15;
        r24 = _namespace_0;
        r25 = _descriptors_0;
        r26 = _f_1;
        WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_STEP_0);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K692)
  {
    WL_POPN(3);
    Term _rest_1 = STK(0);
    u32 _namespace_1 = STK(1);
    Term _descriptors_1 = STK(2);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = _rest_1;
    e.mem[_nd_0 + 1] = _namespace_1;
    e.mem[_nd_0 + 2] = _descriptors_1;
    Term _next_0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_C693, _nd_0);
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _h_6);
    e.mem[_nd_6 + 1] = rfc_seal(e, _h_7);
    u64 _nd_7 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_6));
    e.mem[_nd_7 + 1] = rfc_seal(e, _h_8);
    e.mem[_nd_7 + 2] = rfc_seal(e, _h_9);
    u64 _nd_8 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_8 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_8 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_8 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_8 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_8 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_8 + 5] = rfc_seal(e, _h_5);
    e.mem[_nd_8 + 6] = rfc_seal(e, term_ctr(CID________________BENDVY_SRC_ECS_RELATION_COMMANDS_STORE, _nd_7));
    e.mem[_nd_8 + 7] = rfc_seal(e, _h_10);
    e.mem[_nd_8 + 8] = rfc_seal(e, _h_11);
    e.mem[_nd_8 + 9] = rfc_seal(e, _h_12);
    e.mem[_nd_8 + 10] = rfc_seal(e, _h_13);
    e.mem[_nd_8 + 11] = rfc_seal(e, _h_14);
    e.mem[_nd_8 + 12] = rfc_seal(e, _h_15);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_16;
      STK(1) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K696;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K696, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_16;
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K696, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_5 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _next_0;
      e.mem[_t_5 + 1] = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_8);
      return term_tsk(FID_CLO_APPLY, _t_5);
    }
    r0 = _next_0;
    r1 = term_ctr(CID________________BENDVY_SRC_ECS_WORLD_WORLD, _nd_8);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_C693)
  {
    Term _rest_2 = r0;
    u32 _namespace_2 = r1;
    Term _descriptors_2 = r2;
    Term _x_0 = r3;
    WL_OPEN
    Term _fb_3[13];
    u64 _sp_3 = ctr_take(e, _x_0, 13, _fb_3);
    u32 _f_11 = _fb_3[0];
    u32 _f_12 = _fb_3[1];
    u32 _f_13 = _fb_3[2];
    Term _f_14 = _fb_3[3];
    u32 _f_15 = _fb_3[4];
    Term _f_16 = _fb_3[5];
    Term _f_17 = _fb_3[6];
    Term _f_18 = _fb_3[7];
    Term _f_19 = _fb_3[8];
    Term _f_20 = _fb_3[9];
    Term _f_21 = _fb_3[10];
    u32 _f_22 = _fb_3[11];
    u32 _f_23 = _fb_3[12];
    spare_free(e, cls_fit(13), _sp_3);
    Term _fb_4[3];
    u64 _sp_4 = ctr_take(e, _f_17, 3, _fb_4);
    Term _f_24 = _fb_4[0];
    Term _f_25 = _fb_4[1];
    Term _f_26 = _fb_4[2];
    spare_free(e, cls_fit(3), _sp_4);
    Term _fb_5[2];
    u64 _sp_5 = ctr_take(e, _f_24, 2, _fb_5);
    Term _f_27 = _fb_5[0];
    Term _f_28 = _fb_5[1];
    spare_free(e, cls_fit(2), _sp_5);
    u64 _nd_1 = heap_alloc(e, cls_fit(19));
    e.mem[_nd_1 + 0] = _rest_2;
    e.mem[_nd_1 + 1] = _namespace_2;
    e.mem[_nd_1 + 2] = _descriptors_2;
    e.mem[_nd_1 + 3] = _f_11;
    e.mem[_nd_1 + 4] = _f_12;
    e.mem[_nd_1 + 5] = _f_13;
    e.mem[_nd_1 + 6] = _f_14;
    e.mem[_nd_1 + 7] = _f_15;
    e.mem[_nd_1 + 8] = _f_16;
    e.mem[_nd_1 + 9] = _f_27;
    e.mem[_nd_1 + 10] = _f_28;
    e.mem[_nd_1 + 11] = _f_25;
    e.mem[_nd_1 + 12] = _f_26;
    e.mem[_nd_1 + 13] = _f_18;
    e.mem[_nd_1 + 14] = _f_19;
    e.mem[_nd_1 + 15] = _f_20;
    e.mem[_nd_1 + 16] = _f_21;
    e.mem[_nd_1 + 17] = _f_22;
    e.mem[_nd_1 + 18] = _f_23;
    r0 = term_clo(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_C694, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_C694)
  {
    Term _rest_3 = r0;
    u32 _namespace_3 = r1;
    Term _descriptors_3 = r2;
    u32 _f_29 = r3;
    u32 _f_30 = r4;
    u32 _f_31 = r5;
    Term _f_32 = r6;
    u32 _f_33 = r7;
    Term _f_34 = r8;
    Term _f_35 = r9;
    Term _f_36 = r10;
    Term _f_37 = r11;
    Term _f_38 = r12;
    Term _f_39 = r13;
    Term _f_40 = r14;
    Term _f_41 = r15;
    Term _f_42 = r16;
    u32 _f_43 = r17;
    u32 _f_44 = r18;
    Term _x_1 = r19;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K695;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K695, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K695, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0)) {
      u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _rest_3;
      e.mem[_t_3 + 1] = _x_1;
      e.mem[_t_3 + 2] = _f_29;
      e.mem[_t_3 + 3] = _f_30;
      e.mem[_t_3 + 4] = _f_31;
      e.mem[_t_3 + 5] = _f_32;
      e.mem[_t_3 + 6] = _f_33;
      e.mem[_t_3 + 7] = _f_34;
      e.mem[_t_3 + 8] = _f_35;
      e.mem[_t_3 + 9] = _f_36;
      e.mem[_t_3 + 10] = _f_37;
      e.mem[_t_3 + 11] = _f_38;
      e.mem[_t_3 + 12] = _f_39;
      e.mem[_t_3 + 13] = _f_40;
      e.mem[_t_3 + 14] = _f_41;
      e.mem[_t_3 + 15] = _f_42;
      e.mem[_t_3 + 16] = _f_43;
      e.mem[_t_3 + 17] = _f_44;
      e.mem[_t_3 + 18] = _namespace_3;
      e.mem[_t_3 + 19] = _descriptors_3;
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0, _t_3);
    }
    r0 = _rest_3;
    r1 = _x_1;
    r2 = _f_29;
    r3 = _f_30;
    r4 = _f_31;
    r5 = _f_32;
    r6 = _f_33;
    r7 = _f_34;
    r8 = _f_35;
    r9 = _f_36;
    r10 = _f_37;
    r11 = _f_38;
    r12 = _f_39;
    r13 = _f_40;
    r14 = _f_41;
    r15 = _f_42;
    r16 = _f_43;
    r17 = _f_44;
    r18 = _namespace_3;
    r19 = _descriptors_3;
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K695)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    u32 _r_3 = r3;
    Term _r_4 = r4;
    u32 _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    Term _r_8 = r8;
    Term _r_9 = r9;
    Term _r_10 = r10;
    Term _r_11 = r11;
    Term _r_12 = r12;
    Term _r_13 = r13;
    Term _r_14 = r14;
    u32 _r_15 = r15;
    u32 _r_16 = r16;
    Term _r_17 = r17;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _r_7);
      e.mem[_nd_2 + 1] = rfc_seal(e, _r_8);
      u64 _nd_3 = heap_alloc(e, cls_fit(15));
      e.mem[_nd_3 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_3 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_3 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_3 + 3] = rfc_seal(e, _r_4);
      e.mem[_nd_3 + 4] = rfc_seal(e, _r_5);
      e.mem[_nd_3 + 5] = rfc_seal(e, _r_6);
      e.mem[_nd_3 + 6] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_2));
      e.mem[_nd_3 + 7] = rfc_seal(e, _r_9);
      e.mem[_nd_3 + 8] = rfc_seal(e, _r_10);
      e.mem[_nd_3 + 9] = rfc_seal(e, _r_11);
      e.mem[_nd_3 + 10] = rfc_seal(e, _r_12);
      e.mem[_nd_3 + 11] = rfc_seal(e, _r_13);
      e.mem[_nd_3 + 12] = rfc_seal(e, _r_14);
      e.mem[_nd_3 + 13] = rfc_seal(e, _r_15);
      e.mem[_nd_3 + 14] = rfc_seal(e, _r_16);
      _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_CLEANUP_COMPLETE, _nd_3);
    } else {
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, _r_7);
      e.mem[_nd_4 + 1] = rfc_seal(e, _r_8);
      u64 _nd_5 = heap_alloc(e, cls_fit(16));
      e.mem[_nd_5 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_5 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_5 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_5 + 3] = rfc_seal(e, _r_4);
      e.mem[_nd_5 + 4] = rfc_seal(e, _r_5);
      e.mem[_nd_5 + 5] = rfc_seal(e, _r_6);
      e.mem[_nd_5 + 6] = rfc_seal(e, term_ctr(CID_CONSUMER_COMPONENTS, _nd_4));
      e.mem[_nd_5 + 7] = rfc_seal(e, _r_9);
      e.mem[_nd_5 + 8] = rfc_seal(e, _r_10);
      e.mem[_nd_5 + 9] = rfc_seal(e, _r_11);
      e.mem[_nd_5 + 10] = rfc_seal(e, _r_12);
      e.mem[_nd_5 + 11] = rfc_seal(e, _r_13);
      e.mem[_nd_5 + 12] = rfc_seal(e, _r_14);
      e.mem[_nd_5 + 13] = rfc_seal(e, _r_15);
      e.mem[_nd_5 + 14] = rfc_seal(e, _r_16);
      e.mem[_nd_5 + 15] = rfc_seal(e, _r_17);
      _b_0 = term_ctr(CID________________BENDVY_SRC_ECS_RELATION_CLEANUP_INCOMPLETE, _nd_5);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K696)
  {
    WL_POPN(1);
    Term _h_18 = STK(0);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K697;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K697, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K697, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_7 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_17;
      e.mem[_t_7 + 1] = _h_18;
      return term_tsk(FID_CLO_APPLY, _t_7);
    }
    r0 = _h_17;
    r1 = _h_18;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0_K697)
  {
    Term _r_18 = r0;
    WL_OPEN
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    u32 _o_10 = 0;
    u32 _o_11 = 0;
    Term _o_12 = 0;
    u32 _o_13 = 0;
    Term _o_14 = 0;
    Term _o_15 = 0;
    Term _o_16 = 0;
    Term _o_17 = 0;
    Term _o_18 = 0;
    Term _o_19 = 0;
    Term _o_20 = 0;
    Term _o_21 = 0;
    Term _o_22 = 0;
    u32 _o_23 = 0;
    u32 _o_24 = 0;
    Term _o_25 = 0;
    if (term_aux(_r_18) == CID________________BENDVY_SRC_ECS_RELATION_CLEANUP_COMPLETE) {
      _o_8 = 0;
      Term _fb_6[15];
      u64 _sp_6 = ctr_take(e, _r_18, 15, _fb_6);
      u32 _f_45 = _fb_6[0];
      u32 _f_46 = _fb_6[1];
      u32 _f_47 = _fb_6[2];
      Term _f_48 = _fb_6[3];
      u32 _f_49 = _fb_6[4];
      Term _f_50 = _fb_6[5];
      Term _f_51 = _fb_6[6];
      Term _f_52 = _fb_6[7];
      Term _f_53 = _fb_6[8];
      Term _f_54 = _fb_6[9];
      Term _f_55 = _fb_6[10];
      Term _f_56 = _fb_6[11];
      Term _f_57 = _fb_6[12];
      u32 _f_58 = _fb_6[13];
      u32 _f_59 = _fb_6[14];
      spare_free(e, cls_fit(15), _sp_6);
      Term _fb_7[2];
      u64 _sp_7 = ctr_take(e, _f_51, 2, _fb_7);
      Term _f_60 = _fb_7[0];
      Term _f_61 = _fb_7[1];
      spare_free(e, cls_fit(2), _sp_7);
      _o_9 = _f_45;
      _o_10 = _f_46;
      _o_11 = _f_47;
      _o_12 = _f_48;
      _o_13 = _f_49;
      _o_14 = _f_50;
      _o_15 = _f_60;
      _o_16 = _f_61;
      _o_17 = _f_52;
      _o_18 = _f_53;
      _o_19 = _f_54;
      _o_20 = _f_55;
      _o_21 = _f_56;
      _o_22 = _f_57;
      _o_23 = _f_58;
      _o_24 = _f_59;
    } else {
      _o_8 = 1;
      Term _fb_8[16];
      u64 _sp_8 = ctr_take(e, _r_18, 16, _fb_8);
      u32 _f_62 = _fb_8[0];
      u32 _f_63 = _fb_8[1];
      u32 _f_64 = _fb_8[2];
      Term _f_65 = _fb_8[3];
      u32 _f_66 = _fb_8[4];
      Term _f_67 = _fb_8[5];
      Term _f_68 = _fb_8[6];
      Term _f_69 = _fb_8[7];
      Term _f_70 = _fb_8[8];
      Term _f_71 = _fb_8[9];
      Term _f_72 = _fb_8[10];
      Term _f_73 = _fb_8[11];
      Term _f_74 = _fb_8[12];
      u32 _f_75 = _fb_8[13];
      u32 _f_76 = _fb_8[14];
      Term _f_77 = _fb_8[15];
      spare_free(e, cls_fit(16), _sp_8);
      Term _fb_9[2];
      u64 _sp_9 = ctr_take(e, _f_68, 2, _fb_9);
      Term _f_78 = _fb_9[0];
      Term _f_79 = _fb_9[1];
      spare_free(e, cls_fit(2), _sp_9);
      _o_9 = _f_62;
      _o_10 = _f_63;
      _o_11 = _f_64;
      _o_12 = _f_65;
      _o_13 = _f_66;
      _o_14 = _f_67;
      _o_15 = _f_78;
      _o_16 = _f_79;
      _o_17 = _f_69;
      _o_18 = _f_70;
      _o_19 = _f_71;
      _o_20 = _f_72;
      _o_21 = _f_73;
      _o_22 = _f_74;
      _o_23 = _f_75;
      _o_24 = _f_76;
      _o_25 = _f_77;
    }
    r0 = _o_8;
    r1 = _o_9;
    r2 = _o_10;
    r3 = _o_11;
    r4 = _o_12;
    r5 = _o_13;
    r6 = _o_14;
    r7 = _o_15;
    r8 = _o_16;
    r9 = _o_17;
    r10 = _o_18;
    r11 = _o_19;
    r12 = _o_20;
    r13 = _o_21;
    r14 = _o_22;
    r15 = _o_23;
    r16 = _o_24;
    r17 = _o_25;
    WL_RETN(18);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_RESULT_OBSERVE_0)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    u32 _result_2 = r2;
    u32 _result_3 = r3;
    Term _result_4 = r4;
    u32 _result_5 = r5;
    Term _result_6 = r6;
    Term _result_7 = r7;
    Term _result_8 = r8;
    Term _result_9 = r9;
    Term _result_10 = r10;
    Term _result_11 = r11;
    Term _result_12 = r12;
    Term _result_13 = r13;
    Term _result_14 = r14;
    u32 _result_15 = r15;
    u32 _result_16 = r16;
    Term _result_17 = r17;
    WL_OPEN
    if (_result_0 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CONSUMER_RESULT_OBSERVE_0_K699;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CONSUMER_RESULT_OBSERVE_0_K699, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CONSUMER_RESULT_OBSERVE_0_K699, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_OBSERVE_0)) {
        u64 _t_1 = task_node(e, FID_CONSUMER_OBSERVE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _result_1;
        e.mem[_t_1 + 1] = _result_2;
        e.mem[_t_1 + 2] = _result_3;
        e.mem[_t_1 + 3] = _result_4;
        e.mem[_t_1 + 4] = _result_5;
        e.mem[_t_1 + 5] = _result_6;
        e.mem[_t_1 + 6] = _result_7;
        e.mem[_t_1 + 7] = _result_8;
        e.mem[_t_1 + 8] = _result_9;
        e.mem[_t_1 + 9] = _result_10;
        e.mem[_t_1 + 10] = _result_11;
        e.mem[_t_1 + 11] = _result_12;
        e.mem[_t_1 + 12] = _result_13;
        e.mem[_t_1 + 13] = _result_14;
        e.mem[_t_1 + 14] = _result_15;
        e.mem[_t_1 + 15] = _result_16;
        return term_tsk(FID_CONSUMER_OBSERVE_0, _t_1);
      }
      r0 = _result_1;
      r1 = _result_2;
      r2 = _result_3;
      r3 = _result_4;
      r4 = _result_5;
      r5 = _result_6;
      r6 = _result_7;
      r7 = _result_8;
      r8 = _result_9;
      r9 = _result_10;
      r10 = _result_11;
      r11 = _result_12;
      r12 = _result_13;
      r13 = _result_14;
      r14 = _result_15;
      r15 = _result_16;
      WL_JMP(FID_CONSUMER_OBSERVE_0);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _result_17;
        STK(1) = FID_CONSUMER_RESULT_OBSERVE_0_K700;
        WL_PUSHN(2);
      } else {
        u64 _t_3 = task_node(e, FID_CONSUMER_RESULT_OBSERVE_0_K700, WL_CONT, WL_IDX, 1);
        e.mem[_t_3 + 0] = _result_17;
        WL_CONT = term_tsk(FID_CONSUMER_RESULT_OBSERVE_0_K700, _t_3);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_OBSERVE_0)) {
        u64 _t_4 = task_node(e, FID_CONSUMER_OBSERVE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_4 + 0] = _result_1;
        e.mem[_t_4 + 1] = _result_2;
        e.mem[_t_4 + 2] = _result_3;
        e.mem[_t_4 + 3] = _result_4;
        e.mem[_t_4 + 4] = _result_5;
        e.mem[_t_4 + 5] = _result_6;
        e.mem[_t_4 + 6] = _result_7;
        e.mem[_t_4 + 7] = _result_8;
        e.mem[_t_4 + 8] = _result_9;
        e.mem[_t_4 + 9] = _result_10;
        e.mem[_t_4 + 10] = _result_11;
        e.mem[_t_4 + 11] = _result_12;
        e.mem[_t_4 + 12] = _result_13;
        e.mem[_t_4 + 13] = _result_14;
        e.mem[_t_4 + 14] = _result_15;
        e.mem[_t_4 + 15] = _result_16;
        return term_tsk(FID_CONSUMER_OBSERVE_0, _t_4);
      }
      r0 = _result_1;
      r1 = _result_2;
      r2 = _result_3;
      r3 = _result_4;
      r4 = _result_5;
      r5 = _result_6;
      r6 = _result_7;
      r7 = _result_8;
      r8 = _result_9;
      r9 = _result_10;
      r10 = _result_11;
      r11 = _result_12;
      r12 = _result_13;
      r13 = _result_14;
      r14 = _result_15;
      r15 = _result_16;
      WL_JMP(FID_CONSUMER_OBSERVE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_RESULT_OBSERVE_0_K699)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_COMPLETE_OBSERVED_0)) {
      u64 _t_2 = task_node(e, FID_CONSUMER_COMPLETE_OBSERVED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      e.mem[_t_2 + 3] = _h_3;
      e.mem[_t_2 + 4] = _h_4;
      e.mem[_t_2 + 5] = _h_5;
      e.mem[_t_2 + 6] = _h_6;
      e.mem[_t_2 + 7] = _h_7;
      e.mem[_t_2 + 8] = _h_8;
      e.mem[_t_2 + 9] = _h_9;
      e.mem[_t_2 + 10] = _h_10;
      e.mem[_t_2 + 11] = _h_11;
      e.mem[_t_2 + 12] = _h_12;
      e.mem[_t_2 + 13] = _h_13;
      e.mem[_t_2 + 14] = _h_14;
      e.mem[_t_2 + 15] = _h_15;
      e.mem[_t_2 + 16] = _h_16;
      return term_tsk(FID_CONSUMER_COMPLETE_OBSERVED_0, _t_2);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = _h_16;
    WL_JMP(FID_CONSUMER_COMPLETE_OBSERVED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONSUMER_RESULT_OBSERVE_0_K700)
  {
    WL_POPN(1);
    Term _result_18 = STK(0);
    u32 _h_17 = r0;
    u32 _h_18 = r1;
    u32 _h_19 = r2;
    Term _h_20 = r3;
    u32 _h_21 = r4;
    Term _h_22 = r5;
    Term _h_23 = r6;
    Term _h_24 = r7;
    Term _h_25 = r8;
    Term _h_26 = r9;
    Term _h_27 = r10;
    Term _h_28 = r11;
    Term _h_29 = r12;
    Term _h_30 = r13;
    u32 _h_31 = r14;
    u32 _h_32 = r15;
    Term _h_33 = r16;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_INCOMPLETE_OBSERVED_0)) {
      u64 _t_5 = task_node(e, FID_CONSUMER_INCOMPLETE_OBSERVED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _result_18;
      e.mem[_t_5 + 1] = _h_17;
      e.mem[_t_5 + 2] = _h_18;
      e.mem[_t_5 + 3] = _h_19;
      e.mem[_t_5 + 4] = _h_20;
      e.mem[_t_5 + 5] = _h_21;
      e.mem[_t_5 + 6] = _h_22;
      e.mem[_t_5 + 7] = _h_23;
      e.mem[_t_5 + 8] = _h_24;
      e.mem[_t_5 + 9] = _h_25;
      e.mem[_t_5 + 10] = _h_26;
      e.mem[_t_5 + 11] = _h_27;
      e.mem[_t_5 + 12] = _h_28;
      e.mem[_t_5 + 13] = _h_29;
      e.mem[_t_5 + 14] = _h_30;
      e.mem[_t_5 + 15] = _h_31;
      e.mem[_t_5 + 16] = _h_32;
      e.mem[_t_5 + 17] = _h_33;
      return term_tsk(FID_CONSUMER_INCOMPLETE_OBSERVED_0, _t_5);
    }
    r0 = _result_18;
    r1 = _h_17;
    r2 = _h_18;
    r3 = _h_19;
    r4 = _h_20;
    r5 = _h_21;
    r6 = _h_22;
    r7 = _h_23;
    r8 = _h_24;
    r9 = _h_25;
    r10 = _h_26;
    r11 = _h_27;
    r12 = _h_28;
    r13 = _h_29;
    r14 = _h_30;
    r15 = _h_31;
    r16 = _h_32;
    r17 = _h_33;
    WL_JMP(FID_CONSUMER_INCOMPLETE_OBSERVED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    u32 _namespace_0 = 31ull;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _namespace_0;
      STK(1) = FID_MAIN_K715;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K715, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _namespace_0;
      WL_CONT = term_tsk(FID_MAIN_K715, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_SETUP_0)) {
      u64 _t_1 = task_node(e, FID_CONSUMER_SETUP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _namespace_0;
      return term_tsk(FID_CONSUMER_SETUP_0, _t_1);
    }
    r0 = _namespace_0;
    WL_JMP(FID_CONSUMER_SETUP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K715)
  {
    WL_POPN(1);
    u32 _namespace_1 = STK(0);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    u32 _h_14 = r14;
    u32 _h_15 = r15;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _namespace_1;
      STK(1) = FID_MAIN_K716;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K716, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _namespace_1;
      WL_CONT = term_tsk(FID_MAIN_K716, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0)) {
      u64 _t_3 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = 0;
      e.mem[_t_3 + 1] = term_ctr(CID_CON, STAT_OFF + 478);
      e.mem[_t_3 + 2] = _h_0;
      e.mem[_t_3 + 3] = _h_1;
      e.mem[_t_3 + 4] = _h_2;
      e.mem[_t_3 + 5] = _h_3;
      e.mem[_t_3 + 6] = _h_4;
      e.mem[_t_3 + 7] = _h_5;
      e.mem[_t_3 + 8] = _h_6;
      e.mem[_t_3 + 9] = _h_7;
      e.mem[_t_3 + 10] = _h_8;
      e.mem[_t_3 + 11] = _h_9;
      e.mem[_t_3 + 12] = _h_10;
      e.mem[_t_3 + 13] = _h_11;
      e.mem[_t_3 + 14] = _h_12;
      e.mem[_t_3 + 15] = _h_13;
      e.mem[_t_3 + 16] = _h_14;
      e.mem[_t_3 + 17] = _h_15;
      e.mem[_t_3 + 18] = _namespace_1;
      e.mem[_t_3 + 19] = term_ctr(CID_CON, STAT_OFF + 476);
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0, _t_3);
    }
    r0 = 0;
    r1 = term_ctr(CID_CON, STAT_OFF + 478);
    r2 = _h_0;
    r3 = _h_1;
    r4 = _h_2;
    r5 = _h_3;
    r6 = _h_4;
    r7 = _h_5;
    r8 = _h_6;
    r9 = _h_7;
    r10 = _h_8;
    r11 = _h_9;
    r12 = _h_10;
    r13 = _h_11;
    r14 = _h_12;
    r15 = _h_13;
    r16 = _h_14;
    r17 = _h_15;
    r18 = _namespace_1;
    r19 = term_ctr(CID_CON, STAT_OFF + 476);
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_DRIVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K716)
  {
    WL_POPN(1);
    u32 _namespace_2 = STK(0);
    u32 _h_16 = r0;
    u32 _h_17 = r1;
    u32 _h_18 = r2;
    u32 _h_19 = r3;
    Term _h_20 = r4;
    u32 _h_21 = r5;
    Term _h_22 = r6;
    Term _h_23 = r7;
    Term _h_24 = r8;
    Term _h_25 = r9;
    Term _h_26 = r10;
    Term _h_27 = r11;
    Term _h_28 = r12;
    Term _h_29 = r13;
    Term _h_30 = r14;
    u32 _h_31 = r15;
    u32 _h_32 = r16;
    Term _h_33 = r17;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _namespace_2;
      STK(1) = FID_MAIN_K717;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K717, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _namespace_2;
      WL_CONT = term_tsk(FID_MAIN_K717, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_RESULT_OBSERVE_0)) {
      u64 _t_5 = task_node(e, FID_CONSUMER_RESULT_OBSERVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_16;
      e.mem[_t_5 + 1] = _h_17;
      e.mem[_t_5 + 2] = _h_18;
      e.mem[_t_5 + 3] = _h_19;
      e.mem[_t_5 + 4] = _h_20;
      e.mem[_t_5 + 5] = _h_21;
      e.mem[_t_5 + 6] = _h_22;
      e.mem[_t_5 + 7] = _h_23;
      e.mem[_t_5 + 8] = _h_24;
      e.mem[_t_5 + 9] = _h_25;
      e.mem[_t_5 + 10] = _h_26;
      e.mem[_t_5 + 11] = _h_27;
      e.mem[_t_5 + 12] = _h_28;
      e.mem[_t_5 + 13] = _h_29;
      e.mem[_t_5 + 14] = _h_30;
      e.mem[_t_5 + 15] = _h_31;
      e.mem[_t_5 + 16] = _h_32;
      e.mem[_t_5 + 17] = _h_33;
      return term_tsk(FID_CONSUMER_RESULT_OBSERVE_0, _t_5);
    }
    r0 = _h_16;
    r1 = _h_17;
    r2 = _h_18;
    r3 = _h_19;
    r4 = _h_20;
    r5 = _h_21;
    r6 = _h_22;
    r7 = _h_23;
    r8 = _h_24;
    r9 = _h_25;
    r10 = _h_26;
    r11 = _h_27;
    r12 = _h_28;
    r13 = _h_29;
    r14 = _h_30;
    r15 = _h_31;
    r16 = _h_32;
    r17 = _h_33;
    WL_JMP(FID_CONSUMER_RESULT_OBSERVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K717)
  {
    WL_POPN(1);
    u32 _namespace_3 = STK(0);
    u32 _h_34 = r0;
    u32 _h_35 = r1;
    u32 _h_36 = r2;
    u32 _h_37 = r3;
    Term _h_38 = r4;
    u32 _h_39 = r5;
    Term _h_40 = r6;
    Term _h_41 = r7;
    Term _h_42 = r8;
    Term _h_43 = r9;
    Term _h_44 = r10;
    Term _h_45 = r11;
    Term _h_46 = r12;
    Term _h_47 = r13;
    Term _h_48 = r14;
    u32 _h_49 = r15;
    u32 _h_50 = r16;
    Term _h_51 = r17;
    Term _h_52 = r18;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _namespace_3;
      STK(1) = _h_52;
      STK(2) = FID_MAIN_K718;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K718, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _namespace_3;
      e.mem[_t_6 + 1] = _h_52;
      WL_CONT = term_tsk(FID_MAIN_K718, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0)) {
      u64 _t_7 = task_node(e, FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = 4ull;
      e.mem[_t_7 + 1] = _h_34;
      e.mem[_t_7 + 2] = _h_35;
      e.mem[_t_7 + 3] = _h_36;
      e.mem[_t_7 + 4] = _h_37;
      e.mem[_t_7 + 5] = _h_38;
      e.mem[_t_7 + 6] = _h_39;
      e.mem[_t_7 + 7] = _h_40;
      e.mem[_t_7 + 8] = _h_41;
      e.mem[_t_7 + 9] = _h_42;
      e.mem[_t_7 + 10] = _h_43;
      e.mem[_t_7 + 11] = _h_44;
      e.mem[_t_7 + 12] = _h_45;
      e.mem[_t_7 + 13] = _h_46;
      e.mem[_t_7 + 14] = _h_47;
      e.mem[_t_7 + 15] = _h_48;
      e.mem[_t_7 + 16] = _h_49;
      e.mem[_t_7 + 17] = _h_50;
      e.mem[_t_7 + 18] = _h_51;
      e.mem[_t_7 + 19] = _namespace_3;
      e.mem[_t_7 + 20] = term_ctr(CID_CON, STAT_OFF + 476);
      return term_tsk(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0, _t_7);
    }
    r0 = 4ull;
    r1 = _h_34;
    r2 = _h_35;
    r3 = _h_36;
    r4 = _h_37;
    r5 = _h_38;
    r6 = _h_39;
    r7 = _h_40;
    r8 = _h_41;
    r9 = _h_42;
    r10 = _h_43;
    r11 = _h_44;
    r12 = _h_45;
    r13 = _h_46;
    r14 = _h_47;
    r15 = _h_48;
    r16 = _h_49;
    r17 = _h_50;
    r18 = _h_51;
    r19 = _namespace_3;
    r20 = term_ctr(CID_CON, STAT_OFF + 476);
    WL_JMP(FID________________BENDVY_SRC_ECS_RELATION_CLEANUP_UNITS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K718)
  {
    WL_POPN(2);
    u32 _namespace_4 = STK(0);
    Term _h_71 = STK(1);
    u32 _h_53 = r0;
    u32 _h_54 = r1;
    u32 _h_55 = r2;
    u32 _h_56 = r3;
    Term _h_57 = r4;
    u32 _h_58 = r5;
    Term _h_59 = r6;
    Term _h_60 = r7;
    Term _h_61 = r8;
    Term _h_62 = r9;
    Term _h_63 = r10;
    Term _h_64 = r11;
    Term _h_65 = r12;
    Term _h_66 = r13;
    Term _h_67 = r14;
    u32 _h_68 = r15;
    u32 _h_69 = r16;
    Term _h_70 = r17;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _namespace_4;
      STK(1) = _h_71;
      STK(2) = FID_MAIN_K719;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID_MAIN_K719, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _namespace_4;
      e.mem[_t_8 + 1] = _h_71;
      WL_CONT = term_tsk(FID_MAIN_K719, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_RESULT_OBSERVE_0)) {
      u64 _t_9 = task_node(e, FID_CONSUMER_RESULT_OBSERVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_53;
      e.mem[_t_9 + 1] = _h_54;
      e.mem[_t_9 + 2] = _h_55;
      e.mem[_t_9 + 3] = _h_56;
      e.mem[_t_9 + 4] = _h_57;
      e.mem[_t_9 + 5] = _h_58;
      e.mem[_t_9 + 6] = _h_59;
      e.mem[_t_9 + 7] = _h_60;
      e.mem[_t_9 + 8] = _h_61;
      e.mem[_t_9 + 9] = _h_62;
      e.mem[_t_9 + 10] = _h_63;
      e.mem[_t_9 + 11] = _h_64;
      e.mem[_t_9 + 12] = _h_65;
      e.mem[_t_9 + 13] = _h_66;
      e.mem[_t_9 + 14] = _h_67;
      e.mem[_t_9 + 15] = _h_68;
      e.mem[_t_9 + 16] = _h_69;
      e.mem[_t_9 + 17] = _h_70;
      return term_tsk(FID_CONSUMER_RESULT_OBSERVE_0, _t_9);
    }
    r0 = _h_53;
    r1 = _h_54;
    r2 = _h_55;
    r3 = _h_56;
    r4 = _h_57;
    r5 = _h_58;
    r6 = _h_59;
    r7 = _h_60;
    r8 = _h_61;
    r9 = _h_62;
    r10 = _h_63;
    r11 = _h_64;
    r12 = _h_65;
    r13 = _h_66;
    r14 = _h_67;
    r15 = _h_68;
    r16 = _h_69;
    r17 = _h_70;
    WL_JMP(FID_CONSUMER_RESULT_OBSERVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K719)
  {
    WL_POPN(2);
    u32 _namespace_5 = STK(0);
    Term _h_91 = STK(1);
    u32 _h_72 = r0;
    u32 _h_73 = r1;
    u32 _h_74 = r2;
    u32 _h_75 = r3;
    Term _h_76 = r4;
    u32 _h_77 = r5;
    Term _h_78 = r6;
    Term _h_79 = r7;
    Term _h_80 = r8;
    Term _h_81 = r9;
    Term _h_82 = r10;
    Term _h_83 = r11;
    Term _h_84 = r12;
    Term _h_85 = r13;
    Term _h_86 = r14;
    u32 _h_87 = r15;
    u32 _h_88 = r16;
    Term _h_89 = r17;
    Term _h_90 = r18;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_91;
      STK(1) = FID_MAIN_K720;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K720, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_91;
      WL_CONT = term_tsk(FID_MAIN_K720, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONSUMER_RESUMED_ONCE_0)) {
      u64 _t_11 = task_node(e, FID_CONSUMER_RESUMED_ONCE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _namespace_5;
      e.mem[_t_11 + 1] = _h_72;
      e.mem[_t_11 + 2] = _h_73;
      e.mem[_t_11 + 3] = _h_74;
      e.mem[_t_11 + 4] = _h_75;
      e.mem[_t_11 + 5] = _h_76;
      e.mem[_t_11 + 6] = _h_77;
      e.mem[_t_11 + 7] = _h_78;
      e.mem[_t_11 + 8] = _h_79;
      e.mem[_t_11 + 9] = _h_80;
      e.mem[_t_11 + 10] = _h_81;
      e.mem[_t_11 + 11] = _h_82;
      e.mem[_t_11 + 12] = _h_83;
      e.mem[_t_11 + 13] = _h_84;
      e.mem[_t_11 + 14] = _h_85;
      e.mem[_t_11 + 15] = _h_86;
      e.mem[_t_11 + 16] = _h_87;
      e.mem[_t_11 + 17] = _h_88;
      e.mem[_t_11 + 18] = _h_89;
      e.mem[_t_11 + 19] = _h_90;
      return term_tsk(FID_CONSUMER_RESUMED_ONCE_0, _t_11);
    }
    r0 = _namespace_5;
    r1 = _h_72;
    r2 = _h_73;
    r3 = _h_74;
    r4 = _h_75;
    r5 = _h_76;
    r6 = _h_77;
    r7 = _h_78;
    r8 = _h_79;
    r9 = _h_80;
    r10 = _h_81;
    r11 = _h_82;
    r12 = _h_83;
    r13 = _h_84;
    r14 = _h_85;
    r15 = _h_86;
    r16 = _h_87;
    r17 = _h_88;
    r18 = _h_89;
    r19 = _h_90;
    WL_JMP(FID_CONSUMER_RESUMED_ONCE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K720)
  {
    WL_POPN(1);
    Term _h_93 = STK(0);
    Term _h_92 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_93;
      STK(1) = FID_MAIN_K721;
      WL_PUSHN(2);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K721, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_93;
      WL_CONT = term_tsk(FID_MAIN_K721, _t_12);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 344);
      e.mem[_t_13 + 1] = _h_92;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 344);
    r1 = _h_92;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K721)
  {
    WL_POPN(1);
    Term _h_95 = STK(0);
    Term _h_94 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_95;
      e.mem[_t_14 + 1] = _h_94;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = _h_95;
    r1 = _h_94;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========



// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
