
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_MISSING 13
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULL 14
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER 15
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_SIGNEDINTEGER 16
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FLOAT 17
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BINARY64 18
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT 19
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_UTF16TEXT 20
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BOOLEAN 21
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_HANDLE 22
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY 23
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT 24
#define CID_CHR 25
#define CID_NIL 26
#define CID_CON 27
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD 28
#define CID_CONTEXT 29
#define CID_SCHEMAA 30
#define CID_________________________BENDVY_SRC_ECS_BUNDLE_PACK_PACK 31
#define CID_INCOMING 32
#define CID_TAIL 33
#define CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLEFACTORY 34
#define CID_PAYLOAD 35
#define CID_BLOCKED 36
#define CID_________________________BENDVY_SRC_ECS_BUNDLE_CONSTRUCTION_VALID 37
#define CID_________________________BENDVY_SRC_ECS_BUNDLE_CONSTRUCTION_FAILED 38
#define CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_VALIDATION 39
#define CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_CONSTRUCTOR 40
#define CID_________________________BENDVY_SRC_ECS_PERSISTENCE_DECLARATION_CONSTRUCTED 41
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FINITENUMBER 42
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_INTEGER 43
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRINGVALUE 44
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BOOLVALUE 45
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_LITERAL 46
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_LITERALVALUES 47
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_LITERALRENDERED 48
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULLABLE 49
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAYVALUE 50
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT 51
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_HANDLEVALUE 52
#define CID_________________________BENDVY_SRC_ECS_ORDINARY_DECLARATION_DECLARATION 53
#define CID_________________________BENDVY_SRC_ECS_BUNDLE_CONSTRUCTION_CONSTRUCTED 54
#define CID_________________________BENDVY_SRC_ECS_BUNDLE_CONSTRUCTION_INVALID 55
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_INVALID 56
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FUELEXHAUSTED 57
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NAMEDCODEC 58
#define CID_REST 59
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_RECEIPT 60
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ACCEPTED 61
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_REJECTED 62
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED 63
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_CONTINUE 64
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STOP 65
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_WORK 66
#define CID_LT 67
#define CID_EQ 68
#define CID_GT 69
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FINITE 70
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_INFINITY 71
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NOTNUMBER 72
#define CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NAN 73
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL 0
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_C12 1
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K13 2
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K14 3
#define FID_STRING_CMP 4
#define FID_STRING_CMP_K21 5
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT 6
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT_K25 7
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED 8
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K27 9
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K28 10
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K29 11
#define FID_STRING_ORDER 12
#define FID_STRING_ORDER_K36 13
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK 14
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K39 15
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K40 16
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K41 17
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K42 18
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK 19
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K44 20
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K45 21
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K46 22
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K47 23
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K48 24
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES 25
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K50 26
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K51 27
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL 28
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K53 29
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K54 30
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID 31
#define FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID_K56 32
#define FID_STRING_EQ 33
#define FID_STRING_EQ_K63 34
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND 35
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K66 36
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K67 37
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K68 38
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K69 39
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K70 40
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K71 41
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD 42
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_K73 43
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_C74 44
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE 45
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE_K78 46
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL 47
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K80 48
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K81 49
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K82 50
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K83 51
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K84 52
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE 53
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K86 54
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K87 55
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K88 56
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K89 57
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE 58
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K91 59
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K92 60
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K93 61
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K94 62
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0 63
#define FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0_K96 64
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET 65
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K101 66
#define FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K102 67
#define FID_BUILT_C115 68
#define FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0 69
#define FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K118 70
#define FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K119 71
#define FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K120 72
#define FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0 73
#define FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0_K123 74
#define FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0 75
#define FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0_K127 76
#define FID_LIST_APPEND 77
#define FID_LIST_APPEND_K130 78
#define FID_U32_SHOW_GO 79
#define FID_TAIL_0 80
#define FID_TAIL_0_K141 81
#define FID_TAIL_0_C142 82
#define FID_HEAD_HEAD_0 83
#define FID_HEAD_HEAD_0_K150 84
#define FID_WIRE 85
#define FID_WIRE_K169 86
#define FID_WIRE_K170 87
#define FID_WIRE_K171 88
#define FID_U32_SHOW 89
#define FID_LIST_SHOW_GO_2 90
#define FID_LIST_SHOW_GO_2_K180 91
#define FID_LIST_SHOW_GO_2_K181 92
#define FID_LIST_SHOW_GO_1 93
#define FID_LIST_SHOW_GO_1_K197 94
#define FID_LIST_SHOW_GO_1_K198 95
#define FID_LIST_SHOW_GO_1_K199 96
#define FID_POSITION 97
#define FID_POSITION_K201 98
#define FID_POSITION_K202 99
#define FID_POSITION_K203 100
#define FID_POSITION_K204 101
#define FID_POSITION_K205 102
#define FID_POSITION_K206 103
#define FID_POSITION_K207 104
#define FID_TREE 105
#define FID_TREE_K226 106
#define FID_TREE_K227 107
#define FID_TREE_K228 108
#define FID_TREE_K229 109
#define FID_TREE_K230 110
#define FID_TREE_K231 111
#define FID_TREE_K232 112
#define FID_TREE_K233 113
#define FID_TREE_K234 114
#define FID_LIST_SHOW_2 115
#define FID_LIST_SHOW_2_K242 116
#define FID_LIST_SHOW_2_K243 117
#define FID_HEAD_STAGE_0 118
#define FID_HEAD_STAGE_0_K245 119
#define FID_HEAD_STAGE_0_K246 120
#define FID_HEAD_STAGE_0_C247 121
#define FID_HEAD_STAGE_0_K248 122
#define FID_HEAD_STAGE_0_K249 123
#define FID_HEAD_STAGE_0_K250 124
#define FID_HEAD_STAGE_0_K251 125
#define FID_HEAD_STAGE_0_K252 126
#define FID_PAYLOAD_OBSERVE 127
#define FID_PAYLOAD_OBSERVE_K258 128
#define FID_PAYLOAD_OBSERVE_K259 129
#define FID_PAYLOAD_OBSERVE_K260 130
#define FID_PAYLOAD_OBSERVE_K261 131
#define FID_LIST_SHOW_1 132
#define FID_LIST_SHOW_1_K266 133
#define FID_LIST_SHOW_1_K267 134
#define FID_LIST_SHOW_1_K268 135
#define FID_TAIL_OBSERVE 136
#define FID_TAIL_OBSERVE_K276 137
#define FID_TAIL_OBSERVE_K277 138
#define FID_TAIL_OBSERVE_K278 139
#define FID_TAIL_OBSERVE_K279 140
#define FID_TAIL_OBSERVE_K280 141
#define FID_TAIL_OBSERVE_K281 142
#define FID_INCOMING_OBSERVE 143
#define FID_INCOMING_OBSERVE_K283 144
#define FID_INCOMING_OBSERVE_K284 145
#define FID_INCOMING_OBSERVE_K285 146
#define FID_INCOMING_OBSERVE_K286 147
#define FID_INCOMING_OBSERVE_K287 148
#define FID_INCOMING_OBSERVE_K288 149
#define FID_OUTER 150
#define FID_OUTER_K293 151
#define FID_OUTER_K294 152
#define FID_OUTER_K295 153
#define FID_OUTER_K296 154
#define FID_OUTER_K297 155
#define FID_OUTER_K298 156
#define FID_OUTER_K299 157
#define FID_OUTER_K300 158
#define FID_OUTER_K301 159
#define FID_FACTORY_OBSERVE_0 160
#define FID_FACTORY_OBSERVE_0_K303 161
#define FID_FACTORY_OBSERVE_0_K304 162
#define FID_FACTORY_OBSERVE_0_K305 163
#define FID_FACTORY_OBSERVE_0_K306 164
#define FID_FACTORY_OBSERVE_0_K307 165
#define FID_COOKED_OBSERVE 166
#define FID_COOKED_OBSERVE_K329 167
#define FID_COOKED_OBSERVE_K330 168
#define FID_COOKED_OBSERVE_K331 169
#define FID_COOKED_OBSERVE_K332 170
#define FID_COMPLETE_0 171
#define FID_COMPLETE_0_K334 172
#define FID_COMPLETE_0_K335 173
#define FID_COMPLETE_0_K336 174
#define FID_COMPLETE_0_K337 175
#define FID_COMPLETE_0_K338 176
#define FID_COMPLETE_0_K339 177
#define FID_COMPLETE_0_K340 178
#define FID_COMPLETE_0_K341 179
#define FID_COMPLETE_0_K342 180
#define FID_COMPLETE_0_K343 181
#define FID_COMPLETE_0_K344 182
#define FID_COMPLETE_0_K345 183
#define FID_COMPLETE_0_K346 184
#define FID_RAW_OBSERVE 185
#define FID_RAW_OBSERVE_K350 186
#define FID_RAW_OBSERVE_K351 187
#define FID_RAW_OBSERVE_K352 188
#define FID_RAW_OBSERVE_K353 189
#define FID_CONTEXT_OBSERVE_0 190
#define FID_CONTEXT_OBSERVE_0_K355 191
#define FID_CONTEXT_OBSERVE_0_K356 192
#define FID_CONTEXT_OBSERVE_0_K357 193
#define FID_CONTEXT_OBSERVE_0_K358 194
#define FID_CONTEXT_OBSERVE_0_K359 195
#define FID_CONTEXT_OBSERVE_0_K360 196
#define FID_CONTEXT_OBSERVE_0_K361 197
#define FID_CONTEXT_OBSERVE_0_K362 198
#define FID_STAGE_0 199
#define FID_STAGE_0_K369 200
#define FID_INITIAL_0 201
#define FID_INITIAL_0_K386 202
#define FID_INITIAL_0_K387 203
#define FID_INITIAL_0_K388 204
#define FID_INITIAL_0_K389 205
#define FID_INITIAL_0_K390 206
#define FID_INITIAL_0_K391 207
#define FID_SCENARIO_0 208
#define FID_SCENARIO_0_K408 209
#define FID_SCENARIO_0_K409 210
#define FID_SCENARIO_0_K410 211
#define FID_SCENARIO_0_K411 212
#define FID_SCENARIO_0_K412 213
#define FID_SCENARIO_0_K413 214
#define FID_SCENARIO_0_K414 215
#define FID_SCENARIO_0_K415 216
#define FID_SCENARIO_0_K416 217
#define FID_SCENARIO_0_K417 218
#define FID_SCENARIO_0_K418 219
#define FID_SCENARIO_0_K419 220
#define FID_SCENARIO_0_K420 221
#define FID_SCENARIO_0_K421 222
#define FID_SCENARIO_0_K422 223
#define FID_STRING_APPEND 224
#define FID_STRING_APPEND_K424 225
#define FID_MAIN 226
#define FID_MAIN_K426 227
#define FID_MAIN_K427 228
#define FID_MAIN_K428 229
#define FID_MAIN_K429 230
#define FID_MAIN_K430 231
#define FID_MAIN_K431 232
#define FID_MAIN_K432 233
#define FID_IO_EMIT 234
#define FID_CLO_APPLY 235
#define FID_EXIT 236
#define FID_ENTER 237
CONSTV u8 FID_T[][3] = { { 2, 0, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 5, 3, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 3, 3, 2 }, { 4, 0, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 4, 1, 2 }, { 5, 0, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 4, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 4, 0, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 5, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 4, 1, 2 }, { 3, 0, 2 }, { 7, 0, 2 }, { 7, 5, 2 }, { 3, 0, 2 }, { 4, 1, 2 }, { 2, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 6, 0, 2 }, { 8, 5, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 4, 0, 2 }, { 6, 1, 2 }, { 10, 8, 2 }, { 4, 1, 2 }, { 5, 0, 2 }, { 8, 8, 2 }, { 5, 0, 2 }, { 11, 9, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 7, 0, 2 }, { 7, 1, 2 }, { 1, 0, 2 }, { 7, 0, 2 }, { 13, 11, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 6, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 10, 0, 2 }, { 16, 13, 2 }, { 13, 10, 2 }, { 3, 0, 2 }, { 5, 1, 2 }, { 2, 1, 2 }, { 9, 1, 2 }, { 18, 10, 2 }, { 14, 1, 2 }, { 2, 0, 2 }, { 3, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 4, 2, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 3, 0, 2 }, { 4, 2, 2 }, { 5, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 1, 0, 2 }, { 2, 2, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 5, 0, 2 }, { 6, 3, 2 }, { 7, 4, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 13, 0, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 12, 5, 2 }, { 7, 1, 2 }, { 13, 7, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 6, 0, 2 }, { 7, 4, 2 }, { 8, 4, 2 }, { 8, 1, 2 }, { 7, 1, 2 }, { 4, 0, 2 }, { 5, 3, 2 }, { 6, 2, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 10, 0, 2 }, { 12, 12, 2 }, { 10, 0, 2 }, { 11, 5, 2 }, { 12, 7, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 2, 0, 2 }, { 11, 11, 2 }, { 13, 12, 2 }, { 13, 6, 2 }, { 13, 5, 2 }, { 14, 7, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 11, 1, 2 }, { 13, 12, 2 }, { 13, 6, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 0 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 0 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 2, 1 }, { 1, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 4, 0 }, { 0, 1 }, { 2, 0 }, { 3, 1 }, { 3, 0 }, { 2, 1 }, { 2, 1 }, { 0, 1 }, { 4, 0 }, { 3, 0 }, { 4, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 1, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 1, 0 }, { 2, 0 }, { 2, 0 }, { 3, 1 }, { 1, 1 }, { 2, 1 }, { 2, 0 }, { 6, 0 }, { 1, 0 }, { 4, 0 }, { 2, 0 }, { 1, 0 }, { 4, 0 }, { 3, 1 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 4, 0 }, { 1, 0 }, { 0, 0 }, { 0, 0 } };
#define STAT_LEN 710

#define WL_RESW 13
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12

#define WL_TABLE WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_C12) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K13) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K14) WL_X(FID_STRING_CMP) WL_X(FID_STRING_CMP_K21) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT_K25) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K27) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K28) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K29) WL_X(FID_STRING_ORDER) WL_X(FID_STRING_ORDER_K36) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K39) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K40) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K41) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K42) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K44) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K45) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K46) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K47) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K48) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K50) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K51) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K53) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K54) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID_K56) WL_X(FID_STRING_EQ) WL_X(FID_STRING_EQ_K63) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K66) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K67) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K68) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K69) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K70) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K71) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_K73) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_C74) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE_K78) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K80) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K81) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K82) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K83) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K84) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K86) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K87) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K88) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K89) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K91) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K92) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K93) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K94) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0_K96) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K101) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K102) WL_X(FID_BUILT_C115) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K118) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K119) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K120) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0_K123) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0) WL_X(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0_K127) WL_X(FID_LIST_APPEND) WL_X(FID_LIST_APPEND_K130) WL_X(FID_U32_SHOW_GO) WL_X(FID_TAIL_0) WL_X(FID_TAIL_0_K141) WL_X(FID_TAIL_0_C142) WL_X(FID_HEAD_HEAD_0) WL_X(FID_HEAD_HEAD_0_K150) WL_X(FID_WIRE) WL_X(FID_WIRE_K169) WL_X(FID_WIRE_K170) WL_X(FID_WIRE_K171) WL_X(FID_U32_SHOW) WL_X(FID_LIST_SHOW_GO_2) WL_X(FID_LIST_SHOW_GO_2_K180) WL_X(FID_LIST_SHOW_GO_2_K181) WL_X(FID_LIST_SHOW_GO_1) WL_X(FID_LIST_SHOW_GO_1_K197) WL_X(FID_LIST_SHOW_GO_1_K198) WL_X(FID_LIST_SHOW_GO_1_K199) WL_X(FID_POSITION) WL_X(FID_POSITION_K201) WL_X(FID_POSITION_K202) WL_X(FID_POSITION_K203) WL_X(FID_POSITION_K204) WL_X(FID_POSITION_K205) WL_X(FID_POSITION_K206) WL_X(FID_POSITION_K207) WL_X(FID_TREE) WL_X(FID_TREE_K226) WL_X(FID_TREE_K227) WL_X(FID_TREE_K228) WL_X(FID_TREE_K229) WL_X(FID_TREE_K230) WL_X(FID_TREE_K231) WL_X(FID_TREE_K232) WL_X(FID_TREE_K233) WL_X(FID_TREE_K234) WL_X(FID_LIST_SHOW_2) WL_X(FID_LIST_SHOW_2_K242) WL_X(FID_LIST_SHOW_2_K243) WL_X(FID_HEAD_STAGE_0) WL_X(FID_HEAD_STAGE_0_K245) WL_X(FID_HEAD_STAGE_0_K246) WL_X(FID_HEAD_STAGE_0_C247) WL_X(FID_HEAD_STAGE_0_K248) WL_X(FID_HEAD_STAGE_0_K249) WL_X(FID_HEAD_STAGE_0_K250) WL_X(FID_HEAD_STAGE_0_K251) WL_X(FID_HEAD_STAGE_0_K252) WL_X(FID_PAYLOAD_OBSERVE) WL_X(FID_PAYLOAD_OBSERVE_K258) WL_X(FID_PAYLOAD_OBSERVE_K259) WL_X(FID_PAYLOAD_OBSERVE_K260) WL_X(FID_PAYLOAD_OBSERVE_K261) WL_X(FID_LIST_SHOW_1) WL_X(FID_LIST_SHOW_1_K266) WL_X(FID_LIST_SHOW_1_K267) WL_X(FID_LIST_SHOW_1_K268) WL_X(FID_TAIL_OBSERVE) WL_X(FID_TAIL_OBSERVE_K276) WL_X(FID_TAIL_OBSERVE_K277) WL_X(FID_TAIL_OBSERVE_K278) WL_X(FID_TAIL_OBSERVE_K279) WL_X(FID_TAIL_OBSERVE_K280) WL_X(FID_TAIL_OBSERVE_K281) WL_X(FID_INCOMING_OBSERVE) WL_X(FID_INCOMING_OBSERVE_K283) WL_X(FID_INCOMING_OBSERVE_K284) WL_X(FID_INCOMING_OBSERVE_K285) WL_X(FID_INCOMING_OBSERVE_K286) WL_X(FID_INCOMING_OBSERVE_K287) WL_X(FID_INCOMING_OBSERVE_K288) WL_X(FID_OUTER) WL_X(FID_OUTER_K293) WL_X(FID_OUTER_K294) WL_X(FID_OUTER_K295) WL_X(FID_OUTER_K296) WL_X(FID_OUTER_K297) WL_X(FID_OUTER_K298) WL_X(FID_OUTER_K299) WL_X(FID_OUTER_K300) WL_X(FID_OUTER_K301) WL_X(FID_FACTORY_OBSERVE_0) WL_X(FID_FACTORY_OBSERVE_0_K303) WL_X(FID_FACTORY_OBSERVE_0_K304) WL_X(FID_FACTORY_OBSERVE_0_K305) WL_X(FID_FACTORY_OBSERVE_0_K306) WL_X(FID_FACTORY_OBSERVE_0_K307) WL_X(FID_COOKED_OBSERVE) WL_X(FID_COOKED_OBSERVE_K329) WL_X(FID_COOKED_OBSERVE_K330) WL_X(FID_COOKED_OBSERVE_K331) WL_X(FID_COOKED_OBSERVE_K332) WL_X(FID_COMPLETE_0) WL_X(FID_COMPLETE_0_K334) WL_X(FID_COMPLETE_0_K335) WL_X(FID_COMPLETE_0_K336) WL_X(FID_COMPLETE_0_K337) WL_X(FID_COMPLETE_0_K338) WL_X(FID_COMPLETE_0_K339) WL_X(FID_COMPLETE_0_K340) WL_X(FID_COMPLETE_0_K341) WL_X(FID_COMPLETE_0_K342) WL_X(FID_COMPLETE_0_K343) WL_X(FID_COMPLETE_0_K344) WL_X(FID_COMPLETE_0_K345) WL_X(FID_COMPLETE_0_K346) WL_X(FID_RAW_OBSERVE) WL_X(FID_RAW_OBSERVE_K350) WL_X(FID_RAW_OBSERVE_K351) WL_X(FID_RAW_OBSERVE_K352) WL_X(FID_RAW_OBSERVE_K353) WL_X(FID_CONTEXT_OBSERVE_0) WL_X(FID_CONTEXT_OBSERVE_0_K355) WL_X(FID_CONTEXT_OBSERVE_0_K356) WL_X(FID_CONTEXT_OBSERVE_0_K357) WL_X(FID_CONTEXT_OBSERVE_0_K358) WL_X(FID_CONTEXT_OBSERVE_0_K359) WL_X(FID_CONTEXT_OBSERVE_0_K360) WL_X(FID_CONTEXT_OBSERVE_0_K361) WL_X(FID_CONTEXT_OBSERVE_0_K362) WL_X(FID_STAGE_0) WL_X(FID_STAGE_0_K369) WL_X(FID_INITIAL_0) WL_X(FID_INITIAL_0_K386) WL_X(FID_INITIAL_0_K387) WL_X(FID_INITIAL_0_K388) WL_X(FID_INITIAL_0_K389) WL_X(FID_INITIAL_0_K390) WL_X(FID_INITIAL_0_K391) WL_X(FID_SCENARIO_0) WL_X(FID_SCENARIO_0_K408) WL_X(FID_SCENARIO_0_K409) WL_X(FID_SCENARIO_0_K410) WL_X(FID_SCENARIO_0_K411) WL_X(FID_SCENARIO_0_K412) WL_X(FID_SCENARIO_0_K413) WL_X(FID_SCENARIO_0_K414) WL_X(FID_SCENARIO_0_K415) WL_X(FID_SCENARIO_0_K416) WL_X(FID_SCENARIO_0_K417) WL_X(FID_SCENARIO_0_K418) WL_X(FID_SCENARIO_0_K419) WL_X(FID_SCENARIO_0_K420) WL_X(FID_SCENARIO_0_K421) WL_X(FID_SCENARIO_0_K422) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K424) WL_X(FID_MAIN) WL_X(FID_MAIN_K426) WL_X(FID_MAIN_K427) WL_X(FID_MAIN_K428) WL_X(FID_MAIN_K429) WL_X(FID_MAIN_K430) WL_X(FID_MAIN_K431) WL_X(FID_MAIN_K432) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 1
#define BLK_SHR 1

#if !DEVICE

static const u32 SHOW_DESC[] = { 4 };

static const char* SHOW_NAMES[] = {  };

#endif

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 46ull, term_pak(CID_SNIL, 0), 93ull, term_pak(CID_SNIL, 0), 91ull, term_pak(CID_SNIL, 0), 114ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 6), 103ull, term_ctr(CID_SCON, STAT_OFF + 8), 101ull, term_ctr(CID_SCON, STAT_OFF + 10), 116ull, term_ctr(CID_SCON, STAT_OFF + 12), 110ull, term_ctr(CID_SCON, STAT_OFF + 14), 105ull, term_ctr(CID_SCON, STAT_OFF + 16), 98ull, term_ctr(CID_SCON, STAT_OFF + 8), 109ull, term_ctr(CID_SCON, STAT_OFF + 20), 117ull, term_ctr(CID_SCON, STAT_OFF + 22), 110ull, term_ctr(CID_SCON, STAT_OFF + 24), 32ull, term_ctr(CID_SCON, STAT_OFF + 26), 101ull, term_ctr(CID_SCON, STAT_OFF + 28), 116ull, term_ctr(CID_SCON, STAT_OFF + 30), 105ull, term_ctr(CID_SCON, STAT_OFF + 32), 110ull, term_ctr(CID_SCON, STAT_OFF + 34), 105ull, term_ctr(CID_SCON, STAT_OFF + 36), 102ull, term_ctr(CID_SCON, STAT_OFF + 38), 103ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 42), 105ull, term_ctr(CID_SCON, STAT_OFF + 44), 114ull, term_ctr(CID_SCON, STAT_OFF + 46), 116ull, term_ctr(CID_SCON, STAT_OFF + 48), 115ull, term_ctr(CID_SCON, STAT_OFF + 50), 110ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 54), 101ull, term_ctr(CID_SCON, STAT_OFF + 56), 108ull, term_ctr(CID_SCON, STAT_OFF + 58), 111ull, term_ctr(CID_SCON, STAT_OFF + 60), 111ull, term_ctr(CID_SCON, STAT_OFF + 62), 98ull, term_ctr(CID_SCON, STAT_OFF + 64), 108ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 68), 114ull, term_ctr(CID_SCON, STAT_OFF + 70), 101ull, term_ctr(CID_SCON, STAT_OFF + 72), 116ull, term_ctr(CID_SCON, STAT_OFF + 74), 105ull, term_ctr(CID_SCON, STAT_OFF + 76), 108ull, term_ctr(CID_SCON, STAT_OFF + 78), 121ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 82), 114ull, term_ctr(CID_SCON, STAT_OFF + 84), 114ull, term_ctr(CID_SCON, STAT_OFF + 86), 97ull, term_ctr(CID_SCON, STAT_OFF + 88), 116ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 92), 101ull, term_ctr(CID_SCON, STAT_OFF + 94), 106ull, term_ctr(CID_SCON, STAT_OFF + 96), 98ull, term_ctr(CID_SCON, STAT_OFF + 98), 111ull, term_ctr(CID_SCON, STAT_OFF + 100), 101ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 104), 100ull, term_ctr(CID_SCON, STAT_OFF + 106), 110ull, term_ctr(CID_SCON, STAT_OFF + 108), 97ull, term_ctr(CID_SCON, STAT_OFF + 110), 104ull, term_ctr(CID_SCON, STAT_OFF + 112), 32ull, term_ctr(CID_SCON, STAT_OFF + 114), 100ull, term_ctr(CID_SCON, STAT_OFF + 116), 108ull, term_ctr(CID_SCON, STAT_OFF + 118), 114ull, term_ctr(CID_SCON, STAT_OFF + 120), 111ull, term_ctr(CID_SCON, STAT_OFF + 122), 119ull, term_ctr(CID_SCON, STAT_OFF + 124), 45ull, term_ctr(CID_SCON, STAT_OFF + 126), 101ull, term_ctr(CID_SCON, STAT_OFF + 128), 109ull, term_ctr(CID_SCON, STAT_OFF + 130), 97ull, term_ctr(CID_SCON, STAT_OFF + 132), 115ull, term_ctr(CID_SCON, STAT_OFF + 134), term_pak(CID_NIL, 0), 36ull, term_pak(CID_SNIL, 0), 105ull, term_ctr(CID_SCON, STAT_OFF + 68), 97ull, term_ctr(CID_SCON, STAT_OFF + 141), 116ull, term_ctr(CID_SCON, STAT_OFF + 143), term_ctr(CID_SCON, STAT_OFF + 145), term_pak(CID_NIL, 0), term_pak(CID_NONE, 0), term_pak(CID_NIL, 0), 48ull, term_pak(CID_SNIL, 0), 41ull, term_pak(CID_SNIL, 0), 100ull, term_ctr(CID_SCON, STAT_OFF + 153), 101ull, term_ctr(CID_SCON, STAT_OFF + 155), 107ull, term_ctr(CID_SCON, STAT_OFF + 157), 99ull, term_ctr(CID_SCON, STAT_OFF + 159), 111ull, term_ctr(CID_SCON, STAT_OFF + 161), 108ull, term_ctr(CID_SCON, STAT_OFF + 163), 66ull, term_ctr(CID_SCON, STAT_OFF + 165), 40ull, term_ctr(CID_SCON, STAT_OFF + 167), 114ull, term_ctr(CID_SCON, STAT_OFF + 169), 111ull, term_ctr(CID_SCON, STAT_OFF + 171), 116ull, term_ctr(CID_SCON, STAT_OFF + 173), 99ull, term_ctr(CID_SCON, STAT_OFF + 175), 117ull, term_ctr(CID_SCON, STAT_OFF + 177), 114ull, term_ctr(CID_SCON, STAT_OFF + 179), 116ull, term_ctr(CID_SCON, STAT_OFF + 181), 115ull, term_ctr(CID_SCON, STAT_OFF + 183), 110ull, term_ctr(CID_SCON, STAT_OFF + 185), 111ull, term_ctr(CID_SCON, STAT_OFF + 187), 67ull, term_ctr(CID_SCON, STAT_OFF + 189), 44ull, term_pak(CID_SNIL, 0), 40ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 195), 111ull, term_ctr(CID_SCON, STAT_OFF + 197), 105ull, term_ctr(CID_SCON, STAT_OFF + 199), 116ull, term_ctr(CID_SCON, STAT_OFF + 201), 97ull, term_ctr(CID_SCON, STAT_OFF + 203), 100ull, term_ctr(CID_SCON, STAT_OFF + 205), 105ull, term_ctr(CID_SCON, STAT_OFF + 207), 108ull, term_ctr(CID_SCON, STAT_OFF + 209), 97ull, term_ctr(CID_SCON, STAT_OFF + 211), 86ull, term_ctr(CID_SCON, STAT_OFF + 213), 100ull, term_ctr(CID_SCON, STAT_OFF + 195), 101ull, term_ctr(CID_SCON, STAT_OFF + 217), 116ull, term_ctr(CID_SCON, STAT_OFF + 219), 115ull, term_ctr(CID_SCON, STAT_OFF + 221), 117ull, term_ctr(CID_SCON, STAT_OFF + 223), 97ull, term_ctr(CID_SCON, STAT_OFF + 225), 104ull, term_ctr(CID_SCON, STAT_OFF + 227), 120ull, term_ctr(CID_SCON, STAT_OFF + 229), 69ull, term_ctr(CID_SCON, STAT_OFF + 231), 108ull, term_ctr(CID_SCON, STAT_OFF + 233), 101ull, term_ctr(CID_SCON, STAT_OFF + 235), 117ull, term_ctr(CID_SCON, STAT_OFF + 237), 70ull, term_ctr(CID_SCON, STAT_OFF + 239), 115ull, term_ctr(CID_SCON, STAT_OFF + 104), 108ull, term_ctr(CID_SCON, STAT_OFF + 243), 97ull, term_ctr(CID_SCON, STAT_OFF + 245), 70ull, term_ctr(CID_SCON, STAT_OFF + 247), 117ull, term_ctr(CID_SCON, STAT_OFF + 104), 114ull, term_ctr(CID_SCON, STAT_OFF + 251), 84ull, term_ctr(CID_SCON, STAT_OFF + 253), 114ull, term_ctr(CID_SCON, STAT_OFF + 195), 101ull, term_ctr(CID_SCON, STAT_OFF + 257), 98ull, term_ctr(CID_SCON, STAT_OFF + 259), 109ull, term_ctr(CID_SCON, STAT_OFF + 261), 117ull, term_ctr(CID_SCON, STAT_OFF + 263), 78ull, term_ctr(CID_SCON, STAT_OFF + 265), 116ull, term_ctr(CID_SCON, STAT_OFF + 195), 120ull, term_ctr(CID_SCON, STAT_OFF + 269), 101ull, term_ctr(CID_SCON, STAT_OFF + 271), 84ull, term_ctr(CID_SCON, STAT_OFF + 273), 100ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 277), 116ull, term_ctr(CID_SCON, STAT_OFF + 279), 99ull, term_ctr(CID_SCON, STAT_OFF + 281), 101ull, term_ctr(CID_SCON, STAT_OFF + 283), 112ull, term_ctr(CID_SCON, STAT_OFF + 285), 120ull, term_ctr(CID_SCON, STAT_OFF + 287), 101ull, term_ctr(CID_SCON, STAT_OFF + 289), 110ull, term_ctr(CID_SCON, STAT_OFF + 291), 117ull, term_ctr(CID_SCON, STAT_OFF + 293), 78ull, term_ctr(CID_SCON, STAT_OFF + 195), 32ull, term_pak(CID_SNIL, 0), 44ull, term_ctr(CID_SCON, STAT_OFF + 299), 61ull, term_pak(CID_SNIL, 0), 114ull, term_ctr(CID_SCON, STAT_OFF + 303), 101ull, term_ctr(CID_SCON, STAT_OFF + 305), 98ull, term_ctr(CID_SCON, STAT_OFF + 307), 109ull, term_ctr(CID_SCON, STAT_OFF + 309), 117ull, term_ctr(CID_SCON, STAT_OFF + 311), 110ull, term_ctr(CID_SCON, STAT_OFF + 313), 47ull, term_ctr(CID_SCON, STAT_OFF + 315), 110ull, term_ctr(CID_SCON, STAT_OFF + 104), 111ull, term_ctr(CID_SCON, STAT_OFF + 319), 78ull, term_ctr(CID_SCON, STAT_OFF + 321), 97ull, term_ctr(CID_SCON, STAT_OFF + 305), 108ull, term_ctr(CID_SCON, STAT_OFF + 325), 97ull, term_ctr(CID_SCON, STAT_OFF + 327), 99ull, term_ctr(CID_SCON, STAT_OFF + 329), 115ull, term_ctr(CID_SCON, STAT_OFF + 331), 47ull, term_ctr(CID_SCON, STAT_OFF + 333), 103ull, term_ctr(CID_SCON, STAT_OFF + 303), 97ull, term_ctr(CID_SCON, STAT_OFF + 337), 116ull, term_ctr(CID_SCON, STAT_OFF + 339), 47ull, term_ctr(CID_SCON, STAT_OFF + 341), 108ull, term_ctr(CID_SCON, STAT_OFF + 303), 105ull, term_ctr(CID_SCON, STAT_OFF + 345), 97ull, term_ctr(CID_SCON, STAT_OFF + 347), 102ull, term_ctr(CID_SCON, STAT_OFF + 349), 47ull, term_ctr(CID_SCON, STAT_OFF + 351), 101ull, term_ctr(CID_SCON, STAT_OFF + 303), 114ull, term_ctr(CID_SCON, STAT_OFF + 355), 105ull, term_ctr(CID_SCON, STAT_OFF + 357), 119ull, term_ctr(CID_SCON, STAT_OFF + 359), 47ull, term_ctr(CID_SCON, STAT_OFF + 361), 76ull, term_ctr(CID_SCON, STAT_OFF + 195), 78ull, term_ctr(CID_SCON, STAT_OFF + 24), 101ull, term_ctr(CID_SCON, STAT_OFF + 367), 116ull, term_ctr(CID_SCON, STAT_OFF + 369), 105ull, term_ctr(CID_SCON, STAT_OFF + 371), 110ull, term_ctr(CID_SCON, STAT_OFF + 373), 105ull, term_ctr(CID_SCON, STAT_OFF + 375), 70ull, term_ctr(CID_SCON, STAT_OFF + 377), 73ull, term_ctr(CID_SCON, STAT_OFF + 16), 108ull, term_ctr(CID_SCON, STAT_OFF + 251), 97ull, term_ctr(CID_SCON, STAT_OFF + 383), 86ull, term_ctr(CID_SCON, STAT_OFF + 385), 103ull, term_ctr(CID_SCON, STAT_OFF + 387), 110ull, term_ctr(CID_SCON, STAT_OFF + 389), 105ull, term_ctr(CID_SCON, STAT_OFF + 391), 114ull, term_ctr(CID_SCON, STAT_OFF + 393), 116ull, term_ctr(CID_SCON, STAT_OFF + 395), 83ull, term_ctr(CID_SCON, STAT_OFF + 397), 108ull, term_ctr(CID_SCON, STAT_OFF + 387), 111ull, term_ctr(CID_SCON, STAT_OFF + 401), 111ull, term_ctr(CID_SCON, STAT_OFF + 403), 66ull, term_ctr(CID_SCON, STAT_OFF + 405), 99ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 409), 100ull, term_ctr(CID_SCON, STAT_OFF + 411), 111ull, term_ctr(CID_SCON, STAT_OFF + 413), 99ull, term_ctr(CID_SCON, STAT_OFF + 415), 45ull, term_ctr(CID_SCON, STAT_OFF + 417), 100ull, term_ctr(CID_SCON, STAT_OFF + 419), 101ull, term_ctr(CID_SCON, STAT_OFF + 421), 116ull, term_ctr(CID_SCON, STAT_OFF + 423), 99ull, term_ctr(CID_SCON, STAT_OFF + 425), 101ull, term_ctr(CID_SCON, STAT_OFF + 427), 112ull, term_ctr(CID_SCON, STAT_OFF + 429), 120ull, term_ctr(CID_SCON, STAT_OFF + 431), 101ull, term_ctr(CID_SCON, STAT_OFF + 433), 110ull, term_ctr(CID_SCON, STAT_OFF + 435), 117ull, term_ctr(CID_SCON, STAT_OFF + 437), 45ull, term_ctr(CID_SCON, STAT_OFF + 90), 100ull, term_ctr(CID_SCON, STAT_OFF + 441), 101ull, term_ctr(CID_SCON, STAT_OFF + 443), 116ull, term_ctr(CID_SCON, STAT_OFF + 445), 99ull, term_ctr(CID_SCON, STAT_OFF + 447), 117ull, term_ctr(CID_SCON, STAT_OFF + 449), 114ull, term_ctr(CID_SCON, STAT_OFF + 451), 116ull, term_ctr(CID_SCON, STAT_OFF + 453), 115ull, term_ctr(CID_SCON, STAT_OFF + 455), 110ull, term_ctr(CID_SCON, STAT_OFF + 457), 111ull, term_ctr(CID_SCON, STAT_OFF + 459), 99ull, term_ctr(CID_SCON, STAT_OFF + 461), 91ull, term_ctr(CID_SCON, STAT_OFF + 2), 114ull, term_ctr(CID_SCON, STAT_OFF + 104), 117ull, term_ctr(CID_SCON, STAT_OFF + 467), 108ull, term_ctr(CID_SCON, STAT_OFF + 469), 105ull, term_ctr(CID_SCON, STAT_OFF + 471), 97ull, term_ctr(CID_SCON, STAT_OFF + 473), 102ull, term_ctr(CID_SCON, STAT_OFF + 475), 45ull, term_ctr(CID_SCON, STAT_OFF + 477), 121ull, term_ctr(CID_SCON, STAT_OFF + 479), 114ull, term_ctr(CID_SCON, STAT_OFF + 481), 116ull, term_ctr(CID_SCON, STAT_OFF + 483), 101ull, term_ctr(CID_SCON, STAT_OFF + 485), 114ull, term_ctr(CID_SCON, STAT_OFF + 487), 45ull, term_ctr(CID_SCON, STAT_OFF + 489), 100ull, term_ctr(CID_SCON, STAT_OFF + 491), 101ull, term_ctr(CID_SCON, STAT_OFF + 493), 116ull, term_ctr(CID_SCON, STAT_OFF + 495), 99ull, term_ctr(CID_SCON, STAT_OFF + 497), 101ull, term_ctr(CID_SCON, STAT_OFF + 499), 112ull, term_ctr(CID_SCON, STAT_OFF + 501), 120ull, term_ctr(CID_SCON, STAT_OFF + 503), 101ull, term_ctr(CID_SCON, STAT_OFF + 505), 110ull, term_ctr(CID_SCON, STAT_OFF + 507), 117ull, term_ctr(CID_SCON, STAT_OFF + 509), 116ull, term_ctr(CID_SCON, STAT_OFF + 349), 47ull, term_ctr(CID_SCON, STAT_OFF + 513), 10ull, term_pak(CID_SNIL, 0), 119ull, term_ctr(CID_SCON, STAT_OFF + 303), 97ull, term_ctr(CID_SCON, STAT_OFF + 519), 114ull, term_ctr(CID_SCON, STAT_OFF + 521), 47ull, term_ctr(CID_SCON, STAT_OFF + 523), 58ull, term_pak(CID_SNIL, 0), 100ull, term_ctr(CID_SCON, STAT_OFF + 527), 101ull, term_ctr(CID_SCON, STAT_OFF + 529), 114ull, term_ctr(CID_SCON, STAT_OFF + 531), 111ull, term_ctr(CID_SCON, STAT_OFF + 533), 116ull, term_ctr(CID_SCON, STAT_OFF + 535), 115ull, term_ctr(CID_SCON, STAT_OFF + 537), 101ull, term_ctr(CID_SCON, STAT_OFF + 539), 114ull, term_ctr(CID_SCON, STAT_OFF + 541), 116ull, term_ctr(CID_SCON, STAT_OFF + 303), 117ull, term_ctr(CID_SCON, STAT_OFF + 545), 112ull, term_ctr(CID_SCON, STAT_OFF + 547), 110ull, term_ctr(CID_SCON, STAT_OFF + 549), 105ull, term_ctr(CID_SCON, STAT_OFF + 551), 47ull, term_ctr(CID_SCON, STAT_OFF + 553), 99ull, term_ctr(CID_SCON, STAT_OFF + 345), 101ull, term_ctr(CID_SCON, STAT_OFF + 557), 100ull, term_ctr(CID_SCON, STAT_OFF + 559), 47ull, term_ctr(CID_SCON, STAT_OFF + 561), 121ull, term_ctr(CID_SCON, STAT_OFF + 303), 116ull, term_ctr(CID_SCON, STAT_OFF + 565), 105ull, term_ctr(CID_SCON, STAT_OFF + 567), 116ull, term_ctr(CID_SCON, STAT_OFF + 569), 110ull, term_ctr(CID_SCON, STAT_OFF + 571), 101ull, term_ctr(CID_SCON, STAT_OFF + 573), 100ull, term_ctr(CID_SCON, STAT_OFF + 575), 105ull, term_ctr(CID_SCON, STAT_OFF + 577), 114ull, term_ctr(CID_SCON, STAT_OFF + 349), 116ull, term_ctr(CID_SCON, STAT_OFF + 581), 47ull, term_ctr(CID_SCON, STAT_OFF + 583), 115ull, term_ctr(CID_SCON, STAT_OFF + 545), 101ull, term_ctr(CID_SCON, STAT_OFF + 587), 114ull, term_ctr(CID_SCON, STAT_OFF + 589), 47ull, term_ctr(CID_SCON, STAT_OFF + 591), 114ull, term_ctr(CID_SCON, STAT_OFF + 565), 111ull, term_ctr(CID_SCON, STAT_OFF + 595), 116ull, term_ctr(CID_SCON, STAT_OFF + 597), 99ull, term_ctr(CID_SCON, STAT_OFF + 599), 97ull, term_ctr(CID_SCON, STAT_OFF + 601), 102ull, term_ctr(CID_SCON, STAT_OFF + 603), 115ull, term_ctr(CID_SCON, STAT_OFF + 303), 110ull, term_ctr(CID_SCON, STAT_OFF + 607), 111ull, term_ctr(CID_SCON, STAT_OFF + 609), 105ull, term_ctr(CID_SCON, STAT_OFF + 611), 116ull, term_ctr(CID_SCON, STAT_OFF + 613), 105ull, term_ctr(CID_SCON, STAT_OFF + 615), 115ull, term_ctr(CID_SCON, STAT_OFF + 617), 111ull, term_ctr(CID_SCON, STAT_OFF + 619), 112ull, term_ctr(CID_SCON, STAT_OFF + 621), 47ull, term_ctr(CID_SCON, STAT_OFF + 623), 115ull, term_ctr(CID_SCON, STAT_OFF + 531), 117ull, term_ctr(CID_SCON, STAT_OFF + 627), 102ull, term_ctr(CID_SCON, STAT_OFF + 629), 101ull, term_ctr(CID_SCON, STAT_OFF + 631), 114ull, term_ctr(CID_SCON, STAT_OFF + 633), 105ull, term_ctr(CID_SCON, STAT_OFF + 529), 108ull, term_ctr(CID_SCON, STAT_OFF + 637), 97ull, term_ctr(CID_SCON, STAT_OFF + 639), 118ull, term_ctr(CID_SCON, STAT_OFF + 641), 108ull, term_ctr(CID_SCON, STAT_OFF + 527), 97ull, term_ctr(CID_SCON, STAT_OFF + 645), 105ull, term_ctr(CID_SCON, STAT_OFF + 647), 116ull, term_ctr(CID_SCON, STAT_OFF + 649), 105ull, term_ctr(CID_SCON, STAT_OFF + 651), 110ull, term_ctr(CID_SCON, STAT_OFF + 653), 105ull, term_ctr(CID_SCON, STAT_OFF + 655), 97ull, term_ctr(CID_SCON, STAT_OFF + 277), 98ull, term_ctr(CID_SCON, STAT_OFF + 659), term_ctr(CID_SCON, STAT_OFF + 661), 115ull, term_ctr(CID_SCON, STAT_OFF + 517), 115ull, term_ctr(CID_SCON, STAT_OFF + 664), 101ull, term_ctr(CID_SCON, STAT_OFF + 666), 99ull, term_ctr(CID_SCON, STAT_OFF + 668), 99ull, term_ctr(CID_SCON, STAT_OFF + 670), 117ull, term_ctr(CID_SCON, STAT_OFF + 672), 115ull, term_ctr(CID_SCON, STAT_OFF + 674), 109ull, term_ctr(CID_SCON, STAT_OFF + 517), 111ull, term_ctr(CID_SCON, STAT_OFF + 678), 116ull, term_ctr(CID_SCON, STAT_OFF + 680), 115ull, term_ctr(CID_SCON, STAT_OFF + 682), 117ull, term_ctr(CID_SCON, STAT_OFF + 684), 99ull, term_ctr(CID_SCON, STAT_OFF + 686), 110ull, term_ctr(CID_SCON, STAT_OFF + 517), 111ull, term_ctr(CID_SCON, STAT_OFF + 690), 105ull, term_ctr(CID_SCON, STAT_OFF + 692), 116ull, term_ctr(CID_SCON, STAT_OFF + 694), 97ull, term_ctr(CID_SCON, STAT_OFF + 696), 100ull, term_ctr(CID_SCON, STAT_OFF + 698), 105ull, term_ctr(CID_SCON, STAT_OFF + 700), 108ull, term_ctr(CID_SCON, STAT_OFF + 702), 97ull, term_ctr(CID_SCON, STAT_OFF + 704), 118ull, term_ctr(CID_SCON, STAT_OFF + 706) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_1 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_1 = 0;
    } else {
      _v_1 = _b_0;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _negative_0 = r0;
  u32 _infinite_0 = r1;
  WL_SPIN
    if (_infinite_0 == 1) {
      _v_5 = 1;
      _v_6 = _negative_0;
      _v_7 = 0;
      _v_8 = 0;
      _v_9 = 0;
    } else {
      _v_5 = 3;
      _v_6 = 0;
      _v_7 = 0;
      _v_8 = 0;
      _v_9 = 0;
    }
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6) {
  u32 wpoll = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _fuel_1 = r0;
  u32 _negative_2 = r1;
  u32 _high_1 = r2;
  u32 _low_1 = r3;
  u32 _exponent_2 = r4;
  u32 _zero_1 = r5;
  u32 _even_0 = r6;
  WL_SPIN
    if (_fuel_1 == 0) {
      if (_zero_1 == 1) {
        _v_27 = 0;
        _v_28 = 0;
        _v_29 = 0ull;
        _v_30 = 0ull;
        _v_31 = 0ull;
      } else {
        if (_even_0 == 0) {
          _v_27 = 0;
          _v_28 = _negative_2;
          _v_29 = _high_1;
          _v_30 = _low_1;
          _v_31 = _exponent_2;
        } else {
          _v_27 = 0;
          _v_28 = _negative_2;
          _v_29 = _high_1;
          _v_30 = _low_1;
          _v_31 = _exponent_2;
        }
      }
    } else {
      Term _more_0 = (_fuel_1 - 1);
      if (_zero_1 == 1) {
        _v_27 = 0;
        _v_28 = 0;
        _v_29 = 0ull;
        _v_30 = 0ull;
        _v_31 = 0ull;
      } else {
        if (_even_0 == 0) {
          _v_27 = 0;
          _v_28 = _negative_2;
          _v_29 = _high_1;
          _v_30 = _low_1;
          _v_31 = _exponent_2;
        } else {
          Term _a_1 = 2ull;
          Term _a_2 = 2ull;
          Term _a_3 = 2ull;
          Term _a_4 = 2ull;
          Term _a_5 = ((u32)(_a_4) == 0 ? 0 : (u64)U32_QUO((u32)(_low_1), (u32)(_a_4)));
          Term _a_6 = 2ull;
          r0 = _more_0;
          r1 = _negative_2;
          r2 = ((u32)(_a_1) == 0 ? 0 : (u64)U32_QUO((u32)(_high_1), (u32)(_a_1)));
          r3 = U32_BIN(((u32)(_a_2) == 0 ? 0 : (u64)U32_QUO((u32)(_low_1), (u32)(_a_2))), +, U32_BIN(((u32)(_a_3) == 0 ? _high_1 : U32_BIN(_high_1, -, U32_QUO((u32)(_high_1), (u32)(_a_3)) * _a_3)), *, 2147483648ull));
          r4 = U32_BIN(_exponent_2, +, 1ull);
          r5 = 0;
          r6 = U32_BIN(((u32)(_a_6) == 0 ? _a_5 : U32_BIN(_a_5, -, U32_QUO((u32)(_a_5), (u32)(_a_6)) * _a_6)), ==, 0ull);
          _fuel_1 = r0;
          _negative_2 = r1;
          _high_1 = r2;
          _low_1 = r3;
          _exponent_2 = r4;
          _zero_1 = r5;
          _even_0 = r6;
          WL_AGAIN(spin_3);
        }
      }
    }
  break;
  }
  o[0] = _v_27;
  o[1] = _v_28;
  o[2] = _v_29;
  o[3] = _v_30;
  o[4] = _v_31;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, Term r0, u32 r1, u32 r2, u32 r3, u32 r4) {
  u32 wpoll = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  Term _fuel_0 = r0;
  u32 _negative_1 = r1;
  u32 _high_0 = r2;
  u32 _low_0 = r3;
  u32 _exponent_1 = r4;
  WL_SPIN
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    Term _o_1[1];
    if (spin_0(e, _o_1, U32_BIN(_high_0, ==, 0ull), U32_BIN(_low_0, ==, 0ull)) == 0) {
      return 0;
    }
    _v_21 = _o_1[0];
    _v_20 = _v_21;
    Term _a_0 = 2ull;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _o_2[5];
    if (spin_3(e, _o_2, _fuel_0, _negative_1, _high_0, _low_0, _exponent_1, _v_20, U32_BIN(((u32)(_a_0) == 0 ? _low_0 : U32_BIN(_low_0, -, U32_QUO((u32)(_low_0), (u32)(_a_0)) * _a_0)), ==, 0ull)) == 0) {
      return 0;
    }
    _v_22 = _o_2[0];
    _v_23 = _o_2[1];
    _v_24 = _o_2[2];
    _v_25 = _o_2[3];
    _v_26 = _o_2[4];
    _v_15 = _v_22;
    _v_16 = _v_23;
    _v_17 = _v_24;
    _v_18 = _v_25;
    _v_19 = _v_26;
  break;
  }
  o[0] = _v_15;
  o[1] = _v_16;
  o[2] = _v_17;
  o[3] = _v_18;
  o[4] = _v_19;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_3 = 0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  u32 _h1b_0 = r0;
  u32 _h2b_0 = r1;
  Term _rr_0 = r2;
  Term _rr_1 = r3;
  u32 _rr_2 = r4;
  WL_SPIN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h1b_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _rr_0);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h2b_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _rr_1);
    _v_3 = term_ctr(CID_SCON, _nd_2);
    _v_4 = term_ctr(CID_SCON, _nd_3);
    _v_5 = _rr_2;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  u32 _v_1 = 0;
  Term _units_0 = r0;
  WL_SPIN
    if (term_aux(_units_0) == CID_NIL) {
      _v_1 = 1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _units_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      term_sink(e, _f_1);
      _v_1 = 0;
      spare_free(e, cls_fit(2), _sp_0);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4) {
  u32 wpoll = 0;
  u32 _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  u32 _bits_1 = r0;
  u32 _exponent_0 = r1;
  u32 _fraction_0 = r2;
  u32 _special_0 = r3;
  u32 _zero_0 = r4;
  WL_SPIN
    if (_special_0 == 1) {
      u32 _v_10 = 0;
      u32 _v_11 = 0;
      u32 _v_12 = 0;
      u32 _v_13 = 0;
      u32 _v_14 = 0;
      Term _o_0[5];
      if (spin_1(e, _o_0, U32_BIN(_bits_1, >=, 2147483648ull), U32_BIN(_fraction_0, ==, 0ull)) == 0) {
        return 0;
      }
      _v_10 = _o_0[0];
      _v_11 = _o_0[1];
      _v_12 = _o_0[2];
      _v_13 = _o_0[3];
      _v_14 = _o_0[4];
      _v_5 = _v_10;
      _v_6 = _v_11;
      _v_7 = _v_12;
      _v_8 = _v_13;
      _v_9 = _v_14;
    } else {
      if (_zero_0 == 1) {
        u32 _v_15 = 0;
        u32 _v_16 = 0;
        u32 _v_17 = 0;
        u32 _v_18 = 0;
        u32 _v_19 = 0;
        Term _o_1[5];
        if (spin_2(e, _o_1, 64ull, U32_BIN(_bits_1, >=, 2147483648ull), 0ull, _fraction_0, 925ull) == 0) {
          return 0;
        }
        _v_15 = _o_1[0];
        _v_16 = _o_1[1];
        _v_17 = _o_1[2];
        _v_18 = _o_1[3];
        _v_19 = _o_1[4];
        _v_5 = _v_15;
        _v_6 = _v_16;
        _v_7 = _v_17;
        _v_8 = _v_18;
        _v_9 = _v_19;
      } else {
        u32 _v_20 = 0;
        u32 _v_21 = 0;
        u32 _v_22 = 0;
        u32 _v_23 = 0;
        u32 _v_24 = 0;
        Term _o_2[5];
        if (spin_2(e, _o_2, 64ull, U32_BIN(_bits_1, >=, 2147483648ull), 0ull, U32_BIN(_fraction_0, +, 8388608ull), U32_BIN(_exponent_0, +, 924ull)) == 0) {
          return 0;
        }
        _v_20 = _o_2[0];
        _v_21 = _o_2[1];
        _v_22 = _o_2[2];
        _v_23 = _o_2[3];
        _v_24 = _o_2[4];
        _v_5 = _v_20;
        _v_6 = _v_21;
        _v_7 = _v_22;
        _v_8 = _v_23;
        _v_9 = _v_24;
      }
    }
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _p_0 = r0;
  Term _p_1 = r1;
  WL_SPIN
    term_sink(e, _p_0);
    _v_1 = _p_1;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    _v_6 = _a_1;
    _v_7 = _b_1;
    _v_8 = (U32_BIN(_a_1, >, _b_1) + U32_BIN(_a_1, >=, _b_1));
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_1 = 0;
  u32 _code_0 = r0;
  Term _rest_0 = r1;
  u32 _bmp_0 = r2;
  WL_SPIN
    if (_bmp_0 == 1) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _code_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _rest_0);
      _v_1 = term_ctr(CID_CON, _nd_0);
    } else {
      Term _a_0 = U32_BIN(_code_0, -, 65536ull);
      Term _a_1 = 1024ull;
      Term _a_2 = U32_BIN(_code_0, -, 65536ull);
      Term _a_3 = 1024ull;
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, U32_BIN(56320ull, +, ((u32)(_a_3) == 0 ? _a_2 : U32_BIN(_a_2, -, U32_QUO((u32)(_a_2), (u32)(_a_3)) * _a_3))));
      e.mem[_nd_1 + 1] = rfc_seal(e, _rest_0);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, U32_BIN(55296ull, +, ((u32)(_a_1) == 0 ? 0 : (u64)U32_QUO((u32)(_a_0), (u32)(_a_1)))));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
      _v_1 = term_ctr(CID_CON, _nd_2);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_9 = 0;
  Term _p_0 = r0;
  Term _p_1 = r1;
  WL_SPIN
    term_sink(e, _p_1);
    _v_9 = _p_0;
  break;
  }
  o[0] = _v_9;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_7 = 0;
  Term _a_0 = r0;
  Term _b_0 = r1;
  WL_SPIN
    Term _a_1 = (_b_0 == 0 ? 0 : _a_0 / _b_0);
    Term _a_2 = (_b_0 == 0 ? _a_0 : _a_0 % _b_0);
    Term _v_8 = 0;
    Term _o_1[1];
    if (spin_11(e, _o_1, _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_8 = _o_1[0];
    _v_7 = _v_8;
  break;
  }
  o[0] = _v_7;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_12 = 0;
  Term _a_3 = r0;
  Term _b_1 = r1;
  WL_SPIN
    Term _a_4 = (_b_1 == 0 ? 0 : _a_3 / _b_1);
    Term _a_5 = (_b_1 == 0 ? _a_3 : _a_3 % _b_1);
    Term _v_13 = 0;
    Term _o_3[1];
    if (spin_7(e, _o_3, _a_4, blk_loc(e.mem, _a_4), _a_5, blk_loc(e.mem, _a_5)) == 0) {
      return 0;
    }
    _v_13 = _o_3[0];
    _v_12 = _v_13;
  break;
  }
  o[0] = _v_12;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _bits_0 = r0;
  WL_SPIN
    Term _a_6 = 8388608ull;
    Term _a_7 = ((u32)(_a_6) == 0 ? 0 : (u64)U32_QUO((u32)(_bits_0), (u32)(_a_6)));
    Term _a_8 = 256ull;
    Term _a_9 = 8388608ull;
    Term _a_10 = 8388608ull;
    Term _a_11 = ((u32)(_a_10) == 0 ? 0 : (u64)U32_QUO((u32)(_bits_0), (u32)(_a_10)));
    Term _a_12 = 256ull;
    Term _a_13 = 8388608ull;
    Term _a_14 = ((u32)(_a_13) == 0 ? 0 : (u64)U32_QUO((u32)(_bits_0), (u32)(_a_13)));
    Term _a_15 = 256ull;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _o_6[5];
    if (spin_6(e, _o_6, _bits_0, ((u32)(_a_8) == 0 ? _a_7 : U32_BIN(_a_7, -, U32_QUO((u32)(_a_7), (u32)(_a_8)) * _a_8)), ((u32)(_a_9) == 0 ? _bits_0 : U32_BIN(_bits_0, -, U32_QUO((u32)(_bits_0), (u32)(_a_9)) * _a_9)), U32_BIN(((u32)(_a_12) == 0 ? _a_11 : U32_BIN(_a_11, -, U32_QUO((u32)(_a_11), (u32)(_a_12)) * _a_12)), ==, 255ull), U32_BIN(((u32)(_a_15) == 0 ? _a_14 : U32_BIN(_a_14, -, U32_QUO((u32)(_a_14), (u32)(_a_15)) * _a_15)), ==, 0ull)) == 0) {
      return 0;
    }
    _v_29 = _o_6[0];
    _v_30 = _o_6[1];
    _v_31 = _o_6[2];
    _v_32 = _o_6[3];
    _v_33 = _o_6[4];
    _v_24 = _v_29;
    _v_25 = _v_30;
    _v_26 = _v_31;
    _v_27 = _v_32;
    _v_28 = _v_33;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _negative_0 = r0;
  u32 _exponent_0 = r1;
  u32 _high_1 = r2;
  u32 _low_1 = r3;
  u32 _special_0 = r4;
  u32 _zero_0 = r5;
  WL_SPIN
    if (_special_0 == 1) {
      u32 _v_54 = 0;
      u32 _v_55 = 0;
      Term _o_8[1];
      if (spin_0(e, _o_8, U32_BIN(_high_1, ==, 0ull), U32_BIN(_low_1, ==, 0ull)) == 0) {
        return 0;
      }
      _v_55 = _o_8[0];
      _v_54 = _v_55;
      u32 _v_56 = 0;
      u32 _v_57 = 0;
      u32 _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      Term _o_9[5];
      if (spin_1(e, _o_9, _negative_0, _v_54) == 0) {
        return 0;
      }
      _v_56 = _o_9[0];
      _v_57 = _o_9[1];
      _v_58 = _o_9[2];
      _v_59 = _o_9[3];
      _v_60 = _o_9[4];
      _v_49 = _v_56;
      _v_50 = _v_57;
      _v_51 = _v_58;
      _v_52 = _v_59;
      _v_53 = _v_60;
    } else {
      if (_zero_0 == 1) {
        u32 _v_61 = 0;
        u32 _v_62 = 0;
        u32 _v_63 = 0;
        u32 _v_64 = 0;
        u32 _v_65 = 0;
        Term _o_10[5];
        if (spin_2(e, _o_10, 64ull, _negative_0, _high_1, _low_1, 0ull) == 0) {
          return 0;
        }
        _v_61 = _o_10[0];
        _v_62 = _o_10[1];
        _v_63 = _o_10[2];
        _v_64 = _o_10[3];
        _v_65 = _o_10[4];
        _v_49 = _v_61;
        _v_50 = _v_62;
        _v_51 = _v_63;
        _v_52 = _v_64;
        _v_53 = _v_65;
      } else {
        u32 _v_66 = 0;
        u32 _v_67 = 0;
        u32 _v_68 = 0;
        u32 _v_69 = 0;
        u32 _v_70 = 0;
        Term _o_11[5];
        if (spin_2(e, _o_11, 64ull, _negative_0, U32_BIN(_high_1, +, 1048576ull), _low_1, U32_BIN(_exponent_0, -, 1ull)) == 0) {
          return 0;
        }
        _v_66 = _o_11[0];
        _v_67 = _o_11[1];
        _v_68 = _o_11[2];
        _v_69 = _o_11[3];
        _v_70 = _o_11[4];
        _v_49 = _v_66;
        _v_50 = _v_67;
        _v_51 = _v_68;
        _v_52 = _v_69;
        _v_53 = _v_70;
      }
    }
  break;
  }
  o[0] = _v_49;
  o[1] = _v_50;
  o[2] = _v_51;
  o[3] = _v_52;
  o[4] = _v_53;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_39 = 0;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _high_0 = r0;
  u32 _low_0 = r1;
  WL_SPIN
    Term _a_16 = 1048576ull;
    Term _a_17 = ((u32)(_a_16) == 0 ? 0 : (u64)U32_QUO((u32)(_high_0), (u32)(_a_16)));
    Term _a_18 = 2048ull;
    Term _a_19 = 1048576ull;
    Term _a_20 = 1048576ull;
    Term _a_21 = ((u32)(_a_20) == 0 ? 0 : (u64)U32_QUO((u32)(_high_0), (u32)(_a_20)));
    Term _a_22 = 2048ull;
    Term _a_23 = 1048576ull;
    Term _a_24 = ((u32)(_a_23) == 0 ? 0 : (u64)U32_QUO((u32)(_high_0), (u32)(_a_23)));
    Term _a_25 = 2048ull;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    u32 _v_48 = 0;
    Term _o_12[5];
    if (spin_15(e, _o_12, U32_BIN(_high_0, >=, 2147483648ull), ((u32)(_a_18) == 0 ? _a_17 : U32_BIN(_a_17, -, U32_QUO((u32)(_a_17), (u32)(_a_18)) * _a_18)), ((u32)(_a_19) == 0 ? _high_0 : U32_BIN(_high_0, -, U32_QUO((u32)(_high_0), (u32)(_a_19)) * _a_19)), _low_0, U32_BIN(((u32)(_a_22) == 0 ? _a_21 : U32_BIN(_a_21, -, U32_QUO((u32)(_a_21), (u32)(_a_22)) * _a_22)), ==, 2047ull), U32_BIN(((u32)(_a_25) == 0 ? _a_24 : U32_BIN(_a_24, -, U32_QUO((u32)(_a_24), (u32)(_a_25)) * _a_25)), ==, 0ull)) == 0) {
      return 0;
    }
    _v_44 = _o_12[0];
    _v_45 = _o_12[1];
    _v_46 = _o_12[2];
    _v_47 = _o_12[3];
    _v_48 = _o_12[4];
    _v_39 = _v_44;
    _v_40 = _v_45;
    _v_41 = _v_46;
    _v_42 = _v_47;
    _v_43 = _v_48;
  break;
  }
  o[0] = _v_39;
  o[1] = _v_40;
  o[2] = _v_41;
  o[3] = _v_42;
  o[4] = _v_43;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  u32 _a_5 = r0;
  u32 _b_5 = r1;
  WL_SPIN
    if (_a_5 == 1) {
      if (_b_5 == 1) {
        _v_4 = 1;
      } else {
        _v_4 = 0;
      }
    } else {
      if (_b_5 == 0) {
        _v_4 = 1;
      } else {
        _v_4 = 0;
      }
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _result_5 = r0;
  u32 _result_6 = r1;
  u32 _result_7 = r2;
  u32 _result_8 = r3;
  u32 _result_9 = r4;
  WL_SPIN
    if (_result_5 == 0) {
      u32 _v_3 = 0;
      u32 _v_4 = 0;
      Term _o_0[1];
      if (spin_0(e, _o_0, U32_BIN(_result_7, ==, 0ull), U32_BIN(_result_8, ==, 0ull)) == 0) {
        return 0;
      }
      _v_4 = _o_0[0];
      _v_3 = _v_4;
      u32 _v_5 = 0;
      u32 _v_6 = 0;
      Term _o_1[1];
      if (spin_0(e, _o_1, U32_BIN(_result_9, >=, 1074ull), U32_BIN(_result_9, <=, 1126ull)) == 0) {
        return 0;
      }
      _v_6 = _o_1[0];
      _v_5 = _v_6;
      _v_2 = ((_v_3) | (_v_5));
    } else {
      _v_2 = 0;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _p_0 = r0;
  Term _p_1 = r1;
  WL_SPIN
    term_sink(e, _p_0);
    _v_1 = _p_1;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _raw_0 = r0;
  WL_SPIN
    if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER) {
      u32 _value_0 = term_loc(_raw_0);
      u32 _v_15 = 0;
      u32 _v_16 = 0;
      u32 _v_17 = 0;
      u32 _v_18 = 0;
      u32 _v_19 = 0;
      Term _o_0[5];
      if (spin_2(e, _o_0, 64ull, 0, 0ull, _value_0, 1074ull) == 0) {
        return 0;
      }
      _v_15 = _o_0[0];
      _v_16 = _o_0[1];
      _v_17 = _o_0[2];
      _v_18 = _o_0[3];
      _v_19 = _o_0[4];
      _v_10 = _v_15;
      _v_11 = _v_16;
      _v_12 = _v_17;
      _v_13 = _v_18;
      _v_14 = _v_19;
    } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_SIGNEDINTEGER) {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _raw_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _v_20 = 0;
      Term _v_21 = 0;
      Term _o_1[1];
      if (spin_10(e, _o_1, _f_1, nat_mul(e, ((u64)65536ull), ((u64)65536ull))) == 0) {
        return 0;
      }
      _v_21 = _o_1[0];
      _v_20 = _v_21;
      Term _v_22 = 0;
      Term _v_23 = 0;
      Term _o_2[1];
      if (spin_12(e, _o_2, _f_1, nat_mul(e, ((u64)65536ull), ((u64)65536ull))) == 0) {
        return 0;
      }
      _v_23 = _o_2[0];
      _v_22 = _v_23;
      u32 _v_24 = 0;
      u32 _v_25 = 0;
      u32 _v_26 = 0;
      u32 _v_27 = 0;
      u32 _v_28 = 0;
      Term _o_3[5];
      if (spin_2(e, _o_3, 64ull, _f_0, ((u64)(u32)(_v_20)), ((u64)(u32)(_v_22)), 1074ull) == 0) {
        return 0;
      }
      _v_24 = _o_3[0];
      _v_25 = _o_3[1];
      _v_26 = _o_3[2];
      _v_27 = _o_3[3];
      _v_28 = _o_3[4];
      _v_10 = _v_24;
      _v_11 = _v_25;
      _v_12 = _v_26;
      _v_13 = _v_27;
      _v_14 = _v_28;
      spare_free(e, cls_fit(2), _sp_0);
    } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FLOAT) {
      u32 _value_1 = term_loc(_raw_0);
      u32 _v_29 = 0;
      u32 _v_30 = 0;
      u32 _v_31 = 0;
      u32 _v_32 = 0;
      u32 _v_33 = 0;
      Term _o_4[5];
      if (spin_13(e, _o_4, _value_1) == 0) {
        return 0;
      }
      _v_29 = _o_4[0];
      _v_30 = _o_4[1];
      _v_31 = _o_4[2];
      _v_32 = _o_4[3];
      _v_33 = _o_4[4];
      _v_10 = _v_29;
      _v_11 = _v_30;
      _v_12 = _v_31;
      _v_13 = _v_32;
      _v_14 = _v_33;
    } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BINARY64) {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _raw_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      u32 _v_34 = 0;
      u32 _v_35 = 0;
      u32 _v_36 = 0;
      u32 _v_37 = 0;
      u32 _v_38 = 0;
      Term _o_5[5];
      if (spin_14(e, _o_5, _f_2, _f_3) == 0) {
        return 0;
      }
      _v_34 = _o_5[0];
      _v_35 = _o_5[1];
      _v_36 = _o_5[2];
      _v_37 = _o_5[3];
      _v_38 = _o_5[4];
      _v_10 = _v_34;
      _v_11 = _v_35;
      _v_12 = _v_36;
      _v_13 = _v_37;
      _v_14 = _v_38;
      spare_free(e, cls_fit(2), _sp_1);
    } else {
      term_sink(e, _raw_0);
      _v_10 = 2;
      _v_11 = 0;
      _v_12 = 0;
      _v_13 = 0;
      _v_14 = 0;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, u32 r9) {
  u32 wpoll = 0;
  u32 _v_40 = 0;
  u32 _a_1 = r0;
  u32 _a_2 = r1;
  u32 _a_3 = r2;
  u32 _a_4 = r3;
  u32 _a_5 = r4;
  u32 _b_1 = r5;
  u32 _b_2 = r6;
  u32 _b_3 = r7;
  u32 _b_4 = r8;
  u32 _b_5 = r9;
  WL_SPIN
    if (_a_1 == 0) {
      if (_b_1 == 0) {
        u32 _v_41 = 0;
        u32 _v_42 = 0;
        u32 _v_43 = 0;
        u32 _v_44 = 0;
        Term _o_7[1];
        if (spin_16(e, _o_7, _a_2, _b_2) == 0) {
          return 0;
        }
        _v_44 = _o_7[0];
        _v_43 = _v_44;
        u32 _v_45 = 0;
        Term _o_8[1];
        if (spin_0(e, _o_8, _v_43, U32_BIN(_a_3, ==, _b_3)) == 0) {
          return 0;
        }
        _v_45 = _o_8[0];
        _v_42 = _v_45;
        u32 _v_46 = 0;
        Term _o_9[1];
        if (spin_0(e, _o_9, _v_42, U32_BIN(_a_4, ==, _b_4)) == 0) {
          return 0;
        }
        _v_46 = _o_9[0];
        _v_41 = _v_46;
        u32 _v_47 = 0;
        Term _o_10[1];
        if (spin_0(e, _o_10, _v_41, U32_BIN(_a_5, ==, _b_5)) == 0) {
          return 0;
        }
        _v_47 = _o_10[0];
        _v_40 = _v_47;
      } else {
        _v_40 = 0;
      }
    } else if (_a_1 == 1) {
      if (_b_1 == 1) {
        u32 _v_48 = 0;
        Term _o_11[1];
        if (spin_16(e, _o_11, _a_2, _b_2) == 0) {
          return 0;
        }
        _v_48 = _o_11[0];
        _v_40 = _v_48;
      } else {
        _v_40 = 0;
      }
    } else if (_a_1 == 3) {
      if (_b_1 == 3) {
        _v_40 = 1;
      } else {
        _v_40 = 0;
      }
    } else {
      _v_40 = 0;
    }
  break;
  }
  o[0] = _v_40;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_12 = 0;
  u32 _high_1 = r0;
  WL_SPIN
    Term _a_0 = 1048576ull;
    Term _a_1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_high_1), (u32)(_a_0)));
    Term _a_2 = 2048ull;
    _v_12 = ((u32)(_a_2) == 0 ? _a_1 : U32_BIN(_a_1, -, U32_QUO((u32)(_a_1), (u32)(_a_2)) * _a_2));
  break;
  }
  o[0] = _v_12;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  u32 _v_14 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  u32 _small_0 = r5;
  WL_SPIN
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    Term _o_2[1];
    if (spin_17(e, _o_2, _result_0, _result_1, _result_2, _result_3, _result_4) == 0) {
      return 0;
    }
    _v_16 = _o_2[0];
    _v_15 = _v_16;
    u32 _v_17 = 0;
    Term _o_3[1];
    if (spin_0(e, _o_3, _small_0, _v_15) == 0) {
      return 0;
    }
    _v_17 = _o_3[0];
    _v_14 = _v_17;
  break;
  }
  o[0] = _v_14;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_1 = 0;
  u32 _c_0 = r0;
  WL_SPIN
    if (_c_0 == 1) {
      _v_1 = 1;
    } else {
      _v_1 = 0;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  u32 _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _valid_0 = r0;
  Term _path_1 = r1;
  Term _expected_0 = r2;
  Term _raw_1 = r3;
  Term _rest_1 = r4;
  WL_SPIN
    if (_valid_0 == 1) {
      term_sink(e, _path_1);
      term_sink(e, _expected_0);
      term_sink(e, _raw_1);
      _v_7 = 0;
      _v_8 = _rest_1;
      _v_9 = 0;
      _v_10 = 0;
      _v_11 = 0;
    } else {
      term_sink(e, _rest_1);
      _v_7 = 1;
      _v_8 = 0;
      _v_9 = _path_1;
      _v_10 = _expected_0;
      _v_11 = _raw_1;
    }
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_21 = 0;
  u32 _high_0 = r0;
  u32 _low_0 = r1;
  WL_SPIN
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_4[5];
    if (spin_14(e, _o_4, _high_0, _low_0) == 0) {
      return 0;
    }
    _v_27 = _o_4[0];
    _v_28 = _o_4[1];
    _v_29 = _o_4[2];
    _v_30 = _o_4[3];
    _v_31 = _o_4[4];
    _v_22 = _v_27;
    _v_23 = _v_28;
    _v_24 = _v_29;
    _v_25 = _v_30;
    _v_26 = _v_31;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _o_5[1];
    if (spin_21(e, _o_5, _high_0) == 0) {
      return 0;
    }
    _v_33 = _o_5[0];
    _v_32 = _v_33;
    u32 _v_34 = 0;
    Term _o_6[1];
    if (spin_22(e, _o_6, _v_22, _v_23, _v_24, _v_25, _v_26, U32_BIN(_v_32, <, 1076ull)) == 0) {
      return 0;
    }
    _v_34 = _o_6[0];
    _v_21 = _v_34;
  break;
  }
  o[0] = _v_21;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _head_0 = r0;
  Term _tail_0 = r1;
  WL_SPIN
    if (term_aux(_tail_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY) {
      Term _fb_4[1];
      u64 _sp_4 = ctr_take(e, _tail_0, 1, _fb_4);
      Term _f_7 = _fb_4[0];
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _head_0);
      e.mem[_nd_2 + 1] = rfc_seal(e, _f_7);
      u64 _nd_3 = _sp_4 >= HEAP_OFF ? _sp_4 : heap_alloc(e, cls_fit(1));
      e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
      _v_1 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY, _nd_3);
    } else {
      term_sink(e, _head_0);
      _v_1 = _tail_0;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_3 = 0;
  Term _name_0 = r0;
  Term _head_1 = r1;
  Term _tail_1 = r2;
  WL_SPIN
    if (term_aux(_tail_1) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT) {
      Term _fb_10[1];
      u64 _sp_10 = ctr_take(e, _tail_1, 1, _fb_10);
      Term _f_23 = _fb_10[0];
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, _name_0);
      e.mem[_nd_6 + 1] = rfc_seal(e, _head_1);
      u64 _nd_7 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD, _nd_6));
      e.mem[_nd_7 + 1] = rfc_seal(e, _f_23);
      u64 _nd_8 = _sp_10 >= HEAP_OFF ? _sp_10 : heap_alloc(e, cls_fit(1));
      e.mem[_nd_8 + 0] = rfc_seal(e, term_ctr(CID_CON, _nd_7));
      _v_3 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT, _nd_8);
    } else {
      term_sink(e, _name_0);
      term_sink(e, _head_1);
      _v_3 = _tail_1;
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term _v_3 = 0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _wire_2 = r0;
  u32 _fail_2 = r1;
  Term _owner_0 = r2;
  u32 _owner_1 = r3;
  WL_SPIN
    _v_3 = _owner_0;
    _v_4 = _wire_2;
    _v_5 = _fail_2;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_2 = 1;
    } else {
      _v_2 = 0;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  u32 _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  u32 _allowed_0 = r0;
  Term _wire_0 = r1;
  u32 _fail_0 = r2;
  Term _owned_0 = r3;
  u32 _number_1 = r4;
  WL_SPIN
    if (_allowed_0 == 1) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _wire_0;
      e.mem[_nd_0 + 1] = _fail_0;
      _v_7 = 0;
      _v_8 = _owned_0;
      _v_9 = _number_1;
      _v_10 = term_clo(FID_BUILT_C115, _nd_0);
    } else {
      _v_7 = 1;
      _v_8 = _owned_0;
      _v_9 = _wire_0;
      _v_10 = _fail_0;
    }
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_8 = 0;
  Term _v_9 = 0;
  u32 _v_10 = 0;
  Term _v_11 = 0;
  Term _owner_3 = r0;
  Term _owner_4 = r1;
  u32 _owner_5 = r2;
  WL_SPIN
    _owner_4 = term_keep(e, _owner_4, 1);
    _v_8 = _owner_3;
    _v_9 = _owner_4;
    _v_10 = _owner_5;
    _v_11 = _owner_4;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h3 = r3;
  u32 _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _owner_0 = r0;
  Term _owner_1 = r1;
  u32 _owner_2 = r2;
  Term _canonical_0 = r3;
  WL_SPIN
    if (term_aux(_canonical_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER) {
      u32 _number_0 = term_loc(_canonical_0);
      u32 _v_12 = 0;
      u32 _v_13 = 0;
      Term _o_0[1];
      if (spin_29(e, _o_0, _owner_2) == 0) {
        return 0;
      }
      _v_13 = _o_0[0];
      _v_12 = _v_13;
      u32 _v_14 = 0;
      Term _v_15 = 0;
      Term _v_16 = 0;
      Term _v_17 = 0;
      Term _o_1[4];
      if (spin_30(e, _o_1, _v_12, _owner_1, _owner_1 == h1 ? q1 : blk_loc(e.mem, _owner_1), _owner_2, _owner_0, _owner_0 == h0 ? q0 : blk_loc(e.mem, _owner_0), _number_0) == 0) {
        return 0;
      }
      _v_14 = _o_1[0];
      _v_15 = _o_1[1];
      _v_16 = _o_1[2];
      _v_17 = _o_1[3];
      _v_8 = _v_14;
      _v_9 = _v_15;
      _v_10 = _v_16;
      _v_11 = _v_17;
    } else {
      term_sink(e, _canonical_0);
      _v_8 = 1;
      _v_9 = _owner_0;
      _v_10 = _owner_1;
      _v_11 = _owner_2;
    }
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  u32 _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _result_0 = r0;
  Term _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  WL_SPIN
    if (_result_0 == 1) {
      _v_27 = 1;
      _v_28 = _result_1;
      _v_29 = _result_2;
      _v_30 = _result_3;
      _v_31 = 1;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
    } else {
      _v_27 = 0;
      _v_28 = _result_1;
      _v_29 = _result_2;
      _v_30 = _result_3;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
      _v_34 = 0;
      _v_35 = 0;
    }
  break;
  }
  o[0] = _v_27;
  o[1] = _v_28;
  o[2] = _v_29;
  o[3] = _v_30;
  o[4] = _v_31;
  o[5] = _v_32;
  o[6] = _v_33;
  o[7] = _v_34;
  o[8] = _v_35;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _receipt_0 = r0;
  Term _receipt_1 = r1;
  u32 _receipt_2 = r2;
  u32 _receipt_3 = r3;
  Term _receipt_4 = r4;
  Term _receipt_5 = r5;
  Term _receipt_6 = r6;
  Term _receipt_7 = r7;
  WL_SPIN
    if (_receipt_3 == 1) {
      _v_9 = 1;
      _v_10 = _receipt_0;
      _v_11 = _receipt_1;
      _v_12 = _receipt_2;
      _v_13 = 0;
      _v_14 = _receipt_4;
      _v_15 = _receipt_5;
      _v_16 = _receipt_6;
      _v_17 = _receipt_7;
    } else {
      u32 _v_18 = 0;
      Term _v_19 = 0;
      Term _v_20 = 0;
      Term _v_21 = 0;
      u32 _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _o_0[4];
      if (spin_32(e, _o_0, _receipt_0, _receipt_0 == h0 ? q0 : blk_loc(e.mem, _receipt_0), _receipt_1, _receipt_1 == h1 ? q1 : blk_loc(e.mem, _receipt_1), _receipt_2, _receipt_4, _receipt_4 == h4 ? q4 : blk_loc(e.mem, _receipt_4)) == 0) {
        return 0;
      }
      _v_22 = _o_0[0];
      _v_23 = _o_0[1];
      _v_24 = _o_0[2];
      _v_25 = _o_0[3];
      _v_18 = _v_22;
      _v_19 = _v_23;
      _v_20 = _v_24;
      _v_21 = _v_25;
      u32 _v_26 = 0;
      Term _v_27 = 0;
      Term _v_28 = 0;
      Term _v_29 = 0;
      u32 _v_30 = 0;
      u32 _v_31 = 0;
      Term _v_32 = 0;
      Term _v_33 = 0;
      Term _v_34 = 0;
      Term _o_1[9];
      if (spin_33(e, _o_1, _v_18, _v_19, _v_19 == h7 ? q7 : _v_19 == h6 ? q6 : _v_19 == h5 ? q5 : _v_19 == h4 ? q4 : _v_19 == h1 ? q1 : _v_19 == h0 ? q0 : blk_loc(e.mem, _v_19), _v_20, _v_20 == h7 ? q7 : _v_20 == h6 ? q6 : _v_20 == h5 ? q5 : _v_20 == h4 ? q4 : _v_20 == h1 ? q1 : _v_20 == h0 ? q0 : blk_loc(e.mem, _v_20), _v_21, _v_21 == h7 ? q7 : _v_21 == h6 ? q6 : _v_21 == h5 ? q5 : _v_21 == h4 ? q4 : _v_21 == h1 ? q1 : _v_21 == h0 ? q0 : blk_loc(e.mem, _v_21)) == 0) {
        return 0;
      }
      _v_26 = _o_1[0];
      _v_27 = _o_1[1];
      _v_28 = _o_1[2];
      _v_29 = _o_1[3];
      _v_30 = _o_1[4];
      _v_31 = _o_1[5];
      _v_32 = _o_1[6];
      _v_33 = _o_1[7];
      _v_34 = _o_1[8];
      _v_9 = _v_26;
      _v_10 = _v_27;
      _v_11 = _v_28;
      _v_12 = _v_29;
      _v_13 = _v_30;
      _v_14 = _v_31;
      _v_15 = _v_32;
      _v_16 = _v_33;
      _v_17 = _v_34;
    }
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _factory_0 = r0;
  Term _factory_1 = r1;
  Term _rest_2 = r2;
  Term _rest_3 = r3;
  WL_SPIN
    _v_8 = _factory_0;
    _v_9 = _factory_1;
    _v_10 = _rest_2;
    _v_11 = _rest_3;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _rest_0 = r0;
  Term _rest_1 = r1;
  Term _observed_6 = r2;
  Term _observed_7 = r3;
  u32 _observed_8 = r4;
  Term _observed_9 = r5;
  Term _observed_10 = r6;
  Term _observed_11 = r7;
  u32 _observed_12 = r8;
  u32 _observed_13 = r9;
  Term _observed_14 = r10;
  Term _observed_15 = r11;
  Term _observed_16 = r12;
  WL_SPIN
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _o_0[4];
    if (spin_35(e, _o_0, _observed_6, _observed_6 == h2 ? q2 : blk_loc(e.mem, _observed_6), _observed_7, _observed_7 == h3 ? q3 : blk_loc(e.mem, _observed_7), _rest_0, _rest_0 == h0 ? q0 : blk_loc(e.mem, _rest_0), _rest_1, _rest_1 == h1 ? q1 : blk_loc(e.mem, _rest_1)) == 0) {
      return 0;
    }
    _v_30 = _o_0[0];
    _v_31 = _o_0[1];
    _v_32 = _o_0[2];
    _v_33 = _o_0[3];
    _v_26 = _v_30;
    _v_27 = _v_31;
    _v_28 = _v_32;
    _v_29 = _v_33;
    _v_13 = _v_26;
    _v_14 = _v_27;
    _v_15 = _v_28;
    _v_16 = _v_29;
    _v_17 = _observed_8;
    _v_18 = _observed_9;
    _v_19 = _observed_10;
    _v_20 = _observed_11;
    _v_21 = _observed_12;
    _v_22 = _observed_13;
    _v_23 = _observed_14;
    _v_24 = _observed_15;
    _v_25 = _observed_16;
  break;
  }
  o[0] = _v_13;
  o[1] = _v_14;
  o[2] = _v_15;
  o[3] = _v_16;
  o[4] = _v_17;
  o[5] = _v_18;
  o[6] = _v_19;
  o[7] = _v_20;
  o[8] = _v_21;
  o[9] = _v_22;
  o[10] = _v_23;
  o[11] = _v_24;
  o[12] = _v_25;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _context_0 = r0;
  Term _context_1 = r1;
  Term _context_2 = r2;
  Term _context_3 = r3;
  WL_SPIN
    _v_8 = _context_0;
    _v_9 = _context_1;
    _v_10 = _context_2;
    _v_11 = _context_3;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 249);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 255);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_6 = 0;
  Term _v_7 = 0;
  u32 _v_8 = 0;
  Term _owner_0 = r0;
  Term _owner_1 = r1;
  u32 _owner_2 = r2;
  WL_SPIN
    term_sink(e, _owner_1);
    _v_6 = _owner_0;
    _v_7 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER, 9ull);
    _v_8 = 0;
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _value_0 = r0;
  WL_SPIN
    if (term_aux(_value_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FINITENUMBER) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 379);
    } else if (term_aux(_value_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_INTEGER) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 381);
    } else if (term_aux(_value_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRINGVALUE) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 399);
    } else if (term_aux(_value_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BOOLVALUE) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 407);
    } else {
      term_sink(e, _value_0);
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 439);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_6 = 0;
  Term _declaration_0 = r0;
  WL_SPIN
    _v_6 = _declaration_0;
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_10 = 0;
  Term _declaration_1 = r0;
  WL_SPIN
    _v_10 = _declaration_1;
  break;
  }
  o[0] = _v_10;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _result_0 = r0;
  Term _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  u32 _result_9 = r9;
  Term _result_10 = r10;
  Term _result_11 = r11;
  WL_SPIN
    if (_result_0 == 0) {
      term_sink(e, _result_11);
      _v_12 = 0;
      _v_13 = _result_1;
      _v_14 = _result_2;
      _v_15 = _result_3;
      _v_16 = _result_4;
      _v_17 = _result_5;
      _v_18 = _result_6;
      _v_19 = _result_7;
      _v_20 = _result_8;
      _v_21 = _result_9;
      _v_22 = _result_10;
      _v_23 = term_pak(CID_NIL, 0);
    } else {
      term_sink(e, _result_11);
      _v_12 = 1;
      _v_13 = _result_1;
      _v_14 = _result_2;
      _v_15 = _result_3;
      _v_16 = _result_4;
      _v_17 = _result_5;
      _v_18 = _result_6;
      _v_19 = _result_7;
      _v_20 = _result_8;
      _v_21 = _result_9;
      _v_22 = _result_10;
      _v_23 = term_pak(CID_NIL, 0);
    }
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  o[6] = _v_18;
  o[7] = _v_19;
  o[8] = _v_20;
  o[9] = _v_21;
  o[10] = _v_22;
  o[11] = _v_23;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, u32 r4, u32 r5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h3 = r3;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _raw_58 = r0;
  Term _raw_59 = r1;
  u32 _raw_60 = r2;
  Term _raw_61 = r3;
  u32 _raw_62 = r4;
  u32 _raw_63 = r5;
  WL_SPIN
    Term _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    Term _o_0[3];
    if (spin_40(e, _o_0, _raw_58, _raw_58 == h0 ? q0 : blk_loc(e.mem, _raw_58), _raw_59, _raw_59 == h1 ? q1 : blk_loc(e.mem, _raw_59), _raw_60) == 0) {
      return 0;
    }
    _v_21 = _o_0[0];
    _v_22 = _o_0[1];
    _v_23 = _o_0[2];
    _v_18 = _v_21;
    _v_19 = _v_22;
    _v_20 = _v_23;
    _v_12 = _v_18;
    _v_13 = _v_19;
    _v_14 = _v_20;
    _v_15 = _raw_61;
    _v_16 = _raw_62;
    _v_17 = _raw_63;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL)
  {
    Term _left_0 = r0;
    Term _right_0 = r1;
    WL_OPEN
    if (term_aux(_left_0) == CID_NIL) {
      u32 _v_0 = 0;
      Term _o_0[1];
      if (spin_5(e, _o_0, _right_0, blk_loc(e.mem, _right_0)) == 0) {
        return 0;
      }
      _v_0 = _o_0[0];
      r0 = _v_0;
      WL_RETN(1);
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _left_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u64 _nd_0 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_0 + 0] = _f_3;
      if (term_aux(_right_0) == CID_NIL) {
        Term _next_0 = term_clo(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_C12, _nd_0);
        term_sink(e, _next_0);
        spare_free(e, cls_fit(2), _sp_1);
        r0 = 0;
        WL_RETN(1);
      } else {
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _right_0, 2, _fb_2);
        Term _f_5 = _fb_2[0];
        Term _f_6 = _fb_2[1];
        Term _next_1 = term_clo(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_C12, _nd_0);
        spare_free(e, cls_fit(2), _sp_2);
        spare_free(e, cls_fit(2), _sp_1);
        if (seq) {
          WL_ROOM(3);
          STK(0) = _f_2;
          STK(1) = _f_5;
          STK(2) = FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K14;
          WL_PUSHN(3);
        } else {
          u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K14, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _f_2;
          e.mem[_t_2 + 1] = _f_5;
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K14, _t_2);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _next_1;
          e.mem[_t_3 + 1] = _f_6;
          return term_tsk(FID_CLO_APPLY, _t_3);
        }
        r0 = _next_1;
        r1 = _f_6;
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_C12)
  {
    Term _f_4 = r0;
    Term _x_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K13;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K13, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K13, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL)) {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_4;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL, _t_1);
    }
    r0 = _f_4;
    r1 = _x_0;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K13)
  {
    u32 _r_0 = r0;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      _b_0 = term_pak(CID_FALSE, 0);
    } else {
      _b_0 = term_pak(CID_TRUE, 0);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL_K14)
  {
    WL_POPN(2);
    u32 _f_7 = STK(0);
    u32 _f_8 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    u32 _o_1 = 0;
    if (term_aux(_h_0) == CID_FALSE) {
      _o_1 = 0;
    } else {
      _o_1 = 1;
    }
    u32 _v_2 = 0;
    Term _o_2[1];
    if (spin_0(e, _o_2, U32_BIN(_f_7, ==, _f_8), _o_1) == 0) {
      return 0;
    }
    _v_2 = _o_2[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_CMP)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      if (term_aux(_b_0) == CID_SNIL) {
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 1;
        WL_RETN(3);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _b_0, 2, _fb_0);
        u32 _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
        e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_ctr(CID_SCON, _nd_0);
        r2 = 0;
        WL_RETN(3);
      }
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _a_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      if (term_aux(_b_0) == CID_SNIL) {
        u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
        e.mem[_nd_1 + 1] = rfc_seal(e, _f_3);
        r0 = term_ctr(CID_SCON, _nd_1);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 2;
        WL_RETN(3);
      } else {
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _b_0, 2, _fb_2);
        u32 _f_4 = _fb_2[0];
        Term _f_5 = _fb_2[1];
        u32 _v_0 = 0;
        u32 _v_1 = 0;
        u32 _v_2 = 0;
        u32 _v_3 = 0;
        u32 _v_4 = 0;
        u32 _v_5 = 0;
        Term _o_0[3];
        if (spin_8(e, _o_0, _f_2, _f_4) == 0) {
          return 0;
        }
        _v_3 = _o_0[0];
        _v_4 = _o_0[1];
        _v_5 = _o_0[2];
        _v_0 = _v_3;
        _v_1 = _v_4;
        _v_2 = _v_5;
        if (_v_2 == 0) {
          u64 _nd_2 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_2 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_2 + 1] = rfc_seal(e, _f_3);
          u64 _nd_3 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_3 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_2);
          r1 = term_ctr(CID_SCON, _nd_3);
          r2 = 0;
          WL_RETN(3);
        } else if (_v_2 == 1) {
          spare_free(e, cls_fit(2), _sp_2);
          spare_free(e, cls_fit(2), _sp_1);
          if (seq) {
            WL_ROOM(3);
            STK(0) = _v_0;
            STK(1) = _v_1;
            STK(2) = FID_STRING_CMP_K21;
            WL_PUSHN(3);
          } else {
            u64 _t_0 = task_node(e, FID_STRING_CMP_K21, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _v_0;
            e.mem[_t_0 + 1] = _v_1;
            WL_CONT = term_tsk(FID_STRING_CMP_K21, _t_0);
            WL_IDX = 2;
          }
          r0 = _f_3;
          r1 = _f_5;
          _a_0 = r0;
          _b_0 = r1;
          WL_AGAIN(FID_STRING_CMP);
        } else {
          u64 _nd_4 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_4 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_4 + 1] = rfc_seal(e, _f_3);
          u64 _nd_5 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_5 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_5 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_4);
          r1 = term_ctr(CID_SCON, _nd_5);
          r2 = 2;
          WL_RETN(3);
        }
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_CMP_K21)
  {
    WL_POPN(2);
    u32 _v_9 = STK(0);
    u32 _v_10 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    Term _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _o_1[3];
    if (spin_4(e, _o_1, _v_9, _v_10, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_12 = _o_1[1];
    _v_13 = _o_1[2];
    r0 = _v_11;
    r1 = _v_12;
    r2 = _v_13;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT)
  {
    Term _value_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_value_0) == CID_SNIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _value_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT_K25;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT_K25, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT_K25, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _value_0 = r0;
      WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT_K25)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_9(e, _o_0, _f_2, _h_0, blk_loc(e.mem, _h_0), U32_BIN(_f_2, <, 65536ull)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED)
  {
    Term _left_0 = r0;
    Term _right_0 = r1;
    WL_OPEN
    _left_0 = term_keep(e, _left_0, 1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _left_0;
      STK(1) = _right_0;
      STK(2) = FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K27;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K27, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _left_0;
      e.mem[_t_0 + 1] = _right_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K27, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID)) {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _left_0;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID, _t_1);
    }
    r0 = _left_0;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K27)
  {
    WL_POPN(2);
    Term _left_1 = STK(0);
    Term _right_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    _right_1 = term_keep(e, _right_1, 1);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _left_1;
      STK(1) = _right_1;
      STK(2) = _h_0;
      STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K28;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K28, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _left_1;
      e.mem[_t_2 + 1] = _right_1;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K28, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID)) {
      u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _right_1;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID, _t_3);
    }
    r0 = _right_1;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K28)
  {
    WL_POPN(3);
    Term _left_2 = STK(0);
    Term _right_2 = STK(1);
    u32 _h_2 = STK(2);
    u32 _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K29;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K29, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K29, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL)) {
      u64 _t_5 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _left_2;
      e.mem[_t_5 + 1] = _right_2;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL, _t_5);
    }
    r0 = _left_2;
    r1 = _right_2;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_EQUAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED_K29)
  {
    WL_POPN(2);
    u32 _h_4 = STK(0);
    u32 _h_5 = STK(1);
    u32 _h_3 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_0(e, _o_0, _h_4, _h_5) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u32 _v_2 = 0;
    Term _o_1[1];
    if (spin_0(e, _o_1, _v_0, _h_3) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_ORDER_K36;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_ORDER_K36, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_ORDER_K36, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_CMP)) {
      u64 _t_1 = task_node(e, FID_STRING_CMP, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_CMP, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_CMP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER_K36)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_0;
    e.mem[_nd_0 + 1] = _h_1;
    Term _b_1 = 0;
    if (_h_2 == 0) {
      _b_1 = term_pak(CID_LT, 0);
    } else if (_h_2 == 1) {
      _b_1 = term_pak(CID_EQ, 0);
    } else {
      _b_1 = term_pak(CID_GT, 0);
    }
    Term _v_0 = 0;
    Term _o_0[1];
    Term _a_1 = term_ctr(CID_TUPLE, _nd_0);
    if (spin_18(e, _o_0, _a_1, blk_loc(e.mem, _a_1), _b_1, blk_loc(e.mem, _b_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    u32 _o_1 = 0;
    if (term_aux(_v_0) == CID_LT) {
      _o_1 = 0;
    } else if (term_aux(_v_0) == CID_EQ) {
      _o_1 = 1;
    } else {
      _o_1 = 2;
    }
    r0 = _o_1;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK)
  {
    Term _fields_0 = r0;
    Term _values_0 = r1;
    Term _path_0 = r2;
    Term _rest_0 = r3;
    WL_OPEN
    if (term_aux(_fields_0) == CID_NIL) {
      term_sink(e, _values_0);
      term_sink(e, _path_0);
      r0 = _rest_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _fields_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      _f_2 = term_keep(e, _f_2, 1);
      _values_0 = term_keep(e, _values_0, 1);
      spare_free(e, cls_fit(2), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(7);
        STK(0) = _f_2;
        STK(1) = _f_3;
        STK(2) = _f_1;
        STK(3) = _values_0;
        STK(4) = _path_0;
        STK(5) = _rest_0;
        STK(6) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K39;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K39, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_2;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _f_1;
        e.mem[_t_0 + 3] = _values_0;
        e.mem[_t_0 + 4] = _path_0;
        e.mem[_t_0 + 5] = _rest_0;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K39, _t_0);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD)) {
        u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _values_0;
        return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD, _t_1);
      }
      r0 = _f_2;
      r1 = _values_0;
      WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K39)
  {
    WL_POPN(6);
    Term _f_4 = STK(0);
    Term _f_5 = STK(1);
    Term _f_6 = STK(2);
    Term _values_1 = STK(3);
    Term _path_1 = STK(4);
    Term _rest_1 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _f_5;
      STK(1) = _f_6;
      STK(2) = _values_1;
      STK(3) = _path_1;
      STK(4) = _rest_1;
      STK(5) = _h_0;
      STK(6) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K40;
      WL_PUSHN(7);
    } else {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K40, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _f_6;
      e.mem[_t_2 + 2] = _values_1;
      e.mem[_t_2 + 3] = _path_1;
      e.mem[_t_2 + 4] = _rest_1;
      e.mem[_t_2 + 5] = _h_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K40, _t_2);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 0);
      e.mem[_t_3 + 1] = _f_4;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 0);
    r1 = _f_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K40)
  {
    WL_POPN(6);
    Term _f_7 = STK(0);
    Term _f_8 = STK(1);
    Term _values_2 = STK(2);
    Term _path_2 = STK(3);
    Term _rest_2 = STK(4);
    Term _h_2 = STK(5);
    Term _h_1 = r0;
    WL_OPEN
    _path_2 = term_keep(e, _path_2, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _f_7;
      STK(1) = _f_8;
      STK(2) = _values_2;
      STK(3) = _path_2;
      STK(4) = _rest_2;
      STK(5) = _h_2;
      STK(6) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K41;
      WL_PUSHN(7);
    } else {
      u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K41, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _f_7;
      e.mem[_t_4 + 1] = _f_8;
      e.mem[_t_4 + 2] = _values_2;
      e.mem[_t_4 + 3] = _path_2;
      e.mem[_t_4 + 4] = _rest_2;
      e.mem[_t_4 + 5] = _h_2;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K41, _t_4);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _path_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _path_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K41)
  {
    WL_POPN(6);
    Term _f_9 = STK(0);
    Term _f_10 = STK(1);
    Term _values_3 = STK(2);
    Term _path_3 = STK(3);
    Term _rest_3 = STK(4);
    Term _h_4 = STK(5);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _f_9;
      STK(1) = _h_4;
      STK(2) = _h_3;
      STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K42;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K42, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _f_9;
      e.mem[_t_6 + 1] = _h_4;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K42, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK)) {
      u64 _t_7 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _f_10;
      e.mem[_t_7 + 1] = _values_3;
      e.mem[_t_7 + 2] = _path_3;
      e.mem[_t_7 + 3] = _rest_3;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK, _t_7);
    }
    r0 = _f_10;
    r1 = _values_3;
    r2 = _path_3;
    r3 = _rest_3;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK_K42)
  {
    WL_POPN(3);
    Term _f_11 = STK(0);
    Term _h_6 = STK(1);
    Term _h_7 = STK(2);
    Term _h_5 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_11);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_6);
    e.mem[_nd_0 + 2] = rfc_seal(e, _h_7);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_WORK, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_5);
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK)
  {
    Term _codec_0 = r0;
    Term _items_0 = r1;
    Term _path_0 = r2;
    u32 _index_0 = r3;
    Term _rest_0 = r4;
    WL_OPEN
    if (term_aux(_items_0) == CID_NIL) {
      term_sink(e, _codec_0);
      term_sink(e, _path_0);
      r0 = _rest_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(7);
        STK(0) = _codec_0;
        STK(1) = _f_0;
        STK(2) = _f_1;
        STK(3) = _path_0;
        STK(4) = _index_0;
        STK(5) = _rest_0;
        STK(6) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K44;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K44, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _codec_0;
        e.mem[_t_0 + 1] = _f_0;
        e.mem[_t_0 + 2] = _f_1;
        e.mem[_t_0 + 3] = _path_0;
        e.mem[_t_0 + 4] = _index_0;
        e.mem[_t_0 + 5] = _rest_0;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K44, _t_0);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _index_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _index_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K44)
  {
    WL_POPN(6);
    Term _codec_1 = STK(0);
    Term _f_2 = STK(1);
    Term _f_3 = STK(2);
    Term _path_1 = STK(3);
    u32 _index_1 = STK(4);
    Term _rest_1 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _codec_1;
      STK(1) = _f_2;
      STK(2) = _f_3;
      STK(3) = _path_1;
      STK(4) = _index_1;
      STK(5) = _rest_1;
      STK(6) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K45;
      WL_PUSHN(7);
    } else {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K45, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _codec_1;
      e.mem[_t_2 + 1] = _f_2;
      e.mem[_t_2 + 2] = _f_3;
      e.mem[_t_2 + 3] = _path_1;
      e.mem[_t_2 + 4] = _index_1;
      e.mem[_t_2 + 5] = _rest_1;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K45, _t_2);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 2);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K45)
  {
    WL_POPN(6);
    Term _codec_2 = STK(0);
    Term _f_4 = STK(1);
    Term _f_5 = STK(2);
    Term _path_2 = STK(3);
    u32 _index_2 = STK(4);
    Term _rest_2 = STK(5);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _codec_2;
      STK(1) = _f_4;
      STK(2) = _f_5;
      STK(3) = _path_2;
      STK(4) = _index_2;
      STK(5) = _rest_2;
      STK(6) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K46;
      WL_PUSHN(7);
    } else {
      u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K46, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _codec_2;
      e.mem[_t_4 + 1] = _f_4;
      e.mem[_t_4 + 2] = _f_5;
      e.mem[_t_4 + 3] = _path_2;
      e.mem[_t_4 + 4] = _index_2;
      e.mem[_t_4 + 5] = _rest_2;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K46, _t_4);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K46)
  {
    WL_POPN(6);
    Term _codec_3 = STK(0);
    Term _f_6 = STK(1);
    Term _f_7 = STK(2);
    Term _path_3 = STK(3);
    u32 _index_3 = STK(4);
    Term _rest_3 = STK(5);
    Term _h_2 = r0;
    WL_OPEN
    _path_3 = term_keep(e, _path_3, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _codec_3;
      STK(1) = _f_6;
      STK(2) = _f_7;
      STK(3) = _path_3;
      STK(4) = _index_3;
      STK(5) = _rest_3;
      STK(6) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K47;
      WL_PUSHN(7);
    } else {
      u64 _t_6 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K47, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _codec_3;
      e.mem[_t_6 + 1] = _f_6;
      e.mem[_t_6 + 2] = _f_7;
      e.mem[_t_6 + 3] = _path_3;
      e.mem[_t_6 + 4] = _index_3;
      e.mem[_t_6 + 5] = _rest_3;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K47, _t_6);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _path_3;
      e.mem[_t_7 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _path_3;
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K47)
  {
    WL_POPN(6);
    Term _codec_4 = STK(0);
    Term _f_8 = STK(1);
    Term _f_9 = STK(2);
    Term _path_4 = STK(3);
    u32 _index_4 = STK(4);
    Term _rest_4 = STK(5);
    Term _h_3 = r0;
    WL_OPEN
    _codec_4 = term_keep(e, _codec_4, 1);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _codec_4;
      STK(1) = _f_8;
      STK(2) = _h_3;
      STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K48;
      WL_PUSHN(4);
    } else {
      u64 _t_8 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K48, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _codec_4;
      e.mem[_t_8 + 1] = _f_8;
      e.mem[_t_8 + 2] = _h_3;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K48, _t_8);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK)) {
      u64 _t_9 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _codec_4;
      e.mem[_t_9 + 1] = _f_9;
      e.mem[_t_9 + 2] = _path_4;
      e.mem[_t_9 + 3] = U32_BIN(_index_4, +, 1ull);
      e.mem[_t_9 + 4] = _rest_4;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK, _t_9);
    }
    r0 = _codec_4;
    r1 = _f_9;
    r2 = _path_4;
    r3 = U32_BIN(_index_4, +, 1ull);
    r4 = _rest_4;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK_K48)
  {
    WL_POPN(3);
    Term _codec_5 = STK(0);
    Term _f_10 = STK(1);
    Term _h_5 = STK(2);
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, _codec_5);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_10);
    e.mem[_nd_0 + 2] = rfc_seal(e, _h_5);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_WORK, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_4);
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES)
  {
    Term _values_0 = r0;
    Term _raw_0 = r1;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      term_sink(e, _raw_0);
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      _raw_0 = term_keep(e, _raw_0, 1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_1;
        STK(1) = _raw_0;
        STK(2) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K50;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K50, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _raw_0;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K50, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL)) {
        u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        e.mem[_t_1 + 1] = _raw_0;
        return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL, _t_1);
      }
      r0 = _f_0;
      r1 = _raw_0;
      WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K50)
  {
    WL_POPN(2);
    Term _f_2 = STK(0);
    Term _raw_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K51;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K51, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K51, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES)) {
      u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      e.mem[_t_3 + 1] = _raw_1;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES, _t_3);
    }
    r0 = _f_2;
    r1 = _raw_1;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES_K51)
  {
    WL_POPN(1);
    u32 _h_2 = STK(0);
    u32 _h_1 = r0;
    WL_OPEN
    r0 = ((_h_2) | (_h_1));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (term_aux(_a_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULL) {
      if (term_aux(_b_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULL) {
        r0 = 1;
        WL_RETN(1);
      } else {
        u32 _v_0 = 0;
        u32 _v_1 = 0;
        u32 _v_2 = 0;
        u32 _v_3 = 0;
        u32 _v_4 = 0;
        u32 _v_5 = 0;
        u32 _v_6 = 0;
        u32 _v_7 = 0;
        u32 _v_8 = 0;
        u32 _v_9 = 0;
        Term _o_6[5];
        if (spin_19(e, _o_6, _b_0, blk_loc(e.mem, _b_0)) == 0) {
          return 0;
        }
        _v_5 = _o_6[0];
        _v_6 = _o_6[1];
        _v_7 = _o_6[2];
        _v_8 = _o_6[3];
        _v_9 = _o_6[4];
        _v_0 = _v_5;
        _v_1 = _v_6;
        _v_2 = _v_7;
        _v_3 = _v_8;
        _v_4 = _v_9;
        u32 _v_39 = 0;
        Term _o_12[1];
        if (spin_20(e, _o_12, 2, 0, 0, 0, 0, _v_0, _v_1, _v_2, _v_3, _v_4) == 0) {
          return 0;
        }
        _v_39 = _o_12[0];
        r0 = _v_39;
        WL_RETN(1);
      }
    } else if (term_aux(_a_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT) {
      Term _fb_2[1];
      u64 _sp_2 = ctr_take(e, _a_0, 1, _fb_2);
      Term _f_4 = _fb_2[0];
      if (term_aux(_b_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT) {
        Term _fb_3[1];
        u64 _sp_3 = ctr_take(e, _b_0, 1, _fb_3);
        Term _f_5 = _fb_3[0];
        spare_free(e, cls_fit(1), _sp_3);
        spare_free(e, cls_fit(1), _sp_2);
        if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
          u64 _t_0 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
          e.mem[_t_0 + 0] = _f_4;
          e.mem[_t_0 + 1] = _f_5;
          return term_tsk(FID_STRING_EQ, _t_0);
        }
        r0 = _f_4;
        r1 = _f_5;
        WL_JMP(FID_STRING_EQ);
      } else if (term_aux(_b_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_UTF16TEXT) {
        Term _fb_4[1];
        u64 _sp_4 = ctr_take(e, _b_0, 1, _fb_4);
        Term _f_6 = _fb_4[0];
        spare_free(e, cls_fit(1), _sp_4);
        spare_free(e, cls_fit(1), _sp_2);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_6;
          STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K53;
          WL_PUSHN(2);
        } else {
          u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K53, WL_CONT, WL_IDX, 1);
          e.mem[_t_1 + 0] = _f_6;
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K53, _t_1);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT)) {
          u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT, WL_CONT, WL_IDX, 0);
          e.mem[_t_2 + 0] = _f_4;
          return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT, _t_2);
        }
        r0 = _f_4;
        WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT);
      } else {
        u32 _v_49 = 0;
        u32 _v_50 = 0;
        u32 _v_51 = 0;
        u32 _v_52 = 0;
        u32 _v_53 = 0;
        u64 _nd_0 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(1));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_4);
        u32 _v_54 = 0;
        u32 _v_55 = 0;
        u32 _v_56 = 0;
        u32 _v_57 = 0;
        u32 _v_58 = 0;
        Term _o_13[5];
        Term _a_6 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT, _nd_0);
        if (spin_19(e, _o_13, _a_6, blk_loc(e.mem, _a_6)) == 0) {
          return 0;
        }
        _v_54 = _o_13[0];
        _v_55 = _o_13[1];
        _v_56 = _o_13[2];
        _v_57 = _o_13[3];
        _v_58 = _o_13[4];
        _v_49 = _v_54;
        _v_50 = _v_55;
        _v_51 = _v_56;
        _v_52 = _v_57;
        _v_53 = _v_58;
        u32 _v_59 = 0;
        u32 _v_60 = 0;
        u32 _v_61 = 0;
        u32 _v_62 = 0;
        u32 _v_63 = 0;
        u32 _v_64 = 0;
        u32 _v_65 = 0;
        u32 _v_66 = 0;
        u32 _v_67 = 0;
        u32 _v_68 = 0;
        Term _o_14[5];
        if (spin_19(e, _o_14, _b_0, blk_loc(e.mem, _b_0)) == 0) {
          return 0;
        }
        _v_64 = _o_14[0];
        _v_65 = _o_14[1];
        _v_66 = _o_14[2];
        _v_67 = _o_14[3];
        _v_68 = _o_14[4];
        _v_59 = _v_64;
        _v_60 = _v_65;
        _v_61 = _v_66;
        _v_62 = _v_67;
        _v_63 = _v_68;
        u32 _v_69 = 0;
        Term _o_15[1];
        if (spin_20(e, _o_15, _v_49, _v_50, _v_51, _v_52, _v_53, _v_59, _v_60, _v_61, _v_62, _v_63) == 0) {
          return 0;
        }
        _v_69 = _o_15[0];
        r0 = _v_69;
        WL_RETN(1);
      }
    } else if (term_aux(_a_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_UTF16TEXT) {
      Term _fb_5[1];
      u64 _sp_5 = ctr_take(e, _a_0, 1, _fb_5);
      Term _f_8 = _fb_5[0];
      if (term_aux(_b_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_UTF16TEXT) {
        Term _fb_6[1];
        u64 _sp_6 = ctr_take(e, _b_0, 1, _fb_6);
        Term _f_9 = _fb_6[0];
        spare_free(e, cls_fit(1), _sp_6);
        spare_free(e, cls_fit(1), _sp_5);
        if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED)) {
          u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED, WL_CONT, WL_IDX, 0);
          e.mem[_t_4 + 0] = _f_8;
          e.mem[_t_4 + 1] = _f_9;
          return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED, _t_4);
        }
        r0 = _f_8;
        r1 = _f_9;
        WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED);
      } else if (term_aux(_b_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT) {
        Term _fb_7[1];
        u64 _sp_7 = ctr_take(e, _b_0, 1, _fb_7);
        Term _f_10 = _fb_7[0];
        spare_free(e, cls_fit(1), _sp_7);
        spare_free(e, cls_fit(1), _sp_5);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_8;
          STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K54;
          WL_PUSHN(2);
        } else {
          u64 _t_5 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K54, WL_CONT, WL_IDX, 1);
          e.mem[_t_5 + 0] = _f_8;
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K54, _t_5);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT)) {
          u64 _t_6 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT, WL_CONT, WL_IDX, 0);
          e.mem[_t_6 + 0] = _f_10;
          return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT, _t_6);
        }
        r0 = _f_10;
        WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_TEXT);
      } else {
        u32 _v_70 = 0;
        u32 _v_71 = 0;
        u32 _v_72 = 0;
        u32 _v_73 = 0;
        u32 _v_74 = 0;
        u64 _nd_1 = _sp_5 >= HEAP_OFF ? _sp_5 : heap_alloc(e, cls_fit(1));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_8);
        u32 _v_75 = 0;
        u32 _v_76 = 0;
        u32 _v_77 = 0;
        u32 _v_78 = 0;
        u32 _v_79 = 0;
        Term _o_16[5];
        Term _a_7 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_UTF16TEXT, _nd_1);
        if (spin_19(e, _o_16, _a_7, blk_loc(e.mem, _a_7)) == 0) {
          return 0;
        }
        _v_75 = _o_16[0];
        _v_76 = _o_16[1];
        _v_77 = _o_16[2];
        _v_78 = _o_16[3];
        _v_79 = _o_16[4];
        _v_70 = _v_75;
        _v_71 = _v_76;
        _v_72 = _v_77;
        _v_73 = _v_78;
        _v_74 = _v_79;
        u32 _v_80 = 0;
        u32 _v_81 = 0;
        u32 _v_82 = 0;
        u32 _v_83 = 0;
        u32 _v_84 = 0;
        u32 _v_85 = 0;
        u32 _v_86 = 0;
        u32 _v_87 = 0;
        u32 _v_88 = 0;
        u32 _v_89 = 0;
        Term _o_17[5];
        if (spin_19(e, _o_17, _b_0, blk_loc(e.mem, _b_0)) == 0) {
          return 0;
        }
        _v_85 = _o_17[0];
        _v_86 = _o_17[1];
        _v_87 = _o_17[2];
        _v_88 = _o_17[3];
        _v_89 = _o_17[4];
        _v_80 = _v_85;
        _v_81 = _v_86;
        _v_82 = _v_87;
        _v_83 = _v_88;
        _v_84 = _v_89;
        u32 _v_90 = 0;
        Term _o_18[1];
        if (spin_20(e, _o_18, _v_70, _v_71, _v_72, _v_73, _v_74, _v_80, _v_81, _v_82, _v_83, _v_84) == 0) {
          return 0;
        }
        _v_90 = _o_18[0];
        r0 = _v_90;
        WL_RETN(1);
      }
    } else if (term_aux(_a_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BOOLEAN) {
      u32 _a_8 = term_loc(_a_0);
      if (term_aux(_b_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BOOLEAN) {
        u32 _b_6 = term_loc(_b_0);
        u32 _v_91 = 0;
        Term _o_19[1];
        if (spin_16(e, _o_19, _a_8, _b_6) == 0) {
          return 0;
        }
        _v_91 = _o_19[0];
        r0 = _v_91;
        WL_RETN(1);
      } else {
        u32 _v_92 = 0;
        u32 _v_93 = 0;
        u32 _v_94 = 0;
        u32 _v_95 = 0;
        u32 _v_96 = 0;
        u32 _v_97 = 0;
        u32 _v_98 = 0;
        u32 _v_99 = 0;
        u32 _v_100 = 0;
        u32 _v_101 = 0;
        Term _o_20[5];
        Term _a_9 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BOOLEAN, _a_8);
        if (spin_19(e, _o_20, _a_9, blk_loc(e.mem, _a_9)) == 0) {
          return 0;
        }
        _v_97 = _o_20[0];
        _v_98 = _o_20[1];
        _v_99 = _o_20[2];
        _v_100 = _o_20[3];
        _v_101 = _o_20[4];
        _v_92 = _v_97;
        _v_93 = _v_98;
        _v_94 = _v_99;
        _v_95 = _v_100;
        _v_96 = _v_101;
        u32 _v_102 = 0;
        u32 _v_103 = 0;
        u32 _v_104 = 0;
        u32 _v_105 = 0;
        u32 _v_106 = 0;
        u32 _v_107 = 0;
        u32 _v_108 = 0;
        u32 _v_109 = 0;
        u32 _v_110 = 0;
        u32 _v_111 = 0;
        Term _o_21[5];
        if (spin_19(e, _o_21, _b_0, blk_loc(e.mem, _b_0)) == 0) {
          return 0;
        }
        _v_107 = _o_21[0];
        _v_108 = _o_21[1];
        _v_109 = _o_21[2];
        _v_110 = _o_21[3];
        _v_111 = _o_21[4];
        _v_102 = _v_107;
        _v_103 = _v_108;
        _v_104 = _v_109;
        _v_105 = _v_110;
        _v_106 = _v_111;
        u32 _v_112 = 0;
        Term _o_22[1];
        if (spin_20(e, _o_22, _v_92, _v_93, _v_94, _v_95, _v_96, _v_102, _v_103, _v_104, _v_105, _v_106) == 0) {
          return 0;
        }
        _v_112 = _o_22[0];
        r0 = _v_112;
        WL_RETN(1);
      }
    } else {
      u32 _v_113 = 0;
      u32 _v_114 = 0;
      u32 _v_115 = 0;
      u32 _v_116 = 0;
      u32 _v_117 = 0;
      u32 _v_118 = 0;
      u32 _v_119 = 0;
      u32 _v_120 = 0;
      u32 _v_121 = 0;
      u32 _v_122 = 0;
      Term _o_23[5];
      if (spin_19(e, _o_23, _a_0, blk_loc(e.mem, _a_0)) == 0) {
        return 0;
      }
      _v_118 = _o_23[0];
      _v_119 = _o_23[1];
      _v_120 = _o_23[2];
      _v_121 = _o_23[3];
      _v_122 = _o_23[4];
      _v_113 = _v_118;
      _v_114 = _v_119;
      _v_115 = _v_120;
      _v_116 = _v_121;
      _v_117 = _v_122;
      u32 _v_123 = 0;
      u32 _v_124 = 0;
      u32 _v_125 = 0;
      u32 _v_126 = 0;
      u32 _v_127 = 0;
      u32 _v_128 = 0;
      u32 _v_129 = 0;
      u32 _v_130 = 0;
      u32 _v_131 = 0;
      u32 _v_132 = 0;
      Term _o_24[5];
      if (spin_19(e, _o_24, _b_0, blk_loc(e.mem, _b_0)) == 0) {
        return 0;
      }
      _v_128 = _o_24[0];
      _v_129 = _o_24[1];
      _v_130 = _o_24[2];
      _v_131 = _o_24[3];
      _v_132 = _o_24[4];
      _v_123 = _v_128;
      _v_124 = _v_129;
      _v_125 = _v_130;
      _v_126 = _v_131;
      _v_127 = _v_132;
      u32 _v_133 = 0;
      Term _o_25[1];
      if (spin_20(e, _o_25, _v_113, _v_114, _v_115, _v_116, _v_117, _v_123, _v_124, _v_125, _v_126, _v_127) == 0) {
        return 0;
      }
      _v_133 = _o_25[0];
      r0 = _v_133;
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K53)
  {
    WL_POPN(1);
    Term _f_7 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED)) {
      u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _f_7;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED, _t_3);
    }
    r0 = _h_0;
    r1 = _f_7;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL_K54)
  {
    WL_POPN(1);
    Term _f_11 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED)) {
      u64 _t_7 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _f_11;
      e.mem[_t_7 + 1] = _h_1;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED, _t_7);
    }
    r0 = _f_11;
    r1 = _h_1;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_CHECKED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID)
  {
    Term _units_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_units_0) == CID_NIL) {
      r0 = 1;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _units_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID_K56;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID_K56, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID_K56, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _units_0 = r0;
      WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID_K56)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _o_0[1];
    if (spin_0(e, _o_0, U32_BIN(_f_2, <=, 65535ull), _h_0) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_EQ_K63;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_EQ_K63, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_EQ_K63, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_ORDER)) {
      u64 _t_1 = task_node(e, FID_STRING_ORDER, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_ORDER, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_ORDER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ_K63)
  {
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _o_0[1];
    if (spin_23(e, _o_0, _h_0) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND)
  {
    Term _codec_0 = r0;
    Term _raw_0 = r1;
    Term _path_0 = r2;
    Term _rest_0 = r3;
    WL_OPEN
    if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_INTEGER) {
      if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER) {
        u32 __0 = term_loc(_raw_0);
        term_sink(e, _path_0);
        r0 = 0;
        r1 = _rest_0;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        WL_RETN(5);
      } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_SIGNEDINTEGER) {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _raw_0, 2, _fb_0);
        u32 _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        Term _v_0 = 0;
        Term _v_1 = 0;
        Term _o_0[1];
        if (spin_10(e, _o_0, _f_1, nat_mul(e, ((u64)65536ull), ((u64)65536ull))) == 0) {
          return 0;
        }
        _v_1 = _o_0[0];
        _v_0 = _v_1;
        u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
        e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _v_4 = 0;
        Term _v_5 = 0;
        Term _v_6 = 0;
        Term _o_1[5];
        Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 18);
        Term _a_1 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_SIGNEDINTEGER, _nd_0);
        if (spin_24(e, _o_1, (_v_0 < ((u64)2097152ull)), _path_0, blk_loc(e.mem, _path_0), _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1), _rest_0, blk_loc(e.mem, _rest_0)) == 0) {
          return 0;
        }
        _v_2 = _o_1[0];
        _v_3 = _o_1[1];
        _v_4 = _o_1[2];
        _v_5 = _o_1[3];
        _v_6 = _o_1[4];
        r0 = _v_2;
        r1 = _v_3;
        r2 = _v_4;
        r3 = _v_5;
        r4 = _v_6;
        WL_RETN(5);
      } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FLOAT) {
        u32 _value_0 = term_loc(_raw_0);
        u32 _v_12 = 0;
        u32 _v_13 = 0;
        Term _o_2[1];
        if (spin_0(e, _o_2, ((u64)(f32_unbox(f32_rewrap((f32)floor(f32_unbox(_value_0)))) == f32_unbox(_value_0))), ((u64)(f32_unbox(f32_rewrap((f32)fabs(f32_unbox(_value_0)))) < f32_unbox(1509949440ull)))) == 0) {
          return 0;
        }
        _v_13 = _o_2[0];
        _v_12 = _v_13;
        u32 _v_14 = 0;
        Term _v_15 = 0;
        Term _v_16 = 0;
        Term _v_17 = 0;
        Term _v_18 = 0;
        Term _o_3[5];
        Term _a_2 = term_ctr(CID_SCON, STAT_OFF + 18);
        Term _a_3 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FLOAT, _value_0);
        if (spin_24(e, _o_3, _v_12, _path_0, blk_loc(e.mem, _path_0), _a_2, blk_loc(e.mem, _a_2), _a_3, blk_loc(e.mem, _a_3), _rest_0, blk_loc(e.mem, _rest_0)) == 0) {
          return 0;
        }
        _v_14 = _o_3[0];
        _v_15 = _o_3[1];
        _v_16 = _o_3[2];
        _v_17 = _o_3[3];
        _v_18 = _o_3[4];
        r0 = _v_14;
        r1 = _v_15;
        r2 = _v_16;
        r3 = _v_17;
        r4 = _v_18;
        WL_RETN(5);
      } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BINARY64) {
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _raw_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        u32 _v_19 = 0;
        u32 _v_20 = 0;
        Term _o_7[1];
        if (spin_25(e, _o_7, _f_2, _f_3) == 0) {
          return 0;
        }
        _v_20 = _o_7[0];
        _v_19 = _v_20;
        u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
        e.mem[_nd_1 + 1] = rfc_seal(e, _f_3);
        u32 _v_35 = 0;
        Term _v_36 = 0;
        Term _v_37 = 0;
        Term _v_38 = 0;
        Term _v_39 = 0;
        Term _o_8[5];
        Term _a_4 = term_ctr(CID_SCON, STAT_OFF + 18);
        Term _a_5 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BINARY64, _nd_1);
        if (spin_24(e, _o_8, _v_19, _path_0, blk_loc(e.mem, _path_0), _a_4, blk_loc(e.mem, _a_4), _a_5, blk_loc(e.mem, _a_5), _rest_0, blk_loc(e.mem, _rest_0)) == 0) {
          return 0;
        }
        _v_35 = _o_8[0];
        _v_36 = _o_8[1];
        _v_37 = _o_8[2];
        _v_38 = _o_8[3];
        _v_39 = _o_8[4];
        r0 = _v_35;
        r1 = _v_36;
        r2 = _v_37;
        r3 = _v_38;
        r4 = _v_39;
        WL_RETN(5);
      } else {
        term_sink(e, _rest_0);
        r0 = 1;
        r1 = 0;
        r2 = _path_0;
        r3 = term_ctr(CID_SCON, STAT_OFF + 18);
        r4 = _raw_0;
        WL_RETN(5);
      }
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FINITENUMBER) {
      if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER) {
        u32 __1 = term_loc(_raw_0);
        term_sink(e, _path_0);
        r0 = 0;
        r1 = _rest_0;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        WL_RETN(5);
      } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_SIGNEDINTEGER) {
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _raw_0, 2, _fb_2);
        u32 _f_4 = _fb_2[0];
        Term _f_5 = _fb_2[1];
        term_sink(e, _path_0);
        spare_free(e, cls_fit(2), _sp_2);
        r0 = 0;
        r1 = _rest_0;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        WL_RETN(5);
      } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FLOAT) {
        u32 _value_1 = term_loc(_raw_0);
        u32 _v_40 = 0;
        Term _v_41 = 0;
        Term _v_42 = 0;
        Term _v_43 = 0;
        Term _v_44 = 0;
        Term _o_9[5];
        Term _a_6 = term_ctr(CID_SCON, STAT_OFF + 40);
        Term _a_7 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FLOAT, _value_1);
        if (spin_24(e, _o_9, ((u64)(f32_unbox(f32_rewrap((f32)fabs(f32_unbox(_value_1)))) <= f32_unbox(2139095039ull))), _path_0, blk_loc(e.mem, _path_0), _a_6, blk_loc(e.mem, _a_6), _a_7, blk_loc(e.mem, _a_7), _rest_0, blk_loc(e.mem, _rest_0)) == 0) {
          return 0;
        }
        _v_40 = _o_9[0];
        _v_41 = _o_9[1];
        _v_42 = _o_9[2];
        _v_43 = _o_9[3];
        _v_44 = _o_9[4];
        r0 = _v_40;
        r1 = _v_41;
        r2 = _v_42;
        r3 = _v_43;
        r4 = _v_44;
        WL_RETN(5);
      } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BINARY64) {
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _raw_0, 2, _fb_3);
        u32 _f_6 = _fb_3[0];
        u32 _f_7 = _fb_3[1];
        u32 _v_45 = 0;
        u32 _v_46 = 0;
        Term _o_10[1];
        if (spin_21(e, _o_10, _f_6) == 0) {
          return 0;
        }
        _v_46 = _o_10[0];
        _v_45 = _v_46;
        u64 _nd_2 = _sp_3 >= HEAP_OFF ? _sp_3 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_2 + 0] = rfc_seal(e, _f_6);
        e.mem[_nd_2 + 1] = rfc_seal(e, _f_7);
        u32 _v_47 = 0;
        Term _v_48 = 0;
        Term _v_49 = 0;
        Term _v_50 = 0;
        Term _v_51 = 0;
        Term _o_11[5];
        Term _a_8 = term_ctr(CID_SCON, STAT_OFF + 40);
        Term _a_9 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BINARY64, _nd_2);
        if (spin_24(e, _o_11, U32_BIN(_v_45, <, 2047ull), _path_0, blk_loc(e.mem, _path_0), _a_8, blk_loc(e.mem, _a_8), _a_9, blk_loc(e.mem, _a_9), _rest_0, blk_loc(e.mem, _rest_0)) == 0) {
          return 0;
        }
        _v_47 = _o_11[0];
        _v_48 = _o_11[1];
        _v_49 = _o_11[2];
        _v_50 = _o_11[3];
        _v_51 = _o_11[4];
        r0 = _v_47;
        r1 = _v_48;
        r2 = _v_49;
        r3 = _v_50;
        r4 = _v_51;
        WL_RETN(5);
      } else {
        term_sink(e, _rest_0);
        r0 = 1;
        r1 = 0;
        r2 = _path_0;
        r3 = term_ctr(CID_SCON, STAT_OFF + 40);
        r4 = _raw_0;
        WL_RETN(5);
      }
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRINGVALUE) {
      if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT) {
        Term _fb_4[1];
        u64 _sp_4 = ctr_take(e, _raw_0, 1, _fb_4);
        Term _f_8 = _fb_4[0];
        term_sink(e, _f_8);
        term_sink(e, _path_0);
        spare_free(e, cls_fit(1), _sp_4);
        r0 = 0;
        r1 = _rest_0;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        WL_RETN(5);
      } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_UTF16TEXT) {
        Term _fb_5[1];
        u64 _sp_5 = ctr_take(e, _raw_0, 1, _fb_5);
        Term _f_9 = _fb_5[0];
        _f_9 = term_keep(e, _f_9, 1);
        spare_free(e, cls_fit(1), _sp_5);
        if (seq) {
          WL_ROOM(4);
          STK(0) = _f_9;
          STK(1) = _path_0;
          STK(2) = _rest_0;
          STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K66;
          WL_PUSHN(4);
        } else {
          u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K66, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_9;
          e.mem[_t_0 + 1] = _path_0;
          e.mem[_t_0 + 2] = _rest_0;
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K66, _t_0);
          WL_IDX = 3;
        }
        if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID)) {
          u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _f_9;
          return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID, _t_1);
        }
        r0 = _f_9;
        WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_UTF16_VALID);
      } else {
        term_sink(e, _rest_0);
        r0 = 1;
        r1 = 0;
        r2 = _path_0;
        r3 = term_ctr(CID_SCON, STAT_OFF + 52);
        r4 = _raw_0;
        WL_RETN(5);
      }
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BOOLVALUE) {
      if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_BOOLEAN) {
        u32 __2 = term_loc(_raw_0);
        term_sink(e, _path_0);
        r0 = 0;
        r1 = _rest_0;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        WL_RETN(5);
      } else {
        term_sink(e, _rest_0);
        r0 = 1;
        r1 = 0;
        r2 = _path_0;
        r3 = term_ctr(CID_SCON, STAT_OFF + 66);
        r4 = _raw_0;
        WL_RETN(5);
      }
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_LITERAL) {
      Term _fb_6[1];
      u64 _sp_6 = ctr_take(e, _codec_0, 1, _fb_6);
      Term _f_11 = _fb_6[0];
      _raw_0 = term_keep(e, _raw_0, 1);
      spare_free(e, cls_fit(1), _sp_6);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _raw_0;
        STK(1) = _path_0;
        STK(2) = _rest_0;
        STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K67;
        WL_PUSHN(4);
      } else {
        u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K67, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _raw_0;
        e.mem[_t_2 + 1] = _path_0;
        e.mem[_t_2 + 2] = _rest_0;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K67, _t_2);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL)) {
        u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _f_11;
        e.mem[_t_3 + 1] = _raw_0;
        return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL, _t_3);
      }
      r0 = _f_11;
      r1 = _raw_0;
      WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EQUAL);
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_LITERALVALUES) {
      Term _fb_7[1];
      u64 _sp_7 = ctr_take(e, _codec_0, 1, _fb_7);
      Term _f_12 = _fb_7[0];
      _raw_0 = term_keep(e, _raw_0, 1);
      spare_free(e, cls_fit(1), _sp_7);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _raw_0;
        STK(1) = _path_0;
        STK(2) = _rest_0;
        STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K68;
        WL_PUSHN(4);
      } else {
        u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K68, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _raw_0;
        e.mem[_t_4 + 1] = _path_0;
        e.mem[_t_4 + 2] = _rest_0;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K68, _t_4);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES)) {
        u64 _t_5 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _f_12;
        e.mem[_t_5 + 1] = _raw_0;
        return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES, _t_5);
      }
      r0 = _f_12;
      r1 = _raw_0;
      WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES);
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_LITERALRENDERED) {
      Term _fb_8[2];
      u64 _sp_8 = ctr_take(e, _codec_0, 2, _fb_8);
      Term _f_13 = _fb_8[0];
      Term _f_14 = _fb_8[1];
      _raw_0 = term_keep(e, _raw_0, 1);
      spare_free(e, cls_fit(2), _sp_8);
      if (seq) {
        WL_ROOM(5);
        STK(0) = _f_14;
        STK(1) = _raw_0;
        STK(2) = _path_0;
        STK(3) = _rest_0;
        STK(4) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K69;
        WL_PUSHN(5);
      } else {
        u64 _t_6 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K69, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _f_14;
        e.mem[_t_6 + 1] = _raw_0;
        e.mem[_t_6 + 2] = _path_0;
        e.mem[_t_6 + 3] = _rest_0;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K69, _t_6);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES)) {
        u64 _t_7 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES, WL_CONT, WL_IDX, 0);
        e.mem[_t_7 + 0] = _f_13;
        e.mem[_t_7 + 1] = _raw_0;
        return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES, _t_7);
      }
      r0 = _f_13;
      r1 = _raw_0;
      WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ALTERNATIVES);
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULLABLE) {
      Term _fb_9[1];
      u64 _sp_9 = ctr_take(e, _codec_0, 1, _fb_9);
      Term _f_16 = _fb_9[0];
      if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULL) {
        term_sink(e, _f_16);
        term_sink(e, _path_0);
        spare_free(e, cls_fit(1), _sp_9);
        r0 = 0;
        r1 = _rest_0;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        WL_RETN(5);
      } else {
        u64 _nd_4 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_4 + 0] = rfc_seal(e, _f_16);
        e.mem[_nd_4 + 1] = rfc_seal(e, _raw_0);
        e.mem[_nd_4 + 2] = rfc_seal(e, _path_0);
        u64 _nd_5 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_WORK, _nd_4));
        e.mem[_nd_5 + 1] = rfc_seal(e, _rest_0);
        spare_free(e, cls_fit(1), _sp_9);
        r0 = 0;
        r1 = term_ctr(CID_CON, _nd_5);
        r2 = 0;
        r3 = 0;
        r4 = 0;
        WL_RETN(5);
      }
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAYVALUE) {
      Term _fb_10[1];
      u64 _sp_10 = ctr_take(e, _codec_0, 1, _fb_10);
      Term _f_17 = _fb_10[0];
      if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY) {
        Term _fb_11[1];
        u64 _sp_11 = ctr_take(e, _raw_0, 1, _fb_11);
        Term _f_18 = _fb_11[0];
        spare_free(e, cls_fit(1), _sp_11);
        spare_free(e, cls_fit(1), _sp_10);
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K70;
          WL_PUSHN(1);
        } else {
          u64 _t_8 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K70, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K70, _t_8);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK)) {
          u64 _t_9 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK, WL_CONT, WL_IDX, 0);
          e.mem[_t_9 + 0] = _f_17;
          e.mem[_t_9 + 1] = _f_18;
          e.mem[_t_9 + 2] = _path_0;
          e.mem[_t_9 + 3] = 0ull;
          e.mem[_t_9 + 4] = _rest_0;
          return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK, _t_9);
        }
        r0 = _f_17;
        r1 = _f_18;
        r2 = _path_0;
        r3 = 0ull;
        r4 = _rest_0;
        WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY_WORK);
      } else {
        term_sink(e, _f_17);
        term_sink(e, _rest_0);
        spare_free(e, cls_fit(1), _sp_10);
        r0 = 1;
        r1 = 0;
        r2 = _path_0;
        r3 = term_ctr(CID_SCON, STAT_OFF + 90);
        r4 = _raw_0;
        WL_RETN(5);
      }
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT) {
      Term _fb_12[1];
      u64 _sp_12 = ctr_take(e, _codec_0, 1, _fb_12);
      Term _f_19 = _fb_12[0];
      if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT) {
        Term _fb_13[1];
        u64 _sp_13 = ctr_take(e, _raw_0, 1, _fb_13);
        Term _f_20 = _fb_13[0];
        spare_free(e, cls_fit(1), _sp_13);
        spare_free(e, cls_fit(1), _sp_12);
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K71;
          WL_PUSHN(1);
        } else {
          u64 _t_10 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K71, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K71, _t_10);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK)) {
          u64 _t_11 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK, WL_CONT, WL_IDX, 0);
          e.mem[_t_11 + 0] = _f_19;
          e.mem[_t_11 + 1] = _f_20;
          e.mem[_t_11 + 2] = _path_0;
          e.mem[_t_11 + 3] = _rest_0;
          return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK, _t_11);
        }
        r0 = _f_19;
        r1 = _f_20;
        r2 = _path_0;
        r3 = _rest_0;
        WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT_WORK);
      } else {
        term_sink(e, _f_19);
        term_sink(e, _rest_0);
        spare_free(e, cls_fit(1), _sp_12);
        r0 = 1;
        r1 = 0;
        r2 = _path_0;
        r3 = term_ctr(CID_SCON, STAT_OFF + 102);
        r4 = _raw_0;
        WL_RETN(5);
      }
    } else {
      u32 _ns_0 = term_loc(_codec_0);
      if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_HANDLE) {
        Term _fb_14[2];
        u64 _sp_14 = ctr_take(e, _raw_0, 2, _fb_14);
        u32 _f_21 = _fb_14[0];
        u32 _f_22 = _fb_14[1];
        u32 _v_72 = 0;
        u32 _v_73 = 0;
        Term _o_16[1];
        if (spin_0(e, _o_16, U32_BIN(_ns_0, ==, _f_21), U32_BIN(_f_22, >, 0ull)) == 0) {
          return 0;
        }
        _v_73 = _o_16[0];
        _v_72 = _v_73;
        u64 _nd_6 = _sp_14 >= HEAP_OFF ? _sp_14 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_6 + 0] = rfc_seal(e, _f_21);
        e.mem[_nd_6 + 1] = rfc_seal(e, _f_22);
        u32 _v_74 = 0;
        Term _v_75 = 0;
        Term _v_76 = 0;
        Term _v_77 = 0;
        Term _v_78 = 0;
        Term _o_17[5];
        Term _a_14 = term_ctr(CID_SCON, STAT_OFF + 136);
        Term _a_15 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_HANDLE, _nd_6);
        if (spin_24(e, _o_17, _v_72, _path_0, blk_loc(e.mem, _path_0), _a_14, blk_loc(e.mem, _a_14), _a_15, blk_loc(e.mem, _a_15), _rest_0, blk_loc(e.mem, _rest_0)) == 0) {
          return 0;
        }
        _v_74 = _o_17[0];
        _v_75 = _o_17[1];
        _v_76 = _o_17[2];
        _v_77 = _o_17[3];
        _v_78 = _o_17[4];
        r0 = _v_74;
        r1 = _v_75;
        r2 = _v_76;
        r3 = _v_77;
        r4 = _v_78;
        WL_RETN(5);
      } else {
        term_sink(e, _rest_0);
        r0 = 1;
        r1 = 0;
        r2 = _path_0;
        r3 = term_ctr(CID_SCON, STAT_OFF + 136);
        r4 = _raw_0;
        WL_RETN(5);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K66)
  {
    WL_POPN(3);
    Term _f_10 = STK(0);
    Term _path_2 = STK(1);
    Term _rest_2 = STK(2);
    u32 _h_0 = r0;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_3 + 0] = rfc_seal(e, _f_10);
    u32 _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _o_12[5];
    Term _a_10 = term_ctr(CID_SCON, STAT_OFF + 52);
    Term _a_11 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_UTF16TEXT, _nd_3);
    if (spin_24(e, _o_12, _h_0, _path_2, blk_loc(e.mem, _path_2), _a_10, blk_loc(e.mem, _a_10), _a_11, blk_loc(e.mem, _a_11), _rest_2, blk_loc(e.mem, _rest_2)) == 0) {
      return 0;
    }
    _v_52 = _o_12[0];
    _v_53 = _o_12[1];
    _v_54 = _o_12[2];
    _v_55 = _o_12[3];
    _v_56 = _o_12[4];
    r0 = _v_52;
    r1 = _v_53;
    r2 = _v_54;
    r3 = _v_55;
    r4 = _v_56;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K67)
  {
    WL_POPN(3);
    Term _raw_2 = STK(0);
    Term _path_3 = STK(1);
    Term _rest_3 = STK(2);
    u32 _h_1 = r0;
    WL_OPEN
    u32 _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _o_13[5];
    Term _a_12 = term_ctr(CID_SCON, STAT_OFF + 80);
    if (spin_24(e, _o_13, _h_1, _path_3, blk_loc(e.mem, _path_3), _a_12, blk_loc(e.mem, _a_12), _raw_2, blk_loc(e.mem, _raw_2), _rest_3, blk_loc(e.mem, _rest_3)) == 0) {
      return 0;
    }
    _v_57 = _o_13[0];
    _v_58 = _o_13[1];
    _v_59 = _o_13[2];
    _v_60 = _o_13[3];
    _v_61 = _o_13[4];
    r0 = _v_57;
    r1 = _v_58;
    r2 = _v_59;
    r3 = _v_60;
    r4 = _v_61;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K68)
  {
    WL_POPN(3);
    Term _raw_3 = STK(0);
    Term _path_4 = STK(1);
    Term _rest_4 = STK(2);
    u32 _h_2 = r0;
    WL_OPEN
    u32 _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _o_14[5];
    Term _a_13 = term_ctr(CID_SCON, STAT_OFF + 80);
    if (spin_24(e, _o_14, _h_2, _path_4, blk_loc(e.mem, _path_4), _a_13, blk_loc(e.mem, _a_13), _raw_3, blk_loc(e.mem, _raw_3), _rest_4, blk_loc(e.mem, _rest_4)) == 0) {
      return 0;
    }
    _v_62 = _o_14[0];
    _v_63 = _o_14[1];
    _v_64 = _o_14[2];
    _v_65 = _o_14[3];
    _v_66 = _o_14[4];
    r0 = _v_62;
    r1 = _v_63;
    r2 = _v_64;
    r3 = _v_65;
    r4 = _v_66;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K69)
  {
    WL_POPN(4);
    Term _f_15 = STK(0);
    Term _raw_4 = STK(1);
    Term _path_5 = STK(2);
    Term _rest_5 = STK(3);
    u32 _h_3 = r0;
    WL_OPEN
    u32 _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    Term _o_15[5];
    if (spin_24(e, _o_15, _h_3, _path_5, blk_loc(e.mem, _path_5), _f_15, blk_loc(e.mem, _f_15), _raw_4, blk_loc(e.mem, _raw_4), _rest_5, blk_loc(e.mem, _rest_5)) == 0) {
      return 0;
    }
    _v_67 = _o_15[0];
    _v_68 = _o_15[1];
    _v_69 = _o_15[2];
    _v_70 = _o_15[3];
    _v_71 = _o_15[4];
    r0 = _v_67;
    r1 = _v_68;
    r2 = _v_69;
    r3 = _v_70;
    r4 = _v_71;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K70)
  {
    Term _h_4 = r0;
    WL_OPEN
    r0 = 0;
    r1 = _h_4;
    r2 = 0;
    r3 = 0;
    r4 = 0;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND_K71)
  {
    Term _h_5 = r0;
    WL_OPEN
    r0 = 0;
    r1 = _h_5;
    r2 = 0;
    r3 = 0;
    r4 = 0;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD)
  {
    Term _name_0 = r0;
    Term _fields_0 = r1;
    WL_OPEN
    if (term_aux(_fields_0) == CID_NIL) {
      term_sink(e, _name_0);
      r0 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_MISSING, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _fields_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      _name_0 = term_keep(e, _name_0, 1);
      spare_free(e, cls_fit(2), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _name_0;
        STK(1) = _f_3;
        STK(2) = _f_1;
        STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_K73;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_K73, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _name_0;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _f_1;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_K73, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
        u64 _t_1 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _name_0;
        e.mem[_t_1 + 1] = _f_2;
        return term_tsk(FID_STRING_EQ, _t_1);
      }
      r0 = _name_0;
      r1 = _f_2;
      WL_JMP(FID_STRING_EQ);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_K73)
  {
    WL_POPN(3);
    Term _name_1 = STK(0);
    Term _f_4 = STK(1);
    Term _f_5 = STK(2);
    u32 _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _name_1;
    e.mem[_nd_0 + 1] = _f_5;
    if (_h_0 == 1) {
      Term _next_0 = term_clo(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_C74, _nd_0);
      term_sink(e, _next_0);
      r0 = _f_4;
      WL_RETN(1);
    } else {
      term_sink(e, _f_4);
      Term _next_1 = term_clo(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_C74, _nd_0);
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _next_1;
        e.mem[_t_3 + 1] = term_pak(CID_UNIT, 0);
        return term_tsk(FID_CLO_APPLY, _t_3);
      }
      r0 = _next_1;
      r1 = term_pak(CID_UNIT, 0);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD_C74)
  {
    Term _name_2 = r0;
    Term _f_6 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD)) {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _name_2;
      e.mem[_t_2 + 1] = _f_6;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD, _t_2);
    }
    r0 = _name_2;
    r1 = _f_6;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE)
  {
    Term _fuel_0 = r0;
    u32 _step_0 = r1;
    Term _step_1 = r2;
    Term _step_2 = r3;
    Term _step_3 = r4;
    Term _step_4 = r5;
    Term _original_0 = r6;
    WL_OPEN
    if (_fuel_0 == 0) {
      if (_step_0 == 1) {
        term_sink(e, _original_0);
        r0 = 1;
        r1 = _step_1;
        r2 = _step_2;
        r3 = _step_3;
        r4 = _step_4;
        WL_RETN(5);
      } else {
        if (term_aux(_step_1) == CID_NIL) {
          r0 = 0;
          r1 = _original_0;
          r2 = 0;
          r3 = 0;
          r4 = 0;
          WL_RETN(5);
        } else {
          Term _fb_0[2];
          u64 _sp_0 = ctr_take(e, _step_1, 2, _fb_0);
          Term _f_0 = _fb_0[0];
          Term _f_1 = _fb_0[1];
          Term _fb_1[3];
          u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
          Term _f_2 = _fb_1[0];
          Term _f_3 = _fb_1[1];
          Term _f_4 = _fb_1[2];
          spare_free(e, cls_fit(3), _sp_1);
          term_sink(e, _f_2);
          term_sink(e, _f_3);
          term_sink(e, _f_1);
          term_sink(e, _original_0);
          spare_free(e, cls_fit(2), _sp_0);
          r0 = 1;
          r1 = 1;
          r2 = _f_4;
          r3 = 0;
          r4 = 0;
          WL_RETN(5);
        }
      }
    } else {
      Term _more_0 = (_fuel_0 - 1);
      if (_step_0 == 1) {
        term_sink(e, _original_0);
        r0 = 1;
        r1 = _step_1;
        r2 = _step_2;
        r3 = _step_3;
        r4 = _step_4;
        WL_RETN(5);
      } else {
        if (term_aux(_step_1) == CID_NIL) {
          r0 = 0;
          r1 = _original_0;
          r2 = 0;
          r3 = 0;
          r4 = 0;
          WL_RETN(5);
        } else {
          Term _fb_2[2];
          u64 _sp_2 = ctr_take(e, _step_1, 2, _fb_2);
          Term _f_5 = _fb_2[0];
          Term _f_6 = _fb_2[1];
          Term _fb_3[3];
          u64 _sp_3 = ctr_take(e, _f_5, 3, _fb_3);
          Term _f_7 = _fb_3[0];
          Term _f_8 = _fb_3[1];
          Term _f_9 = _fb_3[2];
          spare_free(e, cls_fit(3), _sp_3);
          spare_free(e, cls_fit(2), _sp_2);
          if (seq) {
            WL_ROOM(3);
            STK(0) = _more_0;
            STK(1) = _original_0;
            STK(2) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE_K78;
            WL_PUSHN(3);
          } else {
            u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE_K78, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _more_0;
            e.mem[_t_0 + 1] = _original_0;
            WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE_K78, _t_0);
            WL_IDX = 2;
          }
          if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND)) {
            u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND, WL_CONT, WL_IDX, 0);
            e.mem[_t_1 + 0] = _f_7;
            e.mem[_t_1 + 1] = _f_8;
            e.mem[_t_1 + 2] = _f_9;
            e.mem[_t_1 + 3] = _f_6;
            return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND, _t_1);
          }
          r0 = _f_7;
          r1 = _f_8;
          r2 = _f_9;
          r3 = _f_6;
          WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_EXPAND);
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE_K78)
  {
    WL_POPN(2);
    Term _more_1 = STK(0);
    Term _original_1 = STK(1);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE)) {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _more_1;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      e.mem[_t_2 + 3] = _h_2;
      e.mem[_t_2 + 4] = _h_3;
      e.mem[_t_2 + 5] = _h_4;
      e.mem[_t_2 + 6] = _original_1;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE, _t_2);
    }
    r0 = _more_1;
    r1 = _h_0;
    r2 = _h_1;
    r3 = _h_2;
    r4 = _h_3;
    r5 = _h_4;
    r6 = _original_1;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL)
  {
    Term _fuel_0 = r0;
    Term _codec_0 = r1;
    Term _raw_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_fuel_0 == 0) {
      term_sink(e, _codec_0);
      r0 = _raw_0;
      WL_RETN(1);
    } else {
      Term _more_0 = (_fuel_0 - 1);
      if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULLABLE) {
        Term _fb_0[1];
        u64 _sp_0 = ctr_take(e, _codec_0, 1, _fb_0);
        Term _f_0 = _fb_0[0];
        if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULL) {
          term_sink(e, _f_0);
          spare_free(e, cls_fit(1), _sp_0);
          r0 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULL, 0);
          WL_RETN(1);
        } else {
          spare_free(e, cls_fit(1), _sp_0);
          r0 = _more_0;
          r1 = _f_0;
          r2 = _raw_0;
          _fuel_0 = r0;
          _codec_0 = r1;
          _raw_0 = r2;
          WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL);
        }
      } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAYVALUE) {
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _codec_0, 1, _fb_1);
        Term _f_1 = _fb_1[0];
        if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY) {
          Term _fb_2[1];
          u64 _sp_2 = ctr_take(e, _raw_0, 1, _fb_2);
          Term _f_2 = _fb_2[0];
          if (term_aux(_f_2) == CID_NIL) {
            term_sink(e, _f_1);
            spare_free(e, cls_fit(1), _sp_2);
            spare_free(e, cls_fit(1), _sp_1);
            r0 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY, STAT_OFF + 138);
            WL_RETN(1);
          } else {
            Term _fb_3[2];
            u64 _sp_3 = ctr_take(e, _f_2, 2, _fb_3);
            Term _f_3 = _fb_3[0];
            Term _f_4 = _fb_3[1];
            _f_1 = term_keep(e, _f_1, 1);
            spare_free(e, cls_fit(2), _sp_3);
            spare_free(e, cls_fit(1), _sp_2);
            spare_free(e, cls_fit(1), _sp_1);
            if (seq) {
              WL_ROOM(4);
              STK(0) = _more_0;
              STK(1) = _f_1;
              STK(2) = _f_4;
              STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K80;
              WL_PUSHN(4);
            } else {
              u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K80, WL_CONT, WL_IDX, 1);
              e.mem[_t_0 + 0] = _more_0;
              e.mem[_t_0 + 1] = _f_1;
              e.mem[_t_0 + 2] = _f_4;
              WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K80, _t_0);
              WL_IDX = 3;
            }
            r0 = _more_0;
            r1 = _f_1;
            r2 = _f_3;
            _fuel_0 = r0;
            _codec_0 = r1;
            _raw_0 = r2;
            WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL);
          }
        } else {
          term_sink(e, _f_1);
          spare_free(e, cls_fit(1), _sp_1);
          r0 = _raw_0;
          WL_RETN(1);
        }
      } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT) {
        Term _fb_5[1];
        u64 _sp_5 = ctr_take(e, _codec_0, 1, _fb_5);
        Term _f_8 = _fb_5[0];
        if (term_aux(_f_8) == CID_NIL) {
          if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT) {
            Term _fb_6[1];
            u64 _sp_6 = ctr_take(e, _raw_0, 1, _fb_6);
            Term _f_9 = _fb_6[0];
            term_sink(e, _f_9);
            spare_free(e, cls_fit(1), _sp_6);
            spare_free(e, cls_fit(1), _sp_5);
            r0 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT, STAT_OFF + 138);
            WL_RETN(1);
          } else {
            spare_free(e, cls_fit(1), _sp_5);
            r0 = _raw_0;
            WL_RETN(1);
          }
        } else {
          Term _fb_7[2];
          u64 _sp_7 = ctr_take(e, _f_8, 2, _fb_7);
          Term _f_10 = _fb_7[0];
          Term _f_11 = _fb_7[1];
          Term _fb_8[2];
          u64 _sp_8 = ctr_take(e, _f_10, 2, _fb_8);
          Term _f_12 = _fb_8[0];
          Term _f_13 = _fb_8[1];
          if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT) {
            Term _fb_9[1];
            u64 _sp_9 = ctr_take(e, _raw_0, 1, _fb_9);
            Term _f_14 = _fb_9[0];
            _f_12 = term_keep(e, _f_12, 1);
            _f_14 = term_keep(e, _f_14, 1);
            spare_free(e, cls_fit(1), _sp_9);
            spare_free(e, cls_fit(2), _sp_8);
            spare_free(e, cls_fit(2), _sp_7);
            spare_free(e, cls_fit(1), _sp_5);
            if (seq) {
              WL_ROOM(6);
              STK(0) = _more_0;
              STK(1) = _f_12;
              STK(2) = _f_13;
              STK(3) = _f_11;
              STK(4) = _f_14;
              STK(5) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K82;
              WL_PUSHN(6);
            } else {
              u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K82, WL_CONT, WL_IDX, 1);
              e.mem[_t_3 + 0] = _more_0;
              e.mem[_t_3 + 1] = _f_12;
              e.mem[_t_3 + 2] = _f_13;
              e.mem[_t_3 + 3] = _f_11;
              e.mem[_t_3 + 4] = _f_14;
              WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K82, _t_3);
              WL_IDX = 5;
            }
            if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD)) {
              u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD, WL_CONT, WL_IDX, 0);
              e.mem[_t_4 + 0] = _f_12;
              e.mem[_t_4 + 1] = _f_14;
              return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD, _t_4);
            }
            r0 = _f_12;
            r1 = _f_14;
            WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_FIELD);
          } else {
            term_sink(e, _f_12);
            term_sink(e, _f_13);
            term_sink(e, _f_11);
            spare_free(e, cls_fit(2), _sp_8);
            spare_free(e, cls_fit(2), _sp_7);
            spare_free(e, cls_fit(1), _sp_5);
            r0 = _raw_0;
            WL_RETN(1);
          }
        }
      } else {
        term_sink(e, _codec_0);
        r0 = _raw_0;
        WL_RETN(1);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K80)
  {
    WL_POPN(3);
    Term _more_1 = STK(0);
    Term _f_5 = STK(1);
    Term _f_6 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_5);
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = rfc_seal(e, _f_6);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K81;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K81, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K81, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL)) {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _more_1;
      e.mem[_t_2 + 1] = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAYVALUE, _nd_0);
      e.mem[_t_2 + 2] = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY, _nd_1);
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL, _t_2);
    }
    r0 = _more_1;
    r1 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAYVALUE, _nd_0);
    r2 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY, _nd_1);
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K81)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_26(e, _o_0, _h_2, blk_loc(e.mem, _h_2), _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K82)
  {
    WL_POPN(5);
    Term _more_2 = STK(0);
    Term _f_15 = STK(1);
    Term _f_16 = STK(2);
    Term _f_17 = STK(3);
    Term _f_18 = STK(4);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _more_2;
      STK(1) = _f_15;
      STK(2) = _f_17;
      STK(3) = _f_18;
      STK(4) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K83;
      WL_PUSHN(5);
    } else {
      u64 _t_5 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K83, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _more_2;
      e.mem[_t_5 + 1] = _f_15;
      e.mem[_t_5 + 2] = _f_17;
      e.mem[_t_5 + 3] = _f_18;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K83, _t_5);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL)) {
      u64 _t_6 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _more_2;
      e.mem[_t_6 + 1] = _f_16;
      e.mem[_t_6 + 2] = _h_3;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL, _t_6);
    }
    r0 = _more_2;
    r1 = _f_16;
    r2 = _h_3;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K83)
  {
    WL_POPN(4);
    Term _more_3 = STK(0);
    Term _f_19 = STK(1);
    Term _f_20 = STK(2);
    Term _f_21 = STK(3);
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_4 + 0] = rfc_seal(e, _f_20);
    u64 _nd_5 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_5 + 0] = rfc_seal(e, _f_21);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _f_19;
      STK(1) = _h_4;
      STK(2) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K84;
      WL_PUSHN(3);
    } else {
      u64 _t_7 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K84, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _f_19;
      e.mem[_t_7 + 1] = _h_4;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K84, _t_7);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL)) {
      u64 _t_8 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _more_3;
      e.mem[_t_8 + 1] = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT, _nd_4);
      e.mem[_t_8 + 2] = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT, _nd_5);
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL, _t_8);
    }
    r0 = _more_3;
    r1 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT, _nd_4);
    r2 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT, _nd_5);
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL_K84)
  {
    WL_POPN(2);
    Term _f_22 = STK(0);
    Term _h_6 = STK(1);
    Term _h_5 = r0;
    WL_OPEN
    Term _v_2 = 0;
    Term _o_1[1];
    if (spin_27(e, _o_1, _f_22, blk_loc(e.mem, _f_22), _h_6, blk_loc(e.mem, _h_6), _h_5, blk_loc(e.mem, _h_5)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE)
  {
    Term _raw_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY) {
      Term _fb_0[1];
      u64 _sp_0 = ctr_take(e, _raw_0, 1, _fb_0);
      Term _f_0 = _fb_0[0];
      if (term_aux(_f_0) == CID_NIL) {
        spare_free(e, cls_fit(1), _sp_0);
        r0 = 1ull;
        WL_RETN(1);
      } else {
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        Term _f_1 = _fb_1[0];
        Term _f_2 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        spare_free(e, cls_fit(1), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_2;
          STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K86;
          WL_PUSHN(2);
        } else {
          u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K86, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_2;
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K86, _t_0);
          WL_IDX = 1;
        }
        r0 = _f_1;
        _raw_0 = r0;
        WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE);
      }
    } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT) {
      Term _fb_2[1];
      u64 _sp_2 = ctr_take(e, _raw_0, 1, _fb_2);
      Term _f_4 = _fb_2[0];
      if (term_aux(_f_4) == CID_NIL) {
        spare_free(e, cls_fit(1), _sp_2);
        r0 = 1ull;
        WL_RETN(1);
      } else {
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_4, 2, _fb_3);
        Term _f_5 = _fb_3[0];
        Term _f_6 = _fb_3[1];
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_5, 2, _fb_4);
        Term _f_7 = _fb_4[0];
        Term _f_8 = _fb_4[1];
        term_sink(e, _f_7);
        spare_free(e, cls_fit(2), _sp_4);
        spare_free(e, cls_fit(2), _sp_3);
        spare_free(e, cls_fit(1), _sp_2);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_6;
          STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K88;
          WL_PUSHN(2);
        } else {
          u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K88, WL_CONT, WL_IDX, 1);
          e.mem[_t_3 + 0] = _f_6;
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K88, _t_3);
          WL_IDX = 1;
        }
        r0 = _f_8;
        _raw_0 = r0;
        WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE);
      }
    } else {
      term_sink(e, _raw_0);
      r0 = 1ull;
      WL_RETN(1);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K86)
  {
    WL_POPN(1);
    Term _f_3 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_3);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K87;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K87, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K87, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE)) {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY, _nd_0);
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE, _t_2);
    }
    r0 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAY, _nd_0);
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K87)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    r0 = nat_chk(e, _h_2 + _h_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K88)
  {
    WL_POPN(1);
    Term _f_9 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = rfc_seal(e, _f_9);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_3;
      STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K89;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K89, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_3;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K89, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE)) {
      u64 _t_5 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT, _nd_1);
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE, _t_5);
    }
    r0 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_OBJECT, _nd_1);
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE_K89)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    r0 = nat_chk(e, _h_5 + _h_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE)
  {
    Term _codec_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NULLABLE) {
      Term _fb_0[1];
      u64 _sp_0 = ctr_take(e, _codec_0, 1, _fb_0);
      Term _f_0 = _fb_0[0];
      spare_free(e, cls_fit(1), _sp_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K91;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K91, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K91, _t_0);
        WL_IDX = 0;
      }
      r0 = _f_0;
      _codec_0 = r0;
      WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE);
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_ARRAYVALUE) {
      Term _fb_1[1];
      u64 _sp_1 = ctr_take(e, _codec_0, 1, _fb_1);
      Term _f_1 = _fb_1[0];
      spare_free(e, cls_fit(1), _sp_1);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K92;
        WL_PUSHN(1);
      } else {
        u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K92, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K92, _t_1);
        WL_IDX = 0;
      }
      r0 = _f_1;
      _codec_0 = r0;
      WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE);
    } else if (term_aux(_codec_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT) {
      Term _fb_2[1];
      u64 _sp_2 = ctr_take(e, _codec_0, 1, _fb_2);
      Term _f_2 = _fb_2[0];
      if (term_aux(_f_2) == CID_NIL) {
        spare_free(e, cls_fit(1), _sp_2);
        r0 = 1ull;
        WL_RETN(1);
      } else {
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_2, 2, _fb_3);
        Term _f_3 = _fb_3[0];
        Term _f_4 = _fb_3[1];
        Term _fb_4[2];
        u64 _sp_4 = ctr_take(e, _f_3, 2, _fb_4);
        Term _f_5 = _fb_4[0];
        Term _f_6 = _fb_4[1];
        term_sink(e, _f_5);
        spare_free(e, cls_fit(2), _sp_4);
        spare_free(e, cls_fit(2), _sp_3);
        spare_free(e, cls_fit(1), _sp_2);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_4;
          STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K93;
          WL_PUSHN(2);
        } else {
          u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K93, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _f_4;
          WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K93, _t_2);
          WL_IDX = 1;
        }
        r0 = _f_6;
        _codec_0 = r0;
        WL_AGAIN(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE);
      }
    } else {
      term_sink(e, _codec_0);
      r0 = 1ull;
      WL_RETN(1);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K91)
  {
    Term _h_0 = r0;
    WL_OPEN
    r0 = nat_chk(e, 1ull + _h_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K92)
  {
    Term _h_1 = r0;
    WL_OPEN
    r0 = nat_chk(e, 1ull + _h_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K93)
  {
    WL_POPN(1);
    Term _f_7 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_7);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K94;
      WL_PUSHN(2);
    } else {
      u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K94, WL_CONT, WL_IDX, 1);
      e.mem[_t_3 + 0] = _h_2;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K94, _t_3);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE)) {
      u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT, _nd_0);
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE, _t_4);
    }
    r0 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_STRUCT, _nd_0);
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE_K94)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    r0 = nat_chk(e, 1ull + nat_chk(e, _h_4 + _h_3));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0)
  {
    Term _fuel_0 = r0;
    Term _codec_0 = r1;
    Term _input_0 = r2;
    Term _input_1 = r3;
    u32 _input_2 = r4;
    Term _input_3 = r5;
    WL_OPEN
    _input_3 = term_keep(e, _input_3, 1);
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, _codec_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _input_3);
    e.mem[_nd_0 + 2] = rfc_seal(e, term_ctr(CID_SCON, STAT_OFF + 139));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_WORK, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(4);
      STK(0) = _input_0;
      STK(1) = _input_1;
      STK(2) = _input_2;
      STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0_K96;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0_K96, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _input_0;
      e.mem[_t_0 + 1] = _input_1;
      e.mem[_t_0 + 2] = _input_2;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0_K96, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE)) {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _fuel_0;
      e.mem[_t_1 + 1] = 0;
      e.mem[_t_1 + 2] = term_ctr(CID_CON, _nd_1);
      e.mem[_t_1 + 3] = 0;
      e.mem[_t_1 + 4] = 0;
      e.mem[_t_1 + 5] = 0;
      e.mem[_t_1 + 6] = _input_3;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE, _t_1);
    }
    r0 = _fuel_0;
    r1 = 0;
    r2 = term_ctr(CID_CON, _nd_1);
    r3 = 0;
    r4 = 0;
    r5 = 0;
    r6 = _input_3;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_VALIDATE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0_K96)
  {
    WL_POPN(3);
    Term _input_4 = STK(0);
    Term _input_5 = STK(1);
    u32 _input_6 = STK(2);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    WL_OPEN
    r0 = _input_4;
    r1 = _input_5;
    r2 = _input_6;
    r3 = _h_0;
    r4 = _h_1;
    r5 = _h_2;
    r6 = _h_3;
    r7 = _h_4;
    WL_RETN(8);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET)
  {
    Term _codec_0 = r0;
    Term _raw_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _raw_0;
      STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K101;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K101, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _raw_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K101, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE)) {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _codec_0;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE, _t_1);
    }
    r0 = _codec_0;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_CODEC_SIZE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K101)
  {
    WL_POPN(1);
    Term _raw_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K102;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K102, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K102, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE)) {
      u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _raw_1;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE, _t_3);
    }
    r0 = _raw_1;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_RAW_SIZE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET_K102)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    r0 = nat_mul(e, 4ull, nat_mul(e, _h_2, nat_chk(e, _h_1 + 1ull)));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_BUILT_C115)
  {
    Term _wire_1 = r0;
    u32 _fail_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _x_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _o_1[3];
    if (spin_28(e, _o_1, _wire_1, blk_loc(e.mem, _wire_1), _fail_1, _f_0, blk_loc(e.mem, _f_0), _f_1) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_12 = _o_1[1];
    _v_13 = _o_1[2];
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_11);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_12);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_13);
    r0 = term_ctr(CID_INCOMING, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0)
  {
    Term _codec_0 = r0;
    Term _owner_0 = r1;
    Term _owner_1 = r2;
    u32 _owner_2 = r3;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[4];
    if (spin_31(e, _o_0, _owner_0, blk_loc(e.mem, _owner_0), _owner_1, blk_loc(e.mem, _owner_1), _owner_2) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_5 = _o_0[1];
    _v_6 = _o_0[2];
    _v_7 = _o_0[3];
    _v_0 = _v_4;
    _v_1 = _v_5;
    _v_2 = _v_6;
    _v_3 = _v_7;
    _codec_0 = term_keep(e, _codec_0, 1);
    _v_3 = term_keep(e, _v_3, 1);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _codec_0;
      STK(1) = _v_0;
      STK(2) = _v_1;
      STK(3) = _v_2;
      STK(4) = _v_3;
      STK(5) = FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K118;
      WL_PUSHN(6);
    } else {
      u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K118, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _codec_0;
      e.mem[_t_0 + 1] = _v_0;
      e.mem[_t_0 + 2] = _v_1;
      e.mem[_t_0 + 3] = _v_2;
      e.mem[_t_0 + 4] = _v_3;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K118, _t_0);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET)) {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _codec_0;
      e.mem[_t_1 + 1] = _v_3;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET, _t_1);
    }
    r0 = _codec_0;
    r1 = _v_3;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_SIZE_BUDGET);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K118)
  {
    WL_POPN(5);
    Term _codec_1 = STK(0);
    Term _v_12 = STK(1);
    Term _v_13 = STK(2);
    u32 _v_14 = STK(3);
    Term _v_15 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    _codec_1 = term_keep(e, _codec_1, 1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _codec_1;
      STK(1) = _h_0;
      STK(2) = FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K119;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K119, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _codec_1;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K119, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0)) {
      u64 _t_3 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _codec_1;
      e.mem[_t_3 + 2] = _v_12;
      e.mem[_t_3 + 3] = _v_13;
      e.mem[_t_3 + 4] = _v_14;
      e.mem[_t_3 + 5] = _v_15;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0, _t_3);
    }
    r0 = _h_0;
    r1 = _codec_1;
    r2 = _v_12;
    r3 = _v_13;
    r4 = _v_14;
    r5 = _v_15;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_OWNED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K119)
  {
    WL_POPN(2);
    Term _codec_2 = STK(0);
    Term _h_9 = STK(1);
    Term _h_1 = r0;
    Term _h_2 = r1;
    u32 _h_3 = r2;
    u32 _h_4 = r3;
    Term _h_5 = r4;
    Term _h_6 = r5;
    Term _h_7 = r6;
    Term _h_8 = r7;
    WL_OPEN
    if (_h_4 == 0) {
      if (seq) {
        WL_ROOM(4);
        STK(0) = _h_1;
        STK(1) = _h_2;
        STK(2) = _h_3;
        STK(3) = FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K120;
        WL_PUSHN(4);
      } else {
        u64 _t_4 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K120, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _h_1;
        e.mem[_t_4 + 1] = _h_2;
        e.mem[_t_4 + 2] = _h_3;
        WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K120, _t_4);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL)) {
        u64 _t_5 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _h_9;
        e.mem[_t_5 + 1] = _codec_2;
        e.mem[_t_5 + 2] = _h_5;
        return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL, _t_5);
      }
      r0 = _h_9;
      r1 = _codec_2;
      r2 = _h_5;
      WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DATA_CANONICAL);
    } else {
      term_sink(e, _codec_2);
      r0 = _h_1;
      r1 = _h_2;
      r2 = _h_3;
      r3 = 1;
      r4 = _h_5;
      r5 = _h_6;
      r6 = _h_7;
      r7 = _h_8;
      WL_RETN(8);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0_K120)
  {
    WL_POPN(3);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    u32 _h_13 = STK(2);
    Term _h_10 = r0;
    WL_OPEN
    r0 = _h_11;
    r1 = _h_12;
    r2 = _h_13;
    r3 = 0;
    r4 = _h_10;
    r5 = 0;
    r6 = 0;
    r7 = 0;
    WL_RETN(8);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0)
  {
    Term _factory_0 = r0;
    Term _factory_1 = r1;
    Term _input_0 = r2;
    Term _input_1 = r3;
    u32 _input_2 = r4;
    WL_OPEN
    term_sink(e, _factory_0);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0_K123;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0_K123, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0_K123, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0)) {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _factory_1;
      e.mem[_t_1 + 1] = _input_0;
      e.mem[_t_1 + 2] = _input_1;
      e.mem[_t_1 + 3] = _input_2;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0, _t_1);
    }
    r0 = _factory_1;
    r1 = _input_0;
    r2 = _input_1;
    r3 = _input_2;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_DECODE_OWNER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0_K123)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _o_2[9];
    if (spin_34(e, _o_2, _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, _h_3, _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7)) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    _v_1 = _o_2[1];
    _v_2 = _o_2[2];
    _v_3 = _o_2[3];
    _v_4 = _o_2[4];
    _v_5 = _o_2[5];
    _v_6 = _o_2[6];
    _v_7 = _o_2[7];
    _v_8 = _o_2[8];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0)
  {
    Term _factory_0 = r0;
    Term _factory_1 = r1;
    Term _input_0 = r2;
    Term _input_1 = r3;
    u32 _input_2 = r4;
    WL_OPEN
    _factory_0 = term_keep(e, _factory_0, 1);
    _factory_1 = term_keep(e, _factory_1, 1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _factory_0;
      STK(1) = _factory_1;
      STK(2) = FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0_K127;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0_K127, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _factory_0;
      e.mem[_t_0 + 1] = _factory_1;
      WL_CONT = term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0_K127, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0)) {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _factory_0;
      e.mem[_t_1 + 1] = _factory_1;
      e.mem[_t_1 + 2] = _input_0;
      e.mem[_t_1 + 3] = _input_1;
      e.mem[_t_1 + 4] = _input_2;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0, _t_1);
    }
    r0 = _factory_0;
    r1 = _factory_1;
    r2 = _input_0;
    r3 = _input_1;
    r4 = _input_2;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_CONSTRUCT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0_K127)
  {
    WL_POPN(2);
    Term _factory_2 = STK(0);
    Term _factory_3 = STK(1);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    u32 _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    WL_OPEN
    r0 = _factory_2;
    r1 = _factory_3;
    r2 = _h_0;
    r3 = _h_1;
    r4 = _h_2;
    r5 = _h_3;
    r6 = _h_4;
    r7 = _h_5;
    r8 = _h_6;
    r9 = _h_7;
    r10 = _h_8;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = _ys_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_APPEND_K130;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_APPEND_K130, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_APPEND_K130, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _ys_0;
      _xs_0 = r0;
      _ys_0 = r1;
      WL_AGAIN(FID_LIST_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND_K130)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_0)
  {
    Term _context_0 = r0;
    Term _context_1 = r1;
    Term _context_2 = r2;
    Term _context_3 = r3;
    Term _owner_0 = r4;
    u32 _owner_1 = r5;
    u32 _owner_2 = r6;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _context_0;
      STK(1) = _context_1;
      STK(2) = _context_2;
      STK(3) = _owner_0;
      STK(4) = _owner_1;
      STK(5) = _owner_2;
      STK(6) = FID_TAIL_0_K141;
      WL_PUSHN(7);
    } else {
      u64 _t_0 = task_node(e, FID_TAIL_0_K141, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _context_0;
      e.mem[_t_0 + 1] = _context_1;
      e.mem[_t_0 + 2] = _context_2;
      e.mem[_t_0 + 3] = _owner_0;
      e.mem[_t_0 + 4] = _owner_1;
      e.mem[_t_0 + 5] = _owner_2;
      WL_CONT = term_tsk(FID_TAIL_0_K141, _t_0);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _context_3;
      e.mem[_t_1 + 1] = term_ctr(CID_CON, STAT_OFF + 147);
      return term_tsk(FID_LIST_APPEND, _t_1);
    }
    r0 = _context_3;
    r1 = term_ctr(CID_CON, STAT_OFF + 147);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_0_K141)
  {
    WL_POPN(6);
    Term _context_4 = STK(0);
    Term _context_5 = STK(1);
    Term _context_6 = STK(2);
    Term _owner_3 = STK(3);
    u32 _owner_4 = STK(4);
    u32 _owner_5 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    r0 = 0;
    r1 = _context_4;
    r2 = _context_5;
    r3 = _context_6;
    r4 = _h_0;
    r5 = _owner_3;
    r6 = _owner_4;
    r7 = _owner_5;
    r8 = term_clo(FID_TAIL_0_C142, 0);
    r9 = term_ctr(CID_CON, STAT_OFF + 149);
    WL_RETN(10);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_0_C142)
  {
    Term _x_0 = r0;
    WL_OPEN
    u64 _sp_0 = term_loc(_x_0);
    Term _f_0 = e.mem[_sp_0 + 0];
    u32 _f_1 = e.mem[_sp_0 + 1];
    u32 _f_2 = e.mem[_sp_0 + 2];
    heap_free(e, cls_fit(3), _sp_0);
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _f_1;
    e.mem[_nd_0 + 2] = _f_2;
    r0 = term_ctr(CID_TAIL, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_HEAD_0)
  {
    Term _ctx_0 = r0;
    Term _ctx_1 = r1;
    Term _ctx_2 = r2;
    Term _ctx_3 = r3;
    Term _input_0 = r4;
    Term _input_1 = r5;
    u32 _input_2 = r6;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[4];
    if (spin_37(e, _o_0, _ctx_0, blk_loc(e.mem, _ctx_0), _ctx_1, blk_loc(e.mem, _ctx_1), _ctx_2, blk_loc(e.mem, _ctx_2), _ctx_3, blk_loc(e.mem, _ctx_3)) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_5 = _o_0[1];
    _v_6 = _o_0[2];
    _v_7 = _o_0[3];
    _v_0 = _v_4;
    _v_1 = _v_5;
    _v_2 = _v_6;
    _v_3 = _v_7;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _v_2;
      STK(1) = _v_3;
      STK(2) = FID_HEAD_HEAD_0_K150;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_HEAD_HEAD_0_K150, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _v_2;
      e.mem[_t_0 + 1] = _v_3;
      WL_CONT = term_tsk(FID_HEAD_HEAD_0_K150, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0)) {
      u64 _t_1 = task_node(e, FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      e.mem[_t_1 + 1] = _v_1;
      e.mem[_t_1 + 2] = _input_0;
      e.mem[_t_1 + 3] = _input_1;
      e.mem[_t_1 + 4] = _input_2;
      return term_tsk(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0, _t_1);
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _input_0;
    r3 = _input_1;
    r4 = _input_2;
    WL_JMP(FID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_FALLIBLE_REQUEST_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_HEAD_0_K150)
  {
    WL_POPN(2);
    Term _v_12 = STK(0);
    Term _v_13 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    WL_OPEN
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _o_1[13];
    if (spin_36(e, _o_1, _v_12, blk_loc(e.mem, _v_12), _v_13, blk_loc(e.mem, _v_13), _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1), _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, _h_7, _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10)) == 0) {
      return 0;
    }
    _v_14 = _o_1[0];
    _v_15 = _o_1[1];
    _v_16 = _o_1[2];
    _v_17 = _o_1[3];
    _v_18 = _o_1[4];
    _v_19 = _o_1[5];
    _v_20 = _o_1[6];
    _v_21 = _o_1[7];
    _v_22 = _o_1[8];
    _v_23 = _o_1[9];
    _v_24 = _o_1[10];
    _v_25 = _o_1[11];
    _v_26 = _o_1[12];
    r0 = _v_14;
    r1 = _v_15;
    r2 = _v_16;
    r3 = _v_17;
    r4 = _v_18;
    r5 = _v_19;
    r6 = _v_20;
    r7 = _v_21;
    r8 = _v_22;
    r9 = _v_23;
    r10 = _v_24;
    r11 = _v_25;
    r12 = _v_26;
    WL_RETN(13);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WIRE)
  {
    Term _raw_0 = r0;
    WL_OPEN
    if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER) {
      u32 _n_0 = term_loc(_raw_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_WIRE_K169;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_WIRE_K169, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_WIRE_K169, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _n_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _n_0;
      WL_JMP(FID_U32_SHOW);
    } else if (term_aux(_raw_0) == CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT) {
      Term _fb_0[1];
      u64 _sp_0 = ctr_take(e, _raw_0, 1, _fb_0);
      Term _f_0 = _fb_0[0];
      spare_free(e, cls_fit(1), _sp_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_WIRE_K171;
        WL_PUSHN(1);
      } else {
        u64 _t_5 = task_node(e, FID_WIRE_K171, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_WIRE_K171, _t_5);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_6 + 0] = _f_0;
        e.mem[_t_6 + 1] = term_ctr(CID_SCON, STAT_OFF + 153);
        return term_tsk(FID_STRING_APPEND, _t_6);
      }
      r0 = _f_0;
      r1 = term_ctr(CID_SCON, STAT_OFF + 153);
      WL_JMP(FID_STRING_APPEND);
    } else {
      term_sink(e, _raw_0);
      r0 = term_ctr(CID_SCON, STAT_OFF + 295);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WIRE_K169)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_WIRE_K170;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_WIRE_K170, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_WIRE_K170, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 153);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 153);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WIRE_K170)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = term_ctr(CID_SCON, STAT_OFF + 267);
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 267);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_WIRE_K171)
  {
    Term _h_2 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 275);
      e.mem[_t_7 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 275);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 151);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_2)
  {
    Term _xs_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 2);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_SHOW_GO_2_K180;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_2_K180, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_2_K180, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _xs_0 = r0;
      WL_AGAIN(FID_LIST_SHOW_GO_2);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_2_K180)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_2_K181;
      WL_PUSHN(1);
    } else {
      u64 _t_1 = task_node(e, FID_LIST_SHOW_GO_2_K181, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_2_K181, _t_1);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_2);
    }
    r0 = _f_2;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_2_K181)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 301);
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 301);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 2);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      u32 _o_2 = 0;
      Term _o_3 = 0;
      Term _o_4 = 0;
      Term _o_5 = 0;
      if (term_aux(_f_0) == CID_NONE) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        u32 _o_6 = 0;
        u32 _o_7 = 0;
        Term _o_8 = 0;
        Term _o_9 = 0;
        Term _o_10 = 0;
        if (term_aux(_f_2) == CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_VALIDATION) {
          _o_6 = 0;
          Term _fb_2[4];
          u64 _sp_2 = ctr_take(e, _f_2, 4, _fb_2);
          u32 _f_3 = _fb_2[0];
          Term _f_4 = _fb_2[1];
          Term _f_5 = _fb_2[2];
          Term _f_6 = _fb_2[3];
          spare_free(e, cls_fit(4), _sp_2);
          _o_7 = _f_3;
          _o_8 = _f_4;
          _o_9 = _f_5;
          _o_10 = _f_6;
        } else {
          _o_6 = 1;
          Term _fb_3[1];
          u64 _sp_3 = ctr_take(e, _f_2, 1, _fb_3);
          Term _f_7 = _fb_3[0];
          spare_free(e, cls_fit(1), _sp_3);
        }
        _o_1 = _o_6;
        _o_2 = _o_7;
        _o_3 = _o_8;
        _o_4 = _o_9;
        _o_5 = _o_10;
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_GO_1_K197;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_GO_1_K197, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K197, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_POSITION)) {
        u64 _t_1 = task_node(e, FID_POSITION, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        e.mem[_t_1 + 5] = _o_5;
        return term_tsk(FID_POSITION, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      r5 = _o_5;
      WL_JMP(FID_POSITION);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K197)
  {
    WL_POPN(1);
    Term _f_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_GO_1_K198;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_GO_1_K198, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K198, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_1)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_8;
      return term_tsk(FID_LIST_SHOW_GO_1, _t_3);
    }
    r0 = _f_8;
    WL_JMP(FID_LIST_SHOW_GO_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K198)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_GO_1_K199;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_GO_1_K199, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_GO_1_K199, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_GO_1_K199)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 301);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 301);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    Term _value_3 = r3;
    Term _value_4 = r4;
    Term _value_5 = r5;
    WL_OPEN
    if (_value_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 323);
      WL_RETN(1);
    } else {
      if (_value_1 == 1) {
        r0 = term_ctr(CID_SCON, STAT_OFF + 191);
        WL_RETN(1);
      } else {
        if (_value_2 == 0) {
          if (seq) {
            WL_ROOM(3);
            STK(0) = _value_3;
            STK(1) = _value_4;
            STK(2) = FID_POSITION_K201;
            WL_PUSHN(3);
          } else {
            u64 _t_0 = task_node(e, FID_POSITION_K201, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _value_3;
            e.mem[_t_0 + 1] = _value_4;
            WL_CONT = term_tsk(FID_POSITION_K201, _t_0);
            WL_IDX = 2;
          }
          if (!DEVICE && !seq && fid_nofk(FID_WIRE)) {
            u64 _t_1 = task_node(e, FID_WIRE, WL_CONT, WL_IDX, 0);
            e.mem[_t_1 + 0] = _value_5;
            return term_tsk(FID_WIRE, _t_1);
          }
          r0 = _value_5;
          WL_JMP(FID_WIRE);
        } else {
          if (seq) {
            WL_ROOM(1);
            STK(0) = FID_POSITION_K207;
            WL_PUSHN(1);
          } else {
            u64 _t_13 = task_node(e, FID_POSITION_K207, WL_CONT, WL_IDX, 1);
            WL_CONT = term_tsk(FID_POSITION_K207, _t_13);
            WL_IDX = 0;
          }
          if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
            u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
            e.mem[_t_14 + 0] = _value_3;
            e.mem[_t_14 + 1] = term_ctr(CID_SCON, STAT_OFF + 153);
            return term_tsk(FID_STRING_APPEND, _t_14);
          }
          r0 = _value_3;
          r1 = term_ctr(CID_SCON, STAT_OFF + 153);
          WL_JMP(FID_STRING_APPEND);
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K201)
  {
    WL_POPN(2);
    Term _value_6 = STK(0);
    Term _value_7 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_6;
      STK(1) = _value_7;
      STK(2) = FID_POSITION_K202;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_POSITION_K202, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_6;
      e.mem[_t_2 + 1] = _value_7;
      WL_CONT = term_tsk(FID_POSITION_K202, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 153);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 153);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K202)
  {
    WL_POPN(2);
    Term _value_8 = STK(0);
    Term _value_9 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_8;
      STK(1) = _value_9;
      STK(2) = FID_POSITION_K203;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_POSITION_K203, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_8;
      e.mem[_t_4 + 1] = _value_9;
      WL_CONT = term_tsk(FID_POSITION_K203, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 193);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 193);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K203)
  {
    WL_POPN(2);
    Term _value_10 = STK(0);
    Term _value_11 = STK(1);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_10;
      STK(1) = FID_POSITION_K204;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_POSITION_K204, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _value_10;
      WL_CONT = term_tsk(FID_POSITION_K204, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _value_11;
      e.mem[_t_7 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _value_11;
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K204)
  {
    WL_POPN(1);
    Term _value_12 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_12;
      STK(1) = FID_POSITION_K205;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_POSITION_K205, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _value_12;
      WL_CONT = term_tsk(FID_POSITION_K205, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 193);
      e.mem[_t_9 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 193);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K205)
  {
    WL_POPN(1);
    Term _value_13 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_POSITION_K206;
      WL_PUSHN(1);
    } else {
      u64 _t_10 = task_node(e, FID_POSITION_K206, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_POSITION_K206, _t_10);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _value_13;
      e.mem[_t_11 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = _value_13;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K206)
  {
    Term _h_5 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 215);
      e.mem[_t_12 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 215);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K207)
  {
    Term _h_6 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 241);
      e.mem[_t_15 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 241);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE)
  {
    Term _owner_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_owner_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _owner_0), 0 + 0);
      blk_free(e, _owner_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _c_0;
        STK(1) = FID_TREE_K226;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_TREE_K226, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _c_0;
        WL_CONT = term_tsk(FID_TREE_K226, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _c_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _c_0;
      WL_JMP(FID_U32_SHOW);
    } else {
      Term _h_3 = blk_half(e, _owner_0, 0);
      Term _h_4 = blk_half(e, _owner_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_4;
        STK(1) = FID_TREE_K229;
        WL_PUSHN(2);
      } else {
        u64 _t_6 = task_node(e, FID_TREE_K229, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _h_4;
        WL_CONT = term_tsk(FID_TREE_K229, _t_6);
        WL_IDX = 1;
      }
      r0 = _h_3;
      _owner_0 = r0;
      WL_AGAIN(FID_TREE);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K226)
  {
    WL_POPN(1);
    u32 _c_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _c_1;
      STK(1) = FID_TREE_K227;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_TREE_K227, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _c_1;
      WL_CONT = term_tsk(FID_TREE_K227, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 153);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 153);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K227)
  {
    WL_POPN(1);
    u32 _c_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _c_2;
      STK(1) = FID_TREE_K228;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_TREE_K228, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _c_2;
      WL_CONT = term_tsk(FID_TREE_K228, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 365);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 365);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K228)
  {
    WL_POPN(1);
    u32 _c_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _c_3;
    r0 = blk_new(e, 0, 0, 0, 1, _fv_0);
    r1 = _h_2;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K229)
  {
    WL_POPN(1);
    Term _h_7 = STK(0);
    Term _h_5 = r0;
    Term _h_6 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_5;
      STK(1) = _h_6;
      STK(2) = FID_TREE_K230;
      WL_PUSHN(3);
    } else {
      u64 _t_7 = task_node(e, FID_TREE_K230, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_5;
      e.mem[_t_7 + 1] = _h_6;
      WL_CONT = term_tsk(FID_TREE_K230, _t_7);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TREE)) {
      u64 _t_8 = task_node(e, FID_TREE, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_7;
      return term_tsk(FID_TREE, _t_8);
    }
    r0 = _h_7;
    WL_JMP(FID_TREE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K230)
  {
    WL_POPN(2);
    Term _h_10 = STK(0);
    Term _h_11 = STK(1);
    Term _h_8 = r0;
    Term _h_9 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_10;
      STK(1) = _h_11;
      STK(2) = _h_8;
      STK(3) = FID_TREE_K231;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_TREE_K231, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_10;
      e.mem[_t_9 + 1] = _h_11;
      e.mem[_t_9 + 2] = _h_8;
      WL_CONT = term_tsk(FID_TREE_K231, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_9;
      e.mem[_t_10 + 1] = term_ctr(CID_SCON, STAT_OFF + 153);
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_9;
    r1 = term_ctr(CID_SCON, STAT_OFF + 153);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K231)
  {
    WL_POPN(3);
    Term _h_13 = STK(0);
    Term _h_14 = STK(1);
    Term _h_15 = STK(2);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_13;
      STK(1) = _h_14;
      STK(2) = _h_15;
      STK(3) = FID_TREE_K232;
      WL_PUSHN(4);
    } else {
      u64 _t_11 = task_node(e, FID_TREE_K232, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_13;
      e.mem[_t_11 + 1] = _h_14;
      e.mem[_t_11 + 2] = _h_15;
      WL_CONT = term_tsk(FID_TREE_K232, _t_11);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 193);
      e.mem[_t_12 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 193);
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K232)
  {
    WL_POPN(3);
    Term _h_17 = STK(0);
    Term _h_18 = STK(1);
    Term _h_19 = STK(2);
    Term _h_16 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_17;
      STK(1) = _h_19;
      STK(2) = FID_TREE_K233;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_TREE_K233, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_17;
      e.mem[_t_13 + 1] = _h_19;
      WL_CONT = term_tsk(FID_TREE_K233, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_18;
      e.mem[_t_14 + 1] = _h_16;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = _h_18;
    r1 = _h_16;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K233)
  {
    WL_POPN(2);
    Term _h_21 = STK(0);
    Term _h_22 = STK(1);
    Term _h_20 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_21;
      STK(1) = _h_22;
      STK(2) = FID_TREE_K234;
      WL_PUSHN(3);
    } else {
      u64 _t_15 = task_node(e, FID_TREE_K234, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _h_21;
      e.mem[_t_15 + 1] = _h_22;
      WL_CONT = term_tsk(FID_TREE_K234, _t_15);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 297);
      e.mem[_t_16 + 1] = _h_20;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 297);
    r1 = _h_20;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TREE_K234)
  {
    WL_POPN(2);
    Term _h_24 = STK(0);
    Term _h_25 = STK(1);
    Term _h_23 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_24, _h_25);
    r1 = _h_23;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_2)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 465);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_SHOW_2_K242;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_2_K242, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_SHOW_2_K242, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_2)) {
        u64 _t_1 = task_node(e, FID_LIST_SHOW_GO_2, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_1;
        return term_tsk(FID_LIST_SHOW_GO_2, _t_1);
      }
      r0 = _f_1;
      WL_JMP(FID_LIST_SHOW_GO_2);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_2_K242)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_2_K243;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_2_K243, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_2_K243, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _f_2;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_2_K243)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0)
  {
    Term _ctx_0 = r0;
    Term _ctx_1 = r1;
    Term _ctx_2 = r2;
    Term _ctx_3 = r3;
    Term _input_0 = r4;
    Term _input_1 = r5;
    u32 _input_2 = r6;
    Term _input_3 = r7;
    u32 _input_4 = r8;
    u32 _input_5 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _input_3;
      STK(1) = _input_4;
      STK(2) = _input_5;
      STK(3) = FID_HEAD_STAGE_0_K245;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_HEAD_STAGE_0_K245, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _input_3;
      e.mem[_t_0 + 1] = _input_4;
      e.mem[_t_0 + 2] = _input_5;
      WL_CONT = term_tsk(FID_HEAD_STAGE_0_K245, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEAD_HEAD_0)) {
      u64 _t_1 = task_node(e, FID_HEAD_HEAD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _ctx_0;
      e.mem[_t_1 + 1] = _ctx_1;
      e.mem[_t_1 + 2] = _ctx_2;
      e.mem[_t_1 + 3] = _ctx_3;
      e.mem[_t_1 + 4] = _input_0;
      e.mem[_t_1 + 5] = _input_1;
      e.mem[_t_1 + 6] = _input_2;
      return term_tsk(FID_HEAD_HEAD_0, _t_1);
    }
    r0 = _ctx_0;
    r1 = _ctx_1;
    r2 = _ctx_2;
    r3 = _ctx_3;
    r4 = _input_0;
    r5 = _input_1;
    r6 = _input_2;
    WL_JMP(FID_HEAD_HEAD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0_K245)
  {
    WL_POPN(3);
    Term _input_6 = STK(0);
    u32 _input_7 = STK(1);
    u32 _input_8 = STK(2);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    WL_OPEN
    if (_h_4 == 0) {
      if (seq) {
        WL_ROOM(4);
        STK(0) = _h_5;
        STK(1) = _h_6;
        STK(2) = _h_7;
        STK(3) = FID_HEAD_STAGE_0_K246;
        WL_PUSHN(4);
      } else {
        u64 _t_2 = task_node(e, FID_HEAD_STAGE_0_K246, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _h_5;
        e.mem[_t_2 + 1] = _h_6;
        e.mem[_t_2 + 2] = _h_7;
        WL_CONT = term_tsk(FID_HEAD_STAGE_0_K246, _t_2);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_TAIL_0)) {
        u64 _t_3 = task_node(e, FID_TAIL_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_0;
        e.mem[_t_3 + 1] = _h_1;
        e.mem[_t_3 + 2] = _h_2;
        e.mem[_t_3 + 3] = _h_3;
        e.mem[_t_3 + 4] = _input_6;
        e.mem[_t_3 + 5] = _input_7;
        e.mem[_t_3 + 6] = _input_8;
        return term_tsk(FID_TAIL_0, _t_3);
      }
      r0 = _h_0;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _input_6;
      r5 = _input_7;
      r6 = _input_8;
      WL_JMP(FID_TAIL_0);
    } else {
      if (seq) {
        WL_ROOM(9);
        STK(0) = _h_5;
        STK(1) = _h_6;
        STK(2) = _h_7;
        STK(3) = _h_8;
        STK(4) = _h_9;
        STK(5) = _h_10;
        STK(6) = _h_11;
        STK(7) = _h_12;
        STK(8) = FID_HEAD_STAGE_0_K251;
        WL_PUSHN(9);
      } else {
        u64 _t_10 = task_node(e, FID_HEAD_STAGE_0_K251, WL_CONT, WL_IDX, 1);
        e.mem[_t_10 + 0] = _h_5;
        e.mem[_t_10 + 1] = _h_6;
        e.mem[_t_10 + 2] = _h_7;
        e.mem[_t_10 + 3] = _h_8;
        e.mem[_t_10 + 4] = _h_9;
        e.mem[_t_10 + 5] = _h_10;
        e.mem[_t_10 + 6] = _h_11;
        e.mem[_t_10 + 7] = _h_12;
        WL_CONT = term_tsk(FID_HEAD_STAGE_0_K251, _t_10);
        WL_IDX = 8;
      }
      if (!DEVICE && !seq && fid_nofk(FID_TAIL_0)) {
        u64 _t_11 = task_node(e, FID_TAIL_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_11 + 0] = _h_0;
        e.mem[_t_11 + 1] = _h_1;
        e.mem[_t_11 + 2] = _h_2;
        e.mem[_t_11 + 3] = _h_3;
        e.mem[_t_11 + 4] = _input_6;
        e.mem[_t_11 + 5] = _input_7;
        e.mem[_t_11 + 6] = _input_8;
        return term_tsk(FID_TAIL_0, _t_11);
      }
      r0 = _h_0;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _input_6;
      r5 = _input_7;
      r6 = _input_8;
      WL_JMP(FID_TAIL_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0_K246)
  {
    WL_POPN(3);
    Term _h_23 = STK(0);
    u32 _h_24 = STK(1);
    Term _h_25 = STK(2);
    u32 _h_13 = r0;
    Term _h_14 = r1;
    Term _h_15 = r2;
    Term _h_16 = r3;
    Term _h_17 = r4;
    Term _h_18 = r5;
    u32 _h_19 = r6;
    u32 _h_20 = r7;
    Term _h_21 = r8;
    Term _h_22 = r9;
    WL_OPEN
    if (_h_13 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _h_25;
      e.mem[_nd_0 + 1] = _h_21;
      u64 _nd_4 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_4 + 0] = rfc_seal(e, term_pak(CID_NONE, 0));
      e.mem[_nd_4 + 1] = rfc_seal(e, _h_22);
      r0 = 0;
      r1 = _h_14;
      r2 = _h_15;
      r3 = _h_16;
      r4 = _h_17;
      r5 = _h_23;
      r6 = _h_24;
      r7 = _h_18;
      r8 = _h_19;
      r9 = _h_20;
      r10 = term_clo(FID_HEAD_STAGE_0_C247, _nd_0);
      r11 = term_ctr(CID_CON, _nd_4);
      WL_RETN(12);
    } else {
      u64 _nd_5 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_5 + 0] = rfc_seal(e, _h_23);
      e.mem[_nd_5 + 1] = rfc_seal(e, _h_24);
      if (seq) {
        WL_ROOM(9);
        STK(0) = _h_14;
        STK(1) = _h_15;
        STK(2) = _h_16;
        STK(3) = _h_17;
        STK(4) = _h_18;
        STK(5) = _h_19;
        STK(6) = _h_20;
        STK(7) = _h_21;
        STK(8) = FID_HEAD_STAGE_0_K250;
        WL_PUSHN(9);
      } else {
        u64 _t_8 = task_node(e, FID_HEAD_STAGE_0_K250, WL_CONT, WL_IDX, 1);
        e.mem[_t_8 + 0] = _h_14;
        e.mem[_t_8 + 1] = _h_15;
        e.mem[_t_8 + 2] = _h_16;
        e.mem[_t_8 + 3] = _h_17;
        e.mem[_t_8 + 4] = _h_18;
        e.mem[_t_8 + 5] = _h_19;
        e.mem[_t_8 + 6] = _h_20;
        e.mem[_t_8 + 7] = _h_21;
        WL_CONT = term_tsk(FID_HEAD_STAGE_0_K250, _t_8);
        WL_IDX = 8;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_9 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_9 + 0] = _h_25;
        e.mem[_t_9 + 1] = term_ctr(CID_PAYLOAD, _nd_5);
        return term_tsk(FID_CLO_APPLY, _t_9);
      }
      r0 = _h_25;
      r1 = term_ctr(CID_PAYLOAD, _nd_5);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0_C247)
  {
    Term _h_26 = r0;
    Term _h_27 = r1;
    Term _x_0 = r2;
    WL_OPEN
    u64 _sp_0 = term_loc(_x_0);
    Term _f_0 = e.mem[_sp_0 + 0];
    Term _f_1 = e.mem[_sp_0 + 1];
    heap_free(e, cls_fit(2), _sp_0);
    Term _fb_0[2];
    u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_0);
    Term _f_2 = _fb_0[0];
    u32 _f_3 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_1);
    u64 _sp_2 = term_loc(_f_1);
    Term _f_4 = e.mem[_sp_2 + 0];
    u32 _f_5 = e.mem[_sp_2 + 1];
    u32 _f_6 = e.mem[_sp_2 + 2];
    heap_free(e, cls_fit(3), _sp_2);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_1 + 1] = rfc_seal(e, _f_3);
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_27;
      STK(1) = _f_4;
      STK(2) = _f_5;
      STK(3) = _f_6;
      STK(4) = FID_HEAD_STAGE_0_K248;
      WL_PUSHN(5);
    } else {
      u64 _t_4 = task_node(e, FID_HEAD_STAGE_0_K248, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_27;
      e.mem[_t_4 + 1] = _f_4;
      e.mem[_t_4 + 2] = _f_5;
      e.mem[_t_4 + 3] = _f_6;
      WL_CONT = term_tsk(FID_HEAD_STAGE_0_K248, _t_4);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_5 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_26;
      e.mem[_t_5 + 1] = term_ctr(CID_PAYLOAD, _nd_1);
      return term_tsk(FID_CLO_APPLY, _t_5);
    }
    r0 = _h_26;
    r1 = term_ctr(CID_PAYLOAD, _nd_1);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0_K248)
  {
    WL_POPN(4);
    Term _h_29 = STK(0);
    Term _f_7 = STK(1);
    u32 _f_8 = STK(2);
    u32 _f_9 = STK(3);
    Term _h_28 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_2 + 0] = _f_7;
    e.mem[_nd_2 + 1] = _f_8;
    e.mem[_nd_2 + 2] = _f_9;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_28;
      STK(1) = FID_HEAD_STAGE_0_K249;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_HEAD_STAGE_0_K249, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_28;
      WL_CONT = term_tsk(FID_HEAD_STAGE_0_K249, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_7 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_29;
      e.mem[_t_7 + 1] = term_ctr(CID_TAIL, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_7);
    }
    r0 = _h_29;
    r1 = term_ctr(CID_TAIL, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0_K249)
  {
    WL_POPN(1);
    Term _h_31 = STK(0);
    Term _h_30 = r0;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = _h_31;
    e.mem[_nd_3 + 1] = _h_30;
    r0 = term_ctr(CID_________________________BENDVY_SRC_ECS_BUNDLE_PACK_PACK, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0_K250)
  {
    WL_POPN(8);
    Term _h_33 = STK(0);
    Term _h_34 = STK(1);
    Term _h_35 = STK(2);
    Term _h_36 = STK(3);
    Term _h_37 = STK(4);
    u32 _h_38 = STK(5);
    u32 _h_39 = STK(6);
    Term _h_40 = STK(7);
    Term _h_32 = r0;
    WL_OPEN
    Term _fb_1[3];
    u64 _sp_3 = ctr_take(e, _h_32, 3, _fb_1);
    Term _f_10 = _fb_1[0];
    Term _f_11 = _fb_1[1];
    u32 _f_12 = _fb_1[2];
    spare_free(e, cls_fit(3), _sp_3);
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, term_pak(CID_NONE, 0));
    e.mem[_nd_6 + 1] = rfc_seal(e, _h_40);
    r0 = 1;
    r1 = _h_33;
    r2 = _h_34;
    r3 = _h_35;
    r4 = _h_36;
    r5 = _f_10;
    r6 = _f_11;
    r7 = _f_12;
    r8 = _h_37;
    r9 = _h_38;
    r10 = _h_39;
    r11 = term_ctr(CID_CON, _nd_6);
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0_K251)
  {
    WL_POPN(8);
    Term _h_51 = STK(0);
    Term _h_52 = STK(1);
    u32 _h_53 = STK(2);
    u32 _h_54 = STK(3);
    u32 _h_55 = STK(4);
    Term _h_56 = STK(5);
    Term _h_57 = STK(6);
    Term _h_58 = STK(7);
    u32 _h_41 = r0;
    Term _h_42 = r1;
    Term _h_43 = r2;
    Term _h_44 = r3;
    Term _h_45 = r4;
    Term _h_46 = r5;
    u32 _h_47 = r6;
    u32 _h_48 = r7;
    Term _h_49 = r8;
    Term _h_50 = r9;
    WL_OPEN
    if (_h_41 == 0) {
      u64 _nd_7 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_7 + 0] = _h_46;
      e.mem[_nd_7 + 1] = _h_47;
      e.mem[_nd_7 + 2] = _h_48;
      if (seq) {
        WL_ROOM(14);
        STK(0) = _h_51;
        STK(1) = _h_52;
        STK(2) = _h_53;
        STK(3) = _h_54;
        STK(4) = _h_55;
        STK(5) = _h_56;
        STK(6) = _h_57;
        STK(7) = _h_58;
        STK(8) = _h_42;
        STK(9) = _h_43;
        STK(10) = _h_44;
        STK(11) = _h_45;
        STK(12) = _h_50;
        STK(13) = FID_HEAD_STAGE_0_K252;
        WL_PUSHN(14);
      } else {
        u64 _t_12 = task_node(e, FID_HEAD_STAGE_0_K252, WL_CONT, WL_IDX, 1);
        e.mem[_t_12 + 0] = _h_51;
        e.mem[_t_12 + 1] = _h_52;
        e.mem[_t_12 + 2] = _h_53;
        e.mem[_t_12 + 3] = _h_54;
        e.mem[_t_12 + 4] = _h_55;
        e.mem[_t_12 + 5] = _h_56;
        e.mem[_t_12 + 6] = _h_57;
        e.mem[_t_12 + 7] = _h_58;
        e.mem[_t_12 + 8] = _h_42;
        e.mem[_t_12 + 9] = _h_43;
        e.mem[_t_12 + 10] = _h_44;
        e.mem[_t_12 + 11] = _h_45;
        e.mem[_t_12 + 12] = _h_50;
        WL_CONT = term_tsk(FID_HEAD_STAGE_0_K252, _t_12);
        WL_IDX = 13;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_13 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_13 + 0] = _h_49;
        e.mem[_t_13 + 1] = term_ctr(CID_TAIL, _nd_7);
        return term_tsk(FID_CLO_APPLY, _t_13);
      }
      r0 = _h_49;
      r1 = term_ctr(CID_TAIL, _nd_7);
      WL_JMP(FID_CLO_APPLY);
    } else {
      Term _b_1 = 0;
      if (_h_54 == 0) {
        u64 _nd_12 = heap_alloc(e, cls_fit(4));
        e.mem[_nd_12 + 0] = rfc_seal(e, _h_55);
        e.mem[_nd_12 + 1] = rfc_seal(e, _h_56);
        e.mem[_nd_12 + 2] = rfc_seal(e, _h_57);
        e.mem[_nd_12 + 3] = rfc_seal(e, _h_58);
        _b_1 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_VALIDATION, _nd_12);
      } else {
        u64 _nd_13 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID_BLOCKED, 0));
        _b_1 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_CONSTRUCTOR, _nd_13);
      }
      u64 _nd_14 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_14 + 0] = rfc_seal(e, _b_1);
      u64 _nd_15 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_15 + 0] = rfc_seal(e, term_ctr(CID_SOME, _nd_14));
      e.mem[_nd_15 + 1] = rfc_seal(e, _h_49);
      r0 = 1;
      r1 = _h_42;
      r2 = _h_43;
      r3 = _h_44;
      r4 = _h_45;
      r5 = _h_51;
      r6 = _h_52;
      r7 = _h_53;
      r8 = _h_46;
      r9 = _h_47;
      r10 = _h_48;
      r11 = term_ctr(CID_CON, _nd_15);
      WL_RETN(12);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_HEAD_STAGE_0_K252)
  {
    WL_POPN(13);
    Term _h_60 = STK(0);
    Term _h_61 = STK(1);
    u32 _h_62 = STK(2);
    u32 _h_63 = STK(3);
    u32 _h_64 = STK(4);
    Term _h_65 = STK(5);
    Term _h_66 = STK(6);
    Term _h_67 = STK(7);
    Term _h_68 = STK(8);
    Term _h_69 = STK(9);
    Term _h_70 = STK(10);
    Term _h_71 = STK(11);
    Term _h_72 = STK(12);
    Term _h_59 = r0;
    WL_OPEN
    u64 _sp_4 = term_loc(_h_59);
    Term _f_13 = e.mem[_sp_4 + 0];
    u32 _f_14 = e.mem[_sp_4 + 1];
    u32 _f_15 = e.mem[_sp_4 + 2];
    heap_free(e, cls_fit(3), _sp_4);
    Term _b_0 = 0;
    if (_h_63 == 0) {
      u64 _nd_8 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_8 + 0] = rfc_seal(e, _h_64);
      e.mem[_nd_8 + 1] = rfc_seal(e, _h_65);
      e.mem[_nd_8 + 2] = rfc_seal(e, _h_66);
      e.mem[_nd_8 + 3] = rfc_seal(e, _h_67);
      _b_0 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_VALIDATION, _nd_8);
    } else {
      u64 _nd_9 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_9 + 0] = rfc_seal(e, term_pak(CID_BLOCKED, 0));
      _b_0 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_CONSTRUCTOR, _nd_9);
    }
    u64 _nd_10 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_10 + 0] = rfc_seal(e, _b_0);
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_SOME, _nd_10));
    e.mem[_nd_11 + 1] = rfc_seal(e, _h_72);
    r0 = 1;
    r1 = _h_68;
    r2 = _h_69;
    r3 = _h_70;
    r4 = _h_71;
    r5 = _h_60;
    r6 = _h_61;
    r7 = _h_62;
    r8 = _f_13;
    r9 = _f_14;
    r10 = _f_15;
    r11 = term_ctr(CID_CON, _nd_11);
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PAYLOAD_OBSERVE)
  {
    Term _owner_0 = r0;
    u32 _owner_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _owner_1;
      STK(1) = FID_PAYLOAD_OBSERVE_K258;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_PAYLOAD_OBSERVE_K258, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_1;
      WL_CONT = term_tsk(FID_PAYLOAD_OBSERVE_K258, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TREE)) {
      u64 _t_1 = task_node(e, FID_TREE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_0;
      return term_tsk(FID_TREE, _t_1);
    }
    r0 = _owner_0;
    WL_JMP(FID_TREE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PAYLOAD_OBSERVE_K258)
  {
    WL_POPN(1);
    u32 _owner_2 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _owner_2;
      STK(1) = _h_0;
      STK(2) = _h_1;
      STK(3) = FID_PAYLOAD_OBSERVE_K259;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_PAYLOAD_OBSERVE_K259, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _owner_2;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      WL_CONT = term_tsk(FID_PAYLOAD_OBSERVE_K259, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _owner_2;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _owner_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PAYLOAD_OBSERVE_K259)
  {
    WL_POPN(3);
    u32 _owner_3 = STK(0);
    Term _h_3 = STK(1);
    Term _h_4 = STK(2);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _owner_3;
      STK(1) = _h_3;
      STK(2) = _h_4;
      STK(3) = FID_PAYLOAD_OBSERVE_K260;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_PAYLOAD_OBSERVE_K260, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _owner_3;
      e.mem[_t_4 + 1] = _h_3;
      e.mem[_t_4 + 2] = _h_4;
      WL_CONT = term_tsk(FID_PAYLOAD_OBSERVE_K260, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 317);
      e.mem[_t_5 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 317);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PAYLOAD_OBSERVE_K260)
  {
    WL_POPN(3);
    u32 _owner_4 = STK(0);
    Term _h_6 = STK(1);
    Term _h_7 = STK(2);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _owner_4;
      STK(1) = _h_6;
      STK(2) = FID_PAYLOAD_OBSERVE_K261;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_PAYLOAD_OBSERVE_K261, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _owner_4;
      e.mem[_t_6 + 1] = _h_6;
      WL_CONT = term_tsk(FID_PAYLOAD_OBSERVE_K261, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_7;
      e.mem[_t_7 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_7;
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_PAYLOAD_OBSERVE_K261)
  {
    WL_POPN(2);
    u32 _owner_5 = STK(0);
    Term _h_9 = STK(1);
    Term _h_8 = r0;
    WL_OPEN
    r0 = _h_9;
    r1 = _owner_5;
    r2 = _h_8;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1)
  {
    Term _xs_0 = r0;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 465);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      u32 _o_2 = 0;
      Term _o_3 = 0;
      Term _o_4 = 0;
      Term _o_5 = 0;
      if (term_aux(_f_0) == CID_NONE) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        u32 _o_6 = 0;
        u32 _o_7 = 0;
        Term _o_8 = 0;
        Term _o_9 = 0;
        Term _o_10 = 0;
        if (term_aux(_f_2) == CID_________________________BENDVY_SRC_ECS_DECODE_CONSTRUCTION_VALIDATION) {
          _o_6 = 0;
          Term _fb_2[4];
          u64 _sp_2 = ctr_take(e, _f_2, 4, _fb_2);
          u32 _f_3 = _fb_2[0];
          Term _f_4 = _fb_2[1];
          Term _f_5 = _fb_2[2];
          Term _f_6 = _fb_2[3];
          spare_free(e, cls_fit(4), _sp_2);
          _o_7 = _f_3;
          _o_8 = _f_4;
          _o_9 = _f_5;
          _o_10 = _f_6;
        } else {
          _o_6 = 1;
          Term _fb_3[1];
          u64 _sp_3 = ctr_take(e, _f_2, 1, _fb_3);
          Term _f_7 = _fb_3[0];
          spare_free(e, cls_fit(1), _sp_3);
        }
        _o_1 = _o_6;
        _o_2 = _o_7;
        _o_3 = _o_8;
        _o_4 = _o_9;
        _o_5 = _o_10;
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_LIST_SHOW_1_K266;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_SHOW_1_K266, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_LIST_SHOW_1_K266, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_POSITION)) {
        u64 _t_1 = task_node(e, FID_POSITION, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        e.mem[_t_1 + 5] = _o_5;
        return term_tsk(FID_POSITION, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      r5 = _o_5;
      WL_JMP(FID_POSITION);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K266)
  {
    WL_POPN(1);
    Term _f_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_LIST_SHOW_1_K267;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_LIST_SHOW_1_K267, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_LIST_SHOW_1_K267, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_GO_1)) {
      u64 _t_3 = task_node(e, FID_LIST_SHOW_GO_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_8;
      return term_tsk(FID_LIST_SHOW_GO_1, _t_3);
    }
    r0 = _f_8;
    WL_JMP(FID_LIST_SHOW_GO_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K267)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LIST_SHOW_1_K268;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_LIST_SHOW_1_K268, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LIST_SHOW_1_K268, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_SHOW_1_K268)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 4);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 4);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_OBSERVE)
  {
    Term _owner_0 = r0;
    u32 _owner_1 = r1;
    u32 _owner_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _owner_1;
      STK(1) = _owner_2;
      STK(2) = FID_TAIL_OBSERVE_K276;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_TAIL_OBSERVE_K276, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_1;
      e.mem[_t_0 + 1] = _owner_2;
      WL_CONT = term_tsk(FID_TAIL_OBSERVE_K276, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TREE)) {
      u64 _t_1 = task_node(e, FID_TREE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_0;
      return term_tsk(FID_TREE, _t_1);
    }
    r0 = _owner_0;
    WL_JMP(FID_TREE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_OBSERVE_K276)
  {
    WL_POPN(2);
    u32 _owner_3 = STK(0);
    u32 _owner_4 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _owner_3;
      STK(1) = _owner_4;
      STK(2) = _h_0;
      STK(3) = _h_1;
      STK(4) = FID_TAIL_OBSERVE_K277;
      WL_PUSHN(5);
    } else {
      u64 _t_2 = task_node(e, FID_TAIL_OBSERVE_K277, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _owner_3;
      e.mem[_t_2 + 1] = _owner_4;
      e.mem[_t_2 + 2] = _h_0;
      e.mem[_t_2 + 3] = _h_1;
      WL_CONT = term_tsk(FID_TAIL_OBSERVE_K277, _t_2);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _owner_4;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _owner_4;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_OBSERVE_K277)
  {
    WL_POPN(4);
    u32 _owner_5 = STK(0);
    u32 _owner_6 = STK(1);
    Term _h_3 = STK(2);
    Term _h_4 = STK(3);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _owner_5;
      STK(1) = _owner_6;
      STK(2) = _h_3;
      STK(3) = _h_4;
      STK(4) = FID_TAIL_OBSERVE_K278;
      WL_PUSHN(5);
    } else {
      u64 _t_4 = task_node(e, FID_TAIL_OBSERVE_K278, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _owner_5;
      e.mem[_t_4 + 1] = _owner_6;
      e.mem[_t_4 + 2] = _h_3;
      e.mem[_t_4 + 3] = _h_4;
      WL_CONT = term_tsk(FID_TAIL_OBSERVE_K278, _t_4);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 335);
      e.mem[_t_5 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 335);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_OBSERVE_K278)
  {
    WL_POPN(4);
    u32 _owner_7 = STK(0);
    u32 _owner_8 = STK(1);
    Term _h_6 = STK(2);
    Term _h_7 = STK(3);
    Term _h_5 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_38(e, _o_0, _owner_7) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(5);
      STK(0) = _owner_7;
      STK(1) = _owner_8;
      STK(2) = _h_6;
      STK(3) = _h_7;
      STK(4) = FID_TAIL_OBSERVE_K279;
      WL_PUSHN(5);
    } else {
      u64 _t_6 = task_node(e, FID_TAIL_OBSERVE_K279, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _owner_7;
      e.mem[_t_6 + 1] = _owner_8;
      e.mem[_t_6 + 2] = _h_6;
      e.mem[_t_6 + 3] = _h_7;
      WL_CONT = term_tsk(FID_TAIL_OBSERVE_K279, _t_6);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _v_0;
      e.mem[_t_7 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _v_0;
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_OBSERVE_K279)
  {
    WL_POPN(4);
    u32 _owner_9 = STK(0);
    u32 _owner_10 = STK(1);
    Term _h_9 = STK(2);
    Term _h_10 = STK(3);
    Term _h_8 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _owner_9;
      STK(1) = _owner_10;
      STK(2) = _h_9;
      STK(3) = _h_10;
      STK(4) = FID_TAIL_OBSERVE_K280;
      WL_PUSHN(5);
    } else {
      u64 _t_8 = task_node(e, FID_TAIL_OBSERVE_K280, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _owner_9;
      e.mem[_t_8 + 1] = _owner_10;
      e.mem[_t_8 + 2] = _h_9;
      e.mem[_t_8 + 3] = _h_10;
      WL_CONT = term_tsk(FID_TAIL_OBSERVE_K280, _t_8);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 343);
      e.mem[_t_9 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 343);
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_OBSERVE_K280)
  {
    WL_POPN(4);
    u32 _owner_11 = STK(0);
    u32 _owner_12 = STK(1);
    Term _h_12 = STK(2);
    Term _h_13 = STK(3);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _owner_11;
      STK(1) = _owner_12;
      STK(2) = _h_12;
      STK(3) = FID_TAIL_OBSERVE_K281;
      WL_PUSHN(4);
    } else {
      u64 _t_10 = task_node(e, FID_TAIL_OBSERVE_K281, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _owner_11;
      e.mem[_t_10 + 1] = _owner_12;
      e.mem[_t_10 + 2] = _h_12;
      WL_CONT = term_tsk(FID_TAIL_OBSERVE_K281, _t_10);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_13;
      e.mem[_t_11 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = _h_13;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_OBSERVE_K281)
  {
    WL_POPN(3);
    u32 _owner_13 = STK(0);
    u32 _owner_14 = STK(1);
    Term _h_15 = STK(2);
    Term _h_14 = r0;
    WL_OPEN
    r0 = _h_15;
    r1 = _owner_13;
    r2 = _owner_14;
    r3 = _h_14;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INCOMING_OBSERVE)
  {
    Term _owner_0 = r0;
    Term _owner_1 = r1;
    u32 _owner_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _owner_1;
      STK(1) = _owner_2;
      STK(2) = FID_INCOMING_OBSERVE_K283;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_INCOMING_OBSERVE_K283, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_1;
      e.mem[_t_0 + 1] = _owner_2;
      WL_CONT = term_tsk(FID_INCOMING_OBSERVE_K283, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TREE)) {
      u64 _t_1 = task_node(e, FID_TREE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_0;
      return term_tsk(FID_TREE, _t_1);
    }
    r0 = _owner_0;
    WL_JMP(FID_TREE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INCOMING_OBSERVE_K283)
  {
    WL_POPN(2);
    Term _owner_3 = STK(0);
    u32 _owner_4 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    _owner_3 = term_keep(e, _owner_3, 1);
    if (seq) {
      WL_ROOM(5);
      STK(0) = _owner_3;
      STK(1) = _owner_4;
      STK(2) = _h_0;
      STK(3) = _h_1;
      STK(4) = FID_INCOMING_OBSERVE_K284;
      WL_PUSHN(5);
    } else {
      u64 _t_2 = task_node(e, FID_INCOMING_OBSERVE_K284, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _owner_3;
      e.mem[_t_2 + 1] = _owner_4;
      e.mem[_t_2 + 2] = _h_0;
      e.mem[_t_2 + 3] = _h_1;
      WL_CONT = term_tsk(FID_INCOMING_OBSERVE_K284, _t_2);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_WIRE)) {
      u64 _t_3 = task_node(e, FID_WIRE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _owner_3;
      return term_tsk(FID_WIRE, _t_3);
    }
    r0 = _owner_3;
    WL_JMP(FID_WIRE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INCOMING_OBSERVE_K284)
  {
    WL_POPN(4);
    Term _owner_5 = STK(0);
    u32 _owner_6 = STK(1);
    Term _h_3 = STK(2);
    Term _h_4 = STK(3);
    Term _h_2 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_38(e, _o_0, _owner_6) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(6);
      STK(0) = _owner_5;
      STK(1) = _owner_6;
      STK(2) = _h_3;
      STK(3) = _h_4;
      STK(4) = _h_2;
      STK(5) = FID_INCOMING_OBSERVE_K285;
      WL_PUSHN(6);
    } else {
      u64 _t_4 = task_node(e, FID_INCOMING_OBSERVE_K285, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _owner_5;
      e.mem[_t_4 + 1] = _owner_6;
      e.mem[_t_4 + 2] = _h_3;
      e.mem[_t_4 + 3] = _h_4;
      e.mem[_t_4 + 4] = _h_2;
      WL_CONT = term_tsk(FID_INCOMING_OBSERVE_K285, _t_4);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 353);
      e.mem[_t_5 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 353);
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INCOMING_OBSERVE_K285)
  {
    WL_POPN(5);
    Term _owner_7 = STK(0);
    u32 _owner_8 = STK(1);
    Term _h_6 = STK(2);
    Term _h_7 = STK(3);
    Term _h_8 = STK(4);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _owner_7;
      STK(1) = _owner_8;
      STK(2) = _h_6;
      STK(3) = _h_7;
      STK(4) = FID_INCOMING_OBSERVE_K286;
      WL_PUSHN(5);
    } else {
      u64 _t_6 = task_node(e, FID_INCOMING_OBSERVE_K286, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _owner_7;
      e.mem[_t_6 + 1] = _owner_8;
      e.mem[_t_6 + 2] = _h_6;
      e.mem[_t_6 + 3] = _h_7;
      WL_CONT = term_tsk(FID_INCOMING_OBSERVE_K286, _t_6);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_8;
      e.mem[_t_7 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_8;
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INCOMING_OBSERVE_K286)
  {
    WL_POPN(4);
    Term _owner_9 = STK(0);
    u32 _owner_10 = STK(1);
    Term _h_10 = STK(2);
    Term _h_11 = STK(3);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _owner_9;
      STK(1) = _owner_10;
      STK(2) = _h_10;
      STK(3) = _h_11;
      STK(4) = FID_INCOMING_OBSERVE_K287;
      WL_PUSHN(5);
    } else {
      u64 _t_8 = task_node(e, FID_INCOMING_OBSERVE_K287, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _owner_9;
      e.mem[_t_8 + 1] = _owner_10;
      e.mem[_t_8 + 2] = _h_10;
      e.mem[_t_8 + 3] = _h_11;
      WL_CONT = term_tsk(FID_INCOMING_OBSERVE_K287, _t_8);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 363);
      e.mem[_t_9 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 363);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INCOMING_OBSERVE_K287)
  {
    WL_POPN(4);
    Term _owner_11 = STK(0);
    u32 _owner_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_14 = STK(3);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _owner_11;
      STK(1) = _owner_12;
      STK(2) = _h_13;
      STK(3) = FID_INCOMING_OBSERVE_K288;
      WL_PUSHN(4);
    } else {
      u64 _t_10 = task_node(e, FID_INCOMING_OBSERVE_K288, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _owner_11;
      e.mem[_t_10 + 1] = _owner_12;
      e.mem[_t_10 + 2] = _h_13;
      WL_CONT = term_tsk(FID_INCOMING_OBSERVE_K288, _t_10);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_14;
      e.mem[_t_11 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = _h_14;
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INCOMING_OBSERVE_K288)
  {
    WL_POPN(3);
    Term _owner_13 = STK(0);
    u32 _owner_14 = STK(1);
    Term _h_16 = STK(2);
    Term _h_15 = r0;
    WL_OPEN
    r0 = _h_16;
    r1 = _owner_13;
    r2 = _owner_14;
    r3 = _h_15;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER)
  {
    Term _owner_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_owner_0) == 0) {
      Term _c_0 = blk_shr(_owner_0) ? blk_keep(e, blk_loc(e.mem, _owner_0) + 0 + 0) : e.mem[blk_loc(e.mem, _owner_0) + 0 + 0];
      blk_free(e, _owner_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_OUTER_K293;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_OUTER_K293, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_OUTER_K293, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_TREE)) {
        u64 _t_1 = task_node(e, FID_TREE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _c_0;
        return term_tsk(FID_TREE, _t_1);
      }
      r0 = _c_0;
      WL_JMP(FID_TREE);
    } else {
      Term _h_6 = blk_half(e, _owner_0, 0);
      Term _h_7 = blk_half(e, _owner_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_7;
        STK(1) = FID_OUTER_K296;
        WL_PUSHN(2);
      } else {
        u64 _t_6 = task_node(e, FID_OUTER_K296, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _h_7;
        WL_CONT = term_tsk(FID_OUTER_K296, _t_6);
        WL_IDX = 1;
      }
      r0 = _h_6;
      _owner_0 = r0;
      WL_AGAIN(FID_OUTER);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K293)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_OUTER_K294;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_OUTER_K294, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_OUTER_K294, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_1;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 153);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_SCON, STAT_OFF + 153);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K294)
  {
    WL_POPN(1);
    Term _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_3;
      STK(1) = FID_OUTER_K295;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_OUTER_K295, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_3;
      WL_CONT = term_tsk(FID_OUTER_K295, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 365);
      e.mem[_t_5 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 365);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K295)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _h_5;
    r0 = blk_new(e, 1, 0, 0, 1, _fv_0);
    r1 = _h_4;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K296)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_8 = r0;
    Term _h_9 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_8;
      STK(1) = _h_9;
      STK(2) = FID_OUTER_K297;
      WL_PUSHN(3);
    } else {
      u64 _t_7 = task_node(e, FID_OUTER_K297, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_8;
      e.mem[_t_7 + 1] = _h_9;
      WL_CONT = term_tsk(FID_OUTER_K297, _t_7);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OUTER)) {
      u64 _t_8 = task_node(e, FID_OUTER, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_10;
      return term_tsk(FID_OUTER, _t_8);
    }
    r0 = _h_10;
    WL_JMP(FID_OUTER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K297)
  {
    WL_POPN(2);
    Term _h_13 = STK(0);
    Term _h_14 = STK(1);
    Term _h_11 = r0;
    Term _h_12 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_13;
      STK(1) = _h_14;
      STK(2) = _h_11;
      STK(3) = FID_OUTER_K298;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID_OUTER_K298, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_13;
      e.mem[_t_9 + 1] = _h_14;
      e.mem[_t_9 + 2] = _h_11;
      WL_CONT = term_tsk(FID_OUTER_K298, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_12;
      e.mem[_t_10 + 1] = term_ctr(CID_SCON, STAT_OFF + 153);
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = _h_12;
    r1 = term_ctr(CID_SCON, STAT_OFF + 153);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K298)
  {
    WL_POPN(3);
    Term _h_16 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_16;
      STK(1) = _h_17;
      STK(2) = _h_18;
      STK(3) = FID_OUTER_K299;
      WL_PUSHN(4);
    } else {
      u64 _t_11 = task_node(e, FID_OUTER_K299, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_16;
      e.mem[_t_11 + 1] = _h_17;
      e.mem[_t_11 + 2] = _h_18;
      WL_CONT = term_tsk(FID_OUTER_K299, _t_11);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = term_ctr(CID_SCON, STAT_OFF + 193);
      e.mem[_t_12 + 1] = _h_15;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 193);
    r1 = _h_15;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K299)
  {
    WL_POPN(3);
    Term _h_20 = STK(0);
    Term _h_21 = STK(1);
    Term _h_22 = STK(2);
    Term _h_19 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_20;
      STK(1) = _h_22;
      STK(2) = FID_OUTER_K300;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_OUTER_K300, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_20;
      e.mem[_t_13 + 1] = _h_22;
      WL_CONT = term_tsk(FID_OUTER_K300, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_21;
      e.mem[_t_14 + 1] = _h_19;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = _h_21;
    r1 = _h_19;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K300)
  {
    WL_POPN(2);
    Term _h_24 = STK(0);
    Term _h_25 = STK(1);
    Term _h_23 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_24;
      STK(1) = _h_25;
      STK(2) = FID_OUTER_K301;
      WL_PUSHN(3);
    } else {
      u64 _t_15 = task_node(e, FID_OUTER_K301, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _h_24;
      e.mem[_t_15 + 1] = _h_25;
      WL_CONT = term_tsk(FID_OUTER_K301, _t_15);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 297);
      e.mem[_t_16 + 1] = _h_23;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 297);
    r1 = _h_23;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_OUTER_K301)
  {
    WL_POPN(2);
    Term _h_27 = STK(0);
    Term _h_28 = STK(1);
    Term _h_26 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_27, _h_28);
    r1 = _h_26;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FACTORY_OBSERVE_0)
  {
    Term _factory_0 = r0;
    Term _factory_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    _factory_1 = term_keep(e, _factory_1, 1);
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_41(e, _o_0, _factory_1, blk_loc(e.mem, _factory_1)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _factory_0;
      STK(1) = _factory_1;
      STK(2) = FID_FACTORY_OBSERVE_0_K303;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_FACTORY_OBSERVE_0_K303, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _factory_0;
      e.mem[_t_0 + 1] = _factory_1;
      WL_CONT = term_tsk(FID_FACTORY_OBSERVE_0_K303, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 555);
      e.mem[_t_1 + 1] = _v_0;
      return term_tsk(FID_STRING_APPEND, _t_1);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 555);
    r1 = _v_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FACTORY_OBSERVE_0_K303)
  {
    WL_POPN(2);
    Term _factory_2 = STK(0);
    Term _factory_3 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_3 = 0;
    Term _v_4 = 0;
    _factory_2 = term_keep(e, _factory_2, 1);
    Term _v_5 = 0;
    Term _o_1[1];
    if (spin_42(e, _o_1, _factory_2, blk_loc(e.mem, _factory_2)) == 0) {
      return 0;
    }
    _v_5 = _o_1[0];
    _v_4 = _v_5;
    Term _v_7 = 0;
    Term _o_2[1];
    if (spin_41(e, _o_2, _v_4, blk_loc(e.mem, _v_4)) == 0) {
      return 0;
    }
    _v_7 = _o_2[0];
    _v_3 = _v_7;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _factory_2;
      STK(1) = _factory_3;
      STK(2) = FID_FACTORY_OBSERVE_0_K304;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_FACTORY_OBSERVE_0_K304, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _factory_2;
      e.mem[_t_2 + 1] = _factory_3;
      WL_CONT = term_tsk(FID_FACTORY_OBSERVE_0_K304, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _v_3;
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _v_3;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FACTORY_OBSERVE_0_K304)
  {
    WL_POPN(2);
    Term _factory_4 = STK(0);
    Term _factory_5 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _factory_4;
      STK(1) = _factory_5;
      STK(2) = FID_FACTORY_OBSERVE_0_K305;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_FACTORY_OBSERVE_0_K305, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _factory_4;
      e.mem[_t_4 + 1] = _factory_5;
      WL_CONT = term_tsk(FID_FACTORY_OBSERVE_0_K305, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 563);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 563);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FACTORY_OBSERVE_0_K305)
  {
    WL_POPN(2);
    Term _factory_6 = STK(0);
    Term _factory_7 = STK(1);
    Term _h_2 = r0;
    WL_OPEN
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _o_3[1];
    Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 463);
    if (spin_43(e, _o_3, _a_0, blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_9 = _o_3[0];
    _v_8 = _v_9;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _factory_6;
      STK(1) = _factory_7;
      STK(2) = FID_FACTORY_OBSERVE_0_K306;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_FACTORY_OBSERVE_0_K306, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _factory_6;
      e.mem[_t_6 + 1] = _factory_7;
      WL_CONT = term_tsk(FID_FACTORY_OBSERVE_0_K306, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _v_8;
      e.mem[_t_7 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _v_8;
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FACTORY_OBSERVE_0_K306)
  {
    WL_POPN(2);
    Term _factory_8 = STK(0);
    Term _factory_9 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _factory_8;
      STK(1) = _factory_9;
      STK(2) = FID_FACTORY_OBSERVE_0_K307;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID_FACTORY_OBSERVE_0_K307, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _factory_8;
      e.mem[_t_8 + 1] = _factory_9;
      WL_CONT = term_tsk(FID_FACTORY_OBSERVE_0_K307, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 579);
      e.mem[_t_9 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 579);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FACTORY_OBSERVE_0_K307)
  {
    WL_POPN(2);
    Term _factory_10 = STK(0);
    Term _factory_11 = STK(1);
    Term _h_4 = r0;
    WL_OPEN
    r0 = _factory_10;
    r1 = _factory_11;
    r2 = _h_4;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COOKED_OBSERVE)
  {
    Term _cooked_0 = r0;
    u32 _cooked_1 = r1;
    Term _cooked_2 = r2;
    u32 _cooked_3 = r3;
    u32 _cooked_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _cooked_2;
      STK(1) = _cooked_3;
      STK(2) = _cooked_4;
      STK(3) = FID_COOKED_OBSERVE_K329;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_COOKED_OBSERVE_K329, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _cooked_2;
      e.mem[_t_0 + 1] = _cooked_3;
      e.mem[_t_0 + 2] = _cooked_4;
      WL_CONT = term_tsk(FID_COOKED_OBSERVE_K329, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_PAYLOAD_OBSERVE)) {
      u64 _t_1 = task_node(e, FID_PAYLOAD_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _cooked_0;
      e.mem[_t_1 + 1] = _cooked_1;
      return term_tsk(FID_PAYLOAD_OBSERVE, _t_1);
    }
    r0 = _cooked_0;
    r1 = _cooked_1;
    WL_JMP(FID_PAYLOAD_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COOKED_OBSERVE_K329)
  {
    WL_POPN(3);
    Term _cooked_5 = STK(0);
    u32 _cooked_6 = STK(1);
    u32 _cooked_7 = STK(2);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = FID_COOKED_OBSERVE_K330;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_COOKED_OBSERVE_K330, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      WL_CONT = term_tsk(FID_COOKED_OBSERVE_K330, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TAIL_OBSERVE)) {
      u64 _t_3 = task_node(e, FID_TAIL_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _cooked_5;
      e.mem[_t_3 + 1] = _cooked_6;
      e.mem[_t_3 + 2] = _cooked_7;
      return term_tsk(FID_TAIL_OBSERVE, _t_3);
    }
    r0 = _cooked_5;
    r1 = _cooked_6;
    r2 = _cooked_7;
    WL_JMP(FID_TAIL_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COOKED_OBSERVE_K330)
  {
    WL_POPN(3);
    Term _h_7 = STK(0);
    u32 _h_8 = STK(1);
    Term _h_9 = STK(2);
    Term _h_3 = r0;
    u32 _h_4 = r1;
    u32 _h_5 = r2;
    Term _h_6 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_7;
      STK(1) = _h_8;
      STK(2) = _h_9;
      STK(3) = _h_3;
      STK(4) = _h_4;
      STK(5) = _h_5;
      STK(6) = FID_COOKED_OBSERVE_K331;
      WL_PUSHN(7);
    } else {
      u64 _t_4 = task_node(e, FID_COOKED_OBSERVE_K331, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_7;
      e.mem[_t_4 + 1] = _h_8;
      e.mem[_t_4 + 2] = _h_9;
      e.mem[_t_4 + 3] = _h_3;
      e.mem[_t_4 + 4] = _h_4;
      e.mem[_t_4 + 5] = _h_5;
      WL_CONT = term_tsk(FID_COOKED_OBSERVE_K331, _t_4);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 515);
      e.mem[_t_5 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 515);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COOKED_OBSERVE_K331)
  {
    WL_POPN(6);
    Term _h_11 = STK(0);
    u32 _h_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_14 = STK(3);
    u32 _h_15 = STK(4);
    u32 _h_16 = STK(5);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_14;
      STK(3) = _h_15;
      STK(4) = _h_16;
      STK(5) = FID_COOKED_OBSERVE_K332;
      WL_PUSHN(6);
    } else {
      u64 _t_6 = task_node(e, FID_COOKED_OBSERVE_K332, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_11;
      e.mem[_t_6 + 1] = _h_12;
      e.mem[_t_6 + 2] = _h_14;
      e.mem[_t_6 + 3] = _h_15;
      e.mem[_t_6 + 4] = _h_16;
      WL_CONT = term_tsk(FID_COOKED_OBSERVE_K332, _t_6);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_13;
      e.mem[_t_7 + 1] = _h_10;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_13;
    r1 = _h_10;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COOKED_OBSERVE_K332)
  {
    WL_POPN(5);
    Term _h_18 = STK(0);
    u32 _h_19 = STK(1);
    Term _h_20 = STK(2);
    u32 _h_21 = STK(3);
    u32 _h_22 = STK(4);
    Term _h_17 = r0;
    WL_OPEN
    r0 = _h_18;
    r1 = _h_19;
    r2 = _h_20;
    r3 = _h_21;
    r4 = _h_22;
    r5 = _h_17;
    WL_RETN(6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0)
  {
    Term _prior_0 = r0;
    Term _context_0 = r1;
    Term _context_1 = r2;
    Term _context_2 = r3;
    Term _context_3 = r4;
    Term _undo_0 = r5;
    Term _cooked_0 = r6;
    u32 _cooked_1 = r7;
    Term _cooked_2 = r8;
    u32 _cooked_3 = r9;
    u32 _cooked_4 = r10;
    Term _cooked_5 = r11;
    Term _positions_0 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _prior_0;
      STK(1) = _context_0;
      STK(2) = _context_1;
      STK(3) = _context_2;
      STK(4) = _context_3;
      STK(5) = _undo_0;
      STK(6) = _cooked_0;
      STK(7) = _cooked_1;
      STK(8) = _cooked_2;
      STK(9) = _cooked_3;
      STK(10) = _cooked_4;
      STK(11) = _cooked_5;
      STK(12) = FID_COMPLETE_0_K334;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID_COMPLETE_0_K334, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _prior_0;
      e.mem[_t_0 + 1] = _context_0;
      e.mem[_t_0 + 2] = _context_1;
      e.mem[_t_0 + 3] = _context_2;
      e.mem[_t_0 + 4] = _context_3;
      e.mem[_t_0 + 5] = _undo_0;
      e.mem[_t_0 + 6] = _cooked_0;
      e.mem[_t_0 + 7] = _cooked_1;
      e.mem[_t_0 + 8] = _cooked_2;
      e.mem[_t_0 + 9] = _cooked_3;
      e.mem[_t_0 + 10] = _cooked_4;
      e.mem[_t_0 + 11] = _cooked_5;
      WL_CONT = term_tsk(FID_COMPLETE_0_K334, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_1)) {
      u64 _t_1 = task_node(e, FID_LIST_SHOW_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _positions_0;
      return term_tsk(FID_LIST_SHOW_1, _t_1);
    }
    r0 = _positions_0;
    WL_JMP(FID_LIST_SHOW_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K334)
  {
    WL_POPN(12);
    Term _prior_1 = STK(0);
    Term _context_4 = STK(1);
    Term _context_5 = STK(2);
    Term _context_6 = STK(3);
    Term _context_7 = STK(4);
    Term _undo_1 = STK(5);
    Term _cooked_6 = STK(6);
    u32 _cooked_7 = STK(7);
    Term _cooked_8 = STK(8);
    u32 _cooked_9 = STK(9);
    u32 _cooked_10 = STK(10);
    Term _cooked_11 = STK(11);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _prior_1;
      STK(1) = _context_4;
      STK(2) = _context_5;
      STK(3) = _context_6;
      STK(4) = _context_7;
      STK(5) = _undo_1;
      STK(6) = _cooked_6;
      STK(7) = _cooked_7;
      STK(8) = _cooked_8;
      STK(9) = _cooked_9;
      STK(10) = _cooked_10;
      STK(11) = _cooked_11;
      STK(12) = FID_COMPLETE_0_K335;
      WL_PUSHN(13);
    } else {
      u64 _t_2 = task_node(e, FID_COMPLETE_0_K335, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _prior_1;
      e.mem[_t_2 + 1] = _context_4;
      e.mem[_t_2 + 2] = _context_5;
      e.mem[_t_2 + 3] = _context_6;
      e.mem[_t_2 + 4] = _context_7;
      e.mem[_t_2 + 5] = _undo_1;
      e.mem[_t_2 + 6] = _cooked_6;
      e.mem[_t_2 + 7] = _cooked_7;
      e.mem[_t_2 + 8] = _cooked_8;
      e.mem[_t_2 + 9] = _cooked_9;
      e.mem[_t_2 + 10] = _cooked_10;
      e.mem[_t_2 + 11] = _cooked_11;
      WL_CONT = term_tsk(FID_COMPLETE_0_K335, _t_2);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 517);
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 517);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K335)
  {
    WL_POPN(12);
    Term _prior_2 = STK(0);
    Term _context_8 = STK(1);
    Term _context_9 = STK(2);
    Term _context_10 = STK(3);
    Term _context_11 = STK(4);
    Term _undo_2 = STK(5);
    Term _cooked_12 = STK(6);
    u32 _cooked_13 = STK(7);
    Term _cooked_14 = STK(8);
    u32 _cooked_15 = STK(9);
    u32 _cooked_16 = STK(10);
    Term _cooked_17 = STK(11);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _prior_2;
      STK(1) = _context_8;
      STK(2) = _context_9;
      STK(3) = _context_10;
      STK(4) = _context_11;
      STK(5) = _undo_2;
      STK(6) = _cooked_12;
      STK(7) = _cooked_13;
      STK(8) = _cooked_14;
      STK(9) = _cooked_15;
      STK(10) = _cooked_16;
      STK(11) = _cooked_17;
      STK(12) = FID_COMPLETE_0_K336;
      WL_PUSHN(13);
    } else {
      u64 _t_4 = task_node(e, FID_COMPLETE_0_K336, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _prior_2;
      e.mem[_t_4 + 1] = _context_8;
      e.mem[_t_4 + 2] = _context_9;
      e.mem[_t_4 + 3] = _context_10;
      e.mem[_t_4 + 4] = _context_11;
      e.mem[_t_4 + 5] = _undo_2;
      e.mem[_t_4 + 6] = _cooked_12;
      e.mem[_t_4 + 7] = _cooked_13;
      e.mem[_t_4 + 8] = _cooked_14;
      e.mem[_t_4 + 9] = _cooked_15;
      e.mem[_t_4 + 10] = _cooked_16;
      e.mem[_t_4 + 11] = _cooked_17;
      WL_CONT = term_tsk(FID_COMPLETE_0_K336, _t_4);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 625);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 625);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K336)
  {
    WL_POPN(12);
    Term _prior_3 = STK(0);
    Term _context_12 = STK(1);
    Term _context_13 = STK(2);
    Term _context_14 = STK(3);
    Term _context_15 = STK(4);
    Term _undo_3 = STK(5);
    Term _cooked_18 = STK(6);
    u32 _cooked_19 = STK(7);
    Term _cooked_20 = STK(8);
    u32 _cooked_21 = STK(9);
    u32 _cooked_22 = STK(10);
    Term _cooked_23 = STK(11);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _prior_3;
      STK(1) = _context_12;
      STK(2) = _context_13;
      STK(3) = _context_14;
      STK(4) = _context_15;
      STK(5) = _undo_3;
      STK(6) = _cooked_18;
      STK(7) = _cooked_19;
      STK(8) = _cooked_20;
      STK(9) = _cooked_21;
      STK(10) = _cooked_22;
      STK(11) = FID_COMPLETE_0_K337;
      WL_PUSHN(12);
    } else {
      u64 _t_6 = task_node(e, FID_COMPLETE_0_K337, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _prior_3;
      e.mem[_t_6 + 1] = _context_12;
      e.mem[_t_6 + 2] = _context_13;
      e.mem[_t_6 + 3] = _context_14;
      e.mem[_t_6 + 4] = _context_15;
      e.mem[_t_6 + 5] = _undo_3;
      e.mem[_t_6 + 6] = _cooked_18;
      e.mem[_t_6 + 7] = _cooked_19;
      e.mem[_t_6 + 8] = _cooked_20;
      e.mem[_t_6 + 9] = _cooked_21;
      e.mem[_t_6 + 10] = _cooked_22;
      WL_CONT = term_tsk(FID_COMPLETE_0_K337, _t_6);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _cooked_23;
      e.mem[_t_7 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _cooked_23;
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K337)
  {
    WL_POPN(11);
    Term _prior_4 = STK(0);
    Term _context_16 = STK(1);
    Term _context_17 = STK(2);
    Term _context_18 = STK(3);
    Term _context_19 = STK(4);
    Term _undo_4 = STK(5);
    Term _cooked_24 = STK(6);
    u32 _cooked_25 = STK(7);
    Term _cooked_26 = STK(8);
    u32 _cooked_27 = STK(9);
    u32 _cooked_28 = STK(10);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _prior_4;
      STK(1) = _context_16;
      STK(2) = _context_17;
      STK(3) = _context_18;
      STK(4) = _context_19;
      STK(5) = _undo_4;
      STK(6) = _cooked_24;
      STK(7) = _cooked_25;
      STK(8) = _cooked_26;
      STK(9) = _cooked_27;
      STK(10) = _cooked_28;
      STK(11) = FID_COMPLETE_0_K338;
      WL_PUSHN(12);
    } else {
      u64 _t_8 = task_node(e, FID_COMPLETE_0_K338, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _prior_4;
      e.mem[_t_8 + 1] = _context_16;
      e.mem[_t_8 + 2] = _context_17;
      e.mem[_t_8 + 3] = _context_18;
      e.mem[_t_8 + 4] = _context_19;
      e.mem[_t_8 + 5] = _undo_4;
      e.mem[_t_8 + 6] = _cooked_24;
      e.mem[_t_8 + 7] = _cooked_25;
      e.mem[_t_8 + 8] = _cooked_26;
      e.mem[_t_8 + 9] = _cooked_27;
      e.mem[_t_8 + 10] = _cooked_28;
      WL_CONT = term_tsk(FID_COMPLETE_0_K338, _t_8);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 643);
      e.mem[_t_9 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 643);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K338)
  {
    WL_POPN(11);
    Term _prior_5 = STK(0);
    Term _context_20 = STK(1);
    Term _context_21 = STK(2);
    Term _context_22 = STK(3);
    Term _context_23 = STK(4);
    Term _undo_5 = STK(5);
    Term _cooked_29 = STK(6);
    u32 _cooked_30 = STK(7);
    Term _cooked_31 = STK(8);
    u32 _cooked_32 = STK(9);
    u32 _cooked_33 = STK(10);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _context_20;
      STK(1) = _context_21;
      STK(2) = _context_22;
      STK(3) = _context_23;
      STK(4) = _undo_5;
      STK(5) = _cooked_29;
      STK(6) = _cooked_30;
      STK(7) = _cooked_31;
      STK(8) = _cooked_32;
      STK(9) = _cooked_33;
      STK(10) = FID_COMPLETE_0_K339;
      WL_PUSHN(11);
    } else {
      u64 _t_10 = task_node(e, FID_COMPLETE_0_K339, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _context_20;
      e.mem[_t_10 + 1] = _context_21;
      e.mem[_t_10 + 2] = _context_22;
      e.mem[_t_10 + 3] = _context_23;
      e.mem[_t_10 + 4] = _undo_5;
      e.mem[_t_10 + 5] = _cooked_29;
      e.mem[_t_10 + 6] = _cooked_30;
      e.mem[_t_10 + 7] = _cooked_31;
      e.mem[_t_10 + 8] = _cooked_32;
      e.mem[_t_10 + 9] = _cooked_33;
      WL_CONT = term_tsk(FID_COMPLETE_0_K339, _t_10);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _prior_5;
      e.mem[_t_11 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = _prior_5;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K339)
  {
    WL_POPN(10);
    Term _context_24 = STK(0);
    Term _context_25 = STK(1);
    Term _context_26 = STK(2);
    Term _context_27 = STK(3);
    Term _undo_6 = STK(4);
    Term _cooked_34 = STK(5);
    u32 _cooked_35 = STK(6);
    Term _cooked_36 = STK(7);
    u32 _cooked_37 = STK(8);
    u32 _cooked_38 = STK(9);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _undo_6;
      STK(1) = _cooked_34;
      STK(2) = _cooked_35;
      STK(3) = _cooked_36;
      STK(4) = _cooked_37;
      STK(5) = _cooked_38;
      STK(6) = _h_5;
      STK(7) = FID_COMPLETE_0_K340;
      WL_PUSHN(8);
    } else {
      u64 _t_12 = task_node(e, FID_COMPLETE_0_K340, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _undo_6;
      e.mem[_t_12 + 1] = _cooked_34;
      e.mem[_t_12 + 2] = _cooked_35;
      e.mem[_t_12 + 3] = _cooked_36;
      e.mem[_t_12 + 4] = _cooked_37;
      e.mem[_t_12 + 5] = _cooked_38;
      e.mem[_t_12 + 6] = _h_5;
      WL_CONT = term_tsk(FID_COMPLETE_0_K340, _t_12);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONTEXT_OBSERVE_0)) {
      u64 _t_13 = task_node(e, FID_CONTEXT_OBSERVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _context_24;
      e.mem[_t_13 + 1] = _context_25;
      e.mem[_t_13 + 2] = _context_26;
      e.mem[_t_13 + 3] = _context_27;
      return term_tsk(FID_CONTEXT_OBSERVE_0, _t_13);
    }
    r0 = _context_24;
    r1 = _context_25;
    r2 = _context_26;
    r3 = _context_27;
    WL_JMP(FID_CONTEXT_OBSERVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K340)
  {
    WL_POPN(7);
    Term _undo_7 = STK(0);
    Term _cooked_39 = STK(1);
    u32 _cooked_40 = STK(2);
    Term _cooked_41 = STK(3);
    u32 _cooked_42 = STK(4);
    u32 _cooked_43 = STK(5);
    Term _h_11 = STK(6);
    Term _h_6 = r0;
    Term _h_7 = r1;
    Term _h_8 = r2;
    Term _h_9 = r3;
    Term _h_10 = r4;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _cooked_39);
    e.mem[_nd_0 + 1] = rfc_seal(e, _cooked_40);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = _cooked_41;
    e.mem[_nd_1 + 1] = _cooked_42;
    e.mem[_nd_1 + 2] = _cooked_43;
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = term_ctr(CID_PAYLOAD, _nd_0);
    e.mem[_nd_2 + 1] = term_ctr(CID_TAIL, _nd_1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_11;
      STK(1) = _h_6;
      STK(2) = _h_7;
      STK(3) = _h_8;
      STK(4) = _h_9;
      STK(5) = _h_10;
      STK(6) = FID_COMPLETE_0_K341;
      WL_PUSHN(7);
    } else {
      u64 _t_14 = task_node(e, FID_COMPLETE_0_K341, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_11;
      e.mem[_t_14 + 1] = _h_6;
      e.mem[_t_14 + 2] = _h_7;
      e.mem[_t_14 + 3] = _h_8;
      e.mem[_t_14 + 4] = _h_9;
      e.mem[_t_14 + 5] = _h_10;
      WL_CONT = term_tsk(FID_COMPLETE_0_K341, _t_14);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_15 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _undo_7;
      e.mem[_t_15 + 1] = term_ctr(CID_________________________BENDVY_SRC_ECS_BUNDLE_PACK_PACK, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_15);
    }
    r0 = _undo_7;
    r1 = term_ctr(CID_________________________BENDVY_SRC_ECS_BUNDLE_PACK_PACK, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K341)
  {
    WL_POPN(6);
    Term _h_13 = STK(0);
    Term _h_14 = STK(1);
    Term _h_15 = STK(2);
    Term _h_16 = STK(3);
    Term _h_17 = STK(4);
    Term _h_18 = STK(5);
    Term _h_12 = r0;
    WL_OPEN
    u64 _sp_0 = term_loc(_h_12);
    Term _f_0 = e.mem[_sp_0 + 0];
    Term _f_1 = e.mem[_sp_0 + 1];
    heap_free(e, cls_fit(2), _sp_0);
    Term _fb_0[3];
    u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_0);
    Term _f_2 = _fb_0[0];
    Term _f_3 = _fb_0[1];
    u32 _f_4 = _fb_0[2];
    spare_free(e, cls_fit(3), _sp_1);
    u64 _sp_2 = term_loc(_f_1);
    Term _f_5 = e.mem[_sp_2 + 0];
    u32 _f_6 = e.mem[_sp_2 + 1];
    u32 _f_7 = e.mem[_sp_2 + 2];
    heap_free(e, cls_fit(3), _sp_2);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_13;
      STK(1) = _h_14;
      STK(2) = _h_15;
      STK(3) = _h_16;
      STK(4) = _h_17;
      STK(5) = _h_18;
      STK(6) = FID_COMPLETE_0_K342;
      WL_PUSHN(7);
    } else {
      u64 _t_16 = task_node(e, FID_COMPLETE_0_K342, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_13;
      e.mem[_t_16 + 1] = _h_14;
      e.mem[_t_16 + 2] = _h_15;
      e.mem[_t_16 + 3] = _h_16;
      e.mem[_t_16 + 4] = _h_17;
      e.mem[_t_16 + 5] = _h_18;
      WL_CONT = term_tsk(FID_COMPLETE_0_K342, _t_16);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RAW_OBSERVE)) {
      u64 _t_17 = task_node(e, FID_RAW_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _f_2;
      e.mem[_t_17 + 1] = _f_3;
      e.mem[_t_17 + 2] = _f_4;
      e.mem[_t_17 + 3] = _f_5;
      e.mem[_t_17 + 4] = _f_6;
      e.mem[_t_17 + 5] = _f_7;
      return term_tsk(FID_RAW_OBSERVE, _t_17);
    }
    r0 = _f_2;
    r1 = _f_3;
    r2 = _f_4;
    r3 = _f_5;
    r4 = _f_6;
    r5 = _f_7;
    WL_JMP(FID_RAW_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K342)
  {
    WL_POPN(6);
    Term _h_26 = STK(0);
    Term _h_27 = STK(1);
    Term _h_28 = STK(2);
    Term _h_29 = STK(3);
    Term _h_30 = STK(4);
    Term _h_31 = STK(5);
    Term _h_19 = r0;
    Term _h_20 = r1;
    u32 _h_21 = r2;
    Term _h_22 = r3;
    u32 _h_23 = r4;
    u32 _h_24 = r5;
    Term _h_25 = r6;
    WL_OPEN
    term_sink(e, _h_27);
    term_sink(e, _h_28);
    term_sink(e, _h_29);
    term_sink(e, _h_30);
    term_sink(e, _h_19);
    term_sink(e, _h_20);
    term_sink(e, _h_22);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_26;
      STK(1) = _h_31;
      STK(2) = FID_COMPLETE_0_K343;
      WL_PUSHN(3);
    } else {
      u64 _t_18 = task_node(e, FID_COMPLETE_0_K343, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_26;
      e.mem[_t_18 + 1] = _h_31;
      WL_CONT = term_tsk(FID_COMPLETE_0_K343, _t_18);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_25;
      e.mem[_t_19 + 1] = term_ctr(CID_SCON, STAT_OFF + 517);
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_25;
    r1 = term_ctr(CID_SCON, STAT_OFF + 517);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K343)
  {
    WL_POPN(2);
    Term _h_33 = STK(0);
    Term _h_34 = STK(1);
    Term _h_32 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_33;
      STK(1) = _h_34;
      STK(2) = FID_COMPLETE_0_K344;
      WL_PUSHN(3);
    } else {
      u64 _t_20 = task_node(e, FID_COMPLETE_0_K344, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _h_33;
      e.mem[_t_20 + 1] = _h_34;
      WL_CONT = term_tsk(FID_COMPLETE_0_K344, _t_20);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 525);
      e.mem[_t_21 + 1] = _h_32;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 525);
    r1 = _h_32;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K344)
  {
    WL_POPN(2);
    Term _h_36 = STK(0);
    Term _h_37 = STK(1);
    Term _h_35 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_36;
      STK(1) = FID_COMPLETE_0_K345;
      WL_PUSHN(2);
    } else {
      u64 _t_22 = task_node(e, FID_COMPLETE_0_K345, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _h_36;
      WL_CONT = term_tsk(FID_COMPLETE_0_K345, _t_22);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_37;
      e.mem[_t_23 + 1] = _h_35;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = _h_37;
    r1 = _h_35;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K345)
  {
    WL_POPN(1);
    Term _h_39 = STK(0);
    Term _h_38 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_39;
      STK(1) = FID_COMPLETE_0_K346;
      WL_PUSHN(2);
    } else {
      u64 _t_24 = task_node(e, FID_COMPLETE_0_K346, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _h_39;
      WL_CONT = term_tsk(FID_COMPLETE_0_K346, _t_24);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 543);
      e.mem[_t_25 + 1] = _h_38;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 543);
    r1 = _h_38;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_COMPLETE_0_K346)
  {
    WL_POPN(1);
    Term _h_41 = STK(0);
    Term _h_40 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_26 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_26 + 0] = _h_41;
      e.mem[_t_26 + 1] = _h_40;
      return term_tsk(FID_STRING_APPEND, _t_26);
    }
    r0 = _h_41;
    r1 = _h_40;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RAW_OBSERVE)
  {
    Term _raw_0 = r0;
    Term _raw_1 = r1;
    u32 _raw_2 = r2;
    Term _raw_3 = r3;
    u32 _raw_4 = r4;
    u32 _raw_5 = r5;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _raw_3;
      STK(1) = _raw_4;
      STK(2) = _raw_5;
      STK(3) = FID_RAW_OBSERVE_K350;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID_RAW_OBSERVE_K350, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _raw_3;
      e.mem[_t_0 + 1] = _raw_4;
      e.mem[_t_0 + 2] = _raw_5;
      WL_CONT = term_tsk(FID_RAW_OBSERVE_K350, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_INCOMING_OBSERVE)) {
      u64 _t_1 = task_node(e, FID_INCOMING_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _raw_0;
      e.mem[_t_1 + 1] = _raw_1;
      e.mem[_t_1 + 2] = _raw_2;
      return term_tsk(FID_INCOMING_OBSERVE, _t_1);
    }
    r0 = _raw_0;
    r1 = _raw_1;
    r2 = _raw_2;
    WL_JMP(FID_INCOMING_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RAW_OBSERVE_K350)
  {
    WL_POPN(3);
    Term _raw_6 = STK(0);
    u32 _raw_7 = STK(1);
    u32 _raw_8 = STK(2);
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = _h_3;
      STK(4) = FID_RAW_OBSERVE_K351;
      WL_PUSHN(5);
    } else {
      u64 _t_2 = task_node(e, FID_RAW_OBSERVE_K351, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      e.mem[_t_2 + 3] = _h_3;
      WL_CONT = term_tsk(FID_RAW_OBSERVE_K351, _t_2);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TAIL_OBSERVE)) {
      u64 _t_3 = task_node(e, FID_TAIL_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _raw_6;
      e.mem[_t_3 + 1] = _raw_7;
      e.mem[_t_3 + 2] = _raw_8;
      return term_tsk(FID_TAIL_OBSERVE, _t_3);
    }
    r0 = _raw_6;
    r1 = _raw_7;
    r2 = _raw_8;
    WL_JMP(FID_TAIL_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RAW_OBSERVE_K351)
  {
    WL_POPN(4);
    Term _h_8 = STK(0);
    Term _h_9 = STK(1);
    u32 _h_10 = STK(2);
    Term _h_11 = STK(3);
    Term _h_4 = r0;
    u32 _h_5 = r1;
    u32 _h_6 = r2;
    Term _h_7 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_8;
      STK(1) = _h_9;
      STK(2) = _h_10;
      STK(3) = _h_11;
      STK(4) = _h_4;
      STK(5) = _h_5;
      STK(6) = _h_6;
      STK(7) = FID_RAW_OBSERVE_K352;
      WL_PUSHN(8);
    } else {
      u64 _t_4 = task_node(e, FID_RAW_OBSERVE_K352, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_8;
      e.mem[_t_4 + 1] = _h_9;
      e.mem[_t_4 + 2] = _h_10;
      e.mem[_t_4 + 3] = _h_11;
      e.mem[_t_4 + 4] = _h_4;
      e.mem[_t_4 + 5] = _h_5;
      e.mem[_t_4 + 6] = _h_6;
      WL_CONT = term_tsk(FID_RAW_OBSERVE_K352, _t_4);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 515);
      e.mem[_t_5 + 1] = _h_7;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 515);
    r1 = _h_7;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RAW_OBSERVE_K352)
  {
    WL_POPN(7);
    Term _h_13 = STK(0);
    Term _h_14 = STK(1);
    u32 _h_15 = STK(2);
    Term _h_16 = STK(3);
    Term _h_17 = STK(4);
    u32 _h_18 = STK(5);
    u32 _h_19 = STK(6);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_13;
      STK(1) = _h_14;
      STK(2) = _h_15;
      STK(3) = _h_17;
      STK(4) = _h_18;
      STK(5) = _h_19;
      STK(6) = FID_RAW_OBSERVE_K353;
      WL_PUSHN(7);
    } else {
      u64 _t_6 = task_node(e, FID_RAW_OBSERVE_K353, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_13;
      e.mem[_t_6 + 1] = _h_14;
      e.mem[_t_6 + 2] = _h_15;
      e.mem[_t_6 + 3] = _h_17;
      e.mem[_t_6 + 4] = _h_18;
      e.mem[_t_6 + 5] = _h_19;
      WL_CONT = term_tsk(FID_RAW_OBSERVE_K353, _t_6);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_16;
      e.mem[_t_7 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_16;
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_RAW_OBSERVE_K353)
  {
    WL_POPN(6);
    Term _h_21 = STK(0);
    Term _h_22 = STK(1);
    u32 _h_23 = STK(2);
    Term _h_24 = STK(3);
    u32 _h_25 = STK(4);
    u32 _h_26 = STK(5);
    Term _h_20 = r0;
    WL_OPEN
    r0 = _h_21;
    r1 = _h_22;
    r2 = _h_23;
    r3 = _h_24;
    r4 = _h_25;
    r5 = _h_26;
    r6 = _h_20;
    WL_RETN(7);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0)
  {
    Term _context_0 = r0;
    Term _context_1 = r1;
    Term _context_2 = r2;
    Term _context_3 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _context_2;
      STK(1) = _context_3;
      STK(2) = FID_CONTEXT_OBSERVE_0_K355;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_CONTEXT_OBSERVE_0_K355, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _context_2;
      e.mem[_t_0 + 1] = _context_3;
      WL_CONT = term_tsk(FID_CONTEXT_OBSERVE_0_K355, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_FACTORY_OBSERVE_0)) {
      u64 _t_1 = task_node(e, FID_FACTORY_OBSERVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _context_0;
      e.mem[_t_1 + 1] = _context_1;
      return term_tsk(FID_FACTORY_OBSERVE_0, _t_1);
    }
    r0 = _context_0;
    r1 = _context_1;
    WL_JMP(FID_FACTORY_OBSERVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0_K355)
  {
    WL_POPN(2);
    Term _context_4 = STK(0);
    Term _context_5 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _context_5;
      STK(1) = _h_0;
      STK(2) = _h_1;
      STK(3) = _h_2;
      STK(4) = FID_CONTEXT_OBSERVE_0_K356;
      WL_PUSHN(5);
    } else {
      u64 _t_2 = task_node(e, FID_CONTEXT_OBSERVE_0_K356, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _context_5;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      e.mem[_t_2 + 3] = _h_2;
      WL_CONT = term_tsk(FID_CONTEXT_OBSERVE_0_K356, _t_2);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_OUTER)) {
      u64 _t_3 = task_node(e, FID_OUTER, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _context_4;
      return term_tsk(FID_OUTER, _t_3);
    }
    r0 = _context_4;
    WL_JMP(FID_OUTER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0_K356)
  {
    WL_POPN(4);
    Term _context_6 = STK(0);
    Term _h_5 = STK(1);
    Term _h_6 = STK(2);
    Term _h_7 = STK(3);
    Term _h_3 = r0;
    Term _h_4 = r1;
    WL_OPEN
    _context_6 = term_keep(e, _context_6, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_5;
      STK(1) = _h_6;
      STK(2) = _h_7;
      STK(3) = _context_6;
      STK(4) = _h_3;
      STK(5) = _h_4;
      STK(6) = FID_CONTEXT_OBSERVE_0_K357;
      WL_PUSHN(7);
    } else {
      u64 _t_4 = task_node(e, FID_CONTEXT_OBSERVE_0_K357, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_5;
      e.mem[_t_4 + 1] = _h_6;
      e.mem[_t_4 + 2] = _h_7;
      e.mem[_t_4 + 3] = _context_6;
      e.mem[_t_4 + 4] = _h_3;
      e.mem[_t_4 + 5] = _h_4;
      WL_CONT = term_tsk(FID_CONTEXT_OBSERVE_0_K357, _t_4);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_2)) {
      u64 _t_5 = task_node(e, FID_LIST_SHOW_2, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _context_6;
      return term_tsk(FID_LIST_SHOW_2, _t_5);
    }
    r0 = _context_6;
    WL_JMP(FID_LIST_SHOW_2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0_K357)
  {
    WL_POPN(6);
    Term _h_9 = STK(0);
    Term _h_10 = STK(1);
    Term _h_11 = STK(2);
    Term _context_7 = STK(3);
    Term _h_12 = STK(4);
    Term _h_13 = STK(5);
    Term _h_8 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_9;
      STK(1) = _h_10;
      STK(2) = _h_11;
      STK(3) = _context_7;
      STK(4) = _h_12;
      STK(5) = _h_13;
      STK(6) = FID_CONTEXT_OBSERVE_0_K358;
      WL_PUSHN(7);
    } else {
      u64 _t_6 = task_node(e, FID_CONTEXT_OBSERVE_0_K358, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_9;
      e.mem[_t_6 + 1] = _h_10;
      e.mem[_t_6 + 2] = _h_11;
      e.mem[_t_6 + 3] = _context_7;
      e.mem[_t_6 + 4] = _h_12;
      e.mem[_t_6 + 5] = _h_13;
      WL_CONT = term_tsk(FID_CONTEXT_OBSERVE_0_K358, _t_6);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 585);
      e.mem[_t_7 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 585);
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0_K358)
  {
    WL_POPN(6);
    Term _h_15 = STK(0);
    Term _h_16 = STK(1);
    Term _h_17 = STK(2);
    Term _context_8 = STK(3);
    Term _h_18 = STK(4);
    Term _h_19 = STK(5);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_15;
      STK(1) = _h_16;
      STK(2) = _h_17;
      STK(3) = _context_8;
      STK(4) = _h_18;
      STK(5) = FID_CONTEXT_OBSERVE_0_K359;
      WL_PUSHN(6);
    } else {
      u64 _t_8 = task_node(e, FID_CONTEXT_OBSERVE_0_K359, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_15;
      e.mem[_t_8 + 1] = _h_16;
      e.mem[_t_8 + 2] = _h_17;
      e.mem[_t_8 + 3] = _context_8;
      e.mem[_t_8 + 4] = _h_18;
      WL_CONT = term_tsk(FID_CONTEXT_OBSERVE_0_K359, _t_8);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_19;
      e.mem[_t_9 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_19;
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0_K359)
  {
    WL_POPN(5);
    Term _h_21 = STK(0);
    Term _h_22 = STK(1);
    Term _h_23 = STK(2);
    Term _context_9 = STK(3);
    Term _h_24 = STK(4);
    Term _h_20 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_21;
      STK(1) = _h_22;
      STK(2) = _h_23;
      STK(3) = _context_9;
      STK(4) = _h_24;
      STK(5) = FID_CONTEXT_OBSERVE_0_K360;
      WL_PUSHN(6);
    } else {
      u64 _t_10 = task_node(e, FID_CONTEXT_OBSERVE_0_K360, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_21;
      e.mem[_t_10 + 1] = _h_22;
      e.mem[_t_10 + 2] = _h_23;
      e.mem[_t_10 + 3] = _context_9;
      e.mem[_t_10 + 4] = _h_24;
      WL_CONT = term_tsk(FID_CONTEXT_OBSERVE_0_K360, _t_10);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 593);
      e.mem[_t_11 + 1] = _h_20;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 593);
    r1 = _h_20;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0_K360)
  {
    WL_POPN(5);
    Term _h_26 = STK(0);
    Term _h_27 = STK(1);
    Term _h_28 = STK(2);
    Term _context_10 = STK(3);
    Term _h_29 = STK(4);
    Term _h_25 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_26;
      STK(1) = _h_27;
      STK(2) = _context_10;
      STK(3) = _h_29;
      STK(4) = FID_CONTEXT_OBSERVE_0_K361;
      WL_PUSHN(5);
    } else {
      u64 _t_12 = task_node(e, FID_CONTEXT_OBSERVE_0_K361, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_26;
      e.mem[_t_12 + 1] = _h_27;
      e.mem[_t_12 + 2] = _context_10;
      e.mem[_t_12 + 3] = _h_29;
      WL_CONT = term_tsk(FID_CONTEXT_OBSERVE_0_K361, _t_12);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_28;
      e.mem[_t_13 + 1] = _h_25;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_28;
    r1 = _h_25;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0_K361)
  {
    WL_POPN(4);
    Term _h_31 = STK(0);
    Term _h_32 = STK(1);
    Term _context_11 = STK(2);
    Term _h_33 = STK(3);
    Term _h_30 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_31;
      STK(1) = _h_32;
      STK(2) = _context_11;
      STK(3) = _h_33;
      STK(4) = FID_CONTEXT_OBSERVE_0_K362;
      WL_PUSHN(5);
    } else {
      u64 _t_14 = task_node(e, FID_CONTEXT_OBSERVE_0_K362, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_31;
      e.mem[_t_14 + 1] = _h_32;
      e.mem[_t_14 + 2] = _context_11;
      e.mem[_t_14 + 3] = _h_33;
      WL_CONT = term_tsk(FID_CONTEXT_OBSERVE_0_K362, _t_14);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 605);
      e.mem[_t_15 + 1] = _h_30;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 605);
    r1 = _h_30;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTEXT_OBSERVE_0_K362)
  {
    WL_POPN(4);
    Term _h_35 = STK(0);
    Term _h_36 = STK(1);
    Term _context_12 = STK(2);
    Term _h_37 = STK(3);
    Term _h_34 = r0;
    WL_OPEN
    r0 = _h_35;
    r1 = _h_36;
    r2 = _h_37;
    r3 = _context_12;
    r4 = _h_34;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STAGE_0)
  {
    Term _context_0 = r0;
    Term _context_1 = r1;
    Term _context_2 = r2;
    Term _context_3 = r3;
    Term _raw_0 = r4;
    Term _raw_1 = r5;
    u32 _raw_2 = r6;
    Term _raw_3 = r7;
    u32 _raw_4 = r8;
    u32 _raw_5 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STAGE_0_K369;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STAGE_0_K369, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STAGE_0_K369, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_HEAD_STAGE_0)) {
      u64 _t_1 = task_node(e, FID_HEAD_STAGE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _context_0;
      e.mem[_t_1 + 1] = _context_1;
      e.mem[_t_1 + 2] = _context_2;
      e.mem[_t_1 + 3] = _context_3;
      e.mem[_t_1 + 4] = _raw_0;
      e.mem[_t_1 + 5] = _raw_1;
      e.mem[_t_1 + 6] = _raw_2;
      e.mem[_t_1 + 7] = _raw_3;
      e.mem[_t_1 + 8] = _raw_4;
      e.mem[_t_1 + 9] = _raw_5;
      return term_tsk(FID_HEAD_STAGE_0, _t_1);
    }
    r0 = _context_0;
    r1 = _context_1;
    r2 = _context_2;
    r3 = _context_3;
    r4 = _raw_0;
    r5 = _raw_1;
    r6 = _raw_2;
    r7 = _raw_3;
    r8 = _raw_4;
    r9 = _raw_5;
    WL_JMP(FID_HEAD_STAGE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STAGE_0_K369)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _o_0[12];
    if (spin_44(e, _o_0, _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, _h_10, blk_loc(e.mem, _h_10), _h_11, blk_loc(e.mem, _h_11)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INITIAL_0)
  {
    Term _context_0 = r0;
    Term _context_1 = r1;
    Term _context_2 = r2;
    Term _context_3 = r3;
    Term _raw_0 = r4;
    Term _raw_1 = r5;
    u32 _raw_2 = r6;
    Term _raw_3 = r7;
    u32 _raw_4 = r8;
    u32 _raw_5 = r9;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _raw_0;
      STK(1) = _raw_1;
      STK(2) = _raw_2;
      STK(3) = _raw_3;
      STK(4) = _raw_4;
      STK(5) = _raw_5;
      STK(6) = FID_INITIAL_0_K386;
      WL_PUSHN(7);
    } else {
      u64 _t_0 = task_node(e, FID_INITIAL_0_K386, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _raw_0;
      e.mem[_t_0 + 1] = _raw_1;
      e.mem[_t_0 + 2] = _raw_2;
      e.mem[_t_0 + 3] = _raw_3;
      e.mem[_t_0 + 4] = _raw_4;
      e.mem[_t_0 + 5] = _raw_5;
      WL_CONT = term_tsk(FID_INITIAL_0_K386, _t_0);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONTEXT_OBSERVE_0)) {
      u64 _t_1 = task_node(e, FID_CONTEXT_OBSERVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _context_0;
      e.mem[_t_1 + 1] = _context_1;
      e.mem[_t_1 + 2] = _context_2;
      e.mem[_t_1 + 3] = _context_3;
      return term_tsk(FID_CONTEXT_OBSERVE_0, _t_1);
    }
    r0 = _context_0;
    r1 = _context_1;
    r2 = _context_2;
    r3 = _context_3;
    WL_JMP(FID_CONTEXT_OBSERVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INITIAL_0_K386)
  {
    WL_POPN(6);
    Term _raw_6 = STK(0);
    Term _raw_7 = STK(1);
    u32 _raw_8 = STK(2);
    Term _raw_9 = STK(3);
    u32 _raw_10 = STK(4);
    u32 _raw_11 = STK(5);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = _h_3;
      STK(4) = _h_4;
      STK(5) = FID_INITIAL_0_K387;
      WL_PUSHN(6);
    } else {
      u64 _t_2 = task_node(e, FID_INITIAL_0_K387, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      e.mem[_t_2 + 3] = _h_3;
      e.mem[_t_2 + 4] = _h_4;
      WL_CONT = term_tsk(FID_INITIAL_0_K387, _t_2);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RAW_OBSERVE)) {
      u64 _t_3 = task_node(e, FID_RAW_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _raw_6;
      e.mem[_t_3 + 1] = _raw_7;
      e.mem[_t_3 + 2] = _raw_8;
      e.mem[_t_3 + 3] = _raw_9;
      e.mem[_t_3 + 4] = _raw_10;
      e.mem[_t_3 + 5] = _raw_11;
      return term_tsk(FID_RAW_OBSERVE, _t_3);
    }
    r0 = _raw_6;
    r1 = _raw_7;
    r2 = _raw_8;
    r3 = _raw_9;
    r4 = _raw_10;
    r5 = _raw_11;
    WL_JMP(FID_RAW_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INITIAL_0_K387)
  {
    WL_POPN(5);
    Term _h_12 = STK(0);
    Term _h_13 = STK(1);
    Term _h_14 = STK(2);
    Term _h_15 = STK(3);
    Term _h_16 = STK(4);
    Term _h_5 = r0;
    Term _h_6 = r1;
    u32 _h_7 = r2;
    Term _h_8 = r3;
    u32 _h_9 = r4;
    u32 _h_10 = r5;
    Term _h_11 = r6;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_12;
      STK(1) = _h_13;
      STK(2) = _h_14;
      STK(3) = _h_15;
      STK(4) = _h_16;
      STK(5) = _h_5;
      STK(6) = _h_6;
      STK(7) = _h_7;
      STK(8) = _h_8;
      STK(9) = _h_9;
      STK(10) = _h_10;
      STK(11) = FID_INITIAL_0_K388;
      WL_PUSHN(12);
    } else {
      u64 _t_4 = task_node(e, FID_INITIAL_0_K388, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_12;
      e.mem[_t_4 + 1] = _h_13;
      e.mem[_t_4 + 2] = _h_14;
      e.mem[_t_4 + 3] = _h_15;
      e.mem[_t_4 + 4] = _h_16;
      e.mem[_t_4 + 5] = _h_5;
      e.mem[_t_4 + 6] = _h_6;
      e.mem[_t_4 + 7] = _h_7;
      e.mem[_t_4 + 8] = _h_8;
      e.mem[_t_4 + 9] = _h_9;
      e.mem[_t_4 + 10] = _h_10;
      WL_CONT = term_tsk(FID_INITIAL_0_K388, _t_4);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_11;
      e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 517);
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_11;
    r1 = term_ctr(CID_SCON, STAT_OFF + 517);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INITIAL_0_K388)
  {
    WL_POPN(11);
    Term _h_18 = STK(0);
    Term _h_19 = STK(1);
    Term _h_20 = STK(2);
    Term _h_21 = STK(3);
    Term _h_22 = STK(4);
    Term _h_23 = STK(5);
    Term _h_24 = STK(6);
    u32 _h_25 = STK(7);
    Term _h_26 = STK(8);
    u32 _h_27 = STK(9);
    u32 _h_28 = STK(10);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_18;
      STK(1) = _h_19;
      STK(2) = _h_20;
      STK(3) = _h_21;
      STK(4) = _h_22;
      STK(5) = _h_23;
      STK(6) = _h_24;
      STK(7) = _h_25;
      STK(8) = _h_26;
      STK(9) = _h_27;
      STK(10) = _h_28;
      STK(11) = FID_INITIAL_0_K389;
      WL_PUSHN(12);
    } else {
      u64 _t_6 = task_node(e, FID_INITIAL_0_K389, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_18;
      e.mem[_t_6 + 1] = _h_19;
      e.mem[_t_6 + 2] = _h_20;
      e.mem[_t_6 + 3] = _h_21;
      e.mem[_t_6 + 4] = _h_22;
      e.mem[_t_6 + 5] = _h_23;
      e.mem[_t_6 + 6] = _h_24;
      e.mem[_t_6 + 7] = _h_25;
      e.mem[_t_6 + 8] = _h_26;
      e.mem[_t_6 + 9] = _h_27;
      e.mem[_t_6 + 10] = _h_28;
      WL_CONT = term_tsk(FID_INITIAL_0_K389, _t_6);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 525);
      e.mem[_t_7 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 525);
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INITIAL_0_K389)
  {
    WL_POPN(11);
    Term _h_30 = STK(0);
    Term _h_31 = STK(1);
    Term _h_32 = STK(2);
    Term _h_33 = STK(3);
    Term _h_34 = STK(4);
    Term _h_35 = STK(5);
    Term _h_36 = STK(6);
    u32 _h_37 = STK(7);
    Term _h_38 = STK(8);
    u32 _h_39 = STK(9);
    u32 _h_40 = STK(10);
    Term _h_29 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_30;
      STK(1) = _h_31;
      STK(2) = _h_32;
      STK(3) = _h_33;
      STK(4) = _h_35;
      STK(5) = _h_36;
      STK(6) = _h_37;
      STK(7) = _h_38;
      STK(8) = _h_39;
      STK(9) = _h_40;
      STK(10) = FID_INITIAL_0_K390;
      WL_PUSHN(11);
    } else {
      u64 _t_8 = task_node(e, FID_INITIAL_0_K390, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_30;
      e.mem[_t_8 + 1] = _h_31;
      e.mem[_t_8 + 2] = _h_32;
      e.mem[_t_8 + 3] = _h_33;
      e.mem[_t_8 + 4] = _h_35;
      e.mem[_t_8 + 5] = _h_36;
      e.mem[_t_8 + 6] = _h_37;
      e.mem[_t_8 + 7] = _h_38;
      e.mem[_t_8 + 8] = _h_39;
      e.mem[_t_8 + 9] = _h_40;
      WL_CONT = term_tsk(FID_INITIAL_0_K390, _t_8);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_34;
      e.mem[_t_9 + 1] = _h_29;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_34;
    r1 = _h_29;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INITIAL_0_K390)
  {
    WL_POPN(10);
    Term _h_42 = STK(0);
    Term _h_43 = STK(1);
    Term _h_44 = STK(2);
    Term _h_45 = STK(3);
    Term _h_46 = STK(4);
    Term _h_47 = STK(5);
    u32 _h_48 = STK(6);
    Term _h_49 = STK(7);
    u32 _h_50 = STK(8);
    u32 _h_51 = STK(9);
    Term _h_41 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_42;
      STK(1) = _h_43;
      STK(2) = _h_44;
      STK(3) = _h_45;
      STK(4) = _h_46;
      STK(5) = _h_47;
      STK(6) = _h_48;
      STK(7) = _h_49;
      STK(8) = _h_50;
      STK(9) = _h_51;
      STK(10) = FID_INITIAL_0_K391;
      WL_PUSHN(11);
    } else {
      u64 _t_10 = task_node(e, FID_INITIAL_0_K391, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_42;
      e.mem[_t_10 + 1] = _h_43;
      e.mem[_t_10 + 2] = _h_44;
      e.mem[_t_10 + 3] = _h_45;
      e.mem[_t_10 + 4] = _h_46;
      e.mem[_t_10 + 5] = _h_47;
      e.mem[_t_10 + 6] = _h_48;
      e.mem[_t_10 + 7] = _h_49;
      e.mem[_t_10 + 8] = _h_50;
      e.mem[_t_10 + 9] = _h_51;
      WL_CONT = term_tsk(FID_INITIAL_0_K391, _t_10);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 657);
      e.mem[_t_11 + 1] = _h_41;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 657);
    r1 = _h_41;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_INITIAL_0_K391)
  {
    WL_POPN(10);
    Term _h_53 = STK(0);
    Term _h_54 = STK(1);
    Term _h_55 = STK(2);
    Term _h_56 = STK(3);
    Term _h_57 = STK(4);
    Term _h_58 = STK(5);
    u32 _h_59 = STK(6);
    Term _h_60 = STK(7);
    u32 _h_61 = STK(8);
    u32 _h_62 = STK(9);
    Term _h_52 = r0;
    WL_OPEN
    r0 = _h_53;
    r1 = _h_54;
    r2 = _h_55;
    r3 = _h_56;
    r4 = _h_57;
    r5 = _h_58;
    r6 = _h_59;
    r7 = _h_60;
    r8 = _h_61;
    r9 = _h_62;
    r10 = _h_52;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0)
  {
    Term _raw_0 = r0;
    u32 _fail_0 = r1;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = 70ull;
    Term _fv_1[1];
    _fv_1[0] = 71ull;
    Term _fv_2[1];
    _fv_2[0] = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_0), blk_new(e, 0, 0, 0, 1, _fv_1));
    Term _fv_3[1];
    _fv_3[0] = 72ull;
    Term _fv_4[1];
    _fv_4[0] = blk_new(e, 0, 0, 0, 1, _fv_3);
    Term _fv_5[1];
    _fv_5[0] = 11ull;
    Term _fv_6[1];
    _fv_6[0] = 12ull;
    Term _fv_7[1];
    _fv_7[0] = 21ull;
    Term _fv_8[1];
    _fv_8[0] = 22ull;
    Term _fv_9[1];
    _fv_9[0] = 23ull;
    Term _fv_10[1];
    _fv_10[0] = 24ull;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SCENARIO_0_K408;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_SCENARIO_0_K408, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SCENARIO_0_K408, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_INITIAL_0)) {
      u64 _t_1 = task_node(e, FID_INITIAL_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FINITENUMBER, 0);
      e.mem[_t_1 + 1] = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FINITENUMBER, 0);
      e.mem[_t_1 + 2] = blk_node(e, blk_new(e, 1, 0, 0, 1, _fv_2), blk_new(e, 1, 0, 0, 1, _fv_4));
      e.mem[_t_1 + 3] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 4] = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_5), blk_new(e, 0, 0, 0, 1, _fv_6));
      e.mem[_t_1 + 5] = _raw_0;
      e.mem[_t_1 + 6] = _fail_0;
      e.mem[_t_1 + 7] = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_7), blk_new(e, 0, 0, 0, 1, _fv_8)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_9), blk_new(e, 0, 0, 0, 1, _fv_10)));
      e.mem[_t_1 + 8] = 1;
      e.mem[_t_1 + 9] = 31ull;
      return term_tsk(FID_INITIAL_0, _t_1);
    }
    r0 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FINITENUMBER, 0);
    r1 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_FINITENUMBER, 0);
    r2 = blk_node(e, blk_new(e, 1, 0, 0, 1, _fv_2), blk_new(e, 1, 0, 0, 1, _fv_4));
    r3 = term_pak(CID_NIL, 0);
    r4 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_5), blk_new(e, 0, 0, 0, 1, _fv_6));
    r5 = _raw_0;
    r6 = _fail_0;
    r7 = blk_node(e, blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_7), blk_new(e, 0, 0, 0, 1, _fv_8)), blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_9), blk_new(e, 0, 0, 0, 1, _fv_10)));
    r8 = 1;
    r9 = 31ull;
    WL_JMP(FID_INITIAL_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K408)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_10;
      STK(1) = FID_SCENARIO_0_K409;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_SCENARIO_0_K409, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_10;
      WL_CONT = term_tsk(FID_SCENARIO_0_K409, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STAGE_0)) {
      u64 _t_3 = task_node(e, FID_STAGE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      return term_tsk(FID_STAGE_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    WL_JMP(FID_STAGE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K409)
  {
    WL_POPN(1);
    Term _h_23 = STK(0);
    u32 _h_11 = r0;
    Term _h_12 = r1;
    Term _h_13 = r2;
    Term _h_14 = r3;
    Term _h_15 = r4;
    Term _h_16 = r5;
    Term _h_17 = r6;
    Term _h_18 = r7;
    Term _h_19 = r8;
    u32 _h_20 = r9;
    Term _h_21 = r10;
    Term _h_22 = r11;
    WL_OPEN
    if (_h_11 == 0) {
      if (seq) {
        WL_ROOM(8);
        STK(0) = _h_23;
        STK(1) = _h_12;
        STK(2) = _h_13;
        STK(3) = _h_14;
        STK(4) = _h_15;
        STK(5) = _h_21;
        STK(6) = _h_22;
        STK(7) = FID_SCENARIO_0_K410;
        WL_PUSHN(8);
      } else {
        u64 _t_4 = task_node(e, FID_SCENARIO_0_K410, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _h_23;
        e.mem[_t_4 + 1] = _h_12;
        e.mem[_t_4 + 2] = _h_13;
        e.mem[_t_4 + 3] = _h_14;
        e.mem[_t_4 + 4] = _h_15;
        e.mem[_t_4 + 5] = _h_21;
        e.mem[_t_4 + 6] = _h_22;
        WL_CONT = term_tsk(FID_SCENARIO_0_K410, _t_4);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COOKED_OBSERVE)) {
        u64 _t_5 = task_node(e, FID_COOKED_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _h_16;
        e.mem[_t_5 + 1] = _h_17;
        e.mem[_t_5 + 2] = _h_18;
        e.mem[_t_5 + 3] = _h_19;
        e.mem[_t_5 + 4] = _h_20;
        return term_tsk(FID_COOKED_OBSERVE, _t_5);
      }
      r0 = _h_16;
      r1 = _h_17;
      r2 = _h_18;
      r3 = _h_19;
      r4 = _h_20;
      WL_JMP(FID_COOKED_OBSERVE);
    } else {
      if (seq) {
        WL_ROOM(9);
        STK(0) = _h_23;
        STK(1) = _h_16;
        STK(2) = _h_17;
        STK(3) = _h_18;
        STK(4) = _h_19;
        STK(5) = _h_20;
        STK(6) = _h_21;
        STK(7) = _h_22;
        STK(8) = FID_SCENARIO_0_K411;
        WL_PUSHN(9);
      } else {
        u64 _t_7 = task_node(e, FID_SCENARIO_0_K411, WL_CONT, WL_IDX, 1);
        e.mem[_t_7 + 0] = _h_23;
        e.mem[_t_7 + 1] = _h_16;
        e.mem[_t_7 + 2] = _h_17;
        e.mem[_t_7 + 3] = _h_18;
        e.mem[_t_7 + 4] = _h_19;
        e.mem[_t_7 + 5] = _h_20;
        e.mem[_t_7 + 6] = _h_21;
        e.mem[_t_7 + 7] = _h_22;
        WL_CONT = term_tsk(FID_SCENARIO_0_K411, _t_7);
        WL_IDX = 8;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CONTEXT_OBSERVE_0)) {
        u64 _t_8 = task_node(e, FID_CONTEXT_OBSERVE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_8 + 0] = _h_12;
        e.mem[_t_8 + 1] = _h_13;
        e.mem[_t_8 + 2] = _h_14;
        e.mem[_t_8 + 3] = _h_15;
        return term_tsk(FID_CONTEXT_OBSERVE_0, _t_8);
      }
      r0 = _h_12;
      r1 = _h_13;
      r2 = _h_14;
      r3 = _h_15;
      WL_JMP(FID_CONTEXT_OBSERVE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K410)
  {
    WL_POPN(7);
    Term _h_30 = STK(0);
    Term _h_31 = STK(1);
    Term _h_32 = STK(2);
    Term _h_33 = STK(3);
    Term _h_34 = STK(4);
    Term _h_35 = STK(5);
    Term _h_36 = STK(6);
    Term _h_24 = r0;
    u32 _h_25 = r1;
    Term _h_26 = r2;
    u32 _h_27 = r3;
    u32 _h_28 = r4;
    Term _h_29 = r5;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMPLETE_0)) {
      u64 _t_6 = task_node(e, FID_COMPLETE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_30;
      e.mem[_t_6 + 1] = _h_31;
      e.mem[_t_6 + 2] = _h_32;
      e.mem[_t_6 + 3] = _h_33;
      e.mem[_t_6 + 4] = _h_34;
      e.mem[_t_6 + 5] = _h_35;
      e.mem[_t_6 + 6] = _h_24;
      e.mem[_t_6 + 7] = _h_25;
      e.mem[_t_6 + 8] = _h_26;
      e.mem[_t_6 + 9] = _h_27;
      e.mem[_t_6 + 10] = _h_28;
      e.mem[_t_6 + 11] = _h_29;
      e.mem[_t_6 + 12] = _h_36;
      return term_tsk(FID_COMPLETE_0, _t_6);
    }
    r0 = _h_30;
    r1 = _h_31;
    r2 = _h_32;
    r3 = _h_33;
    r4 = _h_34;
    r5 = _h_35;
    r6 = _h_24;
    r7 = _h_25;
    r8 = _h_26;
    r9 = _h_27;
    r10 = _h_28;
    r11 = _h_29;
    r12 = _h_36;
    WL_JMP(FID_COMPLETE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K411)
  {
    WL_POPN(8);
    Term _h_42 = STK(0);
    Term _h_43 = STK(1);
    Term _h_44 = STK(2);
    u32 _h_45 = STK(3);
    Term _h_46 = STK(4);
    u32 _h_47 = STK(5);
    u32 _h_48 = STK(6);
    Term _h_49 = STK(7);
    Term _h_37 = r0;
    Term _h_38 = r1;
    Term _h_39 = r2;
    Term _h_40 = r3;
    Term _h_41 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_42;
      STK(1) = _h_49;
      STK(2) = _h_37;
      STK(3) = _h_38;
      STK(4) = _h_39;
      STK(5) = _h_40;
      STK(6) = _h_41;
      STK(7) = FID_SCENARIO_0_K412;
      WL_PUSHN(8);
    } else {
      u64 _t_9 = task_node(e, FID_SCENARIO_0_K412, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_42;
      e.mem[_t_9 + 1] = _h_49;
      e.mem[_t_9 + 2] = _h_37;
      e.mem[_t_9 + 3] = _h_38;
      e.mem[_t_9 + 4] = _h_39;
      e.mem[_t_9 + 5] = _h_40;
      e.mem[_t_9 + 6] = _h_41;
      WL_CONT = term_tsk(FID_SCENARIO_0_K412, _t_9);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_RAW_OBSERVE)) {
      u64 _t_10 = task_node(e, FID_RAW_OBSERVE, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _h_43;
      e.mem[_t_10 + 1] = _h_44;
      e.mem[_t_10 + 2] = _h_45;
      e.mem[_t_10 + 3] = _h_46;
      e.mem[_t_10 + 4] = _h_47;
      e.mem[_t_10 + 5] = _h_48;
      return term_tsk(FID_RAW_OBSERVE, _t_10);
    }
    r0 = _h_43;
    r1 = _h_44;
    r2 = _h_45;
    r3 = _h_46;
    r4 = _h_47;
    r5 = _h_48;
    WL_JMP(FID_RAW_OBSERVE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K412)
  {
    WL_POPN(7);
    Term _h_57 = STK(0);
    Term _h_58 = STK(1);
    Term _h_59 = STK(2);
    Term _h_60 = STK(3);
    Term _h_61 = STK(4);
    Term _h_62 = STK(5);
    Term _h_63 = STK(6);
    Term _h_50 = r0;
    Term _h_51 = r1;
    u32 _h_52 = r2;
    Term _h_53 = r3;
    u32 _h_54 = r4;
    u32 _h_55 = r5;
    Term _h_56 = r6;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_57;
      STK(1) = _h_59;
      STK(2) = _h_60;
      STK(3) = _h_61;
      STK(4) = _h_62;
      STK(5) = _h_63;
      STK(6) = _h_50;
      STK(7) = _h_51;
      STK(8) = _h_52;
      STK(9) = _h_53;
      STK(10) = _h_54;
      STK(11) = _h_55;
      STK(12) = _h_56;
      STK(13) = FID_SCENARIO_0_K413;
      WL_PUSHN(14);
    } else {
      u64 _t_11 = task_node(e, FID_SCENARIO_0_K413, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_57;
      e.mem[_t_11 + 1] = _h_59;
      e.mem[_t_11 + 2] = _h_60;
      e.mem[_t_11 + 3] = _h_61;
      e.mem[_t_11 + 4] = _h_62;
      e.mem[_t_11 + 5] = _h_63;
      e.mem[_t_11 + 6] = _h_50;
      e.mem[_t_11 + 7] = _h_51;
      e.mem[_t_11 + 8] = _h_52;
      e.mem[_t_11 + 9] = _h_53;
      e.mem[_t_11 + 10] = _h_54;
      e.mem[_t_11 + 11] = _h_55;
      e.mem[_t_11 + 12] = _h_56;
      WL_CONT = term_tsk(FID_SCENARIO_0_K413, _t_11);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_SHOW_1)) {
      u64 _t_12 = task_node(e, FID_LIST_SHOW_1, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_58;
      return term_tsk(FID_LIST_SHOW_1, _t_12);
    }
    r0 = _h_58;
    WL_JMP(FID_LIST_SHOW_1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K413)
  {
    WL_POPN(13);
    Term _h_65 = STK(0);
    Term _h_66 = STK(1);
    Term _h_67 = STK(2);
    Term _h_68 = STK(3);
    Term _h_69 = STK(4);
    Term _h_70 = STK(5);
    Term _h_71 = STK(6);
    Term _h_72 = STK(7);
    u32 _h_73 = STK(8);
    Term _h_74 = STK(9);
    u32 _h_75 = STK(10);
    u32 _h_76 = STK(11);
    Term _h_77 = STK(12);
    Term _h_64 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_65;
      STK(1) = _h_66;
      STK(2) = _h_67;
      STK(3) = _h_68;
      STK(4) = _h_69;
      STK(5) = _h_70;
      STK(6) = _h_71;
      STK(7) = _h_72;
      STK(8) = _h_73;
      STK(9) = _h_74;
      STK(10) = _h_75;
      STK(11) = _h_76;
      STK(12) = _h_77;
      STK(13) = FID_SCENARIO_0_K414;
      WL_PUSHN(14);
    } else {
      u64 _t_13 = task_node(e, FID_SCENARIO_0_K414, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_65;
      e.mem[_t_13 + 1] = _h_66;
      e.mem[_t_13 + 2] = _h_67;
      e.mem[_t_13 + 3] = _h_68;
      e.mem[_t_13 + 4] = _h_69;
      e.mem[_t_13 + 5] = _h_70;
      e.mem[_t_13 + 6] = _h_71;
      e.mem[_t_13 + 7] = _h_72;
      e.mem[_t_13 + 8] = _h_73;
      e.mem[_t_13 + 9] = _h_74;
      e.mem[_t_13 + 10] = _h_75;
      e.mem[_t_13 + 11] = _h_76;
      e.mem[_t_13 + 12] = _h_77;
      WL_CONT = term_tsk(FID_SCENARIO_0_K414, _t_13);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_64;
      e.mem[_t_14 + 1] = term_ctr(CID_SCON, STAT_OFF + 517);
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = _h_64;
    r1 = term_ctr(CID_SCON, STAT_OFF + 517);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K414)
  {
    WL_POPN(13);
    Term _h_79 = STK(0);
    Term _h_80 = STK(1);
    Term _h_81 = STK(2);
    Term _h_82 = STK(3);
    Term _h_83 = STK(4);
    Term _h_84 = STK(5);
    Term _h_85 = STK(6);
    Term _h_86 = STK(7);
    u32 _h_87 = STK(8);
    Term _h_88 = STK(9);
    u32 _h_89 = STK(10);
    u32 _h_90 = STK(11);
    Term _h_91 = STK(12);
    Term _h_78 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_79;
      STK(1) = _h_80;
      STK(2) = _h_81;
      STK(3) = _h_82;
      STK(4) = _h_83;
      STK(5) = _h_84;
      STK(6) = _h_85;
      STK(7) = _h_86;
      STK(8) = _h_87;
      STK(9) = _h_88;
      STK(10) = _h_89;
      STK(11) = _h_90;
      STK(12) = _h_91;
      STK(13) = FID_SCENARIO_0_K415;
      WL_PUSHN(14);
    } else {
      u64 _t_15 = task_node(e, FID_SCENARIO_0_K415, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _h_79;
      e.mem[_t_15 + 1] = _h_80;
      e.mem[_t_15 + 2] = _h_81;
      e.mem[_t_15 + 3] = _h_82;
      e.mem[_t_15 + 4] = _h_83;
      e.mem[_t_15 + 5] = _h_84;
      e.mem[_t_15 + 6] = _h_85;
      e.mem[_t_15 + 7] = _h_86;
      e.mem[_t_15 + 8] = _h_87;
      e.mem[_t_15 + 9] = _h_88;
      e.mem[_t_15 + 10] = _h_89;
      e.mem[_t_15 + 11] = _h_90;
      e.mem[_t_15 + 12] = _h_91;
      WL_CONT = term_tsk(FID_SCENARIO_0_K415, _t_15);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 625);
      e.mem[_t_16 + 1] = _h_78;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 625);
    r1 = _h_78;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K415)
  {
    WL_POPN(13);
    Term _h_93 = STK(0);
    Term _h_94 = STK(1);
    Term _h_95 = STK(2);
    Term _h_96 = STK(3);
    Term _h_97 = STK(4);
    Term _h_98 = STK(5);
    Term _h_99 = STK(6);
    Term _h_100 = STK(7);
    u32 _h_101 = STK(8);
    Term _h_102 = STK(9);
    u32 _h_103 = STK(10);
    u32 _h_104 = STK(11);
    Term _h_105 = STK(12);
    Term _h_92 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_93;
      STK(1) = _h_94;
      STK(2) = _h_95;
      STK(3) = _h_96;
      STK(4) = _h_97;
      STK(5) = _h_98;
      STK(6) = _h_99;
      STK(7) = _h_100;
      STK(8) = _h_101;
      STK(9) = _h_102;
      STK(10) = _h_103;
      STK(11) = _h_104;
      STK(12) = FID_SCENARIO_0_K416;
      WL_PUSHN(13);
    } else {
      u64 _t_17 = task_node(e, FID_SCENARIO_0_K416, WL_CONT, WL_IDX, 1);
      e.mem[_t_17 + 0] = _h_93;
      e.mem[_t_17 + 1] = _h_94;
      e.mem[_t_17 + 2] = _h_95;
      e.mem[_t_17 + 3] = _h_96;
      e.mem[_t_17 + 4] = _h_97;
      e.mem[_t_17 + 5] = _h_98;
      e.mem[_t_17 + 6] = _h_99;
      e.mem[_t_17 + 7] = _h_100;
      e.mem[_t_17 + 8] = _h_101;
      e.mem[_t_17 + 9] = _h_102;
      e.mem[_t_17 + 10] = _h_103;
      e.mem[_t_17 + 11] = _h_104;
      WL_CONT = term_tsk(FID_SCENARIO_0_K416, _t_17);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_18 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = _h_105;
      e.mem[_t_18 + 1] = _h_92;
      return term_tsk(FID_STRING_APPEND, _t_18);
    }
    r0 = _h_105;
    r1 = _h_92;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K416)
  {
    WL_POPN(12);
    Term _h_107 = STK(0);
    Term _h_108 = STK(1);
    Term _h_109 = STK(2);
    Term _h_110 = STK(3);
    Term _h_111 = STK(4);
    Term _h_112 = STK(5);
    Term _h_113 = STK(6);
    Term _h_114 = STK(7);
    u32 _h_115 = STK(8);
    Term _h_116 = STK(9);
    u32 _h_117 = STK(10);
    u32 _h_118 = STK(11);
    Term _h_106 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_107;
      STK(1) = _h_108;
      STK(2) = _h_109;
      STK(3) = _h_110;
      STK(4) = _h_111;
      STK(5) = _h_112;
      STK(6) = _h_113;
      STK(7) = _h_114;
      STK(8) = _h_115;
      STK(9) = _h_116;
      STK(10) = _h_117;
      STK(11) = _h_118;
      STK(12) = FID_SCENARIO_0_K417;
      WL_PUSHN(13);
    } else {
      u64 _t_19 = task_node(e, FID_SCENARIO_0_K417, WL_CONT, WL_IDX, 1);
      e.mem[_t_19 + 0] = _h_107;
      e.mem[_t_19 + 1] = _h_108;
      e.mem[_t_19 + 2] = _h_109;
      e.mem[_t_19 + 3] = _h_110;
      e.mem[_t_19 + 4] = _h_111;
      e.mem[_t_19 + 5] = _h_112;
      e.mem[_t_19 + 6] = _h_113;
      e.mem[_t_19 + 7] = _h_114;
      e.mem[_t_19 + 8] = _h_115;
      e.mem[_t_19 + 9] = _h_116;
      e.mem[_t_19 + 10] = _h_117;
      e.mem[_t_19 + 11] = _h_118;
      WL_CONT = term_tsk(FID_SCENARIO_0_K417, _t_19);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_20 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = term_ctr(CID_SCON, STAT_OFF + 525);
      e.mem[_t_20 + 1] = _h_106;
      return term_tsk(FID_STRING_APPEND, _t_20);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 525);
    r1 = _h_106;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K417)
  {
    WL_POPN(12);
    Term _h_120 = STK(0);
    Term _h_121 = STK(1);
    Term _h_122 = STK(2);
    Term _h_123 = STK(3);
    Term _h_124 = STK(4);
    Term _h_125 = STK(5);
    Term _h_126 = STK(6);
    Term _h_127 = STK(7);
    u32 _h_128 = STK(8);
    Term _h_129 = STK(9);
    u32 _h_130 = STK(10);
    u32 _h_131 = STK(11);
    Term _h_119 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_120;
      STK(1) = _h_121;
      STK(2) = _h_122;
      STK(3) = _h_123;
      STK(4) = _h_124;
      STK(5) = _h_126;
      STK(6) = _h_127;
      STK(7) = _h_128;
      STK(8) = _h_129;
      STK(9) = _h_130;
      STK(10) = _h_131;
      STK(11) = FID_SCENARIO_0_K418;
      WL_PUSHN(12);
    } else {
      u64 _t_21 = task_node(e, FID_SCENARIO_0_K418, WL_CONT, WL_IDX, 1);
      e.mem[_t_21 + 0] = _h_120;
      e.mem[_t_21 + 1] = _h_121;
      e.mem[_t_21 + 2] = _h_122;
      e.mem[_t_21 + 3] = _h_123;
      e.mem[_t_21 + 4] = _h_124;
      e.mem[_t_21 + 5] = _h_126;
      e.mem[_t_21 + 6] = _h_127;
      e.mem[_t_21 + 7] = _h_128;
      e.mem[_t_21 + 8] = _h_129;
      e.mem[_t_21 + 9] = _h_130;
      e.mem[_t_21 + 10] = _h_131;
      WL_CONT = term_tsk(FID_SCENARIO_0_K418, _t_21);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_22 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = _h_125;
      e.mem[_t_22 + 1] = _h_119;
      return term_tsk(FID_STRING_APPEND, _t_22);
    }
    r0 = _h_125;
    r1 = _h_119;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K418)
  {
    WL_POPN(11);
    Term _h_133 = STK(0);
    Term _h_134 = STK(1);
    Term _h_135 = STK(2);
    Term _h_136 = STK(3);
    Term _h_137 = STK(4);
    Term _h_138 = STK(5);
    Term _h_139 = STK(6);
    u32 _h_140 = STK(7);
    Term _h_141 = STK(8);
    u32 _h_142 = STK(9);
    u32 _h_143 = STK(10);
    Term _h_132 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_133;
      STK(1) = _h_134;
      STK(2) = _h_135;
      STK(3) = _h_136;
      STK(4) = _h_137;
      STK(5) = _h_138;
      STK(6) = _h_139;
      STK(7) = _h_140;
      STK(8) = _h_141;
      STK(9) = _h_142;
      STK(10) = _h_143;
      STK(11) = FID_SCENARIO_0_K419;
      WL_PUSHN(12);
    } else {
      u64 _t_23 = task_node(e, FID_SCENARIO_0_K419, WL_CONT, WL_IDX, 1);
      e.mem[_t_23 + 0] = _h_133;
      e.mem[_t_23 + 1] = _h_134;
      e.mem[_t_23 + 2] = _h_135;
      e.mem[_t_23 + 3] = _h_136;
      e.mem[_t_23 + 4] = _h_137;
      e.mem[_t_23 + 5] = _h_138;
      e.mem[_t_23 + 6] = _h_139;
      e.mem[_t_23 + 7] = _h_140;
      e.mem[_t_23 + 8] = _h_141;
      e.mem[_t_23 + 9] = _h_142;
      e.mem[_t_23 + 10] = _h_143;
      WL_CONT = term_tsk(FID_SCENARIO_0_K419, _t_23);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_24 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_24 + 0] = term_ctr(CID_SCON, STAT_OFF + 635);
      e.mem[_t_24 + 1] = _h_132;
      return term_tsk(FID_STRING_APPEND, _t_24);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 635);
    r1 = _h_132;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K419)
  {
    WL_POPN(11);
    Term _h_145 = STK(0);
    Term _h_146 = STK(1);
    Term _h_147 = STK(2);
    Term _h_148 = STK(3);
    Term _h_149 = STK(4);
    Term _h_150 = STK(5);
    Term _h_151 = STK(6);
    u32 _h_152 = STK(7);
    Term _h_153 = STK(8);
    u32 _h_154 = STK(9);
    u32 _h_155 = STK(10);
    Term _h_144 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_146;
      STK(1) = _h_147;
      STK(2) = _h_148;
      STK(3) = _h_149;
      STK(4) = _h_150;
      STK(5) = _h_151;
      STK(6) = _h_152;
      STK(7) = _h_153;
      STK(8) = _h_154;
      STK(9) = _h_155;
      STK(10) = FID_SCENARIO_0_K420;
      WL_PUSHN(11);
    } else {
      u64 _t_25 = task_node(e, FID_SCENARIO_0_K420, WL_CONT, WL_IDX, 1);
      e.mem[_t_25 + 0] = _h_146;
      e.mem[_t_25 + 1] = _h_147;
      e.mem[_t_25 + 2] = _h_148;
      e.mem[_t_25 + 3] = _h_149;
      e.mem[_t_25 + 4] = _h_150;
      e.mem[_t_25 + 5] = _h_151;
      e.mem[_t_25 + 6] = _h_152;
      e.mem[_t_25 + 7] = _h_153;
      e.mem[_t_25 + 8] = _h_154;
      e.mem[_t_25 + 9] = _h_155;
      WL_CONT = term_tsk(FID_SCENARIO_0_K420, _t_25);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_26 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_26 + 0] = _h_145;
      e.mem[_t_26 + 1] = _h_144;
      return term_tsk(FID_STRING_APPEND, _t_26);
    }
    r0 = _h_145;
    r1 = _h_144;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K420)
  {
    WL_POPN(10);
    Term _h_157 = STK(0);
    Term _h_158 = STK(1);
    Term _h_159 = STK(2);
    Term _h_160 = STK(3);
    Term _h_161 = STK(4);
    Term _h_162 = STK(5);
    u32 _h_163 = STK(6);
    Term _h_164 = STK(7);
    u32 _h_165 = STK(8);
    u32 _h_166 = STK(9);
    Term _h_156 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _o_0[6];
    if (spin_45(e, _o_0, _h_161, blk_loc(e.mem, _h_161), _h_162, blk_loc(e.mem, _h_162), _h_163, _h_164, blk_loc(e.mem, _h_164), _h_165, _h_166) == 0) {
      return 0;
    }
    _v_6 = _o_0[0];
    _v_7 = _o_0[1];
    _v_8 = _o_0[2];
    _v_9 = _o_0[3];
    _v_10 = _o_0[4];
    _v_11 = _o_0[5];
    _v_0 = _v_6;
    _v_1 = _v_7;
    _v_2 = _v_8;
    _v_3 = _v_9;
    _v_4 = _v_10;
    _v_5 = _v_11;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_156;
      STK(1) = FID_SCENARIO_0_K421;
      WL_PUSHN(2);
    } else {
      u64 _t_27 = task_node(e, FID_SCENARIO_0_K421, WL_CONT, WL_IDX, 1);
      e.mem[_t_27 + 0] = _h_156;
      WL_CONT = term_tsk(FID_SCENARIO_0_K421, _t_27);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STAGE_0)) {
      u64 _t_28 = task_node(e, FID_STAGE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _h_157;
      e.mem[_t_28 + 1] = _h_158;
      e.mem[_t_28 + 2] = _h_159;
      e.mem[_t_28 + 3] = _h_160;
      e.mem[_t_28 + 4] = _v_0;
      e.mem[_t_28 + 5] = _v_1;
      e.mem[_t_28 + 6] = _v_2;
      e.mem[_t_28 + 7] = _v_3;
      e.mem[_t_28 + 8] = _v_4;
      e.mem[_t_28 + 9] = _v_5;
      return term_tsk(FID_STAGE_0, _t_28);
    }
    r0 = _h_157;
    r1 = _h_158;
    r2 = _h_159;
    r3 = _h_160;
    r4 = _v_0;
    r5 = _v_1;
    r6 = _v_2;
    r7 = _v_3;
    r8 = _v_4;
    r9 = _v_5;
    WL_JMP(FID_STAGE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K421)
  {
    WL_POPN(1);
    Term _h_179 = STK(0);
    u32 _h_167 = r0;
    Term _h_168 = r1;
    Term _h_169 = r2;
    Term _h_170 = r3;
    Term _h_171 = r4;
    Term _h_172 = r5;
    Term _h_173 = r6;
    Term _h_174 = r7;
    Term _h_175 = r8;
    u32 _h_176 = r9;
    Term _h_177 = r10;
    Term _h_178 = r11;
    WL_OPEN
    if (_h_167 == 0) {
      if (seq) {
        WL_ROOM(8);
        STK(0) = _h_179;
        STK(1) = _h_168;
        STK(2) = _h_169;
        STK(3) = _h_170;
        STK(4) = _h_171;
        STK(5) = _h_177;
        STK(6) = _h_178;
        STK(7) = FID_SCENARIO_0_K422;
        WL_PUSHN(8);
      } else {
        u64 _t_29 = task_node(e, FID_SCENARIO_0_K422, WL_CONT, WL_IDX, 1);
        e.mem[_t_29 + 0] = _h_179;
        e.mem[_t_29 + 1] = _h_168;
        e.mem[_t_29 + 2] = _h_169;
        e.mem[_t_29 + 3] = _h_170;
        e.mem[_t_29 + 4] = _h_171;
        e.mem[_t_29 + 5] = _h_177;
        e.mem[_t_29 + 6] = _h_178;
        WL_CONT = term_tsk(FID_SCENARIO_0_K422, _t_29);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID_COOKED_OBSERVE)) {
        u64 _t_30 = task_node(e, FID_COOKED_OBSERVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_30 + 0] = _h_172;
        e.mem[_t_30 + 1] = _h_173;
        e.mem[_t_30 + 2] = _h_174;
        e.mem[_t_30 + 3] = _h_175;
        e.mem[_t_30 + 4] = _h_176;
        return term_tsk(FID_COOKED_OBSERVE, _t_30);
      }
      r0 = _h_172;
      r1 = _h_173;
      r2 = _h_174;
      r3 = _h_175;
      r4 = _h_176;
      WL_JMP(FID_COOKED_OBSERVE);
    } else {
      term_sink(e, _h_179);
      term_sink(e, _h_168);
      term_sink(e, _h_169);
      term_sink(e, _h_170);
      term_sink(e, _h_171);
      term_sink(e, _h_172);
      term_sink(e, _h_173);
      term_sink(e, _h_175);
      term_sink(e, _h_178);
      r0 = term_ctr(CID_SCON, STAT_OFF + 511);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCENARIO_0_K422)
  {
    WL_POPN(7);
    Term _h_186 = STK(0);
    Term _h_187 = STK(1);
    Term _h_188 = STK(2);
    Term _h_189 = STK(3);
    Term _h_190 = STK(4);
    Term _h_191 = STK(5);
    Term _h_192 = STK(6);
    Term _h_180 = r0;
    u32 _h_181 = r1;
    Term _h_182 = r2;
    u32 _h_183 = r3;
    u32 _h_184 = r4;
    Term _h_185 = r5;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_COMPLETE_0)) {
      u64 _t_31 = task_node(e, FID_COMPLETE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_186;
      e.mem[_t_31 + 1] = _h_187;
      e.mem[_t_31 + 2] = _h_188;
      e.mem[_t_31 + 3] = _h_189;
      e.mem[_t_31 + 4] = _h_190;
      e.mem[_t_31 + 5] = _h_191;
      e.mem[_t_31 + 6] = _h_180;
      e.mem[_t_31 + 7] = _h_181;
      e.mem[_t_31 + 8] = _h_182;
      e.mem[_t_31 + 9] = _h_183;
      e.mem[_t_31 + 10] = _h_184;
      e.mem[_t_31 + 11] = _h_185;
      e.mem[_t_31 + 12] = _h_192;
      return term_tsk(FID_COMPLETE_0, _t_31);
    }
    r0 = _h_186;
    r1 = _h_187;
    r2 = _h_188;
    r3 = _h_189;
    r4 = _h_190;
    r5 = _h_191;
    r6 = _h_180;
    r7 = _h_181;
    r8 = _h_182;
    r9 = _h_183;
    r10 = _h_184;
    r11 = _h_185;
    r12 = _h_192;
    WL_JMP(FID_COMPLETE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K424;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K424, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K424, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K424)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K426;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K426, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K426, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_0)) {
      u64 _t_1 = task_node(e, FID_SCENARIO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT, STAT_OFF + 663);
      e.mem[_t_1 + 1] = 0;
      return term_tsk(FID_SCENARIO_0, _t_1);
    }
    r0 = term_ctr(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_TEXT, STAT_OFF + 663);
    r1 = 0;
    WL_JMP(FID_SCENARIO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K426)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_MAIN_K427;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K427, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_MAIN_K427, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_0)) {
      u64 _t_3 = task_node(e, FID_SCENARIO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER, 8ull);
      e.mem[_t_3 + 1] = 1;
      return term_tsk(FID_SCENARIO_0, _t_3);
    }
    r0 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER, 8ull);
    r1 = 1;
    WL_JMP(FID_SCENARIO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K427)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_MAIN_K428;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K428, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_MAIN_K428, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCENARIO_0)) {
      u64 _t_5 = task_node(e, FID_SCENARIO_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER, 7ull);
      e.mem[_t_5 + 1] = 0;
      return term_tsk(FID_SCENARIO_0, _t_5);
    }
    r0 = term_pak(CID_________________________BENDVY_SRC_ECS_DECODE_DATA_NUMBER, 7ull);
    r1 = 0;
    WL_JMP(FID_SCENARIO_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K428)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_MAIN_K429;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_MAIN_K429, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      WL_CONT = term_tsk(FID_MAIN_K429, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 676);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 676);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K429)
  {
    WL_POPN(2);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_7;
      STK(1) = FID_MAIN_K430;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_MAIN_K430, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      WL_CONT = term_tsk(FID_MAIN_K430, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_8;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K430)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_10;
      STK(1) = FID_MAIN_K431;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K431, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_10;
      WL_CONT = term_tsk(FID_MAIN_K431, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 688);
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 688);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K431)
  {
    WL_POPN(1);
    Term _h_12 = STK(0);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K432;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K432, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K432, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_12;
      e.mem[_t_13 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_12;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K432)
  {
    Term _h_13 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 708);
      e.mem[_t_14 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 708);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========



// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
