function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// One allocator per emitted program, shared by all canonical world creations.
let bendvy_namespace_next = 1;
function bendvy_namespace_fresh() {
  if (bendvy_namespace_next >= 0xffffffff) return 0;
  return bendvy_namespace_next++;
}
io_eff("../../../../src/ecs/world-namespace.fresh", bendvy_namespace_fresh);

})();

(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["../../../../src/ecs/world-namespace.fresh","IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058create$1260$({$: "Mail", "returned": {$: "Nil"}, "installed": {$: "Nil"}, "quarantined": {$: "Nil"}, "errors": {$: "Nil"}})), run_clo((_x_1) => {
  return $created$(_x_1);
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058create$1260$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1260$(_x_2, _resource_0);
}), _x_0);
});
}

function $created$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    return (_x_0) => $IO$print$(($spawned$(($request$(_world_0, {$: "../../../../src/ecs/bundle-requests.Spawn"}, ($$$$047core$045consumer$045v4$047consumer$058sample$()))))), _x_0);
  } else {
    return (_x_1) => $IO$print$("namespace-refused\n", _x_1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_k_0) {
  return { $: "$FFI", run: $0eff["../../../../src/ecs/world-namespace.fresh"].run, need: $0eff["../../../../src/ecs/world-namespace.fresh"].need, args: [], kont: (_k_0) };
}
function $$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1260$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $spawned$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/bundle-requests.Accepted") {
    const _target_0 = _t_0["target"];
    return $spawned_before$(_target_0, ($observe$(_world_0, _target_0)));
  } else {
    const _raw_0 = _t_0["raw"];
    const _x_0 = ($state$(_world_0));
    const _x_1 = ($raw_text$(_raw_0));
    const _x_2 = ("|" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return ("spawn-refused=" + _x_3);
  }
}

function $request$(_world_0, _operation_0, _raw_0) {
  return $finish$(run_loop($$$$047core$045consumer$045v4$047consumer$058run$1261$(($$$$047core$045consumer$045v4$047consumer$058owner$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)))), {$: "../../../../src/ecs/bundle-requests.Input", "operation": _operation_0, "raw": _raw_0})));
}

function $$$$047core$045consumer$045v4$047consumer$058sample$() {
  return {$: "../../../../src/ecs/bundle-pack.Pack", "head": {$: "Some", "value": array_node([7], [9])}, "tail": {$: "../../../../src/ecs/bundle-pack.Pack", "head": {$: "Some", "value": 11}, "tail": {$: "Unit"}}};
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1260$(_created_0) {
  if (_created_0.$ === "../../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../../src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../../src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $spawned_before$(_target_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $spawned_after$(_target_0, _before_0, ($observe$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)), _target_0)));
}

function $observe$(_world_0, _target_0) {
  return $observed_array$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1261$(($$$$047core$045consumer$045v4$047consumer$058array_family$()), _world_0, _target_0)));
}

function $raw_text$(_raw_0) {
  const _t_0 = _raw_0["head"];
  if (_t_0.$ === "Some") {
    const _array_0 = _t_0["value"];
    const _t_1 = _raw_0["tail"];
    const _t_2 = _t_1["head"];
    if (_t_2.$ === "Some") {
      const _scalar_0 = _t_2["value"];
      const _t_3 = _t_1["tail"];
      const _x_0 = ($U32$show$(_scalar_0));
      const _x_1 = ($array_text$(_array_0));
      const _x_2 = (":" + _x_0);
      return (_x_1 + _x_2);
    } else {
      return "optional-empty";
    }
  } else {
    return "optional-empty";
  }
}

function $state$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _t_0 = _world_0["resource"];
  const _returned_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantined_0 = _t_0["quarantined"];
  const _errors_0 = _t_0["errors"];
  const _commands_0 = _world_0["pending"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($U32$show$(($count$1262$(_commands_0))));
  const _x_1 = ($Nat$show$(($List$length$(_errors_0))));
  const _x_2 = ("|pending=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(($count$1261$(_quarantined_0))));
  const _x_5 = ("|errors=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(($count$1260$(_installed_0))));
  const _x_8 = ("|quarantine=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($returned_text$(_returned_0));
  const _x_11 = ("|installed=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($U32$show$(_clock_0));
  const _x_14 = ("|returned=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($U32$show$(_high_0));
  const _x_17 = ("|clock=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($U32$show$(_next_0));
  const _x_20 = ("|high=" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ($U32$show$(_ns_0));
  const _x_23 = ("|next=" + _x_21);
  const _x_24 = (_x_22 + _x_23);
  return ("ns=" + _x_24);
}

function $finish$(_requested_0) {
  const _t_0 = _requested_0["fst"];
  const _batch_0 = _t_0["batch"];
  const _output_0 = _requested_0["snd"];
  return $finished$(_output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058finish$1260$(_batch_0, {$: "../../../../src/ecs/transaction.Success"})));
}

function $$$$047core$045consumer$045v4$047consumer$058run$1261$(_ctx_0, _input_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045provider$058provide_owned$1261$(_input_0, _ctx_0);
}

function $$$$047core$045consumer$045v4$047consumer$058owner$1261$(_tx_0) {
  return {$: "../../../../src/ecs/bundle-insert-adapter.Owner", "batch": {$: "../../../../src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}}, "context": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $empty$(_unit_0) {
  return {$: "../core-consumer-v4/consumer.Store", "arrays": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1260$()), "scalars": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1261$())};
}

function $spawned_after$(_target_0, _before_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  const _x_0 = ("\nspawn-after=" + _after_0);
  const _x_1 = (_before_0 + _x_0);
  return $replaced$(_world_0, _target_0, ("spawn-before=" + _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $observed_array$(_target_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _array_0 = _result_0["snd"];
  return $observed_scalar$(_array_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1260$(($$$$047core$045consumer$045v4$047consumer$058scalar_family$()), _world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047core$045consumer$045v4$047consumer$058array_family$() {
  return {$: "../../../../src/ecs/component.Family", "name": "array"};
}

function $array_text$(_value_0) {
  return $projected_array$(($$$$047core$045consumer$045v4$047consumer$058project_array$(_value_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $returned_text$(_packets_0) {
  if (_packets_0.$ === "Nil") {
    return "end";
  } else {
    const _packet_0 = _packets_0["head"];
    const _rest_0 = _packets_0["tail"];
    const _x_0 = ($returned_text$(_rest_0));
    const _x_1 = ($raw_text$(run_loop($$$$047core$045consumer$045v4$047consumer$058unpack$(_packet_0))));
    const _x_2 = ("," + _x_0);
    return (_x_1 + _x_2);
  }
}

function $count$1260$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _owners_0["tail"];
    const _x_0 = ($count$1260$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $count$1261$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _owners_0["tail"];
    const _x_0 = ($count$1261$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $count$1262$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _owners_0["tail"];
    const _x_0 = ($count$1262$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $finished$(_output_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-batch.Committed") {
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": _world_0, "snd": _output_0};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": _output_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058finish$1260$(_batch_0, _outcome_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058committed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058stage$1260$(($List$reverse$(_prepared_0)), _tx_0)), {$: "../../../../src/ecs/transaction.Success"})));
  } else {
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058failed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058originals$1260$(($List$reverse$(_prepared_0)))), _error_0, ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../../src/ecs/transaction.Failure", "error": _error_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045provider$058provide_owned$1261$(_args_0, _ctx_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1260$() {
  return {$: "../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1261$() {
  return {$: "../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $replaced$(_world_0, _target_0, _prefix_0) {
  return $replaced_result$(_prefix_0, ($request$(_world_0, {$: "../../../../src/ecs/bundle-requests.Insert", "target": _target_0}, {$: "../../../../src/ecs/bundle-pack.Pack", "head": {$: "Some", "value": array_node([13], [17])}, "tail": {$: "../../../../src/ecs/bundle-pack.Pack", "head": {$: "Some", "value": 19}, "tail": {$: "Unit"}}})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $observed_scalar$(_array_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _scalar_0 = _result_0["snd"];
  const _x_0 = ($scalar_access$(_scalar_0));
  const _x_1 = ($array_access$(_array_0));
  const _x_2 = (":" + _x_0);
  return {$: "Tuple", "fst": _world_0, "snd": (_x_1 + _x_2)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047core$045consumer$045v4$047consumer$058scalar_family$() {
  return {$: "../../../../src/ecs/component.Family", "name": "scalar"};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1261$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, ($$$$047core$045consumer$045v4$047consumer$058take_array$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $projected_array$(_result_0) {
  const _cells_0 = _result_0["snd"];
  return $List$show$1260$(_cells_0);
}

function $$$$047core$045consumer$045v4$047consumer$058project_array$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047core$045consumer$045v4$047consumer$058projected$(($$$$047core$045consumer$045v4$047consumer$058project_array$(_a_0)), ($$$$047core$045consumer$045v4$047consumer$058project_array$(_b_0)));
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047core$045consumer$045v4$047consumer$058unpack$(_packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return run_tail(_undo_0, _cooked_0);
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058committed$1260$(_observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../../../../src/ecs/bundle-batch.Committed", "world": _world_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058stage$1260$(_prepared_0, _tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058staged$1260$(_prepared_0, ($List$reverse$(_commands_0)), 0, {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Nil"}, "events": _events_0});
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058failed$1260$(_payloads_0, _error_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../../../../src/ecs/bundle-batch.Failed", "world": _world_0, "payloads": _payloads_0, "error": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058originals$1260$($0) {
  for (;;) {
    {
      const _prepared_0 = $0;
      if (_prepared_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../../../../src/ecs/bundle-batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          continue;
        } else {
          const _payload_0 = _t_0["payload"];
          const _tail_1 = _prepared_0["tail"];
          return {$: "Con", "head": _payload_0, "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058originals$1260$(_tail_1))};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, _ctx_0) {
  return $$$$047core$045consumer$045v4$047consumer$058body$1261$(_args_0, _ctx_0);
}

function $replaced_result$(_prefix_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/bundle-requests.Accepted") {
    const _target_0 = _t_0["target"];
    return $replaced_observed$(_target_0, _prefix_0, ($observe$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)), _target_0)));
  } else {
    const _raw_0 = _t_0["raw"];
    const _x_0 = ($state$(_world_0));
    const _x_1 = ($raw_text$(_raw_0));
    const _x_2 = ("|" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ("\ninsert-refused=" + _x_3);
    return (_prefix_0 + _x_4);
  }
}

function $array_access$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/component.Found") {
    const _cells_0 = _value_0["value"];
    return $List$show$1260$(_cells_0);
  } else if (_value_0.$ === "../../../../src/ecs/component.ComponentAbsent") {
    return "absent";
  } else {
    return "missing";
  }
}

function $scalar_access$(_value_0) {
  if (_value_0.$ === "../../../../src/ecs/component.Found") {
    const _value_1 = _value_0["value"];
    return $U32$show$(_value_1);
  } else if (_value_0.$ === "../../../../src/ecs/component.ComponentAbsent") {
    return "absent";
  } else {
    return "missing";
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, ($$$$047core$045consumer$045v4$047consumer$058take_scalar$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)));
}

function $$$$047core$045consumer$045v4$047consumer$058take_array$(_store_0) {
  const _arrays_0 = _store_0["arrays"];
  const _scalars_0 = _store_0["scalars"];
  return {$: "Tuple", "fst": _scalars_0, "snd": _arrays_0};
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047core$045consumer$045v4$047consumer$058projected$(_left_0, _right_0) {
  const _a_0 = _left_0["fst"];
  const _xs_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _ys_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ($List$append$(_xs_0, _ys_0))};
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058staged$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _prepared_0 = $0;
      const _commands_0 = $1;
      const _current_0 = $2;
      const _tx_0 = $3;
      if (_prepared_0.$ === "Nil") {
        return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058remaining$1260$(_commands_0, _tx_0);
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../../../../src/ecs/bundle-batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          $1 = _commands_0;
          $2 = _current_0;
          $3 = _tx_0;
          continue;
        } else {
          const _target_1 = _t_0["target"];
          const _payload_0 = _t_0["payload"];
          const _position_0 = _t_0["position"];
          const _tail_1 = _prepared_0["tail"];
          return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058staged_after$1260$(_target_1, _payload_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058staged$1260$(_tail_1, _x_0, _position_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058preceding$1260$((_position_0 < _current_0 ? 0 : _position_0 - _current_0), _commands_0, _tx_0)));
        }
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047core$045consumer$045v4$047consumer$058body$1261$(_input_0, _ctx_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058owned_request$1261$(_ctx_0, _input_0);
}

function $replaced_observed$(_target_0, _prefix_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ("\ninsert=" + _view_0);
  return $restored_observed$(_target_0, (_prefix_0 + _x_0), ($observe$(($unwind$(_world_0)), _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0)));
}

function $$$$047core$045consumer$045v4$047consumer$058take_scalar$(_store_0) {
  const _arrays_0 = _store_0["arrays"];
  const _scalars_0 = _store_0["scalars"];
  return {$: "Tuple", "fst": _arrays_0, "snd": _scalars_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_array$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1261$(_value_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058remaining$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _tx_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _tx_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058staged_after$1260$(_target_0, _payload_0, _next_0, _result_0) {
  const _after_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return run_tail(_next_0(_after_0), ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045delivery$058enqueue$1260$(_before_0, _target_0, _payload_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058preceding$1260$($0, $1, $2) {
  for (;;) {
    {
      const _count_0 = $0;
      const _commands_0 = $1;
      const _tx_0 = $2;
      if (_count_0 === 0) {
        return {$: "Tuple", "fst": _commands_0, "snd": _tx_0};
      } else {
        const _rest_0 = (_count_0 - 1);
        if (_commands_0.$ === "Nil") {
          return {$: "Tuple", "fst": {$: "Nil"}, "snd": _tx_0};
        } else {
          const _command_0 = _commands_0["head"];
          const _tail_0 = _commands_0["tail"];
          $0 = _rest_0;
          $1 = _tail_0;
          $2 = ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058owned_request$1261$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058owned_request_field$1261$({$: "../../../../src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047core$045consumer$045v4$047consumer$058request$1261$(_x_0, _x_1);
});
})}))(_ctx_0), _input_0);
}

function $restored_observed$(_target_0, _prefix_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ("\nrestore=" + _view_0);
  return $cleanup_observed$((_prefix_0 + _x_0), ($observe$(($unwind$(_world_0)), _target_0)));
}

function $unwind$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _returned_0 = _t_0["returned"];
  const _t_1 = _t_0["installed"];
  if (_t_1.$ === "Con") {
    const _t_2 = _t_1["head"];
    const _inverse_0 = _t_2["inverse"];
    const _undo_0 = _t_2["undo"];
    const _receipts_0 = _t_1["tail"];
    const _quarantined_0 = _t_0["quarantined"];
    const _errors_0 = _t_0["errors"];
    const _events_0 = _world_0["events"];
    const _commands_0 = _world_0["pending"];
    const _regs_0 = _world_0["registrations"];
    const _system_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return $unwound$(_undo_0, _inverse_0({$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "Mail", "returned": _returned_0, "installed": _receipts_0, "quarantined": _quarantined_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}));
  } else {
    const _quarantined_1 = _t_0["quarantined"];
    const _errors_1 = _t_0["errors"];
    const _events_1 = _world_0["events"];
    const _commands_1 = _world_0["pending"];
    const _regs_1 = _world_0["registrations"];
    const _system_1 = _world_0["nextSystemId"];
    const _clock_1 = _world_0["clock"];
    return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "Mail", "returned": _returned_0, "installed": _t_1, "quarantined": _quarantined_1, "errors": _errors_1}, "events": _events_1, "pending": _commands_1, "registrations": _regs_1, "nextSystemId": _system_1, "clock": _clock_1};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_scalar$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047core$045consumer$045v4$047consumer$058put_array$(_scalars_0, _arrays_0) {
  return {$: "../core-consumer-v4/consumer.Store", "arrays": _arrays_0, "scalars": _scalars_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045delivery$058enqueue$1260$(_tx_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045delivery$058apply$1260$(_x_0, _handle_0, _payload_0);
}));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058owned_request_field$1261$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $$$$047core$045consumer$045v4$047consumer$058request$1261$(_ctx_0, _input_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058request$1261$(_ctx_0, _input_0);
}

function $cleanup_observed$(_prefix_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ($state$(_world_0));
  const _x_1 = ("|" + _x_0);
  const _x_2 = (_view_0 + _x_1);
  const _x_3 = ("\ncleanup=" + _x_2);
  return (_prefix_0 + _x_3);
}

function $unwound$(_undo_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _entries_0 = _result_0["payload"];
    return $remember$(_world_0, {$: "../core-consumer-v4/consumer.Packet", "cooked": _undo_0(($$$$047core$045consumer$045v4$047consumer$058raw_of$(_entries_0))), "undo": run_clo((_x_0) => {
  return _x_0;
})});
  } else {
    const _t_0 = _result_0["world"];
    const _ns_0 = _t_0["namespace"];
    const _next_0 = _t_0["nextId"];
    const _high_0 = _t_0["highWater"];
    const _live_0 = _t_0["live"];
    const _cap_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _store_0 = _t_0["store"];
    const _t_1 = _t_0["resource"];
    const _returned_0 = _t_1["returned"];
    const _installed_0 = _t_1["installed"];
    const _quarantined_0 = _t_1["quarantined"];
    const _errors_0 = _t_1["errors"];
    const _events_0 = _t_0["events"];
    const _commands_0 = _t_0["pending"];
    const _regs_0 = _t_0["registrations"];
    const _system_0 = _t_0["nextSystemId"];
    const _clock_0 = _t_0["clock"];
    const _recovery_0 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "Mail", "returned": _returned_0, "installed": _installed_0, "quarantined": {$: "Con", "head": {$: "Quarantine", "recovery": _recovery_0, "undo": _undo_0, "error": _error_0}, "tail": _quarantined_0}, "errors": {$: "Con", "head": _error_0, "tail": _errors_0}}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
  }
}

function $$$$047core$045consumer$045v4$047consumer$058put_scalar$(_arrays_0, _scalars_0) {
  return {$: "../core-consumer-v4/consumer.Store", "arrays": _arrays_0, "scalars": _scalars_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045delivery$058apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045delivery$058apply_checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058request$1261$(_owner_0, _input_0) {
  const _batch_0 = _owner_0["batch"];
  const _context_0 = _owner_0["context"];
  const _operation_0 = _input_0["operation"];
  const _raw_0 = _input_0["raw"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058constructed$1261$(_batch_0, _operation_0, ($$$$047core$045consumer$045v4$047consumer$058construct$(_context_0, _raw_0)));
}

function $remember$(_world_0, _packet_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _returned_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantined_0 = _t_0["quarantined"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "Mail", "returned": {$: "Con", "head": _packet_0, "tail": _returned_0}, "installed": _installed_0, "quarantined": _quarantined_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047core$045consumer$045v4$047consumer$058raw_of$(_entries_0) {
  const _t_0 = _entries_0["head"];
  const _array_0 = _t_0["owner"];
  const _t_1 = _entries_0["tail"];
  const _t_2 = _t_1["head"];
  const _scalar_0 = _t_2["owner"];
  const _t_3 = _t_1["tail"];
  return {$: "../../../../src/ecs/bundle-pack.Pack", "head": _array_0, "tail": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _scalar_0, "tail": {$: "Unit"}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($$$$047core$045consumer$045v4$047consumer$058project_array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047core$045consumer$045v4$047consumer$058project_array$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047core$045consumer$045v4$047consumer$058project_array$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045delivery$058apply_checked$1260$(_observed_0, _handle_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $recover$(_world_0, _payload_0, {$: "../../../../src/ecs/world.MissingEntity"});
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045delivery$058deliver$1260$(($attempt$(_world_0, _handle_0, _payload_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058constructed$1261$(_batch_0, _operation_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-construction.Failed") {
    const _context_0 = _result_0["context"];
    const _raw_0 = _result_0["raw"];
    const _positions_0 = _result_0["positions"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../src/ecs/bundle-requests.Refused", "raw": _raw_0, "error": {$: "../../../../src/ecs/bundle-insert-adapter.ConstructionRefused", "positions": _positions_0}}};
  } else {
    const _context_1 = _result_0["context"];
    const _cooked_0 = _result_0["cooked"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058enqueue$1261$(_batch_0, _context_1, _operation_0, ($$$$047core$045consumer$045v4$047consumer$058pack$(_cooked_0, _undo_0)));
  }
}

function $$$$047core$045consumer$045v4$047consumer$058construct$(_ctx_0, _raw_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058stage$1261$(_ctx_0, _raw_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($$$$047core$045consumer$045v4$047consumer$058project_scalar$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047core$045consumer$045v4$047consumer$058project_scalar$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047core$045consumer$045v4$047consumer$058project_scalar$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(($$$$047core$045consumer$045v4$047consumer$058project_array$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047core$045consumer$045v4$047consumer$058project_array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../../src/ecs/column.Indexed", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($$$$047core$045consumer$045v4$047consumer$058project_array$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047core$045consumer$045v4$047consumer$058project_array$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $recover$(_world_0, _packet_0, _error_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _returned_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantined_0 = _t_0["quarantined"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "Mail", "returned": {$: "Con", "head": _packet_0, "tail": _returned_0}, "installed": _installed_0, "quarantined": _quarantined_0, "errors": {$: "Con", "head": _error_0, "tail": _errors_0}}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045delivery$058deliver$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-delivery.Delivered") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $recover$(_world_1, _payload_0, _error_0);
  }
}

function $attempt$(_world_0, _target_0, _packet_0) {
  return $attempted$(($$$$047core$045consumer$045v4$047consumer$058install_recipe$1261$(_world_0, _target_0, _packet_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058enqueue$1261$(_batch_0, _context_0, _operation_0, _packet_0) {
  if (_operation_0.$ === "../../../../src/ecs/bundle-requests.Spawn") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058spawned$1261$(_context_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058spawn$1261$(_batch_0, _packet_0)));
  } else {
    const _target_0 = _operation_0["target"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058inserted$1261$(_context_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058insert$1261$(_batch_0, _target_0, _packet_0)));
  }
}

function $$$$047core$045consumer$045v4$047consumer$058pack$(_cooked_0, _undo_0) {
  return {$: "../core-consumer-v4/consumer.Packet", "cooked": _cooked_0, "undo": _undo_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058stage$1261$(_ctx_0, _raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058constructed_head$1261$(_tail_0, ($$$$047core$045consumer$045v4$047consumer$058construct_array$(_ctx_0, _head_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047core$045consumer$045v4$047consumer$058project_scalar$(_value_0) {
  const _copy_0 = _value_0;
  return {$: "Tuple", "fst": _copy_0, "snd": _copy_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(($$$$047core$045consumer$045v4$047consumer$058project_scalar$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047core$045consumer$045v4$047consumer$058project_scalar$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../src/ecs/column.Indexed", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($$$$047core$045consumer$045v4$047consumer$058project_scalar$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047core$045consumer$045v4$047consumer$058project_scalar$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $attempted$(_result_0) {
  const _observed_0 = _result_0["fst"];
  const _undo_0 = _result_0["snd"];
  return $installed$(_undo_0, _observed_0);
}

function $$$$047core$045consumer$045v4$047consumer$058install_recipe$1261$(_world_0, _target_0, _packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058install_entries$1261$(_world_0, ($$$$047core$045consumer$045v4$047consumer$058entries$(_target_0, _cooked_0)))), "snd": _undo_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058spawned$1261$(_context_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-batch.Spawned") {
    const _batch_0 = _result_0["batch"];
    const _target_0 = _result_0["target"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../src/ecs/bundle-requests.Accepted", "target": _target_0, "spawned": true}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _packet_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/bundle-insert-adapter.Owner", "batch": _batch_1, "context": _context_0}, "snd": {$: "../../../../src/ecs/bundle-requests.Refused", "raw": run_loop($$$$047core$045consumer$045v4$047consumer$058unpack$(_packet_0)), "error": {$: "../../../../src/ecs/bundle-insert-adapter.EntityRefused", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058spawn$1261$(_batch_0, _payload_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058spawn_reserved$1261$(_prepared_0, _payload_0, ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, {$: "Unit"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045requests$058inserted$1261$(_context_0, _target_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../src/ecs/bundle-requests.Accepted", "target": _target_0, "spawned": false}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _packet_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/bundle-insert-adapter.Owner", "batch": _batch_1, "context": _context_0}, "snd": {$: "../../../../src/ecs/bundle-requests.Refused", "raw": run_loop($$$$047core$045consumer$045v4$047consumer$058unpack$(_packet_0)), "error": {$: "../../../../src/ecs/bundle-insert-adapter.EntityRefused", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058insert$1261$(_batch_0, _target_0, _payload_0) {
  const _t_0 = _batch_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058checked$1261$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058constructed_head$1261$(_tail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/bundle-construction.Constructed") {
    const _head_0 = _t_0["cooked"];
    const _undo_0 = _t_0["undo"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058constructed_tail$1261$(_head_0, _undo_0, ($$$$047core$045consumer$045v4$047consumer$058stage_scalar$(_ctx_0, _tail_0)));
  } else {
    const _head_1 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058invalid_tail$1261$(_head_1, _error_0, ($$$$047core$045consumer$045v4$047consumer$058stage_scalar$(_ctx_0, _tail_0)));
  }
}

function $$$$047core$045consumer$045v4$047consumer$058construct_array$(_ctx_0, _owner_0) {
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../../src/ecs/bundle-construction.Constructed", "cooked": _owner_0, "undo": run_clo((_x_0) => {
  return _x_0;
})}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $installed$(_undo_0, _observed_0) {
  if (_observed_0.$ === "../../../../src/ecs/bundle-install.Installed") {
    const _t_0 = _observed_0["world"];
    const _ns_0 = _t_0["namespace"];
    const _next_0 = _t_0["nextId"];
    const _high_0 = _t_0["highWater"];
    const _live_0 = _t_0["live"];
    const _cap_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _store_0 = _t_0["store"];
    const _t_1 = _t_0["resource"];
    const _returned_0 = _t_1["returned"];
    const _receipts_0 = _t_1["installed"];
    const _quarantined_0 = _t_1["quarantined"];
    const _errors_0 = _t_1["errors"];
    const _events_0 = _t_0["events"];
    const _commands_0 = _t_0["pending"];
    const _regs_0 = _t_0["registrations"];
    const _system_0 = _t_0["nextSystemId"];
    const _clock_0 = _t_0["clock"];
    const _inverse_0 = _observed_0["undo"];
    return {$: "../../../../src/ecs/bundle-delivery.Delivered", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "Mail", "returned": _returned_0, "installed": {$: "Con", "head": {$: "Saved", "inverse": _inverse_0, "undo": _undo_0}, "tail": _receipts_0}, "quarantined": _quarantined_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}};
  } else if (_observed_0.$ === "../../../../src/ecs/bundle-install.Refused") {
    const _world_0 = _observed_0["world"];
    const _entries_0 = _observed_0["payload"];
    const _error_0 = _observed_0["error"];
    return {$: "../../../../src/ecs/bundle-delivery.Undelivered", "world": _world_0, "payload": {$: "../core-consumer-v4/consumer.Packet", "cooked": ($$$$047core$045consumer$045v4$047consumer$058raw_of$(_entries_0)), "undo": _undo_0}, "error": _error_0};
  } else {
    const _t_2 = _observed_0["world"];
    const _ns_1 = _t_2["namespace"];
    const _next_1 = _t_2["nextId"];
    const _high_1 = _t_2["highWater"];
    const _live_1 = _t_2["live"];
    const _cap_1 = _t_2["capacity"];
    const _depth_1 = _t_2["depth"];
    const _store_1 = _t_2["store"];
    const _t_3 = _t_2["resource"];
    const _returned_1 = _t_3["returned"];
    const _receipts_1 = _t_3["installed"];
    const _quarantined_1 = _t_3["quarantined"];
    const _errors_1 = _t_3["errors"];
    const _events_1 = _t_2["events"];
    const _commands_1 = _t_2["pending"];
    const _regs_1 = _t_2["registrations"];
    const _system_1 = _t_2["nextSystemId"];
    const _clock_1 = _t_2["clock"];
    const _recovery_0 = _observed_0["recovery"];
    const _error_1 = _observed_0["error"];
    return {$: "../../../../src/ecs/bundle-delivery.Delivered", "world": {$: "../../../../src/ecs/world.World", "namespace": _ns_1, "nextId": _next_1, "highWater": _high_1, "live": _live_1, "capacity": _cap_1, "depth": _depth_1, "store": _store_1, "resource": {$: "Mail", "returned": _returned_1, "installed": _receipts_1, "quarantined": {$: "Con", "head": {$: "Quarantine", "recovery": _recovery_0, "undo": _undo_0, "error": _error_1}, "tail": _quarantined_1}, "errors": {$: "Con", "head": _error_1, "tail": _errors_1}}, "events": _events_1, "pending": _commands_1, "registrations": _regs_1, "nextSystemId": _system_1, "clock": _clock_1}};
  }
}

function $$$$047core$045consumer$045v4$047consumer$058install_entries$1261$(_world_0, _entries_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058install$1262$(_world_0, _entries_0);
}

function $$$$047core$045consumer$045v4$047consumer$058entries$(_target_0, _raw_0) {
  const _array_0 = _raw_0["head"];
  const _t_0 = _raw_0["tail"];
  const _scalar_0 = _t_0["head"];
  const _t_1 = _t_0["tail"];
  return {$: "../../../../src/ecs/bundle-pack.Pack", "head": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": _array_0}, "tail": {$: "../../../../src/ecs/bundle-pack.Pack", "head": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": _scalar_0}, "tail": {$: "Unit"}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058spawn_reserved$1261$(_prepared_0, _payload_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "../../../../src/ecs/world.Reserved") {
    const _target_0 = _t_1["handle"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058spawn_positioned$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058positioned$1261$({$: "Con", "head": {$: "../../../../src/ecs/bundle-batch.ReservationReceipt", "target": _target_0}, "tail": _prepared_0}, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058count_commands$1261$(_commands_0)))));
  } else {
    const _error_0 = _t_1["error"];
    return {$: "../../../../src/ecs/bundle-batch.SpawnRefused", "batch": {$: "../../../../src/ecs/bundle-batch.Batch", "tx": {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1261$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058checked$1261$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_checked$1261$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_prepared_0, _target_0)));
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058count_commands$1261$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058constructed_tail$1261$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../../../../src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../src/ecs/bundle-construction.Valid", "context": _ctx_0, "cooked": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058undo_pack$1261$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047core$045consumer$045v4$047consumer$058stage_scalar$(_ctx_0, _raw_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058stage$1260$(_ctx_0, _raw_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058invalid_tail$1261$(_head_0, _error_0, _tail_0) {
  if (_tail_0.$ === "../../../../src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../src/ecs/bundle-construction.Failed", "context": _ctx_0, "raw": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _undo_0(_cooked_0)}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _raw_0}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058install$1262$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058installed_head$1262$(($$$$047core$045consumer$045v4$047consumer$058install_array$1261$(_world_0, _head_0)), _tail_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058spawn_positioned$1261$(_target_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "../../../../src/ecs/bundle-batch.Spawned", "batch": _batch_0, "target": _target_0};
  } else {
    const _batch_1 = _result_0["batch"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-batch.SpawnRefused", "batch": _batch_1, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/bundle-batch.Inserted", "batch": {$: "../../../../src/ecs/bundle-batch.Batch", "tx": {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": {$: "Con", "head": {$: "../../../../src/ecs/bundle-batch.Prepared", "target": _target_0, "payload": _payload_0, "position": _position_0}, "tail": _prepared_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058count_commands$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058counted$1261$(_command_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058count_commands$1261$(_tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1261$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_checked$1261$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _result_0) {
  const _prepared_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../../../../src/ecs/bundle-batch.Refused", "batch": {$: "../../../../src/ecs/bundle-batch.Batch", "tx": {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": {$: "../../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058count_commands$1261$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_prepared_0, _target_0) {
  if (_prepared_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": false};
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../../../../src/ecs/bundle-batch.Prepared") {
      const _handle_0 = _t_0["target"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _tail_0 = _prepared_0["tail"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_join$1260$({$: "../../../../src/ecs/bundle-batch.Prepared", "target": _handle_0, "payload": _payload_0, "position": _position_0}, false, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_tail_0, _target_0)));
    } else {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _tail_1 = _prepared_0["tail"];
      const _otherNs_0 = _target_0["namespace"];
      const _otherId_0 = _target_0["id"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_join$1260$({$: "../../../../src/ecs/bundle-batch.ReservationReceipt", "target": {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}}, ($Bool$and$((_ns_0 === _otherNs_0), (_id_0 === _otherId_0))), ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_tail_1, {$: "../../../../src/ecs/world.Handle", "namespace": _otherNs_0, "id": _otherId_0})));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058undo_pack$1261$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../../../../src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058stage$1260$(_ctx_0, _raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058constructed_head$1260$(_tail_0, ($$$$047core$045consumer$045v4$047consumer$058construct_scalar$(_ctx_0, _head_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058installed_head$1262$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../../../../src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058installed_tail$1262$(_undo_0, ($$$$047core$045consumer$045v4$047consumer$058install_scalar_tail$1261$(_world_2, _tail_0)));
  }
}

function $$$$047core$045consumer$045v4$047consumer$058install_array$1261$(_world_0, _entry_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058install$1263$(($$$$047core$045consumer$045v4$047consumer$058array_family$()), _world_0, _entry_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058counted$1261$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1261$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1261$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045batch$058receipt_join$1260$(_entry_0, _seen_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _found_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _tail_0}, "snd": (_seen_0 || _found_0)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058constructed_head$1260$(_tail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/bundle-construction.Constructed") {
    const _head_0 = _t_0["cooked"];
    const _undo_0 = _t_0["undo"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058constructed_tail$1260$(_head_0, _undo_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058terminal$1260$(_ctx_0, _tail_0)));
  } else {
    const _head_1 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058invalid_tail$1260$(_head_1, _error_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058terminal$1260$(_ctx_0, _tail_0)));
  }
}

function $$$$047core$045consumer$045v4$047consumer$058construct_scalar$(_ctx_0, _owner_0) {
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../../../../src/ecs/bundle-construction.Constructed", "cooked": _owner_0, "undo": run_clo((_x_0) => {
  return _x_0;
})}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058installed_tail$1262$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058refused_head$1262$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../../../../src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../../../../src/ecs/bundle-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058restored_tail$1262$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047core$045consumer$045v4$047consumer$058install_scalar_tail$1261$(_world_0, _tail_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058install$1263$(_world_0, _tail_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058install$1263$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058stamped$1263$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1263$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1261$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058constructed_tail$1260$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../../../../src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../src/ecs/bundle-construction.Valid", "context": _ctx_0, "cooked": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058undo_pack$1260$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058terminal$1260$(_ctx_0, _raw_0) {
  return {$: "../../../../src/ecs/bundle-construction.Valid", "context": _ctx_0, "cooked": {$: "Unit"}, "undo": run_clo((_x_0) => {
  return _x_0;
}), "positions": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058invalid_tail$1260$(_head_0, _error_0, _tail_0) {
  if (_tail_0.$ === "../../../../src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../src/ecs/bundle-construction.Failed", "context": _ctx_0, "raw": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _undo_0(_cooked_0)}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _raw_0}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058refused_head$1262$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058restored_tail$1262$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058restored_head$1262$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058install$1263$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058installed_head$1263$(($$$$047core$045consumer$045v4$047consumer$058install_scalar$1261$(_world_0, _head_0)), _tail_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058stamped$1263$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058replaced$1263$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1263$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1263$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058spawned$1261$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Accepted") {
    return _world_0;
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045construction$058undo_pack$1260$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../../../../src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058restored_head$1262$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../src/ecs/bundle-install.Restored", "world": _world_0, "payload": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058installed_head$1263$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../../../../src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058installed_tail$1263$(_undo_0, ($$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058terminal$1261$(_world_2, _tail_0)));
  }
}

function $$$$047core$045consumer$045v4$047consumer$058install_scalar$1261$(_world_0, _entry_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058install$1262$(($$$$047core$045consumer$045v4$047consumer$058scalar_family$()), _world_0, _entry_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058replaced$1263$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../src/ecs/bundle-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo$1263$({$: "../../../../src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1263$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1263$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1263$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058installed_tail$1263$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058refused_head$1263$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../../../../src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../../../../src/ecs/bundle-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058restored_tail$1263$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058terminal$1261$(_world_0, _payload_0) {
  return {$: "../../../../src/ecs/bundle-install.Installed", "world": _world_0, "undo": run_clo((_x_0) => {
  return {$: "../../../../src/ecs/bundle-install.Restored", "world": _x_0, "payload": {$: "Unit"}};
})};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058install$1262$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058stamped$1262$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1262$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo$1263$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo_checked$1263$({$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1263$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1263$(_id_0, ($$$$047core$045consumer$045v4$047consumer$058take_array$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058refused_head$1263$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058restored_tail$1263$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058restored_head$1263$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058stamped$1262$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058replaced$1262$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1262$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo_checked$1263$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../../../src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo_present$1263$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1263$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1263$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1263$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045install$058restored_head$1263$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../src/ecs/bundle-install.Restored", "world": _world_0, "payload": {$: "../../../../src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058replaced$1262$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../src/ecs/bundle-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo$1262$({$: "../../../../src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1262$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1262$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo_present$1263$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undone$1263$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1263$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1263$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_array$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo$1262$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo_checked$1262$({$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1262$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1262$(_id_0, ($$$$047core$045consumer$045v4$047consumer$058take_scalar$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undone$1263$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../../../../src/ecs/bundle-install.Restored", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1263$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../../../../src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047core$045consumer$045v4$047consumer$058take_array$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo_checked$1262$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../../../src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo_present$1262$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1262$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1262$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1262$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1263$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1263$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undo_present$1262$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undone$1262$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1262$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1262$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_scalar$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1263$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1263$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1263$(_id_0, _stamp_0, ($$$$047core$045consumer$045v4$047consumer$058take_array$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_array$(_rest_0, _column_1)), "snd": {$: "../../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047bundle$045component$045install$058undone$1262$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../../../../src/ecs/bundle-install.Restored", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../../../../src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047core$045consumer$045v4$047consumer$058take_scalar$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1263$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_array$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_array$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, ($$$$047core$045consumer$045v4$047consumer$058take_scalar$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_scalar$(_rest_0, _column_1)), "snd": {$: "../../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_scalar$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047core$045consumer$045v4$047consumer$058put_scalar$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_rest_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);