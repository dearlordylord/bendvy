import { Descriptor, Result, Schema } from "@typeonce/bevy-ts"
import * as Size2 from "@typeonce/bevy-ts-math/Size2"
import * as Vector2 from "@typeonce/bevy-ts-math/Vector2"
import type { EntityMut } from "@typeonce/bevy-ts/Entity"
import * as Query from "@typeonce/bevy-ts/Query"
import * as System from "@typeonce/bevy-ts/System"
import type { Query as QueryTypes } from "@typeonce/bevy-ts/Query"
import { describe, expect, it } from "tstyche"

const Position = Descriptor.Component<{ x: number; y: number }>()("Position")
const Velocity = Descriptor.Component<{ x: number; y: number }>()("Velocity")
const Time = Descriptor.Resource<number>()("Time")
const TickEvent = Descriptor.Event<{ dt: number }>()("TickEvent")
const Phase = Descriptor.Resource<"Running" | "Paused">()("Phase")
const Logger = Descriptor.Service<{ log: (message: string) => void }>()("Logger")
const SafePosition = Descriptor.ConstructedComponent(Vector2)("SafePosition")
const Viewport = Descriptor.ConstructedResource(Size2)("Viewport")
const Camera = Descriptor.ConstructedResource(Vector2)("Camera")

const Game = Schema.bind(Schema.fragment({
  components: {
    Position,
    Velocity,
    SafePosition
  },
  resources: {
    Time,
    Viewport,
    Phase,
    Camera
  },
  events: {
    TickEvent
  }
}))
const schema = Game.schema

describe("System", () => {
  it("derives context from the explicit spec", () => {
    const query = Query.Query({
      selection: {
        position: Query.write(SafePosition),
        velocity: Query.read(Velocity)
      }
    })

    const system = System.System(
      "Move",
      {
        schema,
        queries: {
          moving: query
        },
        resources: {
          time: System.readResource(Time),
          viewport: System.writeResource(Viewport),
          phase: System.writeResource(Phase),
          camera: System.writeResource(Camera)
        },
        events: {
          tick: System.writeEvent(TickEvent)
        },
        services: {
          logger: System.service(Logger)
        }
      },
      ({ queries, resources, events, services }) =>
        {
          expect(queries.moving.each()).type.toBe<ReadonlyArray<{
            readonly entity: EntityMut<typeof schema, {
              readonly position: Query.ReadonlyValue<Vector2.Vector2>
              readonly velocity: Query.ReadonlyValue<{ x: number; y: number }>
            }, {
              readonly position: Query.ReadonlyValue<Vector2.Vector2>
            }>
            readonly data: QueryTypes.Cells<typeof query>
          }>>()

          expect(resources.time.get()).type.toBe<number>()
          expect(resources.phase.get()).type.toBe<"Running" | "Paused">()
          expect(resources.viewport.setRaw({ width: 320, height: 180 })).type.toBe<Result.Result<void, Size2.Error>>()
          expect(resources.viewport.updateRaw((viewport) => ({
            width: viewport.width,
            height: viewport.height
          }))).type.toBe<Result.Result<void, Size2.Error>>()
          expect(services.logger).type.toBe<{ log: (message: string) => void }>()
          expect(events.tick.emit).type.toBe<(value: { dt: number }) => void>()
          expect(resources.phase.setResult(Result.success("Running"))).type.toBe<Result.Result<void, unknown>>()
          expect(resources.phase.updateResult(() => Result.success("Paused" as const))).type.toBe<Result.Result<void, unknown>>()
          expect(resources.camera.setRaw({ x: 0, y: 0 })).type.toBe<Result.Result<void, Vector2.Error>>()
          expect(resources.camera.updateRaw((camera) => ({
            x: camera.x + 1,
            y: camera.y + 1
          }))).type.toBe<Result.Result<void, Vector2.Error>>()

          // @ts-expect-error Property 'missing' does not exist on type 'ResourceContext<SystemSpec<SchemaDefinition<{ readonly Position
          resources.missing
          // @ts-expect-error Property 'setRaw' does not exist on type 'ResourceReadView<number>'.
          resources.time.setRaw(1)
        }
    )

    expect(system).type.toBeAssignableTo<System.SystemDefinition<any, void, never>>()
  })

  it("accepts reusable plain object access fragments without a wrapper", () => {
    const query = Query.Query({
      selection: {
        position: Query.write(SafePosition),
        velocity: Query.read(Velocity)
      }
    })

    const movementAccess = {
      queries: {
        moving: query
      },
      resources: {
        time: System.readResource(Time),
        viewport: System.writeResource(Viewport)
      },
      services: {
        logger: System.service(Logger)
      }
    } satisfies System.SystemAccessSpec

    System.System(
      "MoveA",
      {
        schema,
        ...movementAccess
      },
      ({ queries, resources, services }) =>
        {
          expect(queries.moving.each()).type.toBe<ReadonlyArray<{
            readonly entity: EntityMut<typeof schema, {
              readonly position: Query.ReadonlyValue<Vector2.Vector2>
              readonly velocity: Query.ReadonlyValue<{ x: number; y: number }>
            }, {
              readonly position: Query.ReadonlyValue<Vector2.Vector2>
            }>
            readonly data: QueryTypes.Cells<typeof query>
          }>>()

          expect(resources.time.get()).type.toBe<number>()
          expect(resources.viewport.setRaw({ width: 320, height: 180 })).type.toBe<Result.Result<void, Size2.Error>>()
          expect(services.logger).type.toBe<{ log: (message: string) => void }>()

          // @ts-expect-error Property 'missing' does not exist on type 'ResourceContext<SystemSpec<SchemaDefinition<{ readonly Position
          resources.missing
        }
    )

    System.System(
      "MoveB",
      {
        schema,
        ...movementAccess
      },
      ({ resources, services }) =>
        {
          expect(resources.time.get()).type.toBe<number>()
          expect(services.logger.log).type.toBe<(message: string) => void>()

          // @ts-expect-error Property 'missing' does not exist on type 'ServiceContext<SystemSpec<SchemaDefinition<{ readonly Position
          services.missing
        }
    )
  })

  it("rejects unknown access categories at the constructor boundary", () => {
    Game.System("InvalidAccess", {
      // @ts-expect-error Object literal may only specify known properties, but 'resoruces' does not exist in type
      resoruces: {
        time: Game.System.readResource(Time)
      }
    }, () => {})
  })
})
