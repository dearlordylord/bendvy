import { describe, expect, it } from "vitest"
import { Descriptor, Entity, Schema } from "@typeonce/bevy-ts"
import * as Command from "@typeonce/bevy-ts/Command"
import type { EntityId } from "@typeonce/bevy-ts/Entity"
import * as Query from "@typeonce/bevy-ts/Query"
import * as Runtime from "@typeonce/bevy-ts/Runtime"
import * as Schedule from "@typeonce/bevy-ts/Schedule"
import * as System from "@typeonce/bevy-ts/System"
import { readResourceValue } from "./utils/fixtures.ts"

const Position = Descriptor.Component<{ x: number; y: number }>()("Position")
const Velocity = Descriptor.Component<{ x: number; y: number }>()("Velocity")
const Hidden = Descriptor.Component<{ hidden: true }>()("Hidden")
const Count = Descriptor.Resource<number>()("Count")
const LastX = Descriptor.Resource<number>()("LastX")
const LastError = Descriptor.Resource<string>()("LastError")
const HandleRoot = Schema.defineRoot("RuntimeQueryHandle")
const StoredHandle = Descriptor.Resource<Entity.Handle<typeof HandleRoot, typeof Position> | null>()("StoredHandle")
const FollowTarget = Descriptor.Event<{ target: Entity.Handle<typeof HandleRoot, typeof Position> }>()("FollowTarget")
const Followed = Descriptor.Component<{
  target: Entity.Handle<typeof HandleRoot, typeof Position> | null
}>()("Followed")

const HandleGame = Schema.bind(Schema.fragment({
  components: {
    Position,
    Velocity,
    Hidden,
    Followed
  },
  resources: {
    Count,
    LastX,
    LastError,
    StoredHandle
  },
  events: {
    FollowTarget
  }
}), HandleRoot)
const schema = HandleGame.schema

const makeRuntime = () =>
  Runtime.make({
    schema,
    services: Runtime.services(),
    resources: {
      Count: 0,
      LastX: -1,
      LastError: "",
      StoredHandle: null
    }
  })

describe("Runtime query and lookup", () => {
  it("each returns zero matches when nothing satisfies the query", () => {
    const observe = System.System(
      "RuntimeQuery/ObserveEmpty",
      {
        schema,
        queries: {
          positions: Query.Query({
            selection: {
              position: Query.read(Position)
            }
          })
        },
        resources: {
          count: System.writeResource(Count)
        }
      },
      ({ queries, resources }) =>
        {
          resources.count.set(queries.positions.each().length)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(Schedule.Schedule(observe))

    expect(readResourceValue(runtime, schema, Count)).toBe(0)
  })

  it("single returns NoEntities when no entity matches", () => {
    const observe = System.System(
      "RuntimeQuery/SingleNoEntities",
      {
        schema,
        queries: {
          positions: Query.Query({
            selection: {
              position: Query.read(Position)
            }
          })
        },
        resources: {
          lastError: System.writeResource(LastError)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.positions.single()
          resources.lastError.set(result.ok ? "" : result.error._tag)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(Schedule.Schedule(observe))

    expect(readResourceValue(runtime, schema, LastError)).toBe("NoEntities")
  })

  it("single returns MultipleEntities when multiple entities match", () => {
    const spawn = System.System(
      "RuntimeQuery/SpawnMultiple",
      {
        schema
      },
      ({ commands }) =>
        {
          commands.spawn(HandleGame.Command.spawn([Position, { x: 1, y: 1 }] as const))
          commands.spawn(HandleGame.Command.spawn([Position, { x: 2, y: 2 }] as const))
        }
    )

    const observe = System.System(
      "RuntimeQuery/ObserveMultiple",
      {
        schema,
        queries: {
          positions: Query.Query({
            selection: {
              position: Query.read(Position)
            }
          })
        },
        resources: {
          lastError: System.writeResource(LastError)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.positions.single()
          resources.lastError.set(result.ok ? "" : result.error._tag)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Schedule.Schedule(spawn, Schedule.applyDeferred()),
      Schedule.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, LastError)).toBe("MultipleEntities")
  })

  it("singleOptional returns undefined when no entity matches", () => {
    const observe = System.System(
      "RuntimeQuery/SingleOptionalNoEntities",
      {
        schema,
        queries: {
          positions: Query.Query({
            selection: {
              position: Query.read(Position)
            }
          })
        },
        resources: {
          lastX: System.writeResource(LastX),
          lastError: System.writeResource(LastError)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.positions.singleOptional()
          resources.lastError.set(result.ok ? "" : result.error._tag)
          resources.lastX.set(result.ok && result.value ? result.value.data.position.get().x : -1)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(Schedule.Schedule(observe))

    expect(readResourceValue(runtime, schema, LastError)).toBe("")
    expect(readResourceValue(runtime, schema, LastX)).toBe(-1)
  })

  it("singleOptional returns the match when exactly one entity matches", () => {
    const spawn = System.System(
      "RuntimeQuery/SpawnOneForSingleOptional",
      {
        schema
      },
      ({ commands }) =>
        {
          commands.spawn(HandleGame.Command.spawn([Position, { x: 7, y: 3 }] as const))
        }
    )

    const observe = System.System(
      "RuntimeQuery/SingleOptionalOneEntity",
      {
        schema,
        queries: {
          positions: Query.Query({
            selection: {
              position: Query.write(Position)
            }
          })
        },
        resources: {
          lastX: System.writeResource(LastX),
          lastError: System.writeResource(LastError)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.positions.singleOptional()
          resources.lastError.set(result.ok ? "" : result.error._tag)
          if (!result.ok || !result.value) {
            resources.lastX.set(-1)
            return
          }

          result.value.data.position.update((position) => ({
            ...position,
            x: position.x + 1
          }))
          resources.lastX.set(result.value.data.position.get().x)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Schedule.Schedule(spawn, Schedule.applyDeferred()),
      Schedule.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, LastError)).toBe("")
    expect(readResourceValue(runtime, schema, LastX)).toBe(8)
  })

  it("singleOptional returns MultipleEntities when multiple entities match", () => {
    const spawn = System.System(
      "RuntimeQuery/SpawnMultipleForSingleOptional",
      {
        schema
      },
      ({ commands }) =>
        {
          commands.spawn(HandleGame.Command.spawn([Position, { x: 1, y: 1 }] as const))
          commands.spawn(HandleGame.Command.spawn([Position, { x: 2, y: 2 }] as const))
        }
    )

    const observe = System.System(
      "RuntimeQuery/SingleOptionalMultipleEntities",
      {
        schema,
        queries: {
          positions: Query.Query({
            selection: {
              position: Query.read(Position)
            }
          })
        },
        resources: {
          lastError: System.writeResource(LastError)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.positions.singleOptional()
          resources.lastError.set(result.ok ? "" : result.error._tag)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Schedule.Schedule(spawn, Schedule.applyDeferred()),
      Schedule.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, LastError)).toBe("MultipleEntities")
  })

  it("lookup returns MissingEntity and QueryMismatch for the expected cases", () => {
    let existingId: EntityId<typeof schema> | undefined

    const spawn = System.System(
      "RuntimeQuery/SpawnOneForLookup",
      {
        schema
      },
      ({ commands }) =>
        {
          existingId = commands.spawn(HandleGame.Command.spawn(
            [Position, { x: 1, y: 1 }] as const
          ))
        }
    )

    const observe = System.System(
      "RuntimeQuery/ObserveLookupFailures",
      {
        schema,
        resources: {
          lastError: System.writeResource(LastError)
        }
      },
      ({ lookup, resources }) =>
        {
          if (!existingId) {
            resources.lastError.set("MissingSetup")
            return
          }
          const missing = lookup.get(Entity.makeEntityId<typeof schema>(9999), Query.Query({
            selection: {
              position: Query.read(Position)
            }
          }))
          const mismatch = lookup.get(existingId, Query.Query({
            selection: {
              velocity: Query.read(Velocity)
            }
          }))
          resources.lastError.set(`${missing.ok ? "ok" : missing.error._tag}/${mismatch.ok ? "ok" : mismatch.error._tag}`)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Schedule.Schedule(spawn, Schedule.applyDeferred()),
      Schedule.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, LastError)).toBe("MissingEntity/QueryMismatch")
  })

  it("with and without filters refine matching entities", () => {
    const spawn = System.System(
      "RuntimeQuery/SpawnFiltered",
      {
        schema
      },
      ({ commands }) =>
        {
          commands.spawn(HandleGame.Command.spawn(
            [Position, { x: 1, y: 1 }] as const
          ))
          commands.spawn(HandleGame.Command.spawn(
            [Position, { x: 2, y: 2 }] as const,
            [Hidden, { hidden: true }] as const
          ))
        }
    )

    const observe = System.System(
      "RuntimeQuery/ObserveFilters",
      {
        schema,
        queries: {
          visible: Query.Query({
            selection: {
              position: Query.read(Position)
            },
            with: [Position] as const,
            without: [Hidden] as const
          })
        },
        resources: {
          count: System.writeResource(Count)
        }
      },
      ({ queries, resources }) =>
        {
          resources.count.set(queries.visible.each().length)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Schedule.Schedule(spawn, Schedule.applyDeferred()),
      Schedule.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, Count)).toBe(1)
  })

  it("optional component slots do not affect matching and stay explicit in results", () => {
    const spawn = System.System(
      "RuntimeQuery/SpawnOptional",
      {
        schema
      },
      ({ commands }) =>
        {
          commands.spawn(HandleGame.Command.spawn(
            [Position, { x: 1, y: 1 }] as const
          ))
          commands.spawn(HandleGame.Command.spawn(
            [Position, { x: 2, y: 2 }] as const,
            [Velocity, { x: 4, y: 0 }] as const
          ))
        }
    )

    const observe = System.System(
      "RuntimeQuery/ObserveOptional",
      {
        schema,
        queries: {
          moving: Query.Query({
            selection: {
              position: Query.read(Position),
              velocity: Query.optional(Velocity)
            }
          })
        },
        resources: {
          count: System.writeResource(Count),
          lastX: System.writeResource(LastX)
        }
      },
      ({ queries, resources }) =>
        {
          let totalX = 0
          for (const match of queries.moving.each()) {
            if (match.data.velocity.present) {
              totalX += match.data.velocity.get().x
            }
          }

          resources.count.set(queries.moving.each().length)
          resources.lastX.set(totalX)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Schedule.Schedule(spawn, Schedule.applyDeferred()),
      Schedule.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, Count)).toBe(2)
    expect(readResourceValue(runtime, schema, LastX)).toBe(4)
  })

  it("lookup does not fail when only optional components are missing", () => {
    let existingId: EntityId<typeof schema> | undefined

    const spawn = System.System(
      "RuntimeQuery/SpawnLookupOptional",
      {
        schema
      },
      ({ commands }) =>
        {
          existingId = commands.spawn(HandleGame.Command.spawn(
            [Position, { x: 3, y: 7 }] as const
          ))
        }
    )

    const observe = System.System(
      "RuntimeQuery/ObserveLookupOptional",
      {
        schema,
        resources: {
          lastX: System.writeResource(LastX),
          lastError: System.writeResource(LastError)
        }
      },
      ({ lookup, resources }) =>
        {
          if (!existingId) {
            resources.lastError.set("MissingSetup")
            return
          }

          const result = lookup.get(existingId, Query.Query({
            selection: {
              position: Query.read(Position),
              velocity: Query.optional(Velocity)
            }
          }))

          if (!result.ok) {
            resources.lastError.set(result.error._tag)
            return
          }

          resources.lastError.set(result.value.data.velocity.present ? "Present" : "Missing")
          resources.lastX.set(result.value.data.position.get().x)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Schedule.Schedule(spawn, Schedule.applyDeferred()),
      Schedule.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, LastError)).toBe("Missing")
    expect(readResourceValue(runtime, schema, LastX)).toBe(3)
  })

  it("writable query cells update component values", () => {
    const spawn = System.System(
      "RuntimeQuery/SpawnWritable",
      {
        schema
      },
      ({ commands }) =>
        {
          commands.spawn(HandleGame.Command.spawn(
            [Position, { x: 1, y: 1 }] as const
          ))
        }
    )

    const write = System.System(
      "RuntimeQuery/WriteThroughCell",
      {
        schema,
        queries: {
          positions: Query.Query({
            selection: {
              position: Query.write(Position)
            }
          })
        }
      },
      ({ queries }) =>
        {
          const result = queries.positions.single()
          if (result.ok) {
            result.value.data.position.update((position) => ({
              ...position,
              x: 9
            }))
          }
        }
    )

    const read = System.System(
      "RuntimeQuery/ReadWrittenCell",
      {
        schema,
        queries: {
          positions: Query.Query({
            selection: {
              position: Query.read(Position)
            }
          })
        },
        resources: {
          lastX: System.writeResource(LastX)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.positions.single()
          resources.lastX.set(result.ok ? result.value.data.position.get().x : -1)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Schedule.Schedule(spawn, Schedule.applyDeferred()),
      Schedule.Schedule(write, read)
    )

    expect(readResourceValue(runtime, schema, LastX)).toBe(9)
  })

  it("getHandle resolves durable handles explicitly and reports stale handles safely", () => {
    const Game = HandleGame
    let currentHandle: Entity.Handle<typeof HandleRoot, typeof Position> | null = null

    const spawn = Game.System(
      "RuntimeQuery/SpawnHandle",
      {},
      ({ commands }) =>
        {
          const target = commands.spawn(Game.Command.spawn([Position, { x: 5, y: 9 }] as const))
          currentHandle = Game.Entity.handle(target, Position)
        }
    )

    const observe = Game.System(
      "RuntimeQuery/ObserveHandle",
      {
        resources: {
          lastX: Game.System.writeResource(LastX),
          lastError: Game.System.writeResource(LastError)
        }
      },
      ({ lookup, resources }) =>
        {
          if (!currentHandle) {
            resources.lastError.set("MissingSetup")
            return
          }

          const result = lookup.getHandle(currentHandle, Game.Query({
            selection: {
              position: Game.Query.read(Position)
            }
          }))

          if (!result.ok) {
            resources.lastError.set(result.error._tag)
            return
          }

          resources.lastX.set(result.value.data.position.get().x)
          resources.lastError.set("")
        }
    )

    const destroy = Game.System(
      "RuntimeQuery/DestroyHandleTarget",
      {},
      ({ lookup, commands }) =>
        {
          if (!currentHandle) {
            return
          }
          const result = lookup.getHandle(currentHandle, Game.Query({
            selection: {
              position: Game.Query.read(Position)
            }
          }))
          if (result.ok) {
            commands.despawn(result.value.entity.id)
          }
        }
    )

    const runtime = Game.Runtime.make({
      services: Game.Runtime.services(),
      resources: {
        Count: 0,
        LastX: -1,
        LastError: "",
        StoredHandle: null
      }
    })

    runtime.tick(
      Game.Schedule(spawn, Game.Schedule.applyDeferred()),
      Game.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, LastX)).toBe(5)
    expect(readResourceValue(runtime, schema, LastError)).toBe("")

    runtime.tick(
      Game.Schedule(destroy, Game.Schedule.applyDeferred()),
      Game.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, LastError)).toBe("MissingEntity")
  })

  it("resolves handles stored in resources and events with the same explicit failure semantics", () => {
    const Game = HandleGame
    let spawnedTarget: Entity.EntityId<typeof schema, typeof HandleRoot> | undefined

    const spawn = Game.System(
      "RuntimeQuery/SpawnStoredHandle",
      {
        resources: {
          storedHandle: Game.System.writeResource(StoredHandle)
        },
        events: {
          followTarget: Game.System.writeEvent(FollowTarget)
        }
      },
      ({ resources, events, commands }) =>
        {
          spawnedTarget = commands.spawn(Game.Command.spawn([Position, { x: 12, y: 8 }] as const))
          const handle = Game.Entity.handle(spawnedTarget, Position)
          resources.storedHandle.set(handle)
          events.followTarget.emit({ target: handle })
        }
    )

    const observe = Game.System(
      "RuntimeQuery/ObserveStoredHandle",
      {
        resources: {
          storedHandle: Game.System.readResource(StoredHandle),
          lastX: Game.System.writeResource(LastX),
          lastError: Game.System.writeResource(LastError)
        },
        events: {
          followTarget: Game.System.readEvent(FollowTarget)
        }
      },
      ({ lookup, resources, events }) =>
        {
          const resourceHandle = resources.storedHandle.get()
          const eventHandle = events.followTarget.all().at(0)?.target

          if (!resourceHandle || !eventHandle) {
            resources.lastError.set("MissingSetup")
            return
          }

          const resourceResult = lookup.getHandle(resourceHandle, Game.Query({
            selection: {
              position: Game.Query.read(Position)
            }
          }))
          const eventResult = lookup.getHandle(eventHandle, Game.Query({
            selection: {
              position: Game.Query.read(Position)
            }
          }))

          if (!resourceResult.ok || !eventResult.ok) {
            resources.lastError.set(`${resourceResult.ok ? "ok" : resourceResult.error._tag}/${eventResult.ok ? "ok" : eventResult.error._tag}`)
            return
          }

          resources.lastX.set(resourceResult.value.data.position.get().x + eventResult.value.data.position.get().x)
          resources.lastError.set("")
        }
    )

    const destroy = Game.System(
      "RuntimeQuery/DestroyStoredHandleTarget",
      {},
      ({ commands }) =>
        {
          if (spawnedTarget) {
            commands.despawn(spawnedTarget)
          }
        }
    )

    const emitStored = Game.System(
      "RuntimeQuery/EmitStoredHandleAgain",
      {
        resources: {
          storedHandle: Game.System.readResource(StoredHandle)
        },
        events: {
          followTarget: Game.System.writeEvent(FollowTarget)
        }
      },
      ({ resources, events }) =>
        {
          const handle = resources.storedHandle.get()
          if (handle) {
            events.followTarget.emit({ target: handle })
          }
        }
    )

    const runtime = Game.Runtime.make({
      services: Game.Runtime.services(),
      resources: {
        Count: 0,
        LastX: -1,
        LastError: "",
        StoredHandle: null
      }
    })

    runtime.tick(
      Game.Schedule(spawn, Game.Schedule.applyDeferred(), observe)
    )

    expect(readResourceValue(runtime, schema, LastX)).toBe(24)
    expect(readResourceValue(runtime, schema, LastError)).toBe("")

    runtime.tick(
      Game.Schedule(destroy, Game.Schedule.applyDeferred()),
      Game.Schedule(emitStored, observe)
    )

    expect(readResourceValue(runtime, schema, LastError)).toBe("MissingEntity/MissingEntity")
  })
})
