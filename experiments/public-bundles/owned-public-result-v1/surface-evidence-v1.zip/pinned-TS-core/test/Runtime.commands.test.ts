import { describe, expect, it } from "vitest"
import { Descriptor, Result, Schema } from "@typeonce/bevy-ts"
import type { EntityId } from "@typeonce/bevy-ts/Entity"
import * as Vector2 from "@typeonce/bevy-ts-math/Vector2"
import { readResourceValue } from "./utils/fixtures.ts"

const Position = Descriptor.Component<{ x: number; y: number }>()("Position")
const Velocity = Descriptor.Component<{ x: number; y: number }>()("Velocity")
const Count = Descriptor.Resource<number>()("Count")
const LastX = Descriptor.Resource<number>()("LastX")
const SafePosition = Descriptor.ConstructedComponent(Vector2)("SafePosition")

const Game = Schema.bind(Schema.fragment({
  components: {
    Position,
    Velocity
  },
  resources: {
    Count,
    LastX
  }
}))
const schema = Game.schema

const ConstructedGame = Schema.bind(Schema.fragment({
  components: {
    SafePosition
  }
}))
const constructedSchema = ConstructedGame.schema

const makeRuntime = () =>
  Game.Runtime.make({
    services: Game.Runtime.services(),
    resources: {
      Count: 0,
      LastX: -1
    }
  })

describe("Runtime commands", () => {
  it("insertMany applies entries in order with last-write-wins semantics", () => {
    const spawn = Game.System(
      "RuntimeCommands/SpawnInsertMany",
      {},
      ({ commands }) =>
        {
          const id = commands.spawn(Game.Command.spawn(
            [Position, { x: 0, y: 0 }] as const
          ))
          commands.insert(
            id,
            [Position, { x: 1, y: 1 }] as const,
            [Position, { x: 2, y: 2 }] as const,
            [Velocity, { x: 9, y: 9 }] as const
          )
        }
    )

    const observe = Game.System(
      "RuntimeCommands/ObserveLastWriteWins",
      {
        queries: {
          moving: Game.Query({
            selection: {
              position: Game.Query.read(Position),
              velocity: Game.Query.read(Velocity)
            }
          })
        },
        resources: {
          count: Game.System.writeResource(Count),
          lastX: Game.System.writeResource(LastX)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.moving.single()
          resources.count.set(result.ok ? 1 : 0)
          resources.lastX.set(result.ok ? result.value.data.position.get().x : -1)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Game.Schedule(spawn, Game.Schedule.applyDeferred()),
      Game.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, Count)).toBe(1)
    expect(readResourceValue(runtime, schema, LastX)).toBe(2)
  })

  it("remove causes later queries to stop matching", () => {
    const spawn = Game.System(
      "RuntimeCommands/SpawnForRemove",
      {},
      ({ commands }) =>
        {
          const id = commands.spawn(Game.Command.spawn(
            [Position, { x: 1, y: 1 }] as const,
            [Velocity, { x: 1, y: 1 }] as const
          ))
          commands.remove(id, Velocity)
        }
    )

    const observe = Game.System(
      "RuntimeCommands/ObserveRemove",
      {
        queries: {
          moving: Game.Query({
            selection: {
              position: Game.Query.read(Position),
              velocity: Game.Query.read(Velocity)
            }
          })
        },
        resources: {
          count: Game.System.writeResource(Count)
        }
      },
      ({ queries, resources }) =>
        {
          resources.count.set(queries.moving.each().length)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Game.Schedule(spawn, Game.Schedule.applyDeferred()),
      Game.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, Count)).toBe(0)
  })

  it("despawn removes the entity and exact lookup reports MissingEntity", () => {
    let storedId: EntityId<typeof schema, typeof schema> | undefined

    const spawn = Game.System(
      "RuntimeCommands/SpawnAndStoreId",
      {},
      ({ commands }) =>
        {
          const id = commands.spawn(Game.Command.spawn(
            [Position, { x: 1, y: 2 }] as const
          ))
          storedId = id
          commands.despawn(id)
        }
    )

    const lookup = Game.System(
      "RuntimeCommands/LookupDespawned",
      {
        resources: {
          count: Game.System.writeResource(Count)
        }
      },
      ({ lookup, resources }) =>
        {
          const id = storedId
          if (!id) {
            resources.count.set(-1)
            return
          }
          const result = lookup.get(id, Game.Query({
            selection: {
              position: Game.Query.read(Position)
            }
          }))
          resources.count.set(result.ok ? 0 : result.error._tag === "MissingEntity" ? 1 : -1)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Game.Schedule(spawn, Game.Schedule.applyDeferred()),
      Game.Schedule(lookup)
    )

    expect(readResourceValue(runtime, schema, Count)).toBe(1)
  })

  it("entryRaw and insertRaw validate constructed component input explicitly", () => {
    const invalidEntry = ConstructedGame.Command.entryRaw(SafePosition, { x: Number.NaN, y: 0 })
    expect(invalidEntry.ok).toBe(false)

    const spawned = ConstructedGame.Command.spawn(
      ConstructedGame.Command.entryRaw(SafePosition, { x: 1, y: 2 })
    )

    expect(spawned.ok).toBe(true)
    if (!spawned.ok) {
      return
    }

    const inserted = ConstructedGame.Command.insert(
      spawned.value, ConstructedGame.Command.entryRaw(SafePosition, { x: 3, y: 4 }))

    expect(inserted.ok).toBe(true)
  })

  it("insert on an existing entity becomes visible after explicit applyDeferred in the same schedule", () => {
    let storedId: EntityId<typeof schema, typeof schema> | undefined

    const spawn = Game.System(
      "RuntimeCommands/SpawnStoreForInsert",
      {},
      ({ commands }) =>
        {
          const id = commands.spawn(Game.Command.spawn(
            [Position, { x: 0, y: 0 }] as const
          ))
          storedId = id
        }
    )

    const insertVelocity = Game.System(
      "RuntimeCommands/InsertVelocity",
      {},
      ({ commands }) =>
        {
          const id = storedId
          if (id) {
            commands.insert(id, [Velocity, { x: 4, y: 5 }])
          }
        }
    )

    const observe = Game.System(
      "RuntimeCommands/ObserveInsertedVelocity",
      {
        queries: {
          moving: Game.Query({
            selection: {
              position: Game.Query.read(Position),
              velocity: Game.Query.read(Velocity)
            }
          })
        },
        resources: {
          count: Game.System.writeResource(Count)
        }
      },
      ({ queries, resources }) =>
        {
          resources.count.set(queries.moving.each().length)
        }
    )

    const runtime = makeRuntime()
    const spawnSchedule = Game.Schedule(spawn, Game.Schedule.applyDeferred())
    const observeSchedule = Game.Schedule(insertVelocity, Game.Schedule.applyDeferred(), observe)

    runtime.tick(spawnSchedule, observeSchedule)

    expect(readResourceValue(runtime, schema, Count)).toBe(1)
  })

  it("spawnWithResult returns tuple-shaped failures and applies successful drafts", () => {
    const spawn = Game.System(
      "RuntimeCommands/SpawnWithResult",
      {
        resources: {
          count: Game.System.writeResource(Count),
          lastX: Game.System.writeResource(LastX)
        }
      },
      ({ commands, resources }) =>
        {
          const invalidDraft = Game.Command.spawn(
            Game.Command.entryResult(Position, Result.success({ x: 1, y: 2 })),
            Game.Command.entryResult(Velocity, Result.failure("bad-velocity"))
          )

          expect(invalidDraft).toEqual(Result.failure([null, "bad-velocity"]))

          const validDraft = Game.Command.spawn(
            Game.Command.entryResult(Position, Result.success({ x: 4, y: 5 })),
            Game.Command.entryResult(Velocity, Result.success({ x: 6, y: 7 }))
          )

          if (!validDraft.ok) {
            resources.count.set(-1)
            return
          }

          commands.spawn(validDraft.value)
          resources.count.set(1)
          resources.lastX.set(4)
        }
    )

    const observe = Game.System(
      "RuntimeCommands/ObserveSpawnWithResult",
      {
        queries: {
          moving: Game.Query({
            selection: {
              position: Game.Query.read(Position),
              velocity: Game.Query.read(Velocity)
            }
          })
        },
        resources: {
          count: Game.System.writeResource(Count),
          lastX: Game.System.writeResource(LastX)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.moving.single()
          resources.count.set(result.ok ? 1 : 0)
          resources.lastX.set(result.ok ? result.value.data.position.get().x : -1)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Game.Schedule(spawn, Game.Schedule.applyDeferred()),
      Game.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, Count)).toBe(1)
    expect(readResourceValue(runtime, schema, LastX)).toBe(4)
  })

  it("spawnWithMixed accepts plain and validated entries together", () => {
    const spawn = Game.System(
      "RuntimeCommands/SpawnWithMixed",
      {
        resources: {
          count: Game.System.writeResource(Count),
          lastX: Game.System.writeResource(LastX)
        }
      },
      ({ commands, resources }) =>
        {
          const invalidDraft = Game.Command.spawn(
            Game.Command.entry(Position, { x: 1, y: 2 }),
            Game.Command.entryResult(Velocity, Result.failure("bad-velocity"))
          )

          expect(invalidDraft).toEqual(Result.failure([null, "bad-velocity"]))

          const validDraft = Game.Command.spawn(
            Game.Command.entry(Position, { x: 4, y: 5 }),
            Game.Command.entryResult(Velocity, Result.success({ x: 6, y: 7 }))
          )

          if (!validDraft.ok) {
            resources.count.set(-1)
            return
          }

          commands.spawn(validDraft.value)
          resources.count.set(1)
          resources.lastX.set(4)
        }
    )

    const observe = Game.System(
      "RuntimeCommands/ObserveSpawnWithMixed",
      {
        queries: {
          moving: Game.Query({
            selection: {
              position: Game.Query.read(Position),
              velocity: Game.Query.read(Velocity)
            }
          })
        },
        resources: {
          count: Game.System.writeResource(Count),
          lastX: Game.System.writeResource(LastX)
        }
      },
      ({ queries, resources }) =>
        {
          const result = queries.moving.single()
          resources.count.set(result.ok ? 1 : 0)
          resources.lastX.set(result.ok ? result.value.data.position.get().x : -1)
        }
    )

    const runtime = makeRuntime()
    runtime.tick(
      Game.Schedule(spawn, Game.Schedule.applyDeferred()),
      Game.Schedule(observe)
    )

    expect(readResourceValue(runtime, schema, Count)).toBe(1)
    expect(readResourceValue(runtime, schema, LastX)).toBe(4)
  })
})
