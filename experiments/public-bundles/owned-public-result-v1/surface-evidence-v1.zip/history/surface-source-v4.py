"""Exact-source cheap consumer gate. No child execution until explicit admission."""
from pathlib import Path
import hashlib,json,os,re,shutil,sys
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import check_preflight as P
PLAN=HERE/'surface-source-plan-004.json';ENV=HERE/'surface-source-environment-004.json';OUT=HERE/'surface-source-004'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepare():
 assert not PLAN.exists() and not ENV.exists()
 files=set()
 def close(p):
  p=p.resolve()
  if p in files:return
  files.add(p)
  if p.suffix=='.bend':
   for name in re.findall(r'^\s*import\s+(\S+)',p.read_text(),re.M):
    if name!='Base':close(p.parent/name.strip('"'))
 close(HERE/'surface-main.bend')
 files.update(HERE/n for n in ['surface-oracle.py','surface-ts-oracle.py','surface-expected.stdout','surface-expected-reference.stdout','surface-reference.mjs','expected.stderr','surface-expected-check.stderr','surface-source-v4.py'])
 files.update(ROOT/n for n in ['scripts/task_runner.py','scripts/check_preflight.py','scripts/bend-check','src/ecs/world-namespace.js','src/ecs/world-namespace.c','.references/sources.json','docs/SPEC.md'])
 bend=Path(shutil.which('bend')).resolve();files.add(bend);files.add(Path('/home/node/.bend/check.json'))
 checks=[dict(label='canonical-surface-IO-effect-boundary',argv=[str(bend),str(HERE/'surface-main.bend'),'--check-only'],seconds=5,exit=1,stderr=str(HERE/'surface-expected-check.stderr'))]
 files.add(Path(shutil.which('node')).resolve())
 env=dict(os.environ,BEND_NO_TELEMETRY='1');ENV.write_text(json.dumps(env,sort_keys=True,indent=2)+'\n');ENV.chmod(0o600)
 files=sorted(map(str,files));directories=['/home/node/.bend/bend2'];binding=P.binding(ROOT,files,directories,checks,env)
 plan=dict(status='UNEXECUTED',supersedes='Surface002 retained actual SF.Error duplicate-use source failure; routine explicit +error Data repair in both schemas; source checker only, TS/interpreter unexecuted',files=files,directories=directories,checks=checks,binding=binding,environmentSHA256=sha(ENV),rows=20,scope='Two nominal schemas full spawn/insert/duplicate/replacement/invalid Raw retry/registered rollback/ordered cleanup surface. Complete independent20 physical Bend rows and actual10 TS applications/20 public checkpoints. No failed activation reservation or capture policy choices; no performance or production adoption claim.')
 PLAN.write_text(json.dumps(plan,indent=2)+'\n');print(sha(PLAN))
def execute():
 plan=json.loads(PLAN.read_text());assert sha(ENV)==plan['environmentSHA256'];env=json.loads(ENV.read_text())
 assert dict(os.environ,BEND_NO_TELEMETRY='1')==env,'ambient environment mismatch; fresh freeze required'
 assert P.binding(ROOT,plan['files'],plan['directories'],plan['checks'],env)==plan['binding'],'input drift; fresh freeze required'
 print(P.run(OUT,root=ROOT,files=[*plan['files'],str(PLAN),str(ENV)],directories=plan['directories'],checks=plan['checks'],env=env))
if sys.argv[1:]==['--prepare-only']:prepare()
elif sys.argv[1:]==['--execute']:execute()
elif sys.argv[1:]==['--prepare-and-execute']:prepare();execute()
else:raise SystemExit('use --prepare-only or --execute')
