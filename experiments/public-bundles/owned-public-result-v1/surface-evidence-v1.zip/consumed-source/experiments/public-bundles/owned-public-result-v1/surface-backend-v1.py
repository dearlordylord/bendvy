"""Affected full owned bundle surface standalone JS and Native gate."""
from pathlib import Path
import functools,hashlib,json,os,runpy,shutil,sys,tempfile
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import task_runner as R;import check_preflight as P
T=runpy.run_path(str(ROOT/'scripts/owned-tool-pins.py'))
PLAN=HERE/'surface-backend-plan-001.json';ENV=HERE/'surface-backend-environment-001.json';OUT=HERE/'surface-backend-001'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def encoded(value):
 if isinstance(value,bytes):return {'rawHex':value.hex()}
 raise TypeError(type(value).__name__)
def decoded(value):
 if set(value)=={'rawHex'}:return bytes.fromhex(value['rawHex'])
 return value
def ancestors(roots):
 return {parent for root in roots for parent in [root,*root.parents]}
def configs(roots):
 return {str(root/name):(sha(root/name) if (root/name).is_file() else None) for root in ancestors(roots) for name in ['bend.json','bend.config.json','check.json','bunfig.toml','package.json','.clang','clang.cfg']}
def loaders():
 paths=[Path('/etc/ld.so.cache'),Path('/etc/ld.so.conf'),Path('/etc/ld.so.preload')]
 return {'files':{str(p):(sha(p) if p.is_file() else None) for p in paths},'confDirectory':inventory(Path('/etc/ld.so.conf.d'))}
PROBES=[]
def owned_probe(argv,seconds,**kwargs):
 result=R.execute_result(argv,seconds,capture='split',**kwargs)
 PROBES.append(dict(argv=argv,seconds=seconds,result=result))
 return result


def inventory(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def config(env):return dict(execute=owned_probe,tools={'bend':Path(shutil.which('bend')).resolve(),'node':Path(shutil.which('node')).resolve(),'python':Path(sys.executable).resolve(),'clang-wrapper':Path('/tmp/bendvy-clang19-diagnostic/clang19'),'clang-native':Path('/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/bin/clang')},resource_roots=[Path('/home/node/.bend/bend2'),Path('/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/lib/clang/19')],skip_ldd=('clang-wrapper',),ldd=Path(shutil.which('ldd')).resolve(),taskset=Path(shutil.which('taskset')).resolve(),cpu=min(os.sched_getaffinity(0)),env=env,capture_mode='split')
def preflight():
 plan=json.loads((HERE/'surface-plan-006.json').read_text());env=json.loads((HERE/'surface-environment-006.json').read_text())
 return P.verify(HERE/'surface-development-006/receipt.json',root=ROOT,files=[*plan['files'],str(HERE/'surface-plan-006.json'),str(HERE/'surface-environment-006.json')],directories=plan['directories'],checks=plan['checks'],env=env)
def prepare():
 assert not PLAN.exists() and not ENV.exists();preflight()
 base=json.loads((HERE/'surface-plan-006.json').read_text());files={p:sha(p) for p in base['files']}
 for p in [Path(__file__),ROOT/'scripts/owned-tool-pins.py',HERE/'surface-plan-006.json',HERE/'surface-development-006/receipt.json',HERE/'surface-public-join.py',HERE/'surface-development-006/actual-TS-public-surface.stdout',HERE/'surface-development-006/complete-owned-surface.stdout']:files[str(p)]=sha(p)
 env=dict(os.environ,BEND_NO_TELEMETRY='1',BENDVY_CLANG19_ROOT='/tmp/bendvy-clang19-diagnostic/root',LD_LIBRARY_PATH='/tmp/bendvy-clang19-diagnostic/root/usr/lib/aarch64-linux-gnu:/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/lib:/home/node/.local/opt/dnd-clang14/usr/lib/aarch64-linux-gnu');ENV.write_text(json.dumps(env,sort_keys=True,indent=2)+'\n');ENV.chmod(0o600)
 snapshot=T['snapshot'](**config(env));directories={n:inventory(Path(n)) for n in base['directories']}
 main='experiments/public-bundles/owned-public-result-v1/surface-main.bend'
 commands=[dict(label='surface-JS-emit',argv=['bend','STAGE/'+main,'-o','OUT/surface.js'],seconds=30,kind='emit',generated='surface.js'),dict(label='surface-JS-full20',argv=['node','OUT/surface.js'],seconds=5,kind='full'),dict(label='surface-Native-emit',argv=['bend','STAGE/'+main,'-o','OUT/surface.c'],seconds=30,kind='emit',generated='surface.c'),dict(label='surface-Native-clang',argv=['/tmp/bendvy-clang19-diagnostic/clang19','-O3','OUT/surface.c','-pthread','-lm','-o','OUT/surface.native'],seconds=120,kind='emit',generated='surface.native'),dict(label='surface-Native-full20',argv=['OUT/surface.native','--threads','1','--gpu','off'],seconds=5,kind='full')]
 plan=dict(status='UNEXECUTED',files=files,directories=directories,environmentSHA256=sha(ENV),toolSnapshot=snapshot,commands=commands,fullOracleSHA256=sha(HERE/'surface-expected.stdout'),rootConfigurations=configs({ROOT,HERE,OUT,Path.cwd(),Path('/home/node/.bend'),Path('/tmp/bendvy-clang19-diagnostic'),Path('/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/bin'),(ROOT/'.references/bevy-ts/packages/core').resolve()}),loaderConfigurations=loaders(),preparationProbeResults=list(PROBES),scope='Affected full bundle surface only: standalone emittedJS20 and Native20 complete physical oracles. Actual retained TS/CLI and emitted outputs public-row projection compared separately; clocks/ownership/constructor metadata not TS-equal. Existing22 positives/negatives/mutation reused, no reruns or policy/proof/performance claim.')
 PLAN.write_text(json.dumps(plan,indent=2,default=encoded)+'\n');print(sha(PLAN))
def execute():
 plan=json.loads(PLAN.read_text(),object_hook=decoded);assert sha(ENV)==plan['environmentSHA256'];env=json.loads(ENV.read_text());assert env==dict(os.environ,BEND_NO_TELEMETRY='1',BENDVY_CLANG19_ROOT='/tmp/bendvy-clang19-diagnostic/root',LD_LIBRARY_PATH='/tmp/bendvy-clang19-diagnostic/root/usr/lib/aarch64-linux-gnu:/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/lib:/home/node/.local/opt/dnd-clang14/usr/lib/aarch64-linux-gnu'),'ambient drift';preflight();assert not OUT.exists();OUT.mkdir()
 receipt=dict(status='INCOMPLETE',planSHA256=sha(PLAN),commands=[],generated={},toolGuardSnapshots=[],rawLogs={},probeCommands=PROBES)
 def save():(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,default=encoded)+'\n')
 save()
 try:
  with tempfile.TemporaryDirectory(prefix='owned-public-js-') as temp:
   stage=Path(temp);staged={};stageConfigs=configs({stage,stage/HERE.relative_to(ROOT)})
   for name,h in plan['files'].items():
    p=Path(name)
    if p.is_relative_to(ROOT):
     target=stage/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);staged[str(target.relative_to(stage))]=h
   receipt['stagedInputs']=staged
   def guard():
    assert sha(PLAN)==receipt['planSHA256'],'frozen plan drift'
    assert sha(ENV)==plan['environmentSHA256'],'frozen environment drift'
    assert all(sha(n)==h for n,h in plan['files'].items()),'source drift'
    assert all(inventory(Path(n))==h for n,h in plan['directories'].items()),'external drift'
    assert inventory(stage)==staged,'stage drift'
    receipt['toolGuardSnapshots'].append(T['verify'](plan['toolSnapshot'],**config(env)))
    assert configs({ROOT,HERE,OUT,Path.cwd(),Path('/home/node/.bend'),Path('/tmp/bendvy-clang19-diagnostic'),Path('/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/bin'),(ROOT/'.references/bevy-ts/packages/core').resolve()})==plan['rootConfigurations'],'root configurations drift'
    assert configs({stage,stage/HERE.relative_to(ROOT)})==stageConfigs,'stage configurations drift'
    assert loaders()==plan['loaderConfigurations'],'loader configurations drift'
    assert all(sha(OUT/n)==h for n,h in receipt['rawLogs'].items()),'immutable raw log drift'
    save()
    assert all(sha(OUT/n)==h for n,h in receipt['generated'].items()),'generated drift'
   for command in plan['commands']:
    guard();argv=[str(stage)+a[5:] if a.startswith('STAGE/') else str(OUT)+a[3:] if a.startswith('OUT/') else a for a in command['argv']]
    result=R.execute_result(argv,command['seconds'],cwd=stage,env=env,capture='split');label=command['label']
    for stream in ['stdout','stderr']:
     target=OUT/(label+'.'+stream);assert not target.exists();target.write_bytes(result[stream]);receipt['rawLogs'][target.name]=sha(target)
    receipt['commands'].append(dict(label=label,argv=argv,exit=result['exit'],failure=result['failure'],result=result,stdoutSHA256=sha(OUT/(label+'.stdout')),stderrSHA256=sha(OUT/(label+'.stderr'))));save()
    assert result['failure'] is None and result['exit']==0,(label,result)
    assert not result['stderr'],label
    if command['kind']=='emit':
     assert not result['stdout'];receipt['generated'][command['generated']]=sha(OUT/command['generated'])
    else:
     assert result['stdout']==(HERE/'surface-expected.stdout').read_bytes(),'full independently authored20 physical oracle mismatch'
     receipt.setdefault('fullPhysicalRows',{})[label]=20
    guard()
   compare=runpy.run_path(str(HERE/'surface-public-join.py'))['compare'];ts=(HERE/'surface-development-006/actual-TS-public-surface.stdout').read_text()
   joined={label:compare(source.read_text(),ts) for label,source in [('CLI-in-processJSIO',HERE/'surface-development-006/complete-owned-surface.stdout'),('standalone-JS',OUT/'surface-JS-full20.stdout'),('Native',OUT/'surface-Native-full20.stdout')]}
   report=OUT/'declared-public-join.json';report.write_text(json.dumps(joined,indent=2)+'\n');receipt['rawLogs'][report.name]=sha(report);guard()
   receipt['status']='FULL_BUNDLE_SURFACE_BACKENDS_FINITE_PASS'

 finally:save();print(OUT/'receipt.json')
if sys.argv[1:]==['--prepare-only']:prepare()
elif sys.argv[1:]==['--execute']:execute()
else:raise SystemExit('use --prepare-only or --execute')
