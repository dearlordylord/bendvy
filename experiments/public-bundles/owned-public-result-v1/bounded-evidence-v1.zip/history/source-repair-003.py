from pathlib import Path
import hashlib,json,os,sys
ROOT=Path(__file__).resolve().parents[3]; HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import task_runner as R
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads((HERE/'plan-005.json').read_text()); files={n:sha(n) for n in base['files']}
for n in ['commands.bend','composition.bend','source-repair-003.py']:files[str(HERE/n)]=sha(HERE/n)
out=HERE/'source-repair-003';out.mkdir();receipt={'status':'INCOMPLETE','files':files,'commands':[]}
try:
 for name in ['composition.bend','commands.bend']:
  assert all(sha(n)==h for n,h in files.items())
  r=R.execute_result(['bend',str(HERE/name),'--check-only'],5,cwd=ROOT,env=dict(os.environ,BEND_NO_TELEMETRY='1'),capture='split')
  for s in ['stdout','stderr']:(out/(name+'.'+s)).write_bytes(r[s])
  receipt['commands'].append({'name':name,'result':{k:({'rawHex':v.hex()} if isinstance(v,bytes) else v) for k,v in r.items()}})
  assert r['failure'] is None and r['exit']==0 and r['stderr']==b'' and r['stdout']==(HERE/'expected-safe-check.stdout').read_bytes(),(name,r)
  assert all(sha(n)==h for n,h in files.items())
 receipt['status']='SAFE_SOURCE_DIAGNOSTIC_PASS'
finally:
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(receipt['status'])
