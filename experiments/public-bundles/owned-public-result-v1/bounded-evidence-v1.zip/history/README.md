# Owned public bundle result candidate

Additive experiment for the #41 public API gap. No production adoption or proof.

`public.bend` closes `Input:Type`, `Output:Type`, `Args:Type` and
`BodyOutput:Type` before introducing the gameplay callback's abstract `H`.
`Request<H,Input,Output>` is an erased closed template; each call consumes and
returns its single `H` owner. Its result may own arbitrary affine payloads.
The caller explicitly threads these owners into later calls. Runtime closure
capture remains outside this closed-template route.

`adapter.bend` connects this generic route to the existing recursive constructor
stage and typed transaction Batch. Construction and immediate entity refusal
return the actual Raw packet directly; success transfers the Cooked packet and
its typed inverse to the Batch. A schema author supplies the Raw/Cooked/Packet
adapter and reversible constructor; this adds no universal decoding guarantee,
entity identity rule or failed-reservation policy.

`schema-a.bend` and `schema-b.bend` bind actual registered ECS worlds with four
heterogeneous recursive entries (Arrays, U32, tag, nested Array queue owners).
The gameplay body pattern-matches actual refusal, projects the returned owner
without copying, and feeds that same owner into an immediate repaired/local
retry. The pre-existing trusted mailbox is only observed as world state; it is
not the gameplay result channel.

`main.bend` defines 22 observations over two nominal schemas: MissingEntity,
constructor failure, undeclared declaration, real foreign-world handle refusal,
retry, deferred visibility, barrier and actual installed inverse. Each foreign
case creates two real canonical WorldIO worlds whose entity IDs both equal 1.
The physical oracle covers columns, payload values, stamps, world metadata,
events, constructor histories, installed queue payloads, prepared payloads,
actual registration/cursor and the full peer world. Observation rows are
independent fresh worlds; no continuity is claimed across separate rows.

Safe generic modules check without foreign effects. Application fixtures retain
canonical WorldIO imports and the exact named unsafe/foreign effect diagnostics;
they are not proof successes. `plan-001.json` is intentionally unexecuted because
its tool/library binding was incomplete. `plan-002.json` freezes that binding
through the existing cheap consumer preflight guard and is unexecuted pending
admission. Complete oracle bytes were authored before backend execution.

Seven focused source negatives cover duplicate context/input/returned owners,
read/write authority, concrete owner reconstruction, nominal schema mismatch and
escape of abstract H through the closed output type. Development diagnostics
alone grant no delivery acceptance. Native, production adoption and regression
qualification remain unexecuted.
