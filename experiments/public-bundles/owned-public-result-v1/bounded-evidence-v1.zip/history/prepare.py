"""Freeze the smallest complete source-current owned public result gate."""
from pathlib import Path
import hashlib,json,os,re,shutil,sys
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=set()
def close(p):
 p=p.resolve()
 if p in files:return
 files.add(p)
 if p.suffix=='.bend':
  for name in re.findall(r'^\s*import\s+(\S+)',p.read_text(),re.M):
   if name!='Base':close(p.parent/name.strip('"'))
close(HERE/'main.bend')
for p in HERE.iterdir():
 if p.is_file() and p.name not in ['plan-001.json','environment-001.json']:files.add(p)
for name in ['scripts/task_runner.py','scripts/check_preflight.py','scripts/bend-check']:files.add(ROOT/name)
for name in ['src/ecs/world-namespace.js','src/ecs/world-namespace.c']:files.add(ROOT/name)
inputs={str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}
checks=[dict(label='generic-public',argv=['bend',str(HERE/'public.bend'),'--check-only'],seconds=5),dict(label='generic-adapter',argv=['bend',str(HERE/'adapter.bend'),'--check-only'],seconds=5),dict(label='canonical-IO-effect-boundary',argv=['bend',str(HERE/'main.bend'),'--check-only'],seconds=5,exit=1,stderr=str((HERE/'expected-check-only.stderr').relative_to(ROOT))),dict(label='complete-consumer',argv=['bend',str(HERE/'main.bend')],seconds=5,stdout=str((HERE/'expected.stdout').relative_to(ROOT)))]
env=dict(os.environ,BEND_NO_TELEMETRY='1')
(HERE/'environment-001.json').write_text(json.dumps(env,sort_keys=True,indent=2)+'\n')
plan=dict(status='UNEXECUTED',sources=inputs,checks=checks,environmentSHA256=hashlib.sha256(json.dumps(env,sort_keys=True).encode()).hexdigest(),scope='22 complete public owned Raw refusal/retry observations, two nominal schemas, canonical WorldIO, all physical payloads/stamps/queues/registries and foreign peer snapshot; generic modules check-only exit0, IO application exact existing unsafe/foreign diagnostics exit1, no proof/core adoption/policy/new dependency/performance claims',next='After exact cheap full consumer passes: emit JS (30s), Node complete independent oracle (5s); affected Native and owner/authority negatives only under a new admitted immutable plan. No old 77-command cohort.')
(HERE/'plan-001.json').write_text(json.dumps(plan,indent=2)+'\n')
print('planSHA256',sha(HERE/'plan-001.json'),'transitiveBendSources',sum(p.suffix=='.bend' for p in files),'rows',22)
