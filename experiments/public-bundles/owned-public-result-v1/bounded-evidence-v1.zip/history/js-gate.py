"""Two-command emitted JS gate, after exact cheap consumer preflight."""
from pathlib import Path
import functools,hashlib,json,os,runpy,shutil,sys,tempfile
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import task_runner as R;import check_preflight as P
T=runpy.run_path(str(ROOT/'scripts/owned-tool-pins.py'))
PLAN=HERE/'js-plan-001.json';ENV=HERE/'js-environment-001.json';OUT=HERE/'js-001'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inventory(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def config(env):return dict(execute=functools.partial(R.execute_result,capture='split'),tools={'bend':Path(shutil.which('bend')).resolve(),'node':Path(shutil.which('node')).resolve(),'python':Path(sys.executable).resolve()},resource_roots=[Path('/home/node/.bend/bend2')],ldd=Path(shutil.which('ldd')).resolve(),taskset=Path(shutil.which('taskset')).resolve(),cpu=min(os.sched_getaffinity(0)),env=env,capture_mode='split')
def preflight():
 plan=json.loads((HERE/'plan-003.json').read_text());env=json.loads((HERE/'environment-003.json').read_text())
 return P.verify(HERE/'development-003/receipt.json',root=ROOT,files=[*plan['files'],str(HERE/'plan-003.json'),str(HERE/'environment-003.json')],directories=plan['directories'],checks=plan['checks'],env=env)
def prepare():
 assert not PLAN.exists() and not ENV.exists();preflight()
 base=json.loads((HERE/'plan-003.json').read_text());files={p:sha(p) for p in base['files']}
 for p in [Path(__file__),ROOT/'scripts/owned-tool-pins.py',HERE/'plan-003.json',HERE/'development-003/receipt.json']:files[str(p)]=sha(p)
 env=dict(os.environ,BEND_NO_TELEMETRY='1');ENV.write_text(json.dumps(env,sort_keys=True,indent=2)+'\n');ENV.chmod(0o600)
 snapshot=T['snapshot'](**config(env));directories={n:inventory(Path(n)) for n in base['directories']}
 commands=[dict(label='JS-emit',argv=['bend','STAGE/experiments/public-bundles/owned-public-result-v1/main.bend','-o','OUT/owned.js'],seconds=30),dict(label='JS-full22',argv=['node','OUT/owned.js'],seconds=5)]
 plan=dict(status='UNEXECUTED',files=files,directories=directories,environmentSHA256=sha(ENV),toolSnapshot=snapshot,commands=commands,fullOracleSHA256=sha(HERE/'expected.stdout'),scope='Emitted JS direct owned public result API: full22 source-current physical observations, two schemas, no performance/proof/production/full41 claim')
 PLAN.write_text(json.dumps(plan,indent=2)+'\n');print(sha(PLAN))
def execute():
 plan=json.loads(PLAN.read_text());assert sha(ENV)==plan['environmentSHA256'];env=json.loads(ENV.read_text());assert env==dict(os.environ,BEND_NO_TELEMETRY='1'),'ambient drift';preflight();assert not OUT.exists();OUT.mkdir()
 receipt=dict(status='INCOMPLETE',planSHA256=sha(PLAN),commands=[],generated={})
 def save():(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 save()
 try:
  with tempfile.TemporaryDirectory(prefix='owned-public-js-') as temp:
   stage=Path(temp);staged={}
   for name,h in plan['files'].items():
    p=Path(name)
    if p.is_relative_to(ROOT):
     target=stage/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);staged[str(target.relative_to(stage))]=h
   def guard():
    assert all(sha(n)==h for n,h in plan['files'].items()),'source drift'
    assert all(inventory(Path(n))==h for n,h in plan['directories'].items()),'external drift'
    assert inventory(stage)==staged,'stage drift'
    T['verify'](plan['toolSnapshot'],**config(env))
    assert all(sha(OUT/n)==h for n,h in receipt['generated'].items()),'generated drift'
   for command in plan['commands']:
    guard();argv=[str(stage)+a[5:] if a.startswith('STAGE/') else str(OUT)+a[3:] if a.startswith('OUT/') else a for a in command['argv']]
    result=R.execute_result(argv,command['seconds'],cwd=stage,env=env,capture='split');label=command['label']
    for stream in ['stdout','stderr']:(OUT/(label+'.'+stream)).write_bytes(result[stream])
    receipt['commands'].append(dict(label=label,argv=argv,exit=result['exit'],failure=result['failure'],stdoutSHA256=sha(OUT/(label+'.stdout')),stderrSHA256=sha(OUT/(label+'.stderr'))));save()
    assert result['failure'] is None and result['exit']==0,(label,result)
    assert not result['stderr'],label
    if label=='JS-emit':assert not result['stdout'];receipt['generated']['owned.js']=sha(OUT/'owned.js')
    else:assert result['stdout']==(HERE/'expected.stdout').read_bytes(),'full literal mismatch';receipt['fullRows']=22
    guard()
   receipt['status']='OWNED_PUBLIC_RESULT_JS_FINITE_PASS'
 finally:save();print(OUT/'receipt.json')
if sys.argv[1:]==['--prepare-only']:prepare()
elif sys.argv[1:]==['--execute']:execute()
else:raise SystemExit('use --prepare-only or --execute')
