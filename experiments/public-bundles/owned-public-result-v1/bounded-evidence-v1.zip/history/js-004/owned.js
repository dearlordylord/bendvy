function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

(() => {
// One allocator per emitted program, shared by all canonical world creations.
let bendvy_namespace_next = 1;
function bendvy_namespace_fresh() {
  if (bendvy_namespace_next >= 0xffffffff) return 0;
  return bendvy_namespace_next++;
}
io_eff("../../../src/ecs/world-namespace.fresh", bendvy_namespace_fresh);

})();

for (const k of ["IO.print","../../../src/ecs/world-namespace.fresh"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($a$1260$("A-missing-return")), run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $IO$bind$(($a$1261$("A-missing-retry-before")), run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return $IO$bind$(($a$1262$("A-missing-retry-after")), run_clo((_x_5) => {
  return run_clo((_x_6) => {
  return $IO$bind$(($a$1263$("A-missing-retry-unwind")), run_clo((_x_7) => {
  return run_clo((_x_8) => {
  return $IO$bind$(($a$1264$("A-invalid-return")), run_clo((_x_9) => {
  return run_clo((_x_10) => {
  return $IO$bind$(($a$1265$("A-invalid-retry-before")), run_clo((_x_11) => {
  return run_clo((_x_12) => {
  return $IO$bind$(($a$1266$("A-invalid-retry-after")), run_clo((_x_13) => {
  return run_clo((_x_14) => {
  return $IO$bind$(($a$1267$("A-invalid-retry-unwind")), run_clo((_x_15) => {
  return run_clo((_x_16) => {
  return $IO$bind$(($a$1268$("A-undeclared-return")), run_clo((_x_17) => {
  return run_clo((_x_18) => {
  return $IO$bind$(($a_foreign$(0, false, "A-foreign-return")), run_clo((_x_19) => {
  return run_clo((_x_20) => {
  return $IO$bind$(($a_foreign$(1, true, "A-foreign-retry-after")), run_clo((_x_21) => {
  return run_clo((_x_22) => {
  return $IO$bind$(($b$1260$("B-missing-return")), run_clo((_x_23) => {
  return run_clo((_x_24) => {
  return $IO$bind$(($b$1261$("B-missing-retry-before")), run_clo((_x_25) => {
  return run_clo((_x_26) => {
  return $IO$bind$(($b$1262$("B-missing-retry-after")), run_clo((_x_27) => {
  return run_clo((_x_28) => {
  return $IO$bind$(($b$1263$("B-missing-retry-unwind")), run_clo((_x_29) => {
  return run_clo((_x_30) => {
  return $IO$bind$(($b$1264$("B-invalid-return")), run_clo((_x_31) => {
  return run_clo((_x_32) => {
  return $IO$bind$(($b$1265$("B-invalid-retry-before")), run_clo((_x_33) => {
  return run_clo((_x_34) => {
  return $IO$bind$(($b$1266$("B-invalid-retry-after")), run_clo((_x_35) => {
  return run_clo((_x_36) => {
  return $IO$bind$(($b$1267$("B-invalid-retry-unwind")), run_clo((_x_37) => {
  return run_clo((_x_38) => {
  return $IO$bind$(($b$1268$("B-undeclared-return")), run_clo((_x_39) => {
  return run_clo((_x_40) => {
  return $IO$bind$(($b_foreign$(0, false, "B-foreign-return")), run_clo((_x_41) => {
  return $b_foreign$(1, true, "B-foreign-retry-after");
}), _x_40);
});
}), _x_38);
});
}), _x_36);
});
}), _x_34);
});
}), _x_32);
});
}), _x_30);
});
}), _x_28);
});
}), _x_26);
});
}), _x_24);
});
}), _x_22);
});
}), _x_20);
});
}), _x_18);
});
}), _x_16);
});
}), _x_14);
});
}), _x_12);
});
}), _x_10);
});
}), _x_8);
});
}), _x_6);
});
}), _x_4);
});
}), _x_2);
});
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $a$1260$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1260$(_label_0, _x_1);
}), _x_0);
});
}

function $a$1261$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1261$(_label_0, _x_1);
}), _x_0);
});
}

function $a$1262$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1262$(_label_0, _x_1);
}), _x_0);
});
}

function $a$1263$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1263$(_label_0, _x_1);
}), _x_0);
});
}

function $a$1264$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1264$(_label_0, _x_1);
}), _x_0);
});
}

function $a$1265$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1265$(_label_0, _x_1);
}), _x_0);
});
}

function $a$1266$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1266$(_label_0, _x_1);
}), _x_0);
});
}

function $a$1267$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1267$(_label_0, _x_1);
}), _x_0);
});
}

function $a$1268$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_observed$1268$(_label_0, _x_1);
}), _x_0);
});
}

function $a_foreign$(_mode_0, _retry_0, _label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_receiver$(_mode_0, _retry_0, _label_0, _x_1);
}), _x_0);
});
}

function $b$1260$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1260$(_label_0, _x_1);
}), _x_0);
});
}

function $b$1261$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1261$(_label_0, _x_1);
}), _x_0);
});
}

function $b$1262$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1262$(_label_0, _x_1);
}), _x_0);
});
}

function $b$1263$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1263$(_label_0, _x_1);
}), _x_0);
});
}

function $b$1264$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1264$(_label_0, _x_1);
}), _x_0);
});
}

function $b$1265$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1265$(_label_0, _x_1);
}), _x_0);
});
}

function $b$1266$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1266$(_label_0, _x_1);
}), _x_0);
});
}

function $b$1267$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1267$(_label_0, _x_1);
}), _x_0);
});
}

function $b$1268$(_label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_observed$1268$(_label_0, _x_1);
}), _x_0);
});
}

function $b_foreign$(_mode_0, _retry_0, _label_0) {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_receiver$(_mode_0, _retry_0, _label_0, _x_1);
}), _x_0);
});
}

function $$$$047production$045candidate$047schema$045a$058create$() {
  return $$$$047$$$047$$$047src$047ecs$047world$045io$058create$1260$(($$$$047production$045candidate$047schema$045a$058resource$()));
}

function $a_observed$1260$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(0, true, false, false, true, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_observed$1261$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(0, true, false, true, true, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_observed$1262$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(1, true, false, true, true, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_observed$1263$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(2, true, false, true, true, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_observed$1264$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(0, false, true, false, true, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_observed$1265$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(0, false, true, true, true, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_observed$1266$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(1, false, true, true, true, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_observed$1267$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(2, false, true, true, true, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_observed$1268$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045a$058local$(0, false, false, false, false, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $a_receiver$(_mode_0, _retry_0, _label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045a$058create$()), run_clo((_x_1) => {
  return $a_peer_created$(_mode_0, _retry_0, _label_0, run_loop($$$$047production$045candidate$047schema$045a$058seed$(_world_0)), _x_1);
}), _x_0);
});
  } else {
    return (_x_2) => $IO$print$((_label_0 + "=UNEXPECTED_RECEIVER_CREATOR_REFUSAL"), _x_2);
  }
}

function $$$$047production$045candidate$047schema$045b$058create$() {
  return $$$$047$$$047$$$047src$047ecs$047world$045io$058create$1261$(($$$$047production$045candidate$047schema$045b$058resource$()));
}

function $b_observed$1260$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(0, true, false, false, true, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_observed$1261$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(0, true, false, true, true, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_observed$1262$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(1, true, false, true, true, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_observed$1263$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(2, true, false, true, true, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_observed$1264$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(0, false, true, false, true, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_observed$1265$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(0, false, true, true, true, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_observed$1266$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(1, false, true, true, true, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_observed$1267$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(2, false, true, true, true, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_observed$1268$(_label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    const _x_0 = ($schema$045b$058local$(0, false, false, false, false, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0))));
    const _x_1 = ("=" + _x_0);
    return (_x_2) => $IO$print$((_label_0 + _x_1), _x_2);
  } else {
    return (_x_3) => $IO$print$((_label_0 + "=UNEXPECTED_CREATOR_REFUSAL"), _x_3);
  }
}

function $b_receiver$(_mode_0, _retry_0, _label_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    return run_clo((_x_0) => {
  return $IO$bind$(($$$$047production$045candidate$047schema$045b$058create$()), run_clo((_x_1) => {
  return $b_peer_created$(_mode_0, _retry_0, _label_0, run_loop($$$$047production$045candidate$047schema$045b$058seed$(_world_0)), _x_1);
}), _x_0);
});
  } else {
    return (_x_2) => $IO$print$((_label_0 + "=UNEXPECTED_RECEIVER_CREATOR_REFUSAL"), _x_2);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$045io$058create$1260$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1260$(_x_2, _resource_0);
}), _x_0);
});
}

function $$$$047production$045candidate$047schema$045a$058resource$() {
  return {$: "../combined-control.Mail", "context": ($$$$047constructor$045control$058context$()), "returned": {$: "Nil"}, "installed": {$: "Nil"}, "quarantine": {$: "Nil"}, "errors": {$: "Nil"}};
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $schema$045a$058local$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, _world_0) {
  return $schema$045a$058local_named$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047production$045candidate$047schema$045a$058seed$(_world_0) {
  return $$$$047production$045candidate$047schema$045a$058barrier$(($$$$047production$045candidate$047schema$045a$058call$(_world_0, {$: "../production-candidate/schema-a.Spawn"}, ($$$$047constructor$045control$058input$(true, true)))));
}

function $a_peer_created$(_mode_0, _retry_0, _label_0, _receiver_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _peer_0 = _result_0["world"];
    return $a_peer$(_mode_0, _retry_0, _label_0, _receiver_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(run_loop($$$$047production$045candidate$047schema$045a$058seed$(_peer_0)))));
  } else {
    return (_x_0) => $IO$print$((_label_0 + "=UNEXPECTED_PEER_CREATOR_REFUSAL"), _x_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$045io$058create$1261$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1261$(_x_2, _resource_0);
}), _x_0);
});
}

function $$$$047production$045candidate$047schema$045b$058resource$() {
  return {$: "../combined-other.Mail", "context": ($$$$047constructor$045control$058context$()), "returned": {$: "Nil"}, "installed": {$: "Nil"}, "quarantine": {$: "Nil"}, "errors": {$: "Nil"}};
}

function $schema$045b$058local$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, _world_0) {
  return $schema$045b$058local_named$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $$$$047production$045candidate$047schema$045b$058seed$(_world_0) {
  return $$$$047production$045candidate$047schema$045b$058barrier$(($$$$047production$045candidate$047schema$045b$058call$(_world_0, {$: "../production-candidate/schema-b.Spawn"}, ($$$$047constructor$045control$058input$(true, true)))));
}

function $b_peer_created$(_mode_0, _retry_0, _label_0, _receiver_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/world-io.Created") {
    const _peer_0 = _result_0["world"];
    return $b_peer$(_mode_0, _retry_0, _label_0, _receiver_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(run_loop($$$$047production$045candidate$047schema$045b$058seed$(_peer_0)))));
  } else {
    return (_x_0) => $IO$print$((_label_0 + "=UNEXPECTED_PEER_CREATOR_REFUSAL"), _x_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_k_0) {
  return { $: "$FFI", run: $0eff["../../../src/ecs/world-namespace.fresh"].run, need: $0eff["../../../src/ecs/world-namespace.fresh"].need, args: [], kont: (_k_0) };
}
function $$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1260$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1260$(($$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $$$$047constructor$045control$058context$() {
  return {$: "../constructor-control.Context", "calls": array_node(array_node([0], [0]), array_node([0], [0])), "order": {$: "Nil"}};
}

function $schema$045a$058local_named$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $schema$045a$058selected$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, _world_0, _namespace_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047production$045candidate$047schema$045a$058barrier$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0);
}

function $$$$047production$045candidate$047schema$045a$058call$(_world_0, _operation_0, _raw_0) {
  return $$$$047production$045candidate$047schema$045a$058call_with$(($$$$047public$045client$047declared$058available$()), _world_0, _operation_0, _raw_0);
}

function $$$$047constructor$045control$058input$(_ok1_0, _ok3_0) {
  return {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": array_node([11], [12])}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _ok1_0, "owner": 17}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": {$: "../constructor-control.Tag"}}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _ok3_0, "owner": {$: "../constructor-control.QueueOwner", "front": array_node([31], [32]), "back": array_node([41], [42]), "queued": {$: "Con", "head": array_node([51], [52]), "tail": {$: "Nil"}}}}, "tail": {$: "Unit"}}}}};
}

function $a_peer$(_mode_0, _retry_0, _label_0, _receiver_0, _named_0) {
  const _peer_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  const _x_0 = ($schema$045a$058world_snapshot$(_peer_0));
  const _x_1 = ($schema$045a$058foreign$(_mode_0, _retry_0, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, _receiver_0));
  const _x_2 = ("|peer=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("=" + _x_3);
  return (_x_5) => $IO$print$((_label_0 + _x_4), _x_5);
}

function $$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1261$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1261$(($$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $schema$045b$058local_named$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $schema$045b$058selected$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, _world_0, _namespace_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047production$045candidate$047schema$045b$058barrier$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0);
}

function $$$$047production$045candidate$047schema$045b$058call$(_world_0, _operation_0, _raw_0) {
  return $$$$047production$045candidate$047schema$045b$058call_with$(($$$$047public$045client$047declared$045other$058available$()), _world_0, _operation_0, _raw_0);
}

function $b_peer$(_mode_0, _retry_0, _label_0, _receiver_0, _named_0) {
  const _peer_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  const _x_0 = ($schema$045b$058world_snapshot$(_peer_0));
  const _x_1 = ($schema$045b$058foreign$(_mode_0, _retry_0, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, _receiver_0));
  const _x_2 = ("|peer=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("=" + _x_3);
  return (_x_5) => $IO$print$((_label_0 + _x_4), _x_5);
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1260$(_created_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/world.CreateRejected", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../src/ecs/world.Created", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047production$045candidate$047schema$045a$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $schema$045a$058selected$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, _world_0, _namespace_0) {
  if (_missing_0) {
    return $schema$045a$058input_selected$(_mode_0, _invalid_0, _retry_0, _declared_0, _world_0, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 99}, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
  } else {
    return $schema$045a$058input_selected$(_mode_0, _invalid_0, _retry_0, _declared_0, _world_0, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047production$045candidate$047schema$045a$058call_with$(_entries_0, _world_0, _operation_0, _raw_0) {
  return $$$$047production$045candidate$047schema$045a$058bound$(($$$$047public$058provision_declared$1261$({$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": {$: "Tuple", "fst": _world_0, "snd": {$: "../production-candidate/schema-a.Input", "operation": _operation_0, "raw": _raw_0}}}, ($$$$047public$045client$047declared$058required$()))));
}

function $$$$047public$045client$047declared$058available$() {
  return {$: "Con", "head": ($$$$047public$045client$047declared$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058b_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058tag_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058value_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058spawn_entry$()), "tail": {$: "Nil"}}}}}};
}

function $schema$045a$058foreign$(_mode_0, _retry_0, _target_0, _world_0) {
  return $schema$045a$058foreign_named$(_mode_0, _retry_0, _target_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $schema$045a$058world_snapshot$(_world_0) {
  return $schema$045a$058world_seen$(run_loop($schema$045a$058inspected$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1261$(_created_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/world.CreateRejected", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../src/ecs/world.Created", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047production$045candidate$047schema$045b$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $schema$045b$058selected$(_mode_0, _missing_0, _invalid_0, _retry_0, _declared_0, _world_0, _namespace_0) {
  if (_missing_0) {
    return $schema$045b$058input_selected$(_mode_0, _invalid_0, _retry_0, _declared_0, _world_0, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 99}, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
  } else {
    return $schema$045b$058input_selected$(_mode_0, _invalid_0, _retry_0, _declared_0, _world_0, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047production$045candidate$047schema$045b$058call_with$(_entries_0, _world_0, _operation_0, _raw_0) {
  return $$$$047production$045candidate$047schema$045b$058bound$(($$$$047public$058provision_declared$1265$({$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": {$: "Tuple", "fst": _world_0, "snd": {$: "../production-candidate/schema-b.Input", "operation": _operation_0, "raw": _raw_0}}}, ($$$$047public$045client$047declared$045other$058required$()))));
}

function $$$$047public$045client$047declared$045other$058available$() {
  return {$: "Con", "head": ($$$$047public$045client$047declared$045other$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058b_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058tag_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058value_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058spawn_entry$()), "tail": {$: "Nil"}}}}}};
}

function $schema$045b$058foreign$(_mode_0, _retry_0, _target_0, _world_0) {
  return $schema$045b$058foreign_named$(_mode_0, _retry_0, _target_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $schema$045b$058world_snapshot$(_world_0) {
  return $schema$045b$058world_seen$(run_loop($schema$045b$058inspected$(_world_0)));
}

function $$$$047production$045candidate$047schema$045a$058empty$(_unit_0) {
  return {$: "../combined-control.Store", "a": ($$$$047$$$047$$$047src$047ecs$047column$058empty$1260$()), "b": ($$$$047$$$047$$$047src$047ecs$047column$058empty$1260$()), "tag": ($$$$047$$$047$$$047src$047ecs$047column$058empty$1261$()), "value": ($$$$047$$$047$$$047src$047ecs$047column$058empty$1262$())};
}

function $schema$045a$058input_selected$(_mode_0, _invalid_0, _retry_0, _declared_0, _world_0, _target_0, _local_0) {
  if (_invalid_0) {
    return $schema$045a$058launch$(_world_0, {$: "schema-a.Args", "input": {$: "adapter.Input", "target": _target_0, "raw": ($$$$047constructor$045control$058input$(true, false))}, "retryTarget": _local_0, "retry": _retry_0, "declared": _declared_0}, _mode_0);
  } else {
    return $schema$045a$058launch$(_world_0, {$: "schema-a.Args", "input": {$: "adapter.Input", "target": _target_0, "raw": ($$$$047production$045candidate$047schema$045a$058replacement$())}, "retryTarget": _local_0, "retry": _retry_0, "declared": _declared_0}, _mode_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047production$045candidate$047schema$045a$058bound$(_observed_0) {
  if (_observed_0.$ === "../../../src/ecs/schema-fragments.Built") {
    const _world_0 = _observed_0["output"];
    return _world_0;
  } else {
    const _t_0 = _observed_0["fragment"];
    const _t_1 = _t_0["owners"];
    const _world_1 = _t_1["fst"];
    const _t_2 = _t_1["snd"];
    const _raw_0 = _t_2["raw"];
    return $$$$047combined$045control$058returned$(_world_1, {$: "../combined-control.Original", "raw": _raw_0}, "undeclared-refusal");
  }
}

function $$$$047public$058provision_declared$1261$(_fragment_0, _required_0) {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_declared$1261$(_fragment_0, _required_0);
}

function $$$$047public$045client$047declared$058required$() {
  return {$: "Con", "head": ($$$$047public$045client$047declared$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058b_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058tag_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058value_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058spawn_entry$()), "tail": {$: "Nil"}}}}}}};
}

function $$$$047public$045client$047declared$058a_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1260$(($$$$047public$045client$047declared$058a$()));
}

function $$$$047public$045client$047declared$058b_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1261$(($$$$047public$045client$047declared$058b$()));
}

function $$$$047public$045client$047declared$058tag_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1262$(($$$$047public$045client$047declared$058tag$()));
}

function $$$$047public$045client$047declared$058value_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1263$(($$$$047public$045client$047declared$058value$()));
}

function $$$$047public$045client$047declared$058spawn_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1264$(($$$$047public$045client$047declared$058spawn$()));
}

function $schema$045a$058foreign_named$(_mode_0, _retry_0, _target_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $schema$045a$058input_selected$(_mode_0, false, _retry_0, true, _world_0, _target_0, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
}

function $schema$045a$058world_seen$(_seen_0) {
  const _world_0 = _seen_0["fst"];
  const _queues_0 = _seen_0["snd"];
  return $schema$045a$058world_meta$(_world_0, _queues_0);
}

function $schema$045a$058inspected$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $schema$045a$058installed_result$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_0, "returned": _items_0, "installed": _x_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, "snd": ($List$show$1261$(_x_1))};
});
}), run_loop($schema$045a$058installed_read$(_installed_0)));
}

function $$$$047production$045candidate$047schema$045b$058empty$(_unit_0) {
  return {$: "../combined-other.Store", "a": ($$$$047$$$047$$$047src$047ecs$047column$058empty$1263$()), "b": ($$$$047$$$047$$$047src$047ecs$047column$058empty$1263$()), "tag": ($$$$047$$$047$$$047src$047ecs$047column$058empty$1264$()), "value": ($$$$047$$$047$$$047src$047ecs$047column$058empty$1265$())};
}

function $schema$045b$058input_selected$(_mode_0, _invalid_0, _retry_0, _declared_0, _world_0, _target_0, _local_0) {
  if (_invalid_0) {
    return $schema$045b$058launch$(_world_0, {$: "schema-b.Args", "input": {$: "adapter.Input", "target": _target_0, "raw": ($$$$047constructor$045control$058input$(true, false))}, "retryTarget": _local_0, "retry": _retry_0, "declared": _declared_0}, _mode_0);
  } else {
    return $schema$045b$058launch$(_world_0, {$: "schema-b.Args", "input": {$: "adapter.Input", "target": _target_0, "raw": ($$$$047production$045candidate$047schema$045b$058replacement$())}, "retryTarget": _local_0, "retry": _retry_0, "declared": _declared_0}, _mode_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $$$$047production$045candidate$047schema$045b$058bound$(_observed_0) {
  if (_observed_0.$ === "../../../src/ecs/schema-fragments.Built") {
    const _world_0 = _observed_0["output"];
    return _world_0;
  } else {
    const _t_0 = _observed_0["fragment"];
    const _t_1 = _t_0["owners"];
    const _world_1 = _t_1["fst"];
    const _t_2 = _t_1["snd"];
    const _raw_0 = _t_2["raw"];
    return $$$$047combined$045other$058returned$(_world_1, {$: "../combined-other.Original", "raw": _raw_0}, "undeclared-refusal");
  }
}

function $$$$047public$058provision_declared$1265$(_fragment_0, _required_0) {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_declared$1266$(_fragment_0, _required_0);
}

function $$$$047public$045client$047declared$045other$058required$() {
  return {$: "Con", "head": ($$$$047public$045client$047declared$045other$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058b_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058tag_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058value_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058spawn_entry$()), "tail": {$: "Nil"}}}}}}};
}

function $$$$047public$045client$047declared$045other$058a_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1265$(($$$$047public$045client$047declared$045other$058a$()));
}

function $$$$047public$045client$047declared$045other$058b_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1266$(($$$$047public$045client$047declared$045other$058b$()));
}

function $$$$047public$045client$047declared$045other$058tag_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1267$(($$$$047public$045client$047declared$045other$058tag$()));
}

function $$$$047public$045client$047declared$045other$058value_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1268$(($$$$047public$045client$047declared$045other$058value$()));
}

function $$$$047public$045client$047declared$045other$058spawn_entry$() {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1269$(($$$$047public$045client$047declared$045other$058spawn$()));
}

function $schema$045b$058foreign_named$(_mode_0, _retry_0, _target_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $schema$045b$058input_selected$(_mode_0, false, _retry_0, true, _world_0, _target_0, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
}

function $schema$045b$058world_seen$(_seen_0) {
  const _world_0 = _seen_0["fst"];
  const _queues_0 = _seen_0["snd"];
  return $schema$045b$058world_meta$(_world_0, _queues_0);
}

function $schema$045b$058inspected$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $schema$045b$058installed_result$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_0, "returned": _items_0, "installed": _x_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, "snd": ($List$show$1261$(_x_1))};
});
}), run_loop($schema$045b$058installed_read$(_installed_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058empty$1260$() {
  return {$: "../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058empty$1261$() {
  return {$: "../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058empty$1262$() {
  return {$: "../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $schema$045a$058launch$(_world_0, _args_0, _mode_0) {
  return $schema$045a$058registered$(_mode_0, _args_0, ($$$$047$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, "owned-request", {$: "Con", "head": "write:a", "tail": {$: "Con", "head": "write:b", "tail": {$: "Con", "head": "write:tag", "tail": {$: "Con", "head": "write:value", "tail": {$: "Con", "head": "bundle.insert", "tail": {$: "Nil"}}}}}})));
}

function $$$$047production$045candidate$047schema$045a$058replacement$() {
  return {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": array_node([71], [72])}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": 27}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": {$: "../constructor-control.Tag"}}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": {$: "../constructor-control.QueueOwner", "front": array_node([91], [92]), "back": array_node([101], [102]), "queued": {$: "Con", "head": array_node([111], [112]), "tail": {$: "Nil"}}}}, "tail": {$: "Unit"}}}}};
}

function $$$$047combined$045control$058returned$(_world_0, _result_0, _error_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_0, "returned": {$: "Con", "head": _result_0, "tail": _items_0}, "installed": _installed_0, "quarantine": _quarantine_0, "errors": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": {$: "Nil"}}}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_declared$1261$(_fragment_0, _required_0) {
  const _entries_0 = _fragment_0["entries"];
  const _owners_0 = _fragment_0["owners"];
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_requirements$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate$1260$(_entries_0)), _required_0, {$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0});
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1260$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$058a$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "a"};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1261$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$058b$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Component"}, "key": "b", "name": "b"};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1262$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$058tag$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Component"}, "key": "tag", "name": "tag"};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1263$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$058value$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Component"}, "key": "value", "name": "value"};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1264$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$058spawn$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.spawn", "name": "bundle.spawn"};
}

function $schema$045a$058world_meta$(_world_0, _queues_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($U32$show$(_system_0));
  const _x_1 = ($List$show$12612$(_regs_0));
  const _x_2 = ("|nextSystem=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_depth_0));
  const _x_5 = ("|registrations=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ("|depth=" + _x_6);
  const _x_8 = (_queues_0 + _x_7);
  const _x_9 = ($$$$047combined$045control$058snapshot$({$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}));
  const _x_10 = ("|installed-queues=" + _x_8);
  return (_x_9 + _x_10);
}

function $schema$045a$058installed_result$1260$(_next_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _texts_0 = _result_0["snd"];
  return run_tail(_next_0(_owners_0), _texts_0);
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047constructor$045control$058string_identity$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $schema$045a$058installed_read$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $schema$045a$058installed_head$(_head_0, run_loop($schema$045a$058installed_read$(_tail_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058empty$1263$() {
  return {$: "../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058empty$1264$() {
  return {$: "../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058empty$1265$() {
  return {$: "../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $schema$045b$058launch$(_world_0, _args_0, _mode_0) {
  return $schema$045b$058registered$(_mode_0, _args_0, ($$$$047$$$047$$$047src$047ecs$047system$058register$1265$(_world_0, "owned-request", {$: "Con", "head": "write:a", "tail": {$: "Con", "head": "write:b", "tail": {$: "Con", "head": "write:tag", "tail": {$: "Con", "head": "write:value", "tail": {$: "Con", "head": "bundle.insert", "tail": {$: "Nil"}}}}}})));
}

function $$$$047production$045candidate$047schema$045b$058replacement$() {
  return {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": array_node([71], [72])}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": 27}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": {$: "../constructor-control.Tag"}}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": {$: "../constructor-control.QueueOwner", "front": array_node([91], [92]), "back": array_node([101], [102]), "queued": {$: "Con", "head": array_node([111], [112]), "tail": {$: "Nil"}}}}, "tail": {$: "Unit"}}}}};
}

function $$$$047combined$045other$058returned$(_world_0, _result_0, _error_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_0, "returned": {$: "Con", "head": _result_0, "tail": _items_0}, "installed": _installed_0, "quarantine": _quarantine_0, "errors": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": {$: "Nil"}}}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_declared$1266$(_fragment_0, _required_0) {
  const _entries_0 = _fragment_0["entries"];
  const _owners_0 = _fragment_0["owners"];
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_requirements$1266$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate$1261$(_entries_0)), _required_0, {$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0});
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1265$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$045other$058a$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "a"};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1266$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$045other$058b$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Component"}, "key": "b", "name": "b"};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1267$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$045other$058tag$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Component"}, "key": "tag", "name": "tag"};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1268$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$045other$058value$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Component"}, "key": "value", "name": "value"};
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058entry$1269$(_descriptor_0) {
  const _kind_0 = _descriptor_0["kind"];
  const _key_0 = _descriptor_0["key"];
  const _name_0 = _descriptor_0["name"];
  return {$: "../../../src/ecs/schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
}

function $$$$047public$045client$047declared$045other$058spawn$() {
  return {$: "../../../src/ecs/schema-fragments.Descriptor", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.spawn", "name": "bundle.spawn"};
}

function $schema$045b$058world_meta$(_world_0, _queues_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($U32$show$(_system_0));
  const _x_1 = ($List$show$12617$(_regs_0));
  const _x_2 = ("|nextSystem=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_depth_0));
  const _x_5 = ("|registrations=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ("|depth=" + _x_6);
  const _x_8 = (_queues_0 + _x_7);
  const _x_9 = ($$$$047combined$045other$058snapshot$({$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}));
  const _x_10 = ("|installed-queues=" + _x_8);
  return (_x_9 + _x_10);
}

function $schema$045b$058installed_result$1260$(_next_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _texts_0 = _result_0["snd"];
  return run_tail(_next_0(_owners_0), _texts_0);
}

function $schema$045b$058installed_read$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $schema$045b$058installed_head$(_head_0, run_loop($schema$045b$058installed_read$(_tail_0)));
  }
}

function $schema$045a$058registered$(_mode_0, _args_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $schema$045a$058ran$(_mode_0, ($$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0)));
  } else {
    return "UNEXPECTED_REGISTRATION_REFUSAL";
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1262$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_requirements$1261$(_result_0, _required_0, _fragment_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.BindRejected", "error": _error_0, "fragment": _fragment_0};
  } else {
    const _entries_0 = _fragment_0["entries"];
    const _owners_0 = _fragment_0["owners"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_checked$1261$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058requirements$1260$(_required_0, _entries_0)), {$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate$1260$(_entries_0) {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../../src/ecs/schema-fragments.Component"})), {$: "Nil"})), ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../../src/ecs/schema-fragments.Resource"})), {$: "Nil"})), ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../../src/ecs/schema-fragments.Event"})), {$: "Nil"})), ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../../src/ecs/schema-fragments.Relation"})), {$: "Nil"})), run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../../src/ecs/schema-fragments.Service"})), {$: "Nil"})))))))));
}

function $$$$047combined$045control$058snapshot$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($List$show$1262$(_errors_0));
  const _x_1 = ($U32$show$(($$$$047combined$045control$058count$1262$(_commands_0))));
  const _x_2 = ("|errors=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(($$$$047combined$045control$058count$1261$(_quarantine_0))));
  const _x_5 = ("|pending=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(($$$$047combined$045control$058count$1260$(_installed_0))));
  const _x_8 = ("|quarantine=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($$$$047combined$045control$058returned_text$(_items_0));
  const _x_11 = ("|installed=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($$$$047combined$045control$058context_text$(_context_0));
  const _x_14 = ("|raw=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($$$$047combined$045control$058world_text$({$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": ($$$$047constructor$045control$058context$()), "returned": {$: "Nil"}, "installed": {$: "Nil"}, "quarantine": {$: "Nil"}, "errors": {$: "Nil"}}, "events": _events_0, "pending": {$: "Nil"}, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}));
  const _x_17 = ("|context=" + _x_15);
  return (_x_16 + _x_17);
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($schema$045a$058registration$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047constructor$045control$058string_identity$(_text_0) {
  return _text_0;
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047constructor$045control$058string_identity$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $schema$045a$058installed_head$(_head_0, _result_0) {
  const _inverse_0 = _head_0["inverse"];
  const _queued_0 = _head_0["queued"];
  const _undo_0 = _head_0["undo"];
  const _tail_0 = _result_0["fst"];
  const _texts_0 = _result_0["snd"];
  return $schema$045a$058queued_result$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "../combined-control.Installed", "inverse": _inverse_0, "queued": _x_0, "undo": _undo_0}, "tail": _tail_0}, "snd": {$: "Con", "head": ($List$show$1261$(_x_1)), "tail": _texts_0}};
});
}), ($$$$047constructor$045control$058list_read$(_queued_0)));
}

function $schema$045b$058registered$(_mode_0, _args_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $schema$045b$058ran$(_mode_0, ($$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0)));
  } else {
    return "UNEXPECTED_REGISTRATION_REFUSAL";
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1265$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1265$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_requirements$1266$(_result_0, _required_0, _fragment_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.BindRejected", "error": _error_0, "fragment": _fragment_0};
  } else {
    const _entries_0 = _fragment_0["entries"];
    const _owners_0 = _fragment_0["owners"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_checked$1266$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058requirements$1261$(_required_0, _entries_0)), {$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate$1261$(_entries_0) {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../../src/ecs/schema-fragments.Component"})), {$: "Nil"})), ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../../src/ecs/schema-fragments.Resource"})), {$: "Nil"})), ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../../src/ecs/schema-fragments.Event"})), {$: "Nil"})), ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../../src/ecs/schema-fragments.Relation"})), {$: "Nil"})), run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../../src/ecs/schema-fragments.Service"})), {$: "Nil"})))))))));
}

function $$$$047combined$045other$058snapshot$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($List$show$1262$(_errors_0));
  const _x_1 = ($U32$show$(($$$$047combined$045other$058count$1262$(_commands_0))));
  const _x_2 = ("|errors=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(($$$$047combined$045other$058count$1261$(_quarantine_0))));
  const _x_5 = ("|pending=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(($$$$047combined$045other$058count$1260$(_installed_0))));
  const _x_8 = ("|quarantine=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($$$$047combined$045other$058returned_text$(_items_0));
  const _x_11 = ("|installed=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($$$$047combined$045other$058context_text$(_context_0));
  const _x_14 = ("|raw=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($$$$047combined$045other$058world_text$({$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": ($$$$047constructor$045control$058context$()), "returned": {$: "Nil"}, "installed": {$: "Nil"}, "quarantine": {$: "Nil"}, "errors": {$: "Nil"}}, "events": _events_0, "pending": {$: "Nil"}, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}));
  const _x_17 = ("|context=" + _x_15);
  return (_x_16 + _x_17);
}

function $List$show$12617$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($schema$045b$058registration$(_h_0));
    const _x_1 = ($List$show$go$12617$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $schema$045b$058installed_head$(_head_0, _result_0) {
  const _inverse_0 = _head_0["inverse"];
  const _queued_0 = _head_0["queued"];
  const _undo_0 = _head_0["undo"];
  const _tail_0 = _result_0["fst"];
  const _texts_0 = _result_0["snd"];
  return $schema$045b$058queued_result$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "../combined-other.Installed", "inverse": _inverse_0, "queued": _x_0, "undo": _undo_0}, "tail": _tail_0}, "snd": {$: "Con", "head": ($List$show$1261$(_x_1)), "tail": _texts_0}};
});
}), ($$$$047constructor$045control$058list_read$(_queued_0)));
}

function $schema$045a$058ran$(_mode_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Completed") {
    const _t_0 = _result_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    const _t_1 = _result_0["outcome"];
    if (_t_1.$ === "../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_1["world"];
      const _delivery_0 = _t_1["output"];
      const _x_0 = ($schema$045a$058delivered$(_delivery_0));
      const _x_1 = ($U32$show$(_cursor_0));
      const _x_2 = ("|" + _x_0);
      const _x_3 = (_x_1 + _x_2);
      const _x_4 = ($List$show$1261$(_access_0));
      const _x_5 = (":" + _x_3);
      const _x_6 = (_x_4 + _x_5);
      const _x_7 = (":" + _x_6);
      const _x_8 = (_name_0 + _x_7);
      const _x_9 = ($U32$show$(_id_0));
      const _x_10 = (":" + _x_8);
      const _x_11 = (_x_9 + _x_10);
      const _x_12 = ($U32$show$(_namespace_0));
      const _x_13 = (":" + _x_11);
      const _x_14 = (_x_12 + _x_13);
      const _x_15 = ($schema$045a$058world_snapshot$(run_loop($schema$045a$058transform$(_mode_0, _world_0))));
      const _x_16 = ("|registry=" + _x_14);
      return (_x_15 + _x_16);
    } else {
      return "UNEXPECTED_REGISTERED_RUN_RESULT";
    }
  } else {
    return "UNEXPECTED_REGISTERED_RUN_RESULT";
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1262$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_checked$1261$(_result_0, _fragment_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.BindRejected", "error": _error_0, "fragment": _fragment_0};
  } else {
    const _owners_0 = _fragment_0["owners"];
    return {$: "../../../src/ecs/schema-fragments.Built", "output": ($$$$047production$045candidate$047schema$045a$058invoke$(_owners_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058requirements$1260$(_required_0, _entries_0) {
  if (_required_0.$ === "Nil") {
    return {$: "../../../src/ecs/schema-fragments.Valid"};
  } else {
    const _item_0 = _required_0["head"];
    const _rest_0 = _required_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058required_continue$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058required_check$1260$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058descriptor_present$1260$(_entries_0, _item_0)), _item_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058requirements$1260$(_rest_0, _entries_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(_first_0, _second_0) {
  if (_first_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _first_0["error"];
    return {$: "../../../src/ecs/schema-fragments.Invalid", "error": _error_0};
  } else {
    return _second_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(_xs_0, _seen_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "../../../src/ecs/schema-fragments.Valid"};
  } else {
    const _item_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validation_continue$1260$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058check_one$1260$(_seen_0, _item_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(_rest_0, {$: "Con", "head": _item_0, "tail": _seen_0});
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_xs_0, _kind_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _xs_0["head"];
    const _itemKind_0 = _t_0["kind"];
    const _key_0 = _t_0["key"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind_done$1260$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _itemKind_0)), {$: "../../../src/ecs/schema-fragments.Entry", "kind": _itemKind_0, "key": _key_0, "name": _name_0}, ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_rest_0, _kind_0)));
  }
}

function $$$$047combined$045control$058world_text$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _t_0 = _world_0["store"];
  const _a_0 = _t_0["a"];
  const _b_0 = _t_0["b"];
  const _tag_0 = _t_0["tag"];
  const _value_0 = _t_0["value"];
  const _events_0 = _world_0["events"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($List$show$1260$(_events_0));
  const _x_1 = ($U32$show$(_cap_0));
  const _x_2 = ("|events=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_high_0));
  const _x_5 = ("|capacity=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(_next_0));
  const _x_8 = ("|high=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_ns_0));
  const _x_11 = ("|next=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1265$(($$$$047combined$045control$058bool_cells$(_live_0))));
  const _x_14 = ("|ns=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($U32$show$(_clock_0));
  const _x_17 = ("|live=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($$$$047combined$045control$058column_text$1262$(_value_0));
  const _x_20 = ("|clock=" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ($$$$047combined$045control$058column_text$1261$(_tag_0));
  const _x_23 = ("|" + _x_21);
  const _x_24 = (_x_22 + _x_23);
  const _x_25 = ($$$$047combined$045control$058column_text$1260$(_b_0));
  const _x_26 = ("|" + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($$$$047combined$045control$058column_text$1260$(_a_0));
  const _x_29 = ("|" + _x_27);
  return (_x_28 + _x_29);
}

function $$$$047combined$045control$058context_text$(_context_0) {
  const _calls_0 = _context_0["calls"];
  const _order_0 = _context_0["order"];
  const _x_0 = ($List$show$1260$(_order_0));
  const _x_1 = ($List$show$1260$(($$$$047constructor$045control$058cells$(_calls_0))));
  const _x_2 = ("/" + _x_0);
  return (_x_1 + _x_2);
}

function $$$$047combined$045control$058returned_text$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "[]";
  } else {
    const _t_0 = _items_0["head"];
    if (_t_0.$ === "../combined-control.Original") {
      const _raw_0 = _t_0["raw"];
      const _rest_0 = _items_0["tail"];
      const _x_0 = ($$$$047combined$045control$058returned_text$(_rest_0));
      const _x_1 = ($$$$047constructor$045control$058raw_0$(_raw_0));
      const _x_2 = ("]" + _x_0);
      const _x_3 = (_x_1 + _x_2);
      return ("[" + _x_3);
    } else {
      return "UNASSEMBLED";
    }
  }
}

function $$$$047combined$045control$058count$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($$$$047combined$045control$058count$1260$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $$$$047combined$045control$058count$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($$$$047combined$045control$058count$1261$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $$$$047combined$045control$058count$1262$(_items_0) {
  if (_items_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($$$$047combined$045control$058count$1262$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047constructor$045control$058error_view$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $schema$045a$058registration$(_meta_0) {
  const _id_0 = _meta_0["id"];
  const _name_0 = _meta_0["name"];
  const _access_0 = _meta_0["access"];
  const _x_0 = ($List$show$1261$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$12612$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($schema$045a$058registration$(_h_0));
    const _x_1 = ($List$show$go$12612$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $schema$045a$058queued_result$1260$(_next_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _texts_0 = _result_0["snd"];
  return run_tail(_next_0(_owners_0), _texts_0);
}

function $$$$047constructor$045control$058list_read$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $$$$047constructor$045control$058list_read_join$(($$$$047constructor$045control$058array_read$(_head_0)), ($$$$047constructor$045control$058list_read$(_tail_0)));
  }
}

function $schema$045b$058ran$(_mode_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/system.Completed") {
    const _t_0 = _result_0["registry"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _cursor_0 = _t_0["cursor"];
    const _t_1 = _result_0["outcome"];
    if (_t_1.$ === "../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_1["world"];
      const _delivery_0 = _t_1["output"];
      const _x_0 = ($schema$045b$058delivered$(_delivery_0));
      const _x_1 = ($U32$show$(_cursor_0));
      const _x_2 = ("|" + _x_0);
      const _x_3 = (_x_1 + _x_2);
      const _x_4 = ($List$show$1261$(_access_0));
      const _x_5 = (":" + _x_3);
      const _x_6 = (_x_4 + _x_5);
      const _x_7 = (":" + _x_6);
      const _x_8 = (_name_0 + _x_7);
      const _x_9 = ($U32$show$(_id_0));
      const _x_10 = (":" + _x_8);
      const _x_11 = (_x_9 + _x_10);
      const _x_12 = ($U32$show$(_namespace_0));
      const _x_13 = (":" + _x_11);
      const _x_14 = (_x_12 + _x_13);
      const _x_15 = ($schema$045b$058world_snapshot$(run_loop($schema$045b$058transform$(_mode_0, _world_0))));
      const _x_16 = ("|registry=" + _x_14);
      return (_x_15 + _x_16);
    } else {
      return "UNEXPECTED_REGISTERED_RUN_RESULT";
    }
  } else {
    return "UNEXPECTED_REGISTERED_RUN_RESULT";
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047src$047ecs$047system$058run$1265$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1265$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1265$(($$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_checked$1266$(_result_0, _fragment_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.BindRejected", "error": _error_0, "fragment": _fragment_0};
  } else {
    const _owners_0 = _fragment_0["owners"];
    return {$: "../../../src/ecs/schema-fragments.Built", "output": ($$$$047production$045candidate$047schema$045b$058invoke$(_owners_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058requirements$1261$(_required_0, _entries_0) {
  if (_required_0.$ === "Nil") {
    return {$: "../../../src/ecs/schema-fragments.Valid"};
  } else {
    const _item_0 = _required_0["head"];
    const _rest_0 = _required_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058required_continue$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058required_check$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058descriptor_present$1261$(_entries_0, _item_0)), _item_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058requirements$1261$(_rest_0, _entries_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(_xs_0, _seen_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "../../../src/ecs/schema-fragments.Valid"};
  } else {
    const _item_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validation_continue$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058check_one$1261$(_seen_0, _item_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(_rest_0, {$: "Con", "head": _item_0, "tail": _seen_0});
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_xs_0, _kind_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _xs_0["head"];
    const _itemKind_0 = _t_0["kind"];
    const _key_0 = _t_0["key"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind_done$1261$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _itemKind_0)), {$: "../../../src/ecs/schema-fragments.Entry", "kind": _itemKind_0, "key": _key_0, "name": _name_0}, ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_rest_0, _kind_0)));
  }
}

function $$$$047combined$045other$058world_text$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _t_0 = _world_0["store"];
  const _a_0 = _t_0["a"];
  const _b_0 = _t_0["b"];
  const _tag_0 = _t_0["tag"];
  const _value_0 = _t_0["value"];
  const _events_0 = _world_0["events"];
  const _clock_0 = _world_0["clock"];
  const _x_0 = ($List$show$1260$(_events_0));
  const _x_1 = ($U32$show$(_cap_0));
  const _x_2 = ("|events=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_high_0));
  const _x_5 = ("|capacity=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($U32$show$(_next_0));
  const _x_8 = ("|high=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_ns_0));
  const _x_11 = ("|next=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($List$show$1265$(($$$$047combined$045other$058bool_cells$(_live_0))));
  const _x_14 = ("|ns=" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($U32$show$(_clock_0));
  const _x_17 = ("|live=" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($$$$047combined$045other$058column_text$1262$(_value_0));
  const _x_20 = ("|clock=" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ($$$$047combined$045other$058column_text$1261$(_tag_0));
  const _x_23 = ("|" + _x_21);
  const _x_24 = (_x_22 + _x_23);
  const _x_25 = ($$$$047combined$045other$058column_text$1260$(_b_0));
  const _x_26 = ("|" + _x_24);
  const _x_27 = (_x_25 + _x_26);
  const _x_28 = ($$$$047combined$045other$058column_text$1260$(_a_0));
  const _x_29 = ("|" + _x_27);
  return (_x_28 + _x_29);
}

function $$$$047combined$045other$058context_text$(_context_0) {
  const _calls_0 = _context_0["calls"];
  const _order_0 = _context_0["order"];
  const _x_0 = ($List$show$1260$(_order_0));
  const _x_1 = ($List$show$1260$(($$$$047constructor$045control$058cells$(_calls_0))));
  const _x_2 = ("/" + _x_0);
  return (_x_1 + _x_2);
}

function $$$$047combined$045other$058returned_text$(_items_0) {
  if (_items_0.$ === "Nil") {
    return "[]";
  } else {
    const _t_0 = _items_0["head"];
    if (_t_0.$ === "../combined-other.Original") {
      const _raw_0 = _t_0["raw"];
      const _rest_0 = _items_0["tail"];
      const _x_0 = ($$$$047combined$045other$058returned_text$(_rest_0));
      const _x_1 = ($$$$047constructor$045control$058raw_0$(_raw_0));
      const _x_2 = ("]" + _x_0);
      const _x_3 = (_x_1 + _x_2);
      return ("[" + _x_3);
    } else {
      return "UNASSEMBLED";
    }
  }
}

function $$$$047combined$045other$058count$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($$$$047combined$045other$058count$1260$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $$$$047combined$045other$058count$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($$$$047combined$045other$058count$1261$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $$$$047combined$045other$058count$1262$(_items_0) {
  if (_items_0.$ === "Nil") {
    return 0;
  } else {
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($$$$047combined$045other$058count$1262$(_tail_0));
    return ((1 + _x_0) >>> 0);
  }
}

function $schema$045b$058registration$(_meta_0) {
  const _id_0 = _meta_0["id"];
  const _name_0 = _meta_0["name"];
  const _access_0 = _meta_0["access"];
  const _x_0 = ($List$show$1261$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$12617$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($schema$045b$058registration$(_h_0));
    const _x_1 = ($List$show$go$12617$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $schema$045b$058queued_result$1260$(_next_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _texts_0 = _result_0["snd"];
  return run_tail(_next_0(_owners_0), _texts_0);
}

function $schema$045a$058transform$(_mode_0, _world_0) {
  if (_mode_0 === 0) {
    return _world_0;
  } else if (_mode_0 === 1) {
    return $$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0);
  } else {
    return $$$$047combined$045control$058unwind$(run_loop($$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)));
  }
}

function $schema$045a$058delivered$(_delivery_0) {
  const _context_0 = _delivery_0["context"];
  const _t_0 = _delivery_0["result"];
  const _result_0 = _t_0["result"];
  const _error_0 = _t_0["first"];
  const _returned_0 = _t_0["returned"];
  const _prepared_0 = _delivery_0["prepared"];
  const _x_0 = ($List$show$1261$(_prepared_0));
  const _x_1 = ($$$$047combined$045control$058context_text$(_context_0));
  const _x_2 = ("|prepared=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|caller-context=" + _x_3);
  const _x_5 = (_returned_0 + _x_4);
  const _x_6 = ($schema$045a$058first$(_error_0));
  const _x_7 = ("|returned=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($schema$045a$058outcome$(_result_0));
  const _x_10 = ("|first=" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  return ("result=" + _x_11);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047production$045candidate$047schema$045a$058invoke$(_owners_0) {
  const _world_0 = _owners_0["fst"];
  const _input_0 = _owners_0["snd"];
  return $$$$047production$045candidate$047schema$045a$058finished$(($$$$047public$058provide$1261$(_input_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058required_continue$(_result_0, _next_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.Invalid", "error": _error_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058required_check$1260$(_present_0, _item_0) {
  if (_present_0) {
    return {$: "../../../src/ecs/schema-fragments.Valid"};
  } else {
    const _kind_0 = _item_0["kind"];
    const _key_0 = _item_0["key"];
    const _name_0 = _item_0["name"];
    return {$: "../../../src/ecs/schema-fragments.Invalid", "error": {$: "../../../src/ecs/schema-fragments.UndeclaredDescriptor", "kind": _kind_0, "key": _key_0, "name": _name_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058descriptor_present$1260$(_xs_0, _item_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _ak_0 = _t_0["kind"];
    const _ax_0 = _t_0["key"];
    const _an_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    const _bk_0 = _item_0["kind"];
    const _bx_0 = _item_0["key"];
    const _bn_0 = _item_0["name"];
    const _x_0 = ($Bool$and$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_ak_0, _bk_0)), ($Bool$and$(($String$eq$(_ax_0, _bx_0)), ($String$eq$(_an_0, _bn_0))))));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058descriptor_present$1260$(_rest_0, {$: "../../../src/ecs/schema-fragments.Entry", "kind": _bk_0, "key": _bx_0, "name": _bn_0}));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validation_continue$1260$(_result_0, _next_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.Invalid", "error": _error_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058check_one$1260$(_seen_0, _item_0) {
  const _kind_0 = _item_0["kind"];
  const _key_0 = _item_0["key"];
  const _name_0 = _item_0["name"];
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058check_entry$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1260$(_seen_0, _kind_0, _key_0)), ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1260$(_seen_0, _kind_0, _name_0)), _kind_0, _key_0, _name_0);
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind_done$1260$(_selected_0, _item_0, _rest_0) {
  if (_selected_0) {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_a_0, _b_0) {
  if (_a_0.$ === "../../../src/ecs/schema-fragments.Component") {
    if (_b_0.$ === "../../../src/ecs/schema-fragments.Component") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../src/ecs/schema-fragments.Resource") {
    if (_b_0.$ === "../../../src/ecs/schema-fragments.Resource") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../src/ecs/schema-fragments.Event") {
    if (_b_0.$ === "../../../src/ecs/schema-fragments.Event") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../src/ecs/schema-fragments.Relation") {
    if (_b_0.$ === "../../../src/ecs/schema-fragments.Relation") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_b_0.$ === "../../../src/ecs/schema-fragments.Service") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047combined$045control$058column_text$1260$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ($List$show$1264$(_stamps_0));
    const _x_1 = ($List$show$1263$(($$$$047combined$045control$058physical$1260$(_values_0))));
    const _x_2 = ("@" + _x_0);
    return (_x_1 + _x_2);
  } else {
    return "unexpected representation";
  }
}

function $$$$047combined$045control$058column_text$1261$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ($List$show$1264$(_stamps_0));
    const _x_1 = ($List$show$1263$(($$$$047combined$045control$058physical$1261$(_values_0))));
    const _x_2 = ("@" + _x_0);
    return (_x_1 + _x_2);
  } else {
    return "unexpected representation";
  }
}

function $$$$047combined$045control$058column_text$1262$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ($List$show$1264$(_stamps_0));
    const _x_1 = ($List$show$1263$(($$$$047combined$045control$058physical$1262$(_values_0))));
    const _x_2 = ("@" + _x_0);
    return (_x_1 + _x_2);
  } else {
    return "unexpected representation";
  }
}

function $List$show$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($Bool$show$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047combined$045control$058bool_cells$(_values_0) {
  if (_values_0.length === 1) {
    const _value_0 = _values_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($$$$047combined$045control$058bool_cells$(_left_0)), ($$$$047combined$045control$058bool_cells$(_right_0)));
  }
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047constructor$045control$058cells$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $List$append$(($$$$047constructor$045control$058cells$(_left_0)), ($$$$047constructor$045control$058cells$(_right_0)));
  }
}

function $$$$047constructor$045control$058raw_0$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _owner_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  const _x_0 = ($$$$047constructor$045control$058raw_1$(_tail_0));
  const _x_1 = ($$$$047constructor$045control$058array_view$(_owner_0));
  const _x_2 = ("/" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Bool$show$(_valid_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $$$$047constructor$045control$058error_view$(_error_0) {
  if (_error_0.$ === "None") {
    return "null";
  } else {
    const _error_1 = _error_0["value"];
    return _error_1;
  }
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047constructor$045control$058error_view$(_h_0));
    const _x_1 = ($List$show$go$1262$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047constructor$045control$058list_read_join$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _owners_0 = _tail_0["fst"];
  const _texts_0 = _tail_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _owner_0, "tail": _owners_0}, "snd": {$: "Con", "head": _text_0, "tail": _texts_0}};
}

function $$$$047constructor$045control$058array_read$(_owner_0) {
  return $$$$047constructor$045control$058array_read_first$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $schema$045b$058transform$(_mode_0, _world_0) {
  if (_mode_0 === 0) {
    return _world_0;
  } else if (_mode_0 === 1) {
    return $$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0);
  } else {
    return $$$$047combined$045other$058unwind$(run_loop($$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0)));
  }
}

function $schema$045b$058delivered$(_delivery_0) {
  const _context_0 = _delivery_0["context"];
  const _t_0 = _delivery_0["result"];
  const _result_0 = _t_0["result"];
  const _error_0 = _t_0["first"];
  const _returned_0 = _t_0["returned"];
  const _prepared_0 = _delivery_0["prepared"];
  const _x_0 = ($List$show$1261$(_prepared_0));
  const _x_1 = ($$$$047combined$045other$058context_text$(_context_0));
  const _x_2 = ("|prepared=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|caller-context=" + _x_3);
  const _x_5 = (_returned_0 + _x_4);
  const _x_6 = ($schema$045b$058first$(_error_0));
  const _x_7 = ("|returned=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ($schema$045b$058outcome$(_result_0));
  const _x_10 = ("|first=" + _x_8);
  const _x_11 = (_x_9 + _x_10);
  return ("result=" + _x_11);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1265$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1265$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1265$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1265$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047production$045candidate$047schema$045b$058invoke$(_owners_0) {
  const _world_0 = _owners_0["fst"];
  const _input_0 = _owners_0["snd"];
  return $$$$047production$045candidate$047schema$045b$058finished$(($$$$047public$058provide$1264$(_input_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058required_check$1261$(_present_0, _item_0) {
  if (_present_0) {
    return {$: "../../../src/ecs/schema-fragments.Valid"};
  } else {
    const _kind_0 = _item_0["kind"];
    const _key_0 = _item_0["key"];
    const _name_0 = _item_0["name"];
    return {$: "../../../src/ecs/schema-fragments.Invalid", "error": {$: "../../../src/ecs/schema-fragments.UndeclaredDescriptor", "kind": _kind_0, "key": _key_0, "name": _name_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058descriptor_present$1261$(_xs_0, _item_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _ak_0 = _t_0["kind"];
    const _ax_0 = _t_0["key"];
    const _an_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    const _bk_0 = _item_0["kind"];
    const _bx_0 = _item_0["key"];
    const _bn_0 = _item_0["name"];
    const _x_0 = ($Bool$and$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_ak_0, _bk_0)), ($Bool$and$(($String$eq$(_ax_0, _bx_0)), ($String$eq$(_an_0, _bn_0))))));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058descriptor_present$1261$(_rest_0, {$: "../../../src/ecs/schema-fragments.Entry", "kind": _bk_0, "key": _bx_0, "name": _bn_0}));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validation_continue$1261$(_result_0, _next_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.Invalid", "error": _error_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058check_one$1261$(_seen_0, _item_0) {
  const _kind_0 = _item_0["kind"];
  const _key_0 = _item_0["key"];
  const _name_0 = _item_0["name"];
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058check_entry$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1261$(_seen_0, _kind_0, _key_0)), ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1261$(_seen_0, _kind_0, _name_0)), _kind_0, _key_0, _name_0);
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind_done$1261$(_selected_0, _item_0, _rest_0) {
  if (_selected_0) {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047combined$045other$058column_text$1260$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ($List$show$1267$(_stamps_0));
    const _x_1 = ($List$show$1266$(($$$$047combined$045other$058physical$1260$(_values_0))));
    const _x_2 = ("@" + _x_0);
    return (_x_1 + _x_2);
  } else {
    return "unexpected representation";
  }
}

function $$$$047combined$045other$058column_text$1261$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ($List$show$1267$(_stamps_0));
    const _x_1 = ($List$show$1266$(($$$$047combined$045other$058physical$1261$(_values_0))));
    const _x_2 = ("@" + _x_0);
    return (_x_1 + _x_2);
  } else {
    return "unexpected representation";
  }
}

function $$$$047combined$045other$058column_text$1262$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ($List$show$1267$(_stamps_0));
    const _x_1 = ($List$show$1266$(($$$$047combined$045other$058physical$1262$(_values_0))));
    const _x_2 = ("@" + _x_0);
    return (_x_1 + _x_2);
  } else {
    return "unexpected representation";
  }
}

function $$$$047combined$045other$058bool_cells$(_values_0) {
  if (_values_0.length === 1) {
    const _value_0 = _values_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($$$$047combined$045other$058bool_cells$(_left_0)), ($$$$047combined$045other$058bool_cells$(_right_0)));
  }
}

function $$$$047combined$045control$058unwind$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _t_1 = _t_0["installed"];
  if (_t_1.$ === "Con") {
    const _t_2 = _t_1["head"];
    const _inverse_0 = _t_2["inverse"];
    const _queued_0 = _t_2["queued"];
    const _undo_0 = _t_2["undo"];
    const _rest_0 = _t_1["tail"];
    const _quarantine_0 = _t_0["quarantine"];
    const _errors_0 = _t_0["errors"];
    const _events_0 = _world_0["events"];
    const _commands_0 = _world_0["pending"];
    const _regs_0 = _world_0["registrations"];
    const _system_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return $$$$047combined$045control$058restored$(_queued_0, _undo_0, _inverse_0({$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_0, "returned": _items_0, "installed": _rest_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}));
  } else {
    const _quarantine_1 = _t_0["quarantine"];
    const _errors_1 = _t_0["errors"];
    const _events_1 = _world_0["events"];
    const _commands_1 = _world_0["pending"];
    const _regs_1 = _world_0["registrations"];
    const _system_1 = _world_0["nextSystemId"];
    const _clock_1 = _world_0["clock"];
    return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_0, "returned": _items_0, "installed": _t_1, "quarantine": _quarantine_1, "errors": _errors_1}, "events": _events_1, "pending": _commands_1, "registrations": _regs_1, "nextSystemId": _system_1, "clock": _clock_1};
  }
}

function $schema$045a$058outcome$(_result_0) {
  if (_result_0.$ === "adapter.Accepted") {
    return "accepted";
  } else {
    const _raw_0 = _result_0["raw"];
    const _error_0 = _result_0["error"];
    const _x_0 = ($$$$047constructor$045control$058raw_0$(_raw_0));
    const _x_1 = ($schema$045a$058refusal$(_error_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return ("refused:" + _x_3);
  }
}

function $schema$045a$058first$(_first_0) {
  if (_first_0.$ === "None") {
    return "none";
  } else {
    const _error_0 = _first_0["value"];
    return $schema$045a$058refusal$(_error_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047production$045candidate$047schema$045a$058finished$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047public$058provide$1261$(_payload_0, _ctx_0) {
  return $$$$047production$045candidate$047schema$045a$058gameplay$({$: "../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047production$045candidate$047schema$045a$058request$(_x_0, _x_1);
});
})}, _payload_0, _ctx_0);
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058check_entry$(_keyConflict_0, _nameConflict_0, _kind_0, _key_0, _name_0) {
  if (_keyConflict_0) {
    return {$: "../../../src/ecs/schema-fragments.Invalid", "error": {$: "../../../src/ecs/schema-fragments.DuplicateKey", "kind": _kind_0, "key": _key_0}};
  } else {
    if (_nameConflict_0) {
      return {$: "../../../src/ecs/schema-fragments.Invalid", "error": {$: "../../../src/ecs/schema-fragments.DuplicateName", "kind": _kind_0, "name": _name_0}};
    } else {
      return {$: "../../../src/ecs/schema-fragments.Valid"};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1260$(_xs_0, _kind_0, _key_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _other_0 = _t_0["kind"];
    const _otherKey_0 = _t_0["key"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($Bool$and$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_key_0, _otherKey_0))));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1260$(_rest_0, _kind_0, _key_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1260$(_xs_0, _kind_0, _name_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _other_0 = _t_0["kind"];
    const _otherName_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($Bool$and$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_name_0, _otherName_0))));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1260$(_rest_0, _kind_0, _name_0));
    return (_x_0 || _x_1);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047combined$045control$058text_identity$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047combined$045control$058physical$1260$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return {$: "Con", "head": ($$$$047combined$045control$058maybe_text$1260$(_owner_0)), "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($$$$047combined$045control$058physical$1260$(_left_0)), ($$$$047combined$045control$058physical$1260$(_right_0)));
  }
}

function $List$show$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047combined$045control$058stamp_text$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047combined$045control$058physical$1261$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return {$: "Con", "head": ($$$$047combined$045control$058maybe_text$1261$(_owner_0)), "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($$$$047combined$045control$058physical$1261$(_left_0)), ($$$$047combined$045control$058physical$1261$(_right_0)));
  }
}

function $$$$047combined$045control$058physical$1262$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return {$: "Con", "head": ($$$$047combined$045control$058maybe_text$1262$(_owner_0)), "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($$$$047combined$045control$058physical$1262$(_left_0)), ($$$$047combined$045control$058physical$1262$(_right_0)));
  }
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $List$show$go$1265$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($Bool$show$(_h_0));
    const _x_1 = ($List$show$go$1265$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047constructor$045control$058array_view$(_owner_0) {
  return $List$show$1260$(($$$$047constructor$045control$058cells$(_owner_0)));
}

function $$$$047constructor$045control$058raw_1$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _owner_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  const _x_0 = ($$$$047constructor$045control$058raw_2$(_tail_0));
  const _x_1 = ($U32$show$(_owner_0));
  const _x_2 = ("/" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Bool$show$(_valid_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047constructor$045control$058array_read_first$(_seen_0) {
  const _owner_0 = _seen_0["fst"];
  const _first_0 = _seen_0["snd"];
  return $$$$047constructor$045control$058array_read_second$(_first_0, {$: "Tuple", fst: _owner_0, snd: _owner_0[1 % _owner_0.length]});
}

function $$$$047combined$045other$058unwind$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _t_1 = _t_0["installed"];
  if (_t_1.$ === "Con") {
    const _t_2 = _t_1["head"];
    const _inverse_0 = _t_2["inverse"];
    const _queued_0 = _t_2["queued"];
    const _undo_0 = _t_2["undo"];
    const _rest_0 = _t_1["tail"];
    const _quarantine_0 = _t_0["quarantine"];
    const _errors_0 = _t_0["errors"];
    const _events_0 = _world_0["events"];
    const _commands_0 = _world_0["pending"];
    const _regs_0 = _world_0["registrations"];
    const _system_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return $$$$047combined$045other$058restored$(_queued_0, _undo_0, _inverse_0({$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_0, "returned": _items_0, "installed": _rest_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}));
  } else {
    const _quarantine_1 = _t_0["quarantine"];
    const _errors_1 = _t_0["errors"];
    const _events_1 = _world_0["events"];
    const _commands_1 = _world_0["pending"];
    const _regs_1 = _world_0["registrations"];
    const _system_1 = _world_0["nextSystemId"];
    const _clock_1 = _world_0["clock"];
    return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_0, "returned": _items_0, "installed": _t_1, "quarantine": _quarantine_1, "errors": _errors_1}, "events": _events_1, "pending": _commands_1, "registrations": _regs_1, "nextSystemId": _system_1, "clock": _clock_1};
  }
}

function $schema$045b$058outcome$(_result_0) {
  if (_result_0.$ === "adapter.Accepted") {
    return "accepted";
  } else {
    const _raw_0 = _result_0["raw"];
    const _error_0 = _result_0["error"];
    const _x_0 = ($$$$047constructor$045control$058raw_0$(_raw_0));
    const _x_1 = ($schema$045b$058refusal$(_error_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    return ("refused:" + _x_3);
  }
}

function $schema$045b$058first$(_first_0) {
  if (_first_0.$ === "None") {
    return "none";
  } else {
    const _error_0 = _first_0["value"];
    return $schema$045b$058refusal$(_error_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1265$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1265$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1265$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047production$045candidate$047schema$045b$058finished$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047public$058provide$1264$(_payload_0, _ctx_0) {
  return $$$$047production$045candidate$047schema$045b$058gameplay$({$: "../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047production$045candidate$047schema$045b$058request$(_x_0, _x_1);
});
})}, _payload_0, _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1261$(_xs_0, _kind_0, _key_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _other_0 = _t_0["kind"];
    const _otherKey_0 = _t_0["key"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($Bool$and$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_key_0, _otherKey_0))));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1261$(_rest_0, _kind_0, _key_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1261$(_xs_0, _kind_0, _name_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _other_0 = _t_0["kind"];
    const _otherName_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($Bool$and$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_name_0, _otherName_0))));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1261$(_rest_0, _kind_0, _name_0));
    return (_x_0 || _x_1);
  }
}

function $List$show$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047combined$045other$058text_identity$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047combined$045other$058physical$1260$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return {$: "Con", "head": ($$$$047combined$045other$058maybe_text$1260$(_owner_0)), "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($$$$047combined$045other$058physical$1260$(_left_0)), ($$$$047combined$045other$058physical$1260$(_right_0)));
  }
}

function $List$show$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047combined$045other$058stamp_text$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $$$$047combined$045other$058physical$1261$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return {$: "Con", "head": ($$$$047combined$045other$058maybe_text$1261$(_owner_0)), "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($$$$047combined$045other$058physical$1261$(_left_0)), ($$$$047combined$045other$058physical$1261$(_right_0)));
  }
}

function $$$$047combined$045other$058physical$1262$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return {$: "Con", "head": ($$$$047combined$045other$058maybe_text$1262$(_owner_0)), "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($$$$047combined$045other$058physical$1262$(_left_0)), ($$$$047combined$045other$058physical$1262$(_right_0)));
  }
}

function $$$$047combined$045control$058restored$(_queued_0, _undo_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _pack_0 = _result_0["payload"];
    return $$$$047combined$045control$058returned$(_world_0, ($$$$047combined$045control$058rebuild$(_pack_0, _queued_0, _undo_0)), "unwound");
  } else {
    const _world_1 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    return $$$$047combined$045control$058quarantined$(_world_1, _recovery_0, _queued_0, _undo_0);
  }
}

function $schema$045a$058refusal$(_error_0) {
  if (_error_0.$ === "adapter.EntityRefused") {
    const _error_1 = _error_0["error"];
    return $schema$045a$058world_error$(_error_1);
  } else if (_error_0.$ === "adapter.ConstructionRefused") {
    const _positions_0 = _error_0["positions"];
    const _x_0 = ($List$show$1262$(_positions_0));
    return ("ConstructionRefused:" + _x_0);
  } else {
    const _error_2 = _error_0["error"];
    return $schema$045a$058declaration_error$(_error_2);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047production$045candidate$047schema$045a$058gameplay$(_cap_0, _input_0, _ctx_0) {
  return $$$$047production$045candidate$047schema$045a$058done$(run_loop($$$$047public$058apply$(_cap_0, _input_0, _ctx_0)));
}

function $$$$047production$045candidate$047schema$045a$058request$(_world_0, _input_0) {
  return $$$$047production$045candidate$047schema$045a$058observation$(($$$$047production$045candidate$047schema$045a$058requested$(_world_0, _input_0)));
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $$$$047combined$045control$058text_identity$(_text_0) {
  return _text_0;
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047combined$045control$058text_identity$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047combined$045control$058maybe_text$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return "absent";
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047combined$045control$058array_text$(_owner_1);
  }
}

function $$$$047combined$045control$058stamp_text$(_stamp_0) {
  const _id_0 = _stamp_0["id"];
  const _t_0 = _stamp_0["stamp"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _x_0 = ($U32$show$(_changed_0));
  const _x_1 = ($U32$show$(_added_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1264$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047combined$045control$058stamp_text$(_h_0));
    const _x_1 = ($List$show$go$1264$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047combined$045control$058maybe_text$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return "absent";
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047combined$045control$058tag_text$(_owner_1);
  }
}

function $$$$047combined$045control$058maybe_text$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return "absent";
  } else {
    const _owner_1 = _owner_0["value"];
    return $U32$show$(_owner_1);
  }
}

function $$$$047constructor$045control$058raw_2$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _owner_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  const _x_0 = ($$$$047constructor$045control$058raw_3$(_tail_0));
  const _x_1 = ($$$$047constructor$045control$058tag_view$(_owner_0));
  const _x_2 = ("/" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Bool$show$(_valid_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $$$$047constructor$045control$058array_read_second$(_first_0, _seen_0) {
  const _owner_0 = _seen_0["fst"];
  const _second_0 = _seen_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($List$show$1260$({$: "Con", "head": _first_0, "tail": {$: "Con", "head": _second_0, "tail": {$: "Nil"}}}))};
}

function $$$$047combined$045other$058restored$(_queued_0, _undo_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _pack_0 = _result_0["payload"];
    return $$$$047combined$045other$058returned$(_world_0, ($$$$047combined$045other$058rebuild$(_pack_0, _queued_0, _undo_0)), "unwound");
  } else {
    const _world_1 = _result_0["world"];
    const _recovery_0 = _result_0["recovery"];
    return $$$$047combined$045other$058quarantined$(_world_1, _recovery_0, _queued_0, _undo_0);
  }
}

function $schema$045b$058refusal$(_error_0) {
  if (_error_0.$ === "adapter.EntityRefused") {
    const _error_1 = _error_0["error"];
    return $schema$045b$058world_error$(_error_1);
  } else if (_error_0.$ === "adapter.ConstructionRefused") {
    const _positions_0 = _error_0["positions"];
    const _x_0 = ($List$show$1262$(_positions_0));
    return ("ConstructionRefused:" + _x_0);
  } else {
    const _error_2 = _error_0["error"];
    return $schema$045b$058declaration_error$(_error_2);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1265$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1265$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047production$045candidate$047schema$045b$058gameplay$(_cap_0, _input_0, _ctx_0) {
  return $$$$047production$045candidate$047schema$045b$058done$(run_loop($$$$047public$058apply$(_cap_0, _input_0, _ctx_0)));
}

function $$$$047production$045candidate$047schema$045b$058request$(_world_0, _input_0) {
  return $$$$047production$045candidate$047schema$045b$058observation$(($$$$047production$045candidate$047schema$045b$058requested$(_world_0, _input_0)));
}

function $$$$047combined$045other$058text_identity$(_text_0) {
  return _text_0;
}

function $List$show$go$1266$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047combined$045other$058text_identity$(_h_0));
    const _x_1 = ($List$show$go$1266$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047combined$045other$058maybe_text$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return "absent";
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047combined$045other$058array_text$(_owner_1);
  }
}

function $$$$047combined$045other$058stamp_text$(_stamp_0) {
  const _id_0 = _stamp_0["id"];
  const _t_0 = _stamp_0["stamp"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _x_0 = ($U32$show$(_changed_0));
  const _x_1 = ($U32$show$(_added_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1267$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($$$$047combined$045other$058stamp_text$(_h_0));
    const _x_1 = ($List$show$go$1267$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $$$$047combined$045other$058maybe_text$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return "absent";
  } else {
    const _owner_1 = _owner_0["value"];
    return $$$$047combined$045other$058tag_text$(_owner_1);
  }
}

function $$$$047combined$045other$058maybe_text$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return "absent";
  } else {
    const _owner_1 = _owner_0["value"];
    return $U32$show$(_owner_1);
  }
}

function $$$$047combined$045control$058rebuild$(_pack_0, _queued_0, _undo_0) {
  const _t_0 = _pack_0["head"];
  const __0 = _t_0["handle"];
  const _t_1 = _t_0["owner"];
  if (_t_1.$ === "Some") {
    const _a_0 = _t_1["value"];
    const _t_2 = _pack_0["tail"];
    const _t_3 = _t_2["head"];
    const __1 = _t_3["handle"];
    const _t_4 = _t_3["owner"];
    if (_t_4.$ === "Some") {
      const _front_0 = _t_4["value"];
      const _t_5 = _t_2["tail"];
      const _t_6 = _t_5["head"];
      const __2 = _t_6["handle"];
      const _t_7 = _t_6["owner"];
      if (_t_7.$ === "Some") {
        const _back_0 = _t_7["value"];
        const _t_8 = _t_5["tail"];
        const _t_9 = _t_8["head"];
        const __3 = _t_9["handle"];
        const _t_10 = _t_9["owner"];
        if (_t_10.$ === "Some") {
          const _tag_0 = _t_10["value"];
          const _t_11 = _t_8["tail"];
          const _t_12 = _t_11["head"];
          const __4 = _t_12["handle"];
          const _t_13 = _t_12["owner"];
          if (_t_13.$ === "Some") {
            const _value_0 = _t_13["value"];
            const _t_14 = _t_11["tail"];
            return {$: "../combined-control.Original", "raw": _undo_0({$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _a_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _value_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _tag_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": {$: "../constructor-control.QueueOwner", "front": _front_0, "back": _back_0, "queued": _queued_0}}, "tail": {$: "Unit"}}}}})};
          } else {
            const _63_0 = _t_11["tail"];
            return {$: "../combined-control.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __1, "owner": {$: "Some", "value": _front_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __2, "owner": {$: "Some", "value": _back_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __3, "owner": {$: "Some", "value": _tag_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __4, "owner": _t_13}, "tail": _63_0}}}}}, "queued": _queued_0, "undo": _undo_0};
          }
        } else {
          const _60_0 = _t_8["tail"];
          return {$: "../combined-control.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __1, "owner": {$: "Some", "value": _front_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __2, "owner": {$: "Some", "value": _back_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __3, "owner": _t_10}, "tail": _60_0}}}}, "queued": _queued_0, "undo": _undo_0};
        }
      } else {
        const _57_0 = _t_5["tail"];
        return {$: "../combined-control.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __1, "owner": {$: "Some", "value": _front_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __2, "owner": _t_7}, "tail": _57_0}}}, "queued": _queued_0, "undo": _undo_0};
      }
    } else {
      const _54_0 = _t_2["tail"];
      return {$: "../combined-control.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __1, "owner": _t_4}, "tail": _54_0}}, "queued": _queued_0, "undo": _undo_0};
    }
  } else {
    const _51_0 = _pack_0["tail"];
    return {$: "../combined-control.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": _t_1}, "tail": _51_0}, "queued": _queued_0, "undo": _undo_0};
  }
}

function $$$$047combined$045control$058quarantined$(_world_0, _recovery_0, _queued_0, _undo_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _pending_0 = _t_0["quarantine"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_0, "returned": _items_0, "installed": _installed_0, "quarantine": {$: "Con", "head": {$: "../combined-control.Quarantine", "recovery": _recovery_0, "queued": _queued_0, "undo": _undo_0}, "tail": _pending_0}, "errors": {$: "Con", "head": {$: "Some", "value": "quarantined"}, "tail": {$: "Nil"}}}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $schema$045a$058world_error$(_error_0) {
  if (_error_0.$ === "../../../src/ecs/world.MissingEntity") {
    return "MissingEntity";
  } else if (_error_0.$ === "../../../src/ecs/world.CapacityExceeded") {
    return "CapacityExceeded";
  } else if (_error_0.$ === "../../../src/ecs/world.NamespaceExhausted") {
    return "NamespaceExhausted";
  } else {
    return "SystemIdExhausted";
  }
}

function $schema$045a$058declaration_error$(_error_0) {
  if (_error_0.$ === "../../../src/ecs/schema-fragments.UndeclaredDescriptor") {
    const _k_0 = _error_0["kind"];
    const _key_0 = _error_0["key"];
    const _name_0 = _error_0["name"];
    const _x_0 = (":" + _name_0);
    const _x_1 = (_key_0 + _x_0);
    const _x_2 = ($schema$045a$058kind$(_k_0));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("UndeclaredDescriptor:" + _x_4);
  } else if (_error_0.$ === "../../../src/ecs/schema-fragments.DuplicateKey") {
    const _k_1 = _error_0["kind"];
    const _key_1 = _error_0["key"];
    const _x_5 = ($schema$045a$058kind$(_k_1));
    const _x_6 = (":" + _key_1);
    const _x_7 = (_x_5 + _x_6);
    return ("DuplicateKey:" + _x_7);
  } else {
    const _k_2 = _error_0["kind"];
    const _name_1 = _error_0["name"];
    const _x_8 = ($schema$045a$058kind$(_k_2));
    const _x_9 = (":" + _name_1);
    const _x_10 = (_x_8 + _x_9);
    return ("DuplicateName:" + _x_10);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1262$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047production$045candidate$047schema$045a$058done$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Unit"}};
}

function $$$$047public$058apply$(_cap_0, _payload_0, _ctx_0) {
  const _run_0 = _cap_0["run"];
  return run_tail(_run_0(_ctx_0), _payload_0);
}

function $$$$047production$045candidate$047schema$045a$058observation$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_0, "returned": _items_0, "installed": _installed_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, "snd": {$: "../production-candidate/schema-a.Observation", "errors": _errors_0}};
}

function $$$$047production$045candidate$047schema$045a$058requested$(_world_0, _input_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _operation_0 = _input_0["operation"];
  const _raw_0 = _input_0["raw"];
  return $$$$047production$045candidate$047schema$045a$058staged$(_operation_0, {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": ($$$$047constructor$045control$058context$()), "returned": _items_0, "installed": _installed_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, ($$$$047constructor$045control$058stage_0$(_context_0, _raw_0)));
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047combined$045control$058array_text$(_owner_0) {
  return $List$show$1260$(($$$$047combined$045control$058array_cells$(_owner_0)));
}

function $$$$047combined$045control$058tag_text$(_tag_0) {
  return "tag";
}

function $$$$047constructor$045control$058tag_view$(_owner_0) {
  return "tag";
}

function $$$$047constructor$045control$058raw_3$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _owner_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  const _x_0 = ($$$$047constructor$045control$058raw_4$(_tail_0));
  const _x_1 = ($$$$047constructor$045control$058queue_view$(_owner_0));
  const _x_2 = ("/" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Bool$show$(_valid_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $$$$047combined$045other$058rebuild$(_pack_0, _queued_0, _undo_0) {
  const _t_0 = _pack_0["head"];
  const __0 = _t_0["handle"];
  const _t_1 = _t_0["owner"];
  if (_t_1.$ === "Some") {
    const _a_0 = _t_1["value"];
    const _t_2 = _pack_0["tail"];
    const _t_3 = _t_2["head"];
    const __1 = _t_3["handle"];
    const _t_4 = _t_3["owner"];
    if (_t_4.$ === "Some") {
      const _front_0 = _t_4["value"];
      const _t_5 = _t_2["tail"];
      const _t_6 = _t_5["head"];
      const __2 = _t_6["handle"];
      const _t_7 = _t_6["owner"];
      if (_t_7.$ === "Some") {
        const _back_0 = _t_7["value"];
        const _t_8 = _t_5["tail"];
        const _t_9 = _t_8["head"];
        const __3 = _t_9["handle"];
        const _t_10 = _t_9["owner"];
        if (_t_10.$ === "Some") {
          const _tag_0 = _t_10["value"];
          const _t_11 = _t_8["tail"];
          const _t_12 = _t_11["head"];
          const __4 = _t_12["handle"];
          const _t_13 = _t_12["owner"];
          if (_t_13.$ === "Some") {
            const _value_0 = _t_13["value"];
            const _t_14 = _t_11["tail"];
            return {$: "../combined-other.Original", "raw": _undo_0({$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _a_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _value_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _tag_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": {$: "../constructor-control.QueueOwner", "front": _front_0, "back": _back_0, "queued": _queued_0}}, "tail": {$: "Unit"}}}}})};
          } else {
            const _63_0 = _t_11["tail"];
            return {$: "../combined-other.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __1, "owner": {$: "Some", "value": _front_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __2, "owner": {$: "Some", "value": _back_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __3, "owner": {$: "Some", "value": _tag_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __4, "owner": _t_13}, "tail": _63_0}}}}}, "queued": _queued_0, "undo": _undo_0};
          }
        } else {
          const _60_0 = _t_8["tail"];
          return {$: "../combined-other.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __1, "owner": {$: "Some", "value": _front_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __2, "owner": {$: "Some", "value": _back_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __3, "owner": _t_10}, "tail": _60_0}}}}, "queued": _queued_0, "undo": _undo_0};
        }
      } else {
        const _57_0 = _t_5["tail"];
        return {$: "../combined-other.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __1, "owner": {$: "Some", "value": _front_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __2, "owner": _t_7}, "tail": _57_0}}}, "queued": _queued_0, "undo": _undo_0};
      }
    } else {
      const _54_0 = _t_2["tail"];
      return {$: "../combined-other.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __1, "owner": _t_4}, "tail": _54_0}}, "queued": _queued_0, "undo": _undo_0};
    }
  } else {
    const _51_0 = _pack_0["tail"];
    return {$: "../combined-other.Unassembled", "pack": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": __0, "owner": _t_1}, "tail": _51_0}, "queued": _queued_0, "undo": _undo_0};
  }
}

function $$$$047combined$045other$058quarantined$(_world_0, _recovery_0, _queued_0, _undo_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _pending_0 = _t_0["quarantine"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_0, "returned": _items_0, "installed": _installed_0, "quarantine": {$: "Con", "head": {$: "../combined-other.Quarantine", "recovery": _recovery_0, "queued": _queued_0, "undo": _undo_0}, "tail": _pending_0}, "errors": {$: "Con", "head": {$: "Some", "value": "quarantined"}, "tail": {$: "Nil"}}}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $schema$045b$058world_error$(_error_0) {
  if (_error_0.$ === "../../../src/ecs/world.MissingEntity") {
    return "MissingEntity";
  } else if (_error_0.$ === "../../../src/ecs/world.CapacityExceeded") {
    return "CapacityExceeded";
  } else if (_error_0.$ === "../../../src/ecs/world.NamespaceExhausted") {
    return "NamespaceExhausted";
  } else {
    return "SystemIdExhausted";
  }
}

function $schema$045b$058declaration_error$(_error_0) {
  if (_error_0.$ === "../../../src/ecs/schema-fragments.UndeclaredDescriptor") {
    const _k_0 = _error_0["kind"];
    const _key_0 = _error_0["key"];
    const _name_0 = _error_0["name"];
    const _x_0 = (":" + _name_0);
    const _x_1 = (_key_0 + _x_0);
    const _x_2 = ($schema$045b$058kind$(_k_0));
    const _x_3 = (":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("UndeclaredDescriptor:" + _x_4);
  } else if (_error_0.$ === "../../../src/ecs/schema-fragments.DuplicateKey") {
    const _k_1 = _error_0["kind"];
    const _key_1 = _error_0["key"];
    const _x_5 = ($schema$045b$058kind$(_k_1));
    const _x_6 = (":" + _key_1);
    const _x_7 = (_x_5 + _x_6);
    return ("DuplicateKey:" + _x_7);
  } else {
    const _k_2 = _error_0["kind"];
    const _name_1 = _error_0["name"];
    const _x_8 = ($schema$045b$058kind$(_k_2));
    const _x_9 = (":" + _name_1);
    const _x_10 = (_x_8 + _x_9);
    return ("DuplicateName:" + _x_10);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1265$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047production$045candidate$047schema$045b$058done$(_observed_0) {
  const _ctx_0 = _observed_0["fst"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "Unit"}};
}

function $$$$047production$045candidate$047schema$045b$058observation$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_0, "returned": _items_0, "installed": _installed_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, "snd": {$: "../production-candidate/schema-b.Observation", "errors": _errors_0}};
}

function $$$$047production$045candidate$047schema$045b$058requested$(_world_0, _input_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _operation_0 = _input_0["operation"];
  const _raw_0 = _input_0["raw"];
  return $$$$047production$045candidate$047schema$045b$058staged$(_operation_0, {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": ($$$$047constructor$045control$058context$()), "returned": _items_0, "installed": _installed_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, ($$$$047constructor$045control$058stage_0$(_context_0, _raw_0)));
}

function $$$$047combined$045other$058array_text$(_owner_0) {
  return $List$show$1260$(($$$$047combined$045other$058array_cells$(_owner_0)));
}

function $$$$047combined$045other$058tag_text$(_tag_0) {
  return "tag";
}

function $schema$045a$058kind$(_kind_0) {
  if (_kind_0.$ === "../../../src/ecs/schema-fragments.Component") {
    return "component";
  } else if (_kind_0.$ === "../../../src/ecs/schema-fragments.Resource") {
    return "resource";
  } else if (_kind_0.$ === "../../../src/ecs/schema-fragments.Event") {
    return "event";
  } else if (_kind_0.$ === "../../../src/ecs/schema-fragments.Relation") {
    return "relation";
  } else {
    return "service";
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047production$045candidate$047schema$045a$058staged$(_operation_0, _world_0, _observed_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  if (_observed_0.$ === "../constructor-stage.Failed") {
    const _context_0 = _observed_0["context"];
    const _raw_0 = _observed_0["raw"];
    const _errors_0 = _observed_0["positions"];
    return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_0, "returned": {$: "Con", "head": {$: "../combined-control.Original", "raw": _raw_0}, "tail": _items_0}, "installed": _installed_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
  } else {
    const _context_1 = _observed_0["context"];
    const _cooked_0 = _observed_0["cooked"];
    const _inverse_0 = _observed_0["undo"];
    const _errors_1 = _observed_0["positions"];
    return $$$$047production$045candidate$047schema$045a$058dispatch$(_operation_0, {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_1, "returned": _items_0, "installed": _installed_0, "quarantine": _quarantine_0, "errors": _errors_1}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, {$: "../combined-control.Packet", "cooked": _cooked_0, "undo": _inverse_0});
  }
}

function $$$$047constructor$045control$058stage_0$(_ctx_0, _raw_0) {
  return $$$$047constructor$045stage$058stage$1263$(_ctx_0, _raw_0);
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047combined$045control$058array_cells$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $List$append$(($$$$047combined$045control$058array_cells$(_left_0)), ($$$$047combined$045control$058array_cells$(_right_0)));
  }
}

function $$$$047constructor$045control$058queue_view$(_owner_0) {
  const _front_0 = _owner_0["front"];
  const _back_0 = _owner_0["back"];
  const _queued_0 = _owner_0["queued"];
  const _x_0 = ($List$show$1261$(($$$$047constructor$045control$058queue_items$(_queued_0))));
  const _x_1 = ($$$$047constructor$045control$058array_view$(_back_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($$$$047constructor$045control$058array_view$(_front_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $$$$047constructor$045control$058raw_4$(_raw_0) {
  return "end";
}

function $schema$045b$058kind$(_kind_0) {
  if (_kind_0.$ === "../../../src/ecs/schema-fragments.Component") {
    return "component";
  } else if (_kind_0.$ === "../../../src/ecs/schema-fragments.Resource") {
    return "resource";
  } else if (_kind_0.$ === "../../../src/ecs/schema-fragments.Event") {
    return "event";
  } else if (_kind_0.$ === "../../../src/ecs/schema-fragments.Relation") {
    return "relation";
  } else {
    return "service";
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1265$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047production$045candidate$047schema$045b$058staged$(_operation_0, _world_0, _observed_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  if (_observed_0.$ === "../constructor-stage.Failed") {
    const _context_0 = _observed_0["context"];
    const _raw_0 = _observed_0["raw"];
    const _errors_0 = _observed_0["positions"];
    return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_0, "returned": {$: "Con", "head": {$: "../combined-other.Original", "raw": _raw_0}, "tail": _items_0}, "installed": _installed_0, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
  } else {
    const _context_1 = _observed_0["context"];
    const _cooked_0 = _observed_0["cooked"];
    const _inverse_0 = _observed_0["undo"];
    const _errors_1 = _observed_0["positions"];
    return $$$$047production$045candidate$047schema$045b$058dispatch$(_operation_0, {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_1, "returned": _items_0, "installed": _installed_0, "quarantine": _quarantine_0, "errors": _errors_1}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, {$: "../combined-other.Packet", "cooked": _cooked_0, "undo": _inverse_0});
  }
}

function $$$$047combined$045other$058array_cells$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $List$append$(($$$$047combined$045other$058array_cells$(_left_0)), ($$$$047combined$045other$058array_cells$(_right_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, ($schema$045a$058runner$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047production$045candidate$047schema$045a$058dispatch$(_operation_0, _world_0, _packet_0) {
  if (_operation_0.$ === "../production-candidate/schema-a.PendingSpawn") {
    return $$$$047production$045candidate$047schema$045a$058pending_reserved$(_packet_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), {$: "Unit"})));
  } else if (_operation_0.$ === "../production-candidate/schema-a.Spawn") {
    return $$$$047production$045candidate$047schema$045a$058spawn_result$(($$$$047fallible$045spawn$058spawn$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), _packet_0)));
  } else {
    const _target_0 = _operation_0["target"];
    return $$$$047production$045candidate$047schema$045a$058inserted$(($$$$047queue$058enqueue$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), _target_0, _packet_0)));
  }
}

function $$$$047constructor$045stage$058stage$1263$(_ctx_0, _raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047constructor$045stage$058constructed_head$1263$(_tail_0, ($$$$047constructor$045control$058constructor_0$(_ctx_0, _head_0)));
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $$$$047constructor$045control$058queue_items$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _items_0["head"];
    const _tail_0 = _items_0["tail"];
    return {$: "Con", "head": ($$$$047constructor$045control$058array_view$(_head_0)), "tail": ($$$$047constructor$045control$058queue_items$(_tail_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1265$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1265$(_registry_0, ($schema$045b$058runner$(_world_0, _args_0)));
  }
}

function $$$$047production$045candidate$047schema$045b$058dispatch$(_operation_0, _world_0, _packet_0) {
  if (_operation_0.$ === "../production-candidate/schema-b.PendingSpawn") {
    return $$$$047production$045candidate$047schema$045b$058pending_reserved$(_packet_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1262$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), {$: "Unit"})));
  } else if (_operation_0.$ === "../production-candidate/schema-b.Spawn") {
    return $$$$047production$045candidate$047schema$045b$058spawn_result$(($$$$047fallible$045spawn$058spawn$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), _packet_0)));
  } else {
    const _target_0 = _operation_0["target"];
    return $$$$047production$045candidate$047schema$045b$058inserted$(($$$$047queue$058enqueue$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), _target_0, _packet_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $schema$045a$058runner$(_world_0, _args_0) {
  return $schema$045a$058invoked$(($schema$045a$058invoke$({$: "adapter.Owner", "batch": ($$$$047production$045candidate$047transactions$047schema$045a$058begin$(_world_0)), "context": ($$$$047constructor$045control$058context$())}, _args_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047production$045candidate$047schema$045a$058pending_reserved$(_packet_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _observed_0["snd"];
  if (_t_1.$ === "../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_1["handle"];
    return $$$$047production$045candidate$047schema$045a$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(($$$$047prototype$058enqueue$1260$({$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _handle_0, _packet_0)), {$: "../../../src/ecs/transaction.Success"})));
  } else {
    const _error_0 = _t_1["error"];
    return $$$$047production$045candidate$047schema$045a$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$({$: "../../../src/ecs/transaction.Tx", "world": ($$$$047production$045candidate$047schema$045a$058recover$(_world_0, _packet_0, _error_0)), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../src/ecs/transaction.Success"})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047production$045candidate$047schema$045a$058spawn_result$(_observed_0) {
  if (_observed_0.$ === "../prototype.SpawnQueued") {
    const _tx_0 = _observed_0["tx"];
    return $$$$047production$045candidate$047schema$045a$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../src/ecs/transaction.Success"})));
  } else {
    const _t_0 = _observed_0["tx"];
    const _world_0 = _t_0["world"];
    const _undo_0 = _t_0["undo"];
    const _commands_0 = _t_0["commands"];
    const _events_0 = _t_0["events"];
    const _t_1 = _observed_0["payload"];
    const _cooked_0 = _t_1["cooked"];
    const _inverse_0 = _t_1["undo"];
    return $$$$047production$045candidate$047schema$045a$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$({$: "../../../src/ecs/transaction.Tx", "world": ($$$$047combined$045control$058returned$(_world_0, {$: "../combined-control.Original", "raw": _inverse_0(_cooked_0)}, "reserve-refusal")), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../src/ecs/transaction.Success"})));
  }
}

function $$$$047fallible$045spawn$058spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047fallible$045spawn$058reserved$1260$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047production$045candidate$047schema$045a$058inserted$(_observed_0) {
  if (_observed_0.$ === "../queue.Queued") {
    const _tx_0 = _observed_0["tx"];
    return $$$$047production$045candidate$047schema$045a$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../src/ecs/transaction.Success"})));
  } else {
    const _t_0 = _observed_0["tx"];
    const _world_0 = _t_0["world"];
    const _undo_0 = _t_0["undo"];
    const _commands_0 = _t_0["commands"];
    const _events_0 = _t_0["events"];
    const _packet_0 = _observed_0["payload"];
    const _error_0 = _observed_0["error"];
    return $$$$047production$045candidate$047schema$045a$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$({$: "../../../src/ecs/transaction.Tx", "world": ($$$$047production$045candidate$047schema$045a$058recover$(_world_0, _packet_0, _error_0)), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../src/ecs/transaction.Success"})));
  }
}

function $$$$047queue$058enqueue$1260$(_tx_0, _handle_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047queue$058checked$1260$(_undo_0, _commands_0, _events_0, _handle_0, _payload_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)));
}

function $$$$047constructor$045stage$058constructed_head$1263$(_tail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../constructor-stage.Constructed") {
    const _head_0 = _t_0["cooked"];
    const _undo_0 = _t_0["undo"];
    return $$$$047constructor$045stage$058constructed_tail$1263$(_head_0, _undo_0, ($$$$047constructor$045control$058stage_1$(_ctx_0, _tail_0)));
  } else {
    const _head_1 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $$$$047constructor$045stage$058invalid_tail$1263$(_head_1, _error_0, ($$$$047constructor$045control$058stage_1$(_ctx_0, _tail_0)));
  }
}

function $$$$047constructor$045control$058constructor_0$(_ctx_0, _raw_0) {
  return $$$$047constructor$045control$058array_construct$(_ctx_0, _raw_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1265$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $schema$045b$058runner$(_world_0, _args_0) {
  return $schema$045b$058invoked$(($schema$045b$058invoke$({$: "adapter.Owner", "batch": ($$$$047production$045candidate$047transactions$047schema$045b$058begin$(_world_0)), "context": ($$$$047constructor$045control$058context$())}, _args_0)));
}

function $$$$047production$045candidate$047schema$045b$058pending_reserved$(_packet_0, _observed_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _observed_0["snd"];
  if (_t_1.$ === "../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_1["handle"];
    return $$$$047production$045candidate$047schema$045b$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(($$$$047prototype$058enqueue$1261$({$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _handle_0, _packet_0)), {$: "../../../src/ecs/transaction.Success"})));
  } else {
    const _error_0 = _t_1["error"];
    return $$$$047production$045candidate$047schema$045b$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$({$: "../../../src/ecs/transaction.Tx", "world": ($$$$047production$045candidate$047schema$045b$058recover$(_world_0, _packet_0, _error_0)), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../src/ecs/transaction.Success"})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_spawn$1262$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1262$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047production$045candidate$047schema$045b$058spawn_result$(_observed_0) {
  if (_observed_0.$ === "../prototype.SpawnQueued") {
    const _tx_0 = _observed_0["tx"];
    return $$$$047production$045candidate$047schema$045b$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../../src/ecs/transaction.Success"})));
  } else {
    const _t_0 = _observed_0["tx"];
    const _world_0 = _t_0["world"];
    const _undo_0 = _t_0["undo"];
    const _commands_0 = _t_0["commands"];
    const _events_0 = _t_0["events"];
    const _t_1 = _observed_0["payload"];
    const _cooked_0 = _t_1["cooked"];
    const _inverse_0 = _t_1["undo"];
    return $$$$047production$045candidate$047schema$045b$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$({$: "../../../src/ecs/transaction.Tx", "world": ($$$$047combined$045other$058returned$(_world_0, {$: "../combined-other.Original", "raw": _inverse_0(_cooked_0)}, "reserve-refusal")), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../src/ecs/transaction.Success"})));
  }
}

function $$$$047fallible$045spawn$058spawn$1261$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047fallible$045spawn$058reserved$1261$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047production$045candidate$047schema$045b$058inserted$(_observed_0) {
  if (_observed_0.$ === "../queue.Queued") {
    const _tx_0 = _observed_0["tx"];
    return $$$$047production$045candidate$047schema$045b$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../../src/ecs/transaction.Success"})));
  } else {
    const _t_0 = _observed_0["tx"];
    const _world_0 = _t_0["world"];
    const _undo_0 = _t_0["undo"];
    const _commands_0 = _t_0["commands"];
    const _events_0 = _t_0["events"];
    const _packet_0 = _observed_0["payload"];
    const _error_0 = _observed_0["error"];
    return $$$$047production$045candidate$047schema$045b$058commit$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$({$: "../../../src/ecs/transaction.Tx", "world": ($$$$047production$045candidate$047schema$045b$058recover$(_world_0, _packet_0, _error_0)), "undo": _undo_0, "commands": _commands_0, "events": _events_0}, {$: "../../../src/ecs/transaction.Success"})));
  }
}

function $$$$047queue$058enqueue$1261$(_tx_0, _handle_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047queue$058checked$1261$(_undo_0, _commands_0, _events_0, _handle_0, _payload_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)));
}

function $schema$045a$058invoked$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _context_0 = _t_0["context"];
  const _output_0 = _result_0["snd"];
  return $schema$045a$058prepared_finish$(_tx_0, _context_0, _output_0, ($schema$045a$058prepared_read$(_prepared_0)));
}

function $schema$045a$058invoke$(_owner_0, _args_0) {
  const _input_0 = _args_0["input"];
  const _target_0 = _args_0["retryTarget"];
  const _retry_0 = _args_0["retry"];
  const _declared_0 = _args_0["declared"];
  return $schema$045a$058invoked_declaration$(_owner_0, {$: "schema-a.Args", "input": _input_0, "retryTarget": _target_0, "retry": _retry_0, "declared": _declared_0}, _declared_0);
}

function $$$$047production$045candidate$047transactions$047schema$045a$058begin$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047production$045candidate$047transactions$047schema$045a$058journaled$(($$$$047$$$047$$$047src$047ecs$047component$058tx_set$1260$(($$$$047combined$045control$058family_a$()), ($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(($$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$({$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, run_clo((_x_0) => {
  return $$$$047production$045candidate$047transactions$047schema$045a$058published$(_x_0, array_node([801], [802]));
}))))), {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": 1}, array_node([501], [502]))));
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047production$045candidate$047schema$045a$058commit$(_observed_0) {
  const _world_0 = _observed_0["world"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047prototype$058enqueue$1260$(_tx_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047prototype$058apply$1260$(_x_0, _handle_0, _payload_0);
}));
}

function $$$$047production$045candidate$047schema$045a$058recover$(_world_0, _packet_0, _error_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _inverse_0 = _packet_0["undo"];
  return $$$$047combined$045control$058returned$(_world_0, {$: "../combined-control.Original", "raw": _inverse_0(_cooked_0)}, "insert-refusal");
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047fallible$045spawn$058reserved$1260$(_observed_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.ReservationRejected") {
    const _error_0 = _t_0["error"];
    return {$: "../prototype.SpawnRefused", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "payload": _payload_0, "error": _error_0};
  } else {
    const _handle_0 = _t_0["handle"];
    return {$: "../prototype.SpawnQueued", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047fallible$045spawn$058apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "handle": _handle_0};
  }
}

function $$$$047queue$058checked$1260$(_undo_0, _commands_0, _events_0, _handle_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../queue.Refused", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "payload": _payload_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../queue.Queued", "tx": ($$$$047prototype$058enqueue$1260$({$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _handle_0, _payload_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047constructor$045stage$058constructed_tail$1263$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../constructor-stage.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../constructor-stage.Valid", "context": _ctx_0, "cooked": {$: "../prototype.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047constructor$045stage$058undo_pack$1263$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_1, "raw": {$: "../prototype.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047constructor$045control$058stage_1$(_ctx_0, _raw_0) {
  return $$$$047constructor$045stage$058stage$1262$(_ctx_0, _raw_0);
}

function $$$$047constructor$045stage$058invalid_tail$1263$(_head_0, _error_0, _tail_0) {
  if (_tail_0.$ === "../constructor-stage.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_0, "raw": {$: "../prototype.Pack", "head": _head_0, "tail": _undo_0(_cooked_0)}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_1, "raw": {$: "../prototype.Pack", "head": _head_0, "tail": _raw_0}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_1}};
  }
}

function $$$$047constructor$045control$058array_construct$(_ctx_0, _raw_0) {
  const _valid_0 = _raw_0["valid"];
  const _owner_0 = _raw_0["owner"];
  return $$$$047constructor$045control$058array_valid$(($$$$047constructor$045control$058bump$(_ctx_0, 0)), _valid_0, _owner_0);
}

function $schema$045b$058invoked$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _context_0 = _t_0["context"];
  const _output_0 = _result_0["snd"];
  return $schema$045b$058prepared_finish$(_tx_0, _context_0, _output_0, ($schema$045b$058prepared_read$(_prepared_0)));
}

function $schema$045b$058invoke$(_owner_0, _args_0) {
  const _input_0 = _args_0["input"];
  const _target_0 = _args_0["retryTarget"];
  const _retry_0 = _args_0["retry"];
  const _declared_0 = _args_0["declared"];
  return $schema$045b$058invoked_declaration$(_owner_0, {$: "schema-b.Args", "input": _input_0, "retryTarget": _target_0, "retry": _retry_0, "declared": _declared_0}, _declared_0);
}

function $$$$047production$045candidate$047transactions$047schema$045b$058begin$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047production$045candidate$047transactions$047schema$045b$058journaled$(($$$$047$$$047$$$047src$047ecs$047component$058tx_set$1261$(($$$$047combined$045other$058family_a$()), ($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(($$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$({$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, run_clo((_x_0) => {
  return $$$$047production$045candidate$047transactions$047schema$045b$058published$(_x_0, array_node([801], [802]));
}))))), {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": 1}, array_node([501], [502]))));
}

function $$$$047production$045candidate$047schema$045b$058commit$(_observed_0) {
  const _world_0 = _observed_0["world"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047prototype$058enqueue$1261$(_tx_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047prototype$058apply$1261$(_x_0, _handle_0, _payload_0);
}));
}

function $$$$047production$045candidate$047schema$045b$058recover$(_world_0, _packet_0, _error_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _inverse_0 = _packet_0["undo"];
  return $$$$047combined$045other$058returned$(_world_0, {$: "../combined-other.Original", "raw": _inverse_0(_cooked_0)}, "insert-refusal");
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_join$1262$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1262$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047fallible$045spawn$058reserved$1261$(_observed_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.ReservationRejected") {
    const _error_0 = _t_0["error"];
    return {$: "../prototype.SpawnRefused", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "payload": _payload_0, "error": _error_0};
  } else {
    const _handle_0 = _t_0["handle"];
    return {$: "../prototype.SpawnQueued", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047fallible$045spawn$058apply$1261$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "handle": _handle_0};
  }
}

function $$$$047queue$058checked$1261$(_undo_0, _commands_0, _events_0, _handle_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../queue.Refused", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "payload": _payload_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return {$: "../queue.Queued", "tx": ($$$$047prototype$058enqueue$1261$({$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _handle_0, _payload_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $schema$045a$058prepared_finish$(_tx_0, _context_0, _output_0, _seen_0) {
  const _prepared_0 = _seen_0["fst"];
  const _texts_0 = _seen_0["snd"];
  return $schema$045a$058finished$(($$$$047production$045candidate$047transactions$047batch$058finish$1260$({$: "../production-candidate/transactions/batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, {$: "../../../src/ecs/transaction.Success"})), _context_0, _output_0, _texts_0);
}

function $schema$045a$058prepared_read$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $schema$045a$058prepared_head$(_head_0, ($schema$045a$058prepared_read$(_tail_0)));
  }
}

function $schema$045a$058invoked_declaration$(_owner_0, _args_0, _declared_0) {
  return $schema$045a$058bound$(($public$058provision_declared$1260$({$: "../../../src/ecs/schema-fragments.Fragment", "entries": ($schema$045a$058declared_entries$(_declared_0)), "owners": {$: "Tuple", "fst": _owner_0, "snd": _args_0}}, ($$$$047production$045candidate$047transactions$047schema$045a$058required$()))));
}

function $$$$047production$045candidate$047transactions$047schema$045a$058journaled$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return $$$$047production$045candidate$047transactions$047batch$058begin$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047production$045candidate$047transactions$047schema$045a$058published$(_x_0, array_node([901], [902]));
}))), 43)));
  } else if (_result_0.$ === "../../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    return $$$$047production$045candidate$047transactions$047batch$058begin$1260$(_tx_1);
  } else {
    const _tx_2 = _result_0["tx"];
    return $$$$047production$045candidate$047transactions$047batch$058begin$1260$(_tx_2);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set$1260$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1260$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047combined$045control$058family_a$() {
  return {$: "../../../src/ecs/component.Family", "name": "a"};
}

function $$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047production$045candidate$047transactions$047schema$045a$058published$(_world_0, _values_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, ($$$$047constructor$045control$058cells$(_values_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047prototype$058apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047prototype$058apply_checked$1260$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": {$: "../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047fallible$045spawn$058apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047fallible$045spawn$058activated$1260$(($$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047constructor$045stage$058undo_pack$1263$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../prototype.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047constructor$045stage$058stage$1262$(_ctx_0, _raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047constructor$045stage$058constructed_head$1262$(_tail_0, ($$$$047constructor$045control$058constructor_1$(_ctx_0, _head_0)));
}

function $$$$047constructor$045control$058array_valid$(_ctx_0, _valid_0, _owner_0) {
  if (_valid_0) {
    return $$$$047constructor$045control$058array_constructed$(_ctx_0, ($$$$047constructor$045control$058array_change$(_owner_0)));
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../constructor-stage.Invalid", "raw": {$: "../constructor-control.Raw", "valid": false, "owner": _owner_0}, "error": "bad-0"}};
  }
}

function $$$$047constructor$045control$058bump$(_ctx_0, _slot_0) {
  const _calls_0 = _ctx_0["calls"];
  const _order_0 = _ctx_0["order"];
  return $$$$047constructor$045control$058bump_seen$(_slot_0, _order_0, {$: "Tuple", fst: _calls_0, snd: _calls_0[_slot_0 % _calls_0.length]});
}

function $schema$045b$058prepared_finish$(_tx_0, _context_0, _output_0, _seen_0) {
  const _prepared_0 = _seen_0["fst"];
  const _texts_0 = _seen_0["snd"];
  return $schema$045b$058finished$(($$$$047production$045candidate$047transactions$047batch$058finish$1261$({$: "../production-candidate/transactions/batch.Batch", "tx": _tx_0, "prepared": _prepared_0}, {$: "../../../src/ecs/transaction.Success"})), _context_0, _output_0, _texts_0);
}

function $schema$045b$058prepared_read$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $schema$045b$058prepared_head$(_head_0, ($schema$045b$058prepared_read$(_tail_0)));
  }
}

function $schema$045b$058invoked_declaration$(_owner_0, _args_0, _declared_0) {
  return $schema$045b$058bound$(($public$058provision_declared$1261$({$: "../../../src/ecs/schema-fragments.Fragment", "entries": ($schema$045b$058declared_entries$(_declared_0)), "owners": {$: "Tuple", "fst": _owner_0, "snd": _args_0}}, ($$$$047production$045candidate$047transactions$047schema$045b$058required$()))));
}

function $$$$047production$045candidate$047transactions$047schema$045b$058journaled$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Written") {
    const _tx_0 = _result_0["tx"];
    return $$$$047production$045candidate$047transactions$047batch$058begin$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047production$045candidate$047transactions$047schema$045b$058published$(_x_0, array_node([901], [902]));
}))), 43)));
  } else if (_result_0.$ === "../../../src/ecs/component.WriteRejected") {
    const _tx_1 = _result_0["tx"];
    return $$$$047production$045candidate$047transactions$047batch$058begin$1261$(_tx_1);
  } else {
    const _tx_2 = _result_0["tx"];
    return $$$$047production$045candidate$047transactions$047batch$058begin$1261$(_tx_2);
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set$1261$(_family_0, _tx_0, _handle_0, _incoming_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1261$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0)));
}

function $$$$047combined$045other$058family_a$() {
  return {$: "../../../src/ecs/component.Family", "name": "a"};
}

function $$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047production$045candidate$047transactions$047schema$045b$058published$(_world_0, _values_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, ($$$$047constructor$045control$058cells$(_values_0)));
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047prototype$058apply$1261$(_world_0, _handle_0, _payload_0) {
  return $$$$047prototype$058apply_checked$1261$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_reserved$1262$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1262$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": {$: "../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047fallible$045spawn$058apply$1261$(_world_0, _handle_0, _payload_0) {
  return $$$$047fallible$045spawn$058activated$1261$(($$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $schema$045a$058finished$(_result_0, _context_0, _output_0, _prepared_0) {
  if (_result_0.$ === "../production-candidate/transactions/batch.Committed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "schema-a.Delivery", "context": _context_0, "result": _output_0, "prepared": _prepared_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/system.Failed", "world": _world_1, "error": _error_0};
  }
}

function $$$$047production$045candidate$047transactions$047batch$058finish$1260$(_batch_0, _outcome_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    return $$$$047production$045candidate$047transactions$047batch$058committed$1260$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(run_loop($$$$047production$045candidate$047transactions$047batch$058stage$1260$(($List$reverse$(_prepared_0)), _tx_0)), {$: "../../../src/ecs/transaction.Success"})));
  } else {
    const _error_0 = _outcome_0["error"];
    return $$$$047production$045candidate$047transactions$047batch$058failed$1260$(($$$$047production$045candidate$047transactions$047batch$058originals$1260$(($List$reverse$(_prepared_0)))), _error_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../src/ecs/transaction.Failure", "error": _error_0})));
  }
}

function $schema$045a$058prepared_head$(_head_0, _seen_0) {
  if (_head_0.$ === "../production-candidate/transactions/batch.ReservationReceipt") {
    const _target_0 = _head_0["target"];
    const _tail_0 = _seen_0["fst"];
    const _texts_0 = _seen_0["snd"];
    return {$: "Tuple", "fst": {$: "Con", "head": {$: "../production-candidate/transactions/batch.ReservationReceipt", "target": _target_0}, "tail": _tail_0}, "snd": {$: "Con", "head": "receipt", "tail": _texts_0}};
  } else {
    const _target_1 = _head_0["target"];
    const _packet_0 = _head_0["payload"];
    const _position_0 = _head_0["position"];
    const _tail_1 = _seen_0["fst"];
    const _texts_1 = _seen_0["snd"];
    return $schema$045a$058prepared_packet$(_target_1, _position_0, _tail_1, _texts_1, ($schema$045a$058packet_read$(_packet_0)));
  }
}

function $schema$045a$058bound$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Built") {
    const _output_0 = _result_0["output"];
    return _output_0;
  } else {
    const _error_0 = _result_0["error"];
    const _t_0 = _result_0["fragment"];
    const _t_1 = _t_0["owners"];
    const _owner_0 = _t_1["fst"];
    const _t_2 = _t_1["snd"];
    const _t_3 = _t_2["input"];
    const _raw_0 = _t_3["raw"];
    return $schema$045a$058declaration_returned$(_owner_0, _error_0, ($schema$045a$058raw_0$(_raw_0)));
  }
}

function $public$058provision_declared$1260$(_fragment_0, _required_0) {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_declared$1264$(_fragment_0, _required_0);
}

function $schema$045a$058declared_entries$(_declared_0) {
  if (_declared_0) {
    return $$$$047production$045candidate$047transactions$047schema$045a$058available$();
  } else {
    return {$: "Nil"};
  }
}

function $$$$047production$045candidate$047transactions$047schema$045a$058required$() {
  return {$: "Con", "head": ($$$$047public$045client$047declared$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058b_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058tag_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058value_entry$()), "tail": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.insert", "name": "bundle.insert"}, "tail": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.spawn", "name": "bundle.spawn"}, "tail": {$: "Nil"}}}}}}}};
}

function $$$$047production$045candidate$047transactions$047batch$058begin$1260$(_tx_0) {
  return {$: "../production-candidate/transactions/batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047prototype$058apply_checked$1260$(_observed_0, _handle_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047production$045candidate$047schema$045a$058recover$(_world_0, _payload_0, {$: "../../../src/ecs/world.MissingEntity"});
  } else {
    return $$$$047prototype$058deliver$1260$(($$$$047production$045candidate$047schema$045a$058attempt$(_world_0, _handle_0, _payload_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawned$1260$(($$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047fallible$045spawn$058activated$1260$(_observed_0, _handle_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Accepted") {
    return $$$$047fallible$045spawn$058deliver$1260$(_handle_0, ($$$$047combined$045control$058populate$(_world_0, _handle_0, _payload_0)));
  } else {
    const _error_0 = _t_0["error"];
    return $$$$047combined$045control$058recover$(_world_0, _handle_0, _payload_0, {$: "../fallible-spawn.ActivationFailure", "error": _error_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047constructor$045stage$058constructed_head$1262$(_tail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../constructor-stage.Constructed") {
    const _head_0 = _t_0["cooked"];
    const _undo_0 = _t_0["undo"];
    return $$$$047constructor$045stage$058constructed_tail$1262$(_head_0, _undo_0, ($$$$047constructor$045control$058stage_2$(_ctx_0, _tail_0)));
  } else {
    const _head_1 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $$$$047constructor$045stage$058invalid_tail$1262$(_head_1, _error_0, ($$$$047constructor$045control$058stage_2$(_ctx_0, _tail_0)));
  }
}

function $$$$047constructor$045control$058constructor_1$(_ctx_0, _raw_0) {
  return $$$$047constructor$045control$058construct$1261$(1, "bad-1", _ctx_0, _raw_0);
}

function $$$$047constructor$045control$058array_constructed$(_ctx_0, _changed_0) {
  const _owner_0 = _changed_0["fst"];
  const _restore_0 = _changed_0["snd"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../constructor-stage.Constructed", "cooked": {$: "../constructor-control.Cooked", "owner": _owner_0}, "undo": run_clo((_x_0) => {
  return $$$$047constructor$045control$058array_undone$(_restore_0, _x_0);
})}};
}

function $$$$047constructor$045control$058array_change$(_owner_0) {
  return $$$$047constructor$045control$058array_seen$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $$$$047constructor$045control$058bump_seen$(_slot_0, _order_0, _seen_0) {
  const _calls_0 = _seen_0["fst"];
  const _count_0 = _seen_0["snd"];
  const _x_0 = ((_count_0 + 1) >>> 0);
  return {$: "../constructor-control.Context", "calls": (_calls_0[_slot_0 % _calls_0.length] = _x_0, _calls_0), "order": ($List$append$(_order_0, {$: "Con", "head": _slot_0, "tail": {$: "Nil"}}))};
}

function $schema$045b$058finished$(_result_0, _context_0, _output_0, _prepared_0) {
  if (_result_0.$ === "../production-candidate/transactions/batch.Committed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "schema-b.Delivery", "context": _context_0, "result": _output_0, "prepared": _prepared_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/system.Failed", "world": _world_1, "error": _error_0};
  }
}

function $$$$047production$045candidate$047transactions$047batch$058finish$1261$(_batch_0, _outcome_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    return $$$$047production$045candidate$047transactions$047batch$058committed$1261$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(run_loop($$$$047production$045candidate$047transactions$047batch$058stage$1261$(($List$reverse$(_prepared_0)), _tx_0)), {$: "../../../src/ecs/transaction.Success"})));
  } else {
    const _error_0 = _outcome_0["error"];
    return $$$$047production$045candidate$047transactions$047batch$058failed$1261$(($$$$047production$045candidate$047transactions$047batch$058originals$1261$(($List$reverse$(_prepared_0)))), _error_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../../src/ecs/transaction.Failure", "error": _error_0})));
  }
}

function $schema$045b$058prepared_head$(_head_0, _seen_0) {
  if (_head_0.$ === "../production-candidate/transactions/batch.ReservationReceipt") {
    const _target_0 = _head_0["target"];
    const _tail_0 = _seen_0["fst"];
    const _texts_0 = _seen_0["snd"];
    return {$: "Tuple", "fst": {$: "Con", "head": {$: "../production-candidate/transactions/batch.ReservationReceipt", "target": _target_0}, "tail": _tail_0}, "snd": {$: "Con", "head": "receipt", "tail": _texts_0}};
  } else {
    const _target_1 = _head_0["target"];
    const _packet_0 = _head_0["payload"];
    const _position_0 = _head_0["position"];
    const _tail_1 = _seen_0["fst"];
    const _texts_1 = _seen_0["snd"];
    return $schema$045b$058prepared_packet$(_target_1, _position_0, _tail_1, _texts_1, ($schema$045b$058packet_read$(_packet_0)));
  }
}

function $schema$045b$058bound$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Built") {
    const _output_0 = _result_0["output"];
    return _output_0;
  } else {
    const _error_0 = _result_0["error"];
    const _t_0 = _result_0["fragment"];
    const _t_1 = _t_0["owners"];
    const _owner_0 = _t_1["fst"];
    const _t_2 = _t_1["snd"];
    const _t_3 = _t_2["input"];
    const _raw_0 = _t_3["raw"];
    return $schema$045b$058declaration_returned$(_owner_0, _error_0, ($schema$045b$058raw_0$(_raw_0)));
  }
}

function $public$058provision_declared$1261$(_fragment_0, _required_0) {
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_declared$1269$(_fragment_0, _required_0);
}

function $schema$045b$058declared_entries$(_declared_0) {
  if (_declared_0) {
    return $$$$047production$045candidate$047transactions$047schema$045b$058available$();
  } else {
    return {$: "Nil"};
  }
}

function $$$$047production$045candidate$047transactions$047schema$045b$058required$() {
  return {$: "Con", "head": ($$$$047public$045client$047declared$045other$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058b_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058tag_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058value_entry$()), "tail": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.insert", "name": "bundle.insert"}, "tail": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.spawn", "name": "bundle.spawn"}, "tail": {$: "Nil"}}}}}}}};
}

function $$$$047production$045candidate$047transactions$047batch$058begin$1261$(_tx_0) {
  return {$: "../production-candidate/transactions/batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_set_fused$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _observed_0) {
  const _result_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": {$: "Some", "value": _incoming_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047prototype$058apply_checked$1261$(_observed_0, _handle_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047production$045candidate$047schema$045b$058recover$(_world_0, _payload_0, {$: "../../../src/ecs/world.MissingEntity"});
  } else {
    return $$$$047prototype$058deliver$1261$(($$$$047production$045candidate$047schema$045b$058attempt$(_world_0, _handle_0, _payload_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawn_apply$1262$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058spawned$1262$(($$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047fallible$045spawn$058activated$1261$(_observed_0, _handle_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Accepted") {
    return $$$$047fallible$045spawn$058deliver$1261$(_handle_0, ($$$$047combined$045other$058populate$(_world_0, _handle_0, _payload_0)));
  } else {
    const _error_0 = _t_0["error"];
    return $$$$047combined$045other$058recover$(_world_0, _handle_0, _payload_0, {$: "../fallible-spawn.ActivationFailure", "error": _error_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047production$045candidate$047transactions$047batch$058committed$1260$(_observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../production-candidate/transactions/batch.Committed", "world": _world_0};
}

function $$$$047production$045candidate$047transactions$047batch$058stage$1260$(_prepared_0, _tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047production$045candidate$047transactions$047batch$058staged$1260$(_prepared_0, ($List$reverse$(_commands_0)), 0, {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Nil"}, "events": _events_0});
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047production$045candidate$047transactions$047batch$058failed$1260$(_payloads_0, _error_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../production-candidate/transactions/batch.Failed", "world": _world_0, "payloads": _payloads_0, "error": _error_0};
}

function $$$$047production$045candidate$047transactions$047batch$058originals$1260$($0) {
  for (;;) {
    {
      const _prepared_0 = $0;
      if (_prepared_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../production-candidate/transactions/batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          continue;
        } else {
          const _payload_0 = _t_0["payload"];
          const _tail_1 = _prepared_0["tail"];
          return {$: "Con", "head": _payload_0, "tail": ($$$$047production$045candidate$047transactions$047batch$058originals$1260$(_tail_1))};
        }
      }
    }
  }
}

function $schema$045a$058prepared_packet$(_target_0, _position_0, _tail_0, _texts_0, _seen_0) {
  const _packet_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  const _x_0 = ($Nat$show$(_position_0));
  const _x_1 = (":" + _text_0);
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "../production-candidate/transactions/batch.Prepared", "target": _target_0, "payload": _packet_0, "position": _position_0}, "tail": _tail_0}, "snd": {$: "Con", "head": (_x_0 + _x_1), "tail": _texts_0}};
}

function $schema$045a$058packet_read$(_packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return $schema$045a$058packet_seen$(_undo_0, ($$$$047constructor$045control$058cooked_read_0$(_cooked_0)));
}

function $schema$045a$058declaration_returned$(_owner_0, _error_0, _seen_0) {
  const _raw_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "schema-a.GameResult", "result": {$: "adapter.Refused", "raw": _raw_0, "error": {$: "adapter.DeclarationRefused", "error": _error_0}}, "first": {$: "Some", "value": {$: "adapter.DeclarationRefused", "error": _error_0}}, "returned": _text_0}};
}

function $schema$045a$058raw_0$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _array_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  return $schema$045a$058raw_0_seen$(_valid_0, _tail_0, ($$$$047constructor$045control$058array_read$(_array_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_declared$1264$(_fragment_0, _required_0) {
  const _entries_0 = _fragment_0["entries"];
  const _owners_0 = _fragment_0["owners"];
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_requirements$1264$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate$1260$(_entries_0)), _required_0, {$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0});
}

function $$$$047production$045candidate$047transactions$047schema$045a$058available$() {
  return {$: "Con", "head": ($$$$047public$045client$047declared$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058b_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058tag_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$058value_entry$()), "tail": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.insert", "name": "bundle.insert"}, "tail": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.spawn", "name": "bundle.spawn"}, "tail": {$: "Nil"}}}}}}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1260$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../src/ecs/component.Written", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteRejected", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteFailure", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1260$(($$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(($$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047combined$045control$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047prototype$058deliver$1260$(_result_0) {
  if (_result_0.$ === "../prototype.Delivered") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047production$045candidate$047schema$045a$058recover$(_world_1, _payload_0, _error_0);
  }
}

function $$$$047production$045candidate$047schema$045a$058attempt$(_world_0, _handle_0, _packet_0) {
  return $$$$047production$045candidate$047schema$045a$058population$(($$$$047combined$045control$058populate$(_world_0, _handle_0, _packet_0)));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Accepted") {
    return $$$$047production$045candidate$047schema$045a$058empty_population$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047fallible$045spawn$058deliver$1260$(_handle_0, _observed_0) {
  if (_observed_0.$ === "../fallible-spawn.Populated") {
    const _world_0 = _observed_0["world"];
    return _world_0;
  } else {
    const _world_1 = _observed_0["world"];
    const _payload_0 = _observed_0["payload"];
    const _error_0 = _observed_0["error"];
    return $$$$047combined$045control$058recover$(_world_1, _handle_0, _payload_0, {$: "../fallible-spawn.PopulationFailure", "error": _error_0});
  }
}

function $$$$047combined$045control$058populate$(_world_0, _handle_0, _packet_0) {
  const _t_0 = _packet_0["cooked"];
  const _t_1 = _t_0["head"];
  const _a_0 = _t_1["owner"];
  const _t_2 = _t_0["tail"];
  const _t_3 = _t_2["head"];
  const _value_0 = _t_3["owner"];
  const _t_4 = _t_2["tail"];
  const _t_5 = _t_4["head"];
  const _tag_0 = _t_5["owner"];
  const _t_6 = _t_4["tail"];
  const _t_7 = _t_6["head"];
  const _t_8 = _t_7["owner"];
  const _front_0 = _t_8["front"];
  const _back_0 = _t_8["back"];
  const _queued_0 = _t_8["queued"];
  const _t_9 = _t_6["tail"];
  const _undo_0 = _packet_0["undo"];
  const _target_0 = _handle_0;
  return {$: "../fallible-spawn.Populated", "world": ($$$$047combined$045control$058installed$(_queued_0, _undo_0, ($$$$047combined$045control$058install_0$(_world_0, {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _front_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _back_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _tag_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _value_0}}, "tail": {$: "Unit"}}}}}}))))};
}

function $$$$047combined$045control$058recover$(_world_0, _handle_0, _packet_0, _error_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return $$$$047combined$045control$058returned$(_world_0, {$: "../combined-control.Original", "raw": _undo_0(_cooked_0)}, "activation-refusal");
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047constructor$045stage$058constructed_tail$1262$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../constructor-stage.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../constructor-stage.Valid", "context": _ctx_0, "cooked": {$: "../prototype.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047constructor$045stage$058undo_pack$1262$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_1, "raw": {$: "../prototype.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047constructor$045control$058stage_2$(_ctx_0, _raw_0) {
  return $$$$047constructor$045stage$058stage$1261$(_ctx_0, _raw_0);
}

function $$$$047constructor$045stage$058invalid_tail$1262$(_head_0, _error_0, _tail_0) {
  if (_tail_0.$ === "../constructor-stage.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_0, "raw": {$: "../prototype.Pack", "head": _head_0, "tail": _undo_0(_cooked_0)}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_1, "raw": {$: "../prototype.Pack", "head": _head_0, "tail": _raw_0}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_1}};
  }
}

function $$$$047constructor$045control$058construct$1261$(_slot_0, _error_0, _ctx_0, _raw_0) {
  const _valid_0 = _raw_0["valid"];
  const _owner_0 = _raw_0["owner"];
  return $$$$047constructor$045control$058validated$1261$(($$$$047constructor$045control$058bump$(_ctx_0, _slot_0)), _valid_0, _owner_0, _error_0);
}

function $$$$047constructor$045control$058array_undone$(_restore_0, _cooked_0) {
  const _owner_0 = _cooked_0["owner"];
  return {$: "../constructor-control.Raw", "valid": true, "owner": _restore_0(_owner_0)};
}

function $$$$047constructor$045control$058array_seen$(_seen_0) {
  const _owner_0 = _seen_0["fst"];
  const _old0_0 = _seen_0["snd"];
  return $$$$047constructor$045control$058array_changed$(_old0_0, {$: "Tuple", fst: _owner_0, snd: _owner_0[1 % _owner_0.length]});
}

function $$$$047production$045candidate$047transactions$047batch$058committed$1261$(_observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../production-candidate/transactions/batch.Committed", "world": _world_0};
}

function $$$$047production$045candidate$047transactions$047batch$058stage$1261$(_prepared_0, _tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047production$045candidate$047transactions$047batch$058staged$1261$(_prepared_0, ($List$reverse$(_commands_0)), 0, {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Nil"}, "events": _events_0});
}

function $$$$047production$045candidate$047transactions$047batch$058failed$1261$(_payloads_0, _error_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../production-candidate/transactions/batch.Failed", "world": _world_0, "payloads": _payloads_0, "error": _error_0};
}

function $$$$047production$045candidate$047transactions$047batch$058originals$1261$($0) {
  for (;;) {
    {
      const _prepared_0 = $0;
      if (_prepared_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../production-candidate/transactions/batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          continue;
        } else {
          const _payload_0 = _t_0["payload"];
          const _tail_1 = _prepared_0["tail"];
          return {$: "Con", "head": _payload_0, "tail": ($$$$047production$045candidate$047transactions$047batch$058originals$1261$(_tail_1))};
        }
      }
    }
  }
}

function $schema$045b$058prepared_packet$(_target_0, _position_0, _tail_0, _texts_0, _seen_0) {
  const _packet_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  const _x_0 = ($Nat$show$(_position_0));
  const _x_1 = (":" + _text_0);
  return {$: "Tuple", "fst": {$: "Con", "head": {$: "../production-candidate/transactions/batch.Prepared", "target": _target_0, "payload": _packet_0, "position": _position_0}, "tail": _tail_0}, "snd": {$: "Con", "head": (_x_0 + _x_1), "tail": _texts_0}};
}

function $schema$045b$058packet_read$(_packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return $schema$045b$058packet_seen$(_undo_0, ($$$$047constructor$045control$058cooked_read_0$(_cooked_0)));
}

function $schema$045b$058declaration_returned$(_owner_0, _error_0, _seen_0) {
  const _raw_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "schema-b.GameResult", "result": {$: "adapter.Refused", "raw": _raw_0, "error": {$: "adapter.DeclarationRefused", "error": _error_0}}, "first": {$: "Some", "value": {$: "adapter.DeclarationRefused", "error": _error_0}}, "returned": _text_0}};
}

function $schema$045b$058raw_0$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _array_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  return $schema$045b$058raw_0_seen$(_valid_0, _tail_0, ($$$$047constructor$045control$058array_read$(_array_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_declared$1269$(_fragment_0, _required_0) {
  const _entries_0 = _fragment_0["entries"];
  const _owners_0 = _fragment_0["owners"];
  return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_requirements$1269$(($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058validate$1261$(_entries_0)), _required_0, {$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0});
}

function $$$$047production$045candidate$047transactions$047schema$045b$058available$() {
  return {$: "Con", "head": ($$$$047public$045client$047declared$045other$058a_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058b_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058tag_entry$()), "tail": {$: "Con", "head": ($$$$047public$045client$047declared$045other$058value_entry$()), "tail": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.insert", "name": "bundle.insert"}, "tail": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Service"}, "key": "bundle.spawn", "name": "bundle.spawn"}, "tail": {$: "Nil"}}}}}}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058tx_written$1261$(_family_0, _handle_0, _undo_0, _commands_0, _events_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../src/ecs/component.Written", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1264$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _previous_0, _x_0)));
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _t_0 = _result_0["incoming"];
    if (_t_0.$ === "Some") {
      const _incoming_0 = _t_0["value"];
      const _error_0 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteRejected", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "incoming": _incoming_0, "error": _error_0};
    } else {
      const _error_1 = _result_0["error"];
      return {$: "../../../src/ecs/component.WriteFailure", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_1, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "error": _error_1};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1261$(($$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12612$(($$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))), (_clock_0 < 4294967295), ($$$$047combined$045other$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, ($$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, (_clock_0 < 4294967295))))));
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047prototype$058deliver$1261$(_result_0) {
  if (_result_0.$ === "../prototype.Delivered") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047production$045candidate$047schema$045b$058recover$(_world_1, _payload_0, _error_0);
  }
}

function $$$$047production$045candidate$047schema$045b$058attempt$(_world_0, _handle_0, _packet_0) {
  return $$$$047production$045candidate$047schema$045b$058population$(($$$$047combined$045other$058populate$(_world_0, _handle_0, _packet_0)));
}

function $$$$047$$$047$$$047src$047ecs$047commands$058spawned$1262$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Accepted") {
    return $$$$047production$045candidate$047schema$045b$058empty_population$(_world_0, _handle_0, _payload_0);
  } else {
    return _world_0;
  }
}

function $$$$047fallible$045spawn$058deliver$1261$(_handle_0, _observed_0) {
  if (_observed_0.$ === "../fallible-spawn.Populated") {
    const _world_0 = _observed_0["world"];
    return _world_0;
  } else {
    const _world_1 = _observed_0["world"];
    const _payload_0 = _observed_0["payload"];
    const _error_0 = _observed_0["error"];
    return $$$$047combined$045other$058recover$(_world_1, _handle_0, _payload_0, {$: "../fallible-spawn.PopulationFailure", "error": _error_0});
  }
}

function $$$$047combined$045other$058populate$(_world_0, _handle_0, _packet_0) {
  const _t_0 = _packet_0["cooked"];
  const _t_1 = _t_0["head"];
  const _a_0 = _t_1["owner"];
  const _t_2 = _t_0["tail"];
  const _t_3 = _t_2["head"];
  const _value_0 = _t_3["owner"];
  const _t_4 = _t_2["tail"];
  const _t_5 = _t_4["head"];
  const _tag_0 = _t_5["owner"];
  const _t_6 = _t_4["tail"];
  const _t_7 = _t_6["head"];
  const _t_8 = _t_7["owner"];
  const _front_0 = _t_8["front"];
  const _back_0 = _t_8["back"];
  const _queued_0 = _t_8["queued"];
  const _t_9 = _t_6["tail"];
  const _undo_0 = _packet_0["undo"];
  const _target_0 = _handle_0;
  return {$: "../fallible-spawn.Populated", "world": ($$$$047combined$045other$058installed$(_queued_0, _undo_0, ($$$$047combined$045other$058install_0$(_world_0, {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _a_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _front_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _back_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _tag_0}}, "tail": {$: "../prototype.Pack", "head": {$: "../component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _value_0}}, "tail": {$: "Unit"}}}}}}))))};
}

function $$$$047combined$045other$058recover$(_world_0, _handle_0, _packet_0, _error_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return $$$$047combined$045other$058returned$(_world_0, {$: "../combined-other.Original", "raw": _undo_0(_cooked_0)}, "activation-refusal");
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047production$045candidate$047transactions$047batch$058staged$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _prepared_0 = $0;
      const _commands_0 = $1;
      const _current_0 = $2;
      const _tx_0 = $3;
      if (_prepared_0.$ === "Nil") {
        return $$$$047production$045candidate$047transactions$047batch$058remaining$1260$(_commands_0, _tx_0);
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../production-candidate/transactions/batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          $1 = _commands_0;
          $2 = _current_0;
          $3 = _tx_0;
          continue;
        } else {
          const _target_1 = _t_0["target"];
          const _payload_0 = _t_0["payload"];
          const _position_0 = _t_0["position"];
          const _tail_1 = _prepared_0["tail"];
          return $$$$047production$045candidate$047transactions$047batch$058staged_after$1260$(_target_1, _payload_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047production$045candidate$047transactions$047batch$058staged$1260$(_tail_1, _x_0, _position_0, _x_1);
});
}), ($$$$047production$045candidate$047transactions$047batch$058preceding$1260$((_position_0 < _current_0 ? 0 : _position_0 - _current_0), _commands_0, _tx_0)));
        }
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $schema$045a$058packet_seen$(_undo_0, _seen_0) {
  const _cooked_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  return {$: "Tuple", "fst": {$: "../combined-control.Packet", "cooked": _cooked_0, "undo": _undo_0}, "snd": _text_0};
}

function $$$$047constructor$045control$058cooked_read_0$(_cooked_0) {
  const _t_0 = _cooked_0["head"];
  const _owner_0 = _t_0["owner"];
  const _rest_0 = _cooked_0["tail"];
  return $$$$047constructor$045control$058cooked_read_join_0$(($$$$047constructor$045control$058array_read$(_owner_0)), ($$$$047constructor$045control$058cooked_read_1$(_rest_0)));
}

function $schema$045a$058raw_0_seen$(_valid_0, _tail_0, _seen_0) {
  const _array_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  return $schema$045a$058raw_0_tail$(_valid_0, _array_0, _text_0, ($schema$045a$058raw_1$(_tail_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_requirements$1264$(_result_0, _required_0, _fragment_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.BindRejected", "error": _error_0, "fragment": _fragment_0};
  } else {
    const _entries_0 = _fragment_0["entries"];
    const _owners_0 = _fragment_0["owners"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_checked$1264$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058requirements$1260$(_required_0, _entries_0)), {$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore$1260$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1260$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12610$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1260$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047combined$045control$058take_a$(_store_0) {
  const _a_0 = _store_0["a"];
  const _b_0 = _store_0["b"];
  const _tag_0 = _store_0["tag"];
  const _value_0 = _store_0["value"];
  return {$: "Tuple", "fst": {$: "../combined-control.Rest_a", "b": _b_0, "tag": _tag_0, "value": _value_0}, "snd": _a_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047production$045candidate$047schema$045a$058population$(_observed_0) {
  if (_observed_0.$ === "../fallible-spawn.Populated") {
    const _world_0 = _observed_0["world"];
    return {$: "../prototype.Delivered", "world": _world_0};
  } else {
    const _world_1 = _observed_0["world"];
    const _payload_0 = _observed_0["payload"];
    return {$: "../prototype.Undelivered", "world": _world_1, "payload": _payload_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  }
}

function $$$$047production$045candidate$047schema$045a$058empty_population$(_world_0, _handle_0, _unit_0) {
  return _world_0;
}

function $$$$047combined$045control$058installed$(_queued_0, _undo_0, _observed_0) {
  if (_observed_0.$ === "../fallible-install.Installed") {
    const _world_0 = _observed_0["world"];
    const _inverse_0 = _observed_0["undo"];
    return $$$$047combined$045control$058recorded$(_world_0, _inverse_0, _queued_0, _undo_0);
  } else if (_observed_0.$ === "../fallible-install.Refused") {
    const _world_1 = _observed_0["world"];
    const _pack_0 = _observed_0["payload"];
    return $$$$047combined$045control$058returned$(_world_1, ($$$$047combined$045control$058rebuild$(_pack_0, _queued_0, _undo_0)), "column-refusal");
  } else {
    const _world_2 = _observed_0["world"];
    const _recovery_0 = _observed_0["recovery"];
    return $$$$047combined$045control$058quarantined$(_world_2, _recovery_0, _queued_0, _undo_0);
  }
}

function $$$$047combined$045control$058install_0$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1264$(_world_0, _tail_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.Rejected", "error": {$: "../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047constructor$045stage$058undo_pack$1262$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../prototype.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047constructor$045stage$058stage$1261$(_ctx_0, _raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047constructor$045stage$058constructed_head$1261$(_tail_0, ($$$$047constructor$045control$058constructor_2$(_ctx_0, _head_0)));
}

function $$$$047constructor$045control$058validated$1261$(_ctx_0, _valid_0, _owner_0, _error_0) {
  if (_valid_0) {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../constructor-stage.Constructed", "cooked": {$: "../constructor-control.Cooked", "owner": _owner_0}, "undo": run_clo((_x_0) => {
  return $$$$047constructor$045control$058undo$1261$(_x_0);
})}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../constructor-stage.Invalid", "raw": {$: "../constructor-control.Raw", "valid": false, "owner": _owner_0}, "error": _error_0}};
  }
}

function $$$$047constructor$045control$058array_changed$(_old0_0, _seen_0) {
  const _owner_0 = _seen_0["fst"];
  const _old1_0 = _seen_0["snd"];
  const _x_0 = ((_old0_0 + 1000) >>> 0);
  const _x_1 = (_owner_0[0 % _owner_0.length] = _x_0, _owner_0);
  const _x_2 = ((_old1_0 + 1000) >>> 0);
  return {$: "Tuple", "fst": (_x_1[1 % _x_1.length] = _x_2, _x_1), "snd": run_clo((_x_3) => {
  return $$$$047constructor$045control$058array_restore$(_old0_0, _old1_0, _x_3);
})};
}

function $$$$047production$045candidate$047transactions$047batch$058staged$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _prepared_0 = $0;
      const _commands_0 = $1;
      const _current_0 = $2;
      const _tx_0 = $3;
      if (_prepared_0.$ === "Nil") {
        return $$$$047production$045candidate$047transactions$047batch$058remaining$1261$(_commands_0, _tx_0);
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../production-candidate/transactions/batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          $1 = _commands_0;
          $2 = _current_0;
          $3 = _tx_0;
          continue;
        } else {
          const _target_1 = _t_0["target"];
          const _payload_0 = _t_0["payload"];
          const _position_0 = _t_0["position"];
          const _tail_1 = _prepared_0["tail"];
          return $$$$047production$045candidate$047transactions$047batch$058staged_after$1261$(_target_1, _payload_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047production$045candidate$047transactions$047batch$058staged$1261$(_tail_1, _x_0, _position_0, _x_1);
});
}), ($$$$047production$045candidate$047transactions$047batch$058preceding$1261$((_position_0 < _current_0 ? 0 : _position_0 - _current_0), _commands_0, _tx_0)));
        }
      }
    }
  }
}

function $schema$045b$058packet_seen$(_undo_0, _seen_0) {
  const _cooked_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  return {$: "Tuple", "fst": {$: "../combined-other.Packet", "cooked": _cooked_0, "undo": _undo_0}, "snd": _text_0};
}

function $schema$045b$058raw_0_seen$(_valid_0, _tail_0, _seen_0) {
  const _array_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  return $schema$045b$058raw_0_tail$(_valid_0, _array_0, _text_0, ($schema$045b$058raw_1$(_tail_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_requirements$1269$(_result_0, _required_0, _fragment_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.BindRejected", "error": _error_0, "fragment": _fragment_0};
  } else {
    const _entries_0 = _fragment_0["entries"];
    const _owners_0 = _fragment_0["owners"];
    return $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_checked$1269$(run_loop($$$$047$$$047$$$047src$047ecs$047schema$045fragments$058requirements$1261$(_required_0, _entries_0)), {$: "../../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1264$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1264$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1264$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore$1261$(_family_0, _handle_0, _incoming_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1261$(($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_replaced$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _t_1 = _t_0["fst"];
  if (_t_1.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_1["previous"];
    const _stamp_0 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0}, "snd": _stamp_0};
  } else {
    const _incoming_0 = _t_1["incoming"];
    const _stamp_1 = _t_0["snd"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}}, "snd": _stamp_1};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$12612$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store$1261$(_id_0, _incoming_0, _tick_0, _allowed_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1263$(_column_0, _id_0)));
}

function $$$$047combined$045other$058take_a$(_store_0) {
  const _a_0 = _store_0["a"];
  const _b_0 = _store_0["b"];
  const _tag_0 = _store_0["tag"];
  const _value_0 = _store_0["value"];
  return {$: "Tuple", "fst": {$: "../combined-other.Rest_a", "b": _b_0, "tag": _tag_0, "value": _value_0}, "snd": _a_0};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047production$045candidate$047schema$045b$058population$(_observed_0) {
  if (_observed_0.$ === "../fallible-spawn.Populated") {
    const _world_0 = _observed_0["world"];
    return {$: "../prototype.Delivered", "world": _world_0};
  } else {
    const _world_1 = _observed_0["world"];
    const _payload_0 = _observed_0["payload"];
    return {$: "../prototype.Undelivered", "world": _world_1, "payload": _payload_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  }
}

function $$$$047production$045candidate$047schema$045b$058empty_population$(_world_0, _handle_0, _unit_0) {
  return _world_0;
}

function $$$$047combined$045other$058installed$(_queued_0, _undo_0, _observed_0) {
  if (_observed_0.$ === "../fallible-install.Installed") {
    const _world_0 = _observed_0["world"];
    const _inverse_0 = _observed_0["undo"];
    return $$$$047combined$045other$058recorded$(_world_0, _inverse_0, _queued_0, _undo_0);
  } else if (_observed_0.$ === "../fallible-install.Refused") {
    const _world_1 = _observed_0["world"];
    const _pack_0 = _observed_0["payload"];
    return $$$$047combined$045other$058returned$(_world_1, ($$$$047combined$045other$058rebuild$(_pack_0, _queued_0, _undo_0)), "column-refusal");
  } else {
    const _world_2 = _observed_0["world"];
    const _recovery_0 = _observed_0["recovery"];
    return $$$$047combined$045other$058quarantined$(_world_2, _recovery_0, _queued_0, _undo_0);
  }
}

function $$$$047combined$045other$058install_0$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1269$(_world_0, _tail_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.Rejected", "error": {$: "../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047production$045candidate$047transactions$047batch$058remaining$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _tx_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _tx_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047production$045candidate$047transactions$047batch$058staged_after$1260$(_target_0, _payload_0, _next_0, _result_0) {
  const _after_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return run_tail(_next_0(_after_0), ($$$$047prototype$058enqueue$1260$(_before_0, _target_0, _payload_0)));
}

function $$$$047production$045candidate$047transactions$047batch$058preceding$1260$($0, $1, $2) {
  for (;;) {
    {
      const _count_0 = $0;
      const _commands_0 = $1;
      const _tx_0 = $2;
      if (_count_0 === 0) {
        return {$: "Tuple", "fst": _commands_0, "snd": _tx_0};
      } else {
        const _rest_0 = (_count_0 - 1);
        if (_commands_0.$ === "Nil") {
          return {$: "Tuple", "fst": {$: "Nil"}, "snd": _tx_0};
        } else {
          const _command_0 = _commands_0["head"];
          const _tail_0 = _commands_0["tail"];
          $0 = _rest_0;
          $1 = _tail_0;
          $2 = ($$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0));
          continue;
        }
      }
    }
  }
}

function $$$$047constructor$045control$058cooked_read_join_0$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _texts_0 = _tail_0["snd"];
  const _x_0 = ("/" + _texts_0);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _owner_0}, "tail": _rest_0}, "snd": (_text_0 + _x_0)};
}

function $$$$047constructor$045control$058cooked_read_1$(_cooked_0) {
  const _t_0 = _cooked_0["head"];
  const _owner_0 = _t_0["owner"];
  const _rest_0 = _cooked_0["tail"];
  return $$$$047constructor$045control$058cooked_read_join_1$(($$$$047constructor$045control$058value_read$(_owner_0)), ($$$$047constructor$045control$058cooked_read_2$(_rest_0)));
}

function $schema$045a$058raw_0_tail$(_valid_0, _array_0, _text_0, _seen_0) {
  const _tail_0 = _seen_0["fst"];
  const _tailText_0 = _seen_0["snd"];
  const _x_0 = ("/" + _tailText_0);
  const _x_1 = (_text_0 + _x_0);
  const _x_2 = ($Bool$show$(_valid_0));
  const _x_3 = (":" + _x_1);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _valid_0, "owner": _array_0}, "tail": _tail_0}, "snd": (_x_2 + _x_3)};
}

function $schema$045a$058raw_1$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _value_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  return $schema$045a$058raw_1_seen$(_valid_0, _value_0, ($schema$045a$058raw_2$(_tail_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_checked$1264$(_result_0, _fragment_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.BindRejected", "error": _error_0, "fragment": _fragment_0};
  } else {
    const _owners_0 = _fragment_0["owners"];
    return {$: "../../../src/ecs/schema-fragments.Built", "output": ($schema$045a$058provided$(_owners_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, ($$$$047combined$045control$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047combined$045control$058put_a$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_1, ($$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047combined$045control$058recorded$(_world_0, _inverse_0, _queued_0, _undo_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-control.Mail", "context": _context_0, "returned": _items_0, "installed": {$: "Con", "head": {$: "../combined-control.Installed", "inverse": _inverse_0, "queued": _queued_0, "undo": _undo_0}, "tail": _installed_0}, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047fallible$045install$058install$1264$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1264$(($$$$047combined$045control$058install_a$(_world_0, _head_0)), _tail_0);
}

function $$$$047constructor$045stage$058constructed_head$1261$(_tail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../constructor-stage.Constructed") {
    const _head_0 = _t_0["cooked"];
    const _undo_0 = _t_0["undo"];
    return $$$$047constructor$045stage$058constructed_tail$1261$(_head_0, _undo_0, ($$$$047constructor$045control$058stage_3$(_ctx_0, _tail_0)));
  } else {
    const _head_1 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $$$$047constructor$045stage$058invalid_tail$1261$(_head_1, _error_0, ($$$$047constructor$045control$058stage_3$(_ctx_0, _tail_0)));
  }
}

function $$$$047constructor$045control$058constructor_2$(_ctx_0, _raw_0) {
  return $$$$047constructor$045control$058construct$1260$(2, "bad-2", _ctx_0, _raw_0);
}

function $$$$047constructor$045control$058undo$1261$(_cooked_0) {
  const _owner_0 = _cooked_0["owner"];
  return {$: "../constructor-control.Raw", "valid": true, "owner": _owner_0};
}

function $$$$047constructor$045control$058array_restore$(_old0_0, _old1_0, _owner_0) {
  const _x_0 = (_owner_0[0 % _owner_0.length] = _old0_0, _owner_0);
  return (_x_0[1 % _x_0.length] = _old1_0, _x_0);
}

function $$$$047production$045candidate$047transactions$047batch$058remaining$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _tx_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _tx_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047production$045candidate$047transactions$047batch$058staged_after$1261$(_target_0, _payload_0, _next_0, _result_0) {
  const _after_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return run_tail(_next_0(_after_0), ($$$$047prototype$058enqueue$1261$(_before_0, _target_0, _payload_0)));
}

function $$$$047production$045candidate$047transactions$047batch$058preceding$1261$($0, $1, $2) {
  for (;;) {
    {
      const _count_0 = $0;
      const _commands_0 = $1;
      const _tx_0 = $2;
      if (_count_0 === 0) {
        return {$: "Tuple", "fst": _commands_0, "snd": _tx_0};
      } else {
        const _rest_0 = (_count_0 - 1);
        if (_commands_0.$ === "Nil") {
          return {$: "Tuple", "fst": {$: "Nil"}, "snd": _tx_0};
        } else {
          const _command_0 = _commands_0["head"];
          const _tail_0 = _commands_0["tail"];
          $0 = _rest_0;
          $1 = _tail_0;
          $2 = ($$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0));
          continue;
        }
      }
    }
  }
}

function $schema$045b$058raw_0_tail$(_valid_0, _array_0, _text_0, _seen_0) {
  const _tail_0 = _seen_0["fst"];
  const _tailText_0 = _seen_0["snd"];
  const _x_0 = ("/" + _tailText_0);
  const _x_1 = (_text_0 + _x_0);
  const _x_2 = ($Bool$show$(_valid_0));
  const _x_3 = (":" + _x_1);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _valid_0, "owner": _array_0}, "tail": _tail_0}, "snd": (_x_2 + _x_3)};
}

function $schema$045b$058raw_1$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _value_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  return $schema$045b$058raw_1_seen$(_valid_0, _value_0, ($schema$045b$058raw_2$(_tail_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schema$045fragments$058bind_checked$1269$(_result_0, _fragment_0) {
  if (_result_0.$ === "../../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../../src/ecs/schema-fragments.BindRejected", "error": _error_0, "fragment": _fragment_0};
  } else {
    const _owners_0 = _fragment_0["owners"];
    return {$: "../../../src/ecs/schema-fragments.Built", "output": ($schema$045b$058provided$(_owners_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1264$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1264$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1264$(_id_0, _stamp_0, ($$$$047combined$045other$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1261$(($$$$047$$$047$$$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_column$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _allowed_0, _observed_0) {
  if (!_allowed_0) {
    const _column_0 = _observed_0["fst"];
    const _stamp_0 = _observed_0["snd"];
    return {$: "Tuple", "fst": ($$$$047combined$045other$058put_a$(_rest_0, _column_0)), "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/component.SwapRejected", "incoming": {$: "Some", "value": _incoming_0}}, "snd": _stamp_0}};
  } else {
    const _column_1 = _observed_0["fst"];
    const _stamp_1 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_1, ($$$$047$$$047$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, true, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1263$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1263$(_column_1, _id_0)), _id_0, {$: "Some", "value": _incoming_0})))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1263$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1263$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047combined$045other$058recorded$(_world_0, _inverse_0, _queued_0, _undo_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _context_0 = _t_0["context"];
  const _items_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _events_0 = _world_0["events"];
  const _commands_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "../combined-other.Mail", "context": _context_0, "returned": _items_0, "installed": {$: "Con", "head": {$: "../combined-other.Installed", "inverse": _inverse_0, "queued": _queued_0, "undo": _undo_0}, "tail": _installed_0}, "quarantine": _quarantine_0, "errors": _errors_0}, "events": _events_0, "pending": _commands_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047fallible$045install$058install$1269$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1269$(($$$$047combined$045other$058install_a$(_world_0, _head_0)), _tail_0);
}

function $$$$047constructor$045control$058cooked_read_join_1$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _texts_0 = _tail_0["snd"];
  const _x_0 = ("/" + _texts_0);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _owner_0}, "tail": _rest_0}, "snd": (_text_0 + _x_0)};
}

function $$$$047constructor$045control$058value_read$(_owner_0) {
  const _value_0 = _owner_0;
  return {$: "Tuple", "fst": _value_0, "snd": ($U32$show$(_value_0))};
}

function $$$$047constructor$045control$058cooked_read_2$(_cooked_0) {
  const _t_0 = _cooked_0["head"];
  const _owner_0 = _t_0["owner"];
  const _rest_0 = _cooked_0["tail"];
  return $$$$047constructor$045control$058cooked_read_join_2$(($$$$047constructor$045control$058tag_read$(_owner_0)), ($$$$047constructor$045control$058cooked_read_3$(_rest_0)));
}

function $schema$045a$058raw_1_seen$(_valid_0, _value_0, _seen_0) {
  const _tail_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  const _x_0 = ($U32$show$(_value_0));
  const _x_1 = ("/" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = ($Bool$show$(_valid_0));
  const _x_4 = (":" + _x_2);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _valid_0, "owner": _value_0}, "tail": _tail_0}, "snd": (_x_3 + _x_4)};
}

function $schema$045a$058raw_2$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _tag_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  return $schema$045a$058raw_2_seen$(_valid_0, _tag_0, ($schema$045a$058raw_3$(_tail_0)));
}

function $schema$045a$058provided$(_owners_0) {
  const _owner_0 = _owners_0["fst"];
  const _args_0 = _owners_0["snd"];
  return $public$058provide$1260$(_args_0, _owner_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_a$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_world$1260$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, ($$$$047combined$045control$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047combined$045control$058put_a$(_rest_0, _column_0) {
  const _b_0 = _rest_0["b"];
  const _tag_0 = _rest_0["tag"];
  const _value_0 = _rest_0["value"];
  return {$: "../combined-control.Store", "a": _column_0, "b": _b_0, "tag": _tag_0, "value": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1260$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047combined$045control$058put_a$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047fallible$045install$058installed_head$1264$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1264$(_undo_0, ($$$$047combined$045control$058install_1$(_world_2, _tail_0)));
  }
}

function $$$$047combined$045control$058install_a$(_world_0, _entry_0) {
  return $$$$047component$045install$058install$1260$(($$$$047combined$045control$058family_a$()), _world_0, _entry_0);
}

function $$$$047constructor$045stage$058constructed_tail$1261$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../constructor-stage.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../constructor-stage.Valid", "context": _ctx_0, "cooked": {$: "../prototype.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047constructor$045stage$058undo_pack$1261$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_1, "raw": {$: "../prototype.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047constructor$045control$058stage_3$(_ctx_0, _raw_0) {
  return $$$$047constructor$045stage$058stage$1260$(_ctx_0, _raw_0);
}

function $$$$047constructor$045stage$058invalid_tail$1261$(_head_0, _error_0, _tail_0) {
  if (_tail_0.$ === "../constructor-stage.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_0, "raw": {$: "../prototype.Pack", "head": _head_0, "tail": _undo_0(_cooked_0)}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_1, "raw": {$: "../prototype.Pack", "head": _head_0, "tail": _raw_0}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_1}};
  }
}

function $$$$047constructor$045control$058construct$1260$(_slot_0, _error_0, _ctx_0, _raw_0) {
  const _valid_0 = _raw_0["valid"];
  const _owner_0 = _raw_0["owner"];
  return $$$$047constructor$045control$058validated$1260$(($$$$047constructor$045control$058bump$(_ctx_0, _slot_0)), _valid_0, _owner_0, _error_0);
}

function $schema$045b$058raw_1_seen$(_valid_0, _value_0, _seen_0) {
  const _tail_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  const _x_0 = ($U32$show$(_value_0));
  const _x_1 = ("/" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = ($Bool$show$(_valid_0));
  const _x_4 = (":" + _x_2);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _valid_0, "owner": _value_0}, "tail": _tail_0}, "snd": (_x_3 + _x_4)};
}

function $schema$045b$058raw_2$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _tag_0 = _t_0["owner"];
  const _tail_0 = _raw_0["tail"];
  return $schema$045b$058raw_2_seen$(_valid_0, _tag_0, ($schema$045b$058raw_3$(_tail_0)));
}

function $schema$045b$058provided$(_owners_0) {
  const _owner_0 = _owners_0["fst"];
  const _args_0 = _owners_0["snd"];
  return $public$058provide$1261$(_args_0, _owner_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1264$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_a$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1263$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_observed$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_world$1261$(_id_0, _incoming_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, ($$$$047combined$045other$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047combined$045other$058put_a$(_rest_0, _column_0) {
  const _b_0 = _rest_0["b"];
  const _tag_0 = _rest_0["tag"];
  const _value_0 = _rest_0["value"];
  return {$: "../combined-other.Store", "a": _column_0, "b": _b_0, "tag": _tag_0, "value": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058stamped_store_join$1261$(_stamp_0, _result_0) {
  const _store_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _store_0, "snd": {$: "Tuple", "fst": _outcome_0, "snd": _stamp_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1264$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047combined$045other$058put_a$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap$1263$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure$1263$(_column_0, _target_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1263$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1263$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1263$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047fallible$045install$058installed_head$1269$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1269$(_undo_0, ($$$$047combined$045other$058install_1$(_world_2, _tail_0)));
  }
}

function $$$$047combined$045other$058install_a$(_world_0, _entry_0) {
  return $$$$047component$045install$058install$1264$(($$$$047combined$045other$058family_a$()), _world_0, _entry_0);
}

function $$$$047constructor$045control$058cooked_read_join_2$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _texts_0 = _tail_0["snd"];
  const _x_0 = ("/" + _texts_0);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _owner_0}, "tail": _rest_0}, "snd": (_text_0 + _x_0)};
}

function $$$$047constructor$045control$058tag_read$(_owner_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": "tag"};
}

function $$$$047constructor$045control$058cooked_read_3$(_cooked_0) {
  const _t_0 = _cooked_0["head"];
  const _owner_0 = _t_0["owner"];
  const _rest_0 = _cooked_0["tail"];
  return $$$$047constructor$045control$058cooked_read_join_3$(($$$$047constructor$045control$058queue_read$(_owner_0)), ($$$$047constructor$045control$058cooked_read_4$(_rest_0)));
}

function $schema$045a$058raw_2_seen$(_valid_0, _tag_0, _seen_0) {
  const _tail_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  const _x_0 = ($Bool$show$(_valid_0));
  const _x_1 = (":tag/" + _text_0);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _valid_0, "owner": _tag_0}, "tail": _tail_0}, "snd": (_x_0 + _x_1)};
}

function $schema$045a$058raw_3$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _owner_0 = _t_0["owner"];
  const _t_1 = _raw_0["tail"];
  return $schema$045a$058raw_3_seen$(_valid_0, ($$$$047constructor$045control$058queue_read$(_owner_0)));
}

function $public$058provide$1260$(_args_0, _ctx_0) {
  return $schema$045a$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_store$1260$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_a$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047fallible$045install$058installed_tail$1264$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1264$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1264$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045control$058install_1$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1263$(_world_0, _tail_0);
}

function $$$$047component$045install$058install$1260$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047component$045install$058stamped$1260$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0)));
}

function $$$$047constructor$045stage$058undo_pack$1261$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../prototype.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047constructor$045stage$058stage$1260$(_ctx_0, _raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047constructor$045stage$058constructed_head$1260$(_tail_0, ($$$$047constructor$045control$058constructor_3$(_ctx_0, _head_0)));
}

function $$$$047constructor$045control$058validated$1260$(_ctx_0, _valid_0, _owner_0, _error_0) {
  if (_valid_0) {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../constructor-stage.Constructed", "cooked": {$: "../constructor-control.Cooked", "owner": _owner_0}, "undo": run_clo((_x_0) => {
  return $$$$047constructor$045control$058undo$1260$(_x_0);
})}};
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../constructor-stage.Invalid", "raw": {$: "../constructor-control.Raw", "valid": false, "owner": _owner_0}, "error": _error_0}};
  }
}

function $schema$045b$058raw_2_seen$(_valid_0, _tag_0, _seen_0) {
  const _tail_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  const _x_0 = ($Bool$show$(_valid_0));
  const _x_1 = (":tag/" + _text_0);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _valid_0, "owner": _tag_0}, "tail": _tail_0}, "snd": (_x_0 + _x_1)};
}

function $schema$045b$058raw_3$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _valid_0 = _t_0["valid"];
  const _owner_0 = _t_0["owner"];
  const _t_1 = _raw_0["tail"];
  return $schema$045b$058raw_3_seen$(_valid_0, ($$$$047constructor$045control$058queue_read$(_owner_0)));
}

function $public$058provide$1261$(_args_0, _ctx_0) {
  return $schema$045b$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1263$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1263$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1263$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1263$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_store$1261$(_id_0, _incoming_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1263$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1263$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1264$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_a$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1263$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1263$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1263$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1263$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1263$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1263$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1263$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047fallible$045install$058installed_tail$1269$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1269$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1269$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045other$058install_1$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1268$(_world_0, _tail_0);
}

function $$$$047component$045install$058install$1264$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047component$045install$058stamped$1264$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1264$(_family_0, _world_0, _handle_0)));
}

function $$$$047constructor$045control$058cooked_read_join_3$(_head_0, _tail_0) {
  const _owner_0 = _head_0["fst"];
  const _text_0 = _head_0["snd"];
  const _rest_0 = _tail_0["fst"];
  const _texts_0 = _tail_0["snd"];
  const _x_0 = ("/" + _texts_0);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Cooked", "owner": _owner_0}, "tail": _rest_0}, "snd": (_text_0 + _x_0)};
}

function $$$$047constructor$045control$058queue_read$(_owner_0) {
  const _front_0 = _owner_0["front"];
  const _back_0 = _owner_0["back"];
  const _queued_0 = _owner_0["queued"];
  return $$$$047constructor$045control$058queue_read_join$(($$$$047constructor$045control$058array_read$(_front_0)), ($$$$047constructor$045control$058array_read$(_back_0)), ($$$$047constructor$045control$058list_read$(_queued_0)));
}

function $$$$047constructor$045control$058cooked_read_4$(_cooked_0) {
  return {$: "Tuple", "fst": _cooked_0, "snd": "end"};
}

function $schema$045a$058raw_3_seen$(_valid_0, _seen_0) {
  const _owner_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  const _x_0 = (_text_0 + "/end");
  const _x_1 = ($Bool$show$(_valid_0));
  const _x_2 = (":" + _x_0);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _valid_0, "owner": _owner_0}, "tail": {$: "Unit"}}, "snd": (_x_1 + _x_2)};
}

function $schema$045a$058body$1260$(_args_0, _ctx_0) {
  const _input_0 = _args_0["input"];
  const _target_0 = _args_0["retryTarget"];
  const _retry_0 = _args_0["retry"];
  return $schema$045a$058requested$1260$(_target_0, _retry_0, run_loop($public$058apply$1260$(_ctx_0, _input_0)));
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1260$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047combined$045control$058put_a$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047combined$045control$058put_a$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../src/ecs/column.Indexed", "state": {$: "../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047fallible$045install$058refused_head$1264$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1264$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1264$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058install$1263$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1263$(($$$$047combined$045control$058install_a$(_world_0, _head_0)), _tail_0);
}

function $$$$047component$045install$058stamped$1260$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047component$045install$058replaced$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1260$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047constructor$045stage$058constructed_head$1260$(_tail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../constructor-stage.Constructed") {
    const _head_0 = _t_0["cooked"];
    const _undo_0 = _t_0["undo"];
    return $$$$047constructor$045stage$058constructed_tail$1260$(_head_0, _undo_0, ($$$$047constructor$045control$058stage_4$(_ctx_0, _tail_0)));
  } else {
    const _head_1 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $$$$047constructor$045stage$058invalid_tail$1260$(_head_1, _error_0, ($$$$047constructor$045control$058stage_4$(_ctx_0, _tail_0)));
  }
}

function $$$$047constructor$045control$058constructor_3$(_ctx_0, _raw_0) {
  return $$$$047constructor$045control$058queue_construct$(_ctx_0, _raw_0);
}

function $$$$047constructor$045control$058undo$1260$(_cooked_0) {
  const _owner_0 = _cooked_0["owner"];
  return {$: "../constructor-control.Raw", "valid": true, "owner": _owner_0};
}

function $schema$045b$058raw_3_seen$(_valid_0, _seen_0) {
  const _owner_0 = _seen_0["fst"];
  const _text_0 = _seen_0["snd"];
  const _x_0 = (_text_0 + "/end");
  const _x_1 = ($Bool$show$(_valid_0));
  const _x_2 = (":" + _x_0);
  return {$: "Tuple", "fst": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": _valid_0, "owner": _owner_0}, "tail": {$: "Unit"}}, "snd": (_x_1 + _x_2)};
}

function $schema$045b$058body$1260$(_args_0, _ctx_0) {
  const _input_0 = _args_0["input"];
  const _target_0 = _args_0["retryTarget"];
  const _retry_0 = _args_0["retry"];
  return $schema$045b$058requested$1260$(_target_0, _retry_0, run_loop($public$058apply$1261$(_ctx_0, _input_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1263$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1263$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1263$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_swap$1261$(_rest_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047combined$045other$058put_a$(_rest_0, _column_0)), "snd": {$: "Unit"}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": ($$$$047combined$045other$058put_a$(_rest_0, _column_1)), "snd": {$: "Unit"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1263$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058swapped$1263$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1263$({$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058seek$1263$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1263$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1263$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1263$({$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1263$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058grow$1263$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1263$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0) {
  return {$: "../../../src/ecs/column.Indexed", "state": {$: "../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047fallible$045install$058refused_head$1269$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1269$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1269$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058install$1268$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1268$(($$$$047combined$045other$058install_a$(_world_0, _head_0)), _tail_0);
}

function $$$$047component$045install$058stamped$1264$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047component$045install$058replaced$1264$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058replace$1264$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1264$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1264$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0);
}

function $$$$047constructor$045control$058queue_read_join$(_front_0, _back_0, _queued_0) {
  const _a_0 = _front_0["fst"];
  const _ta_0 = _front_0["snd"];
  const _b_0 = _back_0["fst"];
  const _tb_0 = _back_0["snd"];
  const _q_0 = _queued_0["fst"];
  const _tq_0 = _queued_0["snd"];
  const _x_0 = ($List$show$1261$(_tq_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_tb_0 + _x_1);
  const _x_3 = (":" + _x_2);
  return {$: "Tuple", "fst": {$: "../constructor-control.QueueOwner", "front": _a_0, "back": _b_0, "queued": _q_0}, "snd": (_ta_0 + _x_3)};
}

function $schema$045a$058requested$1260$(_target_0, _retry_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "adapter.Accepted") {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "schema-a.GameResult", "result": {$: "adapter.Accepted"}, "first": {$: "None"}, "returned": ""}};
  } else {
    const _raw_0 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $schema$045a$058retry_seen$1260$(_ctx_0, _target_0, _retry_0, _error_0, ($schema$045a$058raw_0$(_raw_0)));
  }
}

function $public$058apply$1260$(_ctx_0, _input_0) {
  return run_tail(($public$058request_field$1260$({$: "public.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $schema$045a$058request$(_x_0, _x_1);
});
})}))(_ctx_0), _input_0);
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047fallible$045install$058restored_head$1264$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058installed_head$1263$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1263$(_undo_0, ($$$$047combined$045control$058install_2$(_world_2, _tail_0)));
  }
}

function $$$$047component$045install$058replaced$1260$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../fallible-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047component$045install$058undo$1260$({$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0);
  }
}

function $$$$047constructor$045stage$058constructed_tail$1260$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../constructor-stage.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../constructor-stage.Valid", "context": _ctx_0, "cooked": {$: "../prototype.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047constructor$045stage$058undo_pack$1260$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_1, "raw": {$: "../prototype.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047constructor$045control$058stage_4$(_ctx_0, _raw_0) {
  return $$$$047constructor$045stage$058terminal$1260$(_ctx_0, _raw_0);
}

function $$$$047constructor$045stage$058invalid_tail$1260$(_head_0, _error_0, _tail_0) {
  if (_tail_0.$ === "../constructor-stage.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_0, "raw": {$: "../prototype.Pack", "head": _head_0, "tail": _undo_0(_cooked_0)}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../constructor-stage.Failed", "context": _ctx_1, "raw": {$: "../prototype.Pack", "head": _head_0, "tail": _raw_0}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_1}};
  }
}

function $$$$047constructor$045control$058queue_construct$(_ctx_0, _raw_0) {
  const _valid_0 = _raw_0["valid"];
  const _owner_0 = _raw_0["owner"];
  return $$$$047constructor$045control$058queue_valid$(($$$$047constructor$045control$058bump$(_ctx_0, 3)), _valid_0, _owner_0);
}

function $schema$045b$058requested$1260$(_target_0, _retry_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "adapter.Accepted") {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "schema-b.GameResult", "result": {$: "adapter.Accepted"}, "first": {$: "None"}, "returned": ""}};
  } else {
    const _raw_0 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $schema$045b$058retry_seen$1260$(_ctx_0, _target_0, _retry_0, _error_0, ($schema$045b$058raw_0$(_raw_0)));
  }
}

function $public$058apply$1261$(_ctx_0, _input_0) {
  return run_tail(($public$058request_field$1261$({$: "public.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $schema$045b$058request$(_x_0, _x_1);
});
})}))(_ctx_0), _input_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swapped$1263$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_0)));
  } else {
    return {$: "../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover$1263$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1263$(($$$$047$$$047$$$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1263$(($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek$1263$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1263$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1263$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1263$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058grow$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1263$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1263$(_column_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1263$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1263$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047fallible$045install$058restored_head$1269$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058installed_head$1268$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1268$(_undo_0, ($$$$047combined$045other$058install_2$(_world_2, _tail_0)));
  }
}

function $$$$047component$045install$058replaced$1264$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../fallible-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047component$045install$058undo$1264$({$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace$1264$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1264$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1264$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1264$(_id_0, _world_0);
  }
}

function $schema$045a$058retry_seen$1260$(_ctx_0, _target_0, _retry_0, _error_0, _seen_0) {
  if (!_retry_0) {
    const _raw_0 = _seen_0["fst"];
    const _text_0 = _seen_0["snd"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "schema-a.GameResult", "result": {$: "adapter.Refused", "raw": _raw_0, "error": _error_0}, "first": {$: "Some", "value": _error_0}, "returned": _text_0}};
  } else {
    const _raw_1 = _seen_0["fst"];
    const _text_1 = _seen_0["snd"];
    return $schema$045a$058retry_done$1260$(_error_0, _text_1, run_loop($public$058apply$1260$(_ctx_0, {$: "adapter.Input", "target": _target_0, "raw": ($schema$045a$058repaired$(_raw_1))})));
  }
}

function $public$058request_field$1260$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $schema$045a$058request$(_owner_0, _input_0) {
  return $adapter$058request$1260$(_owner_0, _input_0);
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047fallible$045install$058installed_tail$1263$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1263$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1263$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045control$058install_2$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1262$(_world_0, _tail_0);
}

function $$$$047component$045install$058undo$1260$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047component$045install$058undo_checked$1260$({$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, ($$$$047combined$045control$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047constructor$045stage$058undo_pack$1260$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../prototype.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047constructor$045stage$058terminal$1260$(_ctx_0, _raw_0) {
  return {$: "../constructor-stage.Valid", "context": _ctx_0, "cooked": {$: "Unit"}, "undo": run_clo((_x_0) => {
  return _x_0;
}), "positions": {$: "Nil"}};
}

function $$$$047constructor$045control$058queue_valid$(_ctx_0, _valid_0, _owner_0) {
  if (_valid_0) {
    const _front_0 = _owner_0["front"];
    const _back_0 = _owner_0["back"];
    const _queued_0 = _owner_0["queued"];
    return $$$$047constructor$045control$058queue_changed$(_ctx_0, ($$$$047constructor$045control$058array_change$(_front_0)), ($$$$047constructor$045control$058array_change$(_back_0)), _queued_0);
  } else {
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../constructor-stage.Invalid", "raw": {$: "../constructor-control.Raw", "valid": false, "owner": _owner_0}, "error": "bad-3"}};
  }
}

function $schema$045b$058retry_seen$1260$(_ctx_0, _target_0, _retry_0, _error_0, _seen_0) {
  if (!_retry_0) {
    const _raw_0 = _seen_0["fst"];
    const _text_0 = _seen_0["snd"];
    return {$: "Tuple", "fst": _ctx_0, "snd": {$: "schema-b.GameResult", "result": {$: "adapter.Refused", "raw": _raw_0, "error": _error_0}, "first": {$: "Some", "value": _error_0}, "returned": _text_0}};
  } else {
    const _raw_1 = _seen_0["fst"];
    const _text_1 = _seen_0["snd"];
    return $schema$045b$058retry_done$1260$(_error_0, _text_1, run_loop($public$058apply$1261$(_ctx_0, {$: "adapter.Input", "target": _target_0, "raw": ($schema$045b$058repaired$(_raw_1))})));
  }
}

function $public$058request_field$1261$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $schema$045b$058request$(_owner_0, _input_0) {
  return $adapter$058request$1261$(_owner_0, _input_0);
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1263$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1263$(_target_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047fallible$045install$058installed_tail$1268$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1268$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1268$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045other$058install_2$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1267$(_world_0, _tail_0);
}

function $$$$047component$045install$058undo$1264$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047component$045install$058undo_checked$1264$({$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1264$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1264$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1264$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1264$(_id_0, ($$$$047combined$045other$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $schema$045a$058retry_done$1260$(_first_0, _returned_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _out_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "schema-a.GameResult", "result": _out_0, "first": {$: "Some", "value": _first_0}, "returned": _returned_0}};
}

function $schema$045a$058repaired$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _a_0 = _t_0["owner"];
  const _t_1 = _raw_0["tail"];
  const _t_2 = _t_1["head"];
  const _v_0 = _t_2["owner"];
  const _t_3 = _t_1["tail"];
  const _t_4 = _t_3["head"];
  const _tag_0 = _t_4["owner"];
  const _t_5 = _t_3["tail"];
  const _t_6 = _t_5["head"];
  const _queue_0 = _t_6["owner"];
  const _t_7 = _t_5["tail"];
  return {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": _a_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": _v_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": _tag_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": _queue_0}, "tail": {$: "Unit"}}}}};
}

function $adapter$058request$1260$(_owner_0, _input_0) {
  const _batch_0 = _owner_0["batch"];
  const _context_0 = _owner_0["context"];
  const _target_0 = _input_0["target"];
  const _raw_0 = _input_0["raw"];
  return $adapter$058constructed$1260$(_batch_0, _target_0, ($$$$047constructor$045control$058stage_0$(_context_0, _raw_0)));
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047fallible$045install$058refused_head$1263$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1263$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1263$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058install$1262$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1262$(($$$$047combined$045control$058install_b$(_world_0, _head_0)), _tail_0);
}

function $$$$047component$045install$058undo_checked$1260$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047component$045install$058undo_present$1260$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047constructor$045control$058queue_changed$(_ctx_0, _front_0, _back_0, _queued_0) {
  const _a_0 = _front_0["fst"];
  const _restoreA_0 = _front_0["snd"];
  const _b_0 = _back_0["fst"];
  const _restoreB_0 = _back_0["snd"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "../constructor-stage.Constructed", "cooked": {$: "../constructor-control.Cooked", "owner": {$: "../constructor-control.QueueOwner", "front": _a_0, "back": _b_0, "queued": _queued_0}}, "undo": run_clo((_x_0) => {
  return $$$$047constructor$045control$058queue_restore$(_restoreA_0, _restoreB_0, _x_0);
})}};
}

function $schema$045b$058retry_done$1260$(_first_0, _returned_0, _result_0) {
  const _ctx_0 = _result_0["fst"];
  const _out_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _ctx_0, "snd": {$: "schema-b.GameResult", "result": _out_0, "first": {$: "Some", "value": _first_0}, "returned": _returned_0}};
}

function $schema$045b$058repaired$(_raw_0) {
  const _t_0 = _raw_0["head"];
  const _a_0 = _t_0["owner"];
  const _t_1 = _raw_0["tail"];
  const _t_2 = _t_1["head"];
  const _v_0 = _t_2["owner"];
  const _t_3 = _t_1["tail"];
  const _t_4 = _t_3["head"];
  const _tag_0 = _t_4["owner"];
  const _t_5 = _t_3["tail"];
  const _t_6 = _t_5["head"];
  const _queue_0 = _t_6["owner"];
  const _t_7 = _t_5["tail"];
  return {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": _a_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": _v_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": _tag_0}, "tail": {$: "../prototype.Pack", "head": {$: "../constructor-control.Raw", "valid": true, "owner": _queue_0}, "tail": {$: "Unit"}}}}};
}

function $adapter$058request$1261$(_owner_0, _input_0) {
  const _batch_0 = _owner_0["batch"];
  const _context_0 = _owner_0["context"];
  const _target_0 = _input_0["target"];
  const _raw_0 = _input_0["raw"];
  return $adapter$058constructed$1261$(_batch_0, _target_0, ($$$$047constructor$045control$058stage_0$(_context_0, _raw_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1263$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1263$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1263$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1263$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1263$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047fallible$045install$058refused_head$1268$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1268$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1268$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058install$1267$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1267$(($$$$047combined$045other$058install_b$(_world_0, _head_0)), _tail_0);
}

function $$$$047component$045install$058undo_checked$1264$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047component$045install$058undo_present$1264$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1264$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1264$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1264$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1264$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1263$(_column_0, _id_0)));
}

function $adapter$058constructed$1260$(_batch_0, _target_0, _result_0) {
  if (_result_0.$ === "../constructor-stage.Failed") {
    const _context_0 = _result_0["context"];
    const _raw_0 = _result_0["raw"];
    const _positions_0 = _result_0["positions"];
    return {$: "Tuple", "fst": {$: "adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "adapter.Refused", "raw": _raw_0, "error": {$: "adapter.ConstructionRefused", "positions": _positions_0}}};
  } else {
    const _context_1 = _result_0["context"];
    const _cooked_0 = _result_0["cooked"];
    const _undo_0 = _result_0["undo"];
    return $adapter$058inserted$1260$(_context_1, ($$$$047production$045candidate$047transactions$047batch$058insert$1260$(_batch_0, _target_0, ($schema$045a$058pack$(_cooked_0, _undo_0)))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047fallible$045install$058restored_head$1263$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058installed_head$1262$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1262$(_undo_0, ($$$$047combined$045control$058install_3$(_world_2, _tail_0)));
  }
}

function $$$$047combined$045control$058install_b$(_world_0, _entry_0) {
  return $$$$047component$045install$058install$1261$(($$$$047combined$045control$058family_b$()), _world_0, _entry_0);
}

function $$$$047component$045install$058undo_present$1260$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047component$045install$058undone$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_a$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047constructor$045control$058queue_restore$(_front_0, _back_0, _cooked_0) {
  const _t_0 = _cooked_0["owner"];
  const _a_0 = _t_0["front"];
  const _b_0 = _t_0["back"];
  const _queued_0 = _t_0["queued"];
  return {$: "../constructor-control.Raw", "valid": true, "owner": {$: "../constructor-control.QueueOwner", "front": _front_0(_a_0), "back": _back_0(_b_0), "queued": _queued_0}};
}

function $adapter$058constructed$1261$(_batch_0, _target_0, _result_0) {
  if (_result_0.$ === "../constructor-stage.Failed") {
    const _context_0 = _result_0["context"];
    const _raw_0 = _result_0["raw"];
    const _positions_0 = _result_0["positions"];
    return {$: "Tuple", "fst": {$: "adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "adapter.Refused", "raw": _raw_0, "error": {$: "adapter.ConstructionRefused", "positions": _positions_0}}};
  } else {
    const _context_1 = _result_0["context"];
    const _cooked_0 = _result_0["cooked"];
    const _undo_0 = _result_0["undo"];
    return $adapter$058inserted$1261$(_context_1, ($$$$047production$045candidate$047transactions$047batch$058insert$1261$(_batch_0, _target_0, ($schema$045b$058pack$(_cooked_0, _undo_0)))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_past$1263$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047fallible$045install$058restored_head$1268$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058installed_head$1267$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1267$(_undo_0, ($$$$047combined$045other$058install_3$(_world_2, _tail_0)));
  }
}

function $$$$047combined$045other$058install_b$(_world_0, _entry_0) {
  return $$$$047component$045install$058install$1265$(($$$$047combined$045other$058family_b$()), _world_0, _entry_0);
}

function $$$$047component$045install$058undo_present$1264$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047component$045install$058undone$1264$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1264$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1264$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1264$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_a$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $adapter$058inserted$1260$(_context_0, _result_0) {
  if (_result_0.$ === "../production-candidate/transactions/batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "Tuple", "fst": {$: "adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "adapter.Accepted"}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _packet_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "adapter.Owner", "batch": _batch_1, "context": _context_0}, "snd": {$: "adapter.Refused", "raw": run_loop($schema$045a$058unpack$(_packet_0)), "error": {$: "adapter.EntityRefused", "error": _error_0}}};
  }
}

function $$$$047production$045candidate$047transactions$047batch$058insert$1260$(_batch_0, _target_0, _payload_0) {
  const _t_0 = _batch_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047production$045candidate$047transactions$047batch$058checked$1260$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $schema$045a$058pack$(_cooked_0, _undo_0) {
  return {$: "../combined-control.Packet", "cooked": _cooked_0, "undo": _undo_0};
}

function $$$$047fallible$045install$058installed_tail$1262$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1262$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1262$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045control$058install_3$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1261$(_world_0, _tail_0);
}

function $$$$047component$045install$058install$1261$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047component$045install$058stamped$1261$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1261$(_family_0, _world_0, _handle_0)));
}

function $$$$047combined$045control$058family_b$() {
  return {$: "../../../src/ecs/component.Family", "name": "b"};
}

function $$$$047component$045install$058undone$1260$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../fallible-install.Restored", "world": ($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047combined$045control$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1260$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $adapter$058inserted$1261$(_context_0, _result_0) {
  if (_result_0.$ === "../production-candidate/transactions/batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "Tuple", "fst": {$: "adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "adapter.Accepted"}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _packet_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "adapter.Owner", "batch": _batch_1, "context": _context_0}, "snd": {$: "adapter.Refused", "raw": run_loop($schema$045b$058unpack$(_packet_0)), "error": {$: "adapter.EntityRefused", "error": _error_0}}};
  }
}

function $$$$047production$045candidate$047transactions$047batch$058insert$1261$(_batch_0, _target_0, _payload_0) {
  const _t_0 = _batch_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047production$045candidate$047transactions$047batch$058checked$1261$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)));
}

function $schema$045b$058pack$(_cooked_0, _undo_0) {
  return {$: "../combined-other.Packet", "cooked": _cooked_0, "undo": _undo_0};
}

function $$$$047fallible$045install$058installed_tail$1267$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1267$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1267$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045other$058install_3$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1266$(_world_0, _tail_0);
}

function $$$$047component$045install$058install$1265$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047component$045install$058stamped$1265$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1265$(_family_0, _world_0, _handle_0)));
}

function $$$$047combined$045other$058family_b$() {
  return {$: "../../../src/ecs/component.Family", "name": "b"};
}

function $$$$047component$045install$058undone$1264$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../fallible-install.Restored", "world": ($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1264$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047combined$045other$058take_a$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1264$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1264$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $schema$045a$058unpack$(_packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return run_tail(_undo_0, _cooked_0);
}

function $$$$047production$045candidate$047transactions$047batch$058checked$1260$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047production$045candidate$047transactions$047batch$058receipt_checked$1260$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047production$045candidate$047transactions$047batch$058receipt_find$1260$(_prepared_0, _target_0)));
  } else {
    return $$$$047production$045candidate$047transactions$047batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047production$045candidate$047transactions$047batch$058count_commands$1260$(_commands_0)));
  }
}

function $$$$047fallible$045install$058refused_head$1262$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1262$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1262$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058install$1261$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1261$(($$$$047combined$045control$058install_tag$(_world_0, _head_0)), _tail_0);
}

function $$$$047component$045install$058stamped$1261$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047component$045install$058replaced$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1261$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1261$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $schema$045b$058unpack$(_packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return run_tail(_undo_0, _cooked_0);
}

function $$$$047production$045candidate$047transactions$047batch$058checked$1261$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047production$045candidate$047transactions$047batch$058receipt_checked$1261$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047production$045candidate$047transactions$047batch$058receipt_find$1261$(_prepared_0, _target_0)));
  } else {
    return $$$$047production$045candidate$047transactions$047batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047production$045candidate$047transactions$047batch$058count_commands$1261$(_commands_0)));
  }
}

function $$$$047fallible$045install$058refused_head$1267$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1267$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1267$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058install$1266$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1266$(($$$$047combined$045other$058install_tag$(_world_0, _head_0)), _tail_0);
}

function $$$$047component$045install$058stamped$1265$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047component$045install$058replaced$1265$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058replace$1265$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1265$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1265$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1264$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1264$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1263$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1263$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1264$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047production$045candidate$047transactions$047batch$058receipt_checked$1260$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _result_0) {
  const _prepared_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../production-candidate/transactions/batch.Refused", "batch": {$: "../production-candidate/transactions/batch.Batch", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047production$045candidate$047transactions$047batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047production$045candidate$047transactions$047batch$058count_commands$1260$(_commands_0)));
  }
}

function $$$$047production$045candidate$047transactions$047batch$058receipt_find$1260$(_prepared_0, _target_0) {
  if (_prepared_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": false};
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../production-candidate/transactions/batch.Prepared") {
      const _handle_0 = _t_0["target"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _tail_0 = _prepared_0["tail"];
      return $$$$047production$045candidate$047transactions$047batch$058receipt_join$1260$({$: "../production-candidate/transactions/batch.Prepared", "target": _handle_0, "payload": _payload_0, "position": _position_0}, false, ($$$$047production$045candidate$047transactions$047batch$058receipt_find$1260$(_tail_0, _target_0)));
    } else {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _tail_1 = _prepared_0["tail"];
      const _otherNs_0 = _target_0["namespace"];
      const _otherId_0 = _target_0["id"];
      return $$$$047production$045candidate$047transactions$047batch$058receipt_join$1260$({$: "../production-candidate/transactions/batch.ReservationReceipt", "target": {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}}, ($Bool$and$((_ns_0 === _otherNs_0), (_id_0 === _otherId_0))), ($$$$047production$045candidate$047transactions$047batch$058receipt_find$1260$(_tail_1, {$: "../../../src/ecs/world.Handle", "namespace": _otherNs_0, "id": _otherId_0})));
    }
  }
}

function $$$$047production$045candidate$047transactions$047batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "../production-candidate/transactions/batch.Inserted", "batch": {$: "../production-candidate/transactions/batch.Batch", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": {$: "Con", "head": {$: "../production-candidate/transactions/batch.Prepared", "target": _target_0, "payload": _payload_0, "position": _position_0}, "tail": _prepared_0}}};
}

function $$$$047production$045candidate$047transactions$047batch$058count_commands$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047production$045candidate$047transactions$047batch$058counted$1260$(_command_0, ($$$$047production$045candidate$047transactions$047batch$058count_commands$1260$(_tail_0)));
  }
}

function $$$$047fallible$045install$058restored_head$1262$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058installed_head$1261$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1261$(_undo_0, ($$$$047combined$045control$058install_4$(_world_2, _tail_0)));
  }
}

function $$$$047combined$045control$058install_tag$(_world_0, _entry_0) {
  return $$$$047component$045install$058install$1262$(($$$$047combined$045control$058family_tag$()), _world_0, _entry_0);
}

function $$$$047component$045install$058replaced$1261$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../fallible-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047component$045install$058undo$1261$({$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1261$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0);
  }
}

function $$$$047production$045candidate$047transactions$047batch$058receipt_checked$1261$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _result_0) {
  const _prepared_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../production-candidate/transactions/batch.Refused", "batch": {$: "../production-candidate/transactions/batch.Batch", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047production$045candidate$047transactions$047batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047production$045candidate$047transactions$047batch$058count_commands$1261$(_commands_0)));
  }
}

function $$$$047production$045candidate$047transactions$047batch$058receipt_find$1261$(_prepared_0, _target_0) {
  if (_prepared_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": false};
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../production-candidate/transactions/batch.Prepared") {
      const _handle_0 = _t_0["target"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _tail_0 = _prepared_0["tail"];
      return $$$$047production$045candidate$047transactions$047batch$058receipt_join$1261$({$: "../production-candidate/transactions/batch.Prepared", "target": _handle_0, "payload": _payload_0, "position": _position_0}, false, ($$$$047production$045candidate$047transactions$047batch$058receipt_find$1261$(_tail_0, _target_0)));
    } else {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _tail_1 = _prepared_0["tail"];
      const _otherNs_0 = _target_0["namespace"];
      const _otherId_0 = _target_0["id"];
      return $$$$047production$045candidate$047transactions$047batch$058receipt_join$1261$({$: "../production-candidate/transactions/batch.ReservationReceipt", "target": {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}}, ($Bool$and$((_ns_0 === _otherNs_0), (_id_0 === _otherId_0))), ($$$$047production$045candidate$047transactions$047batch$058receipt_find$1261$(_tail_1, {$: "../../../src/ecs/world.Handle", "namespace": _otherNs_0, "id": _otherId_0})));
    }
  }
}

function $$$$047production$045candidate$047transactions$047batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "../production-candidate/transactions/batch.Inserted", "batch": {$: "../production-candidate/transactions/batch.Batch", "tx": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": {$: "Con", "head": {$: "../production-candidate/transactions/batch.Prepared", "target": _target_0, "payload": _payload_0, "position": _position_0}, "tail": _prepared_0}}};
}

function $$$$047production$045candidate$047transactions$047batch$058count_commands$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047production$045candidate$047transactions$047batch$058counted$1261$(_command_0, ($$$$047production$045candidate$047transactions$047batch$058count_commands$1261$(_tail_0)));
  }
}

function $$$$047fallible$045install$058restored_head$1267$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058installed_head$1266$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1266$(_undo_0, ($$$$047combined$045other$058install_4$(_world_2, _tail_0)));
  }
}

function $$$$047combined$045other$058install_tag$(_world_0, _entry_0) {
  return $$$$047component$045install$058install$1266$(($$$$047combined$045other$058family_tag$()), _world_0, _entry_0);
}

function $$$$047component$045install$058replaced$1265$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../fallible-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047component$045install$058undo$1265$({$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace$1265$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1265$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1265$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1265$(_id_0, _world_0);
  }
}

function $$$$047production$045candidate$047transactions$047batch$058receipt_join$1260$(_entry_0, _seen_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _found_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _tail_0}, "snd": (_seen_0 || _found_0)};
}

function $$$$047production$045candidate$047transactions$047batch$058counted$1260$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047fallible$045install$058installed_tail$1261$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1261$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1261$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045control$058install_4$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1260$(_world_0, _tail_0);
}

function $$$$047component$045install$058install$1262$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047component$045install$058stamped$1262$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1262$(_family_0, _world_0, _handle_0)));
}

function $$$$047combined$045control$058family_tag$() {
  return {$: "../../../src/ecs/component.Family", "name": "tag"};
}

function $$$$047component$045install$058undo$1261$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047component$045install$058undo_checked$1261$({$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, ($$$$047combined$045control$058take_b$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047production$045candidate$047transactions$047batch$058receipt_join$1261$(_entry_0, _seen_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _found_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _tail_0}, "snd": (_seen_0 || _found_0)};
}

function $$$$047production$045candidate$047transactions$047batch$058counted$1261$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047fallible$045install$058installed_tail$1266$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1266$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1266$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045other$058install_4$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058install$1265$(_world_0, _tail_0);
}

function $$$$047component$045install$058install$1266$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047component$045install$058stamped$1266$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1266$(_family_0, _world_0, _handle_0)));
}

function $$$$047combined$045other$058family_tag$() {
  return {$: "../../../src/ecs/component.Family", "name": "tag"};
}

function $$$$047component$045install$058undo$1265$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047component$045install$058undo_checked$1265$({$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1265$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1265$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1265$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1265$(_id_0, ($$$$047combined$045other$058take_b$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047fallible$045install$058refused_head$1261$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1261$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1261$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058install$1260$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1260$(($$$$047combined$045control$058install_value$(_world_0, _head_0)), _tail_0);
}

function $$$$047component$045install$058stamped$1262$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047component$045install$058replaced$1262$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1262$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1262$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047component$045install$058undo_checked$1261$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047component$045install$058undo_present$1261$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047combined$045control$058take_b$(_store_0) {
  const _a_0 = _store_0["a"];
  const _b_0 = _store_0["b"];
  const _tag_0 = _store_0["tag"];
  const _value_0 = _store_0["value"];
  return {$: "Tuple", "fst": {$: "../combined-control.Rest_b", "a": _a_0, "tag": _tag_0, "value": _value_0}, "snd": _b_0};
}

function $$$$047fallible$045install$058refused_head$1266$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1266$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1266$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058install$1265$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047fallible$045install$058installed_head$1265$(($$$$047combined$045other$058install_value$(_world_0, _head_0)), _tail_0);
}

function $$$$047component$045install$058stamped$1266$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047component$045install$058replaced$1266$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058replace$1266$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1266$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1266$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0);
}

function $$$$047component$045install$058undo_checked$1265$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047component$045install$058undo_present$1265$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1265$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1265$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1265$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1265$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1263$(_column_0, _id_0)));
}

function $$$$047combined$045other$058take_b$(_store_0) {
  const _a_0 = _store_0["a"];
  const _b_0 = _store_0["b"];
  const _tag_0 = _store_0["tag"];
  const _value_0 = _store_0["value"];
  return {$: "Tuple", "fst": {$: "../combined-other.Rest_b", "a": _a_0, "tag": _tag_0, "value": _value_0}, "snd": _b_0};
}

function $$$$047fallible$045install$058restored_head$1261$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058installed_head$1260$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1260$(_undo_0, ($$$$047combined$045control$058install_5$(_world_2, _tail_0)));
  }
}

function $$$$047combined$045control$058install_value$(_world_0, _entry_0) {
  return $$$$047component$045install$058install$1263$(($$$$047combined$045control$058family_value$()), _world_0, _entry_0);
}

function $$$$047component$045install$058replaced$1262$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../fallible-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047component$045install$058undo$1262$({$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1262$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1262$(_id_0, _world_0);
  }
}

function $$$$047component$045install$058undo_present$1261$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047component$045install$058undone$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_b$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047fallible$045install$058restored_head$1266$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058installed_head$1265$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047fallible$045install$058installed_tail$1265$(_undo_0, ($$$$047combined$045other$058install_5$(_world_2, _tail_0)));
  }
}

function $$$$047combined$045other$058install_value$(_world_0, _entry_0) {
  return $$$$047component$045install$058install$1267$(($$$$047combined$045other$058family_value$()), _world_0, _entry_0);
}

function $$$$047component$045install$058replaced$1266$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../fallible-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047component$045install$058undo$1266$({$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace$1266$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1266$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1266$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1266$(_id_0, _world_0);
  }
}

function $$$$047component$045install$058undo_present$1265$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047component$045install$058undone$1265$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1265$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1265$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1265$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1265$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_b$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047fallible$045install$058installed_tail$1260$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1260$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1260$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045control$058install_5$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058terminal$1260$(_world_0, _tail_0);
}

function $$$$047component$045install$058install$1263$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047component$045install$058stamped$1263$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1263$(_family_0, _world_0, _handle_0)));
}

function $$$$047combined$045control$058family_value$() {
  return {$: "../../../src/ecs/component.Family", "name": "value"};
}

function $$$$047component$045install$058undo$1262$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047component$045install$058undo_checked$1262$({$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1262$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1262$(_id_0, ($$$$047combined$045control$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047component$045install$058undone$1261$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../fallible-install.Restored", "world": ($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047combined$045control$058take_b$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1261$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047combined$045control$058put_b$(_rest_0, _column_0) {
  const _a_0 = _rest_0["a"];
  const _tag_0 = _rest_0["tag"];
  const _value_0 = _rest_0["value"];
  return {$: "../combined-control.Store", "a": _a_0, "b": _column_0, "tag": _tag_0, "value": _value_0};
}

function $$$$047fallible$045install$058installed_tail$1265$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047fallible$045install$058refused_head$1265$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../fallible-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../fallible-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047fallible$045install$058restored_tail$1265$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047combined$045other$058install_5$(_world_0, _tail_0) {
  return $$$$047fallible$045install$058terminal$1261$(_world_0, _tail_0);
}

function $$$$047component$045install$058install$1267$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047component$045install$058stamped$1267$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1267$(_family_0, _world_0, _handle_0)));
}

function $$$$047combined$045other$058family_value$() {
  return {$: "../../../src/ecs/component.Family", "name": "value"};
}

function $$$$047component$045install$058undo$1266$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047component$045install$058undo_checked$1266$({$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1266$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1266$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1266$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1266$(_id_0, ($$$$047combined$045other$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047component$045install$058undone$1265$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../fallible-install.Restored", "world": ($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1265$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1265$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1265$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047combined$045other$058take_b$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1265$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1265$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1265$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047combined$045other$058put_b$(_rest_0, _column_0) {
  const _a_0 = _rest_0["a"];
  const _tag_0 = _rest_0["tag"];
  const _value_0 = _rest_0["value"];
  return {$: "../combined-other.Store", "a": _a_0, "b": _column_0, "tag": _tag_0, "value": _value_0};
}

function $$$$047fallible$045install$058refused_head$1260$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1260$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1260$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058terminal$1260$(_world_0, _payload_0) {
  return {$: "../fallible-install.Installed", "world": _world_0, "undo": run_clo((_x_0) => {
  return {$: "../fallible-install.Restored", "world": _x_0, "payload": {$: "Unit"}};
})};
}

function $$$$047component$045install$058stamped$1263$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047component$045install$058replaced$1263$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058replace$1263$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1263$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1263$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047component$045install$058undo_checked$1262$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047component$045install$058undo_present$1262$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1262$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1262$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1262$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047combined$045control$058take_tag$(_store_0) {
  const _a_0 = _store_0["a"];
  const _b_0 = _store_0["b"];
  const _tag_0 = _store_0["tag"];
  const _value_0 = _store_0["value"];
  return {$: "Tuple", "fst": {$: "../combined-control.Rest_tag", "a": _a_0, "b": _b_0, "value": _value_0}, "snd": _tag_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1261$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047fallible$045install$058refused_head$1265$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../fallible-install.Quarantined", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047fallible$045install$058restored_tail$1265$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047fallible$045install$058restored_head$1265$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047fallible$045install$058terminal$1261$(_world_0, _payload_0) {
  return {$: "../fallible-install.Installed", "world": _world_0, "undo": run_clo((_x_0) => {
  return {$: "../fallible-install.Restored", "world": _x_0, "payload": {$: "Unit"}};
})};
}

function $$$$047component$045install$058stamped$1267$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047component$045install$058replaced$1267$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058replace$1267$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1267$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1267$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0);
}

function $$$$047component$045install$058undo_checked$1266$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047component$045install$058undo_present$1266$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1266$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1266$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1266$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1266$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1264$(_column_0, _id_0)));
}

function $$$$047combined$045other$058take_tag$(_store_0) {
  const _a_0 = _store_0["a"];
  const _b_0 = _store_0["b"];
  const _tag_0 = _store_0["tag"];
  const _value_0 = _store_0["value"];
  return {$: "Tuple", "fst": {$: "../combined-other.Rest_tag", "a": _a_0, "b": _b_0, "value": _value_0}, "snd": _tag_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1265$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1265$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1265$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1265$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1265$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1263$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1263$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1265$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047fallible$045install$058restored_head$1260$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047component$045install$058replaced$1263$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../fallible-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047component$045install$058undo$1263$({$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace$1263$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1263$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1263$(_id_0, _world_0);
  }
}

function $$$$047component$045install$058undo_present$1262$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047component$045install$058undone$1262$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1262$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1262$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_tag$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, ($$$$047combined$045control$058take_b$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047combined$045control$058put_b$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047fallible$045install$058restored_head$1265$(_result_0, _tail_0) {
  if (_result_0.$ === "../fallible-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../fallible-install.Restored", "world": _world_0, "payload": {$: "../prototype.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Pending", "world": _world_1, "recovery": {$: "../fallible-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047component$045install$058replaced$1267$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../fallible-install.Refused", "world": _world_0, "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../fallible-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047component$045install$058undo$1267$({$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace$1267$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1267$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1267$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1267$(_id_0, _world_0);
  }
}

function $$$$047component$045install$058undo_present$1266$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047component$045install$058undone$1266$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1266$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1266$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1266$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1266$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_tag$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1264$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1264$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1264$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1264$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1265$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1265$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1265$(_id_0, _stamp_0, ($$$$047combined$045other$058take_b$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1265$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1265$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047combined$045other$058put_b$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047component$045install$058undo$1263$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047component$045install$058undo_checked$1263$({$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1263$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1263$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1263$(_id_0, ($$$$047combined$045control$058take_value$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047component$045install$058undone$1262$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../fallible-install.Restored", "world": ($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047combined$045control$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1262$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047combined$045control$058put_tag$(_rest_0, _column_0) {
  const _a_0 = _rest_0["a"];
  const _b_0 = _rest_0["b"];
  const _value_0 = _rest_0["value"];
  return {$: "../combined-control.Store", "a": _a_0, "b": _b_0, "tag": _column_0, "value": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_b$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_b$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047component$045install$058undo$1267$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047component$045install$058undo_checked$1267$({$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1267$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1267$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1267$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(($$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1267$(_id_0, ($$$$047combined$045other$058take_value$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047component$045install$058undone$1266$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../fallible-install.Restored", "world": ($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1266$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1266$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1266$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047combined$045other$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1266$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1266$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1266$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047combined$045other$058put_tag$(_rest_0, _column_0) {
  const _a_0 = _rest_0["a"];
  const _b_0 = _rest_0["b"];
  const _value_0 = _rest_0["value"];
  return {$: "../combined-other.Store", "a": _a_0, "b": _b_0, "tag": _column_0, "value": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1264$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1264$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1264$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1265$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_b$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1263$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1265$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_b$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047component$045install$058undo_checked$1263$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047component$045install$058undo_present$1263$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1262$(_previous_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1263$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1262$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1263$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1263$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1262$(_column_0, _id_0)));
}

function $$$$047combined$045control$058take_value$(_store_0) {
  const _a_0 = _store_0["a"];
  const _b_0 = _store_0["b"];
  const _tag_0 = _store_0["tag"];
  const _value_0 = _store_0["value"];
  return {$: "Tuple", "fst": {$: "../combined-control.Rest_value", "a": _a_0, "b": _b_0, "tag": _tag_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1262$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047component$045install$058undo_checked$1267$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047component$045install$058undo_present$1267$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1262$(_previous_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1267$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1267$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1262$(_incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1267$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1267$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1265$(_column_0, _id_0)));
}

function $$$$047combined$045other$058take_value$(_store_0) {
  const _a_0 = _store_0["a"];
  const _b_0 = _store_0["b"];
  const _tag_0 = _store_0["tag"];
  const _value_0 = _store_0["value"];
  return {$: "Tuple", "fst": {$: "../combined-other.Rest_value", "a": _a_0, "b": _b_0, "tag": _tag_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1266$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1266$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1266$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1266$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1266$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1264$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1264$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1266$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1264$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1264$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047component$045install$058undo_present$1263$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047component$045install$058undone$1263$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058owner_present$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1263$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1263$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_value$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1262$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, ($$$$047combined$045control$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047combined$045control$058put_tag$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../src/ecs/column.Indexed", "state": {$: "../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047component$045install$058undo_present$1267$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047component$045install$058undone$1267$(_handle_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1267$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1267$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1267$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1267$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_value$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1265$(_column_0, _id_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1265$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1265$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1265$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1265$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1265$(_id_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1265$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1266$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1266$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1266$(_id_0, _stamp_0, ($$$$047combined$045other$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1266$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1266$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047combined$045other$058put_tag$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap$1264$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1264$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1264$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure$1264$(_column_0, _target_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1264$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0) {
  return {$: "../../../src/ecs/column.Indexed", "state": {$: "../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047component$045install$058undone$1263$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../fallible-install.Restored", "world": ($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1263$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047combined$045control$058take_value$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1263$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047combined$045control$058put_value$(_rest_0, _column_0) {
  const _a_0 = _rest_0["a"];
  const _b_0 = _rest_0["b"];
  const _tag_0 = _rest_0["tag"];
  return {$: "../combined-control.Store", "a": _a_0, "b": _b_0, "tag": _tag_0, "value": _column_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1262$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1262$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_tag$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_tag$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047component$045install$058undone$1267$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../fallible-install.Restored", "world": ($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1267$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../fallible-install.Pending", "world": _world_0, "recovery": {$: "../component-install.Recovery", "previous": {$: "../component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_world$1267$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(($$$$047$$$047$$$047src$047ecs$047component$058swap_store$1267$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($$$$047combined$045other$058take_value$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1267$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058replaced$1267$(($$$$047$$$047$$$047src$047ecs$047component$058swap_world$1267$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047combined$045other$058put_value$(_rest_0, _column_0) {
  const _a_0 = _rest_0["a"];
  const _b_0 = _rest_0["b"];
  const _tag_0 = _rest_0["tag"];
  return {$: "../combined-other.Store", "a": _a_0, "b": _b_0, "tag": _tag_0, "value": _column_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1265$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047src$047ecs$047column$058unseal$1265$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1265$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1265$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1265$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1265$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1265$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1265$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1266$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_tag$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1264$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1266$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_tag$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1264$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1264$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1264$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1264$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1264$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1264$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1264$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1263$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1263$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1263$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1262$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1262$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1262$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1262$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp$1267$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1267$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1267$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_store$1267$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1267$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058swap$1265$(($$$$047$$$047$$$047src$047ecs$047column$058ensure$1265$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047src$047ecs$047component$058replaced$1267$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1265$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1265$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1264$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1264$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1264$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1264$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark$1264$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1264$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058swapped$1264$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1264$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1264$({$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058seek$1264$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1264$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1264$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1264$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1264$({$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1264$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058grow$1264$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1264$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1264$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1263$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1263$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1263$(_id_0, _stamp_0, ($$$$047combined$045control$058take_value$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1262$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047combined$045control$058put_value$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap$1262$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure$1262$(_column_0, _target_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1262$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0) {
  return {$: "../../../src/ecs/column.Indexed", "state": {$: "../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_done$1267$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_world$1267$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1267$(_id_0, _stamp_0, ($$$$047combined$045other$058take_value$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047component$058swap_join$1267$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1267$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047component$058owner_present$1262$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($$$$047combined$045other$058put_value$(_rest_0, _column_1)), "snd": {$: "../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap$1265$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1265$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1265$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1265$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1265$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1265$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1265$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1265$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure$1265$(_column_0, _target_0) {
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1265$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, _metadata_0) {
  return {$: "../../../src/ecs/column.Indexed", "state": {$: "../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1264$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1264$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1264$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swapped$1264$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1264$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1264$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1264$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_0)));
  } else {
    return {$: "../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover$1264$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1264$(($$$$047$$$047$$$047src$047ecs$047column$058unseal$1264$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1264$(($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1264$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek$1264$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058past_current$1264$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1264$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1264$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1264$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058grow$1264$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1264$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1264$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1264$(_column_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1264$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1264$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1263$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_value$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1262$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045control$058put_value$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1262$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1262$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1262$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1262$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1262$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1262$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_rest_0)), ($$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047component$058restore_stamp_store$1267$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_value$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1265$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1267$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047combined$045other$058put_value$(_rest_0, ($$$$047$$$047$$$047src$047ecs$047column$058mark$1265$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1265$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1265$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_state$1265$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1265$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1265$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1265$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1265$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1265$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1265$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1265$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1265$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1265$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1265$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1265$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1265$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1265$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1264$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1264$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1264$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1264$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1264$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1264$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1264$(_target_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1264$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1264$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1264$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1264$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1262$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark$1262$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1262$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058swapped$1262$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1262$({$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058seek$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1262$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1262$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1262$({$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058grow$1262$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1262$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_stamp$1265$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1265$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1265$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1265$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1265$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1265$(_id_0, _stamp_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1265$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark$1265$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058unseal$1265$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1265$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1265$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1265$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058swapped$1265$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1265$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1265$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1265$({$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058seek$1265$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1265$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1265$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1265$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1265$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1265$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1265$({$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1265$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058past_current$1265$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1265$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058grow$1265$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1265$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1265$(_target_0, {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1265$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1265$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1265$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1265$(_target_0, {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1264$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1264$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1264$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1264$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1264$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1264$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1264$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swapped$1262$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return {$: "../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover$1262$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1262$(($$$$047$$$047$$$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1262$(($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek$1262$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1262$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1262$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1262$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058grow$1262$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1262$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1262$(_column_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1262$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1262$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058restore_state$1265$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_restore_state$1265$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_restore_state$1265$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058mark_state$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047column$058swapped$1265$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1265$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1265$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1265$(_id_0, _incoming_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1265$(_carrier_0)));
  } else {
    return {$: "../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover$1265$(_column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1265$(($$$$047$$$047$$$047src$047ecs$047column$058unseal$1265$(_carrier_0)));
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1265$(($$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1265$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058seek$1265$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.Prepared", "state": {$: "../../../src/ecs/column.Owned", "state": {$: "../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058past_current$1265$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1265$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1265$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1265$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../src/ecs/column.Rejected", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../src/ecs/column.Accepted", "column": {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058grow$1265$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1265$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1265$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover$1265$(_column_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1265$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1265$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_past$1264$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1262$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058absent$1262$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047src$047ecs$047column$058absent$1262$(_rest_0)), ($$$$047$$$047$$$047src$047ecs$047column$058absent$1262$(_rest_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1262$(_target_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1262$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1265$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_state$1265$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1265$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1265$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1265$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1265$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1265$(_target_0, _column_0) {
  if (_column_0.$ === "../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1265$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1265$(_target_0, ($$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1265$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1265$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1262$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1262$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1262$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1262$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1262$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_current$1265$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1265$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1265$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1265$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1265$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1265$(($$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047src$047ecs$047column$058recover_past$1265$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_past$1262$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047column$058recover_past$1265$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);