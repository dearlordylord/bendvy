"""Exact-source cheap consumer gate. No child execution until explicit admission."""
from pathlib import Path
import hashlib,json,os,re,shutil,sys
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import check_preflight as P
PLAN=HERE/'plan-003.json';ENV=HERE/'environment-003.json';OUT=HERE/'development-003'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepare():
 assert not PLAN.exists() and not ENV.exists()
 files=set()
 def close(p):
  p=p.resolve()
  if p in files:return
  files.add(p)
  if p.suffix=='.bend':
   for name in re.findall(r'^\s*import\s+(\S+)',p.read_text(),re.M):
    if name!='Base':close(p.parent/name.strip('"'))
 close(HERE/'main.bend')
 files.update(HERE/n for n in ['oracle.py','expected.stdout','expected.stderr','expected-check-only.stderr','run-v3.py','expected-safe-check.stdout'])
 files.update(ROOT/n for n in ['scripts/task_runner.py','scripts/check_preflight.py','scripts/bend-check','src/ecs/world-namespace.js','src/ecs/world-namespace.c','.references/sources.json','docs/SPEC.md'])
 bend=Path(shutil.which('bend')).resolve();files.add(bend);files.add(Path('/home/node/.bend/check.json'))
 checks=[dict(label='generic-public',argv=[str(bend),str(HERE/'public.bend'),'--check-only'],seconds=5,stdout=str(HERE/'expected-safe-check.stdout')),dict(label='generic-adapter',argv=[str(bend),str(HERE/'adapter.bend'),'--check-only'],seconds=5,stdout=str(HERE/'expected-safe-check.stdout')),dict(label='canonical-IO-effect-boundary',argv=[str(bend),str(HERE/'main.bend'),'--check-only'],seconds=5,exit=1,stderr=str(HERE/'expected-check-only.stderr')),dict(label='complete-consumer',argv=[str(bend),str(HERE/'main.bend')],seconds=5,stdout=str(HERE/'expected.stdout'))]
 env=dict(os.environ,BEND_NO_TELEMETRY='1');ENV.write_text(json.dumps(env,sort_keys=True,indent=2)+'\n');ENV.chmod(0o600)
 files=sorted(map(str,files));directories=['/home/node/.bend/bend2'];binding=P.binding(ROOT,files,directories,checks,env)
 plan=dict(status='UNEXECUTED',supersedes='plan-002 retained INCOMPLETE: safe checker stdout omitted; no application command reached',files=files,directories=directories,checks=checks,binding=binding,environmentSHA256=sha(ENV),rows=22,scope='Generic owned Input/Output Type API, 22 full independent observations in two schemas through actual registered WorldIO worlds; direct returned Raw retry, actual barrier/inverse, full physical payloads/stamps/queues/registries and independently created foreign peer. Canonical IO diagnostics are effect-boundary observations, not source/proof PASS. No policy/proofs/core adoption/performance claim.')
 PLAN.write_text(json.dumps(plan,indent=2)+'\n');print(sha(PLAN))
def execute():
 plan=json.loads(PLAN.read_text());assert sha(ENV)==plan['environmentSHA256'];env=json.loads(ENV.read_text())
 assert dict(os.environ,BEND_NO_TELEMETRY='1')==env,'ambient environment mismatch; fresh freeze required'
 assert P.binding(ROOT,plan['files'],plan['directories'],plan['checks'],env)==plan['binding'],'input drift; fresh freeze required'
 print(P.run(OUT,root=ROOT,files=[*plan['files'],str(PLAN),str(ENV)],directories=plan['directories'],checks=plan['checks'],env=env))
if sys.argv[1:]==['--prepare-only']:prepare()
elif sys.argv[1:]==['--execute']:execute()
else:raise SystemExit('use --prepare-only or --execute')
