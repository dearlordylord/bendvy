"""Two-command emitted JS gate, after exact cheap consumer preflight."""
from pathlib import Path
import functools,hashlib,json,os,runpy,shutil,sys,tempfile
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import task_runner as R;import check_preflight as P
T=runpy.run_path(str(ROOT/'scripts/owned-tool-pins.py'))
PLAN=HERE/'controls-plan-002.json';ENV=HERE/'controls-environment-002.json';OUT=HERE/'controls-002'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def encoded(value):
 if isinstance(value,bytes):return {'rawHex':value.hex()}
 raise TypeError(type(value).__name__)
def decoded(value):
 if set(value)=={'rawHex'}:return bytes.fromhex(value['rawHex'])
 return value
def ancestors(roots):
 return {parent for root in roots for parent in [root,*root.parents]}
def configs(roots):
 return {str(root/name):(sha(root/name) if (root/name).is_file() else None) for root in ancestors(roots) for name in ['bend.json','bend.config.json','check.json','bunfig.toml','package.json','.clang','clang.cfg']}
def loaders():
 paths=[Path('/etc/ld.so.cache'),Path('/etc/ld.so.conf'),Path('/etc/ld.so.preload')]
 return {'files':{str(p):(sha(p) if p.is_file() else None) for p in paths},'confDirectory':inventory(Path('/etc/ld.so.conf.d'))}
PROBES=[]
def owned_probe(argv,seconds,**kwargs):
 result=R.execute_result(argv,seconds,capture='split',**kwargs)
 PROBES.append(dict(argv=argv,seconds=seconds,result=result))
 return result


def inventory(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def config(env):return dict(execute=owned_probe,tools={'bend':Path(shutil.which('bend')).resolve(),'node':Path(shutil.which('node')).resolve(),'python':Path(sys.executable).resolve(),'clang-wrapper':Path('/tmp/bendvy-clang19-diagnostic/clang19'),'clang-native':Path('/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/bin/clang')},resource_roots=[Path('/home/node/.bend/bend2'),Path('/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/lib/clang/19')],skip_ldd=('clang-wrapper',),ldd=Path(shutil.which('ldd')).resolve(),taskset=Path(shutil.which('taskset')).resolve(),cpu=min(os.sched_getaffinity(0)),env=env,capture_mode='split')
def preflight():
 plan=json.loads((HERE/'plan-005.json').read_text());env=json.loads((HERE/'environment-005.json').read_text())
 return P.verify(HERE/'development-005/receipt.json',root=ROOT,files=[*plan['files'],str(HERE/'plan-005.json'),str(HERE/'environment-005.json')],directories=plan['directories'],checks=plan['checks'],env=env)
def prepare():
 assert not PLAN.exists() and not ENV.exists();preflight()
 base=json.loads((HERE/'plan-005.json').read_text());files={p:sha(p) for p in base['files']}
 for p in [Path(__file__),ROOT/'scripts/owned-tool-pins.py',HERE/'plan-005.json',HERE/'development-005/receipt.json']:files[str(p)]=sha(p)
 env=dict(os.environ,BEND_NO_TELEMETRY='1',BENDVY_CLANG19_ROOT='/tmp/bendvy-clang19-diagnostic/root',LD_LIBRARY_PATH='/tmp/bendvy-clang19-diagnostic/root/usr/lib/aarch64-linux-gnu:/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/lib:/home/node/.local/opt/dnd-clang14/usr/lib/aarch64-linux-gnu');ENV.write_text(json.dumps(env,sort_keys=True,indent=2)+'\n');ENV.chmod(0o600)
 for p in list((HERE/'negatives').glob('*.bend'))+[HERE/n for n in ['commands.bend','composition.bend','negative-witnesses.json','omitted-value-patch.json','omitted-value-oracle.py','expected-omitted-value.stdout']]:files[str(p)]=sha(p)
 snapshot=T['snapshot'](**config(env));directories={n:inventory(Path(n)) for n in base['directories']}
 commands=[]
 commands.append(dict(label='positive-composition',argv=['bend','STAGE/experiments/public-bundles/owned-public-result-v1/composition.bend','--check-only'],seconds=5,kind='source-positive'))
 commands.append(dict(label='positive-commands',argv=['bend','STAGE/experiments/public-bundles/owned-public-result-v1/commands.bend','--check-only'],seconds=5,kind='source-positive'))
 for name in json.loads((HERE/'negative-witnesses.json').read_text()):
  commands.append(dict(label='negative-'+name,argv=['bend','STAGE/experiments/public-bundles/owned-public-result-v1/negatives/'+name+'.bend','--check-only'],seconds=5,kind='negative',name=name))
 main='experiments/public-bundles/owned-public-result-v1/main.bend'
 commands.append(dict(label='mutant-source',argv=['bend','MUTANT/'+main,'--check-only'],seconds=5,kind='effect-boundary'))
 commands.extend([dict(label='Native-emit',argv=['bend','STAGE/'+main,'-o','OUT/owned.c'],seconds=30,kind='emit',generated='owned.c'),dict(label='Native-clang',argv=['/tmp/bendvy-clang19-diagnostic/clang19','-O3','OUT/owned.c','-pthread','-lm','-o','OUT/owned.native'],seconds=120,kind='emit',generated='owned.native'),dict(label='Native-full22',argv=['OUT/owned.native','--threads','1','--gpu','off'],seconds=5,kind='normal')])
 commands.extend([dict(label='mutant-JS-emit',argv=['bend','MUTANT/'+main,'-o','OUT/omitted.js'],seconds=30,kind='emit',generated='omitted.js'),dict(label='mutant-JS-full22',argv=['node','OUT/omitted.js'],seconds=5,kind='mutant'),dict(label='mutant-Native-emit',argv=['bend','MUTANT/'+main,'-o','OUT/omitted.c'],seconds=30,kind='emit',generated='omitted.c'),dict(label='mutant-Native-clang',argv=['/tmp/bendvy-clang19-diagnostic/clang19','-O3','OUT/omitted.c','-pthread','-lm','-o','OUT/omitted.native'],seconds=120,kind='emit',generated='omitted.native'),dict(label='mutant-Native-full22',argv=['OUT/omitted.native','--threads','1','--gpu','off'],seconds=5,kind='mutant')])
 plan=dict(status='UNEXECUTED',files=files,directories=directories,environmentSHA256=sha(ENV),toolSnapshot=snapshot,commands=commands,fullOracleSHA256=sha(HERE/'expected.stdout'),rootConfigurations=configs({ROOT,HERE,Path.cwd(),Path('/home/node/.bend'),Path('/tmp/bendvy-clang19-diagnostic'),Path('/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/bin')}),loaderConfigurations=loaders(),preparationProbeResults=list(PROBES),priorFailedReceiptSHA256=sha(HERE/'controls-001/receipt.json'),retainedFailedCompositionSHA256=sha(HERE/'controls-001/failed-composition-source.bend'),reusedSupportSourceSHA256=sha(HERE/'negatives/support.bend'),scope='Remaining-only affected controls; first repaired Composed checker, safe Commands then unchanged remaining negatives/backend subjects. Prior support PASS source-current; normal JS22 retained unchanged. Affected controls only: generic commands source/support; eight precise owned authority/type negatives; actual omitted-value source effect boundary and full22 mutant JS/Native; normal Native full22. Prior JS full22 source join reused. No legacy replay, policy/proof/production/performance/full41 claim')
 PLAN.write_text(json.dumps(plan,indent=2,default=encoded)+'\n');print(sha(PLAN))
def execute():
 plan=json.loads(PLAN.read_text(),object_hook=decoded);assert sha(ENV)==plan['environmentSHA256'];env=json.loads(ENV.read_text());assert env==dict(os.environ,BEND_NO_TELEMETRY='1',BENDVY_CLANG19_ROOT='/tmp/bendvy-clang19-diagnostic/root',LD_LIBRARY_PATH='/tmp/bendvy-clang19-diagnostic/root/usr/lib/aarch64-linux-gnu:/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/lib:/home/node/.local/opt/dnd-clang14/usr/lib/aarch64-linux-gnu'),'ambient drift';preflight();assert not OUT.exists();OUT.mkdir()
 receipt=dict(status='INCOMPLETE',planSHA256=sha(PLAN),commands=[],generated={},toolGuardSnapshots=[],rawLogs={},probeCommands=PROBES)
 def save():(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,default=encoded)+'\n')
 save()
 try:
  with tempfile.TemporaryDirectory(prefix='owned-public-js-') as temp:
   stage=Path(temp)/'normal';mutant=Path(temp)/'mutant';stage.mkdir();mutant.mkdir();staged={};stageConfigs=configs({stage,stage/HERE.relative_to(ROOT),mutant,mutant/HERE.relative_to(ROOT)})
   for name,h in plan['files'].items():
    p=Path(name)
    if p.is_relative_to(ROOT):
     target=stage/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);staged[str(target.relative_to(stage))]=h
   shutil.copytree(stage,mutant,dirs_exist_ok=True)
   patched=dict(staged)
   for change in json.loads((HERE/'omitted-value-patch.json').read_text())['changes']:
    target=mutant/change['path'];assert sha(target)==change['baseSHA256'];source=target.read_text();assert source.count(change['replace'])==1;target.write_text(source.replace(change['replace'],change['withText']));assert sha(target)==change['mutantSHA256'];patched[change['path']]=change['mutantSHA256']
   receipt['stagedInputs']=staged;receipt['mutantInputs']=patched
   def guard():
    assert sha(PLAN)==receipt['planSHA256'],'frozen plan drift'
    assert sha(ENV)==plan['environmentSHA256'],'frozen environment drift'
    assert all(sha(n)==h for n,h in plan['files'].items()),'source drift'
    assert all(inventory(Path(n))==h for n,h in plan['directories'].items()),'external drift'
    assert inventory(stage)==staged,'stage drift'
    assert inventory(mutant)==patched,'mutant stage drift'
    receipt['toolGuardSnapshots'].append(T['verify'](plan['toolSnapshot'],**config(env)))
    assert configs({ROOT,HERE,Path.cwd(),Path('/home/node/.bend'),Path('/tmp/bendvy-clang19-diagnostic'),Path('/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/bin')})==plan['rootConfigurations'],'root configurations drift'
    assert configs({stage,stage/HERE.relative_to(ROOT),mutant,mutant/HERE.relative_to(ROOT)})==stageConfigs,'stage configurations drift'
    assert loaders()==plan['loaderConfigurations'],'loader configurations drift'
    assert all(sha(OUT/n)==h for n,h in receipt['rawLogs'].items()),'immutable raw log drift'
    save()
    assert all(sha(OUT/n)==h for n,h in receipt['generated'].items()),'generated drift'
   for command in plan['commands']:
    guard();argv=[str(stage)+a[5:] if a.startswith('STAGE/') else str(mutant)+a[6:] if a.startswith('MUTANT/') else str(OUT)+a[3:] if a.startswith('OUT/') else a for a in command['argv']]
    result=R.execute_result(argv,command['seconds'],cwd=stage,env=env,capture='split');label=command['label']
    for stream in ['stdout','stderr']:
     target=OUT/(label+'.'+stream);assert not target.exists();target.write_bytes(result[stream]);receipt['rawLogs'][target.name]=sha(target)
    receipt['commands'].append(dict(label=label,argv=argv,exit=result['exit'],failure=result['failure'],result=result,stdoutSHA256=sha(OUT/(label+'.stdout')),stderrSHA256=sha(OUT/(label+'.stderr'))));save()
    assert result['failure'] is None,(label,result)
    kind=command['kind'];assert result['exit']==(1 if kind in ['negative','effect-boundary'] else 0),(label,result)
    if kind=='source-positive':assert not result['stderr'] and result['stdout']==(HERE/'expected-safe-check.stdout').read_bytes()
    elif kind=='effect-boundary':assert not result['stdout'] and result['stderr']==(HERE/'expected-check-only.stderr').read_bytes()
    elif kind=='negative':
     text=result['stderr'].decode();assert not result['stdout'] and text.startswith('SOME PROOFS FAIL\nError:\n') and text.count('Location: ')==1
     assert all(w in text for w in json.loads((HERE/'negative-witnesses.json').read_text())[command['name']]['contains']),(label,text)
    elif kind=='emit':assert not result['stdout'] and not result['stderr'];receipt['generated'][command['generated']]=sha(OUT/command['generated'])
    else:
     expected=(HERE/('expected.stdout' if kind=='normal' else 'expected-omitted-value.stdout')).read_bytes()
     assert not result['stderr'] and result['stdout']==expected,(label,'full independent literal mismatch')
     if kind=='mutant':assert expected!=(HERE/'expected.stdout').read_bytes();receipt.setdefault('mutantRows',{})[label]=22
     else:receipt['normalNativeRows']=22
    guard()
   receipt['status']='OWNED_PUBLIC_RESULT_AFFECTED_CONTROLS_FINITE_PASS'
 finally:save();print(OUT/'receipt.json')
if sys.argv[1:]==['--prepare-only']:prepare()
elif sys.argv[1:]==['--execute']:execute()
else:raise SystemExit('use --prepare-only or --execute')
