"""Two-command emitted JS gate, after exact cheap consumer preflight."""
from pathlib import Path
import functools,hashlib,json,os,runpy,shutil,sys,tempfile
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import task_runner as R;import check_preflight as P
T=runpy.run_path(str(ROOT/'scripts/owned-tool-pins.py'))
PLAN=HERE/'js-plan-004.json';ENV=HERE/'js-environment-004.json';OUT=HERE/'js-004'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def encoded(value):
 if isinstance(value,bytes):return {'rawHex':value.hex()}
 raise TypeError(type(value).__name__)
def decoded(value):
 if set(value)=={'rawHex'}:return bytes.fromhex(value['rawHex'])
 return value
def ancestors(roots):
 return {parent for root in roots for parent in [root,*root.parents]}
def configs(roots):
 return {str(root/name):(sha(root/name) if (root/name).is_file() else None) for root in ancestors(roots) for name in ['bend.json','bend.config.json','check.json','bunfig.toml','package.json','.clang','clang.cfg']}
def loaders():
 paths=[Path('/etc/ld.so.cache'),Path('/etc/ld.so.conf'),Path('/etc/ld.so.preload')]
 return {'files':{str(p):(sha(p) if p.is_file() else None) for p in paths},'confDirectory':inventory(Path('/etc/ld.so.conf.d'))}
PROBES=[]
def owned_probe(argv,seconds,**kwargs):
 result=R.execute_result(argv,seconds,capture='split',**kwargs)
 PROBES.append(dict(argv=argv,seconds=seconds,result=result))
 return result


def inventory(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def config(env):return dict(execute=owned_probe,tools={'bend':Path(shutil.which('bend')).resolve(),'node':Path(shutil.which('node')).resolve(),'python':Path(sys.executable).resolve()},resource_roots=[Path('/home/node/.bend/bend2')],ldd=Path(shutil.which('ldd')).resolve(),taskset=Path(shutil.which('taskset')).resolve(),cpu=min(os.sched_getaffinity(0)),env=env,capture_mode='split')
def preflight():
 plan=json.loads((HERE/'plan-005.json').read_text());env=json.loads((HERE/'environment-005.json').read_text())
 return P.verify(HERE/'development-005/receipt.json',root=ROOT,files=[*plan['files'],str(HERE/'plan-005.json'),str(HERE/'environment-005.json')],directories=plan['directories'],checks=plan['checks'],env=env)
def prepare():
 assert not PLAN.exists() and not ENV.exists();preflight()
 base=json.loads((HERE/'plan-005.json').read_text());files={p:sha(p) for p in base['files']}
 for p in [Path(__file__),ROOT/'scripts/owned-tool-pins.py',HERE/'plan-005.json',HERE/'development-005/receipt.json']:files[str(p)]=sha(p)
 env=dict(os.environ,BEND_NO_TELEMETRY='1');ENV.write_text(json.dumps(env,sort_keys=True,indent=2)+'\n');ENV.chmod(0o600)
 snapshot=T['snapshot'](**config(env));directories={n:inventory(Path(n)) for n in base['directories']}
 commands=[dict(label='JS-emit',argv=['bend','STAGE/experiments/public-bundles/owned-public-result-v1/main.bend','-o','OUT/owned.js'],seconds=30),dict(label='JS-full22',argv=['node','OUT/owned.js'],seconds=5)]
 plan=dict(status='UNEXECUTED',files=files,directories=directories,environmentSHA256=sha(ENV),toolSnapshot=snapshot,commands=commands,fullOracleSHA256=sha(HERE/'expected.stdout'),rootConfigurations=configs({ROOT,HERE,Path.cwd(),Path('/home/node/.bend')}),loaderConfigurations=loaders(),preparationProbeResults=list(PROBES),scope='Emitted JS direct owned public result API: full22 source-current physical observations, two schemas, no performance/proof/production/full41 claim')
 PLAN.write_text(json.dumps(plan,indent=2,default=encoded)+'\n');print(sha(PLAN))
def execute():
 plan=json.loads(PLAN.read_text(),object_hook=decoded);assert sha(ENV)==plan['environmentSHA256'];env=json.loads(ENV.read_text());assert env==dict(os.environ,BEND_NO_TELEMETRY='1'),'ambient drift';preflight();assert not OUT.exists();OUT.mkdir()
 receipt=dict(status='INCOMPLETE',planSHA256=sha(PLAN),commands=[],generated={},toolGuardSnapshots=[],rawLogs={},probeCommands=PROBES)
 def save():(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2,default=encoded)+'\n')
 save()
 try:
  with tempfile.TemporaryDirectory(prefix='owned-public-js-') as temp:
   stage=Path(temp);staged={};stageConfigs=configs({stage,stage/HERE.relative_to(ROOT)})
   for name,h in plan['files'].items():
    p=Path(name)
    if p.is_relative_to(ROOT):
     target=stage/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);staged[str(target.relative_to(stage))]=h
   def guard():
    assert sha(PLAN)==receipt['planSHA256'],'frozen plan drift'
    assert sha(ENV)==plan['environmentSHA256'],'frozen environment drift'
    assert all(sha(n)==h for n,h in plan['files'].items()),'source drift'
    assert all(inventory(Path(n))==h for n,h in plan['directories'].items()),'external drift'
    assert inventory(stage)==staged,'stage drift'
    receipt['toolGuardSnapshots'].append(T['verify'](plan['toolSnapshot'],**config(env)))
    assert configs({ROOT,HERE,Path.cwd(),Path('/home/node/.bend')})==plan['rootConfigurations'],'root configurations drift'
    assert configs({stage,stage/HERE.relative_to(ROOT)})==stageConfigs,'stage configurations drift'
    assert loaders()==plan['loaderConfigurations'],'loader configurations drift'
    assert all(sha(OUT/n)==h for n,h in receipt['rawLogs'].items()),'immutable raw log drift'
    save()
    assert all(sha(OUT/n)==h for n,h in receipt['generated'].items()),'generated drift'
   for command in plan['commands']:
    guard();argv=[str(stage)+a[5:] if a.startswith('STAGE/') else str(OUT)+a[3:] if a.startswith('OUT/') else a for a in command['argv']]
    result=R.execute_result(argv,command['seconds'],cwd=stage,env=env,capture='split');label=command['label']
    for stream in ['stdout','stderr']:
     target=OUT/(label+'.'+stream);assert not target.exists();target.write_bytes(result[stream]);receipt['rawLogs'][target.name]=sha(target)
    receipt['commands'].append(dict(label=label,argv=argv,exit=result['exit'],failure=result['failure'],result=result,stdoutSHA256=sha(OUT/(label+'.stdout')),stderrSHA256=sha(OUT/(label+'.stderr'))));save()
    assert result['failure'] is None and result['exit']==0,(label,result)
    assert not result['stderr'],label
    if label=='JS-emit':assert not result['stdout'];receipt['generated']['owned.js']=sha(OUT/'owned.js')
    else:assert result['stdout']==(HERE/'expected.stdout').read_bytes(),'full literal mismatch';receipt['fullRows']=22
    guard()
   receipt['status']='OWNED_PUBLIC_RESULT_JS_FINITE_PASS'
 finally:save();print(OUT/'receipt.json')
if sys.argv[1:]==['--prepare-only']:prepare()
elif sys.argv[1:]==['--execute']:execute()
else:raise SystemExit('use --prepare-only or --execute')
