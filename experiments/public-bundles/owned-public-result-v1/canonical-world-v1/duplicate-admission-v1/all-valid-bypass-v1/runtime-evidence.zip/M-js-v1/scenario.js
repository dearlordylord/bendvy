function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// One allocator per emitted program, shared by all canonical world creations.
let bendvy_namespace_next = 1;
function bendvy_namespace_fresh() {
  if (bendvy_namespace_next >= 0xffffffff) return 0;
  return bendvy_namespace_next++;
}
io_eff("../../../../../../../../bendvy/src/ecs/world-namespace.fresh", bendvy_namespace_fresh);

})();

(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["../../../../../../../../bendvy/src/ecs/world-namespace.fresh","IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058create$1260$({$: "runtime.Mail", "returned": {$: "Nil"}, "installed": {$: "Nil"}, "quarantine": {$: "Nil"}, "errors": {$: "Nil"}, "spare": array_node([70], [71])})), run_clo((_x_1) => {
  return $created$(_x_1);
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058create$1260$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058with_namespace$1260$(_x_2, _resource_0);
}), _x_0);
});
}

function $created$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/world-io.Created") {
    const _world_0 = _result_0["world"];
    return (_x_0) => $IO$print$(($duplicate$058begun$(_world_0)), _x_0);
  } else {
    return (_x_1) => $IO$print$("namespace-refused", _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045namespace$058fresh$(_k_0) {
  return { $: "$FFI", run: $0eff["../../../../../../../../bendvy/src/ecs/world-namespace.fresh"].run, need: $0eff["../../../../../../../../bendvy/src/ecs/world-namespace.fresh"].need, args: [], kont: (_k_0) };
}
function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058with_namespace$1260$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058convert$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $duplicate$058begun$(_world_0) {
  return $duplicate$058registered$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, "duplicate-bundle", {$: "Con", "head": "bundle:write", "tail": {$: "Nil"}})));
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$045io$058convert$1260$(_created_0) {
  if (_created_0.$ === "../../../../../../../../bendvy/src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../../../../../../bendvy/src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../../../../../../bendvy/src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/world.Created", "factory": {$: "../../../../../../../../bendvy/src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($runtime$058empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $duplicate$058registered$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $duplicate$058initial_world$(_registry_0, ($$$$047$$$047complete$045families$045v1$047canonical$058context$1260$()), ($observe$058world$(_world_0)));
  } else {
    return "unexpected-registration-failure";
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $runtime$058empty$(_unit_0) {
  return {$: "bundle.Store", "heads": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1260$()), "tails": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1261$()), "tags": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1262$()), "data": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1263$())};
}

function $duplicate$058initial_world$(_registry_0, _context_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return $duplicate$058completed$(("duplicate-initial=" + _text_0), ($duplicate$058run$(_registry_0, _world_0, _context_0, {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../complete-families-v1/canonical.Incoming", "owned": array_node([91], [92]), "wire": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Number", "value": 8}, "fail": false}, "tail": ($drive$058sample$({$: "../../../../../../../../bendvy/src/ecs/decode-data.Number", "value": 7}, false))})));
}

function $$$$047$$$047complete$045families$045v1$047canonical$058context$1260$() {
  return {$: "../../complete-families-v1/canonical.Context", "factory": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058fallible_factory$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058constructed$1260$({$: "../../../../../../../../bendvy/src/ecs/decode-data.FiniteNumber"})))), "rest": array_node([array_node([70], [71])], [[72]]), "trail": {$: "Nil"}};
}

function $observe$058world$(_owner_0) {
  const _ns_0 = _owner_0["namespace"];
  const _next_0 = _owner_0["nextId"];
  const _high_0 = _owner_0["highWater"];
  const _live_0 = _owner_0["live"];
  const _cap_0 = _owner_0["capacity"];
  const _depth_0 = _owner_0["depth"];
  const _columns_0 = _owner_0["store"];
  const _resource_0 = _owner_0["resource"];
  const _events_0 = _owner_0["events"];
  const _pending_0 = _owner_0["pending"];
  const _regs_0 = _owner_0["registrations"];
  const _system_0 = _owner_0["nextSystemId"];
  const _clock_0 = _owner_0["clock"];
  return $observe$058world_join$(_ns_0, _next_0, _high_0, _cap_0, _depth_0, _events_0, _regs_0, _system_0, _clock_0, ($observe$058tree$1264$(_live_0)), ($observe$058store$(_columns_0)), ($observe$058mail$(_resource_0)), ($observe$058counted$1262$(_pending_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1260$() {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1261$() {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1262$() {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058empty$1263$() {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $duplicate$058completed$(_prefix_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _t_1 = _t_0["output"];
      const _context_0 = _t_1["context"];
      const _t_2 = _t_1["output"];
      if (_t_2.$ === "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused") {
        const _raw_0 = _t_2["raw"];
        const _t_3 = _t_2["error"];
        if (_t_3.$ === "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.DeclarationRefused") {
          const _t_4 = _t_3["error"];
          if (_t_4.$ === "../../../../../../../../bendvy/src/ecs/schema-fragments.DuplicateKey") {
            const _t_5 = _t_4["kind"];
            if (_t_5.$ === "../../../../../../../../bendvy/src/ecs/schema-fragments.Component") {
              const _key_0 = _t_4["key"];
              const _prepared_0 = _t_1["prepared"];
              const _x_0 = ($duplicate$058prepared_text$(_prepared_0));
              const _x_1 = ("|prepared=" + _x_0);
              const _x_2 = (_key_0 + _x_1);
              const _x_3 = ("\nduplicate-refused=" + _x_2);
              return $duplicate$058refusal_raw$((_prefix_0 + _x_3), _registry_0, _world_0, _context_0, ($duplicate$058raw_observe$(_raw_0)));
            } else {
              const _prepared_1 = _t_1["prepared"];
              const _x_4 = ($duplicate$058prepared_text$(_prepared_1));
              return ("unexpected-admission|prepared=" + _x_4);
            }
          } else {
            const _prepared_2 = _t_1["prepared"];
            const _x_5 = ($duplicate$058prepared_text$(_prepared_2));
            return ("unexpected-admission|prepared=" + _x_5);
          }
        } else {
          const _prepared_3 = _t_1["prepared"];
          const _x_6 = ($duplicate$058prepared_text$(_prepared_3));
          return ("unexpected-admission|prepared=" + _x_6);
        }
      } else {
        const _target_0 = _t_2["target"];
        const _spawned_0 = _t_2["spawned"];
        const _prepared_4 = _t_1["prepared"];
        return $duplicate$058admitted_world$(_target_0, _spawned_0, _registry_0, _context_0, _prepared_4, _prefix_0, ($observe$058world$(_world_0)));
      }
    } else {
      const _error_0 = _t_0["error"];
      return ("unexpected-failure=" + _error_0);
    }
  } else {
    return "unexpected-registration-refusal";
  }
}

function $duplicate$058run$(_registry_0, _world_0, _context_0, _raw_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, {$: "Tuple", "fst": _context_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Input", "operation": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Spawn"}, "raw": _raw_0}});
}

function $drive$058sample$(_raw_0, _fail_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../complete-families-v1/canonical.Incoming", "owned": array_node([11], [12]), "wire": _raw_0, "fail": _fail_0}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../complete-families-v1/canonical.Tail", "owned": array_node(array_node([21], [22]), array_node([23], [24])), "tag": true, "scalar": 31}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../complete-families-v1/canonical.Tag"}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": 101, "tail": {$: "Unit"}}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058fallible_factory$1260$(_declaration_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/decode-construction.FallibleFactory", "declaration": _declaration_0, "inputCodec": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058codec$1260$(_declaration_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058constructed$1260$(_codec_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/persistence-declaration.Constructed", "codec": _codec_0};
}

function $observe$058world_join$(_ns_0, _next_0, _high_0, _cap_0, _depth_0, _events_0, _regs_0, _system_0, _clock_0, _live_0, _store_0, _resource_0, _pending_0) {
  const _live_1 = _live_0["fst"];
  const _l_0 = _live_0["snd"];
  const _store_1 = _store_0["fst"];
  const _s_0 = _store_0["snd"];
  const _resource_1 = _resource_0["fst"];
  const _r_0 = _resource_0["snd"];
  const _pending_1 = _pending_0["fst"];
  const _p_0 = _pending_0["snd"];
  const _x_0 = ($U32$show$(_clock_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_system_0));
  const _x_3 = (",clock:" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($List$show$1263$(_regs_0));
  const _x_6 = (",system:" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_p_0));
  const _x_9 = (",regs:" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($List$show$1260$(_events_0));
  const _x_12 = (",pending:" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = (",events:" + _x_13);
  const _x_15 = (_r_0 + _x_14);
  const _x_16 = (",resource:" + _x_15);
  const _x_17 = (_s_0 + _x_16);
  const _x_18 = (",store:" + _x_17);
  const _x_19 = (_l_0 + _x_18);
  const _x_20 = ($Nat$show$(_depth_0));
  const _x_21 = (",live:" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  const _x_23 = ($U32$show$(_cap_0));
  const _x_24 = (",depth:" + _x_22);
  const _x_25 = (_x_23 + _x_24);
  const _x_26 = ($U32$show$(_high_0));
  const _x_27 = (",cap:" + _x_25);
  const _x_28 = (_x_26 + _x_27);
  const _x_29 = ($U32$show$(_next_0));
  const _x_30 = (",high:" + _x_28);
  const _x_31 = (_x_29 + _x_30);
  const _x_32 = ($U32$show$(_ns_0));
  const _x_33 = (",next:" + _x_31);
  const _x_34 = (_x_32 + _x_33);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_1, "capacity": _cap_0, "depth": _depth_0, "store": _store_1, "resource": _resource_1, "events": _events_0, "pending": _pending_1, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}, "snd": ("{ns:" + _x_34)};
}

function $observe$058tree$1264$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $observe$058leaf_tree$1264$(($observe$058boolean$(_value_0)));
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $observe$058pair_tree$1264$(($observe$058tree$1264$(_left_0)), ($observe$058tree$1264$(_right_0)));
  }
}

function $observe$058store$(_owner_0) {
  const _heads_0 = _owner_0["heads"];
  const _tails_0 = _owner_0["tails"];
  const _tags_0 = _owner_0["tags"];
  const _data_0 = _owner_0["data"];
  return $observe$058store_join$(($observe$058column$1260$(_heads_0)), ($observe$058column$1261$(_tails_0)), ($observe$058column$1262$(_tags_0)), ($observe$058column$1263$(_data_0)));
}

function $observe$058mail$(_owner_0) {
  const _returned_0 = _owner_0["returned"];
  const _saved_0 = _owner_0["installed"];
  const _quarantine_0 = _owner_0["quarantine"];
  const _errors_0 = _owner_0["errors"];
  const _spare_0 = _owner_0["spare"];
  return $observe$058mail_join$(_errors_0, ($observe$058counted$1260$(_saved_0)), ($observe$058counted$1261$(_quarantine_0)), ($observe$058raws$(_returned_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058tree$(_spare_0)));
}

function $observe$058counted$1262$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $observe$058count_join$1262$(_head_0, ($observe$058counted$1262$(_tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $duplicate$058refusal_raw$(_prefix_0, _registry_0, _world_0, _context_0, _result_0) {
  const _raw_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("|raw=" + _text_0);
  return $duplicate$058refusal_context$((_prefix_0 + _x_0), _registry_0, _world_0, _raw_0, ($$$$047$$$047complete$045families$045v1$047canonical$058context_observe$1260$(_context_0)));
}

function $duplicate$058prepared_text$(_prepared_0) {
  if (_prepared_0.$ === "Nil") {
    return "[]";
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Prepared") {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _rest_0 = _prepared_0["tail"];
      const _x_0 = ($duplicate$058prepared_text$(_rest_0));
      const _x_1 = (_x_0 + "]");
      const _x_2 = ($duplicate$058packet_text$(($duplicate$058raw_observe$(run_loop($duplicate$058unpack$(_payload_0))))));
      const _x_3 = ("};" + _x_1);
      const _x_4 = (_x_2 + _x_3);
      const _x_5 = ($Nat$show$(_position_0));
      const _x_6 = (",raw=" + _x_4);
      const _x_7 = (_x_5 + _x_6);
      const _x_8 = ($U32$show$(_id_0));
      const _x_9 = (",position=" + _x_7);
      const _x_10 = (_x_8 + _x_9);
      const _x_11 = ($U32$show$(_ns_0));
      const _x_12 = (",id=" + _x_10);
      const _x_13 = (_x_11 + _x_12);
      return ("[entry{ns=" + _x_13);
    } else {
      const _t_2 = _t_0["target"];
      const _ns_1 = _t_2["namespace"];
      const _id_1 = _t_2["id"];
      const _rest_1 = _prepared_0["tail"];
      const _x_14 = ($duplicate$058prepared_text$(_rest_1));
      const _x_15 = (_x_14 + "]");
      const _x_16 = ($U32$show$(_id_1));
      const _x_17 = ("};" + _x_15);
      const _x_18 = (_x_16 + _x_17);
      const _x_19 = ($U32$show$(_ns_1));
      const _x_20 = (",id=" + _x_18);
      const _x_21 = (_x_19 + _x_20);
      return ("[reservation{ns=" + _x_21);
    }
  }
}

function $duplicate$058raw_observe$(_raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $duplicate$058raw_join$(($$$$047$$$047complete$045families$045v1$047canonical$058incoming_observe$(_head_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058raw_observe$(_tail_0)));
}

function $duplicate$058admitted_world$(_target_0, _spawned_0, _registry_0, _context_0, _prepared_0, _prefix_0, _observed_0) {
  const _ns_0 = _target_0["namespace"];
  const _id_0 = _target_0["id"];
  const _world_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($Bool$show$(_spawned_0));
  const _x_1 = ("}|world=" + _text_0);
  const _x_2 = (_x_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (",spawned=" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  const _x_6 = ($U32$show$(_ns_0));
  const _x_7 = (",id=" + _x_5);
  const _x_8 = (_x_6 + _x_7);
  const _x_9 = ("\nbypassed-accepted={ns=" + _x_8);
  return $duplicate$058admitted_barrier$((_prefix_0 + _x_9), _registry_0, _context_0, _prepared_0, ($observe$058world$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058codec$1260$(_declaration_0) {
  const _codec_0 = _declaration_0["codec"];
  return _codec_0;
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $List$show$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $List$show$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($observe$058meta$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $observe$058leaf_tree$1264$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": _view_0};
}

function $observe$058boolean$(_value_0) {
  const _copy_0 = _value_0;
  return {$: "Tuple", "fst": _copy_0, "snd": ($Bool$show$(_copy_0))};
}

function $observe$058pair_tree$1264$(_left_0, _right_0) {
  const _a_0 = _left_0["fst"];
  const _x_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _y_0 = _right_0["snd"];
  const _x_1 = (_y_0 + "]");
  const _x_2 = ("," + _x_1);
  const _x_3 = (_x_0 + _x_2);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("[" + _x_3)};
}

function $observe$058store_join$(_left_0, _right_0, _tags_0, _data_0) {
  const _a_0 = _left_0["fst"];
  const _x_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _y_0 = _right_0["snd"];
  const _c_0 = _tags_0["fst"];
  const _z_0 = _tags_0["snd"];
  const _d_0 = _data_0["fst"];
  const _w_0 = _data_0["snd"];
  const _x_1 = (_w_0 + "}");
  const _x_2 = (",data:" + _x_1);
  const _x_3 = (_z_0 + _x_2);
  const _x_4 = (",tags:" + _x_3);
  const _x_5 = (_y_0 + _x_4);
  const _x_6 = (",tails:" + _x_5);
  const _x_7 = (_x_0 + _x_6);
  return {$: "Tuple", "fst": {$: "bundle.Store", "heads": _a_0, "tails": _b_0, "tags": _c_0, "data": _d_0}, "snd": ("{heads:" + _x_7)};
}

function $observe$058column$1260$(_owner_0) {
  if (_owner_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return $observe$058column_join$1260$(_stamps_0, ($observe$058tree$1260$(_values_0)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": "nonplain-column-unqualified"};
  }
}

function $observe$058column$1261$(_owner_0) {
  if (_owner_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return $observe$058column_join$1261$(_stamps_0, ($observe$058tree$1261$(_values_0)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": "nonplain-column-unqualified"};
  }
}

function $observe$058column$1262$(_owner_0) {
  if (_owner_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return $observe$058column_join$1262$(_stamps_0, ($observe$058tree$1262$(_values_0)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": "nonplain-column-unqualified"};
  }
}

function $observe$058column$1263$(_owner_0) {
  if (_owner_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return $observe$058column_join$1263$(_stamps_0, ($observe$058tree$1263$(_values_0)));
  } else {
    return {$: "Tuple", "fst": _owner_0, "snd": "nonplain-column-unqualified"};
  }
}

function $observe$058mail_join$(_errors_0, _saved_0, _quarantine_0, _returned_0, _spare_0) {
  const _saved_1 = _saved_0["fst"];
  const _n_0 = _saved_0["snd"];
  const _quarantine_1 = _quarantine_0["fst"];
  const _q_0 = _quarantine_0["snd"];
  const _returned_1 = _returned_0["fst"];
  const _r_0 = _returned_0["snd"];
  const _spare_1 = _spare_0["fst"];
  const _s_0 = _spare_0["snd"];
  const _x_0 = (_s_0 + "}");
  const _x_1 = ($Nat$show$(($List$length$(_errors_0))));
  const _x_2 = (",spare:" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($Nat$show$(_q_0));
  const _x_5 = (",errors:" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($Nat$show$(_n_0));
  const _x_8 = (",quarantine:" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = (",saved:" + _x_9);
  const _x_11 = (_r_0 + _x_10);
  return {$: "Tuple", "fst": {$: "runtime.Mail", "returned": _returned_1, "installed": _saved_1, "quarantine": _quarantine_1, "errors": _errors_0, "spare": _spare_1}, "snd": ("{returned:" + _x_11)};
}

function $observe$058counted$1260$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $observe$058count_join$1260$(_head_0, ($observe$058counted$1260$(_tail_0)));
  }
}

function $observe$058counted$1261$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _head_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $observe$058count_join$1261$(_head_0, ($observe$058counted$1261$(_tail_0)));
  }
}

function $observe$058raws$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": "end"};
  } else {
    const _owner_0 = _owners_0["head"];
    const _tail_0 = _owners_0["tail"];
    return $observe$058raws_join$(($$$$047$$$047complete$045families$045v1$047canonical$058raw_observe$(_owner_0)), ($observe$058raws$(_tail_0)));
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058tree$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    const _x_0 = ($U32$show$(_value_0));
    const _x_1 = (_x_0 + ")");
    return {$: "Tuple", "fst": [_value_0], "snd": ("L(" + _x_1)};
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047$$$047complete$045families$045v1$047canonical$058tree_join$(($$$$047$$$047complete$045families$045v1$047canonical$058tree$(_a_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058tree$(_b_0)));
  }
}

function $observe$058count_join$1262$(_head_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _n_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _tail_0}, "snd": nat_chk(_n_0 + 1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $duplicate$058refusal_context$(_prefix_0, _registry_0, _world_0, _raw_0, _result_0) {
  const _context_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("|context=" + _text_0);
  return $duplicate$058refusal_world$((_prefix_0 + _x_0), _registry_0, _context_0, _raw_0, ($observe$058world$(_world_0)));
}

function $$$$047$$$047complete$045families$045v1$047canonical$058context_observe$1260$(_context_0) {
  const _factory_0 = _context_0["factory"];
  const _rest_0 = _context_0["rest"];
  const _trail_0 = _context_0["trail"];
  return $$$$047$$$047complete$045families$045v1$047canonical$058context_shown$1260$(($$$$047$$$047complete$045families$045v1$047canonical$058factory_observe$1260$(_factory_0)), _trail_0, ($$$$047$$$047complete$045families$045v1$047canonical$058outer$(_rest_0)));
}

function $duplicate$058packet_text$(_observed_0) {
  const _text_0 = _observed_0["snd"];
  return _text_0;
}

function $duplicate$058unpack$(_packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return run_tail(_undo_0, _cooked_0);
}

function $duplicate$058raw_join$(_head_0, _tail_0) {
  const _a_0 = _head_0["fst"];
  const _x_0 = _head_0["snd"];
  const _b_0 = _tail_0["fst"];
  const _y_0 = _tail_0["snd"];
  const _x_1 = ("/remaining=" + _y_0);
  const _x_2 = (_x_0 + _x_1);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _a_0, "tail": _b_0}, "snd": ("duplicate-head=" + _x_2)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058incoming_observe$(_owner_0) {
  const _owned_0 = _owner_0["owned"];
  const _raw_0 = _owner_0["wire"];
  const _fail_0 = _owner_0["fail"];
  return $$$$047$$$047complete$045families$045v1$047canonical$058incoming_shown$(_raw_0, _fail_0, ($$$$047$$$047complete$045families$045v1$047canonical$058tree$(_owned_0)));
}

function $$$$047$$$047complete$045families$045v1$047canonical$058raw_observe$(_raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047$$$047complete$045families$045v1$047canonical$058raw_join$(($$$$047$$$047complete$045families$045v1$047canonical$058incoming_observe$(_head_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058side_observe$(_tail_0)));
}

function $duplicate$058admitted_barrier$(_prefix_0, _registry_0, _context_0, _prepared_0, _observed_0) {
  const _text_0 = _observed_0["snd"];
  const _x_0 = ("\nbypassed-after-barrier=" + _text_0);
  return $duplicate$058admitted_registry$((_prefix_0 + _x_0), _prepared_0, _context_0, ($duplicate$058registry_observe$(_registry_0)));
}

function $Bool$show$(_b_0) {
  if (!_b_0) {
    return "False";
  } else {
    return "True";
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $List$show$go$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($U32$show$(_h_0));
    const _x_1 = ($List$show$go$1260$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $observe$058meta$(_value_0) {
  const _id_0 = _value_0["id"];
  const _name_0 = _value_0["name"];
  const _access_0 = _value_0["access"];
  const _x_0 = ($List$show$1262$(_access_0));
  const _x_1 = (":" + _x_0);
  const _x_2 = (_name_0 + _x_1);
  const _x_3 = ($U32$show$(_id_0));
  const _x_4 = (":" + _x_2);
  return (_x_3 + _x_4);
}

function $List$show$go$1263$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($observe$058meta$(_h_0));
    const _x_1 = ($List$show$go$1263$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $observe$058column_join$1260$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ($List$show$1261$(_stamps_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (",stamps:" + _x_1);
  const _x_3 = (_view_0 + _x_2);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ("{values:" + _x_3)};
}

function $observe$058tree$1260$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $observe$058leaf_tree$1260$(($observe$058optional$1260$(_value_0)));
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $observe$058pair_tree$1260$(($observe$058tree$1260$(_left_0)), ($observe$058tree$1260$(_right_0)));
  }
}

function $observe$058column_join$1261$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ($List$show$1261$(_stamps_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (",stamps:" + _x_1);
  const _x_3 = (_view_0 + _x_2);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ("{values:" + _x_3)};
}

function $observe$058tree$1261$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $observe$058leaf_tree$1261$(($observe$058optional$1261$(_value_0)));
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $observe$058pair_tree$1261$(($observe$058tree$1261$(_left_0)), ($observe$058tree$1261$(_right_0)));
  }
}

function $observe$058column_join$1262$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ($List$show$1261$(_stamps_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (",stamps:" + _x_1);
  const _x_3 = (_view_0 + _x_2);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ("{values:" + _x_3)};
}

function $observe$058tree$1262$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $observe$058leaf_tree$1262$(($observe$058optional$1262$(_value_0)));
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $observe$058pair_tree$1262$(($observe$058tree$1262$(_left_0)), ($observe$058tree$1262$(_right_0)));
  }
}

function $observe$058column_join$1263$(_stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ($List$show$1261$(_stamps_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = (",stamps:" + _x_1);
  const _x_3 = (_view_0 + _x_2);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ("{values:" + _x_3)};
}

function $observe$058tree$1263$(_owner_0) {
  if (_owner_0.length === 1) {
    const _value_0 = _owner_0[0];
    return $observe$058leaf_tree$1263$(($observe$058optional$1263$(_value_0)));
  } else {
    const _left_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _right_0 = _owner_0.slice(_owner_0.length >> 1);
    return $observe$058pair_tree$1263$(($observe$058tree$1263$(_left_0)), ($observe$058tree$1263$(_right_0)));
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $observe$058count_join$1260$(_head_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _n_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _tail_0}, "snd": nat_chk(_n_0 + 1)};
}

function $observe$058count_join$1261$(_head_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _n_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _head_0, "tail": _tail_0}, "snd": nat_chk(_n_0 + 1)};
}

function $observe$058raws_join$(_raw_0, _tail_0) {
  const _raw_1 = _raw_0["fst"];
  const _x_0 = _raw_0["snd"];
  const _tail_1 = _tail_0["fst"];
  const _y_0 = _tail_0["snd"];
  const _x_1 = (";" + _y_0);
  return {$: "Tuple", "fst": {$: "Con", "head": _raw_1, "tail": _tail_1}, "snd": (_x_0 + _x_1)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058tree_join$(_left_0, _right_0) {
  const _a_0 = _left_0["fst"];
  const _x_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _y_0 = _right_0["snd"];
  const _x_1 = (_y_0 + ")");
  const _x_2 = ("," + _x_1);
  const _x_3 = (_x_0 + _x_2);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_3)};
}

function $duplicate$058refusal_world$(_prefix_0, _registry_0, _context_0, _raw_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ("|world=" + _text_0);
  return $duplicate$058repaired$((_prefix_0 + _x_0), _registry_0, _world_0, _context_0, _raw_0);
}

function $$$$047$$$047complete$045families$045v1$047canonical$058context_shown$1260$(_factory_0, _trail_0, _observed_0) {
  const _f_0 = _factory_0["fst"];
  const _description_0 = _factory_0["snd"];
  const _rest_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($List$show$1262$(_trail_0));
  const _x_1 = ("/trail=" + _x_0);
  const _x_2 = (_text_0 + _x_1);
  const _x_3 = ("/rest=" + _x_2);
  const _x_4 = (_description_0 + _x_3);
  return {$: "Tuple", "fst": {$: "../../complete-families-v1/canonical.Context", "factory": _f_0, "rest": _rest_0, "trail": _trail_0}, "snd": ("factory=" + _x_4)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058factory_observe$1260$(_factory_0) {
  const _declaration_0 = _factory_0["declaration"];
  const _inputCodec_0 = _factory_0["inputCodec"];
  const _x_0 = ($$$$047$$$047complete$045families$045v1$047canonical$058codec$(_inputCodec_0));
  const _x_1 = ($$$$047$$$047complete$045families$045v1$047canonical$058codec$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058codec$1260$(_declaration_0))));
  const _x_2 = ("/input=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047complete$045families$045v1$047canonical$058identity$1260$())));
  const _x_5 = ("/decl=" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/decode-construction.FallibleFactory", "declaration": _declaration_0, "inputCodec": _inputCodec_0}, "snd": ("identity=" + _x_6)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058outer$(_owner_0) {
  if (_owner_0.length === 1) {
    const _owned_0 = _owner_0[0];
    return $$$$047$$$047complete$045families$045v1$047canonical$058outer_leaf$(($$$$047$$$047complete$045families$045v1$047canonical$058tree$(_owned_0)));
  } else {
    const _a_0 = _owner_0.slice(0, _owner_0.length >> 1);
    const _b_0 = _owner_0.slice(_owner_0.length >> 1);
    return $$$$047$$$047complete$045families$045v1$047canonical$058outer_join$(($$$$047$$$047complete$045families$045v1$047canonical$058outer$(_a_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058outer$(_b_0)));
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058incoming_shown$(_raw_0, _fail_0, _observed_0) {
  const _owned_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($Bool$show$(_fail_0));
  const _x_1 = ($$$$047$$$047complete$045families$045v1$047canonical$058wire$(_raw_0));
  const _x_2 = ("/fail=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("/wire=" + _x_3);
  return {$: "Tuple", "fst": {$: "../../complete-families-v1/canonical.Incoming", "owned": _owned_0, "wire": _raw_0, "fail": _fail_0}, "snd": (_text_0 + _x_4)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058raw_join$(_head_0, _tail_0) {
  const _a_0 = _head_0["fst"];
  const _x_0 = _head_0["snd"];
  const _b_0 = _tail_0["fst"];
  const _y_0 = _tail_0["snd"];
  const _x_1 = ("/tail=" + _y_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _a_0, "tail": _b_0}, "snd": (_x_0 + _x_1)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058side_observe$(_owner_0) {
  const _tail_0 = _owner_0["head"];
  const _t_0 = _owner_0["tail"];
  const _tag_0 = _t_0["head"];
  const _t_1 = _t_0["tail"];
  const _data_0 = _t_1["head"];
  return $$$$047$$$047complete$045families$045v1$047canonical$058side_join$(_tag_0, _data_0, ($$$$047$$$047complete$045families$045v1$047canonical$058tail_observe$(_tail_0)));
}

function $duplicate$058admitted_registry$(_prefix_0, _prepared_0, _context_0, _observed_0) {
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($duplicate$058prepared_text$(_prepared_0));
  const _x_1 = ($duplicate$058context_text$(($$$$047$$$047complete$045families$045v1$047canonical$058context_observe$1260$(_context_0))));
  const _x_2 = ("|prepared=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("|context=" + _x_3);
  const _x_5 = (_text_0 + _x_4);
  const _x_6 = ("|registry=" + _x_5);
  return (_prefix_0 + _x_6);
}

function $duplicate$058registry_observe$(_owner_0) {
  const _ns_0 = _owner_0["namespace"];
  const _id_0 = _owner_0["id"];
  const _name_0 = _owner_0["name"];
  const _access_0 = _owner_0["access"];
  const _cursor_0 = _owner_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($List$show$1262$(_access_0));
  const _x_3 = (",cursor=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = (",access=" + _x_4);
  const _x_6 = (_name_0 + _x_5);
  const _x_7 = ($U32$show$(_id_0));
  const _x_8 = (",name=" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_ns_0));
  const _x_11 = (",id=" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": ("{ns=" + _x_12)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1262$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return ("[" + _x_1);
  }
}

function $List$show$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "[]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($observe$058stamp$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return ("[" + _x_2);
  }
}

function $observe$058leaf_tree$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": _view_0};
}

function $observe$058optional$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "null"};
  } else {
    const _value_0 = _owner_0["value"];
    return $observe$058some_shown$1260$(($$$$047$$$047complete$045families$045v1$047canonical$058payload_observe$(_value_0)));
  }
}

function $observe$058pair_tree$1260$(_left_0, _right_0) {
  const _a_0 = _left_0["fst"];
  const _x_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _y_0 = _right_0["snd"];
  const _x_1 = (_y_0 + "]");
  const _x_2 = ("," + _x_1);
  const _x_3 = (_x_0 + _x_2);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("[" + _x_3)};
}

function $observe$058leaf_tree$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": _view_0};
}

function $observe$058optional$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "null"};
  } else {
    const _value_0 = _owner_0["value"];
    return $observe$058some_shown$1261$(($$$$047$$$047complete$045families$045v1$047canonical$058tail_observe$(_value_0)));
  }
}

function $observe$058pair_tree$1261$(_left_0, _right_0) {
  const _a_0 = _left_0["fst"];
  const _x_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _y_0 = _right_0["snd"];
  const _x_1 = (_y_0 + "]");
  const _x_2 = ("," + _x_1);
  const _x_3 = (_x_0 + _x_2);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("[" + _x_3)};
}

function $observe$058leaf_tree$1262$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": _view_0};
}

function $observe$058optional$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "null"};
  } else {
    const _value_0 = _owner_0["value"];
    return $observe$058some_shown$1262$(($$$$047$$$047complete$045families$045v1$047canonical$058tag_observe$(_value_0)));
  }
}

function $observe$058pair_tree$1262$(_left_0, _right_0) {
  const _a_0 = _left_0["fst"];
  const _x_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _y_0 = _right_0["snd"];
  const _x_1 = (_y_0 + "]");
  const _x_2 = ("," + _x_1);
  const _x_3 = (_x_0 + _x_2);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("[" + _x_3)};
}

function $observe$058leaf_tree$1263$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_owner_0], "snd": _view_0};
}

function $observe$058optional$1263$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": "null"};
  } else {
    const _value_0 = _owner_0["value"];
    return $observe$058some_shown$1263$(($$$$047$$$047complete$045families$045v1$047canonical$058data_observe$(_value_0)));
  }
}

function $observe$058pair_tree$1263$(_left_0, _right_0) {
  const _a_0 = _left_0["fst"];
  const _x_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _y_0 = _right_0["snd"];
  const _x_1 = (_y_0 + "]");
  const _x_2 = ("," + _x_1);
  const _x_3 = (_x_0 + _x_2);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("[" + _x_3)};
}

function $duplicate$058repaired$(_prefix_0, _registry_0, _world_0, _context_0, _raw_0) {
  const _extra_0 = _raw_0["head"];
  const _remaining_0 = _raw_0["tail"];
  const _x_0 = ($duplicate$058extra_finished$(_registry_0, _extra_0, ($drive$058begin_returned$(_world_0, _context_0, _remaining_0))));
  const _x_1 = ("\n" + _x_0);
  return (_prefix_0 + _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047complete$045families$045v1$047canonical$058identity$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1263$("constructed-array");
}

function $$$$047$$$047complete$045families$045v1$047canonical$058codec$(_value_0) {
  if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.FiniteNumber") {
    return "FiniteNumber";
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Integer") {
    return "Integer";
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.StringValue") {
    return "StringValue";
  } else if (_value_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.BoolValue") {
    return "BoolValue";
  } else {
    return "unexpected-codec";
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058outer_leaf$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = (_text_0 + ")");
  return {$: "Tuple", "fst": [_owner_0], "snd": ("L(" + _x_0)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058outer_join$(_left_0, _right_0) {
  const _a_0 = _left_0["fst"];
  const _x_0 = _left_0["snd"];
  const _b_0 = _right_0["fst"];
  const _y_0 = _right_0["snd"];
  const _x_1 = (_y_0 + ")");
  const _x_2 = ("," + _x_1);
  const _x_3 = (_x_0 + _x_2);
  return {$: "Tuple", "fst": array_node(_a_0, _b_0), "snd": ("N(" + _x_3)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058wire$(_raw_0) {
  if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Number") {
    const _n_0 = _raw_0["value"];
    const _x_0 = ($U32$show$(_n_0));
    const _x_1 = (_x_0 + ")");
    return ("Number(" + _x_1);
  } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Text") {
    const _x_2 = _raw_0["value"];
    const _x_3 = (_x_2 + ")");
    return ("Text(" + _x_3);
  } else {
    return "unexpected";
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058side_join$(_tag_0, _data_0, _observed_0) {
  const _tail_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($U32$show$(_data_0));
  const _x_1 = ("/tag-component=Tag/data-component=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tail_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tag_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _data_0, "tail": {$: "Unit"}}}}, "snd": (_text_0 + _x_1)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058tail_observe$(_owner_0) {
  const _owned_0 = _owner_0["owned"];
  const _tag_0 = _owner_0["tag"];
  const _scalar_0 = _owner_0["scalar"];
  return $$$$047$$$047complete$045families$045v1$047canonical$058tail_shown$(_tag_0, _scalar_0, ($$$$047$$$047complete$045families$045v1$047canonical$058tree$(_owned_0)));
}

function $duplicate$058context_text$(_observed_0) {
  const _text_0 = _observed_0["snd"];
  return _text_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $List$show$go$1262$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($List$show$go$1262$(_t_0));
    const _x_1 = (_h_0 + _x_0);
    return (", " + _x_1);
  }
}

function $observe$058stamp$(_value_0) {
  const _id_0 = _value_0["id"];
  const _t_0 = _value_0["stamp"];
  const _added_0 = _t_0["added"];
  const _changed_0 = _t_0["changed"];
  const _x_0 = ($U32$show$(_changed_0));
  const _x_1 = ($U32$show$(_added_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($U32$show$(_id_0));
  const _x_5 = (":" + _x_3);
  return (_x_4 + _x_5);
}

function $List$show$go$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "]";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($observe$058stamp$(_h_0));
    const _x_1 = ($List$show$go$1261$(_t_0));
    const _x_2 = (_x_0 + _x_1);
    return (", " + _x_2);
  }
}

function $observe$058some_shown$1260$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": _view_0};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058payload_observe$(_owner_0) {
  const _owned_0 = _owner_0["owned"];
  const _number_0 = _owner_0["number"];
  return $$$$047$$$047complete$045families$045v1$047canonical$058payload_shown$(_number_0, ($$$$047$$$047complete$045families$045v1$047canonical$058tree$(_owned_0)));
}

function $observe$058some_shown$1261$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": _view_0};
}

function $observe$058some_shown$1262$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": _view_0};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058tag_observe$(_owner_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": "Tag"};
}

function $observe$058some_shown$1263$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Some", "value": _owner_0}, "snd": _view_0};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058data_observe$(_owner_0) {
  const _copy_0 = _owner_0;
  return {$: "Tuple", "fst": _copy_0, "snd": ($U32$show$(_copy_0))};
}

function $duplicate$058extra_finished$(_registry_0, _extra_0, _normal_0) {
  return $duplicate$058extra_observed$(_normal_0, ($duplicate$058registry_observe$(_registry_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058incoming_observe$(_extra_0)));
}

function $drive$058begin_returned$(_world_0, _context_0, _raw_0) {
  return $drive$058registered_returned$(_context_0, _raw_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, "canonical-bundle", {$: "Con", "head": "bundle:write", "tail": {$: "Nil"}})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1263$(_key_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058tail_shown$(_tag_0, _scalar_0, _observed_0) {
  const _owned_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($U32$show$(_scalar_0));
  const _x_1 = ($Bool$show$(_tag_0));
  const _x_2 = ("/scalar=" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ("/tag=" + _x_3);
  return {$: "Tuple", "fst": {$: "../../complete-families-v1/canonical.Tail", "owned": _owned_0, "tag": _tag_0, "scalar": _scalar_0}, "snd": (_text_0 + _x_4)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058payload_shown$(_number_0, _observed_0) {
  const _owned_0 = _observed_0["fst"];
  const _text_0 = _observed_0["snd"];
  const _x_0 = ($U32$show$(_number_0));
  const _x_1 = ("/number=" + _x_0);
  return {$: "Tuple", "fst": {$: "../../complete-families-v1/canonical.Payload", "owned": _owned_0, "number": _number_0}, "snd": (_text_0 + _x_1)};
}

function $duplicate$058extra_observed$(_normal_0, _registry_0, _extra_0) {
  const _r_0 = _registry_0["snd"];
  const _e_0 = _extra_0["snd"];
  const _x_0 = ("|registry=" + _r_0);
  const _x_1 = (_e_0 + _x_0);
  const _x_2 = ("\nduplicate-owner-final=" + _x_1);
  return (_normal_0 + _x_2);
}

function $drive$058registered_returned$(_context_0, _raw_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Registered") {
    const _world_0 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $drive$058initial_returned$(_raw_0, ($observe$058session$({$: "observe.Session", "registry": _registry_0, "world": _world_0, "context": _context_0})));
  } else {
    const _world_1 = _result_0["world"];
    return $drive$058failed_world$("registration", ($observe$058world$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $drive$058initial_returned$(_raw_0, _result_0) {
  const _session_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  return $drive$058run$1261$(("initial=" + _view_0), _session_0, {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Input", "operation": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Spawn"}, "raw": _raw_0});
}

function $observe$058session$(_owner_0) {
  const _reg_0 = _owner_0["registry"];
  const _w_0 = _owner_0["world"];
  const _ctx_0 = _owner_0["context"];
  return $observe$058session_join$(($observe$058registry$(_reg_0)), ($observe$058world$(_w_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058context_observe$1260$(_ctx_0)));
}

function $drive$058failed_world$(_error_0, _result_0) {
  const _view_0 = _result_0["snd"];
  const _x_0 = ("|" + _view_0);
  const _x_1 = (_error_0 + _x_0);
  return ("unexpected-system-failure=" + _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, ($duplicate$058runner$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $drive$058run$1261$(_prefix_0, _session_0, _input_0) {
  const _registry_0 = _session_0["registry"];
  const _world_0 = _session_0["world"];
  const _context_0 = _session_0["context"];
  return $drive$058after_run$1261$(_prefix_0, ($runtime$058run$(_registry_0, _world_0, {$: "Tuple", "fst": _context_0, "snd": _input_0})));
}

function $observe$058session_join$(_registry_0, _world_0, _context_0) {
  const _reg_0 = _registry_0["fst"];
  const _g_0 = _registry_0["snd"];
  const _world_1 = _world_0["fst"];
  const _w_0 = _world_0["snd"];
  const _ctx_0 = _context_0["fst"];
  const _c_0 = _context_0["snd"];
  const _x_0 = ("|context=" + _c_0);
  const _x_1 = (_w_0 + _x_0);
  const _x_2 = ("|world=" + _x_1);
  const _x_3 = (_g_0 + _x_2);
  return {$: "Tuple", "fst": {$: "observe.Session", "registry": _reg_0, "world": _world_1, "context": _ctx_0}, "snd": ("registry=" + _x_3)};
}

function $observe$058registry$(_owner_0) {
  const _ns_0 = _owner_0["namespace"];
  const _id_0 = _owner_0["id"];
  const _name_0 = _owner_0["name"];
  const _access_0 = _owner_0["access"];
  const _cursor_0 = _owner_0["cursor"];
  const _x_0 = ($U32$show$(_cursor_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($List$show$1262$(_access_0));
  const _x_3 = (",cursor:" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = (",access:" + _x_4);
  const _x_6 = (_name_0 + _x_5);
  const _x_7 = ($U32$show$(_id_0));
  const _x_8 = (",name:" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($U32$show$(_ns_0));
  const _x_11 = (",id:" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _ns_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": ("{ns:" + _x_12)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $duplicate$058runner$(_world_0, _args_0) {
  const _context_0 = _args_0["fst"];
  const _input_0 = _args_0["snd"];
  return $duplicate$058owned_result$(run_loop($duplicate$058run_owned$({$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058begin$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)))), "context": _context_0}, _input_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $drive$058after_run$1261$(_prefix_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _t_1 = _t_0["output"];
      const _context_0 = _t_1["fst"];
      const _output_0 = _t_1["snd"];
      return $drive$058spawn_result$(_prefix_0, {$: "observe.Session", "registry": _registry_0, "world": _world_0, "context": _context_0}, _output_0);
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return $drive$058failed_world$(_error_0, ($observe$058world$(_world_1)));
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $drive$058rejected$(_registry_1, _world_2, _args_0);
  }
}

function $runtime$058run$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $duplicate$058owned_result$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["batch"];
  const _tx_0 = _t_1["tx"];
  const _prepared_0 = _t_1["prepared"];
  const _context_0 = _t_0["context"];
  const _output_0 = _result_0["snd"];
  return $duplicate$058finished$(_context_0, _output_0, _prepared_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"})));
}

function $duplicate$058run_owned$(_owner_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045provider$058provide_owned$1261$(_input_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058begin$1260$(_tx_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": _tx_0, "prepared": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $drive$058spawn_result$(_prefix_0, _session_0, _output_0) {
  if (_output_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-requests.Accepted") {
    const _target_0 = _output_0["target"];
    return $drive$058spawn_queued$(_target_0, _prefix_0, ($observe$058session$(_session_0)));
  } else {
    const _raw_0 = _output_0["raw"];
    return $drive$058rejected_raw$(($observe$058session$(_session_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058raw_observe$(_raw_0)));
  }
}

function $drive$058rejected$(_registry_0, _world_0, _args_0) {
  const _context_0 = _args_0["fst"];
  const _t_0 = _args_0["snd"];
  const _raw_0 = _t_0["raw"];
  return $drive$058rejected_raw$(($observe$058session$({$: "observe.Session", "registry": _registry_0, "world": _world_0, "context": _context_0})), ($$$$047$$$047complete$045families$045v1$047canonical$058raw_observe$(_raw_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $duplicate$058finished$(_context_0, _output_0, _prepared_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/transaction.Success") {
    return {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": {$: "duplicate.OwnedOutput", "context": _context_0, "output": _output_0, "prepared": _prepared_0}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045provider$058provide_owned$1261$(_args_0, _ctx_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $drive$058spawn_queued$(_target_0, _prefix_0, _result_0) {
  const _session_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ("\nspawn-queued=" + _view_0);
  return $drive$058installed$(_target_0, (_prefix_0 + _x_0), ($observe$058session$(($drive$058barrier$(_session_0)))));
}

function $drive$058rejected_raw$(_session_0, _raw_0) {
  const _s_0 = _session_0["snd"];
  const _r_0 = _raw_0["snd"];
  const _x_0 = ("|raw=" + _r_0);
  const _x_1 = (_s_0 + _x_0);
  return ("unexpected-registration-refusal=" + _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1261$(_args_0, _ctx_0) {
  return $duplicate$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $drive$058installed$(_target_0, _prefix_0, _result_0) {
  const _session_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ("\ninstalled=" + _view_0);
  return $drive$058run$1260$((_prefix_0 + _x_0), _session_0, {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Input", "operation": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Insert", "target": _target_0}, "raw": ($drive$058replacement$())});
}

function $drive$058barrier$(_session_0) {
  const _registry_0 = _session_0["registry"];
  const _world_0 = _session_0["world"];
  const _context_0 = _session_0["context"];
  return {$: "observe.Session", "registry": _registry_0, "world": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058barrier$1260$(_world_0)), "context": _context_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $duplicate$058body$1260$(_input_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1261$(_owner_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $drive$058run$1260$(_prefix_0, _session_0, _input_0) {
  const _registry_0 = _session_0["registry"];
  const _world_0 = _session_0["world"];
  const _context_0 = _session_0["context"];
  return $drive$058after_run$1260$(_prefix_0, ($runtime$058run$(_registry_0, _world_0, {$: "Tuple", "fst": _context_0, "snd": _input_0})));
}

function $drive$058replacement$() {
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../complete-families-v1/canonical.Incoming", "owned": array_node([41], [42]), "wire": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Number", "value": 17}, "fail": false}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../complete-families-v1/canonical.Tail", "owned": array_node(array_node([51], [52]), array_node([53], [54])), "tag": false, "scalar": 61}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../complete-families-v1/canonical.Tag"}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": 202, "tail": {$: "Unit"}}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1261$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1261$({$: "../../../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $duplicate$058request$(_x_0, _x_1);
});
})}))(_ctx_0), _input_0);
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $drive$058after_run$1260$(_prefix_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/system.Completed") {
    const _registry_0 = _result_0["registry"];
    const _t_0 = _result_0["outcome"];
    if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/system.Succeeded") {
      const _world_0 = _t_0["world"];
      const _t_1 = _t_0["output"];
      const _context_0 = _t_1["fst"];
      const _output_0 = _t_1["snd"];
      return $drive$058replacement_result$(_prefix_0, {$: "observe.Session", "registry": _registry_0, "world": _world_0, "context": _context_0}, _output_0);
    } else {
      const _world_1 = _t_0["world"];
      const _error_0 = _t_0["error"];
      return $drive$058failed_world$(_error_0, ($observe$058world$(_world_1)));
    }
  } else {
    const _registry_1 = _result_0["registry"];
    const _world_2 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $drive$058rejected$(_registry_1, _world_2, _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": {$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../../../bendvy/src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1261$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $duplicate$058request$(_owner_0, _input_0) {
  return $ordinary$045bundle$058request$1261$(($duplicate$058plan$()), _owner_0, _input_0);
}

function $drive$058replacement_result$(_prefix_0, _session_0, _output_0) {
  if (_output_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-requests.Accepted") {
    return $drive$058replacement_queued$(_prefix_0, ($observe$058session$(_session_0)));
  } else {
    const _raw_0 = _output_0["raw"];
    return $drive$058rejected_raw$(($observe$058session$(_session_0)), ($$$$047$$$047complete$045families$045v1$047canonical$058raw_observe$(_raw_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $ordinary$045bundle$058request$1261$(_plan_0, _owner_0, _input_0) {
  return $ordinary$045bundle$058checked$1261$({$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Valid"}, _owner_0, _input_0);
}

function $duplicate$058plan$() {
  return $ordinary$045bundle$058compose$1264$(($ordinary$045bundle$058component$1263$(($$$$047$$$047complete$045families$045v1$047canonical$058identity$1260$()))), ($bundle$058plan$()));
}

function $drive$058replacement_queued$(_prefix_0, _result_0) {
  const _session_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ("\nreplacement-queued=" + _view_0);
  return $drive$058replaced$((_prefix_0 + _x_0), ($observe$058session$(($drive$058barrier$(_session_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, ($runtime$058runner$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $ordinary$045bundle$058checked$1261$(_validation_0, _owner_0, _input_0) {
  if (_validation_0.$ === "../../../../../../../../bendvy/src/ecs/schema-fragments.Invalid") {
    const _error_0 = _validation_0["error"];
    const _raw_0 = _input_0["raw"];
    return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused", "raw": _raw_0, "error": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.DeclarationRefused", "error": _error_0}}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058request$1261$(_owner_0, _input_0);
  }
}

function $ordinary$045bundle$058compose$1264$(_head_0, _tail_0) {
  const _heads_0 = _head_0["entries"];
  const _tails_0 = _tail_0["entries"];
  return {$: "ordinary-bundle.Plan", "entries": ($List$append$(_heads_0, _tails_0))};
}

function $ordinary$045bundle$058component$1263$(_identity_0) {
  return {$: "ordinary-bundle.Plan", "entries": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Component"}, "key": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(_identity_0)), "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(_identity_0))}, "tail": {$: "Nil"}}};
}

function $bundle$058plan$() {
  return $ordinary$045bundle$058compose$1263$(($ordinary$045bundle$058component$1263$(($$$$047$$$047complete$045families$045v1$047canonical$058identity$1260$()))), ($bundle$058plan_side$()));
}

function $drive$058replaced$(_prefix_0, _result_0) {
  const _session_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ("\nreplaced=" + _view_0);
  return $drive$058restored$((_prefix_0 + _x_0), ($observe$058session$(($drive$058unwind$(_session_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $runtime$058runner$(_world_0, _args_0) {
  return $runtime$058succeeded$(($runtime$058request$(_world_0, _args_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058request$1261$(_owner_0, _input_0) {
  const _batch_0 = _owner_0["batch"];
  const _context_0 = _owner_0["context"];
  const _operation_0 = _input_0["operation"];
  const _raw_0 = _input_0["raw"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058constructed$1261$(_batch_0, _operation_0, ($duplicate$058construct$(_context_0, _raw_0)));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $ordinary$045bundle$058compose$1263$(_head_0, _tail_0) {
  const _heads_0 = _head_0["entries"];
  const _tails_0 = _tail_0["entries"];
  return {$: "ordinary-bundle.Plan", "entries": ($List$append$(_heads_0, _tails_0))};
}

function $bundle$058plan_side$() {
  return $ordinary$045bundle$058compose$1262$(($ordinary$045bundle$058component$1262$(($bundle$058tail_identity$()))), ($bundle$058plan_extras$()));
}

function $drive$058restored$(_prefix_0, _result_0) {
  const _session_0 = _result_0["fst"];
  const _view_0 = _result_0["snd"];
  const _x_0 = ("\nrestored=" + _view_0);
  return $drive$058finished$((_prefix_0 + _x_0), ($observe$058session$(($drive$058unwind$(_session_0)))));
}

function $drive$058unwind$(_session_0) {
  const _registry_0 = _session_0["registry"];
  const _world_0 = _session_0["world"];
  const _context_0 = _session_0["context"];
  return {$: "observe.Session", "registry": _registry_0, "world": ($runtime$058unwind$(_world_0)), "context": _context_0};
}

function $runtime$058succeeded$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/system.Succeeded", "world": _world_0, "output": _output_0};
}

function $runtime$058request$(_world_0, _args_0) {
  const _context_0 = _args_0["fst"];
  const _input_0 = _args_0["snd"];
  return $runtime$058finish$(run_loop($bundle$058run$1260$({$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058begin$1260$(_world_0)), "prepared": {$: "Nil"}}, "context": _context_0}, _input_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058constructed$1261$(_batch_0, _operation_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed") {
    const _context_0 = _result_0["context"];
    const _raw_0 = _result_0["raw"];
    const _positions_0 = _result_0["positions"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused", "raw": _raw_0, "error": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.ConstructionRefused", "positions": _positions_0}}};
  } else {
    const _context_1 = _result_0["context"];
    const _cooked_0 = _result_0["cooked"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058enqueue$1261$(_batch_0, _context_1, _operation_0, ($duplicate$058pack$(_cooked_0, _undo_0)));
  }
}

function $duplicate$058construct$(_context_0, _raw_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058canonical_stage$1261$(_context_0, _raw_0);
}

function $ordinary$045bundle$058compose$1262$(_head_0, _tail_0) {
  const _heads_0 = _head_0["entries"];
  const _tails_0 = _tail_0["entries"];
  return {$: "ordinary-bundle.Plan", "entries": ($List$append$(_heads_0, _tails_0))};
}

function $ordinary$045bundle$058component$1262$(_identity_0) {
  return {$: "ordinary-bundle.Plan", "entries": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Component"}, "key": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1261$(_identity_0)), "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1261$(_identity_0))}, "tail": {$: "Nil"}}};
}

function $bundle$058tail_identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1260$("canonical-tail");
}

function $bundle$058plan_extras$() {
  return $ordinary$045bundle$058compose$1261$(($ordinary$045bundle$058component$1261$(($bundle$058tag_identity$()))), ($bundle$058plan_data$()));
}

function $drive$058finished$(_prefix_0, _result_0) {
  const _view_0 = _result_0["snd"];
  const _x_0 = ("\ncleaned=" + _view_0);
  return (_prefix_0 + _x_0);
}

function $runtime$058unwind$(_world_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _returned_0 = _t_0["returned"];
  const _t_1 = _t_0["installed"];
  if (_t_1.$ === "Con") {
    const _t_2 = _t_1["head"];
    const _inverse_0 = _t_2["inverse"];
    const _undo_0 = _t_2["undo"];
    const _saved_0 = _t_1["tail"];
    const _quarantine_0 = _t_0["quarantine"];
    const _errors_0 = _t_0["errors"];
    const _spare_0 = _t_0["spare"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _regs_0 = _world_0["registrations"];
    const _system_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return $runtime$058unwound$(_undo_0, _inverse_0({$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "runtime.Mail", "returned": _returned_0, "installed": _saved_0, "quarantine": _quarantine_0, "errors": _errors_0, "spare": _spare_0}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}));
  } else {
    const _quarantine_1 = _t_0["quarantine"];
    const _errors_1 = _t_0["errors"];
    const _spare_1 = _t_0["spare"];
    const _events_1 = _world_0["events"];
    const _pending_1 = _world_0["pending"];
    const _regs_1 = _world_0["registrations"];
    const _system_1 = _world_0["nextSystemId"];
    const _clock_1 = _world_0["clock"];
    return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "runtime.Mail", "returned": _returned_0, "installed": _t_1, "quarantine": _quarantine_1, "errors": _errors_1, "spare": _spare_1}, "events": _events_1, "pending": _pending_1, "registrations": _regs_1, "nextSystemId": _system_1, "clock": _clock_1};
  }
}

function $runtime$058finish$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _batch_0 = _t_0["batch"];
  const _context_0 = _t_0["context"];
  const _output_0 = _result_0["snd"];
  return $runtime$058finished$(_context_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058finish$1260$(_batch_0, {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"})));
}

function $bundle$058run$1260$(_owner_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045provider$058provide_owned$1260$(_input_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058enqueue$1261$(_batch_0, _context_0, _operation_0, _packet_0) {
  if (_operation_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-requests.Spawn") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058spawned$1261$(_context_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn$1261$(_batch_0, _packet_0)));
  } else {
    const _target_0 = _operation_0["target"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058inserted$1261$(_context_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058insert$1261$(_batch_0, _target_0, _packet_0)));
  }
}

function $duplicate$058pack$(_cooked_0, _undo_0) {
  return {$: "duplicate.Packet", "cooked": _cooked_0, "undo": _undo_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058canonical_stage$1261$(_ctx_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058stage$1261$(_ctx_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1261$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1260$(_key_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $ordinary$045bundle$058compose$1261$(_head_0, _tail_0) {
  const _heads_0 = _head_0["entries"];
  const _tails_0 = _tail_0["entries"];
  return {$: "ordinary-bundle.Plan", "entries": ($List$append$(_heads_0, _tails_0))};
}

function $ordinary$045bundle$058component$1261$(_identity_0) {
  return {$: "ordinary-bundle.Plan", "entries": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Component"}, "key": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(_identity_0)), "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(_identity_0))}, "tail": {$: "Nil"}}};
}

function $bundle$058tag_identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1261$("canonical-tag");
}

function $bundle$058plan_data$() {
  return $ordinary$045bundle$058compose$1260$(($ordinary$045bundle$058component$1260$(($bundle$058data_identity$()))), ($ordinary$045bundle$058terminal$1260$()));
}

function $runtime$058unwound$(_undo_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _entries_0 = _result_0["payload"];
    return $runtime$058restored_entries$(_world_0, _undo_0, ($bundle$058cooked_of$(_entries_0)));
  } else {
    const _t_0 = _result_0["world"];
    const _ns_0 = _t_0["namespace"];
    const _next_0 = _t_0["nextId"];
    const _high_0 = _t_0["highWater"];
    const _live_0 = _t_0["live"];
    const _cap_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _store_0 = _t_0["store"];
    const _t_1 = _t_0["resource"];
    const _returned_0 = _t_1["returned"];
    const _saved_0 = _t_1["installed"];
    const _quarantine_0 = _t_1["quarantine"];
    const _errors_0 = _t_1["errors"];
    const _spare_0 = _t_1["spare"];
    const _events_0 = _t_0["events"];
    const _pending_0 = _t_0["pending"];
    const _regs_0 = _t_0["registrations"];
    const _system_0 = _t_0["nextSystemId"];
    const _clock_0 = _t_0["clock"];
    const _recovery_0 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "runtime.Mail", "returned": _returned_0, "installed": _saved_0, "quarantine": {$: "Con", "head": {$: "runtime.Recovery", "recovery": _recovery_0, "undo": _undo_0, "error": _error_0}, "tail": _quarantine_0}, "errors": {$: "Con", "head": _error_0, "tail": _errors_0}, "spare": _spare_0}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
  }
}

function $runtime$058finished$(_context_0, _output_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Committed") {
    const _world_0 = _result_0["world"];
    return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _context_0, "snd": _output_0}};
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": {$: "Tuple", "fst": _context_0, "snd": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058finish$1260$(_batch_0, _outcome_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  if (_outcome_0.$ === "../../../../../../../../bendvy/src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058committed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058stage$1260$(($List$reverse$(_prepared_0)), _tx_0)), {$: "../../../../../../../../bendvy/src/ecs/transaction.Success"})));
  } else {
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058failed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1260$(($List$reverse$(_prepared_0)))), _error_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../../../../../../bendvy/src/ecs/transaction.Failure", "error": _error_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045provider$058provide_owned$1260$(_args_0, _ctx_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058spawned$1261$(_context_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Spawned") {
    const _batch_0 = _result_0["batch"];
    const _target_0 = _result_0["target"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Accepted", "target": _target_0, "spawned": true}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _packet_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_1, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused", "raw": run_loop($duplicate$058unpack$(_packet_0)), "error": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.EntityRefused", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn$1261$(_batch_0, _payload_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_reserved$1261$(_prepared_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, {$: "Unit"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058inserted$1261$(_context_0, _target_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Accepted", "target": _target_0, "spawned": false}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _packet_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_1, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused", "raw": run_loop($duplicate$058unpack$(_packet_0)), "error": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.EntityRefused", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058insert$1261$(_batch_0, _target_0, _payload_0) {
  const _t_0 = _batch_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058checked$1261$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058stage$1261$(_ctx_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058stage$1261$(_ctx_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1261$(_key_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $ordinary$045bundle$058compose$1260$(_head_0, _tail_0) {
  const _heads_0 = _head_0["entries"];
  const _tails_0 = _tail_0["entries"];
  return {$: "ordinary-bundle.Plan", "entries": ($List$append$(_heads_0, _tails_0))};
}

function $ordinary$045bundle$058component$1260$(_identity_0) {
  return {$: "ordinary-bundle.Plan", "entries": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Entry", "kind": {$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Component"}, "key": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1263$(_identity_0)), "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1263$(_identity_0))}, "tail": {$: "Nil"}}};
}

function $bundle$058data_identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1262$("canonical-data");
}

function $ordinary$045bundle$058terminal$1260$() {
  return {$: "ordinary-bundle.Plan", "entries": {$: "Nil"}};
}

function $runtime$058restored_entries$(_world_0, _undo_0, _result_0) {
  if (_result_0.$ === "bundle.Ready") {
    const _cooked_0 = _result_0["cooked"];
    return $runtime$058remember$(_world_0, _undo_0(_cooked_0));
  } else {
    const _entries_0 = _result_0["entries"];
    return $runtime$058quarantine_entries$(_world_0, _entries_0, _undo_0, {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"});
  }
}

function $bundle$058cooked_of$(_entries_0) {
  const _t_0 = _entries_0["head"];
  const _h_0 = _t_0["handle"];
  const _t_1 = _t_0["owner"];
  if (_t_1.$ === "Some") {
    const _head_0 = _t_1["value"];
    const _t_2 = _entries_0["tail"];
    const _t_3 = _t_2["head"];
    const _t_4 = _t_3["handle"];
    const _t_5 = _t_3["owner"];
    if (_t_5.$ === "Some") {
      const _tail_0 = _t_5["value"];
      const _t_6 = _t_2["tail"];
      const _t_7 = _t_6["head"];
      const _g_0 = _t_7["handle"];
      const _t_8 = _t_7["owner"];
      if (_t_8.$ === "Some") {
        const _tag_0 = _t_8["value"];
        const _t_9 = _t_6["tail"];
        const _t_10 = _t_9["head"];
        const _d_0 = _t_10["handle"];
        const _t_11 = _t_10["owner"];
        if (_t_11.$ === "Some") {
          const _data_0 = _t_11["value"];
          const _t_12 = _t_9["tail"];
          return {$: "bundle.Ready", "cooked": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tail_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tag_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _data_0, "tail": {$: "Unit"}}}}}};
        } else {
          const _30_0 = _t_9["tail"];
          return {$: "bundle.Missing", "entries": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _h_0, "owner": {$: "Some", "value": _head_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _t_4, "owner": {$: "Some", "value": _tail_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _g_0, "owner": {$: "Some", "value": _tag_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _d_0, "owner": _t_11}, "tail": _30_0}}}}};
        }
      } else {
        const _27_0 = _t_6["tail"];
        return {$: "bundle.Missing", "entries": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _h_0, "owner": {$: "Some", "value": _head_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _t_4, "owner": {$: "Some", "value": _tail_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _g_0, "owner": _t_8}, "tail": _27_0}}}};
      }
    } else {
      const _24_0 = _t_2["tail"];
      return {$: "bundle.Missing", "entries": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _h_0, "owner": {$: "Some", "value": _head_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _t_4, "owner": _t_5}, "tail": _24_0}}};
    }
  } else {
    const _21_0 = _entries_0["tail"];
    return {$: "bundle.Missing", "entries": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _h_0, "owner": _t_1}, "tail": _21_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058committed$1260$(_observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Committed", "world": _world_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058stage$1260$(_prepared_0, _tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058staged$1260$(_prepared_0, ($List$reverse$(_commands_0)), 0, {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Nil"}, "events": _events_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058failed$1260$(_payloads_0, _error_0, _observed_0) {
  const _world_0 = _observed_0["world"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Failed", "world": _world_0, "payloads": _payloads_0, "error": _error_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1260$($0) {
  for (;;) {
    {
      const _prepared_0 = $0;
      if (_prepared_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          continue;
        } else {
          const _payload_0 = _t_0["payload"];
          const _tail_1 = _prepared_0["tail"];
          return {$: "Con", "head": _payload_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058originals$1260$(_tail_1))};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, _ctx_0) {
  return $bundle$058body$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_reserved$1261$(_prepared_0, _payload_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "../../../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_1["handle"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_positioned$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1261$({$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt", "target": _target_0}, "tail": _prepared_0}, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_commands_0)))));
  } else {
    const _error_0 = _t_1["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.SpawnRefused", "batch": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, _payload_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0)), _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058checked$1261$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_checked$1261$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1261$(_prepared_0, _target_0)));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058stage$1261$(_ctx_0, _raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_head$1261$(_tail_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058head$1260$(_ctx_0, _head_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1263$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1262$(_key_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $runtime$058remember$(_world_0, _raw_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _returned_0 = _t_0["returned"];
  const _saved_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _spare_0 = _t_0["spare"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "runtime.Mail", "returned": {$: "Con", "head": _raw_0, "tail": _returned_0}, "installed": _saved_0, "quarantine": _quarantine_0, "errors": _errors_0, "spare": _spare_0}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $runtime$058quarantine_entries$(_world_0, _entries_0, _undo_0, _error_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _returned_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _spare_0 = _t_0["spare"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "runtime.Mail", "returned": _returned_0, "installed": _installed_0, "quarantine": {$: "Con", "head": {$: "runtime.Entries", "entries": _entries_0, "undo": _undo_0, "error": _error_0}, "tail": _quarantine_0}, "errors": {$: "Con", "head": _error_0, "tail": _errors_0}, "spare": _spare_0}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058staged$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _prepared_0 = $0;
      const _commands_0 = $1;
      const _current_0 = $2;
      const _tx_0 = $3;
      if (_prepared_0.$ === "Nil") {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058remaining$1260$(_commands_0, _tx_0);
      } else {
        const _t_0 = _prepared_0["head"];
        if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt") {
          const _tail_0 = _prepared_0["tail"];
          $0 = _tail_0;
          $1 = _commands_0;
          $2 = _current_0;
          $3 = _tx_0;
          continue;
        } else {
          const _target_1 = _t_0["target"];
          const _payload_0 = _t_0["payload"];
          const _position_0 = _t_0["position"];
          const _tail_1 = _prepared_0["tail"];
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058staged_after$1260$(_target_1, _payload_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058staged$1260$(_tail_1, _x_0, _position_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058preceding$1260$((_position_0 < _current_0 ? 0 : _position_0 - _current_0), _commands_0, _tx_0)));
        }
      }
    }
  }
}

function $bundle$058body$1260$(_input_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1260$(_owner_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_positioned$1261$(_target_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Spawned", "batch": _batch_0, "target": _target_0};
  } else {
    const _batch_1 = _result_0["batch"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.SpawnRefused", "batch": _batch_1, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Inserted", "batch": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Prepared", "target": _target_0, "payload": _payload_0, "position": _position_0}, "tail": _prepared_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _tail_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_join$1260$(_reserved_0, _undo_0, _commands_0, _events_0, _payload_0) {
  const _world_0 = _reserved_0["fst"];
  const _reservation_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_checked$1261$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _result_0) {
  const _prepared_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Refused", "batch": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1261$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1261$(_prepared_0, _target_0) {
  if (_prepared_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": false};
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Prepared") {
      const _handle_0 = _t_0["target"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _tail_0 = _prepared_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1261$({$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Prepared", "target": _handle_0, "payload": _payload_0, "position": _position_0}, false, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1261$(_tail_0, _target_0)));
    } else {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _tail_1 = _prepared_0["tail"];
      const _otherNs_0 = _target_0["namespace"];
      const _otherId_0 = _target_0["id"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1261$({$: "../../../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt", "target": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}}, ($Bool$and$((_ns_0 === _otherNs_0), (_id_0 === _otherId_0))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1261$(_tail_1, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _otherNs_0, "id": _otherId_0})));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_head$1261$(_tail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Constructed") {
    const _head_0 = _t_0["cooked"];
    const _undo_0 = _t_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_tail$1262$(_head_0, _undo_0, ($$$$047$$$047complete$045families$045v1$047canonical$058stage$1260$(_ctx_0, _tail_0)));
  } else {
    const _head_1 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058invalid_tail$1261$(_head_1, _error_0, ($$$$047$$$047complete$045families$045v1$047canonical$058stage$1260$(_ctx_0, _tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058head$1260$(_ctx_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058projected$1260$(_input_0, ($$$$047$$$047complete$045families$045v1$047canonical$058take$1260$(_ctx_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058remaining$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _tx_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _tx_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _tail_0 = _commands_0["tail"];
        $0 = _tail_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058staged_after$1260$(_target_0, _payload_0, _next_0, _result_0) {
  const _after_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return run_tail(_next_0(_after_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045delivery$058enqueue$1260$(_before_0, _target_0, _payload_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058preceding$1260$($0, $1, $2) {
  for (;;) {
    {
      const _count_0 = $0;
      const _commands_0 = $1;
      const _tx_0 = $2;
      if (_count_0 === 0) {
        return {$: "Tuple", "fst": _commands_0, "snd": _tx_0};
      } else {
        const _rest_0 = (_count_0 - 1);
        if (_commands_0.$ === "Nil") {
          return {$: "Tuple", "fst": {$: "Nil"}, "snd": _tx_0};
        } else {
          const _command_0 = _commands_0["head"];
          const _tail_0 = _commands_0["tail"];
          $0 = _rest_0;
          $1 = _tail_0;
          $2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request$1260$(_ctx_0, _input_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1260$({$: "../../../../../../../../bendvy/src/ecs/capabilities.OwnedRequest", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $bundle$058request$1260$(_x_0, _x_1);
});
})}))(_ctx_0), _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058counted$1260$(_command_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": nat_chk(_count_0 + 1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_reserved$1260$(_reservation_0, _world_0, _undo_0, _commands_0, _events_0, _payload_0) {
  if (_reservation_0.$ === "../../../../../../../../bendvy/src/ecs/world.ReservationRejected") {
    const _error_0 = _reservation_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": _error_0}};
  } else {
    const _handle_0 = _reservation_0["handle"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1260$(_x_0, _handle_0, _payload_0);
}), "tail": _commands_0}, "events": _events_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Reserved", "handle": _handle_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.ReservationRejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1261$(_entry_0, _seen_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _found_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _tail_0}, "snd": (_seen_0 || _found_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_tail$1262$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid", "context": _ctx_0, "cooked": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058undo_pack$1262$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058stage$1260$(_context_0, _raw_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058canonical_stage$1260$(_context_0, _raw_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058invalid_tail$1261$(_head_0, _error_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed", "context": _ctx_0, "raw": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _undo_0(_cooked_0)}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _raw_0}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058projected$1260$(_input_0, _observed_0) {
  const _factory_0 = _observed_0["fst"];
  const _rest_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058restored$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058fallible_request$1260$(_factory_0, _input_0)));
}

function $$$$047$$$047complete$045families$045v1$047canonical$058take$1260$(_context_0) {
  const _factory_0 = _context_0["factory"];
  const _owned_0 = _context_0["rest"];
  const _trail_0 = _context_0["trail"];
  return {$: "Tuple", "fst": _factory_0, "snd": {$: "../../complete-families-v1/canonical.Rest", "owned": _owned_0, "trail": _trail_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045delivery$058enqueue$1260$(_tx_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045delivery$058apply$1260$(_x_0, _handle_0, _payload_0);
}));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047capabilities$058owned_request_field$1260$(_cap_0) {
  const _run_0 = _cap_0["run"];
  return _run_0;
}

function $bundle$058request$1260$(_owner_0, _input_0) {
  return $ordinary$045bundle$058request$1260$(($bundle$058plan$()), _owner_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawn_apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Reserved", "handle": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../../../../../bendvy/src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058undo_pack$1262$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058canonical_stage$1260$(_ctx_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058stage$1260$(_ctx_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058restored$1260$(_rest_0, _observed_0) {
  const _factory_0 = _observed_0["fst"];
  const _result_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047complete$045families$045v1$047canonical$058put$1260$(_factory_0, _rest_0)), "snd": _result_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058fallible_request$1260$(_factory_0, _input_0) {
  return {$: "Tuple", "fst": _factory_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058fallible_construct$1260$(_factory_0, _input_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045delivery$058apply$1260$(_world_0, _handle_0, _payload_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045delivery$058apply_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _payload_0);
}

function $ordinary$045bundle$058request$1260$(_plan_0, _owner_0, _input_0) {
  return $ordinary$045bundle$058checked$1260$({$: "../../../../../../../../bendvy/src/ecs/schema-fragments.Valid"}, _owner_0, _input_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058spawned$1260$(_activated_0, _handle_0, _payload_0) {
  const _world_0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/world.Accepted") {
    return _world_0;
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058stage$1260$(_ctx_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058stage$1260$(_ctx_0, _input_0);
}

function $$$$047$$$047complete$045families$045v1$047canonical$058put$1260$(_factory_0, _rest_0) {
  const _owned_0 = _rest_0["owned"];
  const _trail_0 = _rest_0["trail"];
  return {$: "../../complete-families-v1/canonical.Context", "factory": _factory_0, "rest": _owned_0, "trail": _trail_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058fallible_construct$1260$(_factory_0, _input_0) {
  const _inputCodec_0 = _factory_0["inputCodec"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058fallible_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$058decode_owner$1260$(_inputCodec_0, _input_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045delivery$058apply_checked$1260$(_observed_0, _handle_0, _payload_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $runtime$058recover$(_world_0, _payload_0, {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"});
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045delivery$058deliver$1260$(($runtime$058attempt$(_world_0, _handle_0, _payload_0)));
  }
}

function $ordinary$045bundle$058checked$1260$(_validation_0, _owner_0, _input_0) {
  if (_validation_0.$ === "../../../../../../../../bendvy/src/ecs/schema-fragments.Invalid") {
    const _error_0 = _validation_0["error"];
    const _raw_0 = _input_0["raw"];
    return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused", "raw": _raw_0, "error": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.DeclarationRefused", "error": _error_0}}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058request$1260$(_owner_0, _input_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058stage$1260$(_ctx_0, _raw_0) {
  const _head_0 = _raw_0["head"];
  const _tail_0 = _raw_0["tail"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_head$1260$(_tail_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045canonical$045construction$058head$1260$(_ctx_0, _head_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058fallible_checked$1260$(_receipt_0) {
  const _owner_0 = _receipt_0["owner"];
  const _t_0 = _receipt_0["checked"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Rejected") {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Invalid", "raw": _owner_0, "error": {$: "../../../../../../../../bendvy/src/ecs/decode-construction.Validation", "error": _error_0}};
  } else {
    const _canonical_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058custom_result$1260$(($$$$047$$$047complete$045families$045v1$047canonical$058decoded$(_owner_0, _canonical_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$058decode_owner$1260$(_codec_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$058decode_projected$1260$(_codec_0, ($$$$047$$$047complete$045families$045v1$047canonical$058incoming$(_owner_0)));
}

function $runtime$058recover$(_world_0, _packet_0, _error_0) {
  const _ns_0 = _world_0["namespace"];
  const _next_0 = _world_0["nextId"];
  const _high_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _cap_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _returned_0 = _t_0["returned"];
  const _installed_0 = _t_0["installed"];
  const _quarantine_0 = _t_0["quarantine"];
  const _errors_0 = _t_0["errors"];
  const _spare_0 = _t_0["spare"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _regs_0 = _world_0["registrations"];
  const _system_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "runtime.Mail", "returned": {$: "Con", "head": run_loop($bundle$058unpack$(_packet_0)), "tail": _returned_0}, "installed": _installed_0, "quarantine": _quarantine_0, "errors": {$: "Con", "head": _error_0, "tail": _errors_0}, "spare": _spare_0}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045delivery$058deliver$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-delivery.Delivered") {
    const _world_0 = _result_0["world"];
    return _world_0;
  } else {
    const _world_1 = _result_0["world"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $runtime$058recover$(_world_1, _payload_0, _error_0);
  }
}

function $runtime$058attempt$(_world_0, _target_0, _packet_0) {
  return $runtime$058attempted$(($bundle$058install_packet$1260$(_world_0, _target_0, _packet_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058request$1260$(_owner_0, _input_0) {
  const _batch_0 = _owner_0["batch"];
  const _context_0 = _owner_0["context"];
  const _operation_0 = _input_0["operation"];
  const _raw_0 = _input_0["raw"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058constructed$1260$(_batch_0, _operation_0, ($$$$047$$$047complete$045families$045v1$047canonical$058stage$1260$(_context_0, _raw_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Rejected", "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_head$1260$(_tail_0, _observed_0) {
  const _ctx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Constructed") {
    const _head_0 = _t_0["cooked"];
    const _undo_0 = _t_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_tail$1260$(_head_0, _undo_0, ($$$$047$$$047complete$045families$045v1$047canonical$058side$1260$(_ctx_0, _tail_0)));
  } else {
    const _head_1 = _t_0["raw"];
    const _error_0 = _t_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058invalid_tail$1260$(_head_1, _error_0, ($$$$047$$$047complete$045families$045v1$047canonical$058side$1260$(_ctx_0, _tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045construction$058custom_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Invalid") {
    const _owner_0 = _result_0["raw"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Invalid", "raw": _owner_0, "error": {$: "../../../../../../../../bendvy/src/ecs/decode-construction.Constructor", "error": _error_0}};
  } else {
    const _owner_1 = _result_0["cooked"];
    const _undo_0 = _result_0["undo"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Constructed", "cooked": _owner_1, "undo": _undo_0};
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058decoded$(_owner_0, _canonical_0) {
  const _owned_0 = _owner_0["owned"];
  const _wire_0 = _owner_0["wire"];
  const _fail_0 = _owner_0["fail"];
  if (_canonical_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Number") {
    const _number_0 = _canonical_0["value"];
    return $$$$047$$$047complete$045families$045v1$047canonical$058built$(($Bool$not$(_fail_0)), _wire_0, _fail_0, _owned_0, _number_0);
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Invalid", "raw": {$: "../../complete-families-v1/canonical.Incoming", "owned": _owned_0, "wire": _wire_0, "fail": _fail_0}, "error": {$: "../../complete-families-v1/canonical.Blocked"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$058decode_projected$1260$(_codec_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _raw_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$058decode_budget$1260$(_codec_0, _raw_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058budget$(_codec_0, _raw_0)), _owner_0);
}

function $$$$047$$$047complete$045families$045v1$047canonical$058incoming$(_owner_0) {
  const _owned_0 = _owner_0["owned"];
  const _wire_0 = _owner_0["wire"];
  const _fail_0 = _owner_0["fail"];
  return {$: "Tuple", "fst": {$: "../../complete-families-v1/canonical.Incoming", "owned": _owned_0, "wire": _wire_0, "fail": _fail_0}, "snd": _wire_0};
}

function $bundle$058unpack$(_packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return run_tail(_undo_0, _cooked_0);
}

function $runtime$058attempted$(_result_0) {
  const _result_1 = _result_0["fst"];
  const _undo_0 = _result_0["snd"];
  return $runtime$058installed$(_undo_0, _result_1);
}

function $bundle$058install_packet$1260$(_world_0, _target_0, _packet_0) {
  const _cooked_0 = _packet_0["cooked"];
  const _undo_0 = _packet_0["undo"];
  return {$: "Tuple", "fst": ($bundle$058install_entries$1260$(_world_0, ($bundle$058entries$(_target_0, _cooked_0)))), "snd": _undo_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058constructed$1260$(_batch_0, _operation_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed") {
    const _context_0 = _result_0["context"];
    const _raw_0 = _result_0["raw"];
    const _positions_0 = _result_0["positions"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused", "raw": _raw_0, "error": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.ConstructionRefused", "positions": _positions_0}}};
  } else {
    const _context_1 = _result_0["context"];
    const _cooked_0 = _result_0["cooked"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058enqueue$1260$(_batch_0, _context_1, _operation_0, ($bundle$058pack$(_cooked_0, _undo_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_tail$1260$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid", "context": _ctx_0, "cooked": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058undo_pack$1260$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058side$1260$(_context_0, _owner_0) {
  const _tailOwner_0 = _owner_0["head"];
  const _extras_0 = _owner_0["tail"];
  return $$$$047$$$047complete$045families$045v1$047canonical$058side_staged$1260$(_extras_0, ($$$$047$$$047complete$045families$045v1$047canonical$058tail$1260$(_context_0, _tailOwner_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058invalid_tail$1260$(_head_0, _error_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed", "context": _ctx_0, "raw": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _undo_0(_cooked_0)}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _raw_0}, "positions": {$: "Con", "head": {$: "Some", "value": _error_0}, "tail": _positions_1}};
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058built$(_allowed_0, _wire_0, _fail_0, _owned_0, _number_0) {
  if (_allowed_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Constructed", "cooked": {$: "../../complete-families-v1/canonical.Payload", "owned": _owned_0, "number": _number_0}, "undo": run_clo((_x_0) => {
  return $$$$047$$$047complete$045families$045v1$047canonical$058undo$(_wire_0, _fail_0, _x_0);
})};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Invalid", "raw": {$: "../../complete-families-v1/canonical.Incoming", "owned": _owned_0, "wire": _wire_0, "fail": _fail_0}, "error": {$: "../../complete-families-v1/canonical.Blocked"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$058decode_budget$1260$(_codec_0, _raw_0, _fuel_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalized$1260$(_fuel_0, _codec_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058owned$1260$(_fuel_0, _codec_0, {$: "../../../../../../../../bendvy/src/ecs/decode-data.Owned", "owner": _owner_0, "description": _raw_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058budget$(_codec_0, _raw_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058raw_size$(_raw_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058codec_size$(_codec_0));
  const _x_2 = nat_chk(_x_0 + 1);
  const _x_3 = nat_chk(_x_1 * _x_2);
  return nat_chk(4 * _x_3);
}

function $runtime$058installed$(_undo_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Installed") {
    const _t_0 = _result_0["world"];
    const _ns_0 = _t_0["namespace"];
    const _next_0 = _t_0["nextId"];
    const _high_0 = _t_0["highWater"];
    const _live_0 = _t_0["live"];
    const _cap_0 = _t_0["capacity"];
    const _depth_0 = _t_0["depth"];
    const _store_0 = _t_0["store"];
    const _t_1 = _t_0["resource"];
    const _returned_0 = _t_1["returned"];
    const _receipts_0 = _t_1["installed"];
    const _quarantine_0 = _t_1["quarantine"];
    const _errors_0 = _t_1["errors"];
    const _spare_0 = _t_1["spare"];
    const _events_0 = _t_0["events"];
    const _pending_0 = _t_0["pending"];
    const _regs_0 = _t_0["registrations"];
    const _system_0 = _t_0["nextSystemId"];
    const _clock_0 = _t_0["clock"];
    const _inverse_0 = _result_0["undo"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-delivery.Delivered", "world": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_0, "nextId": _next_0, "highWater": _high_0, "live": _live_0, "capacity": _cap_0, "depth": _depth_0, "store": _store_0, "resource": {$: "runtime.Mail", "returned": _returned_0, "installed": {$: "Con", "head": {$: "runtime.Saved", "inverse": _inverse_0, "undo": _undo_0}, "tail": _receipts_0}, "quarantine": _quarantine_0, "errors": _errors_0, "spare": _spare_0}, "events": _events_0, "pending": _pending_0, "registrations": _regs_0, "nextSystemId": _system_0, "clock": _clock_0}};
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _entries_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $runtime$058refused_entries$(_world_0, _undo_0, _error_0, ($bundle$058cooked_of$(_entries_0)));
  } else {
    const _t_2 = _result_0["world"];
    const _ns_1 = _t_2["namespace"];
    const _next_1 = _t_2["nextId"];
    const _high_1 = _t_2["highWater"];
    const _live_1 = _t_2["live"];
    const _cap_1 = _t_2["capacity"];
    const _depth_1 = _t_2["depth"];
    const _store_1 = _t_2["store"];
    const _t_3 = _t_2["resource"];
    const _returned_1 = _t_3["returned"];
    const _receipts_1 = _t_3["installed"];
    const _quarantine_1 = _t_3["quarantine"];
    const _errors_1 = _t_3["errors"];
    const _spare_1 = _t_3["spare"];
    const _events_1 = _t_2["events"];
    const _pending_1 = _t_2["pending"];
    const _regs_1 = _t_2["registrations"];
    const _system_1 = _t_2["nextSystemId"];
    const _clock_1 = _t_2["clock"];
    const _recovery_0 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-delivery.Delivered", "world": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _ns_1, "nextId": _next_1, "highWater": _high_1, "live": _live_1, "capacity": _cap_1, "depth": _depth_1, "store": _store_1, "resource": {$: "runtime.Mail", "returned": _returned_1, "installed": _receipts_1, "quarantine": {$: "Con", "head": {$: "runtime.Recovery", "recovery": _recovery_0, "undo": _undo_0, "error": _error_1}, "tail": _quarantine_1}, "errors": {$: "Con", "head": _error_1, "tail": _errors_1}, "spare": _spare_1}, "events": _events_1, "pending": _pending_1, "registrations": _regs_1, "nextSystemId": _system_1, "clock": _clock_1}};
  }
}

function $bundle$058install_entries$1260$(_world_0, _entries_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058install$1260$(_world_0, _entries_0);
}

function $bundle$058entries$(_target_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _t_0 = _cooked_0["tail"];
  const _tail_0 = _t_0["head"];
  const _t_1 = _t_0["tail"];
  const _tag_0 = _t_1["head"];
  const _t_2 = _t_1["tail"];
  const _data_0 = _t_2["head"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _head_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _tail_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _tag_0}}, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _target_0, "owner": {$: "Some", "value": _data_0}}, "tail": {$: "Unit"}}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058enqueue$1260$(_batch_0, _context_0, _operation_0, _packet_0) {
  if (_operation_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-requests.Spawn") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058spawned$1260$(_context_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn$1260$(_batch_0, _packet_0)));
  } else {
    const _target_0 = _operation_0["target"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058inserted$1260$(_context_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058insert$1260$(_batch_0, _target_0, _packet_0)));
  }
}

function $bundle$058pack$(_cooked_0, _undo_0) {
  return {$: "bundle.Packet", "cooked": _cooked_0, "undo": _undo_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058undo_pack$1260$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058side_staged$1260$(_extras_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid") {
    const _context_0 = _result_0["context"];
    const _owner_0 = _result_0["cooked"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_tail$1261$(_owner_0, _undo_0, ($$$$047$$$047complete$045families$045v1$047canonical$058extra$1260$(_context_0, _extras_0)));
  } else {
    const _context_1 = _result_0["context"];
    const _owner_1 = _result_0["raw"];
    const _positions_1 = _result_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed", "context": _context_1, "raw": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _owner_1, "tail": _extras_0}, "positions": ($List$append$(_positions_1, {$: "Con", "head": {$: "None"}, "tail": {$: "Con", "head": {$: "None"}, "tail": {$: "Nil"}}}))};
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058tail$1260$(_context_0, _owner_0) {
  const _factory_0 = _context_0["factory"];
  const _rest_0 = _context_0["rest"];
  const _trail_0 = _context_0["trail"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid", "context": {$: "../../complete-families-v1/canonical.Context", "factory": _factory_0, "rest": _rest_0, "trail": ($List$append$(_trail_0, {$: "Con", "head": "tail", "tail": {$: "Nil"}}))}, "cooked": _owner_0, "undo": run_clo((_x_0) => {
  return _x_0;
}), "positions": {$: "Con", "head": {$: "None"}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047complete$045families$045v1$047canonical$058undo$(_wire_0, _fail_0, _owner_0) {
  const _owned_0 = _owner_0["owned"];
  return {$: "../../complete-families-v1/canonical.Incoming", "owned": _owned_0, "wire": _wire_0, "fail": _fail_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalized$1260$(_fuel_0, _codec_0, _result_0) {
  const _owner_0 = _result_0["owner"];
  const _t_0 = _result_0["checked"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Accepted") {
    const _value_0 = _t_0["value"];
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Receipt", "owner": _owner_0, "checked": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Accepted", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical$(_fuel_0, _codec_0, _value_0))}};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Receipt", "owner": _owner_0, "checked": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Rejected", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058owned$1260$(_fuel_0, _codec_0, _input_0) {
  const _owner_0 = _input_0["owner"];
  const _description_0 = _input_0["description"];
  return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Receipt", "owner": _owner_0, "checked": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058validate$(_fuel_0, {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Work", "codec": _codec_0, "raw": _description_0, "path": "$"}, "tail": {$: "Nil"}}}, _description_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058codec_size$(_codec_0) {
  if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Nullable") {
    const _inner_0 = _codec_0["inner"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058codec_size$(_inner_0));
    return nat_chk(1 + _x_0);
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.ArrayValue") {
    const _inner_1 = _codec_0["inner"];
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058codec_size$(_inner_1));
    return nat_chk(1 + _x_1);
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Struct") {
    const _t_0 = _codec_0["fields"];
    if (_t_0.$ === "Nil") {
      return 1;
    } else {
      const _t_1 = _t_0["head"];
      const _child_0 = _t_1["codec"];
      const _rest_0 = _t_0["tail"];
      const _x_2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058codec_size$(_child_0));
      const _x_3 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058codec_size$({$: "../../../../../../../../bendvy/src/ecs/decode-data.Struct", "fields": _rest_0}));
      const _x_4 = nat_chk(_x_2 + _x_3);
      return nat_chk(1 + _x_4);
    }
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058raw_size$(_raw_0) {
  if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Array") {
    const _t_0 = _raw_0["items"];
    if (_t_0.$ === "Nil") {
      return 1;
    } else {
      const _head_0 = _t_0["head"];
      const _rest_0 = _t_0["tail"];
      const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058raw_size$(_head_0));
      const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058raw_size$({$: "../../../../../../../../bendvy/src/ecs/decode-data.Array", "items": _rest_0}));
      return nat_chk(_x_0 + _x_1);
    }
  } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Object") {
    const _t_1 = _raw_0["fields"];
    if (_t_1.$ === "Nil") {
      return 1;
    } else {
      const _t_2 = _t_1["head"];
      const _child_0 = _t_2["value"];
      const _rest_1 = _t_1["tail"];
      const _x_2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058raw_size$(_child_0));
      const _x_3 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045size$058raw_size$({$: "../../../../../../../../bendvy/src/ecs/decode-data.Object", "fields": _rest_1}));
      return nat_chk(_x_2 + _x_3);
    }
  } else {
    return 1;
  }
}

function $runtime$058refused_entries$(_world_0, _undo_0, _error_0, _result_0) {
  if (_result_0.$ === "bundle.Ready") {
    const _cooked_0 = _result_0["cooked"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-delivery.Undelivered", "world": _world_0, "payload": {$: "bundle.Packet", "cooked": _cooked_0, "undo": _undo_0}, "error": _error_0};
  } else {
    const _entries_0 = _result_0["entries"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-delivery.Delivered", "world": ($runtime$058quarantine_entries$(_world_0, _entries_0, _undo_0, _error_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058install$1260$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_head$1260$(($bundle$058install_head$1260$(_world_0, _head_0)), _tail_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058spawned$1260$(_context_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Spawned") {
    const _batch_0 = _result_0["batch"];
    const _target_0 = _result_0["target"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Accepted", "target": _target_0, "spawned": true}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _packet_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_1, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused", "raw": run_loop($bundle$058unpack$(_packet_0)), "error": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.EntityRefused", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn$1260$(_batch_0, _payload_0) {
  const _tx_0 = _batch_0["tx"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_reserved$1260$(_prepared_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047commands$058tx_spawn$1260$(_tx_0, {$: "Unit"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045requests$058inserted$1260$(_context_0, _target_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_0, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Accepted", "target": _target_0, "spawned": false}};
  } else {
    const _batch_1 = _result_0["batch"];
    const _packet_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.Owner", "batch": _batch_1, "context": _context_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/bundle-requests.Refused", "raw": run_loop($bundle$058unpack$(_packet_0)), "error": {$: "../../../../../../../../bendvy/src/ecs/bundle-insert-adapter.EntityRefused", "error": _error_0}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058insert$1260$(_batch_0, _target_0, _payload_0) {
  const _t_0 = _batch_0["tx"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _prepared_0 = _batch_0["prepared"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058checked$1260$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058constructed_tail$1261$(_head_0, _headUndo_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid") {
    const _ctx_0 = _tail_0["context"];
    const _cooked_0 = _tail_0["cooked"];
    const _undo_0 = _tail_0["undo"];
    const _positions_0 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid", "context": _ctx_0, "cooked": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _cooked_0}, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058undo_pack$1261$(_headUndo_0, _undo_0, _x_0);
}), "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_0}};
  } else {
    const _ctx_1 = _tail_0["context"];
    const _raw_0 = _tail_0["raw"];
    const _positions_1 = _tail_0["positions"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Failed", "context": _ctx_1, "raw": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _raw_0}, "positions": {$: "Con", "head": {$: "None"}, "tail": _positions_1}};
  }
}

function $$$$047$$$047complete$045families$045v1$047canonical$058extra$1260$(_context_0, _owner_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-construction.Valid", "context": _context_0, "cooked": _owner_0, "undo": run_clo((_x_0) => {
  return _x_0;
}), "positions": {$: "Con", "head": {$: "None"}, "tail": {$: "Con", "head": {$: "None"}, "tail": {$: "Nil"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical$($0, $1, $2) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _codec_0 = $1;
      const _raw_0 = $2;
      if (_fuel_0 === 0) {
        return _raw_0;
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Nullable") {
          const _inner_0 = _codec_0["inner"];
          if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Null") {
            return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Null"};
          } else {
            $0 = _more_0;
            $1 = _inner_0;
            $2 = _raw_0;
            continue;
          }
        } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.ArrayValue") {
          const __0 = _codec_0["inner"];
          if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Array") {
            const _t_0 = _raw_0["items"];
            if (_t_0.$ === "Nil") {
              return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Array", "items": {$: "Nil"}};
            } else {
              const _head_0 = _t_0["head"];
              const _tail_0 = _t_0["tail"];
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical_array_join$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical$(_more_0, __0, _head_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical$(_more_0, {$: "../../../../../../../../bendvy/src/ecs/decode-data.ArrayValue", "inner": __0}, {$: "../../../../../../../../bendvy/src/ecs/decode-data.Array", "items": _tail_0})));
            }
          } else {
            return _raw_0;
          }
        } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Struct") {
          const _t_1 = _codec_0["fields"];
          if (_t_1.$ === "Nil") {
            if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Object") {
              return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Object", "fields": {$: "Nil"}};
            } else {
              return _raw_0;
            }
          } else {
            const _t_2 = _t_1["head"];
            const _name_0 = _t_2["name"];
            const _codec_1 = _t_2["codec"];
            const _rest_0 = _t_1["tail"];
            if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Object") {
              const _values_0 = _raw_0["fields"];
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical_struct_join$(_name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical$(_more_0, _codec_1, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058field$(_name_0, _values_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical$(_more_0, {$: "../../../../../../../../bendvy/src/ecs/decode-data.Struct", "fields": _rest_0}, {$: "../../../../../../../../bendvy/src/ecs/decode-data.Object", "fields": _values_0})));
            } else {
              return _raw_0;
            }
          }
        } else {
          return _raw_0;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058validate$($0, $1, $2) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _step_0 = $1;
      const _original_0 = $2;
      if (_fuel_0 === 0) {
        if (_step_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Stop") {
          const _error_0 = _step_0["error"];
          return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Rejected", "error": _error_0};
        } else {
          const _t_0 = _step_0["work"];
          if (_t_0.$ === "Nil") {
            return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Accepted", "value": _original_0};
          } else {
            const _t_1 = _t_0["head"];
            const _path_0 = _t_1["path"];
            return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Rejected", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.FuelExhausted", "path": _path_0}};
          }
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_step_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Stop") {
          const _error_1 = _step_0["error"];
          return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Rejected", "error": _error_1};
        } else {
          const _t_2 = _step_0["work"];
          if (_t_2.$ === "Nil") {
            return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Accepted", "value": _original_0};
          } else {
            const _t_3 = _t_2["head"];
            const _codec_0 = _t_3["codec"];
            const _raw_0 = _t_3["raw"];
            const _path_1 = _t_3["path"];
            const _rest_0 = _t_2["tail"];
            $0 = _more_0;
            $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058expand$(_codec_0, _raw_0, _path_1, _rest_0));
            $2 = _original_0;
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_head$1260$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_tail$1260$(_undo_0, ($bundle$058install_tail_entries$1260$(_world_2, _tail_0)));
  }
}

function $bundle$058install_head$1260$(_world_0, _entry_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1263$(($bundle$058family_head$()), _world_0, _entry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_reserved$1260$(_prepared_0, _payload_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _world_0 = _t_0["world"];
  const _undo_0 = _t_0["undo"];
  const _commands_0 = _t_0["commands"];
  const _events_0 = _t_0["events"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "../../../../../../../../bendvy/src/ecs/world.Reserved") {
    const _target_0 = _t_1["handle"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_positioned$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1260$({$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt", "target": _target_0}, "tail": _prepared_0}, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_commands_0)))));
  } else {
    const _error_0 = _t_1["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.SpawnRefused", "batch": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058checked$1260$(_prepared_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_checked$1260$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_prepared_0, _target_0)));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045construction$058undo_pack$1261$(_headUndo_0, _tailUndo_0, _cooked_0) {
  const _head_0 = _cooked_0["head"];
  const _tail_0 = _cooked_0["tail"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _headUndo_0(_head_0), "tail": _tailUndo_0(_tail_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical_array_join$(_head_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Array") {
    const _values_0 = _tail_0["items"];
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Array", "items": {$: "Con", "head": _head_0, "tail": _values_0}};
  } else {
    return _tail_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058canonical_struct_join$(_name_0, _head_0, _tail_0) {
  if (_tail_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Object") {
    const _fields_0 = _tail_0["fields"];
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Object", "fields": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Field", "name": _name_0, "value": _head_0}, "tail": _fields_0}};
  } else {
    return _tail_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058field$(_name_0, _fields_0) {
  if (_fields_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Missing"};
  } else {
    const _t_0 = _fields_0["head"];
    const _key_0 = _t_0["name"];
    const _value_0 = _t_0["value"];
    const _rest_0 = _fields_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058field_choose$(($String$eq$(_name_0, _key_0)), _value_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058field$(_name_0, _rest_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058expand$(_codec_0, _raw_0, _path_0, _rest_0) {
  if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Integer") {
    if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Number") {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.SignedInteger") {
      const __1 = _raw_0["negative"];
      const _magnitude_0 = _raw_0["magnitude"];
      const _x_0 = ($Nat$div$(_magnitude_0, nat_chk(65536 * 65536)));
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$((_x_0 < 2097152), _path_0, "integer", {$: "../../../../../../../../bendvy/src/ecs/decode-data.SignedInteger", "negative": __1, "magnitude": _magnitude_0}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Float") {
      const _value_0 = _raw_0["value"];
      const _x_1 = Math.fround(Math.floor(_value_0));
      const _x_2 = Math.fround(Math.abs(_value_0));
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$(($Bool$and$((_x_1 === _value_0), (_x_2 < 9007199254740992))), _path_0, "integer", {$: "../../../../../../../../bendvy/src/ecs/decode-data.Float", "value": _value_0}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Binary64") {
      const _high_0 = _raw_0["high"];
      const _low_0 = _raw_0["low"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_integer$(_high_0, _low_0)), _path_0, "integer", {$: "../../../../../../../../bendvy/src/ecs/decode-data.Binary64", "high": _high_0, "low": _low_0}, _rest_0);
    } else {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "integer", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.FiniteNumber") {
    if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Number") {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.SignedInteger") {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Float") {
      const _value_1 = _raw_0["value"];
      const _x_3 = Math.fround(Math.abs(_value_1));
      const _x_4 = 3.4028234663852886e+38;
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$((_x_3 <= _x_4), _path_0, "finite number", {$: "../../../../../../../../bendvy/src/ecs/decode-data.Float", "value": _value_1}, _rest_0);
    } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Binary64") {
      const _high_1 = _raw_0["high"];
      const __5 = _raw_0["low"];
      const _x_5 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary64_exponent$(_high_1));
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$((_x_5 < 2047), _path_0, "finite number", {$: "../../../../../../../../bendvy/src/ecs/decode-data.Binary64", "high": _high_1, "low": __5}, _rest_0);
    } else {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "finite number", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.StringValue") {
    if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Text") {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": _rest_0};
    } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Utf16Text") {
      const _units_0 = _raw_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058valid$(_units_0)), _path_0, "string", {$: "../../../../../../../../bendvy/src/ecs/decode-data.Utf16Text", "units": _units_0}, _rest_0);
    } else {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "string", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.BoolValue") {
    if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Boolean") {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": _rest_0};
    } else {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "boolean", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Literal") {
    const _value_2 = _codec_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058equal$(_value_2, _raw_0)), _path_0, "literal", _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.LiteralValues") {
    const _values_0 = _codec_0["values"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058alternatives$(_values_0, _raw_0)), _path_0, "literal", _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.LiteralRendered") {
    const _values_1 = _codec_0["values"];
    const _expected_0 = _codec_0["expected"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058alternatives$(_values_1, _raw_0)), _path_0, _expected_0, _raw_0, _rest_0);
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Nullable") {
    const __8 = _codec_0["inner"];
    if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Null") {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": _rest_0};
    } else {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Work", "codec": __8, "raw": _raw_0, "path": _path_0}, "tail": _rest_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.ArrayValue") {
    const _inner_0 = _codec_0["inner"];
    if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Array") {
      const _items_0 = _raw_0["items"];
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058array_work$(_inner_0, _items_0, _path_0, 0, _rest_0))};
    } else {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "array", "actual": _raw_0}};
    }
  } else if (_codec_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Struct") {
    const _fields_0 = _codec_0["fields"];
    if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Object") {
      const _values_2 = _raw_0["fields"];
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058struct_work$(_fields_0, _values_2, _path_0, _rest_0))};
    } else {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "object", "actual": _raw_0}};
    }
  } else {
    const _ns_0 = _codec_0["namespace"];
    if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Handle") {
      const _actual_0 = _raw_0["namespace"];
      const _id_0 = _raw_0["id"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$(($Bool$and$((_ns_0 === _actual_0), (_id_0 > 0))), _path_0, "same-world handle", {$: "../../../../../../../../bendvy/src/ecs/decode-data.Handle", "namespace": _actual_0, "id": _id_0}, _rest_0);
    } else {
      return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Invalid", "path": _path_0, "expected": "same-world handle", "actual": _raw_0}};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_tail$1260$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058refused_head$1260$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_tail$1260$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $bundle$058install_tail_entries$1260$(_world_0, _entries_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058install$1261$(_world_0, _entries_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1263$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1263$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1263$(_family_0, _world_0, _handle_0)));
}

function $bundle$058family_head$() {
  return {$: "../../../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047complete$045families$045v1$047canonical$058identity$1260$())))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058spawn_positioned$1260$(_target_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Inserted") {
    const _batch_0 = _result_0["batch"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Spawned", "batch": _batch_0, "target": _target_0};
  } else {
    const _batch_1 = _result_0["batch"];
    const _payload_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.SpawnRefused", "batch": _batch_1, "payload": _payload_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, _result_0) {
  const _commands_0 = _result_0["fst"];
  const _position_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Inserted", "batch": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Prepared", "target": _target_0, "payload": _payload_0, "position": _position_0}, "tail": _prepared_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_checked$1260$(_world_0, _undo_0, _commands_0, _events_0, _target_0, _payload_0, _result_0) {
  const _prepared_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Refused", "batch": {$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Batch", "tx": {$: "../../../../../../../../bendvy/src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "prepared": _prepared_0}, "payload": _payload_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058positioned$1260$(_prepared_0, _world_0, _undo_0, _events_0, _target_0, _payload_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058count_commands$1260$(_commands_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_prepared_0, _target_0) {
  if (_prepared_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": false};
  } else {
    const _t_0 = _prepared_0["head"];
    if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-batch.Prepared") {
      const _handle_0 = _t_0["target"];
      const _payload_0 = _t_0["payload"];
      const _position_0 = _t_0["position"];
      const _tail_0 = _prepared_0["tail"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1260$({$: "../../../../../../../../bendvy/src/ecs/bundle-batch.Prepared", "target": _handle_0, "payload": _payload_0, "position": _position_0}, false, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_tail_0, _target_0)));
    } else {
      const _t_1 = _t_0["target"];
      const _ns_0 = _t_1["namespace"];
      const _id_0 = _t_1["id"];
      const _tail_1 = _prepared_0["tail"];
      const _otherNs_0 = _target_0["namespace"];
      const _otherId_0 = _target_0["id"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1260$({$: "../../../../../../../../bendvy/src/ecs/bundle-batch.ReservationReceipt", "target": {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}}, ($Bool$and$((_ns_0 === _otherNs_0), (_id_0 === _otherId_0))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_find$1260$(_tail_1, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _otherNs_0, "id": _otherId_0})));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058field_choose$(_equal_0, _value_0, _next_0) {
  if (_equal_0) {
    return _value_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058choose_checked$(_valid_0, _path_0, _expected_0, _raw_0, _rest_0) {
  if (_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Continue", "work": _rest_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Stop", "error": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Invalid", "path": _path_0, "expected": _expected_0, "actual": _raw_0}};
  }
}

function $Nat$div$(_a_0, _b_0) {
  return $Pair$fst$(nat_divmod(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_integer$(_high_0, _low_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary64_exponent$(_high_0));
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_integer_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_numeric$(_high_0, _low_0)), (_x_0 < 1076));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary64_exponent$(_high_0) {
  const _x_0 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  return (2048 === 0 ? _x_0 : _x_0 % 2048);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058valid$(_units_0) {
  if (_units_0.$ === "Nil") {
    return true;
  } else {
    const _unit_0 = _units_0["head"];
    const _tail_0 = _units_0["tail"];
    return $Bool$and$((_unit_0 <= 65535), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058valid$(_tail_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058equal$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Null") {
    if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Null") {
      return true;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$({$: "../../../../../../../../bendvy/src/ecs/decode-data.Null"})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Text") {
    const _a_1 = _a_0["value"];
    if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Text") {
      const _b_1 = _b_0["value"];
      return $String$eq$(_a_1, _b_1);
    } else if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Utf16Text") {
      const _b_2 = _b_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058text$(_a_1)), _b_2);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$({$: "../../../../../../../../bendvy/src/ecs/decode-data.Text", "value": _a_1})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Utf16Text") {
    const _a_2 = _a_0["units"];
    if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Utf16Text") {
      const _b_3 = _b_0["units"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058checked$(_a_2, _b_3);
    } else if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Text") {
      const _b_4 = _b_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058checked$(_a_2, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058text$(_b_4)));
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$({$: "../../../../../../../../bendvy/src/ecs/decode-data.Utf16Text", "units": _a_2})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$(_b_0)));
    }
  } else if (_a_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Boolean") {
    const _a_3 = _a_0["value"];
    if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Boolean") {
      const _b_5 = _b_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_bool$(_a_3, _b_5);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$({$: "../../../../../../../../bendvy/src/ecs/decode-data.Boolean", "value": _a_3})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$(_b_0)));
    }
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_numeric$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$(_a_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$(_b_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058alternatives$(_values_0, _raw_0) {
  if (_values_0.$ === "Nil") {
    return false;
  } else {
    const _value_0 = _values_0["head"];
    const _tail_0 = _values_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058equal$(_value_0, _raw_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058alternatives$(_tail_0, _raw_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058array_work$(_codec_0, _items_0, _path_0, _index_0, _rest_0) {
  if (_items_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _value_0 = _items_0["head"];
    const _tail_0 = _items_0["tail"];
    const _x_0 = ($U32$show$(_index_0));
    const _x_1 = (_x_0 + "]");
    const _x_2 = ("[" + _x_1);
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Work", "codec": _codec_0, "raw": _value_0, "path": (_path_0 + _x_2)}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058array_work$(_codec_0, _tail_0, _path_0, ((_index_0 + 1) >>> 0), _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058struct_work$(_fields_0, _values_0, _path_0, _rest_0) {
  if (_fields_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _t_0 = _fields_0["head"];
    const _name_0 = _t_0["name"];
    const _codec_0 = _t_0["codec"];
    const _tail_0 = _fields_0["tail"];
    const _x_0 = ("." + _name_0);
    return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/decode-data.Work", "codec": _codec_0, "raw": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058field$(_name_0, _values_0)), "path": (_path_0 + _x_0)}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058struct_work$(_tail_0, _values_0, _path_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058refused_head$1260$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_tail$1260$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_head$1260$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058install$1261$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_head$1261$(($bundle$058install_tail$1260$(_world_0, _head_0)), _tail_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1263$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1263$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1263$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1263$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045batch$058receipt_join$1260$(_entry_0, _seen_0, _result_0) {
  const _tail_0 = _result_0["fst"];
  const _found_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _entry_0, "tail": _tail_0}, "snd": (_seen_0 || _found_0)};
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $Pair$fst$(_p_0) {
  const _a_0 = _p_0["fst"];
  return _a_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_integer_checked$(_result_0, _small_0) {
  return $Bool$and$(_small_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_integer_normal$(_result_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_numeric$(_high_0, _low_0) {
  const _x_0 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_1 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_2 = (2048 === 0 ? _x_1 : _x_1 % 2048);
  const _x_3 = (1048576 === 0 ? 0 : (_high_0 / 1048576) >>> 0);
  const _x_4 = (2048 === 0 ? _x_3 : _x_3 % 2048);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_parts$((_high_0 >= 2147483648), (2048 === 0 ? _x_0 : _x_0 % 2048), (1048576 === 0 ? _high_0 : _high_0 % 1048576), _low_0, (_x_2 === 2047), (_x_4 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_numeric$(_a_0, _b_0) {
  if (_a_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Finite") {
    const _an_0 = _a_0["negative"];
    const _ah_0 = _a_0["high"];
    const _al_0 = _a_0["low"];
    const _ae_0 = _a_0["exponent"];
    if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Finite") {
      const _bn_0 = _b_0["negative"];
      const _bh_0 = _b_0["high"];
      const _bl_0 = _b_0["low"];
      const _be_0 = _b_0["exponent"];
      return $Bool$and$(($Bool$and$(($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_bool$(_an_0, _bn_0)), (_ah_0 === _bh_0))), (_al_0 === _bl_0))), (_ae_0 === _be_0));
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Infinity") {
    const _a_1 = _a_0["negative"];
    if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Infinity") {
      const _b_1 = _b_0["negative"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_bool$(_a_1, _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.NaN") {
    if (_b_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.NaN") {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric$(_raw_0) {
  if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Number") {
    const _value_0 = _raw_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize$(64, false, 0, _value_0, 1074);
  } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.SignedInteger") {
    const _negative_0 = _raw_0["negative"];
    const _value_1 = _raw_0["magnitude"];
    const _x_0 = ($Nat$div$(_value_1, nat_chk(65536 * 65536)));
    const _x_1 = ($Nat$mod$(_value_1, nat_chk(65536 * 65536)));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize$(64, _negative_0, (_x_0 >>> 0), (_x_1 >>> 0), 1074);
  } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Float") {
    const _value_2 = _raw_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058float_numeric$(f32_bits(_value_2));
  } else if (_raw_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Binary64") {
    const _high_0 = _raw_0["high"];
    const _low_0 = _raw_0["low"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_numeric$(_high_0, _low_0);
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.NotNumber"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058checked$(_left_0, _right_0) {
  return $Bool$and$(($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058valid$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058valid$(_right_0)))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058equal$(_left_0, _right_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058text$(_value_0) {
  if (_value_0 === "") {
    return {$: "Nil"};
  } else {
    const _t_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(0, 2) : _value_0[0]);
    const _tail_0 = (_value_0.codePointAt(0) > 0xFFFF ? _value_0.slice(2) : _value_0.slice(1));
    const _x_0 = _t_0.codePointAt(0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058scalar$(_t_0.codePointAt(0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058text$(_tail_0)), (_x_0 < 65536));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058same_bool$(_a_0, _b_0) {
  if (_a_0) {
    if (_b_0) {
      return true;
    } else {
      return false;
    }
  } else {
    if (!_b_0) {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_head$1260$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_head$1261$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_tail$1261$(_undo_0, ($bundle$058install_tag_entries$1260$(_world_2, _tail_0)));
  }
}

function $bundle$058install_tail$1260$(_world_0, _entry_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1262$(($bundle$058family_tail$()), _world_0, _entry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1263$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1263$({$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1263$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1263$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1263$(_id_0, _world_0);
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_integer_normal$(_result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/decode-data.Finite") {
    const _high_0 = _result_0["high"];
    const _low_0 = _result_0["low"];
    const _exponent_0 = _result_0["exponent"];
    const _x_0 = ($Bool$and$((_high_0 === 0), (_low_0 === 0)));
    const _x_1 = ($Bool$and$((_exponent_0 >= 1074), (_exponent_0 <= 1126)));
    return (_x_0 || _x_1);
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058binary_parts$(_negative_0, _exponent_0, _high_0, _low_0, _special_0, _zero_0) {
  if (_special_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric_special$(_negative_0, ($Bool$and$((_high_0 === 0), (_low_0 === 0))));
  } else {
    if (_zero_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize$(64, _negative_0, _high_0, _low_0, 0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize$(64, _negative_0, ((_high_0 + 1048576) >>> 0), _low_0, ((_exponent_0 - 1) >>> 0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize$(_fuel_0, _negative_0, _high_0, _low_0, _exponent_0) {
  const _x_0 = (2 === 0 ? _low_0 : _low_0 % 2);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize_checked$(_fuel_0, _negative_0, _high_0, _low_0, _exponent_0, ($Bool$and$((_high_0 === 0), (_low_0 === 0))), (_x_0 === 0));
}

function $Nat$mod$(_a_0, _b_0) {
  return $Pair$snd$(nat_divmod(_a_0, _b_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058float_numeric$(_bits_0) {
  const _x_0 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_1 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_2 = (256 === 0 ? _x_1 : _x_1 % 256);
  const _x_3 = (8388608 === 0 ? 0 : (_bits_0 / 8388608) >>> 0);
  const _x_4 = (256 === 0 ? _x_3 : _x_3 % 256);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058float_parts$(_bits_0, (256 === 0 ? _x_0 : _x_0 % 256), (8388608 === 0 ? _bits_0 : _bits_0 % 8388608), (_x_2 === 255), (_x_4 === 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058equal$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058empty$(_right_0);
  } else {
    const _head_0 = _left_0["head"];
    const _tail_0 = _left_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058compared$(_head_0, _right_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058equal$(_tail_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058scalar$(_code_0, _rest_0, _bmp_0) {
  if (_bmp_0) {
    return {$: "Con", "head": _code_0, "tail": _rest_0};
  } else {
    const _x_0 = ((_code_0 - 65536) >>> 0);
    const _x_1 = (1024 === 0 ? 0 : (_x_0 / 1024) >>> 0);
    const _x_2 = ((_code_0 - 65536) >>> 0);
    const _x_3 = (1024 === 0 ? _x_2 : _x_2 % 1024);
    return {$: "Con", "head": ((55296 + _x_1) >>> 0), "tail": {$: "Con", "head": ((56320 + _x_3) >>> 0), "tail": _rest_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_tail$1261$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058refused_head$1261$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_tail$1261$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $bundle$058install_tag_entries$1260$(_world_0, _entries_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058install$1262$(_world_0, _entries_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1262$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1262$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1262$(_family_0, _world_0, _handle_0)));
}

function $bundle$058family_tail$() {
  return {$: "../../../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1261$(($bundle$058tail_identity$())))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1263$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1263$({$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1263$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1263$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1263$(_id_0, ($bundle$058take_head$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric_special$(_negative_0, _infinite_0) {
  if (_infinite_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Infinity", "negative": _negative_0};
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/decode-data.NaN"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize_checked$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _negative_0 = $1;
      const _high_0 = $2;
      const _low_0 = $3;
      const _exponent_0 = $4;
      const _zero_0 = $5;
      const _even_0 = $6;
      if (_fuel_0 === 0) {
        if (_zero_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Finite", "negative": false, "high": 0, "low": 0, "exponent": 0};
        } else {
          if (!_even_0) {
            return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          } else {
            return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          }
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_zero_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Finite", "negative": false, "high": 0, "low": 0, "exponent": 0};
        } else {
          if (!_even_0) {
            return {$: "../../../../../../../../bendvy/src/ecs/decode-data.Finite", "negative": _negative_0, "high": _high_0, "low": _low_0, "exponent": _exponent_0};
          } else {
            const _x_0 = (2 === 0 ? _high_0 : _high_0 % 2);
            const _x_1 = (2 === 0 ? 0 : (_low_0 / 2) >>> 0);
            const _x_2 = (Math.imul(_x_0, 2147483648) >>> 0);
            const _x_3 = (2 === 0 ? 0 : (_low_0 / 2) >>> 0);
            const _x_4 = (2 === 0 ? _x_3 : _x_3 % 2);
            $0 = _more_0;
            $1 = _negative_0;
            $2 = (2 === 0 ? 0 : (_high_0 / 2) >>> 0);
            $3 = ((_x_1 + _x_2) >>> 0);
            $4 = ((_exponent_0 + 1) >>> 0);
            $5 = false;
            $6 = (_x_4 === 0);
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058float_parts$(_bits_0, _exponent_0, _fraction_0, _special_0, _zero_0) {
  if (_special_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058numeric_special$((_bits_0 >= 2147483648), (_fraction_0 === 0));
  } else {
    if (_zero_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize$(64, (_bits_0 >= 2147483648), 0, _fraction_0, 925);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045data$058normalize$(64, (_bits_0 >= 2147483648), 0, ((_fraction_0 + 8388608) >>> 0), ((_exponent_0 + 924) >>> 0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058empty$(_units_0) {
  if (_units_0.$ === "Nil") {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047decode$045utf16$058compared$(_head_0, _other_0, _next_0) {
  if (_other_0.$ === "Nil") {
    return false;
  } else {
    const _value_0 = _other_0["head"];
    const _tail_0 = _other_0["tail"];
    return $Bool$and$((_head_0 === _value_0), _next_0(_tail_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058refused_head$1261$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_tail$1261$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_head$1261$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058install$1262$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_head$1262$(($bundle$058install_tag$1260$(_world_0, _head_0)), _tail_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1262$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1262$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1262$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1263$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1263$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1263$(_previous_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1263$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1263$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1263$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1263$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1263$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1263$(_column_0, _id_0)));
}

function $bundle$058take_head$(_store_0) {
  const _heads_0 = _store_0["heads"];
  const _tails_0 = _store_0["tails"];
  const _tags_0 = _store_0["tags"];
  const _data_0 = _store_0["data"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tails_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tags_0, "tail": _data_0}}, "snd": _heads_0};
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_head$1261$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_head$1262$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_tail$1262$(_undo_0, ($bundle$058install_data_entries$1260$(_world_2, _tail_0)));
  }
}

function $bundle$058install_tag$1260$(_world_0, _entry_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1261$(($bundle$058family_tag$()), _world_0, _entry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1262$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1262$({$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1262$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1262$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1262$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1263$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1263$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1263$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1263$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1263$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1263$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_head$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1263$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1263$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1263$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1263$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_tail$1262$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058refused_head$1262$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_tail$1262$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $bundle$058install_data_entries$1260$(_world_0, _entries_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058install$1263$(_world_0, _entries_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1261$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1261$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1261$(_family_0, _world_0, _handle_0)));
}

function $bundle$058family_tag$() {
  return {$: "../../../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1262$(($bundle$058tag_identity$())))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1262$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1262$({$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1262$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1262$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1262$(_id_0, ($bundle$058take_tail$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1263$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1263$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($bundle$058take_head$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1263$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $bundle$058put_head$(_rest_0, _owned_0) {
  const _tails_0 = _rest_0["head"];
  const _t_0 = _rest_0["tail"];
  const _tags_0 = _t_0["head"];
  const _data_0 = _t_0["tail"];
  return {$: "bundle.Store", "heads": _owned_0, "tails": _tails_0, "tags": _tags_0, "data": _data_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1263$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1263$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1263$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1263$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058refused_head$1262$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_tail$1262$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_head$1262$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058install$1263$(_world_0, _payload_0) {
  const _head_0 = _payload_0["head"];
  const _tail_0 = _payload_0["tail"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_head$1263$(($bundle$058install_data$1260$(_world_0, _head_0)), _tail_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1261$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1261$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1262$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1262$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1262$(_previous_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1262$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1262$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1262$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1262$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1262$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1262$(_column_0, _id_0)));
}

function $bundle$058take_tail$(_store_0) {
  const _heads_0 = _store_0["heads"];
  const _tails_0 = _store_0["tails"];
  const _tags_0 = _store_0["tags"];
  const _data_0 = _store_0["data"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _heads_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tags_0, "tail": _data_0}}, "snd": _tails_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1263$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1263$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1263$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1263$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1263$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1263$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1263$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_head$1262$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_head$1263$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undo_0 = _result_0["undo"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_tail$1263$(_undo_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058terminal$1260$(_world_2, _tail_0)));
  }
}

function $bundle$058install_data$1260$(_world_0, _entry_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1260$(($bundle$058family_data$()), _world_0, _entry_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1261$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1261$({$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1261$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1262$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1262$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1262$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1262$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1262$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1262$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_tail$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1262$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1262$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1262$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1262$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1263$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1263$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1263$(_id_0, _stamp_0, ($bundle$058take_head$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1263$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1263$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($bundle$058put_head$(_rest_0, _column_1)), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1263$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1263$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1263$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058installed_tail$1263$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Refused") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    const _error_0 = _result_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058refused_head$1263$(_undoHead_0(_world_0), _tail_0, _error_0);
  } else if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined") {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_1 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_1};
  } else {
    const _world_2 = _result_0["world"];
    const _undoTail_0 = _result_0["undo"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_2, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_tail$1263$(_undoHead_0, _undoTail_0(_x_0));
})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058terminal$1260$(_world_0, _payload_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_0, "undo": run_clo((_x_0) => {
  return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": _x_0, "payload": {$: "Unit"}};
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058install$1260$(_family_0, _world_0, _entry_0) {
  const _handle_0 = _entry_0["handle"];
  const _incoming_0 = _entry_0["owner"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1260$(_family_0, _handle_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0)));
}

function $bundle$058family_data$() {
  return {$: "../../../../../../../../bendvy/src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1263$(($bundle$058data_identity$())))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1261$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1261$({$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, ($bundle$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1262$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($bundle$058take_tail$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1262$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $bundle$058put_tail$(_rest_0, _owned_0) {
  const _heads_0 = _rest_0["head"];
  const _t_0 = _rest_0["tail"];
  const _tags_0 = _t_0["head"];
  const _data_0 = _t_0["tail"];
  return {$: "bundle.Store", "heads": _heads_0, "tails": _owned_0, "tags": _tags_0, "data": _data_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1262$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1262$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1262$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1262$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1263$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_head$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1263$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1263$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_head$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1263$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1263$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1263$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1263$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058refused_head$1263$(_result_0, _tail_0, _error_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _restoreError_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Quarantined", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _restoreError_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_tail$1263$(_undoHead_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _tail_0 = _result_0["payload"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_head$1263$(_undoHead_0(_world_0), _tail_0);
  } else {
    const _world_1 = _result_0["world"];
    const _tail_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.TailPending", "undoHead": _undoHead_0, "tail": _tail_1}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058stamped$1260$(_family_0, _handle_0, _incoming_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1261$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1261$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1261$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $bundle$058take_tag$(_store_0) {
  const _heads_0 = _store_0["heads"];
  const _tails_0 = _store_0["tails"];
  const _tags_0 = _store_0["tags"];
  const _data_0 = _store_0["data"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _heads_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tails_0, "tail": _data_0}}, "snd": _tags_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1262$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1262$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1262$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1262$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1262$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1262$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1263$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1263$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1263$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1263$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1263$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1263$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1263$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1263$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1263$({$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1263$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1263$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1263$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1263$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1263$({$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1263$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1263$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1263$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1263$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045install$058restored_head$1263$(_result_0, _tail_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/bundle-install.Restored") {
    const _world_0 = _result_0["world"];
    const _head_0 = _result_0["payload"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _head_0, "tail": _tail_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _head_1 = _result_0["recovery"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_1, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-install.HeadPending", "head": _head_1, "tail": _tail_0}, "error": _error_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058replaced$1260$(_handle_0, _stamp_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected") {
    const _world_0 = _result_0["world"];
    const _incoming_0 = _result_0["incoming"];
    const _error_0 = _result_0["error"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Refused", "world": _world_0, "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}, "error": _error_0};
  } else {
    const _world_1 = _result_0["world"];
    const _previous_0 = _result_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Installed", "world": _world_1, "undo": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1260$({$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, _x_0);
})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_allowed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1261$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1261$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1261$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1261$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_tag$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1262$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1262$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, ($bundle$058take_tail$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1262$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1262$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($bundle$058put_tail$(_rest_0, _column_1)), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1262$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1262$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1262$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1263$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1263$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1263$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1263$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1263$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1263$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1263$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_0)));
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1263$(_column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1263$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1263$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1263$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1263$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1263$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1263$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1263$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1263$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1263$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1263$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1263$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1263$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo$1260$(_recovery_0, _world_0) {
  const _t_0 = _recovery_0["previous"];
  const _t_1 = _t_0["handle"];
  const _ns_0 = _t_1["namespace"];
  const _id_0 = _t_1["id"];
  const _previous_0 = _t_0["owner"];
  const _stamp_0 = _recovery_0["stamp"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1260$({$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0}, _id_0, _stamp_0, _previous_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../../../../../bendvy/src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, ($bundle$058take_data$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1261$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($bundle$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $bundle$058put_tag$(_rest_0, _owned_0) {
  const _heads_0 = _rest_0["head"];
  const _t_0 = _rest_0["tail"];
  const _tails_0 = _t_0["head"];
  const _data_0 = _t_0["tail"];
  return {$: "bundle.Store", "heads": _heads_0, "tails": _tails_0, "tags": _owned_0, "data": _data_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1262$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_tail$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1262$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1262$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_tail$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1262$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1262$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1262$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1262$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1262$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../../../../../../bendvy/src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1263$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1263$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1263$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1263$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1263$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1263$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1263$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1263$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1263$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1263$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1263$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1263$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_checked$1260$(_handle_0, _id_0, _stamp_0, _previous_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _previous_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1260$(_handle_0, _id_0, _stamp_0, _world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $bundle$058take_data$(_store_0) {
  const _heads_0 = _store_0["heads"];
  const _tails_0 = _store_0["tails"];
  const _tags_0 = _store_0["tags"];
  const _data_0 = _store_0["data"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _heads_0, "tail": {$: "../../../../../../../../bendvy/src/ecs/bundle-pack.Pack", "head": _tails_0, "tail": _tags_0}}, "snd": _data_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1261$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1262$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1262$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1262$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1262$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1262$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1262$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1262$({$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1262$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1262$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1262$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1262$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1262$({$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1262$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1262$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1262$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1262$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1263$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1263$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1263$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1263$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1263$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1263$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undo_present$1260$(_handle_0, _id_0, _stamp_0, _world_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _present_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1260$(_handle_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1260$(_id_0, _previous_0, _present_0, 0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_data$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1261$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1261$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, ($bundle$058take_tag$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1261$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($bundle$058put_tag$(_rest_0, _column_1)), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1262$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1262$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1262$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1262$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1262$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1262$(_column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1262$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1262$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1262$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1262$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1262$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1262$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1262$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1262$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1262$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1262$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1262$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1262$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1263$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047bundle$045component$045install$058undone$1260$(_handle_0, _stamp_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _incoming_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Restored", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0)), "payload": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _incoming_0}};
  } else {
    const _old_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/bundle-install.Pending", "world": _world_0, "recovery": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Recovery", "previous": {$: "../../../../../../../../bendvy/src/ecs/bundle-component-install.Entry", "handle": _handle_0, "owner": _old_0}, "stamp": _stamp_0}, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($bundle$058take_data$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $bundle$058put_data$(_rest_0, _owned_0) {
  const _heads_0 = _rest_0["head"];
  const _t_0 = _rest_0["tail"];
  const _tails_0 = _t_0["head"];
  const _tags_0 = _t_0["tail"];
  return {$: "bundle.Store", "heads": _heads_0, "tails": _tails_0, "tags": _tags_0, "data": _owned_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1261$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_tag$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_tag$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1262$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1262$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1262$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1262$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1262$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1262$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1262$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1262$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1262$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1262$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1262$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1262$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../../../../../bendvy/src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp$1260$(_handle_0, _stamp_0, _world_0) {
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../../../../../bendvy/src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../../../../../bendvy/src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../../../../../bendvy/src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1261$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$({$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$({$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1262$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1262$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1262$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1262$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1262$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1262$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_done$1260$(_observed_0) {
  const _world_0 = _observed_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_world$1260$(_id_0, _stamp_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, ($bundle$058take_data$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../bendvy/src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($bundle$058put_data$(_rest_0, _column_1)), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1261$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1262$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058restore_stamp_store$1260$(_id_0, _stamp_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_data$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0)))), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($bundle$058put_data$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../../../../../bendvy/src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1261$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_stamp$1260$(_column_0, _id_0, _stamp_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$({$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$({$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_restore_state$1260$(_id_0, _stamp_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../../../bendvy/src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.Prepared", "state": {$: "../../../../../../../../bendvy/src/ecs/column.Owned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../bendvy/src/ecs/column.Rejected", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../bendvy/src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../bendvy/src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../bendvy/src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../bendvy/src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../bendvy/src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../bendvy/src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../bendvy/src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../../../bendvy/src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../../../bendvy/src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);