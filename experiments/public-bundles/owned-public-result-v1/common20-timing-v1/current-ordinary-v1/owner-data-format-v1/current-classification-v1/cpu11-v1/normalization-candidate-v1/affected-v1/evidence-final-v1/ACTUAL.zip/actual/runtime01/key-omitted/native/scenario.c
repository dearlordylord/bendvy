
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID_NIL 13
#define CID_CON 14
#define CID_CHR 15
#define CID_SCHEMA_FRAGMENTS_ENTRY 16
#define CID_SCHEMA_FRAGMENTS_CLASSIFIED 17
#define CID_S 18
#define CID_SCHEMA_FRAGMENTS_COMPONENT 19
#define CID_SCHEMA_FRAGMENTS_RESOURCE 20
#define CID_SCHEMA_FRAGMENTS_EVENT 21
#define CID_SCHEMA_FRAGMENTS_RELATION 22
#define CID_SCHEMA_FRAGMENTS_SERVICE 23
#define CID_SCHEMA_FRAGMENTS_VALID 24
#define CID_SCHEMA_FRAGMENTS_INVALID 25
#define CID_SCHEMA_FRAGMENTS_MERGED 26
#define CID_SCHEMA_FRAGMENTS_REJECTED 27
#define CID_SCHEMA_FRAGMENTS_FRAGMENT 28
#define CID_SCHEMA_FRAGMENTS_PLAIN 29
#define CID_SCHEMA_FRAGMENTS_TRANSIENT 30
#define CID_SCHEMA_FRAGMENTS_CONSTRUCTED 31
#define CID_SCHEMA_FRAGMENTS_DUPLICATEKEY 32
#define CID_SCHEMA_FRAGMENTS_DUPLICATENAME 33
#define CID_SCHEMA_FRAGMENTS_UNDECLAREDDESCRIPTOR 34
#define CID_ORDINARY_SCHEMA_SCHEMA 35
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_COLUMN 36
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_PREPARED 37
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_INDEXED 38
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_PREPAREDINDEXED 39
#define CID________________________________________BENDVY_SRC_ECS_PERSISTENCE_DECLARATION_PLAIN 40
#define CID________________________________________BENDVY_SRC_ECS_PERSISTENCE_DECLARATION_TRANSIENT 41
#define CID________________________________________BENDVY_SRC_ECS_ORDINARY_DECLARATION_DECLARATION 42
#define CID________________________________________BENDVY_SRC_ECS_LIFECYCLE_ENTRY 43
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_OWNED 44
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_WRAPPED 45
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_INDEXEDORDINARYOWNED 46
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_INDEXEDORDINARYWRAPPED 47
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_INDEXEDPREPAREDOWNED 48
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_INDEXEDPREPAREDWRAPPED 49
#define CID________________________________________BENDVY_SRC_ECS_LIFECYCLE_STAMP 50
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_STATE 51
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_INDEXEDORDINARYSTATE 52
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_INDEXEDPREPAREDSTATE 53
#define CID_LT 54
#define CID_EQ 55
#define CID_GT 56
#define CID________________________________________BENDVY_SRC_ECS_OWNER_HANDOFF_HANDOFFNIL 57
#define CID________________________________________BENDVY_SRC_ECS_OWNER_HANDOFF_HANDOFFCON 58
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_HISTORYNIL 59
#define CID________________________________________BENDVY_SRC_ECS_COLUMN_HISTORYCON 60
#define CID________________________________________BENDVY_SRC_ECS_INDEXED_LIFECYCLE_METADATA 61
#define FID_U32_SHOW_GO 0
#define FID_STRING_CMP 1
#define FID_STRING_CMP_K7 2
#define FID_STRING_ORDER 3
#define FID_STRING_ORDER_K11 4
#define FID_U32_SHOW 5
#define FID_STRING_EQ 6
#define FID_STRING_EQ_K15 7
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32 8
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32_K27 9
#define FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0 10
#define FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K31 11
#define FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K32 12
#define FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0 13
#define FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K41 14
#define FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K42 15
#define FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K43 16
#define FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K44 17
#define FID_FRAGMENT 18
#define FID_FRAGMENT_K48 19
#define FID_FRAGMENT_K49 20
#define FID_FRAGMENT_K50 21
#define FID_FRAGMENT_K51 22
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY 23
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K59 24
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K60 25
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K61 26
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K62 27
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K63 28
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K64 29
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K65 30
#define FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K66 31
#define FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0 32
#define FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K76 33
#define FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K77 34
#define FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0 35
#define FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K82 36
#define FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_C83 37
#define FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K84 38
#define FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K85 39
#define FID_ERROR 40
#define FID_ERROR_K88 41
#define FID_ERROR_K89 42
#define FID_ERROR_K90 43
#define FID_ERROR_K91 44
#define FID_ERROR_K92 45
#define FID_ERROR_K93 46
#define FID_ERROR_K94 47
#define FID_ERROR_K95 48
#define FID_ENTRY 49
#define FID_ENTRY_K99 50
#define FID_ENTRY_K100 51
#define FID_ENTRY_K101 52
#define FID_ENTRY_K102 53
#define FID_ENTRY_K103 54
#define FID_ENTRY_K104 55
#define FID_ENTRY_K105 56
#define FID_ENTRY_K106 57
#define FID_ENTRY_K107 58
#define FID_SCHEMA_FRAGMENTS_CHECK_ONE_0 59
#define FID_SCHEMA_FRAGMENTS_CHECK_ONE_0_K117 60
#define FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0 61
#define FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K119 62
#define FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K120 63
#define FID_SCHEMA_FRAGMENTS_MERGE_0 64
#define FID_SCHEMA_FRAGMENTS_MERGE_0_K122 65
#define FID_SCHEMA_FRAGMENTS_MERGE_0_K123 66
#define FID_SCHEMA_FRAGMENTS_MERGE_0_K124 67
#define FID_SCHEMA_FRAGMENTS_MERGE_0_K125 68
#define FID_SCHEMA_FRAGMENTS_MERGE_0_K126 69
#define FID_MERGE 70
#define FID_MERGE_K128 71
#define FID_MERGE_K129 72
#define FID_MERGE_K130 73
#define FID_MERGE_K131 74
#define FID_MERGE_K132 75
#define FID_MERGE_K133 76
#define FID_MERGE_K134 77
#define FID_MERGE_K135 78
#define FID_MERGE_K136 79
#define FID_MERGE_K137 80
#define FID_MERGE_K138 81
#define FID_MERGE_K139 82
#define FID_MERGE_K140 83
#define FID_MERGE_K141 84
#define FID_MERGE_K142 85
#define FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0 86
#define FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0_K145 87
#define FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0 88
#define FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K147 89
#define FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_C148 90
#define FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K149 91
#define FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K150 92
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0 93
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K152 94
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K153 95
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K154 96
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K155 97
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K156 98
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K157 99
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K158 100
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K159 101
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K160 102
#define FID_SCHEMA_FRAGMENTS_VALIDATE_0_K161 103
#define FID_VALIDATION 104
#define FID_SCHEMA_FRAGMENTS_FILTER_KIND_0 105
#define FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K164 106
#define FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K165 107
#define FID_ENTRIES 108
#define FID_ENTRIES_K167 109
#define FID_ENTRIES_K168 110
#define FID_ENTRIES_K169 111
#define FID_STRING_APPEND 112
#define FID_STRING_APPEND_K171 113
#define FID_CONTROLS 114
#define FID_CONTROLS_K176 115
#define FID_CONTROLS_K177 116
#define FID_CONTROLS_K178 117
#define FID_CONTROLS_K179 118
#define FID_CONTROLS_K180 119
#define FID_CONTROLS_K181 120
#define FID_CONTROLS_K182 121
#define FID_CONTROLS_K183 122
#define FID_CONTROLS_K184 123
#define FID_CONTROLS_K185 124
#define FID_CONTROLS_K186 125
#define FID_CONTROLS_K187 126
#define FID_CONTROLS_K188 127
#define FID_CONTROLS_K189 128
#define FID_CONTROLS_K190 129
#define FID_CONTROLS_K191 130
#define FID_CONTROLS_K192 131
#define FID_CONTROLS_K193 132
#define FID_CONTROLS_K194 133
#define FID_CONTROLS_K195 134
#define FID_CONTROLS_K196 135
#define FID_CONTROLS_K197 136
#define FID_CONTROLS_K198 137
#define FID_CONTROLS_K199 138
#define FID_CONTROLS_K200 139
#define FID_CONTROLS_K201 140
#define FID_CONTROLS_K202 141
#define FID_CONTROLS_K203 142
#define FID_CONTROLS_K204 143
#define FID_CONTROLS_K205 144
#define FID_CONTROLS_K206 145
#define FID_CONTROLS_K207 146
#define FID_CONTROLS_K208 147
#define FID_CONTROLS_K209 148
#define FID_CONTROLS_K210 149
#define FID_CONTROLS_K211 150
#define FID_CONTROLS_K212 151
#define FID_CONTROLS_K213 152
#define FID_CONTROLS_K214 153
#define FID_CONTROLS_K215 154
#define FID_CONTROLS_K216 155
#define FID_CONTROLS_K217 156
#define FID_CONTROLS_K218 157
#define FID_CONTROLS_K219 158
#define FID_CONTROLS_K220 159
#define FID_CONTROLS_K221 160
#define FID_CONTROLS_K222 161
#define FID_CONTROLS_K223 162
#define FID_CONTROLS_K224 163
#define FID_CONTROLS_K225 164
#define FID_CONTROLS_K226 165
#define FID_CONTROLS_K227 166
#define FID_CONTROLS_K228 167
#define FID_CONTROLS_K229 168
#define FID_CONTROLS_K230 169
#define FID_CONTROLS_K231 170
#define FID_CONTROLS_K232 171
#define FID_CONTROLS_K233 172
#define FID_CONTROLS_K234 173
#define FID_CONTROLS_K235 174
#define FID_CONTROLS_K236 175
#define FID_CONTROLS_K237 176
#define FID_CONTROLS_K238 177
#define FID_CONTROLS_K239 178
#define FID_CONTROLS_K240 179
#define FID_CONTROLS_K241 180
#define FID_CONTROLS_K242 181
#define FID_CONTROLS_K243 182
#define FID_CONTROLS_K244 183
#define FID_CONTROLS_K245 184
#define FID_CONTROLS_K246 185
#define FID_CONTROLS_K247 186
#define FID_CONTROLS_K248 187
#define FID_CONTROLS_K249 188
#define FID_CONTROLS_K250 189
#define FID_CONTROLS_K251 190
#define FID_CONTROLS_K252 191
#define FID_CONTROLS_K253 192
#define FID_CONTROLS_K254 193
#define FID_CONTROLS_K255 194
#define FID_CONTROLS_K256 195
#define FID_CONTROLS_K257 196
#define FID_CONTROLS_K258 197
#define FID_CONTROLS_K259 198
#define FID_CONTROLS_K260 199
#define FID_CONTROLS_K261 200
#define FID_CONTROLS_K262 201
#define FID_CONTROLS_K263 202
#define FID_CONTROLS_K264 203
#define FID_CONTROLS_K265 204
#define FID_CONTROLS_K266 205
#define FID_CONTROLS_K267 206
#define FID_CONTROLS_K268 207
#define FID_CONTROLS_K269 208
#define FID_CONTROLS_K270 209
#define FID_CONTROLS_K271 210
#define FID_CONTROLS_K272 211
#define FID_CONTROLS_K273 212
#define FID_CONTROLS_K274 213
#define FID_CONTROLS_K275 214
#define FID_CONTROLS_K276 215
#define FID_CONTROLS_K277 216
#define FID_CONTROLS_K278 217
#define FID_CONTROLS_K279 218
#define FID_CONTROLS_K280 219
#define FID_CONTROLS_K281 220
#define FID_CONTROLS_K282 221
#define FID_CONTROLS_K283 222
#define FID_CONTROLS_K284 223
#define FID_CONTROLS_K285 224
#define FID_CONTROLS_K286 225
#define FID_CONTROLS_K287 226
#define FID_CONTROLS_K288 227
#define FID_CONTROLS_K289 228
#define FID_CONTROLS_K290 229
#define FID_CONTROLS_K291 230
#define FID_CONTROLS_K292 231
#define FID_CONTROLS_K293 232
#define FID_CONTROLS_K294 233
#define FID_CONTROLS_K295 234
#define FID_CONTROLS_K296 235
#define FID_CONTROLS_K297 236
#define FID_CONTROLS_K298 237
#define FID_ORDINARY 238
#define FID_ORDINARY_K300 239
#define FID_ORDINARY_K301 240
#define FID_ORDINARY_K302 241
#define FID_ORDINARY_K303 242
#define FID_ORDINARY_K304 243
#define FID_ORDINARY_K305 244
#define FID_ORDINARY_K306 245
#define FID_ORDINARY_K307 246
#define FID_ORDINARY_K308 247
#define FID_ORDINARY_K309 248
#define FID_ORDINARY_K310 249
#define FID_ORDINARY_K311 250
#define FID_ORDINARY_K312 251
#define FID_ORDINARY_K313 252
#define FID_ORDINARY_K314 253
#define FID_ORDINARY_K315 254
#define FID_ORDINARY_K316 255
#define FID_ORDINARY_K317 256
#define FID_ORDINARY_K318 257
#define FID_ORDINARY_K319 258
#define FID_ORDINARY_K320 259
#define FID_ORDINARY_K321 260
#define FID_ORDINARY_K322 261
#define FID_ORDINARY_K323 262
#define FID_ORDINARY_K324 263
#define FID_ORDINARY_K325 264
#define FID_ORDINARY_K326 265
#define FID_ORDINARY_K327 266
#define FID_ORDINARY_K328 267
#define FID_ORDINARY_K329 268
#define FID_LIST_APPEND 269
#define FID_LIST_APPEND_K331 270
#define FID_MAIN 271
#define FID_MAIN_K333 272
#define FID_MAIN_K334 273
#define FID_IO_EMIT 274
#define FID_CLO_APPLY 275
#define FID_EXIT 276
#define FID_ENTER 277
CONSTV u8 FID_T[][3] = { { 3, 0, 2 }, { 2, 0, 2 }, { 5, 3, 2 }, { 2, 0, 2 }, { 3, 3, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 10, 0, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 3, 0, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 2, 0, 2 }, { 3, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 2, 2, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 4, 2, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 6, 0, 2 }, { 7, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 12, 5, 2 }, { 8, 0, 2 }, { 5, 5, 2 }, { 1, 1, 2 }, { 4, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 5, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 6, 0, 2 }, { 6, 1, 2 }, { 6, 0, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 0, 2 }, { 9, 5, 2 }, { 14, 5, 2 }, { 15, 1, 2 }, { 19, 5, 2 }, { 20, 1, 2 }, { 9, 0, 2 }, { 4, 2, 2 }, { 5, 2, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 9, 3, 2 }, { 10, 3, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 9, 1, 2 }, { 1, 0, 2 }, { 6, 1, 2 }, { 2, 0, 2 }, { 8, 1, 2 }, { 3, 0, 2 }, { 5, 5, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 6, 5, 2 }, { 7, 1, 2 }, { 11, 5, 2 }, { 12, 1, 2 }, { 16, 5, 2 }, { 17, 1, 2 }, { 21, 5, 2 }, { 21, 1, 2 }, { 25, 5, 2 }, { 5, 0, 2 }, { 2, 0, 2 }, { 5, 1, 2 }, { 6, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 5, 5, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 6, 5, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 7, 5, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 8, 5, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 9, 5, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 10, 5, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 11, 5, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 12, 5, 2 }, { 8, 1, 2 }, { 8, 1, 2 }, { 13, 5, 2 }, { 9, 1, 2 }, { 9, 1, 2 }, { 14, 5, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 15, 5, 2 }, { 11, 1, 2 }, { 11, 1, 2 }, { 16, 5, 2 }, { 12, 1, 2 }, { 12, 1, 2 }, { 17, 5, 2 }, { 13, 1, 2 }, { 13, 1, 2 }, { 18, 5, 2 }, { 14, 1, 2 }, { 14, 1, 2 }, { 19, 5, 2 }, { 15, 1, 2 }, { 15, 1, 2 }, { 20, 5, 2 }, { 16, 1, 2 }, { 16, 1, 2 }, { 21, 5, 2 }, { 17, 1, 2 }, { 17, 1, 2 }, { 22, 5, 2 }, { 18, 1, 2 }, { 18, 1, 2 }, { 23, 5, 2 }, { 19, 1, 2 }, { 19, 1, 2 }, { 24, 5, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 25, 5, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 26, 5, 2 }, { 22, 1, 2 }, { 22, 1, 2 }, { 27, 5, 2 }, { 23, 1, 2 }, { 23, 1, 2 }, { 28, 5, 2 }, { 24, 1, 2 }, { 24, 1, 2 }, { 29, 5, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 30, 5, 2 }, { 26, 1, 2 }, { 26, 1, 2 }, { 31, 5, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 32, 5, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 33, 5, 2 }, { 29, 1, 2 }, { 29, 1, 2 }, { 34, 5, 2 }, { 30, 1, 2 }, { 30, 1, 2 }, { 35, 5, 2 }, { 31, 1, 2 }, { 31, 1, 2 }, { 36, 5, 2 }, { 32, 1, 2 }, { 32, 1, 2 }, { 37, 5, 2 }, { 33, 1, 2 }, { 33, 1, 2 }, { 38, 5, 2 }, { 34, 1, 2 }, { 34, 1, 2 }, { 39, 5, 2 }, { 35, 1, 2 }, { 35, 1, 2 }, { 40, 5, 2 }, { 36, 1, 2 }, { 36, 1, 2 }, { 41, 5, 2 }, { 37, 1, 2 }, { 37, 1, 2 }, { 42, 5, 2 }, { 38, 1, 2 }, { 38, 1, 2 }, { 43, 5, 2 }, { 39, 1, 2 }, { 39, 1, 2 }, { 44, 5, 2 }, { 40, 1, 2 }, { 40, 1, 2 }, { 45, 5, 2 }, { 41, 1, 2 }, { 41, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 4, 1, 2 }, { 9, 5, 2 }, { 5, 1, 2 }, { 5, 1, 2 }, { 6, 1, 2 }, { 10, 5, 2 }, { 6, 1, 2 }, { 6, 1, 2 }, { 7, 1, 2 }, { 11, 5, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 8, 1, 2 }, { 11, 5, 2 }, { 7, 1, 2 }, { 7, 1, 2 }, { 8, 1, 2 }, { 16, 9, 2 }, { 17, 10, 2 }, { 26, 9, 2 }, { 27, 10, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 0 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 0 }, { 1, 0 }, { 0, 1 }, { 0, 1 }, { 0, 0 }, { 0, 1 }, { 2, 1 }, { 1, 1 }, { 3, 1 }, { 4, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 0 }, { 4, 0 }, { 3, 0 }, { 8, 0 }, { 2, 0 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 3, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 1, 0 }, { 0, 0 }, { 0, 0 }, { 1, 0 }, { 3, 0 }, { 8, 0 }, { 1, 0 }, { 6, 0 }, { 1, 0 }, { 12, 0 }, { 1, 0 }, { 2, 0 }, { 8, 0 }, { 6, 0 }, { 12, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 3, 0 }, { 0, 0 }, { 4, 0 }, { 5, 0 } };
#define STAT_LEN 1670

#define WL_RESW 10
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9

#define WL_TABLE WL_X(FID_U32_SHOW_GO) WL_X(FID_STRING_CMP) WL_X(FID_STRING_CMP_K7) WL_X(FID_STRING_ORDER) WL_X(FID_STRING_ORDER_K11) WL_X(FID_U32_SHOW) WL_X(FID_STRING_EQ) WL_X(FID_STRING_EQ_K15) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32_K27) WL_X(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0) WL_X(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K31) WL_X(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K32) WL_X(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0) WL_X(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K41) WL_X(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K42) WL_X(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K43) WL_X(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K44) WL_X(FID_FRAGMENT) WL_X(FID_FRAGMENT_K48) WL_X(FID_FRAGMENT_K49) WL_X(FID_FRAGMENT_K50) WL_X(FID_FRAGMENT_K51) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K59) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K60) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K61) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K62) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K63) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K64) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K65) WL_X(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K66) WL_X(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0) WL_X(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K76) WL_X(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K77) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K82) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_C83) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K84) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K85) WL_X(FID_ERROR) WL_X(FID_ERROR_K88) WL_X(FID_ERROR_K89) WL_X(FID_ERROR_K90) WL_X(FID_ERROR_K91) WL_X(FID_ERROR_K92) WL_X(FID_ERROR_K93) WL_X(FID_ERROR_K94) WL_X(FID_ERROR_K95) WL_X(FID_ENTRY) WL_X(FID_ENTRY_K99) WL_X(FID_ENTRY_K100) WL_X(FID_ENTRY_K101) WL_X(FID_ENTRY_K102) WL_X(FID_ENTRY_K103) WL_X(FID_ENTRY_K104) WL_X(FID_ENTRY_K105) WL_X(FID_ENTRY_K106) WL_X(FID_ENTRY_K107) WL_X(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0) WL_X(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0_K117) WL_X(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0) WL_X(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K119) WL_X(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K120) WL_X(FID_SCHEMA_FRAGMENTS_MERGE_0) WL_X(FID_SCHEMA_FRAGMENTS_MERGE_0_K122) WL_X(FID_SCHEMA_FRAGMENTS_MERGE_0_K123) WL_X(FID_SCHEMA_FRAGMENTS_MERGE_0_K124) WL_X(FID_SCHEMA_FRAGMENTS_MERGE_0_K125) WL_X(FID_SCHEMA_FRAGMENTS_MERGE_0_K126) WL_X(FID_MERGE) WL_X(FID_MERGE_K128) WL_X(FID_MERGE_K129) WL_X(FID_MERGE_K130) WL_X(FID_MERGE_K131) WL_X(FID_MERGE_K132) WL_X(FID_MERGE_K133) WL_X(FID_MERGE_K134) WL_X(FID_MERGE_K135) WL_X(FID_MERGE_K136) WL_X(FID_MERGE_K137) WL_X(FID_MERGE_K138) WL_X(FID_MERGE_K139) WL_X(FID_MERGE_K140) WL_X(FID_MERGE_K141) WL_X(FID_MERGE_K142) WL_X(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0) WL_X(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0_K145) WL_X(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0) WL_X(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K147) WL_X(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_C148) WL_X(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K149) WL_X(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K150) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K152) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K153) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K154) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K155) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K156) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K157) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K158) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K159) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K160) WL_X(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K161) WL_X(FID_VALIDATION) WL_X(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0) WL_X(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K164) WL_X(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K165) WL_X(FID_ENTRIES) WL_X(FID_ENTRIES_K167) WL_X(FID_ENTRIES_K168) WL_X(FID_ENTRIES_K169) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K171) WL_X(FID_CONTROLS) WL_X(FID_CONTROLS_K176) WL_X(FID_CONTROLS_K177) WL_X(FID_CONTROLS_K178) WL_X(FID_CONTROLS_K179) WL_X(FID_CONTROLS_K180) WL_X(FID_CONTROLS_K181) WL_X(FID_CONTROLS_K182) WL_X(FID_CONTROLS_K183) WL_X(FID_CONTROLS_K184) WL_X(FID_CONTROLS_K185) WL_X(FID_CONTROLS_K186) WL_X(FID_CONTROLS_K187) WL_X(FID_CONTROLS_K188) WL_X(FID_CONTROLS_K189) WL_X(FID_CONTROLS_K190) WL_X(FID_CONTROLS_K191) WL_X(FID_CONTROLS_K192) WL_X(FID_CONTROLS_K193) WL_X(FID_CONTROLS_K194) WL_X(FID_CONTROLS_K195) WL_X(FID_CONTROLS_K196) WL_X(FID_CONTROLS_K197) WL_X(FID_CONTROLS_K198) WL_X(FID_CONTROLS_K199) WL_X(FID_CONTROLS_K200) WL_X(FID_CONTROLS_K201) WL_X(FID_CONTROLS_K202) WL_X(FID_CONTROLS_K203) WL_X(FID_CONTROLS_K204) WL_X(FID_CONTROLS_K205) WL_X(FID_CONTROLS_K206) WL_X(FID_CONTROLS_K207) WL_X(FID_CONTROLS_K208) WL_X(FID_CONTROLS_K209) WL_X(FID_CONTROLS_K210) WL_X(FID_CONTROLS_K211) WL_X(FID_CONTROLS_K212) WL_X(FID_CONTROLS_K213) WL_X(FID_CONTROLS_K214) WL_X(FID_CONTROLS_K215) WL_X(FID_CONTROLS_K216) WL_X(FID_CONTROLS_K217) WL_X(FID_CONTROLS_K218) WL_X(FID_CONTROLS_K219) WL_X(FID_CONTROLS_K220) WL_X(FID_CONTROLS_K221) WL_X(FID_CONTROLS_K222) WL_X(FID_CONTROLS_K223) WL_X(FID_CONTROLS_K224) WL_X(FID_CONTROLS_K225) WL_X(FID_CONTROLS_K226) WL_X(FID_CONTROLS_K227) WL_X(FID_CONTROLS_K228) WL_X(FID_CONTROLS_K229) WL_X(FID_CONTROLS_K230) WL_X(FID_CONTROLS_K231) WL_X(FID_CONTROLS_K232) WL_X(FID_CONTROLS_K233) WL_X(FID_CONTROLS_K234) WL_X(FID_CONTROLS_K235) WL_X(FID_CONTROLS_K236) WL_X(FID_CONTROLS_K237) WL_X(FID_CONTROLS_K238) WL_X(FID_CONTROLS_K239) WL_X(FID_CONTROLS_K240) WL_X(FID_CONTROLS_K241) WL_X(FID_CONTROLS_K242) WL_X(FID_CONTROLS_K243) WL_X(FID_CONTROLS_K244) WL_X(FID_CONTROLS_K245) WL_X(FID_CONTROLS_K246) WL_X(FID_CONTROLS_K247) WL_X(FID_CONTROLS_K248) WL_X(FID_CONTROLS_K249) WL_X(FID_CONTROLS_K250) WL_X(FID_CONTROLS_K251) WL_X(FID_CONTROLS_K252) WL_X(FID_CONTROLS_K253) WL_X(FID_CONTROLS_K254) WL_X(FID_CONTROLS_K255) WL_X(FID_CONTROLS_K256) WL_X(FID_CONTROLS_K257) WL_X(FID_CONTROLS_K258) WL_X(FID_CONTROLS_K259) WL_X(FID_CONTROLS_K260) WL_X(FID_CONTROLS_K261) WL_X(FID_CONTROLS_K262) WL_X(FID_CONTROLS_K263) WL_X(FID_CONTROLS_K264) WL_X(FID_CONTROLS_K265) WL_X(FID_CONTROLS_K266) WL_X(FID_CONTROLS_K267) WL_X(FID_CONTROLS_K268) WL_X(FID_CONTROLS_K269) WL_X(FID_CONTROLS_K270) WL_X(FID_CONTROLS_K271) WL_X(FID_CONTROLS_K272) WL_X(FID_CONTROLS_K273) WL_X(FID_CONTROLS_K274) WL_X(FID_CONTROLS_K275) WL_X(FID_CONTROLS_K276) WL_X(FID_CONTROLS_K277) WL_X(FID_CONTROLS_K278) WL_X(FID_CONTROLS_K279) WL_X(FID_CONTROLS_K280) WL_X(FID_CONTROLS_K281) WL_X(FID_CONTROLS_K282) WL_X(FID_CONTROLS_K283) WL_X(FID_CONTROLS_K284) WL_X(FID_CONTROLS_K285) WL_X(FID_CONTROLS_K286) WL_X(FID_CONTROLS_K287) WL_X(FID_CONTROLS_K288) WL_X(FID_CONTROLS_K289) WL_X(FID_CONTROLS_K290) WL_X(FID_CONTROLS_K291) WL_X(FID_CONTROLS_K292) WL_X(FID_CONTROLS_K293) WL_X(FID_CONTROLS_K294) WL_X(FID_CONTROLS_K295) WL_X(FID_CONTROLS_K296) WL_X(FID_CONTROLS_K297) WL_X(FID_CONTROLS_K298) WL_X(FID_ORDINARY) WL_X(FID_ORDINARY_K300) WL_X(FID_ORDINARY_K301) WL_X(FID_ORDINARY_K302) WL_X(FID_ORDINARY_K303) WL_X(FID_ORDINARY_K304) WL_X(FID_ORDINARY_K305) WL_X(FID_ORDINARY_K306) WL_X(FID_ORDINARY_K307) WL_X(FID_ORDINARY_K308) WL_X(FID_ORDINARY_K309) WL_X(FID_ORDINARY_K310) WL_X(FID_ORDINARY_K311) WL_X(FID_ORDINARY_K312) WL_X(FID_ORDINARY_K313) WL_X(FID_ORDINARY_K314) WL_X(FID_ORDINARY_K315) WL_X(FID_ORDINARY_K316) WL_X(FID_ORDINARY_K317) WL_X(FID_ORDINARY_K318) WL_X(FID_ORDINARY_K319) WL_X(FID_ORDINARY_K320) WL_X(FID_ORDINARY_K321) WL_X(FID_ORDINARY_K322) WL_X(FID_ORDINARY_K323) WL_X(FID_ORDINARY_K324) WL_X(FID_ORDINARY_K325) WL_X(FID_ORDINARY_K326) WL_X(FID_ORDINARY_K327) WL_X(FID_ORDINARY_K328) WL_X(FID_ORDINARY_K329) WL_X(FID_LIST_APPEND) WL_X(FID_LIST_APPEND_K331) WL_X(FID_MAIN) WL_X(FID_MAIN_K333) WL_X(FID_MAIN_K334) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 1
#define BLK_SHR 0

#if !DEVICE

static const u32 SHOW_DESC[] = { 7, 1, 2, 0, CID_NIL, 0, 1, 1, CID_CON, 2, 1, 0, 15, 1, 0, 4 };

static const char* SHOW_NAMES[] = { "Nil", "Con" };

#endif

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 48ull, term_pak(CID_SNIL, 0), 61ull, term_pak(CID_SNIL, 0), 114ull, term_ctr(CID_SCON, STAT_OFF + 2), 101ull, term_ctr(CID_SCON, STAT_OFF + 4), 110ull, term_ctr(CID_SCON, STAT_OFF + 6), 119ull, term_ctr(CID_SCON, STAT_OFF + 8), 111ull, term_ctr(CID_SCON, STAT_OFF + 10), 124ull, term_ctr(CID_SCON, STAT_OFF + 12), 41ull, term_pak(CID_SNIL, 0), 44ull, term_pak(CID_SNIL, 0), 40ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 20), 100ull, term_ctr(CID_SCON, STAT_OFF + 22), 111ull, term_ctr(CID_SCON, STAT_OFF + 24), 110ull, term_ctr(CID_SCON, STAT_OFF + 26), 58ull, term_pak(CID_SNIL, 0), 102ull, term_ctr(CID_SCON, STAT_OFF + 30), 97ull, term_ctr(CID_SCON, STAT_OFF + 32), 101ull, term_ctr(CID_SCON, STAT_OFF + 34), 108ull, term_ctr(CID_SCON, STAT_OFF + 36), 110ull, term_pak(CID_SNIL, 0), 105ull, term_ctr(CID_SCON, STAT_OFF + 40), 97ull, term_ctr(CID_SCON, STAT_OFF + 42), 108ull, term_ctr(CID_SCON, STAT_OFF + 44), 80ull, term_ctr(CID_SCON, STAT_OFF + 46), 116ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 50), 101ull, term_ctr(CID_SCON, STAT_OFF + 52), 105ull, term_ctr(CID_SCON, STAT_OFF + 54), 115ull, term_ctr(CID_SCON, STAT_OFF + 56), 110ull, term_ctr(CID_SCON, STAT_OFF + 58), 97ull, term_ctr(CID_SCON, STAT_OFF + 60), 114ull, term_ctr(CID_SCON, STAT_OFF + 62), 84ull, term_ctr(CID_SCON, STAT_OFF + 64), 100ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 68), 116ull, term_ctr(CID_SCON, STAT_OFF + 70), 99ull, term_ctr(CID_SCON, STAT_OFF + 72), 117ull, term_ctr(CID_SCON, STAT_OFF + 74), 114ull, term_ctr(CID_SCON, STAT_OFF + 76), 116ull, term_ctr(CID_SCON, STAT_OFF + 78), 115ull, term_ctr(CID_SCON, STAT_OFF + 80), 110ull, term_ctr(CID_SCON, STAT_OFF + 82), 111ull, term_ctr(CID_SCON, STAT_OFF + 84), 67ull, term_ctr(CID_SCON, STAT_OFF + 86), 110ull, term_ctr(CID_SCON, STAT_OFF + 54), 111ull, term_ctr(CID_SCON, STAT_OFF + 90), 112ull, term_ctr(CID_SCON, STAT_OFF + 92), 109ull, term_ctr(CID_SCON, STAT_OFF + 94), 111ull, term_ctr(CID_SCON, STAT_OFF + 96), 67ull, term_ctr(CID_SCON, STAT_OFF + 98), 101ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 102), 114ull, term_ctr(CID_SCON, STAT_OFF + 104), 117ull, term_ctr(CID_SCON, STAT_OFF + 106), 111ull, term_ctr(CID_SCON, STAT_OFF + 108), 115ull, term_ctr(CID_SCON, STAT_OFF + 110), 101ull, term_ctr(CID_SCON, STAT_OFF + 112), 82ull, term_ctr(CID_SCON, STAT_OFF + 114), 118ull, term_ctr(CID_SCON, STAT_OFF + 54), 69ull, term_ctr(CID_SCON, STAT_OFF + 118), 111ull, term_ctr(CID_SCON, STAT_OFF + 40), 105ull, term_ctr(CID_SCON, STAT_OFF + 122), 116ull, term_ctr(CID_SCON, STAT_OFF + 124), 97ull, term_ctr(CID_SCON, STAT_OFF + 126), 108ull, term_ctr(CID_SCON, STAT_OFF + 128), 101ull, term_ctr(CID_SCON, STAT_OFF + 130), 82ull, term_ctr(CID_SCON, STAT_OFF + 132), 105ull, term_ctr(CID_SCON, STAT_OFF + 104), 118ull, term_ctr(CID_SCON, STAT_OFF + 136), 114ull, term_ctr(CID_SCON, STAT_OFF + 138), 101ull, term_ctr(CID_SCON, STAT_OFF + 140), 83ull, term_ctr(CID_SCON, STAT_OFF + 142), 65ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 2), 104ull, term_ctr(CID_SCON, STAT_OFF + 148), 103ull, term_ctr(CID_SCON, STAT_OFF + 150), 105ull, term_ctr(CID_SCON, STAT_OFF + 152), 114ull, term_ctr(CID_SCON, STAT_OFF + 154), 124ull, term_ctr(CID_SCON, STAT_OFF + 156), 102ull, term_ctr(CID_SCON, STAT_OFF + 148), 101ull, term_ctr(CID_SCON, STAT_OFF + 160), 108ull, term_ctr(CID_SCON, STAT_OFF + 162), 124ull, term_ctr(CID_SCON, STAT_OFF + 164), 100ull, term_ctr(CID_SCON, STAT_OFF + 30), 101ull, term_ctr(CID_SCON, STAT_OFF + 168), 103ull, term_ctr(CID_SCON, STAT_OFF + 170), 114ull, term_ctr(CID_SCON, STAT_OFF + 172), 101ull, term_ctr(CID_SCON, STAT_OFF + 174), 77ull, term_ctr(CID_SCON, STAT_OFF + 176), 121ull, term_ctr(CID_SCON, STAT_OFF + 30), 101ull, term_ctr(CID_SCON, STAT_OFF + 180), 75ull, term_ctr(CID_SCON, STAT_OFF + 182), 101ull, term_ctr(CID_SCON, STAT_OFF + 184), 116ull, term_ctr(CID_SCON, STAT_OFF + 186), 97ull, term_ctr(CID_SCON, STAT_OFF + 188), 99ull, term_ctr(CID_SCON, STAT_OFF + 190), 105ull, term_ctr(CID_SCON, STAT_OFF + 192), 108ull, term_ctr(CID_SCON, STAT_OFF + 194), 112ull, term_ctr(CID_SCON, STAT_OFF + 196), 117ull, term_ctr(CID_SCON, STAT_OFF + 198), 68ull, term_ctr(CID_SCON, STAT_OFF + 200), 101ull, term_ctr(CID_SCON, STAT_OFF + 30), 109ull, term_ctr(CID_SCON, STAT_OFF + 204), 97ull, term_ctr(CID_SCON, STAT_OFF + 206), 78ull, term_ctr(CID_SCON, STAT_OFF + 208), 101ull, term_ctr(CID_SCON, STAT_OFF + 210), 116ull, term_ctr(CID_SCON, STAT_OFF + 212), 97ull, term_ctr(CID_SCON, STAT_OFF + 214), 99ull, term_ctr(CID_SCON, STAT_OFF + 216), 105ull, term_ctr(CID_SCON, STAT_OFF + 218), 108ull, term_ctr(CID_SCON, STAT_OFF + 220), 112ull, term_ctr(CID_SCON, STAT_OFF + 222), 117ull, term_ctr(CID_SCON, STAT_OFF + 224), 68ull, term_ctr(CID_SCON, STAT_OFF + 226), 114ull, term_ctr(CID_SCON, STAT_OFF + 170), 97ull, term_ctr(CID_SCON, STAT_OFF + 230), 108ull, term_ctr(CID_SCON, STAT_OFF + 232), 99ull, term_ctr(CID_SCON, STAT_OFF + 234), 101ull, term_ctr(CID_SCON, STAT_OFF + 236), 100ull, term_ctr(CID_SCON, STAT_OFF + 238), 110ull, term_ctr(CID_SCON, STAT_OFF + 240), 85ull, term_ctr(CID_SCON, STAT_OFF + 242), 114ull, term_ctr(CID_SCON, STAT_OFF + 102), 97ull, term_ctr(CID_SCON, STAT_OFF + 246), 98ull, term_ctr(CID_SCON, STAT_OFF + 248), 58ull, term_ctr(CID_SCON, STAT_OFF + 250), 105ull, term_ctr(CID_SCON, STAT_OFF + 68), 108ull, term_ctr(CID_SCON, STAT_OFF + 254), 97ull, term_ctr(CID_SCON, STAT_OFF + 256), 86ull, term_ctr(CID_SCON, STAT_OFF + 258), 110ull, term_ctr(CID_SCON, STAT_OFF + 68), 101ull, term_ctr(CID_SCON, STAT_OFF + 262), 59ull, term_pak(CID_SNIL, 0), 66ull, term_pak(CID_SNIL, 0), 97ull, term_pak(CID_SNIL, 0), 121ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 272), 112ull, term_ctr(CID_SCON, STAT_OFF + 274), 109ull, term_ctr(CID_SCON, STAT_OFF + 276), 101ull, term_ctr(CID_SCON, STAT_OFF + 278), 58ull, term_ctr(CID_SCON, STAT_OFF + 280), 101ull, term_ctr(CID_SCON, STAT_OFF + 282), 114ull, term_ctr(CID_SCON, STAT_OFF + 284), 97ull, term_ctr(CID_SCON, STAT_OFF + 286), 98ull, term_ctr(CID_SCON, STAT_OFF + 288), 0, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 292), term_pak(CID_NIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 272), 110ull, term_ctr(CID_SCON, STAT_OFF + 297), 111ull, term_ctr(CID_SCON, STAT_OFF + 299), 45ull, term_ctr(CID_SCON, STAT_OFF + 301), 121ull, term_ctr(CID_SCON, STAT_OFF + 303), 101ull, term_ctr(CID_SCON, STAT_OFF + 305), 107ull, term_ctr(CID_SCON, STAT_OFF + 307), 58ull, term_ctr(CID_SCON, STAT_OFF + 309), 101ull, term_ctr(CID_SCON, STAT_OFF + 311), 114ull, term_ctr(CID_SCON, STAT_OFF + 313), 97ull, term_ctr(CID_SCON, STAT_OFF + 315), 98ull, term_ctr(CID_SCON, STAT_OFF + 317), 98ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 303), 109ull, term_ctr(CID_SCON, STAT_OFF + 323), 97ull, term_ctr(CID_SCON, STAT_OFF + 325), 110ull, term_ctr(CID_SCON, STAT_OFF + 327), 58ull, term_ctr(CID_SCON, STAT_OFF + 329), 101ull, term_ctr(CID_SCON, STAT_OFF + 331), 114ull, term_ctr(CID_SCON, STAT_OFF + 333), 97ull, term_ctr(CID_SCON, STAT_OFF + 335), 98ull, term_ctr(CID_SCON, STAT_OFF + 337), 115ull, term_ctr(CID_SCON, STAT_OFF + 2), 110ull, term_ctr(CID_SCON, STAT_OFF + 341), 105ull, term_ctr(CID_SCON, STAT_OFF + 343), 119ull, term_ctr(CID_SCON, STAT_OFF + 345), 45ull, term_ctr(CID_SCON, STAT_OFF + 347), 121ull, term_ctr(CID_SCON, STAT_OFF + 349), 101ull, term_ctr(CID_SCON, STAT_OFF + 351), 107ull, term_ctr(CID_SCON, STAT_OFF + 353), 45ull, term_ctr(CID_SCON, STAT_OFF + 355), 104ull, term_ctr(CID_SCON, STAT_OFF + 357), 116ull, term_ctr(CID_SCON, STAT_OFF + 359), 111ull, term_ctr(CID_SCON, STAT_OFF + 361), 98ull, term_ctr(CID_SCON, STAT_OFF + 363), 58ull, term_ctr(CID_SCON, STAT_OFF + 365), 101ull, term_ctr(CID_SCON, STAT_OFF + 367), 114ull, term_ctr(CID_SCON, STAT_OFF + 369), 97ull, term_ctr(CID_SCON, STAT_OFF + 371), 98ull, term_ctr(CID_SCON, STAT_OFF + 373), 0, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), 0, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 377), term_pak(CID_NIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 2), 101ull, term_ctr(CID_SCON, STAT_OFF + 383), 101ull, term_ctr(CID_SCON, STAT_OFF + 385), 115ull, term_ctr(CID_SCON, STAT_OFF + 387), 45ull, term_ctr(CID_SCON, STAT_OFF + 389), 100ull, term_ctr(CID_SCON, STAT_OFF + 391), 101ull, term_ctr(CID_SCON, STAT_OFF + 393), 105ull, term_ctr(CID_SCON, STAT_OFF + 395), 102ull, term_ctr(CID_SCON, STAT_OFF + 397), 105ull, term_ctr(CID_SCON, STAT_OFF + 399), 115ull, term_ctr(CID_SCON, STAT_OFF + 401), 115ull, term_ctr(CID_SCON, STAT_OFF + 403), 97ull, term_ctr(CID_SCON, STAT_OFF + 405), 108ull, term_ctr(CID_SCON, STAT_OFF + 407), 99ull, term_ctr(CID_SCON, STAT_OFF + 409), 58ull, term_ctr(CID_SCON, STAT_OFF + 411), 101ull, term_ctr(CID_SCON, STAT_OFF + 413), 114ull, term_ctr(CID_SCON, STAT_OFF + 415), 97ull, term_ctr(CID_SCON, STAT_OFF + 417), 98ull, term_ctr(CID_SCON, STAT_OFF + 419), 109ull, term_ctr(CID_SCON, STAT_OFF + 2), 101ull, term_ctr(CID_SCON, STAT_OFF + 423), 116ull, term_ctr(CID_SCON, STAT_OFF + 425), 105ull, term_ctr(CID_SCON, STAT_OFF + 427), 45ull, term_ctr(CID_SCON, STAT_OFF + 429), 100ull, term_ctr(CID_SCON, STAT_OFF + 431), 101ull, term_ctr(CID_SCON, STAT_OFF + 433), 105ull, term_ctr(CID_SCON, STAT_OFF + 435), 102ull, term_ctr(CID_SCON, STAT_OFF + 437), 105ull, term_ctr(CID_SCON, STAT_OFF + 439), 115ull, term_ctr(CID_SCON, STAT_OFF + 441), 115ull, term_ctr(CID_SCON, STAT_OFF + 443), 97ull, term_ctr(CID_SCON, STAT_OFF + 445), 108ull, term_ctr(CID_SCON, STAT_OFF + 447), 99ull, term_ctr(CID_SCON, STAT_OFF + 449), 58ull, term_ctr(CID_SCON, STAT_OFF + 451), 101ull, term_ctr(CID_SCON, STAT_OFF + 453), 114ull, term_ctr(CID_SCON, STAT_OFF + 455), 97ull, term_ctr(CID_SCON, STAT_OFF + 457), 98ull, term_ctr(CID_SCON, STAT_OFF + 459), 0, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), 2, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 463), term_pak(CID_NIL, 0), 104ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 469), 111ull, term_ctr(CID_SCON, STAT_OFF + 471), 98ull, term_ctr(CID_SCON, STAT_OFF + 473), 45ull, term_ctr(CID_SCON, STAT_OFF + 475), 100ull, term_ctr(CID_SCON, STAT_OFF + 477), 101ull, term_ctr(CID_SCON, STAT_OFF + 479), 105ull, term_ctr(CID_SCON, STAT_OFF + 481), 102ull, term_ctr(CID_SCON, STAT_OFF + 483), 105ull, term_ctr(CID_SCON, STAT_OFF + 485), 115ull, term_ctr(CID_SCON, STAT_OFF + 487), 115ull, term_ctr(CID_SCON, STAT_OFF + 489), 97ull, term_ctr(CID_SCON, STAT_OFF + 491), 108ull, term_ctr(CID_SCON, STAT_OFF + 493), 99ull, term_ctr(CID_SCON, STAT_OFF + 495), 58ull, term_ctr(CID_SCON, STAT_OFF + 497), 101ull, term_ctr(CID_SCON, STAT_OFF + 499), 114ull, term_ctr(CID_SCON, STAT_OFF + 501), 97ull, term_ctr(CID_SCON, STAT_OFF + 503), 98ull, term_ctr(CID_SCON, STAT_OFF + 505), 1, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), 1, 120ull, term_pak(CID_SNIL, 0), 88ull, term_pak(CID_SNIL, 0), 0, term_ctr(CID_SCON, STAT_OFF + 513), term_ctr(CID_SCON, STAT_OFF + 515), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 517), term_ctr(CID_CON, STAT_OFF + 381), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 509), term_ctr(CID_CON, STAT_OFF + 520), 116ull, term_ctr(CID_SCON, STAT_OFF + 6), 97ull, term_ctr(CID_SCON, STAT_OFF + 524), 108ull, term_ctr(CID_SCON, STAT_OFF + 526), 45ull, term_ctr(CID_SCON, STAT_OFF + 528), 100ull, term_ctr(CID_SCON, STAT_OFF + 530), 101ull, term_ctr(CID_SCON, STAT_OFF + 532), 120ull, term_ctr(CID_SCON, STAT_OFF + 534), 105ull, term_ctr(CID_SCON, STAT_OFF + 536), 109ull, term_ctr(CID_SCON, STAT_OFF + 538), 58ull, term_ctr(CID_SCON, STAT_OFF + 540), 101ull, term_ctr(CID_SCON, STAT_OFF + 542), 114ull, term_ctr(CID_SCON, STAT_OFF + 544), 97ull, term_ctr(CID_SCON, STAT_OFF + 546), 98ull, term_ctr(CID_SCON, STAT_OFF + 548), 48ull, term_ctr(CID_SCON, STAT_OFF + 2), 45ull, term_ctr(CID_SCON, STAT_OFF + 552), 110ull, term_ctr(CID_SCON, STAT_OFF + 554), 105ull, term_ctr(CID_SCON, STAT_OFF + 556), 97ull, term_ctr(CID_SCON, STAT_OFF + 558), 109ull, term_ctr(CID_SCON, STAT_OFF + 560), 111ull, term_ctr(CID_SCON, STAT_OFF + 562), 100ull, term_ctr(CID_SCON, STAT_OFF + 564), 45ull, term_ctr(CID_SCON, STAT_OFF + 566), 101ull, term_ctr(CID_SCON, STAT_OFF + 568), 109ull, term_ctr(CID_SCON, STAT_OFF + 570), 97ull, term_ctr(CID_SCON, STAT_OFF + 572), 115ull, term_ctr(CID_SCON, STAT_OFF + 574), 58ull, term_ctr(CID_SCON, STAT_OFF + 576), 101ull, term_ctr(CID_SCON, STAT_OFF + 578), 114ull, term_ctr(CID_SCON, STAT_OFF + 580), 97ull, term_ctr(CID_SCON, STAT_OFF + 582), 98ull, term_ctr(CID_SCON, STAT_OFF + 584), 1, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 588), term_pak(CID_NIL, 0), 49ull, term_ctr(CID_SCON, STAT_OFF + 2), 45ull, term_ctr(CID_SCON, STAT_OFF + 593), 110ull, term_ctr(CID_SCON, STAT_OFF + 595), 105ull, term_ctr(CID_SCON, STAT_OFF + 597), 97ull, term_ctr(CID_SCON, STAT_OFF + 599), 109ull, term_ctr(CID_SCON, STAT_OFF + 601), 111ull, term_ctr(CID_SCON, STAT_OFF + 603), 100ull, term_ctr(CID_SCON, STAT_OFF + 605), 45ull, term_ctr(CID_SCON, STAT_OFF + 607), 101ull, term_ctr(CID_SCON, STAT_OFF + 609), 109ull, term_ctr(CID_SCON, STAT_OFF + 611), 97ull, term_ctr(CID_SCON, STAT_OFF + 613), 115ull, term_ctr(CID_SCON, STAT_OFF + 615), 58ull, term_ctr(CID_SCON, STAT_OFF + 617), 101ull, term_ctr(CID_SCON, STAT_OFF + 619), 114ull, term_ctr(CID_SCON, STAT_OFF + 621), 97ull, term_ctr(CID_SCON, STAT_OFF + 623), 98ull, term_ctr(CID_SCON, STAT_OFF + 625), 2, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 629), term_pak(CID_NIL, 0), 50ull, term_ctr(CID_SCON, STAT_OFF + 2), 45ull, term_ctr(CID_SCON, STAT_OFF + 634), 110ull, term_ctr(CID_SCON, STAT_OFF + 636), 105ull, term_ctr(CID_SCON, STAT_OFF + 638), 97ull, term_ctr(CID_SCON, STAT_OFF + 640), 109ull, term_ctr(CID_SCON, STAT_OFF + 642), 111ull, term_ctr(CID_SCON, STAT_OFF + 644), 100ull, term_ctr(CID_SCON, STAT_OFF + 646), 45ull, term_ctr(CID_SCON, STAT_OFF + 648), 101ull, term_ctr(CID_SCON, STAT_OFF + 650), 109ull, term_ctr(CID_SCON, STAT_OFF + 652), 97ull, term_ctr(CID_SCON, STAT_OFF + 654), 115ull, term_ctr(CID_SCON, STAT_OFF + 656), 58ull, term_ctr(CID_SCON, STAT_OFF + 658), 101ull, term_ctr(CID_SCON, STAT_OFF + 660), 114ull, term_ctr(CID_SCON, STAT_OFF + 662), 97ull, term_ctr(CID_SCON, STAT_OFF + 664), 98ull, term_ctr(CID_SCON, STAT_OFF + 666), 3, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 670), term_pak(CID_NIL, 0), 51ull, term_ctr(CID_SCON, STAT_OFF + 2), 45ull, term_ctr(CID_SCON, STAT_OFF + 675), 110ull, term_ctr(CID_SCON, STAT_OFF + 677), 105ull, term_ctr(CID_SCON, STAT_OFF + 679), 97ull, term_ctr(CID_SCON, STAT_OFF + 681), 109ull, term_ctr(CID_SCON, STAT_OFF + 683), 111ull, term_ctr(CID_SCON, STAT_OFF + 685), 100ull, term_ctr(CID_SCON, STAT_OFF + 687), 45ull, term_ctr(CID_SCON, STAT_OFF + 689), 101ull, term_ctr(CID_SCON, STAT_OFF + 691), 109ull, term_ctr(CID_SCON, STAT_OFF + 693), 97ull, term_ctr(CID_SCON, STAT_OFF + 695), 115ull, term_ctr(CID_SCON, STAT_OFF + 697), 58ull, term_ctr(CID_SCON, STAT_OFF + 699), 101ull, term_ctr(CID_SCON, STAT_OFF + 701), 114ull, term_ctr(CID_SCON, STAT_OFF + 703), 97ull, term_ctr(CID_SCON, STAT_OFF + 705), 98ull, term_ctr(CID_SCON, STAT_OFF + 707), 4, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 711), term_pak(CID_NIL, 0), 52ull, term_ctr(CID_SCON, STAT_OFF + 2), 45ull, term_ctr(CID_SCON, STAT_OFF + 716), 110ull, term_ctr(CID_SCON, STAT_OFF + 718), 105ull, term_ctr(CID_SCON, STAT_OFF + 720), 97ull, term_ctr(CID_SCON, STAT_OFF + 722), 109ull, term_ctr(CID_SCON, STAT_OFF + 724), 111ull, term_ctr(CID_SCON, STAT_OFF + 726), 100ull, term_ctr(CID_SCON, STAT_OFF + 728), 45ull, term_ctr(CID_SCON, STAT_OFF + 730), 101ull, term_ctr(CID_SCON, STAT_OFF + 732), 109ull, term_ctr(CID_SCON, STAT_OFF + 734), 97ull, term_ctr(CID_SCON, STAT_OFF + 736), 115ull, term_ctr(CID_SCON, STAT_OFF + 738), 58ull, term_ctr(CID_SCON, STAT_OFF + 740), 101ull, term_ctr(CID_SCON, STAT_OFF + 742), 114ull, term_ctr(CID_SCON, STAT_OFF + 744), 97ull, term_ctr(CID_SCON, STAT_OFF + 746), 98ull, term_ctr(CID_SCON, STAT_OFF + 748), 115ull, term_ctr(CID_SCON, STAT_OFF + 568), 115ull, term_ctr(CID_SCON, STAT_OFF + 752), 111ull, term_ctr(CID_SCON, STAT_OFF + 754), 114ull, term_ctr(CID_SCON, STAT_OFF + 756), 99ull, term_ctr(CID_SCON, STAT_OFF + 758), 58ull, term_ctr(CID_SCON, STAT_OFF + 760), 101ull, term_ctr(CID_SCON, STAT_OFF + 762), 114ull, term_ctr(CID_SCON, STAT_OFF + 764), 97ull, term_ctr(CID_SCON, STAT_OFF + 766), 98ull, term_ctr(CID_SCON, STAT_OFF + 768), 1, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), 0, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 772), term_pak(CID_NIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 609), 115ull, term_ctr(CID_SCON, STAT_OFF + 778), 111ull, term_ctr(CID_SCON, STAT_OFF + 780), 114ull, term_ctr(CID_SCON, STAT_OFF + 782), 99ull, term_ctr(CID_SCON, STAT_OFF + 784), 58ull, term_ctr(CID_SCON, STAT_OFF + 786), 101ull, term_ctr(CID_SCON, STAT_OFF + 788), 114ull, term_ctr(CID_SCON, STAT_OFF + 790), 97ull, term_ctr(CID_SCON, STAT_OFF + 792), 98ull, term_ctr(CID_SCON, STAT_OFF + 794), 2, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), 0, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 798), term_pak(CID_NIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 650), 115ull, term_ctr(CID_SCON, STAT_OFF + 804), 111ull, term_ctr(CID_SCON, STAT_OFF + 806), 114ull, term_ctr(CID_SCON, STAT_OFF + 808), 99ull, term_ctr(CID_SCON, STAT_OFF + 810), 58ull, term_ctr(CID_SCON, STAT_OFF + 812), 101ull, term_ctr(CID_SCON, STAT_OFF + 814), 114ull, term_ctr(CID_SCON, STAT_OFF + 816), 97ull, term_ctr(CID_SCON, STAT_OFF + 818), 98ull, term_ctr(CID_SCON, STAT_OFF + 820), 3, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), 0, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 824), term_pak(CID_NIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 691), 115ull, term_ctr(CID_SCON, STAT_OFF + 830), 111ull, term_ctr(CID_SCON, STAT_OFF + 832), 114ull, term_ctr(CID_SCON, STAT_OFF + 834), 99ull, term_ctr(CID_SCON, STAT_OFF + 836), 58ull, term_ctr(CID_SCON, STAT_OFF + 838), 101ull, term_ctr(CID_SCON, STAT_OFF + 840), 114ull, term_ctr(CID_SCON, STAT_OFF + 842), 97ull, term_ctr(CID_SCON, STAT_OFF + 844), 98ull, term_ctr(CID_SCON, STAT_OFF + 846), 4, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 146), 0, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 850), term_pak(CID_NIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 732), 115ull, term_ctr(CID_SCON, STAT_OFF + 856), 111ull, term_ctr(CID_SCON, STAT_OFF + 858), 114ull, term_ctr(CID_SCON, STAT_OFF + 860), 99ull, term_ctr(CID_SCON, STAT_OFF + 862), 58ull, term_ctr(CID_SCON, STAT_OFF + 864), 101ull, term_ctr(CID_SCON, STAT_OFF + 866), 114ull, term_ctr(CID_SCON, STAT_OFF + 868), 97ull, term_ctr(CID_SCON, STAT_OFF + 870), 98ull, term_ctr(CID_SCON, STAT_OFF + 872), 100ull, term_ctr(CID_SCON, STAT_OFF + 282), 101ull, term_ctr(CID_SCON, STAT_OFF + 876), 122ull, term_ctr(CID_SCON, STAT_OFF + 878), 105ull, term_ctr(CID_SCON, STAT_OFF + 880), 108ull, term_ctr(CID_SCON, STAT_OFF + 882), 97ull, term_ctr(CID_SCON, STAT_OFF + 884), 109ull, term_ctr(CID_SCON, STAT_OFF + 886), 114ull, term_ctr(CID_SCON, STAT_OFF + 888), 111ull, term_ctr(CID_SCON, STAT_OFF + 890), 110ull, term_ctr(CID_SCON, STAT_OFF + 892), 100ull, term_ctr(CID_SCON, STAT_OFF + 311), 101ull, term_ctr(CID_SCON, STAT_OFF + 896), 122ull, term_ctr(CID_SCON, STAT_OFF + 898), 105ull, term_ctr(CID_SCON, STAT_OFF + 900), 108ull, term_ctr(CID_SCON, STAT_OFF + 902), 97ull, term_ctr(CID_SCON, STAT_OFF + 904), 109ull, term_ctr(CID_SCON, STAT_OFF + 906), 114ull, term_ctr(CID_SCON, STAT_OFF + 908), 111ull, term_ctr(CID_SCON, STAT_OFF + 910), 110ull, term_ctr(CID_SCON, STAT_OFF + 912), 100ull, term_ctr(CID_SCON, STAT_OFF + 331), 101ull, term_ctr(CID_SCON, STAT_OFF + 916), 122ull, term_ctr(CID_SCON, STAT_OFF + 918), 105ull, term_ctr(CID_SCON, STAT_OFF + 920), 108ull, term_ctr(CID_SCON, STAT_OFF + 922), 97ull, term_ctr(CID_SCON, STAT_OFF + 924), 109ull, term_ctr(CID_SCON, STAT_OFF + 926), 114ull, term_ctr(CID_SCON, STAT_OFF + 928), 111ull, term_ctr(CID_SCON, STAT_OFF + 930), 110ull, term_ctr(CID_SCON, STAT_OFF + 932), 100ull, term_ctr(CID_SCON, STAT_OFF + 367), 101ull, term_ctr(CID_SCON, STAT_OFF + 936), 122ull, term_ctr(CID_SCON, STAT_OFF + 938), 105ull, term_ctr(CID_SCON, STAT_OFF + 940), 108ull, term_ctr(CID_SCON, STAT_OFF + 942), 97ull, term_ctr(CID_SCON, STAT_OFF + 944), 109ull, term_ctr(CID_SCON, STAT_OFF + 946), 114ull, term_ctr(CID_SCON, STAT_OFF + 948), 111ull, term_ctr(CID_SCON, STAT_OFF + 950), 110ull, term_ctr(CID_SCON, STAT_OFF + 952), 100ull, term_ctr(CID_SCON, STAT_OFF + 413), 101ull, term_ctr(CID_SCON, STAT_OFF + 956), 122ull, term_ctr(CID_SCON, STAT_OFF + 958), 105ull, term_ctr(CID_SCON, STAT_OFF + 960), 108ull, term_ctr(CID_SCON, STAT_OFF + 962), 97ull, term_ctr(CID_SCON, STAT_OFF + 964), 109ull, term_ctr(CID_SCON, STAT_OFF + 966), 114ull, term_ctr(CID_SCON, STAT_OFF + 968), 111ull, term_ctr(CID_SCON, STAT_OFF + 970), 110ull, term_ctr(CID_SCON, STAT_OFF + 972), 100ull, term_ctr(CID_SCON, STAT_OFF + 453), 101ull, term_ctr(CID_SCON, STAT_OFF + 976), 122ull, term_ctr(CID_SCON, STAT_OFF + 978), 105ull, term_ctr(CID_SCON, STAT_OFF + 980), 108ull, term_ctr(CID_SCON, STAT_OFF + 982), 97ull, term_ctr(CID_SCON, STAT_OFF + 984), 109ull, term_ctr(CID_SCON, STAT_OFF + 986), 114ull, term_ctr(CID_SCON, STAT_OFF + 988), 111ull, term_ctr(CID_SCON, STAT_OFF + 990), 110ull, term_ctr(CID_SCON, STAT_OFF + 992), 100ull, term_ctr(CID_SCON, STAT_OFF + 499), 101ull, term_ctr(CID_SCON, STAT_OFF + 996), 122ull, term_ctr(CID_SCON, STAT_OFF + 998), 105ull, term_ctr(CID_SCON, STAT_OFF + 1000), 108ull, term_ctr(CID_SCON, STAT_OFF + 1002), 97ull, term_ctr(CID_SCON, STAT_OFF + 1004), 109ull, term_ctr(CID_SCON, STAT_OFF + 1006), 114ull, term_ctr(CID_SCON, STAT_OFF + 1008), 111ull, term_ctr(CID_SCON, STAT_OFF + 1010), 110ull, term_ctr(CID_SCON, STAT_OFF + 1012), 100ull, term_ctr(CID_SCON, STAT_OFF + 542), 101ull, term_ctr(CID_SCON, STAT_OFF + 1016), 122ull, term_ctr(CID_SCON, STAT_OFF + 1018), 105ull, term_ctr(CID_SCON, STAT_OFF + 1020), 108ull, term_ctr(CID_SCON, STAT_OFF + 1022), 97ull, term_ctr(CID_SCON, STAT_OFF + 1024), 109ull, term_ctr(CID_SCON, STAT_OFF + 1026), 114ull, term_ctr(CID_SCON, STAT_OFF + 1028), 111ull, term_ctr(CID_SCON, STAT_OFF + 1030), 110ull, term_ctr(CID_SCON, STAT_OFF + 1032), 100ull, term_ctr(CID_SCON, STAT_OFF + 578), 101ull, term_ctr(CID_SCON, STAT_OFF + 1036), 122ull, term_ctr(CID_SCON, STAT_OFF + 1038), 105ull, term_ctr(CID_SCON, STAT_OFF + 1040), 108ull, term_ctr(CID_SCON, STAT_OFF + 1042), 97ull, term_ctr(CID_SCON, STAT_OFF + 1044), 109ull, term_ctr(CID_SCON, STAT_OFF + 1046), 114ull, term_ctr(CID_SCON, STAT_OFF + 1048), 111ull, term_ctr(CID_SCON, STAT_OFF + 1050), 110ull, term_ctr(CID_SCON, STAT_OFF + 1052), 100ull, term_ctr(CID_SCON, STAT_OFF + 619), 101ull, term_ctr(CID_SCON, STAT_OFF + 1056), 122ull, term_ctr(CID_SCON, STAT_OFF + 1058), 105ull, term_ctr(CID_SCON, STAT_OFF + 1060), 108ull, term_ctr(CID_SCON, STAT_OFF + 1062), 97ull, term_ctr(CID_SCON, STAT_OFF + 1064), 109ull, term_ctr(CID_SCON, STAT_OFF + 1066), 114ull, term_ctr(CID_SCON, STAT_OFF + 1068), 111ull, term_ctr(CID_SCON, STAT_OFF + 1070), 110ull, term_ctr(CID_SCON, STAT_OFF + 1072), 100ull, term_ctr(CID_SCON, STAT_OFF + 660), 101ull, term_ctr(CID_SCON, STAT_OFF + 1076), 122ull, term_ctr(CID_SCON, STAT_OFF + 1078), 105ull, term_ctr(CID_SCON, STAT_OFF + 1080), 108ull, term_ctr(CID_SCON, STAT_OFF + 1082), 97ull, term_ctr(CID_SCON, STAT_OFF + 1084), 109ull, term_ctr(CID_SCON, STAT_OFF + 1086), 114ull, term_ctr(CID_SCON, STAT_OFF + 1088), 111ull, term_ctr(CID_SCON, STAT_OFF + 1090), 110ull, term_ctr(CID_SCON, STAT_OFF + 1092), 100ull, term_ctr(CID_SCON, STAT_OFF + 701), 101ull, term_ctr(CID_SCON, STAT_OFF + 1096), 122ull, term_ctr(CID_SCON, STAT_OFF + 1098), 105ull, term_ctr(CID_SCON, STAT_OFF + 1100), 108ull, term_ctr(CID_SCON, STAT_OFF + 1102), 97ull, term_ctr(CID_SCON, STAT_OFF + 1104), 109ull, term_ctr(CID_SCON, STAT_OFF + 1106), 114ull, term_ctr(CID_SCON, STAT_OFF + 1108), 111ull, term_ctr(CID_SCON, STAT_OFF + 1110), 110ull, term_ctr(CID_SCON, STAT_OFF + 1112), 100ull, term_ctr(CID_SCON, STAT_OFF + 742), 101ull, term_ctr(CID_SCON, STAT_OFF + 1116), 122ull, term_ctr(CID_SCON, STAT_OFF + 1118), 105ull, term_ctr(CID_SCON, STAT_OFF + 1120), 108ull, term_ctr(CID_SCON, STAT_OFF + 1122), 97ull, term_ctr(CID_SCON, STAT_OFF + 1124), 109ull, term_ctr(CID_SCON, STAT_OFF + 1126), 114ull, term_ctr(CID_SCON, STAT_OFF + 1128), 111ull, term_ctr(CID_SCON, STAT_OFF + 1130), 110ull, term_ctr(CID_SCON, STAT_OFF + 1132), 100ull, term_ctr(CID_SCON, STAT_OFF + 762), 101ull, term_ctr(CID_SCON, STAT_OFF + 1136), 122ull, term_ctr(CID_SCON, STAT_OFF + 1138), 105ull, term_ctr(CID_SCON, STAT_OFF + 1140), 108ull, term_ctr(CID_SCON, STAT_OFF + 1142), 97ull, term_ctr(CID_SCON, STAT_OFF + 1144), 109ull, term_ctr(CID_SCON, STAT_OFF + 1146), 114ull, term_ctr(CID_SCON, STAT_OFF + 1148), 111ull, term_ctr(CID_SCON, STAT_OFF + 1150), 110ull, term_ctr(CID_SCON, STAT_OFF + 1152), 100ull, term_ctr(CID_SCON, STAT_OFF + 788), 101ull, term_ctr(CID_SCON, STAT_OFF + 1156), 122ull, term_ctr(CID_SCON, STAT_OFF + 1158), 105ull, term_ctr(CID_SCON, STAT_OFF + 1160), 108ull, term_ctr(CID_SCON, STAT_OFF + 1162), 97ull, term_ctr(CID_SCON, STAT_OFF + 1164), 109ull, term_ctr(CID_SCON, STAT_OFF + 1166), 114ull, term_ctr(CID_SCON, STAT_OFF + 1168), 111ull, term_ctr(CID_SCON, STAT_OFF + 1170), 110ull, term_ctr(CID_SCON, STAT_OFF + 1172), 100ull, term_ctr(CID_SCON, STAT_OFF + 814), 101ull, term_ctr(CID_SCON, STAT_OFF + 1176), 122ull, term_ctr(CID_SCON, STAT_OFF + 1178), 105ull, term_ctr(CID_SCON, STAT_OFF + 1180), 108ull, term_ctr(CID_SCON, STAT_OFF + 1182), 97ull, term_ctr(CID_SCON, STAT_OFF + 1184), 109ull, term_ctr(CID_SCON, STAT_OFF + 1186), 114ull, term_ctr(CID_SCON, STAT_OFF + 1188), 111ull, term_ctr(CID_SCON, STAT_OFF + 1190), 110ull, term_ctr(CID_SCON, STAT_OFF + 1192), 100ull, term_ctr(CID_SCON, STAT_OFF + 840), 101ull, term_ctr(CID_SCON, STAT_OFF + 1196), 122ull, term_ctr(CID_SCON, STAT_OFF + 1198), 105ull, term_ctr(CID_SCON, STAT_OFF + 1200), 108ull, term_ctr(CID_SCON, STAT_OFF + 1202), 97ull, term_ctr(CID_SCON, STAT_OFF + 1204), 109ull, term_ctr(CID_SCON, STAT_OFF + 1206), 114ull, term_ctr(CID_SCON, STAT_OFF + 1208), 111ull, term_ctr(CID_SCON, STAT_OFF + 1210), 110ull, term_ctr(CID_SCON, STAT_OFF + 1212), 100ull, term_ctr(CID_SCON, STAT_OFF + 866), 101ull, term_ctr(CID_SCON, STAT_OFF + 1216), 122ull, term_ctr(CID_SCON, STAT_OFF + 1218), 105ull, term_ctr(CID_SCON, STAT_OFF + 1220), 108ull, term_ctr(CID_SCON, STAT_OFF + 1222), 97ull, term_ctr(CID_SCON, STAT_OFF + 1224), 109ull, term_ctr(CID_SCON, STAT_OFF + 1226), 114ull, term_ctr(CID_SCON, STAT_OFF + 1228), 111ull, term_ctr(CID_SCON, STAT_OFF + 1230), 110ull, term_ctr(CID_SCON, STAT_OFF + 1232), 100ull, term_ctr(CID_SCON, STAT_OFF + 6), 114ull, term_ctr(CID_SCON, STAT_OFF + 1236), 111ull, term_ctr(CID_SCON, STAT_OFF + 1238), 45ull, term_ctr(CID_SCON, STAT_OFF + 1240), 121ull, term_ctr(CID_SCON, STAT_OFF + 1242), 116ull, term_ctr(CID_SCON, STAT_OFF + 1244), 112ull, term_ctr(CID_SCON, STAT_OFF + 1246), 109ull, term_ctr(CID_SCON, STAT_OFF + 1248), 101ull, term_ctr(CID_SCON, STAT_OFF + 1250), 58ull, term_ctr(CID_SCON, STAT_OFF + 1252), 101ull, term_ctr(CID_SCON, STAT_OFF + 1254), 116ull, term_ctr(CID_SCON, STAT_OFF + 1256), 97ull, term_ctr(CID_SCON, STAT_OFF + 1258), 100ull, term_ctr(CID_SCON, STAT_OFF + 1260), 105ull, term_ctr(CID_SCON, STAT_OFF + 1262), 108ull, term_ctr(CID_SCON, STAT_OFF + 1264), 97ull, term_ctr(CID_SCON, STAT_OFF + 1266), 118ull, term_ctr(CID_SCON, STAT_OFF + 1268), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 509), term_pak(CID_NIL, 0), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 377), term_ctr(CID_CON, STAT_OFF + 1272), 100ull, term_ctr(CID_SCON, STAT_OFF + 1242), 101ull, term_ctr(CID_SCON, STAT_OFF + 1276), 120ull, term_ctr(CID_SCON, STAT_OFF + 1278), 105ull, term_ctr(CID_SCON, STAT_OFF + 1280), 109ull, term_ctr(CID_SCON, STAT_OFF + 1282), 58ull, term_ctr(CID_SCON, STAT_OFF + 1284), 101ull, term_ctr(CID_SCON, STAT_OFF + 1286), 116ull, term_ctr(CID_SCON, STAT_OFF + 1288), 97ull, term_ctr(CID_SCON, STAT_OFF + 1290), 100ull, term_ctr(CID_SCON, STAT_OFF + 1292), 105ull, term_ctr(CID_SCON, STAT_OFF + 1294), 108ull, term_ctr(CID_SCON, STAT_OFF + 1296), 97ull, term_ctr(CID_SCON, STAT_OFF + 1298), 118ull, term_ctr(CID_SCON, STAT_OFF + 1300), 0, term_ctr(CID_SCON, STAT_OFF + 321), term_ctr(CID_SCON, STAT_OFF + 268), 0, 99ull, term_pak(CID_SNIL, 0), 0, term_ctr(CID_SCON, STAT_OFF + 1308), term_ctr(CID_SCON, STAT_OFF + 268), 1, 67ull, term_pak(CID_SNIL, 0), 0, term_ctr(CID_SCON, STAT_OFF + 270), term_ctr(CID_SCON, STAT_OFF + 1314), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 1316), term_pak(CID_NIL, 0), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 1310), term_ctr(CID_CON, STAT_OFF + 1319), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 1304), term_ctr(CID_CON, STAT_OFF + 1321), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 292), term_ctr(CID_CON, STAT_OFF + 1323), 101ull, term_ctr(CID_SCON, STAT_OFF + 272), 107ull, term_ctr(CID_SCON, STAT_OFF + 1327), 45ull, term_ctr(CID_SCON, STAT_OFF + 1329), 114ull, term_ctr(CID_SCON, STAT_OFF + 1331), 101ull, term_ctr(CID_SCON, STAT_OFF + 1333), 116ull, term_ctr(CID_SCON, STAT_OFF + 1335), 97ull, term_ctr(CID_SCON, STAT_OFF + 1337), 108ull, term_ctr(CID_SCON, STAT_OFF + 1339), 45ull, term_ctr(CID_SCON, STAT_OFF + 1341), 101ull, term_ctr(CID_SCON, STAT_OFF + 1343), 114ull, term_ctr(CID_SCON, STAT_OFF + 1345), 111ull, term_ctr(CID_SCON, STAT_OFF + 1347), 102ull, term_ctr(CID_SCON, STAT_OFF + 1349), 101ull, term_ctr(CID_SCON, STAT_OFF + 1351), 98ull, term_ctr(CID_SCON, STAT_OFF + 1353), 45ull, term_ctr(CID_SCON, STAT_OFF + 1355), 101ull, term_ctr(CID_SCON, STAT_OFF + 1357), 109ull, term_ctr(CID_SCON, STAT_OFF + 1359), 97ull, term_ctr(CID_SCON, STAT_OFF + 1361), 110ull, term_ctr(CID_SCON, STAT_OFF + 1363), 58ull, term_ctr(CID_SCON, STAT_OFF + 1365), 101ull, term_ctr(CID_SCON, STAT_OFF + 1367), 116ull, term_ctr(CID_SCON, STAT_OFF + 1369), 97ull, term_ctr(CID_SCON, STAT_OFF + 1371), 100ull, term_ctr(CID_SCON, STAT_OFF + 1373), 105ull, term_ctr(CID_SCON, STAT_OFF + 1375), 108ull, term_ctr(CID_SCON, STAT_OFF + 1377), 97ull, term_ctr(CID_SCON, STAT_OFF + 1379), 118ull, term_ctr(CID_SCON, STAT_OFF + 1381), 114ull, term_pak(CID_SNIL, 0), 82ull, term_pak(CID_SNIL, 0), 1, term_ctr(CID_SCON, STAT_OFF + 1385), term_ctr(CID_SCON, STAT_OFF + 1387), 83ull, term_pak(CID_SNIL, 0), 1, term_ctr(CID_SCON, STAT_OFF + 1385), term_ctr(CID_SCON, STAT_OFF + 1392), 0, 0, term_ctr(CID_SCON, STAT_OFF + 321), term_ctr(CID_SCON, STAT_OFF + 146), 1, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 1398), term_pak(CID_NIL, 0), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 377), term_ctr(CID_CON, STAT_OFF + 1402), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 1394), term_ctr(CID_CON, STAT_OFF + 1404), term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, STAT_OFF + 1389), term_ctr(CID_CON, STAT_OFF + 1406), 101ull, term_ctr(CID_SCON, STAT_OFF + 2), 99ull, term_ctr(CID_SCON, STAT_OFF + 1410), 114ull, term_ctr(CID_SCON, STAT_OFF + 1412), 117ull, term_ctr(CID_SCON, STAT_OFF + 1414), 111ull, term_ctr(CID_SCON, STAT_OFF + 1416), 115ull, term_ctr(CID_SCON, STAT_OFF + 1418), 101ull, term_ctr(CID_SCON, STAT_OFF + 1420), 114ull, term_ctr(CID_SCON, STAT_OFF + 1422), 45ull, term_ctr(CID_SCON, STAT_OFF + 1424), 101ull, term_ctr(CID_SCON, STAT_OFF + 1426), 114ull, term_ctr(CID_SCON, STAT_OFF + 1428), 111ull, term_ctr(CID_SCON, STAT_OFF + 1430), 102ull, term_ctr(CID_SCON, STAT_OFF + 1432), 101ull, term_ctr(CID_SCON, STAT_OFF + 1434), 98ull, term_ctr(CID_SCON, STAT_OFF + 1436), 45ull, term_ctr(CID_SCON, STAT_OFF + 1438), 116ull, term_ctr(CID_SCON, STAT_OFF + 1440), 110ull, term_ctr(CID_SCON, STAT_OFF + 1442), 101ull, term_ctr(CID_SCON, STAT_OFF + 1444), 110ull, term_ctr(CID_SCON, STAT_OFF + 1446), 111ull, term_ctr(CID_SCON, STAT_OFF + 1448), 112ull, term_ctr(CID_SCON, STAT_OFF + 1450), 109ull, term_ctr(CID_SCON, STAT_OFF + 1452), 111ull, term_ctr(CID_SCON, STAT_OFF + 1454), 99ull, term_ctr(CID_SCON, STAT_OFF + 1456), 58ull, term_ctr(CID_SCON, STAT_OFF + 1458), 101ull, term_ctr(CID_SCON, STAT_OFF + 1460), 116ull, term_ctr(CID_SCON, STAT_OFF + 1462), 97ull, term_ctr(CID_SCON, STAT_OFF + 1464), 100ull, term_ctr(CID_SCON, STAT_OFF + 1466), 105ull, term_ctr(CID_SCON, STAT_OFF + 1468), 108ull, term_ctr(CID_SCON, STAT_OFF + 1470), 97ull, term_ctr(CID_SCON, STAT_OFF + 1472), 118ull, term_ctr(CID_SCON, STAT_OFF + 1474), 115ull, term_pak(CID_SNIL, 0), 4, term_ctr(CID_SCON, STAT_OFF + 1478), term_ctr(CID_SCON, STAT_OFF + 1392), 2, 69ull, term_pak(CID_SNIL, 0), 2, term_ctr(CID_SCON, STAT_OFF + 102), term_ctr(CID_SCON, STAT_OFF + 1484), 1, 3, term_ctr(CID_SCON, STAT_OFF + 1385), term_ctr(CID_SCON, STAT_OFF + 1387), 0, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 1490), term_pak(CID_NIL, 0), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 1486), term_ctr(CID_CON, STAT_OFF + 1494), term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, STAT_OFF + 1480), term_ctr(CID_CON, STAT_OFF + 1496), 111ull, term_ctr(CID_SCON, STAT_OFF + 383), 105ull, term_ctr(CID_SCON, STAT_OFF + 1500), 116ull, term_ctr(CID_SCON, STAT_OFF + 1502), 97ull, term_ctr(CID_SCON, STAT_OFF + 1504), 99ull, term_ctr(CID_SCON, STAT_OFF + 1506), 105ull, term_ctr(CID_SCON, STAT_OFF + 1508), 102ull, term_ctr(CID_SCON, STAT_OFF + 1510), 105ull, term_ctr(CID_SCON, STAT_OFF + 1512), 115ull, term_ctr(CID_SCON, STAT_OFF + 1514), 115ull, term_ctr(CID_SCON, STAT_OFF + 1516), 97ull, term_ctr(CID_SCON, STAT_OFF + 1518), 108ull, term_ctr(CID_SCON, STAT_OFF + 1520), 99ull, term_ctr(CID_SCON, STAT_OFF + 1522), 45ull, term_ctr(CID_SCON, STAT_OFF + 1524), 100ull, term_ctr(CID_SCON, STAT_OFF + 1526), 101ull, term_ctr(CID_SCON, STAT_OFF + 1528), 110ull, term_ctr(CID_SCON, STAT_OFF + 1530), 105ull, term_ctr(CID_SCON, STAT_OFF + 1532), 97ull, term_ctr(CID_SCON, STAT_OFF + 1534), 116ull, term_ctr(CID_SCON, STAT_OFF + 1536), 101ull, term_ctr(CID_SCON, STAT_OFF + 1538), 114ull, term_ctr(CID_SCON, STAT_OFF + 1540), 58ull, term_ctr(CID_SCON, STAT_OFF + 1542), 101ull, term_ctr(CID_SCON, STAT_OFF + 1544), 116ull, term_ctr(CID_SCON, STAT_OFF + 1546), 97ull, term_ctr(CID_SCON, STAT_OFF + 1548), 100ull, term_ctr(CID_SCON, STAT_OFF + 1550), 105ull, term_ctr(CID_SCON, STAT_OFF + 1552), 108ull, term_ctr(CID_SCON, STAT_OFF + 1554), 97ull, term_ctr(CID_SCON, STAT_OFF + 1556), 118ull, term_ctr(CID_SCON, STAT_OFF + 1558), 108ull, term_ctr(CID_SCON, STAT_OFF + 2), 108ull, term_ctr(CID_SCON, STAT_OFF + 1562), 97ull, term_ctr(CID_SCON, STAT_OFF + 1564), 110ull, term_ctr(CID_SCON, STAT_OFF + 148), 101ull, term_ctr(CID_SCON, STAT_OFF + 1568), 110ull, term_ctr(CID_SCON, STAT_OFF + 1570), 111ull, term_ctr(CID_SCON, STAT_OFF + 1572), 112ull, term_ctr(CID_SCON, STAT_OFF + 1574), 109ull, term_ctr(CID_SCON, STAT_OFF + 1576), 111ull, term_ctr(CID_SCON, STAT_OFF + 1578), 99ull, term_ctr(CID_SCON, STAT_OFF + 1580), 100ull, term_ctr(CID_SCON, STAT_OFF + 2), 105ull, term_ctr(CID_SCON, STAT_OFF + 1584), 108ull, term_ctr(CID_SCON, STAT_OFF + 1586), 97ull, term_ctr(CID_SCON, STAT_OFF + 1588), 118ull, term_ctr(CID_SCON, STAT_OFF + 1590), 116ull, term_ctr(CID_SCON, STAT_OFF + 1410), 97ull, term_ctr(CID_SCON, STAT_OFF + 1594), 99ull, term_ctr(CID_SCON, STAT_OFF + 1596), 105ull, term_ctr(CID_SCON, STAT_OFF + 1598), 108ull, term_ctr(CID_SCON, STAT_OFF + 1600), 112ull, term_ctr(CID_SCON, STAT_OFF + 1602), 117ull, term_ctr(CID_SCON, STAT_OFF + 1604), 100ull, term_ctr(CID_SCON, STAT_OFF + 1606), 114ull, term_ctr(CID_SCON, STAT_OFF + 1410), 97ull, term_ctr(CID_SCON, STAT_OFF + 1610), 98ull, term_ctr(CID_SCON, STAT_OFF + 1612), 45ull, term_ctr(CID_SCON, STAT_OFF + 1614), 100ull, term_ctr(CID_SCON, STAT_OFF + 1616), 101ull, term_ctr(CID_SCON, STAT_OFF + 1618), 114ull, term_ctr(CID_SCON, STAT_OFF + 1620), 105ull, term_ctr(CID_SCON, STAT_OFF + 1622), 117ull, term_ctr(CID_SCON, STAT_OFF + 1624), 113ull, term_ctr(CID_SCON, STAT_OFF + 1626), 101ull, term_ctr(CID_SCON, STAT_OFF + 1628), 114ull, term_ctr(CID_SCON, STAT_OFF + 1630), 101ull, term_ctr(CID_SCON, STAT_OFF + 1584), 105ull, term_ctr(CID_SCON, STAT_OFF + 1634), 102ull, term_ctr(CID_SCON, STAT_OFF + 1636), 105ull, term_ctr(CID_SCON, STAT_OFF + 1638), 115ull, term_ctr(CID_SCON, STAT_OFF + 1640), 115ull, term_ctr(CID_SCON, STAT_OFF + 1642), 97ull, term_ctr(CID_SCON, STAT_OFF + 1644), 108ull, term_ctr(CID_SCON, STAT_OFF + 1646), 99ull, term_ctr(CID_SCON, STAT_OFF + 1648), 45ull, term_ctr(CID_SCON, STAT_OFF + 1650), 100ull, term_ctr(CID_SCON, STAT_OFF + 1652), 101ull, term_ctr(CID_SCON, STAT_OFF + 1654), 114ull, term_ctr(CID_SCON, STAT_OFF + 1656), 105ull, term_ctr(CID_SCON, STAT_OFF + 1658), 117ull, term_ctr(CID_SCON, STAT_OFF + 1660), 113ull, term_ctr(CID_SCON, STAT_OFF + 1662), 101ull, term_ctr(CID_SCON, STAT_OFF + 1664), 114ull, term_ctr(CID_SCON, STAT_OFF + 1666) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, u32 r1, Term r2, Term r3, u32 r4) {
  u32 wpoll = 0;
  Term _v_3 = 0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  u32 _h1b_0 = r0;
  u32 _h2b_0 = r1;
  Term _rr_0 = r2;
  Term _rr_1 = r3;
  u32 _rr_2 = r4;
  WL_SPIN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h1b_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _rr_0);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h2b_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _rr_1);
    _v_3 = term_ctr(CID_SCON, _nd_2);
    _v_4 = term_ctr(CID_SCON, _nd_3);
    _v_5 = _rr_2;
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    _v_6 = _a_1;
    _v_7 = _b_1;
    _v_8 = (U32_BIN(_a_1, >, _b_1) + U32_BIN(_a_1, >=, _b_1));
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _p_0 = r0;
  Term _p_1 = r1;
  WL_SPIN
    term_sink(e, _p_0);
    _v_1 = _p_1;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_1 = 0;
  u32 _c_0 = r0;
  WL_SPIN
    if (_c_0 == 1) {
      _v_1 = 1;
    } else {
      _v_1 = 0;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _a_8 = r0;
  u32 _b_8 = r1;
  WL_SPIN
    if (_a_8 == 0) {
      if (_b_8 == 0) {
        _v_2 = 1;
      } else {
        _v_2 = 0;
      }
    } else if (_a_8 == 1) {
      if (_b_8 == 1) {
        _v_2 = 1;
      } else {
        _v_2 = 0;
      }
    } else if (_a_8 == 2) {
      if (_b_8 == 2) {
        _v_2 = 1;
      } else {
        _v_2 = 0;
      }
    } else if (_a_8 == 3) {
      if (_b_8 == 3) {
        _v_2 = 1;
      } else {
        _v_2 = 0;
      }
    } else {
      if (_b_8 == 4) {
        _v_2 = 1;
      } else {
        _v_2 = 0;
      }
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_5 = 0;
  u32 _a_9 = r0;
  u32 _b_9 = r1;
  WL_SPIN
    if (_a_9 == 0) {
      _v_5 = 0;
    } else {
      _v_5 = _b_9;
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, u32 r0, u32 r1, Term r2, Term r3, u32 r4) {
  u32 wpoll = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  u32 _value_0 = r0;
  u32 _value_1 = r1;
  Term _value_2 = r2;
  Term _value_3 = r3;
  u32 _value_4 = r4;
  WL_SPIN
    if (_value_0 == 0) {
      _v_10 = 0;
      _v_11 = _value_1;
      _v_12 = _value_2;
      _v_13 = _value_3;
      _v_14 = 0;
    } else {
      _v_10 = 0;
      _v_11 = _value_1;
      _v_12 = _value_2;
      _v_13 = _value_3;
      _v_14 = 0;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, Term r4, u32 r5) {
  u32 wpoll = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _present_1 = r0;
  u32 _item_5 = r1;
  u32 _item_6 = r2;
  Term _item_7 = r3;
  Term _item_8 = r4;
  u32 _item_9 = r5;
  WL_SPIN
    if (_present_1 == 1) {
      term_sink(e, _item_7);
      term_sink(e, _item_8);
      _v_15 = 0;
      _v_16 = 0;
      _v_17 = 0;
      _v_18 = 0;
      _v_19 = 0;
    } else {
      if (_item_5 == 0) {
        _v_15 = 1;
        _v_16 = 2;
        _v_17 = _item_6;
        _v_18 = _item_7;
        _v_19 = _item_8;
      } else {
        _v_15 = 1;
        _v_16 = 2;
        _v_17 = _item_6;
        _v_18 = _item_7;
        _v_19 = _item_8;
      }
    }
  break;
  }
  o[0] = _v_15;
  o[1] = _v_16;
  o[2] = _v_17;
  o[3] = _v_18;
  o[4] = _v_19;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _value_5 = r0;
  WL_SPIN
    if (_value_5 == 0) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 100);
    } else if (_value_5 == 1) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 116);
    } else if (_value_5 == 2) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 120);
    } else if (_value_5 == 3) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 134);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 144);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_4 = 0;
  u32 _value_11 = r0;
  WL_SPIN
    if (_value_11 == 0) {
      _v_4 = term_ctr(CID_SCON, STAT_OFF + 48);
    } else if (_value_11 == 1) {
      _v_4 = term_ctr(CID_SCON, STAT_OFF + 66);
    } else {
      _v_4 = term_ctr(CID_SCON, STAT_OFF + 88);
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  Term _declaration_1 = r0;
  WL_SPIN
    _v_2 = _declaration_1;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, Term r4) {
  u32 wpoll = 0;
  u32 _v_5 = 0;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  u32 _keyConflict_0 = r0;
  u32 _nameConflict_0 = r1;
  u32 _kind_0 = r2;
  Term _key_0 = r3;
  Term _name_0 = r4;
  WL_SPIN
    if (_keyConflict_0 == 1) {
      term_sink(e, _name_0);
      _v_5 = 1;
      _v_6 = 0;
      _v_7 = _kind_0;
      _v_8 = _key_0;
      _v_9 = 0;
    } else {
      if (_nameConflict_0 == 1) {
        term_sink(e, _key_0);
        _v_5 = 1;
        _v_6 = 1;
        _v_7 = _kind_0;
        _v_8 = _name_0;
        _v_9 = 0;
      } else {
        term_sink(e, _key_0);
        term_sink(e, _name_0);
        _v_5 = 0;
        _v_6 = 0;
        _v_7 = 0;
        _v_8 = 0;
        _v_9 = 0;
      }
    }
  break;
  }
  o[0] = _v_5;
  o[1] = _v_6;
  o[2] = _v_7;
  o[3] = _v_8;
  o[4] = _v_9;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, Term r4, u32 r5, u32 r6, u32 r7, Term r8, Term r9) {
  u32 wpoll = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _first_0 = r0;
  u32 _first_1 = r1;
  u32 _first_2 = r2;
  Term _first_3 = r3;
  Term _first_4 = r4;
  u32 _second_0 = r5;
  u32 _second_1 = r6;
  u32 _second_2 = r7;
  Term _second_3 = r8;
  Term _second_4 = r9;
  WL_SPIN
    if (_first_0 == 1) {
      term_sink(e, _second_3);
      term_sink(e, _second_4);
      _v_15 = 1;
      _v_16 = _first_1;
      _v_17 = _first_2;
      _v_18 = _first_3;
      _v_19 = _first_4;
    } else {
      _v_15 = _second_0;
      _v_16 = _second_1;
      _v_17 = _second_2;
      _v_18 = _second_3;
      _v_19 = _second_4;
    }
  break;
  }
  o[0] = _v_15;
  o[1] = _v_16;
  o[2] = _v_17;
  o[3] = _v_18;
  o[4] = _v_19;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, Term r4, Term r5, Term r6, Term r7, Term r8, Term r9) {
  u32 wpoll = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  Term _entries_0 = r5;
  Term _left_12 = r6;
  Term _left_13 = r7;
  Term _right_12 = r8;
  Term _right_13 = r9;
  WL_SPIN
    if (_result_0 == 1) {
      term_sink(e, _entries_0);
      _v_34 = 1;
      _v_35 = _result_1;
      _v_36 = _result_2;
      _v_37 = _result_3;
      _v_38 = _result_4;
      _v_39 = _left_12;
      _v_40 = _left_13;
      _v_41 = _right_12;
      _v_42 = _right_13;
    } else {
      term_sink(e, _left_12);
      term_sink(e, _right_12);
      _v_34 = 0;
      _v_35 = _entries_0;
      _v_36 = _left_13;
      _v_37 = _right_13;
      _v_38 = 0;
      _v_39 = 0;
      _v_40 = 0;
      _v_41 = 0;
      _v_42 = 0;
    }
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  o[7] = _v_41;
  o[8] = _v_42;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, Term r4, u32 r5) {
  u32 wpoll = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  u32 _present_0 = r0;
  u32 _item_0 = r1;
  u32 _item_1 = r2;
  Term _item_2 = r3;
  Term _item_3 = r4;
  u32 _item_4 = r5;
  WL_SPIN
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    u32 _v_24 = 0;
    Term _o_10[5];
    if (spin_7(e, _o_10, _item_0, _item_1, _item_2, _item_3, _item_4) == 0) {
      return 0;
    }
    _v_20 = _o_10[0];
    _v_21 = _o_10[1];
    _v_22 = _o_10[2];
    _v_23 = _o_10[3];
    _v_24 = _o_10[4];
    _v_15 = _v_20;
    _v_16 = _v_21;
    _v_17 = _v_22;
    _v_18 = _v_23;
    _v_19 = _v_24;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _o_11[5];
    if (spin_8(e, _o_11, _present_0, _v_15, _v_16, _v_17, _v_18, _v_19) == 0) {
      return 0;
    }
    _v_25 = _o_11[0];
    _v_26 = _o_11[1];
    _v_27 = _o_11[2];
    _v_28 = _o_11[3];
    _v_29 = _o_11[4];
    _v_10 = _v_25;
    _v_11 = _v_26;
    _v_12 = _v_27;
    _v_13 = _v_28;
    _v_14 = _v_29;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, Term r4, u32 r5, Term r6) {
  u32 wpoll = 0;
  Term _v_3 = 0;
  u32 _selected_0 = r0;
  u32 _item_0 = r1;
  u32 _item_1 = r2;
  Term _item_2 = r3;
  Term _item_3 = r4;
  u32 _item_4 = r5;
  Term _rest_0 = r6;
  WL_SPIN
    if (_selected_0 == 1) {
      Term _b_0 = 0;
      if (_item_0 == 0) {
        u64 _nd_0 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_0 + 0] = rfc_seal(e, _item_1);
        e.mem[_nd_0 + 1] = rfc_seal(e, _item_2);
        e.mem[_nd_0 + 2] = rfc_seal(e, _item_3);
        _b_0 = term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, _nd_0);
      } else {
        u64 _nd_1 = heap_alloc(e, cls_fit(4));
        e.mem[_nd_1 + 0] = rfc_seal(e, _item_1);
        e.mem[_nd_1 + 1] = rfc_seal(e, _item_2);
        e.mem[_nd_1 + 2] = rfc_seal(e, _item_3);
        e.mem[_nd_1 + 3] = rfc_seal(e, _item_4);
        _b_0 = term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_1);
      }
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_2 + 1] = rfc_seal(e, _rest_0);
      _v_3 = term_ctr(CID_CON, _nd_2);
    } else {
      term_sink(e, _item_2);
      term_sink(e, _item_3);
      _v_3 = _rest_0;
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  Term _value_0 = r0;
  WL_SPIN
    _v_1 = _value_0;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _v_3 = 0;
  Term _value_0 = r0;
  WL_SPIN
    _v_3 = _value_0;
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, u32 r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term r6, Term r7, Term r8, Term r9) {
  u32 wpoll = 0;
  Term _v_38 = 0;
  u32 _result_0 = r0;
  Term _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  Term _result_9 = r9;
  WL_SPIN
    term_sink(e, _result_1);
    term_sink(e, _result_2);
    term_sink(e, _result_3);
    term_sink(e, _result_4);
    term_sink(e, _result_5);
    term_sink(e, _result_6);
    term_sink(e, _result_7);
    term_sink(e, _result_8);
    _v_38 = _result_9;
  break;
  }
  o[0] = _v_38;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_CMP)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      if (term_aux(_b_0) == CID_SNIL) {
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 1;
        WL_RETN(3);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _b_0, 2, _fb_0);
        u32 _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
        e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_ctr(CID_SCON, _nd_0);
        r2 = 0;
        WL_RETN(3);
      }
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _a_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      if (term_aux(_b_0) == CID_SNIL) {
        u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
        e.mem[_nd_1 + 1] = rfc_seal(e, _f_3);
        r0 = term_ctr(CID_SCON, _nd_1);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 2;
        WL_RETN(3);
      } else {
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _b_0, 2, _fb_2);
        u32 _f_4 = _fb_2[0];
        Term _f_5 = _fb_2[1];
        u32 _v_0 = 0;
        u32 _v_1 = 0;
        u32 _v_2 = 0;
        u32 _v_3 = 0;
        u32 _v_4 = 0;
        u32 _v_5 = 0;
        Term _o_0[3];
        if (spin_1(e, _o_0, _f_2, _f_4) == 0) {
          return 0;
        }
        _v_3 = _o_0[0];
        _v_4 = _o_0[1];
        _v_5 = _o_0[2];
        _v_0 = _v_3;
        _v_1 = _v_4;
        _v_2 = _v_5;
        if (_v_2 == 0) {
          u64 _nd_2 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_2 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_2 + 1] = rfc_seal(e, _f_3);
          u64 _nd_3 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_3 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_2);
          r1 = term_ctr(CID_SCON, _nd_3);
          r2 = 0;
          WL_RETN(3);
        } else if (_v_2 == 1) {
          spare_free(e, cls_fit(2), _sp_2);
          spare_free(e, cls_fit(2), _sp_1);
          if (seq) {
            WL_ROOM(3);
            STK(0) = _v_0;
            STK(1) = _v_1;
            STK(2) = FID_STRING_CMP_K7;
            WL_PUSHN(3);
          } else {
            u64 _t_0 = task_node(e, FID_STRING_CMP_K7, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _v_0;
            e.mem[_t_0 + 1] = _v_1;
            WL_CONT = term_tsk(FID_STRING_CMP_K7, _t_0);
            WL_IDX = 2;
          }
          r0 = _f_3;
          r1 = _f_5;
          _a_0 = r0;
          _b_0 = r1;
          WL_AGAIN(FID_STRING_CMP);
        } else {
          u64 _nd_4 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_4 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_4 + 1] = rfc_seal(e, _f_3);
          u64 _nd_5 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_5 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_5 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_4);
          r1 = term_ctr(CID_SCON, _nd_5);
          r2 = 2;
          WL_RETN(3);
        }
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_CMP_K7)
  {
    WL_POPN(2);
    u32 _v_9 = STK(0);
    u32 _v_10 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    Term _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _o_1[3];
    if (spin_0(e, _o_1, _v_9, _v_10, _h_0, _h_1, _h_2) == 0) {
      return 0;
    }
    _v_11 = _o_1[0];
    _v_12 = _o_1[1];
    _v_13 = _o_1[2];
    r0 = _v_11;
    r1 = _v_12;
    r2 = _v_13;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_ORDER_K11;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_ORDER_K11, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_ORDER_K11, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_CMP)) {
      u64 _t_1 = task_node(e, FID_STRING_CMP, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_CMP, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_CMP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER_K11)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_0;
    e.mem[_nd_0 + 1] = _h_1;
    Term _b_1 = 0;
    if (_h_2 == 0) {
      _b_1 = term_pak(CID_LT, 0);
    } else if (_h_2 == 1) {
      _b_1 = term_pak(CID_EQ, 0);
    } else {
      _b_1 = term_pak(CID_GT, 0);
    }
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_2(e, _o_0, term_ctr(CID_TUPLE, _nd_0), _b_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    u32 _o_1 = 0;
    if (term_aux(_v_0) == CID_LT) {
      _o_1 = 0;
    } else if (term_aux(_v_0) == CID_EQ) {
      _o_1 = 1;
    } else {
      _o_1 = 2;
    }
    r0 = _o_1;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 0);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_EQ_K15;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_EQ_K15, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_EQ_K15, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_ORDER)) {
      u64 _t_1 = task_node(e, FID_STRING_ORDER, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_ORDER, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_ORDER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ_K15)
  {
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _o_0[1];
    if (spin_3(e, _o_0, _h_0) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32)
  {
    u32 _value_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_0;
      STK(1) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32_K27;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32_K27, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_0;
      WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32_K27, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32_K27)
  {
    WL_POPN(1);
    u32 _value_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    r0 = _value_1;
    r1 = _h_0;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0)
  {
    u32 _a_0 = r0;
    u32 _a_1 = r1;
    Term _a_2 = r2;
    Term _a_3 = r3;
    u32 _a_4 = r4;
    u32 _b_0 = r5;
    u32 _b_1 = r6;
    Term _b_2 = r7;
    Term _b_3 = r8;
    u32 _b_4 = r9;
    WL_OPEN
    if (_a_0 == 0) {
      if (_b_0 == 0) {
        if (seq) {
          WL_ROOM(5);
          STK(0) = _a_1;
          STK(1) = _a_3;
          STK(2) = _b_1;
          STK(3) = _b_3;
          STK(4) = FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K31;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K31, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _a_1;
          e.mem[_t_0 + 1] = _a_3;
          e.mem[_t_0 + 2] = _b_1;
          e.mem[_t_0 + 3] = _b_3;
          WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K31, _t_0);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
          u64 _t_1 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _a_2;
          e.mem[_t_1 + 1] = _b_2;
          return term_tsk(FID_STRING_EQ, _t_1);
        }
        r0 = _a_2;
        r1 = _b_2;
        WL_JMP(FID_STRING_EQ);
      } else {
        term_sink(e, _a_2);
        term_sink(e, _a_3);
        term_sink(e, _b_2);
        term_sink(e, _b_3);
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      term_sink(e, _a_2);
      term_sink(e, _a_3);
      term_sink(e, _b_2);
      term_sink(e, _b_3);
      r0 = 0;
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K31)
  {
    WL_POPN(4);
    u32 _a_5 = STK(0);
    Term _a_6 = STK(1);
    u32 _b_5 = STK(2);
    Term _b_6 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _a_5;
      STK(1) = _b_5;
      STK(2) = _h_0;
      STK(3) = FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K32;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K32, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _a_5;
      e.mem[_t_2 + 1] = _b_5;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K32, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_3 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _a_6;
      e.mem[_t_3 + 1] = _b_6;
      return term_tsk(FID_STRING_EQ, _t_3);
    }
    r0 = _a_6;
    r1 = _b_6;
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0_K32)
  {
    WL_POPN(3);
    u32 _a_7 = STK(0);
    u32 _b_7 = STK(1);
    u32 _h_2 = STK(2);
    u32 _h_1 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_4(e, _o_0, _a_7, _b_7) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    Term _o_1[1];
    if (spin_5(e, _o_1, _h_2, _h_1) == 0) {
      return 0;
    }
    _v_4 = _o_1[0];
    _v_3 = _v_4;
    u32 _v_6 = 0;
    Term _o_2[1];
    if (spin_5(e, _o_2, _v_0, _v_3) == 0) {
      return 0;
    }
    _v_6 = _o_2[0];
    r0 = _v_6;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0)
  {
    Term _xs_0 = r0;
    u32 _kind_0 = r1;
    Term _name_0 = r2;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      term_sink(e, _name_0);
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      if (term_aux(_f_0) == CID_SCHEMA_FRAGMENTS_ENTRY) {
        _o_0 = 0;
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
        _o_3 = _f_4;
      } else {
        _o_0 = 1;
        Term _fb_2[4];
        u64 _sp_2 = ctr_take(e, _f_0, 4, _fb_2);
        u32 _f_5 = _fb_2[0];
        Term _f_6 = _fb_2[1];
        Term _f_7 = _fb_2[2];
        u32 _f_8 = _fb_2[3];
        spare_free(e, cls_fit(4), _sp_2);
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
      }
      if (_o_0 == 0) {
        term_sink(e, _o_2);
        _name_0 = term_keep(e, _name_0, 1);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(5);
          STK(0) = _o_1;
          STK(1) = _f_1;
          STK(2) = _kind_0;
          STK(3) = _name_0;
          STK(4) = FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K41;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K41, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          e.mem[_t_0 + 1] = _f_1;
          e.mem[_t_0 + 2] = _kind_0;
          e.mem[_t_0 + 3] = _name_0;
          WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K41, _t_0);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
          u64 _t_1 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _name_0;
          e.mem[_t_1 + 1] = _o_3;
          return term_tsk(FID_STRING_EQ, _t_1);
        }
        r0 = _name_0;
        r1 = _o_3;
        WL_JMP(FID_STRING_EQ);
      } else {
        term_sink(e, _o_2);
        _name_0 = term_keep(e, _name_0, 1);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(5);
          STK(0) = _o_1;
          STK(1) = _f_1;
          STK(2) = _kind_0;
          STK(3) = _name_0;
          STK(4) = FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K43;
          WL_PUSHN(5);
        } else {
          u64 _t_4 = task_node(e, FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K43, WL_CONT, WL_IDX, 1);
          e.mem[_t_4 + 0] = _o_1;
          e.mem[_t_4 + 1] = _f_1;
          e.mem[_t_4 + 2] = _kind_0;
          e.mem[_t_4 + 3] = _name_0;
          WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K43, _t_4);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
          u64 _t_5 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
          e.mem[_t_5 + 0] = _name_0;
          e.mem[_t_5 + 1] = _o_3;
          return term_tsk(FID_STRING_EQ, _t_5);
        }
        r0 = _name_0;
        r1 = _o_3;
        WL_JMP(FID_STRING_EQ);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K41)
  {
    WL_POPN(4);
    u32 _o_5 = STK(0);
    Term _f_9 = STK(1);
    u32 _kind_1 = STK(2);
    Term _name_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _o_5;
      STK(1) = _kind_1;
      STK(2) = _h_0;
      STK(3) = FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K42;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K42, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _o_5;
      e.mem[_t_2 + 1] = _kind_1;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K42, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0)) {
      u64 _t_3 = task_node(e, FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_9;
      e.mem[_t_3 + 1] = _kind_1;
      e.mem[_t_3 + 2] = _name_1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0, _t_3);
    }
    r0 = _f_9;
    r1 = _kind_1;
    r2 = _name_1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K42)
  {
    WL_POPN(3);
    u32 _o_6 = STK(0);
    u32 _kind_2 = STK(1);
    u32 _h_2 = STK(2);
    u32 _h_1 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _o_7[1];
    if (spin_4(e, _o_7, _kind_2, _o_6) == 0) {
      return 0;
    }
    _v_2 = _o_7[0];
    _v_1 = _v_2;
    u32 _v_3 = 0;
    Term _o_8[1];
    if (spin_5(e, _o_8, _v_1, _h_2) == 0) {
      return 0;
    }
    _v_3 = _o_8[0];
    _v_0 = _v_3;
    r0 = ((_v_0) | (_h_1));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K43)
  {
    WL_POPN(4);
    u32 _o_9 = STK(0);
    Term _f_10 = STK(1);
    u32 _kind_3 = STK(2);
    Term _name_2 = STK(3);
    u32 _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _o_9;
      STK(1) = _kind_3;
      STK(2) = _h_3;
      STK(3) = FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K44;
      WL_PUSHN(4);
    } else {
      u64 _t_6 = task_node(e, FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K44, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _o_9;
      e.mem[_t_6 + 1] = _kind_3;
      e.mem[_t_6 + 2] = _h_3;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K44, _t_6);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0)) {
      u64 _t_7 = task_node(e, FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _f_10;
      e.mem[_t_7 + 1] = _kind_3;
      e.mem[_t_7 + 2] = _name_2;
      return term_tsk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0, _t_7);
    }
    r0 = _f_10;
    r1 = _kind_3;
    r2 = _name_2;
    WL_JMP(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0_K44)
  {
    WL_POPN(3);
    u32 _o_10 = STK(0);
    u32 _kind_4 = STK(1);
    u32 _h_5 = STK(2);
    u32 _h_4 = r0;
    WL_OPEN
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _o_11[1];
    if (spin_4(e, _o_11, _kind_4, _o_10) == 0) {
      return 0;
    }
    _v_6 = _o_11[0];
    _v_5 = _v_6;
    u32 _v_7 = 0;
    Term _o_12[1];
    if (spin_5(e, _o_12, _v_5, _h_5) == 0) {
      return 0;
    }
    _v_7 = _o_12[0];
    _v_4 = _v_7;
    r0 = ((_v_4) | (_h_4));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FRAGMENT)
  {
    Term _value_0 = r0;
    Term _value_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_0;
      STK(1) = FID_FRAGMENT_K48;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_FRAGMENT_K48, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_0;
      WL_CONT = term_tsk(FID_FRAGMENT_K48, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY)) {
      u64 _t_1 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_1;
      return term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY, _t_1);
    }
    r0 = _value_1;
    WL_JMP(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FRAGMENT_K48)
  {
    WL_POPN(1);
    Term _value_2 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    _value_2 = term_keep(e, _value_2, 1);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_2;
      STK(1) = _h_0;
      STK(2) = _h_1;
      STK(3) = FID_FRAGMENT_K49;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_FRAGMENT_K49, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_2;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      WL_CONT = term_tsk(FID_FRAGMENT_K49, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ENTRIES)) {
      u64 _t_3 = task_node(e, FID_ENTRIES, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_2;
      return term_tsk(FID_ENTRIES, _t_3);
    }
    r0 = _value_2;
    WL_JMP(FID_ENTRIES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FRAGMENT_K49)
  {
    WL_POPN(3);
    Term _value_3 = STK(0);
    Term _h_3 = STK(1);
    Term _h_4 = STK(2);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_3;
      STK(1) = _h_3;
      STK(2) = _h_2;
      STK(3) = FID_FRAGMENT_K50;
      WL_PUSHN(4);
    } else {
      u64 _t_4 = task_node(e, FID_FRAGMENT_K50, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_3;
      e.mem[_t_4 + 1] = _h_3;
      e.mem[_t_4 + 2] = _h_2;
      WL_CONT = term_tsk(FID_FRAGMENT_K50, _t_4);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 14);
      e.mem[_t_5 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 14);
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FRAGMENT_K50)
  {
    WL_POPN(3);
    Term _value_4 = STK(0);
    Term _h_6 = STK(1);
    Term _h_7 = STK(2);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_4;
      STK(1) = _h_6;
      STK(2) = FID_FRAGMENT_K51;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_FRAGMENT_K51, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _value_4;
      e.mem[_t_6 + 1] = _h_6;
      WL_CONT = term_tsk(FID_FRAGMENT_K51, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_7;
      e.mem[_t_7 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_7;
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_FRAGMENT_K51)
  {
    WL_POPN(2);
    Term _value_5 = STK(0);
    Term _h_9 = STK(1);
    Term _h_8 = r0;
    WL_OPEN
    r0 = _value_5;
    r1 = _h_9;
    r2 = _h_8;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY)
  {
    Term _value_0 = r0;
    WL_OPEN
    WL_SPIN
    if (blk_cls(_value_0) == 0) {
      u32 _c_0 = blk_read(e.mem, 0, blk_loc(e.mem, _value_0), 0 + 0);
      blk_free(e, _value_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K59;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K59, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K59, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32)) {
        u64 _t_1 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _c_0;
        return term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32, _t_1);
      }
      r0 = _c_0;
      WL_JMP(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_U32);
    } else {
      Term _h_4 = blk_half(e, _value_0, 0);
      Term _h_5 = blk_half(e, _value_0, 1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_5;
        STK(1) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K61;
        WL_PUSHN(2);
      } else {
        u64 _t_4 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K61, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _h_5;
        WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K61, _t_4);
        WL_IDX = 1;
      }
      r0 = _h_4;
      _value_0 = r0;
      WL_AGAIN(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K59)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K60;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K60, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K60, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 38);
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 38);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K60)
  {
    WL_POPN(1);
    u32 _h_3 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    Term _fv_0[1];
    _fv_0[0] = _h_3;
    r0 = blk_new(e, 0, 0, 0, 1, _fv_0);
    r1 = _h_2;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K61)
  {
    WL_POPN(1);
    Term _h_8 = STK(0);
    Term _h_6 = r0;
    Term _h_7 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_6;
      STK(1) = _h_7;
      STK(2) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K62;
      WL_PUSHN(3);
    } else {
      u64 _t_5 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K62, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _h_6;
      e.mem[_t_5 + 1] = _h_7;
      WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K62, _t_5);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY)) {
      u64 _t_6 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_8;
      return term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY, _t_6);
    }
    r0 = _h_8;
    WL_JMP(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K62)
  {
    WL_POPN(2);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    Term _h_9 = r0;
    Term _h_10 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_9;
      STK(3) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K63;
      WL_PUSHN(4);
    } else {
      u64 _t_7 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K63, WL_CONT, WL_IDX, 1);
      e.mem[_t_7 + 0] = _h_11;
      e.mem[_t_7 + 1] = _h_12;
      e.mem[_t_7 + 2] = _h_9;
      WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K63, _t_7);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_10;
      e.mem[_t_8 + 1] = term_ctr(CID_SCON, STAT_OFF + 16);
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _h_10;
    r1 = term_ctr(CID_SCON, STAT_OFF + 16);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K63)
  {
    WL_POPN(3);
    Term _h_14 = STK(0);
    Term _h_15 = STK(1);
    Term _h_16 = STK(2);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_14;
      STK(1) = _h_15;
      STK(2) = _h_16;
      STK(3) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K64;
      WL_PUSHN(4);
    } else {
      u64 _t_9 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K64, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_14;
      e.mem[_t_9 + 1] = _h_15;
      e.mem[_t_9 + 2] = _h_16;
      WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K64, _t_9);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 18);
      e.mem[_t_10 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 18);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K64)
  {
    WL_POPN(3);
    Term _h_18 = STK(0);
    Term _h_19 = STK(1);
    Term _h_20 = STK(2);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_18;
      STK(1) = _h_20;
      STK(2) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K65;
      WL_PUSHN(3);
    } else {
      u64 _t_11 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K65, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_18;
      e.mem[_t_11 + 1] = _h_20;
      WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K65, _t_11);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_19;
      e.mem[_t_12 + 1] = _h_17;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _h_19;
    r1 = _h_17;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K65)
  {
    WL_POPN(2);
    Term _h_22 = STK(0);
    Term _h_23 = STK(1);
    Term _h_21 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_22;
      STK(1) = _h_23;
      STK(2) = FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K66;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K66, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _h_22;
      e.mem[_t_13 + 1] = _h_23;
      WL_CONT = term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K66, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 28);
      e.mem[_t_14 + 1] = _h_21;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 28);
    r1 = _h_21;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY_K66)
  {
    WL_POPN(2);
    Term _h_25 = STK(0);
    Term _h_26 = STK(1);
    Term _h_24 = r0;
    WL_OPEN
    r0 = blk_node(e, _h_25, _h_26);
    r1 = _h_24;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0)
  {
    Term _xs_0 = r0;
    u32 _item_0 = r1;
    u32 _item_1 = r2;
    Term _item_2 = r3;
    Term _item_3 = r4;
    u32 _item_4 = r5;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      term_sink(e, _item_2);
      term_sink(e, _item_3);
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      if (term_aux(_f_0) == CID_SCHEMA_FRAGMENTS_ENTRY) {
        _o_0 = 0;
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
        _o_3 = _f_4;
      } else {
        _o_0 = 1;
        Term _fb_2[4];
        u64 _sp_2 = ctr_take(e, _f_0, 4, _fb_2);
        u32 _f_5 = _fb_2[0];
        Term _f_6 = _fb_2[1];
        Term _f_7 = _fb_2[2];
        u32 _f_8 = _fb_2[3];
        spare_free(e, cls_fit(4), _sp_2);
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
      }
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _v_2 = 0;
      Term _v_3 = 0;
      u32 _v_4 = 0;
      u32 _v_5 = 0;
      u32 _v_6 = 0;
      Term _v_7 = 0;
      Term _v_8 = 0;
      u32 _v_9 = 0;
      Term _o_5[5];
      if (spin_7(e, _o_5, _o_0, _o_1, _o_2, _o_3, _o_4) == 0) {
        return 0;
      }
      _v_5 = _o_5[0];
      _v_6 = _o_5[1];
      _v_7 = _o_5[2];
      _v_8 = _o_5[3];
      _v_9 = _o_5[4];
      _v_0 = _v_5;
      _v_1 = _v_6;
      _v_2 = _v_7;
      _v_3 = _v_8;
      _v_4 = _v_9;
      u32 _v_15 = 0;
      u32 _v_16 = 0;
      Term _v_17 = 0;
      Term _v_18 = 0;
      u32 _v_19 = 0;
      _item_2 = term_keep(e, _item_2, 1);
      _item_3 = term_keep(e, _item_3, 1);
      u32 _v_20 = 0;
      u32 _v_21 = 0;
      Term _v_22 = 0;
      Term _v_23 = 0;
      u32 _v_24 = 0;
      Term _o_6[5];
      if (spin_7(e, _o_6, _item_0, _item_1, _item_2, _item_3, _item_4) == 0) {
        return 0;
      }
      _v_20 = _o_6[0];
      _v_21 = _o_6[1];
      _v_22 = _o_6[2];
      _v_23 = _o_6[3];
      _v_24 = _o_6[4];
      _v_15 = _v_20;
      _v_16 = _v_21;
      _v_17 = _v_22;
      _v_18 = _v_23;
      _v_19 = _v_24;
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(7);
        STK(0) = _f_1;
        STK(1) = _item_0;
        STK(2) = _item_1;
        STK(3) = _item_2;
        STK(4) = _item_3;
        STK(5) = _item_4;
        STK(6) = FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K76;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K76, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _item_0;
        e.mem[_t_0 + 2] = _item_1;
        e.mem[_t_0 + 3] = _item_2;
        e.mem[_t_0 + 4] = _item_3;
        e.mem[_t_0 + 5] = _item_4;
        WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K76, _t_0);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0)) {
        u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = _v_1;
        e.mem[_t_1 + 2] = _v_2;
        e.mem[_t_1 + 3] = _v_3;
        e.mem[_t_1 + 4] = _v_4;
        e.mem[_t_1 + 5] = _v_15;
        e.mem[_t_1 + 6] = _v_16;
        e.mem[_t_1 + 7] = _v_17;
        e.mem[_t_1 + 8] = _v_18;
        e.mem[_t_1 + 9] = _v_19;
        return term_tsk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0, _t_1);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_15;
      r6 = _v_16;
      r7 = _v_17;
      r8 = _v_18;
      r9 = _v_19;
      WL_JMP(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_EQUAL_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K76)
  {
    WL_POPN(6);
    Term _f_9 = STK(0);
    u32 _item_5 = STK(1);
    u32 _item_6 = STK(2);
    Term _item_7 = STK(3);
    Term _item_8 = STK(4);
    u32 _item_9 = STK(5);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K77;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K77, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K77, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0)) {
      u64 _t_3 = task_node(e, FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_9;
      e.mem[_t_3 + 1] = _item_5;
      e.mem[_t_3 + 2] = _item_6;
      e.mem[_t_3 + 3] = _item_7;
      e.mem[_t_3 + 4] = _item_8;
      e.mem[_t_3 + 5] = _item_9;
      return term_tsk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0, _t_3);
    }
    r0 = _f_9;
    r1 = _item_5;
    r2 = _item_6;
    r3 = _item_7;
    r4 = _item_8;
    r5 = _item_9;
    WL_JMP(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0_K77)
  {
    WL_POPN(1);
    u32 _h_2 = STK(0);
    u32 _h_1 = r0;
    WL_OPEN
    r0 = ((_h_2) | (_h_1));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0)
  {
    Term _xs_0 = r0;
    Term _seen_0 = r1;
    WL_OPEN
    if (term_aux(_xs_0) == CID_NIL) {
      term_sink(e, _seen_0);
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      WL_RETN(5);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      if (term_aux(_f_0) == CID_SCHEMA_FRAGMENTS_ENTRY) {
        _o_0 = 0;
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
        _o_3 = _f_4;
      } else {
        _o_0 = 1;
        Term _fb_2[4];
        u64 _sp_2 = ctr_take(e, _f_0, 4, _fb_2);
        u32 _f_5 = _fb_2[0];
        Term _f_6 = _fb_2[1];
        Term _f_7 = _fb_2[2];
        u32 _f_8 = _fb_2[3];
        spare_free(e, cls_fit(4), _sp_2);
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
      }
      _seen_0 = term_keep(e, _seen_0, 1);
      _o_2 = term_keep(e, _o_2, 1);
      _o_3 = term_keep(e, _o_3, 1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(8);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = _o_2;
        STK(3) = _o_3;
        STK(4) = _o_4;
        STK(5) = _f_1;
        STK(6) = _seen_0;
        STK(7) = FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K82;
        WL_PUSHN(8);
      } else {
        u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K82, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        e.mem[_t_0 + 2] = _o_2;
        e.mem[_t_0 + 3] = _o_3;
        e.mem[_t_0 + 4] = _o_4;
        e.mem[_t_0 + 5] = _f_1;
        e.mem[_t_0 + 6] = _seen_0;
        WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K82, _t_0);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
        u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _seen_0;
        e.mem[_t_1 + 1] = _o_0;
        e.mem[_t_1 + 2] = _o_1;
        e.mem[_t_1 + 3] = _o_2;
        e.mem[_t_1 + 4] = _o_3;
        e.mem[_t_1 + 5] = _o_4;
        return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_1);
      }
      r0 = _seen_0;
      r1 = _o_0;
      r2 = _o_1;
      r3 = _o_2;
      r4 = _o_3;
      r5 = _o_4;
      WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K82)
  {
    WL_POPN(7);
    u32 _o_5 = STK(0);
    u32 _o_6 = STK(1);
    Term _o_7 = STK(2);
    Term _o_8 = STK(3);
    u32 _o_9 = STK(4);
    Term _f_9 = STK(5);
    Term _seen_1 = STK(6);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(7));
    e.mem[_nd_0 + 0] = _o_5;
    e.mem[_nd_0 + 1] = _o_6;
    e.mem[_nd_0 + 2] = _o_7;
    e.mem[_nd_0 + 3] = _o_8;
    e.mem[_nd_0 + 4] = _o_9;
    e.mem[_nd_0 + 5] = _f_9;
    e.mem[_nd_0 + 6] = _seen_1;
    if (_h_0 == 1) {
      Term _next_0 = term_clo(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_C83, _nd_0);
      term_sink(e, _next_0);
      r0 = 1;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _h_4;
      WL_RETN(5);
    } else {
      Term _next_1 = term_clo(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_C83, _nd_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K85;
        WL_PUSHN(1);
      } else {
        u64 _t_4 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K85, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K85, _t_4);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_5 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _next_1;
        e.mem[_t_5 + 1] = term_pak(CID_UNIT, 0);
        return term_tsk(FID_CLO_APPLY, _t_5);
      }
      r0 = _next_1;
      r1 = term_pak(CID_UNIT, 0);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_C83)
  {
    u32 _o_10 = r0;
    u32 _o_11 = r1;
    Term _o_12 = r2;
    Term _o_13 = r3;
    u32 _o_14 = r4;
    Term _f_10 = r5;
    Term _seen_2 = r6;
    Term _x_0 = r7;
    WL_OPEN
    Term _b_0 = 0;
    if (_o_10 == 0) {
      u64 _nd_1 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_1 + 0] = rfc_seal(e, _o_11);
      e.mem[_nd_1 + 1] = rfc_seal(e, _o_12);
      e.mem[_nd_1 + 2] = rfc_seal(e, _o_13);
      _b_0 = term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, _nd_1);
    } else {
      u64 _nd_2 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_2 + 0] = rfc_seal(e, _o_11);
      e.mem[_nd_2 + 1] = rfc_seal(e, _o_12);
      e.mem[_nd_2 + 2] = rfc_seal(e, _o_13);
      e.mem[_nd_2 + 3] = rfc_seal(e, _o_14);
      _b_0 = term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_2);
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _seen_2);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K84;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K84, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K84, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0)) {
      u64 _t_3 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_10;
      e.mem[_t_3 + 1] = term_ctr(CID_CON, _nd_3);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, _t_3);
    }
    r0 = _f_10;
    r1 = term_ctr(CID_CON, _nd_3);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K84)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    WL_OPEN
    Term _b_1 = 0;
    if (_r_0 == 0) {
      _b_1 = term_pak(CID_SCHEMA_FRAGMENTS_VALID, 0);
    } else {
      u64 _nd_4 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_4 + 0] = _r_1;
      e.mem[_nd_4 + 1] = _r_2;
      e.mem[_nd_4 + 2] = _r_3;
      e.mem[_nd_4 + 3] = _r_4;
      _b_1 = term_ctr(CID_SCHEMA_FRAGMENTS_INVALID, _nd_4);
    }
    r0 = _b_1;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0_K85)
  {
    Term _r_5 = r0;
    WL_OPEN
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    u32 _o_17 = 0;
    Term _o_18 = 0;
    Term _o_19 = 0;
    if (term_aux(_r_5) == CID_SCHEMA_FRAGMENTS_VALID) {
      _o_15 = 0;
    } else {
      _o_15 = 1;
      u64 _sp_3 = term_loc(_r_5);
      u32 _f_11 = e.mem[_sp_3 + 0];
      u32 _f_12 = e.mem[_sp_3 + 1];
      Term _f_13 = e.mem[_sp_3 + 2];
      Term _f_14 = e.mem[_sp_3 + 3];
      heap_free(e, cls_fit(4), _sp_3);
      _o_16 = _f_11;
      _o_17 = _f_12;
      _o_18 = _f_13;
      _o_19 = _f_14;
    }
    r0 = _o_15;
    r1 = _o_16;
    r2 = _o_17;
    r3 = _o_18;
    r4 = _o_19;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    Term _value_2 = r2;
    Term _value_3 = r3;
    WL_OPEN
    if (_value_0 == 0) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _value_1;
        STK(1) = FID_ERROR_K88;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_ERROR_K88, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _value_1;
        WL_CONT = term_tsk(FID_ERROR_K88, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
        e.mem[_t_1 + 1] = _value_2;
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      r1 = _value_2;
      WL_JMP(FID_STRING_APPEND);
    } else if (_value_0 == 1) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _value_1;
        STK(1) = FID_ERROR_K90;
        WL_PUSHN(2);
      } else {
        u64 _t_5 = task_node(e, FID_ERROR_K90, WL_CONT, WL_IDX, 1);
        e.mem[_t_5 + 0] = _value_1;
        WL_CONT = term_tsk(FID_ERROR_K90, _t_5);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
        e.mem[_t_6 + 1] = _value_2;
        return term_tsk(FID_STRING_APPEND, _t_6);
      }
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      r1 = _value_2;
      WL_JMP(FID_STRING_APPEND);
    } else {
      if (seq) {
        WL_ROOM(3);
        STK(0) = _value_1;
        STK(1) = _value_2;
        STK(2) = FID_ERROR_K92;
        WL_PUSHN(3);
      } else {
        u64 _t_10 = task_node(e, FID_ERROR_K92, WL_CONT, WL_IDX, 1);
        e.mem[_t_10 + 0] = _value_1;
        e.mem[_t_10 + 1] = _value_2;
        WL_CONT = term_tsk(FID_ERROR_K92, _t_10);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
        e.mem[_t_11 + 1] = _value_3;
        return term_tsk(FID_STRING_APPEND, _t_11);
      }
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      r1 = _value_3;
      WL_JMP(FID_STRING_APPEND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR_K88)
  {
    WL_POPN(1);
    u32 _value_4 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_9(e, _o_0, _value_4) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ERROR_K89;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_ERROR_K89, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ERROR_K89, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _v_0;
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = _v_0;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR_K89)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = term_ctr(CID_SCON, STAT_OFF + 202);
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 202);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR_K90)
  {
    WL_POPN(1);
    u32 _value_6 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_1[1];
    if (spin_9(e, _o_1, _value_6) == 0) {
      return 0;
    }
    _v_4 = _o_1[0];
    _v_3 = _v_4;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ERROR_K91;
      WL_PUSHN(1);
    } else {
      u64 _t_7 = task_node(e, FID_ERROR_K91, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ERROR_K91, _t_7);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _v_3;
      e.mem[_t_8 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _v_3;
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR_K91)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 228);
      e.mem[_t_9 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 228);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR_K92)
  {
    WL_POPN(2);
    u32 _value_7 = STK(0);
    Term _value_8 = STK(1);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_7;
      STK(1) = FID_ERROR_K93;
      WL_PUSHN(2);
    } else {
      u64 _t_12 = task_node(e, FID_ERROR_K93, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _value_7;
      WL_CONT = term_tsk(FID_ERROR_K93, _t_12);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _value_8;
      e.mem[_t_13 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _value_8;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR_K93)
  {
    WL_POPN(1);
    u32 _value_9 = STK(0);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_9;
      STK(1) = FID_ERROR_K94;
      WL_PUSHN(2);
    } else {
      u64 _t_14 = task_node(e, FID_ERROR_K94, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _value_9;
      WL_CONT = term_tsk(FID_ERROR_K94, _t_14);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_15 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR_K94)
  {
    WL_POPN(1);
    u32 _value_10 = STK(0);
    Term _h_6 = r0;
    WL_OPEN
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _o_2[1];
    if (spin_9(e, _o_2, _value_10) == 0) {
      return 0;
    }
    _v_6 = _o_2[0];
    _v_5 = _v_6;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ERROR_K95;
      WL_PUSHN(1);
    } else {
      u64 _t_16 = task_node(e, FID_ERROR_K95, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ERROR_K95, _t_16);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _v_5;
      e.mem[_t_17 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = _v_5;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ERROR_K95)
  {
    Term _h_7 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_18 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = term_ctr(CID_SCON, STAT_OFF + 244);
      e.mem[_t_18 + 1] = _h_7;
      return term_tsk(FID_STRING_APPEND, _t_18);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 244);
    r1 = _h_7;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    Term _value_2 = r2;
    Term _value_3 = r3;
    u32 _value_4 = r4;
    WL_OPEN
    if (_value_0 == 0) {
      if (seq) {
        WL_ROOM(3);
        STK(0) = _value_1;
        STK(1) = _value_2;
        STK(2) = FID_ENTRY_K99;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID_ENTRY_K99, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _value_1;
        e.mem[_t_0 + 1] = _value_2;
        WL_CONT = term_tsk(FID_ENTRY_K99, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_1 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _value_3;
        e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 252);
        return term_tsk(FID_STRING_APPEND, _t_1);
      }
      r0 = _value_3;
      r1 = term_ctr(CID_SCON, STAT_OFF + 252);
      WL_JMP(FID_STRING_APPEND);
    } else {
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _o_1[1];
      if (spin_10(e, _o_1, _value_4) == 0) {
        return 0;
      }
      _v_3 = _o_1[0];
      _v_2 = _v_3;
      if (seq) {
        WL_ROOM(4);
        STK(0) = _value_1;
        STK(1) = _value_2;
        STK(2) = _value_3;
        STK(3) = FID_ENTRY_K103;
        WL_PUSHN(4);
      } else {
        u64 _t_9 = task_node(e, FID_ENTRY_K103, WL_CONT, WL_IDX, 1);
        e.mem[_t_9 + 0] = _value_1;
        e.mem[_t_9 + 1] = _value_2;
        e.mem[_t_9 + 2] = _value_3;
        WL_CONT = term_tsk(FID_ENTRY_K103, _t_9);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
        e.mem[_t_10 + 1] = _v_2;
        return term_tsk(FID_STRING_APPEND, _t_10);
      }
      r0 = term_ctr(CID_SCON, STAT_OFF + 30);
      r1 = _v_2;
      WL_JMP(FID_STRING_APPEND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K99)
  {
    WL_POPN(2);
    u32 _value_5 = STK(0);
    Term _value_6 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_5;
      STK(1) = _value_6;
      STK(2) = FID_ENTRY_K100;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_ENTRY_K100, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_5;
      e.mem[_t_2 + 1] = _value_6;
      WL_CONT = term_tsk(FID_ENTRY_K100, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K100)
  {
    WL_POPN(2);
    u32 _value_7 = STK(0);
    Term _value_8 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_7;
      STK(1) = FID_ENTRY_K101;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_ENTRY_K101, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_7;
      WL_CONT = term_tsk(FID_ENTRY_K101, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_8;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _value_8;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K101)
  {
    WL_POPN(1);
    u32 _value_9 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_9;
      STK(1) = FID_ENTRY_K102;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_ENTRY_K102, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _value_9;
      WL_CONT = term_tsk(FID_ENTRY_K102, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_7 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K102)
  {
    WL_POPN(1);
    u32 _value_10 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_9(e, _o_0, _value_10) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _v_0;
      e.mem[_t_8 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = _v_0;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K103)
  {
    WL_POPN(3);
    u32 _value_12 = STK(0);
    Term _value_13 = STK(1);
    Term _value_14 = STK(2);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_12;
      STK(1) = _value_13;
      STK(2) = FID_ENTRY_K104;
      WL_PUSHN(3);
    } else {
      u64 _t_11 = task_node(e, FID_ENTRY_K104, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _value_12;
      e.mem[_t_11 + 1] = _value_13;
      WL_CONT = term_tsk(FID_ENTRY_K104, _t_11);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _value_14;
      e.mem[_t_12 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _value_14;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K104)
  {
    WL_POPN(2);
    u32 _value_15 = STK(0);
    Term _value_16 = STK(1);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_15;
      STK(1) = _value_16;
      STK(2) = FID_ENTRY_K105;
      WL_PUSHN(3);
    } else {
      u64 _t_13 = task_node(e, FID_ENTRY_K105, WL_CONT, WL_IDX, 1);
      e.mem[_t_13 + 0] = _value_15;
      e.mem[_t_13 + 1] = _value_16;
      WL_CONT = term_tsk(FID_ENTRY_K105, _t_13);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_14 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K105)
  {
    WL_POPN(2);
    u32 _value_17 = STK(0);
    Term _value_18 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_17;
      STK(1) = FID_ENTRY_K106;
      WL_PUSHN(2);
    } else {
      u64 _t_15 = task_node(e, FID_ENTRY_K106, WL_CONT, WL_IDX, 1);
      e.mem[_t_15 + 0] = _value_17;
      WL_CONT = term_tsk(FID_ENTRY_K106, _t_15);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = _value_18;
      e.mem[_t_16 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = _value_18;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K106)
  {
    WL_POPN(1);
    u32 _value_19 = STK(0);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_19;
      STK(1) = FID_ENTRY_K107;
      WL_PUSHN(2);
    } else {
      u64 _t_17 = task_node(e, FID_ENTRY_K107, WL_CONT, WL_IDX, 1);
      e.mem[_t_17 + 0] = _value_19;
      WL_CONT = term_tsk(FID_ENTRY_K107, _t_17);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_18 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = term_ctr(CID_SCON, STAT_OFF + 30);
      e.mem[_t_18 + 1] = _h_7;
      return term_tsk(FID_STRING_APPEND, _t_18);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 30);
    r1 = _h_7;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRY_K107)
  {
    WL_POPN(1);
    u32 _value_20 = STK(0);
    Term _h_8 = r0;
    WL_OPEN
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _o_2[1];
    if (spin_9(e, _o_2, _value_20) == 0) {
      return 0;
    }
    _v_6 = _o_2[0];
    _v_5 = _v_6;
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _v_5;
      e.mem[_t_19 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _v_5;
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)
  {
    Term _seen_0 = r0;
    u32 _item_0 = r1;
    u32 _item_1 = r2;
    Term _item_2 = r3;
    Term _item_3 = r4;
    u32 _item_4 = r5;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _item_0;
      STK(1) = _item_1;
      STK(2) = _item_2;
      STK(3) = _item_3;
      STK(4) = _item_4;
      STK(5) = FID_SCHEMA_FRAGMENTS_CHECK_ONE_0_K117;
      WL_PUSHN(6);
    } else {
      u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0_K117, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _item_0;
      e.mem[_t_0 + 1] = _item_1;
      e.mem[_t_0 + 2] = _item_2;
      e.mem[_t_0 + 3] = _item_3;
      e.mem[_t_0 + 4] = _item_4;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0_K117, _t_0);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0)) {
      u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _seen_0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0, _t_1);
    }
    r0 = _seen_0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0_K117)
  {
    WL_POPN(5);
    u32 _item_5 = STK(0);
    u32 _item_6 = STK(1);
    Term _item_7 = STK(2);
    Term _item_8 = STK(3);
    u32 _item_9 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _o_0[5];
    if (spin_7(e, _o_0, _item_5, _item_6, _item_7, _item_8, _item_9) == 0) {
      return 0;
    }
    _v_5 = _o_0[0];
    _v_6 = _o_0[1];
    _v_7 = _o_0[2];
    _v_8 = _o_0[3];
    _v_9 = _o_0[4];
    _v_0 = _v_5;
    _v_1 = _v_6;
    _v_2 = _v_7;
    _v_3 = _v_8;
    _v_4 = _v_9;
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _v_0;
      e.mem[_t_2 + 2] = _v_1;
      e.mem[_t_2 + 3] = _v_2;
      e.mem[_t_2 + 4] = _v_3;
      e.mem[_t_2 + 5] = _v_4;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_2);
    }
    r0 = _h_0;
    r1 = _v_0;
    r2 = _v_1;
    r3 = _v_2;
    r4 = _v_3;
    r5 = _v_4;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)
  {
    Term _seen_0 = r0;
    u32 _item_0 = r1;
    u32 _item_1 = r2;
    Term _item_2 = r3;
    Term _item_3 = r4;
    u32 _item_4 = r5;
    WL_OPEN
    if (_item_0 == 0) {
      _item_3 = term_keep(e, _item_3, 1);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _item_1;
        STK(1) = _item_2;
        STK(2) = _item_3;
        STK(3) = FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K119;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K119, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _item_1;
        e.mem[_t_0 + 1] = _item_2;
        e.mem[_t_0 + 2] = _item_3;
        WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K119, _t_0);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0)) {
        u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _seen_0;
        e.mem[_t_1 + 1] = _item_1;
        e.mem[_t_1 + 2] = _item_3;
        return term_tsk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0, _t_1);
      }
      r0 = _seen_0;
      r1 = _item_1;
      r2 = _item_3;
      WL_JMP(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0);
    } else {
      _item_3 = term_keep(e, _item_3, 1);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _item_1;
        STK(1) = _item_2;
        STK(2) = _item_3;
        STK(3) = FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K120;
        WL_PUSHN(4);
      } else {
        u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K120, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _item_1;
        e.mem[_t_2 + 1] = _item_2;
        e.mem[_t_2 + 2] = _item_3;
        WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K120, _t_2);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0)) {
        u64 _t_3 = task_node(e, FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _seen_0;
        e.mem[_t_3 + 1] = _item_1;
        e.mem[_t_3 + 2] = _item_3;
        return term_tsk(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0, _t_3);
      }
      r0 = _seen_0;
      r1 = _item_1;
      r2 = _item_3;
      WL_JMP(FID_SCHEMA_FRAGMENTS_NAME_EXISTS_BARE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K119)
  {
    WL_POPN(3);
    u32 _item_5 = STK(0);
    Term _item_6 = STK(1);
    Term _item_7 = STK(2);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_0[5];
    if (spin_12(e, _o_0, 0, _h_0, _item_5, _item_6, _item_7) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0_K120)
  {
    WL_POPN(3);
    u32 _item_8 = STK(0);
    Term _item_9 = STK(1);
    Term _item_10 = STK(2);
    u32 _h_1 = r0;
    WL_OPEN
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _o_1[5];
    if (spin_12(e, _o_1, 0, _h_1, _item_8, _item_9, _item_10) == 0) {
      return 0;
    }
    _v_10 = _o_1[0];
    _v_11 = _o_1[1];
    _v_12 = _o_1[2];
    _v_13 = _o_1[3];
    _v_14 = _o_1[4];
    r0 = _v_10;
    r1 = _v_11;
    r2 = _v_12;
    r3 = _v_13;
    r4 = _v_14;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_MERGE_0)
  {
    Term _left_0 = r0;
    Term _left_1 = r1;
    Term _right_0 = r2;
    Term _right_1 = r3;
    WL_OPEN
    _left_0 = term_keep(e, _left_0, 1);
    if (seq) {
      WL_ROOM(5);
      STK(0) = _left_0;
      STK(1) = _left_1;
      STK(2) = _right_0;
      STK(3) = _right_1;
      STK(4) = FID_SCHEMA_FRAGMENTS_MERGE_0_K122;
      WL_PUSHN(5);
    } else {
      u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_MERGE_0_K122, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _left_0;
      e.mem[_t_0 + 1] = _left_1;
      e.mem[_t_0 + 2] = _right_0;
      e.mem[_t_0 + 3] = _right_1;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_MERGE_0_K122, _t_0);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _left_0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_1);
    }
    r0 = _left_0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_MERGE_0_K122)
  {
    WL_POPN(4);
    Term _left_2 = STK(0);
    Term _left_3 = STK(1);
    Term _right_2 = STK(2);
    Term _right_3 = STK(3);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    WL_OPEN
    _right_2 = term_keep(e, _right_2, 1);
    if (seq) {
      WL_ROOM(10);
      STK(0) = _left_2;
      STK(1) = _left_3;
      STK(2) = _right_2;
      STK(3) = _right_3;
      STK(4) = _h_0;
      STK(5) = _h_1;
      STK(6) = _h_2;
      STK(7) = _h_3;
      STK(8) = _h_4;
      STK(9) = FID_SCHEMA_FRAGMENTS_MERGE_0_K123;
      WL_PUSHN(10);
    } else {
      u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_MERGE_0_K123, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _left_2;
      e.mem[_t_2 + 1] = _left_3;
      e.mem[_t_2 + 2] = _right_2;
      e.mem[_t_2 + 3] = _right_3;
      e.mem[_t_2 + 4] = _h_0;
      e.mem[_t_2 + 5] = _h_1;
      e.mem[_t_2 + 6] = _h_2;
      e.mem[_t_2 + 7] = _h_3;
      e.mem[_t_2 + 8] = _h_4;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_MERGE_0_K123, _t_2);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_3 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _right_2;
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_3);
    }
    r0 = _right_2;
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_MERGE_0_K123)
  {
    WL_POPN(9);
    Term _left_4 = STK(0);
    Term _left_5 = STK(1);
    Term _right_4 = STK(2);
    Term _right_5 = STK(3);
    u32 _h_10 = STK(4);
    u32 _h_11 = STK(5);
    u32 _h_12 = STK(6);
    Term _h_13 = STK(7);
    Term _h_14 = STK(8);
    u32 _h_5 = r0;
    u32 _h_6 = r1;
    u32 _h_7 = r2;
    Term _h_8 = r3;
    Term _h_9 = r4;
    WL_OPEN
    _left_4 = term_keep(e, _left_4, 1);
    _right_4 = term_keep(e, _right_4, 1);
    if (seq) {
      WL_ROOM(15);
      STK(0) = _left_4;
      STK(1) = _left_5;
      STK(2) = _right_4;
      STK(3) = _right_5;
      STK(4) = _h_10;
      STK(5) = _h_11;
      STK(6) = _h_12;
      STK(7) = _h_13;
      STK(8) = _h_14;
      STK(9) = _h_5;
      STK(10) = _h_6;
      STK(11) = _h_7;
      STK(12) = _h_8;
      STK(13) = _h_9;
      STK(14) = FID_SCHEMA_FRAGMENTS_MERGE_0_K124;
      WL_PUSHN(15);
    } else {
      u64 _t_4 = task_node(e, FID_SCHEMA_FRAGMENTS_MERGE_0_K124, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _left_4;
      e.mem[_t_4 + 1] = _left_5;
      e.mem[_t_4 + 2] = _right_4;
      e.mem[_t_4 + 3] = _right_5;
      e.mem[_t_4 + 4] = _h_10;
      e.mem[_t_4 + 5] = _h_11;
      e.mem[_t_4 + 6] = _h_12;
      e.mem[_t_4 + 7] = _h_13;
      e.mem[_t_4 + 8] = _h_14;
      e.mem[_t_4 + 9] = _h_5;
      e.mem[_t_4 + 10] = _h_6;
      e.mem[_t_4 + 11] = _h_7;
      e.mem[_t_4 + 12] = _h_8;
      e.mem[_t_4 + 13] = _h_9;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_MERGE_0_K124, _t_4);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_5 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _left_4;
      e.mem[_t_5 + 1] = _right_4;
      return term_tsk(FID_LIST_APPEND, _t_5);
    }
    r0 = _left_4;
    r1 = _right_4;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_MERGE_0_K124)
  {
    WL_POPN(14);
    Term _left_6 = STK(0);
    Term _left_7 = STK(1);
    Term _right_6 = STK(2);
    Term _right_7 = STK(3);
    u32 _h_16 = STK(4);
    u32 _h_17 = STK(5);
    u32 _h_18 = STK(6);
    Term _h_19 = STK(7);
    Term _h_20 = STK(8);
    u32 _h_21 = STK(9);
    u32 _h_22 = STK(10);
    u32 _h_23 = STK(11);
    Term _h_24 = STK(12);
    Term _h_25 = STK(13);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _left_6;
      STK(1) = _left_7;
      STK(2) = _right_6;
      STK(3) = _right_7;
      STK(4) = _h_16;
      STK(5) = _h_17;
      STK(6) = _h_18;
      STK(7) = _h_19;
      STK(8) = _h_20;
      STK(9) = _h_21;
      STK(10) = _h_22;
      STK(11) = _h_23;
      STK(12) = _h_24;
      STK(13) = _h_25;
      STK(14) = FID_SCHEMA_FRAGMENTS_MERGE_0_K125;
      WL_PUSHN(15);
    } else {
      u64 _t_6 = task_node(e, FID_SCHEMA_FRAGMENTS_MERGE_0_K125, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _left_6;
      e.mem[_t_6 + 1] = _left_7;
      e.mem[_t_6 + 2] = _right_6;
      e.mem[_t_6 + 3] = _right_7;
      e.mem[_t_6 + 4] = _h_16;
      e.mem[_t_6 + 5] = _h_17;
      e.mem[_t_6 + 6] = _h_18;
      e.mem[_t_6 + 7] = _h_19;
      e.mem[_t_6 + 8] = _h_20;
      e.mem[_t_6 + 9] = _h_21;
      e.mem[_t_6 + 10] = _h_22;
      e.mem[_t_6 + 11] = _h_23;
      e.mem[_t_6 + 12] = _h_24;
      e.mem[_t_6 + 13] = _h_25;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_MERGE_0_K125, _t_6);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_7 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_15;
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_7);
    }
    r0 = _h_15;
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_MERGE_0_K125)
  {
    WL_POPN(14);
    Term _left_8 = STK(0);
    Term _left_9 = STK(1);
    Term _right_8 = STK(2);
    Term _right_9 = STK(3);
    u32 _h_31 = STK(4);
    u32 _h_32 = STK(5);
    u32 _h_33 = STK(6);
    Term _h_34 = STK(7);
    Term _h_35 = STK(8);
    u32 _h_36 = STK(9);
    u32 _h_37 = STK(10);
    u32 _h_38 = STK(11);
    Term _h_39 = STK(12);
    Term _h_40 = STK(13);
    u32 _h_26 = r0;
    u32 _h_27 = r1;
    u32 _h_28 = r2;
    Term _h_29 = r3;
    Term _h_30 = r4;
    WL_OPEN
    _left_8 = term_keep(e, _left_8, 1);
    _right_8 = term_keep(e, _right_8, 1);
    if (seq) {
      WL_ROOM(20);
      STK(0) = _left_8;
      STK(1) = _left_9;
      STK(2) = _right_8;
      STK(3) = _right_9;
      STK(4) = _h_31;
      STK(5) = _h_32;
      STK(6) = _h_33;
      STK(7) = _h_34;
      STK(8) = _h_35;
      STK(9) = _h_36;
      STK(10) = _h_37;
      STK(11) = _h_38;
      STK(12) = _h_39;
      STK(13) = _h_40;
      STK(14) = _h_26;
      STK(15) = _h_27;
      STK(16) = _h_28;
      STK(17) = _h_29;
      STK(18) = _h_30;
      STK(19) = FID_SCHEMA_FRAGMENTS_MERGE_0_K126;
      WL_PUSHN(20);
    } else {
      u64 _t_8 = task_node(e, FID_SCHEMA_FRAGMENTS_MERGE_0_K126, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _left_8;
      e.mem[_t_8 + 1] = _left_9;
      e.mem[_t_8 + 2] = _right_8;
      e.mem[_t_8 + 3] = _right_9;
      e.mem[_t_8 + 4] = _h_31;
      e.mem[_t_8 + 5] = _h_32;
      e.mem[_t_8 + 6] = _h_33;
      e.mem[_t_8 + 7] = _h_34;
      e.mem[_t_8 + 8] = _h_35;
      e.mem[_t_8 + 9] = _h_36;
      e.mem[_t_8 + 10] = _h_37;
      e.mem[_t_8 + 11] = _h_38;
      e.mem[_t_8 + 12] = _h_39;
      e.mem[_t_8 + 13] = _h_40;
      e.mem[_t_8 + 14] = _h_26;
      e.mem[_t_8 + 15] = _h_27;
      e.mem[_t_8 + 16] = _h_28;
      e.mem[_t_8 + 17] = _h_29;
      e.mem[_t_8 + 18] = _h_30;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_MERGE_0_K126, _t_8);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_9 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _left_8;
      e.mem[_t_9 + 1] = _right_8;
      return term_tsk(FID_LIST_APPEND, _t_9);
    }
    r0 = _left_8;
    r1 = _right_8;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_MERGE_0_K126)
  {
    WL_POPN(19);
    Term _left_10 = STK(0);
    Term _left_11 = STK(1);
    Term _right_10 = STK(2);
    Term _right_11 = STK(3);
    u32 _h_42 = STK(4);
    u32 _h_43 = STK(5);
    u32 _h_44 = STK(6);
    Term _h_45 = STK(7);
    Term _h_46 = STK(8);
    u32 _h_47 = STK(9);
    u32 _h_48 = STK(10);
    u32 _h_49 = STK(11);
    Term _h_50 = STK(12);
    Term _h_51 = STK(13);
    u32 _h_52 = STK(14);
    u32 _h_53 = STK(15);
    u32 _h_54 = STK(16);
    Term _h_55 = STK(17);
    Term _h_56 = STK(18);
    Term _h_41 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _o_0[5];
    if (spin_13(e, _o_0, _h_47, _h_48, _h_49, _h_50, _h_51, _h_52, _h_53, _h_54, _h_55, _h_56) == 0) {
      return 0;
    }
    _v_10 = _o_0[0];
    _v_11 = _o_0[1];
    _v_12 = _o_0[2];
    _v_13 = _o_0[3];
    _v_14 = _o_0[4];
    _v_5 = _v_10;
    _v_6 = _v_11;
    _v_7 = _v_12;
    _v_8 = _v_13;
    _v_9 = _v_14;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _o_1[5];
    if (spin_13(e, _o_1, _h_42, _h_43, _h_44, _h_45, _h_46, _v_5, _v_6, _v_7, _v_8, _v_9) == 0) {
      return 0;
    }
    _v_20 = _o_1[0];
    _v_21 = _o_1[1];
    _v_22 = _o_1[2];
    _v_23 = _o_1[3];
    _v_24 = _o_1[4];
    _v_0 = _v_20;
    _v_1 = _v_21;
    _v_2 = _v_22;
    _v_3 = _v_23;
    _v_4 = _v_24;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _o_2[9];
    if (spin_14(e, _o_2, _v_0, _v_1, _v_2, _v_3, _v_4, _h_41, _left_10, _left_11, _right_10, _right_11) == 0) {
      return 0;
    }
    _v_25 = _o_2[0];
    _v_26 = _o_2[1];
    _v_27 = _o_2[2];
    _v_28 = _o_2[3];
    _v_29 = _o_2[4];
    _v_30 = _o_2[5];
    _v_31 = _o_2[6];
    _v_32 = _o_2[7];
    _v_33 = _o_2[8];
    r0 = _v_25;
    r1 = _v_26;
    r2 = _v_27;
    r3 = _v_28;
    r4 = _v_29;
    r5 = _v_30;
    r6 = _v_31;
    r7 = _v_32;
    r8 = _v_33;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE)
  {
    u32 _value_0 = r0;
    Term _value_1 = r1;
    Term _value_2 = r2;
    Term _value_3 = r3;
    Term _value_4 = r4;
    Term _value_5 = r5;
    Term _value_6 = r6;
    Term _value_7 = r7;
    Term _value_8 = r8;
    WL_OPEN
    if (_value_0 == 0) {
      if (seq) {
        WL_ROOM(3);
        STK(0) = _value_1;
        STK(1) = _value_3;
        STK(2) = FID_MERGE_K128;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID_MERGE_K128, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _value_1;
        e.mem[_t_0 + 1] = _value_3;
        WL_CONT = term_tsk(FID_MERGE_K128, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY)) {
        u64 _t_1 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _value_2;
        return term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY, _t_1);
      }
      r0 = _value_2;
      WL_JMP(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY);
    } else {
      if (seq) {
        WL_ROOM(7);
        STK(0) = _value_1;
        STK(1) = _value_2;
        STK(2) = _value_3;
        STK(3) = _value_4;
        STK(4) = _value_7;
        STK(5) = _value_8;
        STK(6) = FID_MERGE_K136;
        WL_PUSHN(7);
      } else {
        u64 _t_16 = task_node(e, FID_MERGE_K136, WL_CONT, WL_IDX, 1);
        e.mem[_t_16 + 0] = _value_1;
        e.mem[_t_16 + 1] = _value_2;
        e.mem[_t_16 + 2] = _value_3;
        e.mem[_t_16 + 3] = _value_4;
        e.mem[_t_16 + 4] = _value_7;
        e.mem[_t_16 + 5] = _value_8;
        WL_CONT = term_tsk(FID_MERGE_K136, _t_16);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_FRAGMENT)) {
        u64 _t_17 = task_node(e, FID_FRAGMENT, WL_CONT, WL_IDX, 0);
        e.mem[_t_17 + 0] = _value_5;
        e.mem[_t_17 + 1] = _value_6;
        return term_tsk(FID_FRAGMENT, _t_17);
      }
      r0 = _value_5;
      r1 = _value_6;
      WL_JMP(FID_FRAGMENT);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K128)
  {
    WL_POPN(2);
    Term _value_9 = STK(0);
    Term _value_10 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_9;
      STK(1) = _h_0;
      STK(2) = _h_1;
      STK(3) = FID_MERGE_K129;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_MERGE_K129, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_9;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      WL_CONT = term_tsk(FID_MERGE_K129, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY)) {
      u64 _t_3 = task_node(e, FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_10;
      return term_tsk(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY, _t_3);
    }
    r0 = _value_10;
    WL_JMP(FID________________________________________BENDVY_SRC_ECS_ORDINARY_DUMP_BUILTIN_ARRAY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K129)
  {
    WL_POPN(3);
    Term _value_11 = STK(0);
    Term _h_4 = STK(1);
    Term _h_5 = STK(2);
    Term _h_2 = r0;
    Term _h_3 = r1;
    WL_OPEN
    _value_11 = term_keep(e, _value_11, 1);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _value_11;
      STK(1) = _h_4;
      STK(2) = _h_5;
      STK(3) = _h_2;
      STK(4) = _h_3;
      STK(5) = FID_MERGE_K130;
      WL_PUSHN(6);
    } else {
      u64 _t_4 = task_node(e, FID_MERGE_K130, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _value_11;
      e.mem[_t_4 + 1] = _h_4;
      e.mem[_t_4 + 2] = _h_5;
      e.mem[_t_4 + 3] = _h_2;
      e.mem[_t_4 + 4] = _h_3;
      WL_CONT = term_tsk(FID_MERGE_K130, _t_4);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ENTRIES)) {
      u64 _t_5 = task_node(e, FID_ENTRIES, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_11;
      return term_tsk(FID_ENTRIES, _t_5);
    }
    r0 = _value_11;
    WL_JMP(FID_ENTRIES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K130)
  {
    WL_POPN(5);
    Term _value_12 = STK(0);
    Term _h_7 = STK(1);
    Term _h_8 = STK(2);
    Term _h_9 = STK(3);
    Term _h_10 = STK(4);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _value_12;
      STK(1) = _h_7;
      STK(2) = _h_8;
      STK(3) = _h_9;
      STK(4) = _h_6;
      STK(5) = FID_MERGE_K131;
      WL_PUSHN(6);
    } else {
      u64 _t_6 = task_node(e, FID_MERGE_K131, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _value_12;
      e.mem[_t_6 + 1] = _h_7;
      e.mem[_t_6 + 2] = _h_8;
      e.mem[_t_6 + 3] = _h_9;
      e.mem[_t_6 + 4] = _h_6;
      WL_CONT = term_tsk(FID_MERGE_K131, _t_6);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 158);
      e.mem[_t_7 + 1] = _h_10;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 158);
    r1 = _h_10;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K131)
  {
    WL_POPN(5);
    Term _value_13 = STK(0);
    Term _h_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_14 = STK(3);
    Term _h_15 = STK(4);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _value_13;
      STK(1) = _h_12;
      STK(2) = _h_14;
      STK(3) = _h_15;
      STK(4) = FID_MERGE_K132;
      WL_PUSHN(5);
    } else {
      u64 _t_8 = task_node(e, FID_MERGE_K132, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _value_13;
      e.mem[_t_8 + 1] = _h_12;
      e.mem[_t_8 + 2] = _h_14;
      e.mem[_t_8 + 3] = _h_15;
      WL_CONT = term_tsk(FID_MERGE_K132, _t_8);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_13;
      e.mem[_t_9 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_13;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K132)
  {
    WL_POPN(4);
    Term _value_14 = STK(0);
    Term _h_17 = STK(1);
    Term _h_18 = STK(2);
    Term _h_19 = STK(3);
    Term _h_16 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _value_14;
      STK(1) = _h_17;
      STK(2) = _h_18;
      STK(3) = _h_19;
      STK(4) = FID_MERGE_K133;
      WL_PUSHN(5);
    } else {
      u64 _t_10 = task_node(e, FID_MERGE_K133, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _value_14;
      e.mem[_t_10 + 1] = _h_17;
      e.mem[_t_10 + 2] = _h_18;
      e.mem[_t_10 + 3] = _h_19;
      WL_CONT = term_tsk(FID_MERGE_K133, _t_10);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 166);
      e.mem[_t_11 + 1] = _h_16;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 166);
    r1 = _h_16;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K133)
  {
    WL_POPN(4);
    Term _value_15 = STK(0);
    Term _h_21 = STK(1);
    Term _h_22 = STK(2);
    Term _h_23 = STK(3);
    Term _h_20 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_15;
      STK(1) = _h_21;
      STK(2) = _h_22;
      STK(3) = FID_MERGE_K134;
      WL_PUSHN(4);
    } else {
      u64 _t_12 = task_node(e, FID_MERGE_K134, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _value_15;
      e.mem[_t_12 + 1] = _h_21;
      e.mem[_t_12 + 2] = _h_22;
      WL_CONT = term_tsk(FID_MERGE_K134, _t_12);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_23;
      e.mem[_t_13 + 1] = _h_20;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_23;
    r1 = _h_20;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K134)
  {
    WL_POPN(3);
    Term _value_16 = STK(0);
    Term _h_25 = STK(1);
    Term _h_26 = STK(2);
    Term _h_24 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _value_16;
      STK(1) = _h_25;
      STK(2) = _h_26;
      STK(3) = FID_MERGE_K135;
      WL_PUSHN(4);
    } else {
      u64 _t_14 = task_node(e, FID_MERGE_K135, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _value_16;
      e.mem[_t_14 + 1] = _h_25;
      e.mem[_t_14 + 2] = _h_26;
      WL_CONT = term_tsk(FID_MERGE_K135, _t_14);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = term_ctr(CID_SCON, STAT_OFF + 178);
      e.mem[_t_15 + 1] = _h_24;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 178);
    r1 = _h_24;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K135)
  {
    WL_POPN(3);
    Term _value_17 = STK(0);
    Term _h_28 = STK(1);
    Term _h_29 = STK(2);
    Term _h_27 = r0;
    WL_OPEN
    r0 = 0;
    r1 = _value_17;
    r2 = _h_28;
    r3 = _h_29;
    r4 = 0;
    r5 = 0;
    r6 = 0;
    r7 = 0;
    r8 = 0;
    r9 = _h_27;
    WL_RETN(10);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K136)
  {
    WL_POPN(6);
    u32 _value_18 = STK(0);
    u32 _value_19 = STK(1);
    Term _value_20 = STK(2);
    Term _value_21 = STK(3);
    Term _value_22 = STK(4);
    Term _value_23 = STK(5);
    Term _h_30 = r0;
    Term _h_31 = r1;
    Term _h_32 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _value_18;
      STK(1) = _value_19;
      STK(2) = _value_20;
      STK(3) = _value_21;
      STK(4) = _h_30;
      STK(5) = _h_31;
      STK(6) = _h_32;
      STK(7) = FID_MERGE_K137;
      WL_PUSHN(8);
    } else {
      u64 _t_18 = task_node(e, FID_MERGE_K137, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _value_18;
      e.mem[_t_18 + 1] = _value_19;
      e.mem[_t_18 + 2] = _value_20;
      e.mem[_t_18 + 3] = _value_21;
      e.mem[_t_18 + 4] = _h_30;
      e.mem[_t_18 + 5] = _h_31;
      e.mem[_t_18 + 6] = _h_32;
      WL_CONT = term_tsk(FID_MERGE_K137, _t_18);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_FRAGMENT)) {
      u64 _t_19 = task_node(e, FID_FRAGMENT, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _value_22;
      e.mem[_t_19 + 1] = _value_23;
      return term_tsk(FID_FRAGMENT, _t_19);
    }
    r0 = _value_22;
    r1 = _value_23;
    WL_JMP(FID_FRAGMENT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K137)
  {
    WL_POPN(7);
    u32 _value_24 = STK(0);
    u32 _value_25 = STK(1);
    Term _value_26 = STK(2);
    Term _value_27 = STK(3);
    Term _h_36 = STK(4);
    Term _h_37 = STK(5);
    Term _h_38 = STK(6);
    Term _h_33 = r0;
    Term _h_34 = r1;
    Term _h_35 = r2;
    WL_OPEN
    _value_26 = term_keep(e, _value_26, 1);
    _value_27 = term_keep(e, _value_27, 1);
    if (seq) {
      WL_ROOM(11);
      STK(0) = _value_24;
      STK(1) = _value_25;
      STK(2) = _value_26;
      STK(3) = _value_27;
      STK(4) = _h_36;
      STK(5) = _h_37;
      STK(6) = _h_38;
      STK(7) = _h_33;
      STK(8) = _h_34;
      STK(9) = _h_35;
      STK(10) = FID_MERGE_K138;
      WL_PUSHN(11);
    } else {
      u64 _t_20 = task_node(e, FID_MERGE_K138, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _value_24;
      e.mem[_t_20 + 1] = _value_25;
      e.mem[_t_20 + 2] = _value_26;
      e.mem[_t_20 + 3] = _value_27;
      e.mem[_t_20 + 4] = _h_36;
      e.mem[_t_20 + 5] = _h_37;
      e.mem[_t_20 + 6] = _h_38;
      e.mem[_t_20 + 7] = _h_33;
      e.mem[_t_20 + 8] = _h_34;
      e.mem[_t_20 + 9] = _h_35;
      WL_CONT = term_tsk(FID_MERGE_K138, _t_20);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ERROR)) {
      u64 _t_21 = task_node(e, FID_ERROR, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _value_24;
      e.mem[_t_21 + 1] = _value_25;
      e.mem[_t_21 + 2] = _value_26;
      e.mem[_t_21 + 3] = _value_27;
      return term_tsk(FID_ERROR, _t_21);
    }
    r0 = _value_24;
    r1 = _value_25;
    r2 = _value_26;
    r3 = _value_27;
    WL_JMP(FID_ERROR);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K138)
  {
    WL_POPN(10);
    u32 _value_28 = STK(0);
    u32 _value_29 = STK(1);
    Term _value_30 = STK(2);
    Term _value_31 = STK(3);
    Term _h_40 = STK(4);
    Term _h_41 = STK(5);
    Term _h_42 = STK(6);
    Term _h_43 = STK(7);
    Term _h_44 = STK(8);
    Term _h_45 = STK(9);
    Term _h_39 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _value_28;
      STK(1) = _value_29;
      STK(2) = _value_30;
      STK(3) = _value_31;
      STK(4) = _h_40;
      STK(5) = _h_41;
      STK(6) = _h_42;
      STK(7) = _h_43;
      STK(8) = _h_44;
      STK(9) = _h_39;
      STK(10) = FID_MERGE_K139;
      WL_PUSHN(11);
    } else {
      u64 _t_22 = task_node(e, FID_MERGE_K139, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _value_28;
      e.mem[_t_22 + 1] = _value_29;
      e.mem[_t_22 + 2] = _value_30;
      e.mem[_t_22 + 3] = _value_31;
      e.mem[_t_22 + 4] = _h_40;
      e.mem[_t_22 + 5] = _h_41;
      e.mem[_t_22 + 6] = _h_42;
      e.mem[_t_22 + 7] = _h_43;
      e.mem[_t_22 + 8] = _h_44;
      e.mem[_t_22 + 9] = _h_39;
      WL_CONT = term_tsk(FID_MERGE_K139, _t_22);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 158);
      e.mem[_t_23 + 1] = _h_45;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 158);
    r1 = _h_45;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K139)
  {
    WL_POPN(10);
    u32 _value_32 = STK(0);
    u32 _value_33 = STK(1);
    Term _value_34 = STK(2);
    Term _value_35 = STK(3);
    Term _h_47 = STK(4);
    Term _h_48 = STK(5);
    Term _h_49 = STK(6);
    Term _h_50 = STK(7);
    Term _h_51 = STK(8);
    Term _h_52 = STK(9);
    Term _h_46 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _value_32;
      STK(1) = _value_33;
      STK(2) = _value_34;
      STK(3) = _value_35;
      STK(4) = _h_47;
      STK(5) = _h_48;
      STK(6) = _h_50;
      STK(7) = _h_51;
      STK(8) = _h_52;
      STK(9) = FID_MERGE_K140;
      WL_PUSHN(10);
    } else {
      u64 _t_24 = task_node(e, FID_MERGE_K140, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _value_32;
      e.mem[_t_24 + 1] = _value_33;
      e.mem[_t_24 + 2] = _value_34;
      e.mem[_t_24 + 3] = _value_35;
      e.mem[_t_24 + 4] = _h_47;
      e.mem[_t_24 + 5] = _h_48;
      e.mem[_t_24 + 6] = _h_50;
      e.mem[_t_24 + 7] = _h_51;
      e.mem[_t_24 + 8] = _h_52;
      WL_CONT = term_tsk(FID_MERGE_K140, _t_24);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _h_49;
      e.mem[_t_25 + 1] = _h_46;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = _h_49;
    r1 = _h_46;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K140)
  {
    WL_POPN(9);
    u32 _value_36 = STK(0);
    u32 _value_37 = STK(1);
    Term _value_38 = STK(2);
    Term _value_39 = STK(3);
    Term _h_54 = STK(4);
    Term _h_55 = STK(5);
    Term _h_56 = STK(6);
    Term _h_57 = STK(7);
    Term _h_58 = STK(8);
    Term _h_53 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _value_36;
      STK(1) = _value_37;
      STK(2) = _value_38;
      STK(3) = _value_39;
      STK(4) = _h_54;
      STK(5) = _h_55;
      STK(6) = _h_56;
      STK(7) = _h_57;
      STK(8) = _h_58;
      STK(9) = FID_MERGE_K141;
      WL_PUSHN(10);
    } else {
      u64 _t_26 = task_node(e, FID_MERGE_K141, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _value_36;
      e.mem[_t_26 + 1] = _value_37;
      e.mem[_t_26 + 2] = _value_38;
      e.mem[_t_26 + 3] = _value_39;
      e.mem[_t_26 + 4] = _h_54;
      e.mem[_t_26 + 5] = _h_55;
      e.mem[_t_26 + 6] = _h_56;
      e.mem[_t_26 + 7] = _h_57;
      e.mem[_t_26 + 8] = _h_58;
      WL_CONT = term_tsk(FID_MERGE_K141, _t_26);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = term_ctr(CID_SCON, STAT_OFF + 166);
      e.mem[_t_27 + 1] = _h_53;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 166);
    r1 = _h_53;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K141)
  {
    WL_POPN(9);
    u32 _value_40 = STK(0);
    u32 _value_41 = STK(1);
    Term _value_42 = STK(2);
    Term _value_43 = STK(3);
    Term _h_60 = STK(4);
    Term _h_61 = STK(5);
    Term _h_62 = STK(6);
    Term _h_63 = STK(7);
    Term _h_64 = STK(8);
    Term _h_59 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _value_40;
      STK(1) = _value_41;
      STK(2) = _value_42;
      STK(3) = _value_43;
      STK(4) = _h_60;
      STK(5) = _h_61;
      STK(6) = _h_62;
      STK(7) = _h_63;
      STK(8) = FID_MERGE_K142;
      WL_PUSHN(9);
    } else {
      u64 _t_28 = task_node(e, FID_MERGE_K142, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _value_40;
      e.mem[_t_28 + 1] = _value_41;
      e.mem[_t_28 + 2] = _value_42;
      e.mem[_t_28 + 3] = _value_43;
      e.mem[_t_28 + 4] = _h_60;
      e.mem[_t_28 + 5] = _h_61;
      e.mem[_t_28 + 6] = _h_62;
      e.mem[_t_28 + 7] = _h_63;
      WL_CONT = term_tsk(FID_MERGE_K142, _t_28);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _h_64;
      e.mem[_t_29 + 1] = _h_59;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = _h_64;
    r1 = _h_59;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MERGE_K142)
  {
    WL_POPN(8);
    u32 _value_44 = STK(0);
    u32 _value_45 = STK(1);
    Term _value_46 = STK(2);
    Term _value_47 = STK(3);
    Term _h_66 = STK(4);
    Term _h_67 = STK(5);
    Term _h_68 = STK(6);
    Term _h_69 = STK(7);
    Term _h_65 = r0;
    WL_OPEN
    r0 = 1;
    r1 = _value_44;
    r2 = _value_45;
    r3 = _value_46;
    r4 = _value_47;
    r5 = _h_66;
    r6 = _h_67;
    r7 = _h_68;
    r8 = _h_69;
    r9 = _h_65;
    WL_RETN(10);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0)
  {
    Term _values_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      if (term_aux(_f_0) == CID_SCHEMA_FRAGMENTS_ENTRY) {
        _o_0 = 0;
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
        _o_3 = _f_4;
      } else {
        _o_0 = 1;
        Term _fb_2[4];
        u64 _sp_2 = ctr_take(e, _f_0, 4, _fb_2);
        u32 _f_5 = _fb_2[0];
        Term _f_6 = _fb_2[1];
        Term _f_7 = _fb_2[2];
        u32 _f_8 = _fb_2[3];
        spare_free(e, cls_fit(4), _sp_2);
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(6);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = _o_2;
        STK(3) = _o_3;
        STK(4) = _o_4;
        STK(5) = FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0_K145;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0_K145, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        e.mem[_t_0 + 2] = _o_2;
        e.mem[_t_0 + 3] = _o_3;
        e.mem[_t_0 + 4] = _o_4;
        WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0_K145, _t_0);
        WL_IDX = 5;
      }
      r0 = _f_1;
      _values_0 = r0;
      WL_AGAIN(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0_K145)
  {
    WL_POPN(5);
    u32 _o_5 = STK(0);
    u32 _o_6 = STK(1);
    Term _o_7 = STK(2);
    Term _o_8 = STK(3);
    u32 _o_9 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _o_10[5];
    if (spin_7(e, _o_10, _o_5, _o_6, _o_7, _o_8, _o_9) == 0) {
      return 0;
    }
    _v_5 = _o_10[0];
    _v_6 = _o_10[1];
    _v_7 = _o_10[2];
    _v_8 = _o_10[3];
    _v_9 = _o_10[4];
    _v_0 = _v_5;
    _v_1 = _v_6;
    _v_2 = _v_7;
    _v_3 = _v_8;
    _v_4 = _v_9;
    Term _b_0 = 0;
    if (_v_0 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_0 + 2] = rfc_seal(e, _v_3);
      _b_0 = term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, _nd_0);
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
      e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
      e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
      _b_0 = term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_1);
    }
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0)
  {
    Term _required_0 = r0;
    Term _entries_0 = r1;
    WL_OPEN
    if (term_aux(_required_0) == CID_NIL) {
      term_sink(e, _entries_0);
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = 0;
      r4 = 0;
      WL_RETN(5);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _required_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      if (term_aux(_f_0) == CID_SCHEMA_FRAGMENTS_ENTRY) {
        _o_0 = 0;
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
        _o_3 = _f_4;
      } else {
        _o_0 = 1;
        Term _fb_2[4];
        u64 _sp_2 = ctr_take(e, _f_0, 4, _fb_2);
        u32 _f_5 = _fb_2[0];
        Term _f_6 = _fb_2[1];
        Term _f_7 = _fb_2[2];
        u32 _f_8 = _fb_2[3];
        spare_free(e, cls_fit(4), _sp_2);
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
      }
      _entries_0 = term_keep(e, _entries_0, 1);
      _o_2 = term_keep(e, _o_2, 1);
      _o_3 = term_keep(e, _o_3, 1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(8);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = _o_2;
        STK(3) = _o_3;
        STK(4) = _o_4;
        STK(5) = _f_1;
        STK(6) = _entries_0;
        STK(7) = FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K147;
        WL_PUSHN(8);
      } else {
        u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K147, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        e.mem[_t_0 + 2] = _o_2;
        e.mem[_t_0 + 3] = _o_3;
        e.mem[_t_0 + 4] = _o_4;
        e.mem[_t_0 + 5] = _f_1;
        e.mem[_t_0 + 6] = _entries_0;
        WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K147, _t_0);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0)) {
        u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _entries_0;
        e.mem[_t_1 + 1] = _o_0;
        e.mem[_t_1 + 2] = _o_1;
        e.mem[_t_1 + 3] = _o_2;
        e.mem[_t_1 + 4] = _o_3;
        e.mem[_t_1 + 5] = _o_4;
        return term_tsk(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0, _t_1);
      }
      r0 = _entries_0;
      r1 = _o_0;
      r2 = _o_1;
      r3 = _o_2;
      r4 = _o_3;
      r5 = _o_4;
      WL_JMP(FID_SCHEMA_FRAGMENTS_DESCRIPTOR_PRESENT_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K147)
  {
    WL_POPN(7);
    u32 _o_5 = STK(0);
    u32 _o_6 = STK(1);
    Term _o_7 = STK(2);
    Term _o_8 = STK(3);
    u32 _o_9 = STK(4);
    Term _f_9 = STK(5);
    Term _entries_1 = STK(6);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _o_12[5];
    if (spin_15(e, _o_12, _h_0, _o_5, _o_6, _o_7, _o_8, _o_9) == 0) {
      return 0;
    }
    _v_5 = _o_12[0];
    _v_6 = _o_12[1];
    _v_7 = _o_12[2];
    _v_8 = _o_12[3];
    _v_9 = _o_12[4];
    _v_0 = _v_5;
    _v_1 = _v_6;
    _v_2 = _v_7;
    _v_3 = _v_8;
    _v_4 = _v_9;
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_9;
    e.mem[_nd_0 + 1] = _entries_1;
    if (_v_0 == 1) {
      Term _next_0 = term_clo(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_C148, _nd_0);
      term_sink(e, _next_0);
      r0 = 1;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      WL_RETN(5);
    } else {
      Term _next_1 = term_clo(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_C148, _nd_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K150;
        WL_PUSHN(1);
      } else {
        u64 _t_4 = task_node(e, FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K150, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K150, _t_4);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_5 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _next_1;
        e.mem[_t_5 + 1] = term_pak(CID_UNIT, 0);
        return term_tsk(FID_CLO_APPLY, _t_5);
      }
      r0 = _next_1;
      r1 = term_pak(CID_UNIT, 0);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_C148)
  {
    Term _f_10 = r0;
    Term _entries_2 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K149;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K149, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K149, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0)) {
      u64 _t_3 = task_node(e, FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_10;
      e.mem[_t_3 + 1] = _entries_2;
      return term_tsk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0, _t_3);
    }
    r0 = _f_10;
    r1 = _entries_2;
    WL_JMP(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K149)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    u32 _r_2 = r2;
    Term _r_3 = r3;
    Term _r_4 = r4;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      _b_0 = term_pak(CID_SCHEMA_FRAGMENTS_VALID, 0);
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_1 + 0] = _r_1;
      e.mem[_nd_1 + 1] = _r_2;
      e.mem[_nd_1 + 2] = _r_3;
      e.mem[_nd_1 + 3] = _r_4;
      _b_0 = term_ctr(CID_SCHEMA_FRAGMENTS_INVALID, _nd_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0_K150)
  {
    Term _r_5 = r0;
    WL_OPEN
    u32 _o_13 = 0;
    u32 _o_14 = 0;
    u32 _o_15 = 0;
    Term _o_16 = 0;
    Term _o_17 = 0;
    if (term_aux(_r_5) == CID_SCHEMA_FRAGMENTS_VALID) {
      _o_13 = 0;
    } else {
      _o_13 = 1;
      u64 _sp_3 = term_loc(_r_5);
      u32 _f_11 = e.mem[_sp_3 + 0];
      u32 _f_12 = e.mem[_sp_3 + 1];
      Term _f_13 = e.mem[_sp_3 + 2];
      Term _f_14 = e.mem[_sp_3 + 3];
      heap_free(e, cls_fit(4), _sp_3);
      _o_14 = _f_11;
      _o_15 = _f_12;
      _o_16 = _f_13;
      _o_17 = _f_14;
    }
    r0 = _o_13;
    r1 = _o_14;
    r2 = _o_15;
    r3 = _o_16;
    r4 = _o_17;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0)
  {
    Term _entries_0 = r0;
    WL_OPEN
    _entries_0 = term_keep(e, _entries_0, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _entries_0;
      STK(1) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K152;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K152, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _entries_0;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K152, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0)) {
      u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _entries_0;
      e.mem[_t_1 + 1] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, _t_1);
    }
    r0 = _entries_0;
    r1 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K152)
  {
    WL_POPN(1);
    Term _entries_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _entries_1;
      STK(1) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K153;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K153, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _entries_1;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K153, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0)) {
      u64 _t_3 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, _t_3);
    }
    r0 = _h_0;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K153)
  {
    WL_POPN(1);
    Term _entries_2 = STK(0);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    u32 _h_3 = r2;
    Term _h_4 = r3;
    Term _h_5 = r4;
    WL_OPEN
    _entries_2 = term_keep(e, _entries_2, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _entries_2;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = _h_3;
      STK(4) = _h_4;
      STK(5) = _h_5;
      STK(6) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K154;
      WL_PUSHN(7);
    } else {
      u64 _t_4 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K154, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _entries_2;
      e.mem[_t_4 + 1] = _h_1;
      e.mem[_t_4 + 2] = _h_2;
      e.mem[_t_4 + 3] = _h_3;
      e.mem[_t_4 + 4] = _h_4;
      e.mem[_t_4 + 5] = _h_5;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K154, _t_4);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0)) {
      u64 _t_5 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _entries_2;
      e.mem[_t_5 + 1] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, _t_5);
    }
    r0 = _entries_2;
    r1 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K154)
  {
    WL_POPN(6);
    Term _entries_3 = STK(0);
    u32 _h_7 = STK(1);
    u32 _h_8 = STK(2);
    u32 _h_9 = STK(3);
    Term _h_10 = STK(4);
    Term _h_11 = STK(5);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _entries_3;
      STK(1) = _h_7;
      STK(2) = _h_8;
      STK(3) = _h_9;
      STK(4) = _h_10;
      STK(5) = _h_11;
      STK(6) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K155;
      WL_PUSHN(7);
    } else {
      u64 _t_6 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K155, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _entries_3;
      e.mem[_t_6 + 1] = _h_7;
      e.mem[_t_6 + 2] = _h_8;
      e.mem[_t_6 + 3] = _h_9;
      e.mem[_t_6 + 4] = _h_10;
      e.mem[_t_6 + 5] = _h_11;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K155, _t_6);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0)) {
      u64 _t_7 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_6;
      e.mem[_t_7 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, _t_7);
    }
    r0 = _h_6;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K155)
  {
    WL_POPN(6);
    Term _entries_4 = STK(0);
    u32 _h_17 = STK(1);
    u32 _h_18 = STK(2);
    u32 _h_19 = STK(3);
    Term _h_20 = STK(4);
    Term _h_21 = STK(5);
    u32 _h_12 = r0;
    u32 _h_13 = r1;
    u32 _h_14 = r2;
    Term _h_15 = r3;
    Term _h_16 = r4;
    WL_OPEN
    _entries_4 = term_keep(e, _entries_4, 1);
    if (seq) {
      WL_ROOM(12);
      STK(0) = _entries_4;
      STK(1) = _h_17;
      STK(2) = _h_18;
      STK(3) = _h_19;
      STK(4) = _h_20;
      STK(5) = _h_21;
      STK(6) = _h_12;
      STK(7) = _h_13;
      STK(8) = _h_14;
      STK(9) = _h_15;
      STK(10) = _h_16;
      STK(11) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K156;
      WL_PUSHN(12);
    } else {
      u64 _t_8 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K156, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _entries_4;
      e.mem[_t_8 + 1] = _h_17;
      e.mem[_t_8 + 2] = _h_18;
      e.mem[_t_8 + 3] = _h_19;
      e.mem[_t_8 + 4] = _h_20;
      e.mem[_t_8 + 5] = _h_21;
      e.mem[_t_8 + 6] = _h_12;
      e.mem[_t_8 + 7] = _h_13;
      e.mem[_t_8 + 8] = _h_14;
      e.mem[_t_8 + 9] = _h_15;
      e.mem[_t_8 + 10] = _h_16;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K156, _t_8);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0)) {
      u64 _t_9 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _entries_4;
      e.mem[_t_9 + 1] = 2;
      return term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, _t_9);
    }
    r0 = _entries_4;
    r1 = 2;
    WL_JMP(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K156)
  {
    WL_POPN(11);
    Term _entries_5 = STK(0);
    u32 _h_23 = STK(1);
    u32 _h_24 = STK(2);
    u32 _h_25 = STK(3);
    Term _h_26 = STK(4);
    Term _h_27 = STK(5);
    u32 _h_28 = STK(6);
    u32 _h_29 = STK(7);
    u32 _h_30 = STK(8);
    Term _h_31 = STK(9);
    Term _h_32 = STK(10);
    Term _h_22 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _entries_5;
      STK(1) = _h_23;
      STK(2) = _h_24;
      STK(3) = _h_25;
      STK(4) = _h_26;
      STK(5) = _h_27;
      STK(6) = _h_28;
      STK(7) = _h_29;
      STK(8) = _h_30;
      STK(9) = _h_31;
      STK(10) = _h_32;
      STK(11) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K157;
      WL_PUSHN(12);
    } else {
      u64 _t_10 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K157, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _entries_5;
      e.mem[_t_10 + 1] = _h_23;
      e.mem[_t_10 + 2] = _h_24;
      e.mem[_t_10 + 3] = _h_25;
      e.mem[_t_10 + 4] = _h_26;
      e.mem[_t_10 + 5] = _h_27;
      e.mem[_t_10 + 6] = _h_28;
      e.mem[_t_10 + 7] = _h_29;
      e.mem[_t_10 + 8] = _h_30;
      e.mem[_t_10 + 9] = _h_31;
      e.mem[_t_10 + 10] = _h_32;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K157, _t_10);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0)) {
      u64 _t_11 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_22;
      e.mem[_t_11 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, _t_11);
    }
    r0 = _h_22;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K157)
  {
    WL_POPN(11);
    Term _entries_6 = STK(0);
    u32 _h_38 = STK(1);
    u32 _h_39 = STK(2);
    u32 _h_40 = STK(3);
    Term _h_41 = STK(4);
    Term _h_42 = STK(5);
    u32 _h_43 = STK(6);
    u32 _h_44 = STK(7);
    u32 _h_45 = STK(8);
    Term _h_46 = STK(9);
    Term _h_47 = STK(10);
    u32 _h_33 = r0;
    u32 _h_34 = r1;
    u32 _h_35 = r2;
    Term _h_36 = r3;
    Term _h_37 = r4;
    WL_OPEN
    _entries_6 = term_keep(e, _entries_6, 1);
    if (seq) {
      WL_ROOM(17);
      STK(0) = _entries_6;
      STK(1) = _h_38;
      STK(2) = _h_39;
      STK(3) = _h_40;
      STK(4) = _h_41;
      STK(5) = _h_42;
      STK(6) = _h_43;
      STK(7) = _h_44;
      STK(8) = _h_45;
      STK(9) = _h_46;
      STK(10) = _h_47;
      STK(11) = _h_33;
      STK(12) = _h_34;
      STK(13) = _h_35;
      STK(14) = _h_36;
      STK(15) = _h_37;
      STK(16) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K158;
      WL_PUSHN(17);
    } else {
      u64 _t_12 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K158, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _entries_6;
      e.mem[_t_12 + 1] = _h_38;
      e.mem[_t_12 + 2] = _h_39;
      e.mem[_t_12 + 3] = _h_40;
      e.mem[_t_12 + 4] = _h_41;
      e.mem[_t_12 + 5] = _h_42;
      e.mem[_t_12 + 6] = _h_43;
      e.mem[_t_12 + 7] = _h_44;
      e.mem[_t_12 + 8] = _h_45;
      e.mem[_t_12 + 9] = _h_46;
      e.mem[_t_12 + 10] = _h_47;
      e.mem[_t_12 + 11] = _h_33;
      e.mem[_t_12 + 12] = _h_34;
      e.mem[_t_12 + 13] = _h_35;
      e.mem[_t_12 + 14] = _h_36;
      e.mem[_t_12 + 15] = _h_37;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K158, _t_12);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0)) {
      u64 _t_13 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _entries_6;
      e.mem[_t_13 + 1] = 3;
      return term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, _t_13);
    }
    r0 = _entries_6;
    r1 = 3;
    WL_JMP(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K158)
  {
    WL_POPN(16);
    Term _entries_7 = STK(0);
    u32 _h_49 = STK(1);
    u32 _h_50 = STK(2);
    u32 _h_51 = STK(3);
    Term _h_52 = STK(4);
    Term _h_53 = STK(5);
    u32 _h_54 = STK(6);
    u32 _h_55 = STK(7);
    u32 _h_56 = STK(8);
    Term _h_57 = STK(9);
    Term _h_58 = STK(10);
    u32 _h_59 = STK(11);
    u32 _h_60 = STK(12);
    u32 _h_61 = STK(13);
    Term _h_62 = STK(14);
    Term _h_63 = STK(15);
    Term _h_48 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _entries_7;
      STK(1) = _h_49;
      STK(2) = _h_50;
      STK(3) = _h_51;
      STK(4) = _h_52;
      STK(5) = _h_53;
      STK(6) = _h_54;
      STK(7) = _h_55;
      STK(8) = _h_56;
      STK(9) = _h_57;
      STK(10) = _h_58;
      STK(11) = _h_59;
      STK(12) = _h_60;
      STK(13) = _h_61;
      STK(14) = _h_62;
      STK(15) = _h_63;
      STK(16) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K159;
      WL_PUSHN(17);
    } else {
      u64 _t_14 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K159, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _entries_7;
      e.mem[_t_14 + 1] = _h_49;
      e.mem[_t_14 + 2] = _h_50;
      e.mem[_t_14 + 3] = _h_51;
      e.mem[_t_14 + 4] = _h_52;
      e.mem[_t_14 + 5] = _h_53;
      e.mem[_t_14 + 6] = _h_54;
      e.mem[_t_14 + 7] = _h_55;
      e.mem[_t_14 + 8] = _h_56;
      e.mem[_t_14 + 9] = _h_57;
      e.mem[_t_14 + 10] = _h_58;
      e.mem[_t_14 + 11] = _h_59;
      e.mem[_t_14 + 12] = _h_60;
      e.mem[_t_14 + 13] = _h_61;
      e.mem[_t_14 + 14] = _h_62;
      e.mem[_t_14 + 15] = _h_63;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K159, _t_14);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0)) {
      u64 _t_15 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_48;
      e.mem[_t_15 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, _t_15);
    }
    r0 = _h_48;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K159)
  {
    WL_POPN(16);
    Term _entries_8 = STK(0);
    u32 _h_69 = STK(1);
    u32 _h_70 = STK(2);
    u32 _h_71 = STK(3);
    Term _h_72 = STK(4);
    Term _h_73 = STK(5);
    u32 _h_74 = STK(6);
    u32 _h_75 = STK(7);
    u32 _h_76 = STK(8);
    Term _h_77 = STK(9);
    Term _h_78 = STK(10);
    u32 _h_79 = STK(11);
    u32 _h_80 = STK(12);
    u32 _h_81 = STK(13);
    Term _h_82 = STK(14);
    Term _h_83 = STK(15);
    u32 _h_64 = r0;
    u32 _h_65 = r1;
    u32 _h_66 = r2;
    Term _h_67 = r3;
    Term _h_68 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_69;
      STK(1) = _h_70;
      STK(2) = _h_71;
      STK(3) = _h_72;
      STK(4) = _h_73;
      STK(5) = _h_74;
      STK(6) = _h_75;
      STK(7) = _h_76;
      STK(8) = _h_77;
      STK(9) = _h_78;
      STK(10) = _h_79;
      STK(11) = _h_80;
      STK(12) = _h_81;
      STK(13) = _h_82;
      STK(14) = _h_83;
      STK(15) = _h_64;
      STK(16) = _h_65;
      STK(17) = _h_66;
      STK(18) = _h_67;
      STK(19) = _h_68;
      STK(20) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K160;
      WL_PUSHN(21);
    } else {
      u64 _t_16 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K160, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_69;
      e.mem[_t_16 + 1] = _h_70;
      e.mem[_t_16 + 2] = _h_71;
      e.mem[_t_16 + 3] = _h_72;
      e.mem[_t_16 + 4] = _h_73;
      e.mem[_t_16 + 5] = _h_74;
      e.mem[_t_16 + 6] = _h_75;
      e.mem[_t_16 + 7] = _h_76;
      e.mem[_t_16 + 8] = _h_77;
      e.mem[_t_16 + 9] = _h_78;
      e.mem[_t_16 + 10] = _h_79;
      e.mem[_t_16 + 11] = _h_80;
      e.mem[_t_16 + 12] = _h_81;
      e.mem[_t_16 + 13] = _h_82;
      e.mem[_t_16 + 14] = _h_83;
      e.mem[_t_16 + 15] = _h_64;
      e.mem[_t_16 + 16] = _h_65;
      e.mem[_t_16 + 17] = _h_66;
      e.mem[_t_16 + 18] = _h_67;
      e.mem[_t_16 + 19] = _h_68;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K160, _t_16);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0)) {
      u64 _t_17 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _entries_8;
      e.mem[_t_17 + 1] = 4;
      return term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, _t_17);
    }
    r0 = _entries_8;
    r1 = 4;
    WL_JMP(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K160)
  {
    WL_POPN(20);
    u32 _h_85 = STK(0);
    u32 _h_86 = STK(1);
    u32 _h_87 = STK(2);
    Term _h_88 = STK(3);
    Term _h_89 = STK(4);
    u32 _h_90 = STK(5);
    u32 _h_91 = STK(6);
    u32 _h_92 = STK(7);
    Term _h_93 = STK(8);
    Term _h_94 = STK(9);
    u32 _h_95 = STK(10);
    u32 _h_96 = STK(11);
    u32 _h_97 = STK(12);
    Term _h_98 = STK(13);
    Term _h_99 = STK(14);
    u32 _h_100 = STK(15);
    u32 _h_101 = STK(16);
    u32 _h_102 = STK(17);
    Term _h_103 = STK(18);
    Term _h_104 = STK(19);
    Term _h_84 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_85;
      STK(1) = _h_86;
      STK(2) = _h_87;
      STK(3) = _h_88;
      STK(4) = _h_89;
      STK(5) = _h_90;
      STK(6) = _h_91;
      STK(7) = _h_92;
      STK(8) = _h_93;
      STK(9) = _h_94;
      STK(10) = _h_95;
      STK(11) = _h_96;
      STK(12) = _h_97;
      STK(13) = _h_98;
      STK(14) = _h_99;
      STK(15) = _h_100;
      STK(16) = _h_101;
      STK(17) = _h_102;
      STK(18) = _h_103;
      STK(19) = _h_104;
      STK(20) = FID_SCHEMA_FRAGMENTS_VALIDATE_0_K161;
      WL_PUSHN(21);
    } else {
      u64 _t_18 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0_K161, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_85;
      e.mem[_t_18 + 1] = _h_86;
      e.mem[_t_18 + 2] = _h_87;
      e.mem[_t_18 + 3] = _h_88;
      e.mem[_t_18 + 4] = _h_89;
      e.mem[_t_18 + 5] = _h_90;
      e.mem[_t_18 + 6] = _h_91;
      e.mem[_t_18 + 7] = _h_92;
      e.mem[_t_18 + 8] = _h_93;
      e.mem[_t_18 + 9] = _h_94;
      e.mem[_t_18 + 10] = _h_95;
      e.mem[_t_18 + 11] = _h_96;
      e.mem[_t_18 + 12] = _h_97;
      e.mem[_t_18 + 13] = _h_98;
      e.mem[_t_18 + 14] = _h_99;
      e.mem[_t_18 + 15] = _h_100;
      e.mem[_t_18 + 16] = _h_101;
      e.mem[_t_18 + 17] = _h_102;
      e.mem[_t_18 + 18] = _h_103;
      e.mem[_t_18 + 19] = _h_104;
      WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K161, _t_18);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0)) {
      u64 _t_19 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_84;
      e.mem[_t_19 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0, _t_19);
    }
    r0 = _h_84;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_VALIDATE_0_K161)
  {
    WL_POPN(20);
    u32 _h_110 = STK(0);
    u32 _h_111 = STK(1);
    u32 _h_112 = STK(2);
    Term _h_113 = STK(3);
    Term _h_114 = STK(4);
    u32 _h_115 = STK(5);
    u32 _h_116 = STK(6);
    u32 _h_117 = STK(7);
    Term _h_118 = STK(8);
    Term _h_119 = STK(9);
    u32 _h_120 = STK(10);
    u32 _h_121 = STK(11);
    u32 _h_122 = STK(12);
    Term _h_123 = STK(13);
    Term _h_124 = STK(14);
    u32 _h_125 = STK(15);
    u32 _h_126 = STK(16);
    u32 _h_127 = STK(17);
    Term _h_128 = STK(18);
    Term _h_129 = STK(19);
    u32 _h_105 = r0;
    u32 _h_106 = r1;
    u32 _h_107 = r2;
    Term _h_108 = r3;
    Term _h_109 = r4;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _o_0[5];
    if (spin_13(e, _o_0, _h_125, _h_126, _h_127, _h_128, _h_129, _h_105, _h_106, _h_107, _h_108, _h_109) == 0) {
      return 0;
    }
    _v_15 = _o_0[0];
    _v_16 = _o_0[1];
    _v_17 = _o_0[2];
    _v_18 = _o_0[3];
    _v_19 = _o_0[4];
    _v_10 = _v_15;
    _v_11 = _v_16;
    _v_12 = _v_17;
    _v_13 = _v_18;
    _v_14 = _v_19;
    u32 _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _o_1[5];
    if (spin_13(e, _o_1, _h_120, _h_121, _h_122, _h_123, _h_124, _v_10, _v_11, _v_12, _v_13, _v_14) == 0) {
      return 0;
    }
    _v_20 = _o_1[0];
    _v_21 = _o_1[1];
    _v_22 = _o_1[2];
    _v_23 = _o_1[3];
    _v_24 = _o_1[4];
    _v_5 = _v_20;
    _v_6 = _v_21;
    _v_7 = _v_22;
    _v_8 = _v_23;
    _v_9 = _v_24;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _o_2[5];
    if (spin_13(e, _o_2, _h_115, _h_116, _h_117, _h_118, _h_119, _v_5, _v_6, _v_7, _v_8, _v_9) == 0) {
      return 0;
    }
    _v_25 = _o_2[0];
    _v_26 = _o_2[1];
    _v_27 = _o_2[2];
    _v_28 = _o_2[3];
    _v_29 = _o_2[4];
    _v_0 = _v_25;
    _v_1 = _v_26;
    _v_2 = _v_27;
    _v_3 = _v_28;
    _v_4 = _v_29;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _o_3[5];
    if (spin_13(e, _o_3, _h_110, _h_111, _h_112, _h_113, _h_114, _v_0, _v_1, _v_2, _v_3, _v_4) == 0) {
      return 0;
    }
    _v_30 = _o_3[0];
    _v_31 = _o_3[1];
    _v_32 = _o_3[2];
    _v_33 = _o_3[3];
    _v_34 = _o_3[4];
    r0 = _v_30;
    r1 = _v_31;
    r2 = _v_32;
    r3 = _v_33;
    r4 = _v_34;
    WL_RETN(5);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_VALIDATION)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    Term _value_3 = r3;
    Term _value_4 = r4;
    WL_OPEN
    if (_value_0 == 0) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 260);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_ERROR)) {
        u64 _t_0 = task_node(e, FID_ERROR, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _value_1;
        e.mem[_t_0 + 1] = _value_2;
        e.mem[_t_0 + 2] = _value_3;
        e.mem[_t_0 + 3] = _value_4;
        return term_tsk(FID_ERROR, _t_0);
      }
      r0 = _value_1;
      r1 = _value_2;
      r2 = _value_3;
      r3 = _value_4;
      WL_JMP(FID_ERROR);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0)
  {
    Term _xs_0 = r0;
    u32 _kind_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      if (term_aux(_f_0) == CID_SCHEMA_FRAGMENTS_ENTRY) {
        _o_0 = 0;
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
        _o_3 = _f_4;
      } else {
        _o_0 = 1;
        Term _fb_2[4];
        u64 _sp_2 = ctr_take(e, _f_0, 4, _fb_2);
        u32 _f_5 = _fb_2[0];
        Term _f_6 = _fb_2[1];
        Term _f_7 = _fb_2[2];
        u32 _f_8 = _fb_2[3];
        spare_free(e, cls_fit(4), _sp_2);
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
      }
      if (_o_0 == 0) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(5);
          STK(0) = _o_1;
          STK(1) = _o_2;
          STK(2) = _o_3;
          STK(3) = _kind_0;
          STK(4) = FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K164;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K164, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          e.mem[_t_0 + 1] = _o_2;
          e.mem[_t_0 + 2] = _o_3;
          e.mem[_t_0 + 3] = _kind_0;
          WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K164, _t_0);
          WL_IDX = 4;
        }
        r0 = _f_1;
        r1 = _kind_0;
        _xs_0 = r0;
        _kind_0 = r1;
        WL_AGAIN(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
      } else {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(6);
          STK(0) = _o_1;
          STK(1) = _o_2;
          STK(2) = _o_3;
          STK(3) = _o_4;
          STK(4) = _kind_0;
          STK(5) = FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K165;
          WL_PUSHN(6);
        } else {
          u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K165, WL_CONT, WL_IDX, 1);
          e.mem[_t_1 + 0] = _o_1;
          e.mem[_t_1 + 1] = _o_2;
          e.mem[_t_1 + 2] = _o_3;
          e.mem[_t_1 + 3] = _o_4;
          e.mem[_t_1 + 4] = _kind_0;
          WL_CONT = term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K165, _t_1);
          WL_IDX = 5;
        }
        r0 = _f_1;
        r1 = _kind_0;
        _xs_0 = r0;
        _kind_0 = r1;
        WL_AGAIN(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K164)
  {
    WL_POPN(4);
    u32 _o_5 = STK(0);
    Term _o_6 = STK(1);
    Term _o_7 = STK(2);
    u32 _kind_1 = STK(3);
    Term _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_8[1];
    if (spin_4(e, _o_8, _kind_1, _o_5) == 0) {
      return 0;
    }
    _v_1 = _o_8[0];
    _v_0 = _v_1;
    Term _v_2 = 0;
    Term _o_9[1];
    if (spin_16(e, _o_9, _v_0, 0, _o_5, _o_6, _o_7, 0, _h_0) == 0) {
      return 0;
    }
    _v_2 = _o_9[0];
    r0 = _v_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0_K165)
  {
    WL_POPN(5);
    u32 _o_10 = STK(0);
    Term _o_11 = STK(1);
    Term _o_12 = STK(2);
    u32 _o_13 = STK(3);
    u32 _kind_2 = STK(4);
    Term _h_1 = r0;
    WL_OPEN
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _o_14[1];
    if (spin_4(e, _o_14, _kind_2, _o_10) == 0) {
      return 0;
    }
    _v_5 = _o_14[0];
    _v_4 = _v_5;
    Term _v_6 = 0;
    Term _o_15[1];
    if (spin_16(e, _o_15, _v_4, 1, _o_10, _o_11, _o_12, _o_13, _h_1) == 0) {
      return 0;
    }
    _v_6 = _o_15[0];
    r0 = _v_6;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRIES)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 264);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      u32 _o_4 = 0;
      if (term_aux(_f_0) == CID_SCHEMA_FRAGMENTS_ENTRY) {
        _o_0 = 0;
        Term _fb_1[3];
        u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        spare_free(e, cls_fit(3), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
        _o_3 = _f_4;
      } else {
        _o_0 = 1;
        Term _fb_2[4];
        u64 _sp_2 = ctr_take(e, _f_0, 4, _fb_2);
        u32 _f_5 = _fb_2[0];
        Term _f_6 = _fb_2[1];
        Term _f_7 = _fb_2[2];
        u32 _f_8 = _fb_2[3];
        spare_free(e, cls_fit(4), _sp_2);
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_ENTRIES_K167;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_ENTRIES_K167, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_ENTRIES_K167, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_ENTRY)) {
        u64 _t_1 = task_node(e, FID_ENTRY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _o_0;
        e.mem[_t_1 + 1] = _o_1;
        e.mem[_t_1 + 2] = _o_2;
        e.mem[_t_1 + 3] = _o_3;
        e.mem[_t_1 + 4] = _o_4;
        return term_tsk(FID_ENTRY, _t_1);
      }
      r0 = _o_0;
      r1 = _o_1;
      r2 = _o_2;
      r3 = _o_3;
      r4 = _o_4;
      WL_JMP(FID_ENTRY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRIES_K167)
  {
    WL_POPN(1);
    Term _f_9 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_ENTRIES_K168;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_ENTRIES_K168, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_ENTRIES_K168, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ENTRIES)) {
      u64 _t_3 = task_node(e, FID_ENTRIES, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_9;
      return term_tsk(FID_ENTRIES, _t_3);
    }
    r0 = _f_9;
    WL_JMP(FID_ENTRIES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRIES_K168)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_ENTRIES_K169;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_ENTRIES_K169, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_ENTRIES_K169, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 266);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 266);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ENTRIES_K169)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K171;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K171, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K171, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K171)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CONTROLS_K176;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_CONTROLS_K176, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CONTROLS_K176, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_1 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 1] = 0;
      e.mem[_t_1 + 2] = 0;
      e.mem[_t_1 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_1 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_1 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_1);
    }
    r0 = term_pak(CID_NIL, 0);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K176)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CONTROLS_K177;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_CONTROLS_K177, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CONTROLS_K177, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_3 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      return term_tsk(FID_VALIDATION, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K177)
  {
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CONTROLS_K178;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_CONTROLS_K178, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CONTROLS_K178, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 290);
      e.mem[_t_5 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 290);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K178)
  {
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_6;
      STK(1) = FID_CONTROLS_K179;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_CONTROLS_K179, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_6;
      WL_CONT = term_tsk(FID_CONTROLS_K179, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_7 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_7 + 1] = 0;
      e.mem[_t_7 + 2] = 0;
      e.mem[_t_7 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_7 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_7 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_7);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K179)
  {
    WL_POPN(1);
    Term _h_12 = STK(0);
    u32 _h_7 = r0;
    u32 _h_8 = r1;
    u32 _h_9 = r2;
    Term _h_10 = r3;
    Term _h_11 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_12;
      STK(1) = FID_CONTROLS_K180;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_CONTROLS_K180, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_12;
      WL_CONT = term_tsk(FID_CONTROLS_K180, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_9 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_7;
      e.mem[_t_9 + 1] = _h_8;
      e.mem[_t_9 + 2] = _h_9;
      e.mem[_t_9 + 3] = _h_10;
      e.mem[_t_9 + 4] = _h_11;
      return term_tsk(FID_VALIDATION, _t_9);
    }
    r0 = _h_7;
    r1 = _h_8;
    r2 = _h_9;
    r3 = _h_10;
    r4 = _h_11;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K180)
  {
    WL_POPN(1);
    Term _h_14 = STK(0);
    Term _h_13 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_14;
      STK(1) = FID_CONTROLS_K181;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_CONTROLS_K181, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_14;
      WL_CONT = term_tsk(FID_CONTROLS_K181, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 319);
      e.mem[_t_11 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 319);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K181)
  {
    WL_POPN(1);
    Term _h_16 = STK(0);
    Term _h_15 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_16;
      STK(1) = _h_15;
      STK(2) = FID_CONTROLS_K182;
      WL_PUSHN(3);
    } else {
      u64 _t_12 = task_node(e, FID_CONTROLS_K182, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_16;
      e.mem[_t_12 + 1] = _h_15;
      WL_CONT = term_tsk(FID_CONTROLS_K182, _t_12);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_13 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_13 + 1] = 0;
      e.mem[_t_13 + 2] = 0;
      e.mem[_t_13 + 3] = term_ctr(CID_SCON, STAT_OFF + 321);
      e.mem[_t_13 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_13 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_13);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 321);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K182)
  {
    WL_POPN(2);
    Term _h_22 = STK(0);
    Term _h_23 = STK(1);
    u32 _h_17 = r0;
    u32 _h_18 = r1;
    u32 _h_19 = r2;
    Term _h_20 = r3;
    Term _h_21 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_22;
      STK(1) = _h_23;
      STK(2) = FID_CONTROLS_K183;
      WL_PUSHN(3);
    } else {
      u64 _t_14 = task_node(e, FID_CONTROLS_K183, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_22;
      e.mem[_t_14 + 1] = _h_23;
      WL_CONT = term_tsk(FID_CONTROLS_K183, _t_14);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_15 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_17;
      e.mem[_t_15 + 1] = _h_18;
      e.mem[_t_15 + 2] = _h_19;
      e.mem[_t_15 + 3] = _h_20;
      e.mem[_t_15 + 4] = _h_21;
      return term_tsk(FID_VALIDATION, _t_15);
    }
    r0 = _h_17;
    r1 = _h_18;
    r2 = _h_19;
    r3 = _h_20;
    r4 = _h_21;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K183)
  {
    WL_POPN(2);
    Term _h_25 = STK(0);
    Term _h_26 = STK(1);
    Term _h_24 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_25;
      STK(1) = _h_26;
      STK(2) = FID_CONTROLS_K184;
      WL_PUSHN(3);
    } else {
      u64 _t_16 = task_node(e, FID_CONTROLS_K184, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_25;
      e.mem[_t_16 + 1] = _h_26;
      WL_CONT = term_tsk(FID_CONTROLS_K184, _t_16);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = term_ctr(CID_SCON, STAT_OFF + 339);
      e.mem[_t_17 + 1] = _h_24;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 339);
    r1 = _h_24;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K184)
  {
    WL_POPN(2);
    Term _h_28 = STK(0);
    Term _h_29 = STK(1);
    Term _h_27 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_28;
      STK(1) = _h_29;
      STK(2) = _h_27;
      STK(3) = FID_CONTROLS_K185;
      WL_PUSHN(4);
    } else {
      u64 _t_18 = task_node(e, FID_CONTROLS_K185, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_28;
      e.mem[_t_18 + 1] = _h_29;
      e.mem[_t_18 + 2] = _h_27;
      WL_CONT = term_tsk(FID_CONTROLS_K185, _t_18);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_19 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_19 + 1] = 0;
      e.mem[_t_19 + 2] = 0;
      e.mem[_t_19 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_19 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_19 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_19);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K185)
  {
    WL_POPN(3);
    Term _h_35 = STK(0);
    Term _h_36 = STK(1);
    Term _h_37 = STK(2);
    u32 _h_30 = r0;
    u32 _h_31 = r1;
    u32 _h_32 = r2;
    Term _h_33 = r3;
    Term _h_34 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_35;
      STK(1) = _h_36;
      STK(2) = _h_37;
      STK(3) = FID_CONTROLS_K186;
      WL_PUSHN(4);
    } else {
      u64 _t_20 = task_node(e, FID_CONTROLS_K186, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _h_35;
      e.mem[_t_20 + 1] = _h_36;
      e.mem[_t_20 + 2] = _h_37;
      WL_CONT = term_tsk(FID_CONTROLS_K186, _t_20);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_21 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _h_30;
      e.mem[_t_21 + 1] = _h_31;
      e.mem[_t_21 + 2] = _h_32;
      e.mem[_t_21 + 3] = _h_33;
      e.mem[_t_21 + 4] = _h_34;
      return term_tsk(FID_VALIDATION, _t_21);
    }
    r0 = _h_30;
    r1 = _h_31;
    r2 = _h_32;
    r3 = _h_33;
    r4 = _h_34;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K186)
  {
    WL_POPN(3);
    Term _h_39 = STK(0);
    Term _h_40 = STK(1);
    Term _h_41 = STK(2);
    Term _h_38 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_39;
      STK(1) = _h_40;
      STK(2) = _h_41;
      STK(3) = FID_CONTROLS_K187;
      WL_PUSHN(4);
    } else {
      u64 _t_22 = task_node(e, FID_CONTROLS_K187, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _h_39;
      e.mem[_t_22 + 1] = _h_40;
      e.mem[_t_22 + 2] = _h_41;
      WL_CONT = term_tsk(FID_CONTROLS_K187, _t_22);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_ctr(CID_SCON, STAT_OFF + 375);
      e.mem[_t_23 + 1] = _h_38;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 375);
    r1 = _h_38;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K187)
  {
    WL_POPN(3);
    Term _h_43 = STK(0);
    Term _h_44 = STK(1);
    Term _h_45 = STK(2);
    Term _h_42 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_43;
      STK(1) = _h_44;
      STK(2) = _h_45;
      STK(3) = _h_42;
      STK(4) = FID_CONTROLS_K188;
      WL_PUSHN(5);
    } else {
      u64 _t_24 = task_node(e, FID_CONTROLS_K188, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _h_43;
      e.mem[_t_24 + 1] = _h_44;
      e.mem[_t_24 + 2] = _h_45;
      e.mem[_t_24 + 3] = _h_42;
      WL_CONT = term_tsk(FID_CONTROLS_K188, _t_24);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_25 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_CON, STAT_OFF + 381);
      e.mem[_t_25 + 1] = 0;
      e.mem[_t_25 + 2] = 0;
      e.mem[_t_25 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_25 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_25 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_25);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 381);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K188)
  {
    WL_POPN(4);
    Term _h_51 = STK(0);
    Term _h_52 = STK(1);
    Term _h_53 = STK(2);
    Term _h_54 = STK(3);
    u32 _h_46 = r0;
    u32 _h_47 = r1;
    u32 _h_48 = r2;
    Term _h_49 = r3;
    Term _h_50 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_51;
      STK(1) = _h_52;
      STK(2) = _h_53;
      STK(3) = _h_54;
      STK(4) = FID_CONTROLS_K189;
      WL_PUSHN(5);
    } else {
      u64 _t_26 = task_node(e, FID_CONTROLS_K189, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _h_51;
      e.mem[_t_26 + 1] = _h_52;
      e.mem[_t_26 + 2] = _h_53;
      e.mem[_t_26 + 3] = _h_54;
      WL_CONT = term_tsk(FID_CONTROLS_K189, _t_26);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_27 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _h_46;
      e.mem[_t_27 + 1] = _h_47;
      e.mem[_t_27 + 2] = _h_48;
      e.mem[_t_27 + 3] = _h_49;
      e.mem[_t_27 + 4] = _h_50;
      return term_tsk(FID_VALIDATION, _t_27);
    }
    r0 = _h_46;
    r1 = _h_47;
    r2 = _h_48;
    r3 = _h_49;
    r4 = _h_50;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K189)
  {
    WL_POPN(4);
    Term _h_56 = STK(0);
    Term _h_57 = STK(1);
    Term _h_58 = STK(2);
    Term _h_59 = STK(3);
    Term _h_55 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _h_56;
      STK(1) = _h_57;
      STK(2) = _h_58;
      STK(3) = _h_59;
      STK(4) = FID_CONTROLS_K190;
      WL_PUSHN(5);
    } else {
      u64 _t_28 = task_node(e, FID_CONTROLS_K190, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _h_56;
      e.mem[_t_28 + 1] = _h_57;
      e.mem[_t_28 + 2] = _h_58;
      e.mem[_t_28 + 3] = _h_59;
      WL_CONT = term_tsk(FID_CONTROLS_K190, _t_28);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 421);
      e.mem[_t_29 + 1] = _h_55;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 421);
    r1 = _h_55;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K190)
  {
    WL_POPN(4);
    Term _h_61 = STK(0);
    Term _h_62 = STK(1);
    Term _h_63 = STK(2);
    Term _h_64 = STK(3);
    Term _h_60 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_61;
      STK(1) = _h_62;
      STK(2) = _h_63;
      STK(3) = _h_64;
      STK(4) = _h_60;
      STK(5) = FID_CONTROLS_K191;
      WL_PUSHN(6);
    } else {
      u64 _t_30 = task_node(e, FID_CONTROLS_K191, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _h_61;
      e.mem[_t_30 + 1] = _h_62;
      e.mem[_t_30 + 2] = _h_63;
      e.mem[_t_30 + 3] = _h_64;
      e.mem[_t_30 + 4] = _h_60;
      WL_CONT = term_tsk(FID_CONTROLS_K191, _t_30);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_31 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_31 + 1] = 1;
      e.mem[_t_31 + 2] = 0;
      e.mem[_t_31 + 3] = term_ctr(CID_SCON, STAT_OFF + 321);
      e.mem[_t_31 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_31 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_31);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 321);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K191)
  {
    WL_POPN(5);
    Term _h_70 = STK(0);
    Term _h_71 = STK(1);
    Term _h_72 = STK(2);
    Term _h_73 = STK(3);
    Term _h_74 = STK(4);
    u32 _h_65 = r0;
    u32 _h_66 = r1;
    u32 _h_67 = r2;
    Term _h_68 = r3;
    Term _h_69 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_70;
      STK(1) = _h_71;
      STK(2) = _h_72;
      STK(3) = _h_73;
      STK(4) = _h_74;
      STK(5) = FID_CONTROLS_K192;
      WL_PUSHN(6);
    } else {
      u64 _t_32 = task_node(e, FID_CONTROLS_K192, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _h_70;
      e.mem[_t_32 + 1] = _h_71;
      e.mem[_t_32 + 2] = _h_72;
      e.mem[_t_32 + 3] = _h_73;
      e.mem[_t_32 + 4] = _h_74;
      WL_CONT = term_tsk(FID_CONTROLS_K192, _t_32);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_33 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = _h_65;
      e.mem[_t_33 + 1] = _h_66;
      e.mem[_t_33 + 2] = _h_67;
      e.mem[_t_33 + 3] = _h_68;
      e.mem[_t_33 + 4] = _h_69;
      return term_tsk(FID_VALIDATION, _t_33);
    }
    r0 = _h_65;
    r1 = _h_66;
    r2 = _h_67;
    r3 = _h_68;
    r4 = _h_69;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K192)
  {
    WL_POPN(5);
    Term _h_76 = STK(0);
    Term _h_77 = STK(1);
    Term _h_78 = STK(2);
    Term _h_79 = STK(3);
    Term _h_80 = STK(4);
    Term _h_75 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _h_76;
      STK(1) = _h_77;
      STK(2) = _h_78;
      STK(3) = _h_79;
      STK(4) = _h_80;
      STK(5) = FID_CONTROLS_K193;
      WL_PUSHN(6);
    } else {
      u64 _t_34 = task_node(e, FID_CONTROLS_K193, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _h_76;
      e.mem[_t_34 + 1] = _h_77;
      e.mem[_t_34 + 2] = _h_78;
      e.mem[_t_34 + 3] = _h_79;
      e.mem[_t_34 + 4] = _h_80;
      WL_CONT = term_tsk(FID_CONTROLS_K193, _t_34);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_35 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = term_ctr(CID_SCON, STAT_OFF + 461);
      e.mem[_t_35 + 1] = _h_75;
      return term_tsk(FID_STRING_APPEND, _t_35);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 461);
    r1 = _h_75;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K193)
  {
    WL_POPN(5);
    Term _h_82 = STK(0);
    Term _h_83 = STK(1);
    Term _h_84 = STK(2);
    Term _h_85 = STK(3);
    Term _h_86 = STK(4);
    Term _h_81 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_82;
      STK(1) = _h_83;
      STK(2) = _h_84;
      STK(3) = _h_85;
      STK(4) = _h_86;
      STK(5) = _h_81;
      STK(6) = FID_CONTROLS_K194;
      WL_PUSHN(7);
    } else {
      u64 _t_36 = task_node(e, FID_CONTROLS_K194, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _h_82;
      e.mem[_t_36 + 1] = _h_83;
      e.mem[_t_36 + 2] = _h_84;
      e.mem[_t_36 + 3] = _h_85;
      e.mem[_t_36 + 4] = _h_86;
      e.mem[_t_36 + 5] = _h_81;
      WL_CONT = term_tsk(FID_CONTROLS_K194, _t_36);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_37 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = term_ctr(CID_CON, STAT_OFF + 467);
      e.mem[_t_37 + 1] = 1;
      e.mem[_t_37 + 2] = 0;
      e.mem[_t_37 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_37 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_37 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_37);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 467);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K194)
  {
    WL_POPN(6);
    Term _h_92 = STK(0);
    Term _h_93 = STK(1);
    Term _h_94 = STK(2);
    Term _h_95 = STK(3);
    Term _h_96 = STK(4);
    Term _h_97 = STK(5);
    u32 _h_87 = r0;
    u32 _h_88 = r1;
    u32 _h_89 = r2;
    Term _h_90 = r3;
    Term _h_91 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_92;
      STK(1) = _h_93;
      STK(2) = _h_94;
      STK(3) = _h_95;
      STK(4) = _h_96;
      STK(5) = _h_97;
      STK(6) = FID_CONTROLS_K195;
      WL_PUSHN(7);
    } else {
      u64 _t_38 = task_node(e, FID_CONTROLS_K195, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _h_92;
      e.mem[_t_38 + 1] = _h_93;
      e.mem[_t_38 + 2] = _h_94;
      e.mem[_t_38 + 3] = _h_95;
      e.mem[_t_38 + 4] = _h_96;
      e.mem[_t_38 + 5] = _h_97;
      WL_CONT = term_tsk(FID_CONTROLS_K195, _t_38);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_39 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _h_87;
      e.mem[_t_39 + 1] = _h_88;
      e.mem[_t_39 + 2] = _h_89;
      e.mem[_t_39 + 3] = _h_90;
      e.mem[_t_39 + 4] = _h_91;
      return term_tsk(FID_VALIDATION, _t_39);
    }
    r0 = _h_87;
    r1 = _h_88;
    r2 = _h_89;
    r3 = _h_90;
    r4 = _h_91;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K195)
  {
    WL_POPN(6);
    Term _h_99 = STK(0);
    Term _h_100 = STK(1);
    Term _h_101 = STK(2);
    Term _h_102 = STK(3);
    Term _h_103 = STK(4);
    Term _h_104 = STK(5);
    Term _h_98 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_99;
      STK(1) = _h_100;
      STK(2) = _h_101;
      STK(3) = _h_102;
      STK(4) = _h_103;
      STK(5) = _h_104;
      STK(6) = FID_CONTROLS_K196;
      WL_PUSHN(7);
    } else {
      u64 _t_40 = task_node(e, FID_CONTROLS_K196, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _h_99;
      e.mem[_t_40 + 1] = _h_100;
      e.mem[_t_40 + 2] = _h_101;
      e.mem[_t_40 + 3] = _h_102;
      e.mem[_t_40 + 4] = _h_103;
      e.mem[_t_40 + 5] = _h_104;
      WL_CONT = term_tsk(FID_CONTROLS_K196, _t_40);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_41 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 507);
      e.mem[_t_41 + 1] = _h_98;
      return term_tsk(FID_STRING_APPEND, _t_41);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 507);
    r1 = _h_98;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K196)
  {
    WL_POPN(6);
    Term _h_106 = STK(0);
    Term _h_107 = STK(1);
    Term _h_108 = STK(2);
    Term _h_109 = STK(3);
    Term _h_110 = STK(4);
    Term _h_111 = STK(5);
    Term _h_105 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_106;
      STK(1) = _h_107;
      STK(2) = _h_108;
      STK(3) = _h_109;
      STK(4) = _h_110;
      STK(5) = _h_111;
      STK(6) = _h_105;
      STK(7) = FID_CONTROLS_K197;
      WL_PUSHN(8);
    } else {
      u64 _t_42 = task_node(e, FID_CONTROLS_K197, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _h_106;
      e.mem[_t_42 + 1] = _h_107;
      e.mem[_t_42 + 2] = _h_108;
      e.mem[_t_42 + 3] = _h_109;
      e.mem[_t_42 + 4] = _h_110;
      e.mem[_t_42 + 5] = _h_111;
      e.mem[_t_42 + 6] = _h_105;
      WL_CONT = term_tsk(FID_CONTROLS_K197, _t_42);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_43 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = term_ctr(CID_CON, STAT_OFF + 522);
      e.mem[_t_43 + 1] = 1;
      e.mem[_t_43 + 2] = 0;
      e.mem[_t_43 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_43 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_43 + 5] = 2;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_43);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 522);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 2;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K197)
  {
    WL_POPN(7);
    Term _h_117 = STK(0);
    Term _h_118 = STK(1);
    Term _h_119 = STK(2);
    Term _h_120 = STK(3);
    Term _h_121 = STK(4);
    Term _h_122 = STK(5);
    Term _h_123 = STK(6);
    u32 _h_112 = r0;
    u32 _h_113 = r1;
    u32 _h_114 = r2;
    Term _h_115 = r3;
    Term _h_116 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_117;
      STK(1) = _h_118;
      STK(2) = _h_119;
      STK(3) = _h_120;
      STK(4) = _h_121;
      STK(5) = _h_122;
      STK(6) = _h_123;
      STK(7) = FID_CONTROLS_K198;
      WL_PUSHN(8);
    } else {
      u64 _t_44 = task_node(e, FID_CONTROLS_K198, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _h_117;
      e.mem[_t_44 + 1] = _h_118;
      e.mem[_t_44 + 2] = _h_119;
      e.mem[_t_44 + 3] = _h_120;
      e.mem[_t_44 + 4] = _h_121;
      e.mem[_t_44 + 5] = _h_122;
      e.mem[_t_44 + 6] = _h_123;
      WL_CONT = term_tsk(FID_CONTROLS_K198, _t_44);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_45 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _h_112;
      e.mem[_t_45 + 1] = _h_113;
      e.mem[_t_45 + 2] = _h_114;
      e.mem[_t_45 + 3] = _h_115;
      e.mem[_t_45 + 4] = _h_116;
      return term_tsk(FID_VALIDATION, _t_45);
    }
    r0 = _h_112;
    r1 = _h_113;
    r2 = _h_114;
    r3 = _h_115;
    r4 = _h_116;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K198)
  {
    WL_POPN(7);
    Term _h_125 = STK(0);
    Term _h_126 = STK(1);
    Term _h_127 = STK(2);
    Term _h_128 = STK(3);
    Term _h_129 = STK(4);
    Term _h_130 = STK(5);
    Term _h_131 = STK(6);
    Term _h_124 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_125;
      STK(1) = _h_126;
      STK(2) = _h_127;
      STK(3) = _h_128;
      STK(4) = _h_129;
      STK(5) = _h_130;
      STK(6) = _h_131;
      STK(7) = FID_CONTROLS_K199;
      WL_PUSHN(8);
    } else {
      u64 _t_46 = task_node(e, FID_CONTROLS_K199, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _h_125;
      e.mem[_t_46 + 1] = _h_126;
      e.mem[_t_46 + 2] = _h_127;
      e.mem[_t_46 + 3] = _h_128;
      e.mem[_t_46 + 4] = _h_129;
      e.mem[_t_46 + 5] = _h_130;
      e.mem[_t_46 + 6] = _h_131;
      WL_CONT = term_tsk(FID_CONTROLS_K199, _t_46);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_47 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = term_ctr(CID_SCON, STAT_OFF + 550);
      e.mem[_t_47 + 1] = _h_124;
      return term_tsk(FID_STRING_APPEND, _t_47);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 550);
    r1 = _h_124;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K199)
  {
    WL_POPN(7);
    Term _h_133 = STK(0);
    Term _h_134 = STK(1);
    Term _h_135 = STK(2);
    Term _h_136 = STK(3);
    Term _h_137 = STK(4);
    Term _h_138 = STK(5);
    Term _h_139 = STK(6);
    Term _h_132 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_133;
      STK(1) = _h_134;
      STK(2) = _h_135;
      STK(3) = _h_136;
      STK(4) = _h_137;
      STK(5) = _h_138;
      STK(6) = _h_139;
      STK(7) = _h_132;
      STK(8) = FID_CONTROLS_K200;
      WL_PUSHN(9);
    } else {
      u64 _t_48 = task_node(e, FID_CONTROLS_K200, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _h_133;
      e.mem[_t_48 + 1] = _h_134;
      e.mem[_t_48 + 2] = _h_135;
      e.mem[_t_48 + 3] = _h_136;
      e.mem[_t_48 + 4] = _h_137;
      e.mem[_t_48 + 5] = _h_138;
      e.mem[_t_48 + 6] = _h_139;
      e.mem[_t_48 + 7] = _h_132;
      WL_CONT = term_tsk(FID_CONTROLS_K200, _t_48);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_49 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_49 + 1] = 1;
      e.mem[_t_49 + 2] = 0;
      e.mem[_t_49 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_49 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_49 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_49);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K200)
  {
    WL_POPN(8);
    Term _h_145 = STK(0);
    Term _h_146 = STK(1);
    Term _h_147 = STK(2);
    Term _h_148 = STK(3);
    Term _h_149 = STK(4);
    Term _h_150 = STK(5);
    Term _h_151 = STK(6);
    Term _h_152 = STK(7);
    u32 _h_140 = r0;
    u32 _h_141 = r1;
    u32 _h_142 = r2;
    Term _h_143 = r3;
    Term _h_144 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_145;
      STK(1) = _h_146;
      STK(2) = _h_147;
      STK(3) = _h_148;
      STK(4) = _h_149;
      STK(5) = _h_150;
      STK(6) = _h_151;
      STK(7) = _h_152;
      STK(8) = FID_CONTROLS_K201;
      WL_PUSHN(9);
    } else {
      u64 _t_50 = task_node(e, FID_CONTROLS_K201, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _h_145;
      e.mem[_t_50 + 1] = _h_146;
      e.mem[_t_50 + 2] = _h_147;
      e.mem[_t_50 + 3] = _h_148;
      e.mem[_t_50 + 4] = _h_149;
      e.mem[_t_50 + 5] = _h_150;
      e.mem[_t_50 + 6] = _h_151;
      e.mem[_t_50 + 7] = _h_152;
      WL_CONT = term_tsk(FID_CONTROLS_K201, _t_50);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_51 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = _h_140;
      e.mem[_t_51 + 1] = _h_141;
      e.mem[_t_51 + 2] = _h_142;
      e.mem[_t_51 + 3] = _h_143;
      e.mem[_t_51 + 4] = _h_144;
      return term_tsk(FID_VALIDATION, _t_51);
    }
    r0 = _h_140;
    r1 = _h_141;
    r2 = _h_142;
    r3 = _h_143;
    r4 = _h_144;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K201)
  {
    WL_POPN(8);
    Term _h_154 = STK(0);
    Term _h_155 = STK(1);
    Term _h_156 = STK(2);
    Term _h_157 = STK(3);
    Term _h_158 = STK(4);
    Term _h_159 = STK(5);
    Term _h_160 = STK(6);
    Term _h_161 = STK(7);
    Term _h_153 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(9);
      STK(0) = _h_154;
      STK(1) = _h_155;
      STK(2) = _h_156;
      STK(3) = _h_157;
      STK(4) = _h_158;
      STK(5) = _h_159;
      STK(6) = _h_160;
      STK(7) = _h_161;
      STK(8) = FID_CONTROLS_K202;
      WL_PUSHN(9);
    } else {
      u64 _t_52 = task_node(e, FID_CONTROLS_K202, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _h_154;
      e.mem[_t_52 + 1] = _h_155;
      e.mem[_t_52 + 2] = _h_156;
      e.mem[_t_52 + 3] = _h_157;
      e.mem[_t_52 + 4] = _h_158;
      e.mem[_t_52 + 5] = _h_159;
      e.mem[_t_52 + 6] = _h_160;
      e.mem[_t_52 + 7] = _h_161;
      WL_CONT = term_tsk(FID_CONTROLS_K202, _t_52);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = term_ctr(CID_SCON, STAT_OFF + 586);
      e.mem[_t_53 + 1] = _h_153;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 586);
    r1 = _h_153;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K202)
  {
    WL_POPN(8);
    Term _h_163 = STK(0);
    Term _h_164 = STK(1);
    Term _h_165 = STK(2);
    Term _h_166 = STK(3);
    Term _h_167 = STK(4);
    Term _h_168 = STK(5);
    Term _h_169 = STK(6);
    Term _h_170 = STK(7);
    Term _h_162 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_163;
      STK(1) = _h_164;
      STK(2) = _h_165;
      STK(3) = _h_166;
      STK(4) = _h_167;
      STK(5) = _h_168;
      STK(6) = _h_169;
      STK(7) = _h_170;
      STK(8) = _h_162;
      STK(9) = FID_CONTROLS_K203;
      WL_PUSHN(10);
    } else {
      u64 _t_54 = task_node(e, FID_CONTROLS_K203, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _h_163;
      e.mem[_t_54 + 1] = _h_164;
      e.mem[_t_54 + 2] = _h_165;
      e.mem[_t_54 + 3] = _h_166;
      e.mem[_t_54 + 4] = _h_167;
      e.mem[_t_54 + 5] = _h_168;
      e.mem[_t_54 + 6] = _h_169;
      e.mem[_t_54 + 7] = _h_170;
      e.mem[_t_54 + 8] = _h_162;
      WL_CONT = term_tsk(FID_CONTROLS_K203, _t_54);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_55 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = term_ctr(CID_CON, STAT_OFF + 591);
      e.mem[_t_55 + 1] = 1;
      e.mem[_t_55 + 2] = 1;
      e.mem[_t_55 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_55 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_55 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_55);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 591);
    r1 = 1;
    r2 = 1;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K203)
  {
    WL_POPN(9);
    Term _h_176 = STK(0);
    Term _h_177 = STK(1);
    Term _h_178 = STK(2);
    Term _h_179 = STK(3);
    Term _h_180 = STK(4);
    Term _h_181 = STK(5);
    Term _h_182 = STK(6);
    Term _h_183 = STK(7);
    Term _h_184 = STK(8);
    u32 _h_171 = r0;
    u32 _h_172 = r1;
    u32 _h_173 = r2;
    Term _h_174 = r3;
    Term _h_175 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_176;
      STK(1) = _h_177;
      STK(2) = _h_178;
      STK(3) = _h_179;
      STK(4) = _h_180;
      STK(5) = _h_181;
      STK(6) = _h_182;
      STK(7) = _h_183;
      STK(8) = _h_184;
      STK(9) = FID_CONTROLS_K204;
      WL_PUSHN(10);
    } else {
      u64 _t_56 = task_node(e, FID_CONTROLS_K204, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_176;
      e.mem[_t_56 + 1] = _h_177;
      e.mem[_t_56 + 2] = _h_178;
      e.mem[_t_56 + 3] = _h_179;
      e.mem[_t_56 + 4] = _h_180;
      e.mem[_t_56 + 5] = _h_181;
      e.mem[_t_56 + 6] = _h_182;
      e.mem[_t_56 + 7] = _h_183;
      e.mem[_t_56 + 8] = _h_184;
      WL_CONT = term_tsk(FID_CONTROLS_K204, _t_56);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_57 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = _h_171;
      e.mem[_t_57 + 1] = _h_172;
      e.mem[_t_57 + 2] = _h_173;
      e.mem[_t_57 + 3] = _h_174;
      e.mem[_t_57 + 4] = _h_175;
      return term_tsk(FID_VALIDATION, _t_57);
    }
    r0 = _h_171;
    r1 = _h_172;
    r2 = _h_173;
    r3 = _h_174;
    r4 = _h_175;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K204)
  {
    WL_POPN(9);
    Term _h_186 = STK(0);
    Term _h_187 = STK(1);
    Term _h_188 = STK(2);
    Term _h_189 = STK(3);
    Term _h_190 = STK(4);
    Term _h_191 = STK(5);
    Term _h_192 = STK(6);
    Term _h_193 = STK(7);
    Term _h_194 = STK(8);
    Term _h_185 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_186;
      STK(1) = _h_187;
      STK(2) = _h_188;
      STK(3) = _h_189;
      STK(4) = _h_190;
      STK(5) = _h_191;
      STK(6) = _h_192;
      STK(7) = _h_193;
      STK(8) = _h_194;
      STK(9) = FID_CONTROLS_K205;
      WL_PUSHN(10);
    } else {
      u64 _t_58 = task_node(e, FID_CONTROLS_K205, WL_CONT, WL_IDX, 1);
      e.mem[_t_58 + 0] = _h_186;
      e.mem[_t_58 + 1] = _h_187;
      e.mem[_t_58 + 2] = _h_188;
      e.mem[_t_58 + 3] = _h_189;
      e.mem[_t_58 + 4] = _h_190;
      e.mem[_t_58 + 5] = _h_191;
      e.mem[_t_58 + 6] = _h_192;
      e.mem[_t_58 + 7] = _h_193;
      e.mem[_t_58 + 8] = _h_194;
      WL_CONT = term_tsk(FID_CONTROLS_K205, _t_58);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_59 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = term_ctr(CID_SCON, STAT_OFF + 627);
      e.mem[_t_59 + 1] = _h_185;
      return term_tsk(FID_STRING_APPEND, _t_59);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 627);
    r1 = _h_185;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K205)
  {
    WL_POPN(9);
    Term _h_196 = STK(0);
    Term _h_197 = STK(1);
    Term _h_198 = STK(2);
    Term _h_199 = STK(3);
    Term _h_200 = STK(4);
    Term _h_201 = STK(5);
    Term _h_202 = STK(6);
    Term _h_203 = STK(7);
    Term _h_204 = STK(8);
    Term _h_195 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_196;
      STK(1) = _h_197;
      STK(2) = _h_198;
      STK(3) = _h_199;
      STK(4) = _h_200;
      STK(5) = _h_201;
      STK(6) = _h_202;
      STK(7) = _h_203;
      STK(8) = _h_204;
      STK(9) = _h_195;
      STK(10) = FID_CONTROLS_K206;
      WL_PUSHN(11);
    } else {
      u64 _t_60 = task_node(e, FID_CONTROLS_K206, WL_CONT, WL_IDX, 1);
      e.mem[_t_60 + 0] = _h_196;
      e.mem[_t_60 + 1] = _h_197;
      e.mem[_t_60 + 2] = _h_198;
      e.mem[_t_60 + 3] = _h_199;
      e.mem[_t_60 + 4] = _h_200;
      e.mem[_t_60 + 5] = _h_201;
      e.mem[_t_60 + 6] = _h_202;
      e.mem[_t_60 + 7] = _h_203;
      e.mem[_t_60 + 8] = _h_204;
      e.mem[_t_60 + 9] = _h_195;
      WL_CONT = term_tsk(FID_CONTROLS_K206, _t_60);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_61 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = term_ctr(CID_CON, STAT_OFF + 632);
      e.mem[_t_61 + 1] = 1;
      e.mem[_t_61 + 2] = 2;
      e.mem[_t_61 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_61 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_61 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_61);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 632);
    r1 = 1;
    r2 = 2;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K206)
  {
    WL_POPN(10);
    Term _h_210 = STK(0);
    Term _h_211 = STK(1);
    Term _h_212 = STK(2);
    Term _h_213 = STK(3);
    Term _h_214 = STK(4);
    Term _h_215 = STK(5);
    Term _h_216 = STK(6);
    Term _h_217 = STK(7);
    Term _h_218 = STK(8);
    Term _h_219 = STK(9);
    u32 _h_205 = r0;
    u32 _h_206 = r1;
    u32 _h_207 = r2;
    Term _h_208 = r3;
    Term _h_209 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_210;
      STK(1) = _h_211;
      STK(2) = _h_212;
      STK(3) = _h_213;
      STK(4) = _h_214;
      STK(5) = _h_215;
      STK(6) = _h_216;
      STK(7) = _h_217;
      STK(8) = _h_218;
      STK(9) = _h_219;
      STK(10) = FID_CONTROLS_K207;
      WL_PUSHN(11);
    } else {
      u64 _t_62 = task_node(e, FID_CONTROLS_K207, WL_CONT, WL_IDX, 1);
      e.mem[_t_62 + 0] = _h_210;
      e.mem[_t_62 + 1] = _h_211;
      e.mem[_t_62 + 2] = _h_212;
      e.mem[_t_62 + 3] = _h_213;
      e.mem[_t_62 + 4] = _h_214;
      e.mem[_t_62 + 5] = _h_215;
      e.mem[_t_62 + 6] = _h_216;
      e.mem[_t_62 + 7] = _h_217;
      e.mem[_t_62 + 8] = _h_218;
      e.mem[_t_62 + 9] = _h_219;
      WL_CONT = term_tsk(FID_CONTROLS_K207, _t_62);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_63 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = _h_205;
      e.mem[_t_63 + 1] = _h_206;
      e.mem[_t_63 + 2] = _h_207;
      e.mem[_t_63 + 3] = _h_208;
      e.mem[_t_63 + 4] = _h_209;
      return term_tsk(FID_VALIDATION, _t_63);
    }
    r0 = _h_205;
    r1 = _h_206;
    r2 = _h_207;
    r3 = _h_208;
    r4 = _h_209;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K207)
  {
    WL_POPN(10);
    Term _h_221 = STK(0);
    Term _h_222 = STK(1);
    Term _h_223 = STK(2);
    Term _h_224 = STK(3);
    Term _h_225 = STK(4);
    Term _h_226 = STK(5);
    Term _h_227 = STK(6);
    Term _h_228 = STK(7);
    Term _h_229 = STK(8);
    Term _h_230 = STK(9);
    Term _h_220 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(11);
      STK(0) = _h_221;
      STK(1) = _h_222;
      STK(2) = _h_223;
      STK(3) = _h_224;
      STK(4) = _h_225;
      STK(5) = _h_226;
      STK(6) = _h_227;
      STK(7) = _h_228;
      STK(8) = _h_229;
      STK(9) = _h_230;
      STK(10) = FID_CONTROLS_K208;
      WL_PUSHN(11);
    } else {
      u64 _t_64 = task_node(e, FID_CONTROLS_K208, WL_CONT, WL_IDX, 1);
      e.mem[_t_64 + 0] = _h_221;
      e.mem[_t_64 + 1] = _h_222;
      e.mem[_t_64 + 2] = _h_223;
      e.mem[_t_64 + 3] = _h_224;
      e.mem[_t_64 + 4] = _h_225;
      e.mem[_t_64 + 5] = _h_226;
      e.mem[_t_64 + 6] = _h_227;
      e.mem[_t_64 + 7] = _h_228;
      e.mem[_t_64 + 8] = _h_229;
      e.mem[_t_64 + 9] = _h_230;
      WL_CONT = term_tsk(FID_CONTROLS_K208, _t_64);
      WL_IDX = 10;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_65 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = term_ctr(CID_SCON, STAT_OFF + 668);
      e.mem[_t_65 + 1] = _h_220;
      return term_tsk(FID_STRING_APPEND, _t_65);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 668);
    r1 = _h_220;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K208)
  {
    WL_POPN(10);
    Term _h_232 = STK(0);
    Term _h_233 = STK(1);
    Term _h_234 = STK(2);
    Term _h_235 = STK(3);
    Term _h_236 = STK(4);
    Term _h_237 = STK(5);
    Term _h_238 = STK(6);
    Term _h_239 = STK(7);
    Term _h_240 = STK(8);
    Term _h_241 = STK(9);
    Term _h_231 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_232;
      STK(1) = _h_233;
      STK(2) = _h_234;
      STK(3) = _h_235;
      STK(4) = _h_236;
      STK(5) = _h_237;
      STK(6) = _h_238;
      STK(7) = _h_239;
      STK(8) = _h_240;
      STK(9) = _h_241;
      STK(10) = _h_231;
      STK(11) = FID_CONTROLS_K209;
      WL_PUSHN(12);
    } else {
      u64 _t_66 = task_node(e, FID_CONTROLS_K209, WL_CONT, WL_IDX, 1);
      e.mem[_t_66 + 0] = _h_232;
      e.mem[_t_66 + 1] = _h_233;
      e.mem[_t_66 + 2] = _h_234;
      e.mem[_t_66 + 3] = _h_235;
      e.mem[_t_66 + 4] = _h_236;
      e.mem[_t_66 + 5] = _h_237;
      e.mem[_t_66 + 6] = _h_238;
      e.mem[_t_66 + 7] = _h_239;
      e.mem[_t_66 + 8] = _h_240;
      e.mem[_t_66 + 9] = _h_241;
      e.mem[_t_66 + 10] = _h_231;
      WL_CONT = term_tsk(FID_CONTROLS_K209, _t_66);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_67 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = term_ctr(CID_CON, STAT_OFF + 673);
      e.mem[_t_67 + 1] = 1;
      e.mem[_t_67 + 2] = 3;
      e.mem[_t_67 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_67 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_67 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_67);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 673);
    r1 = 1;
    r2 = 3;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K209)
  {
    WL_POPN(11);
    Term _h_247 = STK(0);
    Term _h_248 = STK(1);
    Term _h_249 = STK(2);
    Term _h_250 = STK(3);
    Term _h_251 = STK(4);
    Term _h_252 = STK(5);
    Term _h_253 = STK(6);
    Term _h_254 = STK(7);
    Term _h_255 = STK(8);
    Term _h_256 = STK(9);
    Term _h_257 = STK(10);
    u32 _h_242 = r0;
    u32 _h_243 = r1;
    u32 _h_244 = r2;
    Term _h_245 = r3;
    Term _h_246 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_247;
      STK(1) = _h_248;
      STK(2) = _h_249;
      STK(3) = _h_250;
      STK(4) = _h_251;
      STK(5) = _h_252;
      STK(6) = _h_253;
      STK(7) = _h_254;
      STK(8) = _h_255;
      STK(9) = _h_256;
      STK(10) = _h_257;
      STK(11) = FID_CONTROLS_K210;
      WL_PUSHN(12);
    } else {
      u64 _t_68 = task_node(e, FID_CONTROLS_K210, WL_CONT, WL_IDX, 1);
      e.mem[_t_68 + 0] = _h_247;
      e.mem[_t_68 + 1] = _h_248;
      e.mem[_t_68 + 2] = _h_249;
      e.mem[_t_68 + 3] = _h_250;
      e.mem[_t_68 + 4] = _h_251;
      e.mem[_t_68 + 5] = _h_252;
      e.mem[_t_68 + 6] = _h_253;
      e.mem[_t_68 + 7] = _h_254;
      e.mem[_t_68 + 8] = _h_255;
      e.mem[_t_68 + 9] = _h_256;
      e.mem[_t_68 + 10] = _h_257;
      WL_CONT = term_tsk(FID_CONTROLS_K210, _t_68);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_69 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = _h_242;
      e.mem[_t_69 + 1] = _h_243;
      e.mem[_t_69 + 2] = _h_244;
      e.mem[_t_69 + 3] = _h_245;
      e.mem[_t_69 + 4] = _h_246;
      return term_tsk(FID_VALIDATION, _t_69);
    }
    r0 = _h_242;
    r1 = _h_243;
    r2 = _h_244;
    r3 = _h_245;
    r4 = _h_246;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K210)
  {
    WL_POPN(11);
    Term _h_259 = STK(0);
    Term _h_260 = STK(1);
    Term _h_261 = STK(2);
    Term _h_262 = STK(3);
    Term _h_263 = STK(4);
    Term _h_264 = STK(5);
    Term _h_265 = STK(6);
    Term _h_266 = STK(7);
    Term _h_267 = STK(8);
    Term _h_268 = STK(9);
    Term _h_269 = STK(10);
    Term _h_258 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(12);
      STK(0) = _h_259;
      STK(1) = _h_260;
      STK(2) = _h_261;
      STK(3) = _h_262;
      STK(4) = _h_263;
      STK(5) = _h_264;
      STK(6) = _h_265;
      STK(7) = _h_266;
      STK(8) = _h_267;
      STK(9) = _h_268;
      STK(10) = _h_269;
      STK(11) = FID_CONTROLS_K211;
      WL_PUSHN(12);
    } else {
      u64 _t_70 = task_node(e, FID_CONTROLS_K211, WL_CONT, WL_IDX, 1);
      e.mem[_t_70 + 0] = _h_259;
      e.mem[_t_70 + 1] = _h_260;
      e.mem[_t_70 + 2] = _h_261;
      e.mem[_t_70 + 3] = _h_262;
      e.mem[_t_70 + 4] = _h_263;
      e.mem[_t_70 + 5] = _h_264;
      e.mem[_t_70 + 6] = _h_265;
      e.mem[_t_70 + 7] = _h_266;
      e.mem[_t_70 + 8] = _h_267;
      e.mem[_t_70 + 9] = _h_268;
      e.mem[_t_70 + 10] = _h_269;
      WL_CONT = term_tsk(FID_CONTROLS_K211, _t_70);
      WL_IDX = 11;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_71 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_71 + 0] = term_ctr(CID_SCON, STAT_OFF + 709);
      e.mem[_t_71 + 1] = _h_258;
      return term_tsk(FID_STRING_APPEND, _t_71);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 709);
    r1 = _h_258;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K211)
  {
    WL_POPN(11);
    Term _h_271 = STK(0);
    Term _h_272 = STK(1);
    Term _h_273 = STK(2);
    Term _h_274 = STK(3);
    Term _h_275 = STK(4);
    Term _h_276 = STK(5);
    Term _h_277 = STK(6);
    Term _h_278 = STK(7);
    Term _h_279 = STK(8);
    Term _h_280 = STK(9);
    Term _h_281 = STK(10);
    Term _h_270 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_271;
      STK(1) = _h_272;
      STK(2) = _h_273;
      STK(3) = _h_274;
      STK(4) = _h_275;
      STK(5) = _h_276;
      STK(6) = _h_277;
      STK(7) = _h_278;
      STK(8) = _h_279;
      STK(9) = _h_280;
      STK(10) = _h_281;
      STK(11) = _h_270;
      STK(12) = FID_CONTROLS_K212;
      WL_PUSHN(13);
    } else {
      u64 _t_72 = task_node(e, FID_CONTROLS_K212, WL_CONT, WL_IDX, 1);
      e.mem[_t_72 + 0] = _h_271;
      e.mem[_t_72 + 1] = _h_272;
      e.mem[_t_72 + 2] = _h_273;
      e.mem[_t_72 + 3] = _h_274;
      e.mem[_t_72 + 4] = _h_275;
      e.mem[_t_72 + 5] = _h_276;
      e.mem[_t_72 + 6] = _h_277;
      e.mem[_t_72 + 7] = _h_278;
      e.mem[_t_72 + 8] = _h_279;
      e.mem[_t_72 + 9] = _h_280;
      e.mem[_t_72 + 10] = _h_281;
      e.mem[_t_72 + 11] = _h_270;
      WL_CONT = term_tsk(FID_CONTROLS_K212, _t_72);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_73 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_73 + 0] = term_ctr(CID_CON, STAT_OFF + 714);
      e.mem[_t_73 + 1] = 1;
      e.mem[_t_73 + 2] = 4;
      e.mem[_t_73 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_73 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_73 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_73);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 714);
    r1 = 1;
    r2 = 4;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K212)
  {
    WL_POPN(12);
    Term _h_287 = STK(0);
    Term _h_288 = STK(1);
    Term _h_289 = STK(2);
    Term _h_290 = STK(3);
    Term _h_291 = STK(4);
    Term _h_292 = STK(5);
    Term _h_293 = STK(6);
    Term _h_294 = STK(7);
    Term _h_295 = STK(8);
    Term _h_296 = STK(9);
    Term _h_297 = STK(10);
    Term _h_298 = STK(11);
    u32 _h_282 = r0;
    u32 _h_283 = r1;
    u32 _h_284 = r2;
    Term _h_285 = r3;
    Term _h_286 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_287;
      STK(1) = _h_288;
      STK(2) = _h_289;
      STK(3) = _h_290;
      STK(4) = _h_291;
      STK(5) = _h_292;
      STK(6) = _h_293;
      STK(7) = _h_294;
      STK(8) = _h_295;
      STK(9) = _h_296;
      STK(10) = _h_297;
      STK(11) = _h_298;
      STK(12) = FID_CONTROLS_K213;
      WL_PUSHN(13);
    } else {
      u64 _t_74 = task_node(e, FID_CONTROLS_K213, WL_CONT, WL_IDX, 1);
      e.mem[_t_74 + 0] = _h_287;
      e.mem[_t_74 + 1] = _h_288;
      e.mem[_t_74 + 2] = _h_289;
      e.mem[_t_74 + 3] = _h_290;
      e.mem[_t_74 + 4] = _h_291;
      e.mem[_t_74 + 5] = _h_292;
      e.mem[_t_74 + 6] = _h_293;
      e.mem[_t_74 + 7] = _h_294;
      e.mem[_t_74 + 8] = _h_295;
      e.mem[_t_74 + 9] = _h_296;
      e.mem[_t_74 + 10] = _h_297;
      e.mem[_t_74 + 11] = _h_298;
      WL_CONT = term_tsk(FID_CONTROLS_K213, _t_74);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_75 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_75 + 0] = _h_282;
      e.mem[_t_75 + 1] = _h_283;
      e.mem[_t_75 + 2] = _h_284;
      e.mem[_t_75 + 3] = _h_285;
      e.mem[_t_75 + 4] = _h_286;
      return term_tsk(FID_VALIDATION, _t_75);
    }
    r0 = _h_282;
    r1 = _h_283;
    r2 = _h_284;
    r3 = _h_285;
    r4 = _h_286;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K213)
  {
    WL_POPN(12);
    Term _h_300 = STK(0);
    Term _h_301 = STK(1);
    Term _h_302 = STK(2);
    Term _h_303 = STK(3);
    Term _h_304 = STK(4);
    Term _h_305 = STK(5);
    Term _h_306 = STK(6);
    Term _h_307 = STK(7);
    Term _h_308 = STK(8);
    Term _h_309 = STK(9);
    Term _h_310 = STK(10);
    Term _h_311 = STK(11);
    Term _h_299 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _h_300;
      STK(1) = _h_301;
      STK(2) = _h_302;
      STK(3) = _h_303;
      STK(4) = _h_304;
      STK(5) = _h_305;
      STK(6) = _h_306;
      STK(7) = _h_307;
      STK(8) = _h_308;
      STK(9) = _h_309;
      STK(10) = _h_310;
      STK(11) = _h_311;
      STK(12) = FID_CONTROLS_K214;
      WL_PUSHN(13);
    } else {
      u64 _t_76 = task_node(e, FID_CONTROLS_K214, WL_CONT, WL_IDX, 1);
      e.mem[_t_76 + 0] = _h_300;
      e.mem[_t_76 + 1] = _h_301;
      e.mem[_t_76 + 2] = _h_302;
      e.mem[_t_76 + 3] = _h_303;
      e.mem[_t_76 + 4] = _h_304;
      e.mem[_t_76 + 5] = _h_305;
      e.mem[_t_76 + 6] = _h_306;
      e.mem[_t_76 + 7] = _h_307;
      e.mem[_t_76 + 8] = _h_308;
      e.mem[_t_76 + 9] = _h_309;
      e.mem[_t_76 + 10] = _h_310;
      e.mem[_t_76 + 11] = _h_311;
      WL_CONT = term_tsk(FID_CONTROLS_K214, _t_76);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_77 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_77 + 0] = term_ctr(CID_SCON, STAT_OFF + 750);
      e.mem[_t_77 + 1] = _h_299;
      return term_tsk(FID_STRING_APPEND, _t_77);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 750);
    r1 = _h_299;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K214)
  {
    WL_POPN(12);
    Term _h_313 = STK(0);
    Term _h_314 = STK(1);
    Term _h_315 = STK(2);
    Term _h_316 = STK(3);
    Term _h_317 = STK(4);
    Term _h_318 = STK(5);
    Term _h_319 = STK(6);
    Term _h_320 = STK(7);
    Term _h_321 = STK(8);
    Term _h_322 = STK(9);
    Term _h_323 = STK(10);
    Term _h_324 = STK(11);
    Term _h_312 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_313;
      STK(1) = _h_314;
      STK(2) = _h_315;
      STK(3) = _h_316;
      STK(4) = _h_317;
      STK(5) = _h_318;
      STK(6) = _h_319;
      STK(7) = _h_320;
      STK(8) = _h_321;
      STK(9) = _h_322;
      STK(10) = _h_323;
      STK(11) = _h_324;
      STK(12) = _h_312;
      STK(13) = FID_CONTROLS_K215;
      WL_PUSHN(14);
    } else {
      u64 _t_78 = task_node(e, FID_CONTROLS_K215, WL_CONT, WL_IDX, 1);
      e.mem[_t_78 + 0] = _h_313;
      e.mem[_t_78 + 1] = _h_314;
      e.mem[_t_78 + 2] = _h_315;
      e.mem[_t_78 + 3] = _h_316;
      e.mem[_t_78 + 4] = _h_317;
      e.mem[_t_78 + 5] = _h_318;
      e.mem[_t_78 + 6] = _h_319;
      e.mem[_t_78 + 7] = _h_320;
      e.mem[_t_78 + 8] = _h_321;
      e.mem[_t_78 + 9] = _h_322;
      e.mem[_t_78 + 10] = _h_323;
      e.mem[_t_78 + 11] = _h_324;
      e.mem[_t_78 + 12] = _h_312;
      WL_CONT = term_tsk(FID_CONTROLS_K215, _t_78);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_79 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_79 + 0] = term_ctr(CID_CON, STAT_OFF + 381);
      e.mem[_t_79 + 1] = 1;
      e.mem[_t_79 + 2] = 1;
      e.mem[_t_79 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_79 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_79 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_79);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 381);
    r1 = 1;
    r2 = 1;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K215)
  {
    WL_POPN(13);
    Term _h_330 = STK(0);
    Term _h_331 = STK(1);
    Term _h_332 = STK(2);
    Term _h_333 = STK(3);
    Term _h_334 = STK(4);
    Term _h_335 = STK(5);
    Term _h_336 = STK(6);
    Term _h_337 = STK(7);
    Term _h_338 = STK(8);
    Term _h_339 = STK(9);
    Term _h_340 = STK(10);
    Term _h_341 = STK(11);
    Term _h_342 = STK(12);
    u32 _h_325 = r0;
    u32 _h_326 = r1;
    u32 _h_327 = r2;
    Term _h_328 = r3;
    Term _h_329 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_330;
      STK(1) = _h_331;
      STK(2) = _h_332;
      STK(3) = _h_333;
      STK(4) = _h_334;
      STK(5) = _h_335;
      STK(6) = _h_336;
      STK(7) = _h_337;
      STK(8) = _h_338;
      STK(9) = _h_339;
      STK(10) = _h_340;
      STK(11) = _h_341;
      STK(12) = _h_342;
      STK(13) = FID_CONTROLS_K216;
      WL_PUSHN(14);
    } else {
      u64 _t_80 = task_node(e, FID_CONTROLS_K216, WL_CONT, WL_IDX, 1);
      e.mem[_t_80 + 0] = _h_330;
      e.mem[_t_80 + 1] = _h_331;
      e.mem[_t_80 + 2] = _h_332;
      e.mem[_t_80 + 3] = _h_333;
      e.mem[_t_80 + 4] = _h_334;
      e.mem[_t_80 + 5] = _h_335;
      e.mem[_t_80 + 6] = _h_336;
      e.mem[_t_80 + 7] = _h_337;
      e.mem[_t_80 + 8] = _h_338;
      e.mem[_t_80 + 9] = _h_339;
      e.mem[_t_80 + 10] = _h_340;
      e.mem[_t_80 + 11] = _h_341;
      e.mem[_t_80 + 12] = _h_342;
      WL_CONT = term_tsk(FID_CONTROLS_K216, _t_80);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_81 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_81 + 0] = _h_325;
      e.mem[_t_81 + 1] = _h_326;
      e.mem[_t_81 + 2] = _h_327;
      e.mem[_t_81 + 3] = _h_328;
      e.mem[_t_81 + 4] = _h_329;
      return term_tsk(FID_VALIDATION, _t_81);
    }
    r0 = _h_325;
    r1 = _h_326;
    r2 = _h_327;
    r3 = _h_328;
    r4 = _h_329;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K216)
  {
    WL_POPN(13);
    Term _h_344 = STK(0);
    Term _h_345 = STK(1);
    Term _h_346 = STK(2);
    Term _h_347 = STK(3);
    Term _h_348 = STK(4);
    Term _h_349 = STK(5);
    Term _h_350 = STK(6);
    Term _h_351 = STK(7);
    Term _h_352 = STK(8);
    Term _h_353 = STK(9);
    Term _h_354 = STK(10);
    Term _h_355 = STK(11);
    Term _h_356 = STK(12);
    Term _h_343 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _h_344;
      STK(1) = _h_345;
      STK(2) = _h_346;
      STK(3) = _h_347;
      STK(4) = _h_348;
      STK(5) = _h_349;
      STK(6) = _h_350;
      STK(7) = _h_351;
      STK(8) = _h_352;
      STK(9) = _h_353;
      STK(10) = _h_354;
      STK(11) = _h_355;
      STK(12) = _h_356;
      STK(13) = FID_CONTROLS_K217;
      WL_PUSHN(14);
    } else {
      u64 _t_82 = task_node(e, FID_CONTROLS_K217, WL_CONT, WL_IDX, 1);
      e.mem[_t_82 + 0] = _h_344;
      e.mem[_t_82 + 1] = _h_345;
      e.mem[_t_82 + 2] = _h_346;
      e.mem[_t_82 + 3] = _h_347;
      e.mem[_t_82 + 4] = _h_348;
      e.mem[_t_82 + 5] = _h_349;
      e.mem[_t_82 + 6] = _h_350;
      e.mem[_t_82 + 7] = _h_351;
      e.mem[_t_82 + 8] = _h_352;
      e.mem[_t_82 + 9] = _h_353;
      e.mem[_t_82 + 10] = _h_354;
      e.mem[_t_82 + 11] = _h_355;
      e.mem[_t_82 + 12] = _h_356;
      WL_CONT = term_tsk(FID_CONTROLS_K217, _t_82);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_83 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_83 + 0] = term_ctr(CID_SCON, STAT_OFF + 770);
      e.mem[_t_83 + 1] = _h_343;
      return term_tsk(FID_STRING_APPEND, _t_83);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 770);
    r1 = _h_343;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K217)
  {
    WL_POPN(13);
    Term _h_358 = STK(0);
    Term _h_359 = STK(1);
    Term _h_360 = STK(2);
    Term _h_361 = STK(3);
    Term _h_362 = STK(4);
    Term _h_363 = STK(5);
    Term _h_364 = STK(6);
    Term _h_365 = STK(7);
    Term _h_366 = STK(8);
    Term _h_367 = STK(9);
    Term _h_368 = STK(10);
    Term _h_369 = STK(11);
    Term _h_370 = STK(12);
    Term _h_357 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_358;
      STK(1) = _h_359;
      STK(2) = _h_360;
      STK(3) = _h_361;
      STK(4) = _h_362;
      STK(5) = _h_363;
      STK(6) = _h_364;
      STK(7) = _h_365;
      STK(8) = _h_366;
      STK(9) = _h_367;
      STK(10) = _h_368;
      STK(11) = _h_369;
      STK(12) = _h_370;
      STK(13) = _h_357;
      STK(14) = FID_CONTROLS_K218;
      WL_PUSHN(15);
    } else {
      u64 _t_84 = task_node(e, FID_CONTROLS_K218, WL_CONT, WL_IDX, 1);
      e.mem[_t_84 + 0] = _h_358;
      e.mem[_t_84 + 1] = _h_359;
      e.mem[_t_84 + 2] = _h_360;
      e.mem[_t_84 + 3] = _h_361;
      e.mem[_t_84 + 4] = _h_362;
      e.mem[_t_84 + 5] = _h_363;
      e.mem[_t_84 + 6] = _h_364;
      e.mem[_t_84 + 7] = _h_365;
      e.mem[_t_84 + 8] = _h_366;
      e.mem[_t_84 + 9] = _h_367;
      e.mem[_t_84 + 10] = _h_368;
      e.mem[_t_84 + 11] = _h_369;
      e.mem[_t_84 + 12] = _h_370;
      e.mem[_t_84 + 13] = _h_357;
      WL_CONT = term_tsk(FID_CONTROLS_K218, _t_84);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_85 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_85 + 0] = term_ctr(CID_CON, STAT_OFF + 776);
      e.mem[_t_85 + 1] = 1;
      e.mem[_t_85 + 2] = 2;
      e.mem[_t_85 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_85 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_85 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_85);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 776);
    r1 = 1;
    r2 = 2;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K218)
  {
    WL_POPN(14);
    Term _h_376 = STK(0);
    Term _h_377 = STK(1);
    Term _h_378 = STK(2);
    Term _h_379 = STK(3);
    Term _h_380 = STK(4);
    Term _h_381 = STK(5);
    Term _h_382 = STK(6);
    Term _h_383 = STK(7);
    Term _h_384 = STK(8);
    Term _h_385 = STK(9);
    Term _h_386 = STK(10);
    Term _h_387 = STK(11);
    Term _h_388 = STK(12);
    Term _h_389 = STK(13);
    u32 _h_371 = r0;
    u32 _h_372 = r1;
    u32 _h_373 = r2;
    Term _h_374 = r3;
    Term _h_375 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_376;
      STK(1) = _h_377;
      STK(2) = _h_378;
      STK(3) = _h_379;
      STK(4) = _h_380;
      STK(5) = _h_381;
      STK(6) = _h_382;
      STK(7) = _h_383;
      STK(8) = _h_384;
      STK(9) = _h_385;
      STK(10) = _h_386;
      STK(11) = _h_387;
      STK(12) = _h_388;
      STK(13) = _h_389;
      STK(14) = FID_CONTROLS_K219;
      WL_PUSHN(15);
    } else {
      u64 _t_86 = task_node(e, FID_CONTROLS_K219, WL_CONT, WL_IDX, 1);
      e.mem[_t_86 + 0] = _h_376;
      e.mem[_t_86 + 1] = _h_377;
      e.mem[_t_86 + 2] = _h_378;
      e.mem[_t_86 + 3] = _h_379;
      e.mem[_t_86 + 4] = _h_380;
      e.mem[_t_86 + 5] = _h_381;
      e.mem[_t_86 + 6] = _h_382;
      e.mem[_t_86 + 7] = _h_383;
      e.mem[_t_86 + 8] = _h_384;
      e.mem[_t_86 + 9] = _h_385;
      e.mem[_t_86 + 10] = _h_386;
      e.mem[_t_86 + 11] = _h_387;
      e.mem[_t_86 + 12] = _h_388;
      e.mem[_t_86 + 13] = _h_389;
      WL_CONT = term_tsk(FID_CONTROLS_K219, _t_86);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_87 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_87 + 0] = _h_371;
      e.mem[_t_87 + 1] = _h_372;
      e.mem[_t_87 + 2] = _h_373;
      e.mem[_t_87 + 3] = _h_374;
      e.mem[_t_87 + 4] = _h_375;
      return term_tsk(FID_VALIDATION, _t_87);
    }
    r0 = _h_371;
    r1 = _h_372;
    r2 = _h_373;
    r3 = _h_374;
    r4 = _h_375;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K219)
  {
    WL_POPN(14);
    Term _h_391 = STK(0);
    Term _h_392 = STK(1);
    Term _h_393 = STK(2);
    Term _h_394 = STK(3);
    Term _h_395 = STK(4);
    Term _h_396 = STK(5);
    Term _h_397 = STK(6);
    Term _h_398 = STK(7);
    Term _h_399 = STK(8);
    Term _h_400 = STK(9);
    Term _h_401 = STK(10);
    Term _h_402 = STK(11);
    Term _h_403 = STK(12);
    Term _h_404 = STK(13);
    Term _h_390 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(15);
      STK(0) = _h_391;
      STK(1) = _h_392;
      STK(2) = _h_393;
      STK(3) = _h_394;
      STK(4) = _h_395;
      STK(5) = _h_396;
      STK(6) = _h_397;
      STK(7) = _h_398;
      STK(8) = _h_399;
      STK(9) = _h_400;
      STK(10) = _h_401;
      STK(11) = _h_402;
      STK(12) = _h_403;
      STK(13) = _h_404;
      STK(14) = FID_CONTROLS_K220;
      WL_PUSHN(15);
    } else {
      u64 _t_88 = task_node(e, FID_CONTROLS_K220, WL_CONT, WL_IDX, 1);
      e.mem[_t_88 + 0] = _h_391;
      e.mem[_t_88 + 1] = _h_392;
      e.mem[_t_88 + 2] = _h_393;
      e.mem[_t_88 + 3] = _h_394;
      e.mem[_t_88 + 4] = _h_395;
      e.mem[_t_88 + 5] = _h_396;
      e.mem[_t_88 + 6] = _h_397;
      e.mem[_t_88 + 7] = _h_398;
      e.mem[_t_88 + 8] = _h_399;
      e.mem[_t_88 + 9] = _h_400;
      e.mem[_t_88 + 10] = _h_401;
      e.mem[_t_88 + 11] = _h_402;
      e.mem[_t_88 + 12] = _h_403;
      e.mem[_t_88 + 13] = _h_404;
      WL_CONT = term_tsk(FID_CONTROLS_K220, _t_88);
      WL_IDX = 14;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_89 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_89 + 0] = term_ctr(CID_SCON, STAT_OFF + 796);
      e.mem[_t_89 + 1] = _h_390;
      return term_tsk(FID_STRING_APPEND, _t_89);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 796);
    r1 = _h_390;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K220)
  {
    WL_POPN(14);
    Term _h_406 = STK(0);
    Term _h_407 = STK(1);
    Term _h_408 = STK(2);
    Term _h_409 = STK(3);
    Term _h_410 = STK(4);
    Term _h_411 = STK(5);
    Term _h_412 = STK(6);
    Term _h_413 = STK(7);
    Term _h_414 = STK(8);
    Term _h_415 = STK(9);
    Term _h_416 = STK(10);
    Term _h_417 = STK(11);
    Term _h_418 = STK(12);
    Term _h_419 = STK(13);
    Term _h_405 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_406;
      STK(1) = _h_407;
      STK(2) = _h_408;
      STK(3) = _h_409;
      STK(4) = _h_410;
      STK(5) = _h_411;
      STK(6) = _h_412;
      STK(7) = _h_413;
      STK(8) = _h_414;
      STK(9) = _h_415;
      STK(10) = _h_416;
      STK(11) = _h_417;
      STK(12) = _h_418;
      STK(13) = _h_419;
      STK(14) = _h_405;
      STK(15) = FID_CONTROLS_K221;
      WL_PUSHN(16);
    } else {
      u64 _t_90 = task_node(e, FID_CONTROLS_K221, WL_CONT, WL_IDX, 1);
      e.mem[_t_90 + 0] = _h_406;
      e.mem[_t_90 + 1] = _h_407;
      e.mem[_t_90 + 2] = _h_408;
      e.mem[_t_90 + 3] = _h_409;
      e.mem[_t_90 + 4] = _h_410;
      e.mem[_t_90 + 5] = _h_411;
      e.mem[_t_90 + 6] = _h_412;
      e.mem[_t_90 + 7] = _h_413;
      e.mem[_t_90 + 8] = _h_414;
      e.mem[_t_90 + 9] = _h_415;
      e.mem[_t_90 + 10] = _h_416;
      e.mem[_t_90 + 11] = _h_417;
      e.mem[_t_90 + 12] = _h_418;
      e.mem[_t_90 + 13] = _h_419;
      e.mem[_t_90 + 14] = _h_405;
      WL_CONT = term_tsk(FID_CONTROLS_K221, _t_90);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_91 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_91 + 0] = term_ctr(CID_CON, STAT_OFF + 802);
      e.mem[_t_91 + 1] = 1;
      e.mem[_t_91 + 2] = 3;
      e.mem[_t_91 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_91 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_91 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_91);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 802);
    r1 = 1;
    r2 = 3;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K221)
  {
    WL_POPN(15);
    Term _h_425 = STK(0);
    Term _h_426 = STK(1);
    Term _h_427 = STK(2);
    Term _h_428 = STK(3);
    Term _h_429 = STK(4);
    Term _h_430 = STK(5);
    Term _h_431 = STK(6);
    Term _h_432 = STK(7);
    Term _h_433 = STK(8);
    Term _h_434 = STK(9);
    Term _h_435 = STK(10);
    Term _h_436 = STK(11);
    Term _h_437 = STK(12);
    Term _h_438 = STK(13);
    Term _h_439 = STK(14);
    u32 _h_420 = r0;
    u32 _h_421 = r1;
    u32 _h_422 = r2;
    Term _h_423 = r3;
    Term _h_424 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_425;
      STK(1) = _h_426;
      STK(2) = _h_427;
      STK(3) = _h_428;
      STK(4) = _h_429;
      STK(5) = _h_430;
      STK(6) = _h_431;
      STK(7) = _h_432;
      STK(8) = _h_433;
      STK(9) = _h_434;
      STK(10) = _h_435;
      STK(11) = _h_436;
      STK(12) = _h_437;
      STK(13) = _h_438;
      STK(14) = _h_439;
      STK(15) = FID_CONTROLS_K222;
      WL_PUSHN(16);
    } else {
      u64 _t_92 = task_node(e, FID_CONTROLS_K222, WL_CONT, WL_IDX, 1);
      e.mem[_t_92 + 0] = _h_425;
      e.mem[_t_92 + 1] = _h_426;
      e.mem[_t_92 + 2] = _h_427;
      e.mem[_t_92 + 3] = _h_428;
      e.mem[_t_92 + 4] = _h_429;
      e.mem[_t_92 + 5] = _h_430;
      e.mem[_t_92 + 6] = _h_431;
      e.mem[_t_92 + 7] = _h_432;
      e.mem[_t_92 + 8] = _h_433;
      e.mem[_t_92 + 9] = _h_434;
      e.mem[_t_92 + 10] = _h_435;
      e.mem[_t_92 + 11] = _h_436;
      e.mem[_t_92 + 12] = _h_437;
      e.mem[_t_92 + 13] = _h_438;
      e.mem[_t_92 + 14] = _h_439;
      WL_CONT = term_tsk(FID_CONTROLS_K222, _t_92);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_93 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_93 + 0] = _h_420;
      e.mem[_t_93 + 1] = _h_421;
      e.mem[_t_93 + 2] = _h_422;
      e.mem[_t_93 + 3] = _h_423;
      e.mem[_t_93 + 4] = _h_424;
      return term_tsk(FID_VALIDATION, _t_93);
    }
    r0 = _h_420;
    r1 = _h_421;
    r2 = _h_422;
    r3 = _h_423;
    r4 = _h_424;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K222)
  {
    WL_POPN(15);
    Term _h_441 = STK(0);
    Term _h_442 = STK(1);
    Term _h_443 = STK(2);
    Term _h_444 = STK(3);
    Term _h_445 = STK(4);
    Term _h_446 = STK(5);
    Term _h_447 = STK(6);
    Term _h_448 = STK(7);
    Term _h_449 = STK(8);
    Term _h_450 = STK(9);
    Term _h_451 = STK(10);
    Term _h_452 = STK(11);
    Term _h_453 = STK(12);
    Term _h_454 = STK(13);
    Term _h_455 = STK(14);
    Term _h_440 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _h_441;
      STK(1) = _h_442;
      STK(2) = _h_443;
      STK(3) = _h_444;
      STK(4) = _h_445;
      STK(5) = _h_446;
      STK(6) = _h_447;
      STK(7) = _h_448;
      STK(8) = _h_449;
      STK(9) = _h_450;
      STK(10) = _h_451;
      STK(11) = _h_452;
      STK(12) = _h_453;
      STK(13) = _h_454;
      STK(14) = _h_455;
      STK(15) = FID_CONTROLS_K223;
      WL_PUSHN(16);
    } else {
      u64 _t_94 = task_node(e, FID_CONTROLS_K223, WL_CONT, WL_IDX, 1);
      e.mem[_t_94 + 0] = _h_441;
      e.mem[_t_94 + 1] = _h_442;
      e.mem[_t_94 + 2] = _h_443;
      e.mem[_t_94 + 3] = _h_444;
      e.mem[_t_94 + 4] = _h_445;
      e.mem[_t_94 + 5] = _h_446;
      e.mem[_t_94 + 6] = _h_447;
      e.mem[_t_94 + 7] = _h_448;
      e.mem[_t_94 + 8] = _h_449;
      e.mem[_t_94 + 9] = _h_450;
      e.mem[_t_94 + 10] = _h_451;
      e.mem[_t_94 + 11] = _h_452;
      e.mem[_t_94 + 12] = _h_453;
      e.mem[_t_94 + 13] = _h_454;
      e.mem[_t_94 + 14] = _h_455;
      WL_CONT = term_tsk(FID_CONTROLS_K223, _t_94);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_95 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_95 + 0] = term_ctr(CID_SCON, STAT_OFF + 822);
      e.mem[_t_95 + 1] = _h_440;
      return term_tsk(FID_STRING_APPEND, _t_95);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 822);
    r1 = _h_440;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K223)
  {
    WL_POPN(15);
    Term _h_457 = STK(0);
    Term _h_458 = STK(1);
    Term _h_459 = STK(2);
    Term _h_460 = STK(3);
    Term _h_461 = STK(4);
    Term _h_462 = STK(5);
    Term _h_463 = STK(6);
    Term _h_464 = STK(7);
    Term _h_465 = STK(8);
    Term _h_466 = STK(9);
    Term _h_467 = STK(10);
    Term _h_468 = STK(11);
    Term _h_469 = STK(12);
    Term _h_470 = STK(13);
    Term _h_471 = STK(14);
    Term _h_456 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_457;
      STK(1) = _h_458;
      STK(2) = _h_459;
      STK(3) = _h_460;
      STK(4) = _h_461;
      STK(5) = _h_462;
      STK(6) = _h_463;
      STK(7) = _h_464;
      STK(8) = _h_465;
      STK(9) = _h_466;
      STK(10) = _h_467;
      STK(11) = _h_468;
      STK(12) = _h_469;
      STK(13) = _h_470;
      STK(14) = _h_471;
      STK(15) = _h_456;
      STK(16) = FID_CONTROLS_K224;
      WL_PUSHN(17);
    } else {
      u64 _t_96 = task_node(e, FID_CONTROLS_K224, WL_CONT, WL_IDX, 1);
      e.mem[_t_96 + 0] = _h_457;
      e.mem[_t_96 + 1] = _h_458;
      e.mem[_t_96 + 2] = _h_459;
      e.mem[_t_96 + 3] = _h_460;
      e.mem[_t_96 + 4] = _h_461;
      e.mem[_t_96 + 5] = _h_462;
      e.mem[_t_96 + 6] = _h_463;
      e.mem[_t_96 + 7] = _h_464;
      e.mem[_t_96 + 8] = _h_465;
      e.mem[_t_96 + 9] = _h_466;
      e.mem[_t_96 + 10] = _h_467;
      e.mem[_t_96 + 11] = _h_468;
      e.mem[_t_96 + 12] = _h_469;
      e.mem[_t_96 + 13] = _h_470;
      e.mem[_t_96 + 14] = _h_471;
      e.mem[_t_96 + 15] = _h_456;
      WL_CONT = term_tsk(FID_CONTROLS_K224, _t_96);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_97 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_97 + 0] = term_ctr(CID_CON, STAT_OFF + 828);
      e.mem[_t_97 + 1] = 1;
      e.mem[_t_97 + 2] = 4;
      e.mem[_t_97 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_97 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_97 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_97);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 828);
    r1 = 1;
    r2 = 4;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K224)
  {
    WL_POPN(16);
    Term _h_477 = STK(0);
    Term _h_478 = STK(1);
    Term _h_479 = STK(2);
    Term _h_480 = STK(3);
    Term _h_481 = STK(4);
    Term _h_482 = STK(5);
    Term _h_483 = STK(6);
    Term _h_484 = STK(7);
    Term _h_485 = STK(8);
    Term _h_486 = STK(9);
    Term _h_487 = STK(10);
    Term _h_488 = STK(11);
    Term _h_489 = STK(12);
    Term _h_490 = STK(13);
    Term _h_491 = STK(14);
    Term _h_492 = STK(15);
    u32 _h_472 = r0;
    u32 _h_473 = r1;
    u32 _h_474 = r2;
    Term _h_475 = r3;
    Term _h_476 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_477;
      STK(1) = _h_478;
      STK(2) = _h_479;
      STK(3) = _h_480;
      STK(4) = _h_481;
      STK(5) = _h_482;
      STK(6) = _h_483;
      STK(7) = _h_484;
      STK(8) = _h_485;
      STK(9) = _h_486;
      STK(10) = _h_487;
      STK(11) = _h_488;
      STK(12) = _h_489;
      STK(13) = _h_490;
      STK(14) = _h_491;
      STK(15) = _h_492;
      STK(16) = FID_CONTROLS_K225;
      WL_PUSHN(17);
    } else {
      u64 _t_98 = task_node(e, FID_CONTROLS_K225, WL_CONT, WL_IDX, 1);
      e.mem[_t_98 + 0] = _h_477;
      e.mem[_t_98 + 1] = _h_478;
      e.mem[_t_98 + 2] = _h_479;
      e.mem[_t_98 + 3] = _h_480;
      e.mem[_t_98 + 4] = _h_481;
      e.mem[_t_98 + 5] = _h_482;
      e.mem[_t_98 + 6] = _h_483;
      e.mem[_t_98 + 7] = _h_484;
      e.mem[_t_98 + 8] = _h_485;
      e.mem[_t_98 + 9] = _h_486;
      e.mem[_t_98 + 10] = _h_487;
      e.mem[_t_98 + 11] = _h_488;
      e.mem[_t_98 + 12] = _h_489;
      e.mem[_t_98 + 13] = _h_490;
      e.mem[_t_98 + 14] = _h_491;
      e.mem[_t_98 + 15] = _h_492;
      WL_CONT = term_tsk(FID_CONTROLS_K225, _t_98);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_99 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_99 + 0] = _h_472;
      e.mem[_t_99 + 1] = _h_473;
      e.mem[_t_99 + 2] = _h_474;
      e.mem[_t_99 + 3] = _h_475;
      e.mem[_t_99 + 4] = _h_476;
      return term_tsk(FID_VALIDATION, _t_99);
    }
    r0 = _h_472;
    r1 = _h_473;
    r2 = _h_474;
    r3 = _h_475;
    r4 = _h_476;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K225)
  {
    WL_POPN(16);
    Term _h_494 = STK(0);
    Term _h_495 = STK(1);
    Term _h_496 = STK(2);
    Term _h_497 = STK(3);
    Term _h_498 = STK(4);
    Term _h_499 = STK(5);
    Term _h_500 = STK(6);
    Term _h_501 = STK(7);
    Term _h_502 = STK(8);
    Term _h_503 = STK(9);
    Term _h_504 = STK(10);
    Term _h_505 = STK(11);
    Term _h_506 = STK(12);
    Term _h_507 = STK(13);
    Term _h_508 = STK(14);
    Term _h_509 = STK(15);
    Term _h_493 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(17);
      STK(0) = _h_494;
      STK(1) = _h_495;
      STK(2) = _h_496;
      STK(3) = _h_497;
      STK(4) = _h_498;
      STK(5) = _h_499;
      STK(6) = _h_500;
      STK(7) = _h_501;
      STK(8) = _h_502;
      STK(9) = _h_503;
      STK(10) = _h_504;
      STK(11) = _h_505;
      STK(12) = _h_506;
      STK(13) = _h_507;
      STK(14) = _h_508;
      STK(15) = _h_509;
      STK(16) = FID_CONTROLS_K226;
      WL_PUSHN(17);
    } else {
      u64 _t_100 = task_node(e, FID_CONTROLS_K226, WL_CONT, WL_IDX, 1);
      e.mem[_t_100 + 0] = _h_494;
      e.mem[_t_100 + 1] = _h_495;
      e.mem[_t_100 + 2] = _h_496;
      e.mem[_t_100 + 3] = _h_497;
      e.mem[_t_100 + 4] = _h_498;
      e.mem[_t_100 + 5] = _h_499;
      e.mem[_t_100 + 6] = _h_500;
      e.mem[_t_100 + 7] = _h_501;
      e.mem[_t_100 + 8] = _h_502;
      e.mem[_t_100 + 9] = _h_503;
      e.mem[_t_100 + 10] = _h_504;
      e.mem[_t_100 + 11] = _h_505;
      e.mem[_t_100 + 12] = _h_506;
      e.mem[_t_100 + 13] = _h_507;
      e.mem[_t_100 + 14] = _h_508;
      e.mem[_t_100 + 15] = _h_509;
      WL_CONT = term_tsk(FID_CONTROLS_K226, _t_100);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_101 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_101 + 0] = term_ctr(CID_SCON, STAT_OFF + 848);
      e.mem[_t_101 + 1] = _h_493;
      return term_tsk(FID_STRING_APPEND, _t_101);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 848);
    r1 = _h_493;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K226)
  {
    WL_POPN(16);
    Term _h_511 = STK(0);
    Term _h_512 = STK(1);
    Term _h_513 = STK(2);
    Term _h_514 = STK(3);
    Term _h_515 = STK(4);
    Term _h_516 = STK(5);
    Term _h_517 = STK(6);
    Term _h_518 = STK(7);
    Term _h_519 = STK(8);
    Term _h_520 = STK(9);
    Term _h_521 = STK(10);
    Term _h_522 = STK(11);
    Term _h_523 = STK(12);
    Term _h_524 = STK(13);
    Term _h_525 = STK(14);
    Term _h_526 = STK(15);
    Term _h_510 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_511;
      STK(1) = _h_512;
      STK(2) = _h_513;
      STK(3) = _h_514;
      STK(4) = _h_515;
      STK(5) = _h_516;
      STK(6) = _h_517;
      STK(7) = _h_518;
      STK(8) = _h_519;
      STK(9) = _h_520;
      STK(10) = _h_521;
      STK(11) = _h_522;
      STK(12) = _h_523;
      STK(13) = _h_524;
      STK(14) = _h_525;
      STK(15) = _h_526;
      STK(16) = _h_510;
      STK(17) = FID_CONTROLS_K227;
      WL_PUSHN(18);
    } else {
      u64 _t_102 = task_node(e, FID_CONTROLS_K227, WL_CONT, WL_IDX, 1);
      e.mem[_t_102 + 0] = _h_511;
      e.mem[_t_102 + 1] = _h_512;
      e.mem[_t_102 + 2] = _h_513;
      e.mem[_t_102 + 3] = _h_514;
      e.mem[_t_102 + 4] = _h_515;
      e.mem[_t_102 + 5] = _h_516;
      e.mem[_t_102 + 6] = _h_517;
      e.mem[_t_102 + 7] = _h_518;
      e.mem[_t_102 + 8] = _h_519;
      e.mem[_t_102 + 9] = _h_520;
      e.mem[_t_102 + 10] = _h_521;
      e.mem[_t_102 + 11] = _h_522;
      e.mem[_t_102 + 12] = _h_523;
      e.mem[_t_102 + 13] = _h_524;
      e.mem[_t_102 + 14] = _h_525;
      e.mem[_t_102 + 15] = _h_526;
      e.mem[_t_102 + 16] = _h_510;
      WL_CONT = term_tsk(FID_CONTROLS_K227, _t_102);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0)) {
      u64 _t_103 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_103 + 0] = term_ctr(CID_CON, STAT_OFF + 854);
      e.mem[_t_103 + 1] = 1;
      e.mem[_t_103 + 2] = 0;
      e.mem[_t_103 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_103 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_103 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0, _t_103);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 854);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_BARE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K227)
  {
    WL_POPN(17);
    Term _h_532 = STK(0);
    Term _h_533 = STK(1);
    Term _h_534 = STK(2);
    Term _h_535 = STK(3);
    Term _h_536 = STK(4);
    Term _h_537 = STK(5);
    Term _h_538 = STK(6);
    Term _h_539 = STK(7);
    Term _h_540 = STK(8);
    Term _h_541 = STK(9);
    Term _h_542 = STK(10);
    Term _h_543 = STK(11);
    Term _h_544 = STK(12);
    Term _h_545 = STK(13);
    Term _h_546 = STK(14);
    Term _h_547 = STK(15);
    Term _h_548 = STK(16);
    u32 _h_527 = r0;
    u32 _h_528 = r1;
    u32 _h_529 = r2;
    Term _h_530 = r3;
    Term _h_531 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_532;
      STK(1) = _h_533;
      STK(2) = _h_534;
      STK(3) = _h_535;
      STK(4) = _h_536;
      STK(5) = _h_537;
      STK(6) = _h_538;
      STK(7) = _h_539;
      STK(8) = _h_540;
      STK(9) = _h_541;
      STK(10) = _h_542;
      STK(11) = _h_543;
      STK(12) = _h_544;
      STK(13) = _h_545;
      STK(14) = _h_546;
      STK(15) = _h_547;
      STK(16) = _h_548;
      STK(17) = FID_CONTROLS_K228;
      WL_PUSHN(18);
    } else {
      u64 _t_104 = task_node(e, FID_CONTROLS_K228, WL_CONT, WL_IDX, 1);
      e.mem[_t_104 + 0] = _h_532;
      e.mem[_t_104 + 1] = _h_533;
      e.mem[_t_104 + 2] = _h_534;
      e.mem[_t_104 + 3] = _h_535;
      e.mem[_t_104 + 4] = _h_536;
      e.mem[_t_104 + 5] = _h_537;
      e.mem[_t_104 + 6] = _h_538;
      e.mem[_t_104 + 7] = _h_539;
      e.mem[_t_104 + 8] = _h_540;
      e.mem[_t_104 + 9] = _h_541;
      e.mem[_t_104 + 10] = _h_542;
      e.mem[_t_104 + 11] = _h_543;
      e.mem[_t_104 + 12] = _h_544;
      e.mem[_t_104 + 13] = _h_545;
      e.mem[_t_104 + 14] = _h_546;
      e.mem[_t_104 + 15] = _h_547;
      e.mem[_t_104 + 16] = _h_548;
      WL_CONT = term_tsk(FID_CONTROLS_K228, _t_104);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_105 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_105 + 0] = _h_527;
      e.mem[_t_105 + 1] = _h_528;
      e.mem[_t_105 + 2] = _h_529;
      e.mem[_t_105 + 3] = _h_530;
      e.mem[_t_105 + 4] = _h_531;
      return term_tsk(FID_VALIDATION, _t_105);
    }
    r0 = _h_527;
    r1 = _h_528;
    r2 = _h_529;
    r3 = _h_530;
    r4 = _h_531;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K228)
  {
    WL_POPN(17);
    Term _h_550 = STK(0);
    Term _h_551 = STK(1);
    Term _h_552 = STK(2);
    Term _h_553 = STK(3);
    Term _h_554 = STK(4);
    Term _h_555 = STK(5);
    Term _h_556 = STK(6);
    Term _h_557 = STK(7);
    Term _h_558 = STK(8);
    Term _h_559 = STK(9);
    Term _h_560 = STK(10);
    Term _h_561 = STK(11);
    Term _h_562 = STK(12);
    Term _h_563 = STK(13);
    Term _h_564 = STK(14);
    Term _h_565 = STK(15);
    Term _h_566 = STK(16);
    Term _h_549 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_550;
      STK(1) = _h_551;
      STK(2) = _h_552;
      STK(3) = _h_553;
      STK(4) = _h_554;
      STK(5) = _h_555;
      STK(6) = _h_556;
      STK(7) = _h_557;
      STK(8) = _h_558;
      STK(9) = _h_559;
      STK(10) = _h_560;
      STK(11) = _h_561;
      STK(12) = _h_562;
      STK(13) = _h_563;
      STK(14) = _h_564;
      STK(15) = _h_565;
      STK(16) = _h_566;
      STK(17) = FID_CONTROLS_K229;
      WL_PUSHN(18);
    } else {
      u64 _t_106 = task_node(e, FID_CONTROLS_K229, WL_CONT, WL_IDX, 1);
      e.mem[_t_106 + 0] = _h_550;
      e.mem[_t_106 + 1] = _h_551;
      e.mem[_t_106 + 2] = _h_552;
      e.mem[_t_106 + 3] = _h_553;
      e.mem[_t_106 + 4] = _h_554;
      e.mem[_t_106 + 5] = _h_555;
      e.mem[_t_106 + 6] = _h_556;
      e.mem[_t_106 + 7] = _h_557;
      e.mem[_t_106 + 8] = _h_558;
      e.mem[_t_106 + 9] = _h_559;
      e.mem[_t_106 + 10] = _h_560;
      e.mem[_t_106 + 11] = _h_561;
      e.mem[_t_106 + 12] = _h_562;
      e.mem[_t_106 + 13] = _h_563;
      e.mem[_t_106 + 14] = _h_564;
      e.mem[_t_106 + 15] = _h_565;
      e.mem[_t_106 + 16] = _h_566;
      WL_CONT = term_tsk(FID_CONTROLS_K229, _t_106);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_107 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_107 + 0] = term_ctr(CID_SCON, STAT_OFF + 874);
      e.mem[_t_107 + 1] = _h_549;
      return term_tsk(FID_STRING_APPEND, _t_107);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 874);
    r1 = _h_549;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K229)
  {
    WL_POPN(17);
    Term _h_568 = STK(0);
    Term _h_569 = STK(1);
    Term _h_570 = STK(2);
    Term _h_571 = STK(3);
    Term _h_572 = STK(4);
    Term _h_573 = STK(5);
    Term _h_574 = STK(6);
    Term _h_575 = STK(7);
    Term _h_576 = STK(8);
    Term _h_577 = STK(9);
    Term _h_578 = STK(10);
    Term _h_579 = STK(11);
    Term _h_580 = STK(12);
    Term _h_581 = STK(13);
    Term _h_582 = STK(14);
    Term _h_583 = STK(15);
    Term _h_584 = STK(16);
    Term _h_567 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_568;
      STK(1) = _h_569;
      STK(2) = _h_570;
      STK(3) = _h_571;
      STK(4) = _h_572;
      STK(5) = _h_573;
      STK(6) = _h_574;
      STK(7) = _h_575;
      STK(8) = _h_576;
      STK(9) = _h_577;
      STK(10) = _h_578;
      STK(11) = _h_579;
      STK(12) = _h_580;
      STK(13) = _h_581;
      STK(14) = _h_582;
      STK(15) = _h_583;
      STK(16) = _h_584;
      STK(17) = _h_567;
      STK(18) = FID_CONTROLS_K230;
      WL_PUSHN(19);
    } else {
      u64 _t_108 = task_node(e, FID_CONTROLS_K230, WL_CONT, WL_IDX, 1);
      e.mem[_t_108 + 0] = _h_568;
      e.mem[_t_108 + 1] = _h_569;
      e.mem[_t_108 + 2] = _h_570;
      e.mem[_t_108 + 3] = _h_571;
      e.mem[_t_108 + 4] = _h_572;
      e.mem[_t_108 + 5] = _h_573;
      e.mem[_t_108 + 6] = _h_574;
      e.mem[_t_108 + 7] = _h_575;
      e.mem[_t_108 + 8] = _h_576;
      e.mem[_t_108 + 9] = _h_577;
      e.mem[_t_108 + 10] = _h_578;
      e.mem[_t_108 + 11] = _h_579;
      e.mem[_t_108 + 12] = _h_580;
      e.mem[_t_108 + 13] = _h_581;
      e.mem[_t_108 + 14] = _h_582;
      e.mem[_t_108 + 15] = _h_583;
      e.mem[_t_108 + 16] = _h_584;
      e.mem[_t_108 + 17] = _h_567;
      WL_CONT = term_tsk(FID_CONTROLS_K230, _t_108);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_109 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_109 + 0] = term_pak(CID_NIL, 0);
      e.mem[_t_109 + 1] = 0;
      e.mem[_t_109 + 2] = 0;
      e.mem[_t_109 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_109 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_109 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_109);
    }
    r0 = term_pak(CID_NIL, 0);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K230)
  {
    WL_POPN(18);
    Term _h_590 = STK(0);
    Term _h_591 = STK(1);
    Term _h_592 = STK(2);
    Term _h_593 = STK(3);
    Term _h_594 = STK(4);
    Term _h_595 = STK(5);
    Term _h_596 = STK(6);
    Term _h_597 = STK(7);
    Term _h_598 = STK(8);
    Term _h_599 = STK(9);
    Term _h_600 = STK(10);
    Term _h_601 = STK(11);
    Term _h_602 = STK(12);
    Term _h_603 = STK(13);
    Term _h_604 = STK(14);
    Term _h_605 = STK(15);
    Term _h_606 = STK(16);
    Term _h_607 = STK(17);
    u32 _h_585 = r0;
    u32 _h_586 = r1;
    u32 _h_587 = r2;
    Term _h_588 = r3;
    Term _h_589 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_590;
      STK(1) = _h_591;
      STK(2) = _h_592;
      STK(3) = _h_593;
      STK(4) = _h_594;
      STK(5) = _h_595;
      STK(6) = _h_596;
      STK(7) = _h_597;
      STK(8) = _h_598;
      STK(9) = _h_599;
      STK(10) = _h_600;
      STK(11) = _h_601;
      STK(12) = _h_602;
      STK(13) = _h_603;
      STK(14) = _h_604;
      STK(15) = _h_605;
      STK(16) = _h_606;
      STK(17) = _h_607;
      STK(18) = FID_CONTROLS_K231;
      WL_PUSHN(19);
    } else {
      u64 _t_110 = task_node(e, FID_CONTROLS_K231, WL_CONT, WL_IDX, 1);
      e.mem[_t_110 + 0] = _h_590;
      e.mem[_t_110 + 1] = _h_591;
      e.mem[_t_110 + 2] = _h_592;
      e.mem[_t_110 + 3] = _h_593;
      e.mem[_t_110 + 4] = _h_594;
      e.mem[_t_110 + 5] = _h_595;
      e.mem[_t_110 + 6] = _h_596;
      e.mem[_t_110 + 7] = _h_597;
      e.mem[_t_110 + 8] = _h_598;
      e.mem[_t_110 + 9] = _h_599;
      e.mem[_t_110 + 10] = _h_600;
      e.mem[_t_110 + 11] = _h_601;
      e.mem[_t_110 + 12] = _h_602;
      e.mem[_t_110 + 13] = _h_603;
      e.mem[_t_110 + 14] = _h_604;
      e.mem[_t_110 + 15] = _h_605;
      e.mem[_t_110 + 16] = _h_606;
      e.mem[_t_110 + 17] = _h_607;
      WL_CONT = term_tsk(FID_CONTROLS_K231, _t_110);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_111 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_111 + 0] = _h_585;
      e.mem[_t_111 + 1] = _h_586;
      e.mem[_t_111 + 2] = _h_587;
      e.mem[_t_111 + 3] = _h_588;
      e.mem[_t_111 + 4] = _h_589;
      return term_tsk(FID_VALIDATION, _t_111);
    }
    r0 = _h_585;
    r1 = _h_586;
    r2 = _h_587;
    r3 = _h_588;
    r4 = _h_589;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K231)
  {
    WL_POPN(18);
    Term _h_609 = STK(0);
    Term _h_610 = STK(1);
    Term _h_611 = STK(2);
    Term _h_612 = STK(3);
    Term _h_613 = STK(4);
    Term _h_614 = STK(5);
    Term _h_615 = STK(6);
    Term _h_616 = STK(7);
    Term _h_617 = STK(8);
    Term _h_618 = STK(9);
    Term _h_619 = STK(10);
    Term _h_620 = STK(11);
    Term _h_621 = STK(12);
    Term _h_622 = STK(13);
    Term _h_623 = STK(14);
    Term _h_624 = STK(15);
    Term _h_625 = STK(16);
    Term _h_626 = STK(17);
    Term _h_608 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_609;
      STK(1) = _h_610;
      STK(2) = _h_611;
      STK(3) = _h_612;
      STK(4) = _h_613;
      STK(5) = _h_614;
      STK(6) = _h_615;
      STK(7) = _h_616;
      STK(8) = _h_617;
      STK(9) = _h_618;
      STK(10) = _h_619;
      STK(11) = _h_620;
      STK(12) = _h_621;
      STK(13) = _h_622;
      STK(14) = _h_623;
      STK(15) = _h_624;
      STK(16) = _h_625;
      STK(17) = _h_626;
      STK(18) = FID_CONTROLS_K232;
      WL_PUSHN(19);
    } else {
      u64 _t_112 = task_node(e, FID_CONTROLS_K232, WL_CONT, WL_IDX, 1);
      e.mem[_t_112 + 0] = _h_609;
      e.mem[_t_112 + 1] = _h_610;
      e.mem[_t_112 + 2] = _h_611;
      e.mem[_t_112 + 3] = _h_612;
      e.mem[_t_112 + 4] = _h_613;
      e.mem[_t_112 + 5] = _h_614;
      e.mem[_t_112 + 6] = _h_615;
      e.mem[_t_112 + 7] = _h_616;
      e.mem[_t_112 + 8] = _h_617;
      e.mem[_t_112 + 9] = _h_618;
      e.mem[_t_112 + 10] = _h_619;
      e.mem[_t_112 + 11] = _h_620;
      e.mem[_t_112 + 12] = _h_621;
      e.mem[_t_112 + 13] = _h_622;
      e.mem[_t_112 + 14] = _h_623;
      e.mem[_t_112 + 15] = _h_624;
      e.mem[_t_112 + 16] = _h_625;
      e.mem[_t_112 + 17] = _h_626;
      WL_CONT = term_tsk(FID_CONTROLS_K232, _t_112);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_113 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_113 + 0] = term_ctr(CID_SCON, STAT_OFF + 894);
      e.mem[_t_113 + 1] = _h_608;
      return term_tsk(FID_STRING_APPEND, _t_113);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 894);
    r1 = _h_608;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K232)
  {
    WL_POPN(18);
    Term _h_628 = STK(0);
    Term _h_629 = STK(1);
    Term _h_630 = STK(2);
    Term _h_631 = STK(3);
    Term _h_632 = STK(4);
    Term _h_633 = STK(5);
    Term _h_634 = STK(6);
    Term _h_635 = STK(7);
    Term _h_636 = STK(8);
    Term _h_637 = STK(9);
    Term _h_638 = STK(10);
    Term _h_639 = STK(11);
    Term _h_640 = STK(12);
    Term _h_641 = STK(13);
    Term _h_642 = STK(14);
    Term _h_643 = STK(15);
    Term _h_644 = STK(16);
    Term _h_645 = STK(17);
    Term _h_627 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_628;
      STK(1) = _h_629;
      STK(2) = _h_630;
      STK(3) = _h_631;
      STK(4) = _h_632;
      STK(5) = _h_633;
      STK(6) = _h_634;
      STK(7) = _h_635;
      STK(8) = _h_636;
      STK(9) = _h_637;
      STK(10) = _h_638;
      STK(11) = _h_639;
      STK(12) = _h_640;
      STK(13) = _h_641;
      STK(14) = _h_642;
      STK(15) = _h_643;
      STK(16) = _h_644;
      STK(17) = _h_645;
      STK(18) = _h_627;
      STK(19) = FID_CONTROLS_K233;
      WL_PUSHN(20);
    } else {
      u64 _t_114 = task_node(e, FID_CONTROLS_K233, WL_CONT, WL_IDX, 1);
      e.mem[_t_114 + 0] = _h_628;
      e.mem[_t_114 + 1] = _h_629;
      e.mem[_t_114 + 2] = _h_630;
      e.mem[_t_114 + 3] = _h_631;
      e.mem[_t_114 + 4] = _h_632;
      e.mem[_t_114 + 5] = _h_633;
      e.mem[_t_114 + 6] = _h_634;
      e.mem[_t_114 + 7] = _h_635;
      e.mem[_t_114 + 8] = _h_636;
      e.mem[_t_114 + 9] = _h_637;
      e.mem[_t_114 + 10] = _h_638;
      e.mem[_t_114 + 11] = _h_639;
      e.mem[_t_114 + 12] = _h_640;
      e.mem[_t_114 + 13] = _h_641;
      e.mem[_t_114 + 14] = _h_642;
      e.mem[_t_114 + 15] = _h_643;
      e.mem[_t_114 + 16] = _h_644;
      e.mem[_t_114 + 17] = _h_645;
      e.mem[_t_114 + 18] = _h_627;
      WL_CONT = term_tsk(FID_CONTROLS_K233, _t_114);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_115 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_115 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_115 + 1] = 0;
      e.mem[_t_115 + 2] = 0;
      e.mem[_t_115 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_115 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_115 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_115);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K233)
  {
    WL_POPN(19);
    Term _h_651 = STK(0);
    Term _h_652 = STK(1);
    Term _h_653 = STK(2);
    Term _h_654 = STK(3);
    Term _h_655 = STK(4);
    Term _h_656 = STK(5);
    Term _h_657 = STK(6);
    Term _h_658 = STK(7);
    Term _h_659 = STK(8);
    Term _h_660 = STK(9);
    Term _h_661 = STK(10);
    Term _h_662 = STK(11);
    Term _h_663 = STK(12);
    Term _h_664 = STK(13);
    Term _h_665 = STK(14);
    Term _h_666 = STK(15);
    Term _h_667 = STK(16);
    Term _h_668 = STK(17);
    Term _h_669 = STK(18);
    u32 _h_646 = r0;
    u32 _h_647 = r1;
    u32 _h_648 = r2;
    Term _h_649 = r3;
    Term _h_650 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_651;
      STK(1) = _h_652;
      STK(2) = _h_653;
      STK(3) = _h_654;
      STK(4) = _h_655;
      STK(5) = _h_656;
      STK(6) = _h_657;
      STK(7) = _h_658;
      STK(8) = _h_659;
      STK(9) = _h_660;
      STK(10) = _h_661;
      STK(11) = _h_662;
      STK(12) = _h_663;
      STK(13) = _h_664;
      STK(14) = _h_665;
      STK(15) = _h_666;
      STK(16) = _h_667;
      STK(17) = _h_668;
      STK(18) = _h_669;
      STK(19) = FID_CONTROLS_K234;
      WL_PUSHN(20);
    } else {
      u64 _t_116 = task_node(e, FID_CONTROLS_K234, WL_CONT, WL_IDX, 1);
      e.mem[_t_116 + 0] = _h_651;
      e.mem[_t_116 + 1] = _h_652;
      e.mem[_t_116 + 2] = _h_653;
      e.mem[_t_116 + 3] = _h_654;
      e.mem[_t_116 + 4] = _h_655;
      e.mem[_t_116 + 5] = _h_656;
      e.mem[_t_116 + 6] = _h_657;
      e.mem[_t_116 + 7] = _h_658;
      e.mem[_t_116 + 8] = _h_659;
      e.mem[_t_116 + 9] = _h_660;
      e.mem[_t_116 + 10] = _h_661;
      e.mem[_t_116 + 11] = _h_662;
      e.mem[_t_116 + 12] = _h_663;
      e.mem[_t_116 + 13] = _h_664;
      e.mem[_t_116 + 14] = _h_665;
      e.mem[_t_116 + 15] = _h_666;
      e.mem[_t_116 + 16] = _h_667;
      e.mem[_t_116 + 17] = _h_668;
      e.mem[_t_116 + 18] = _h_669;
      WL_CONT = term_tsk(FID_CONTROLS_K234, _t_116);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_117 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_117 + 0] = _h_646;
      e.mem[_t_117 + 1] = _h_647;
      e.mem[_t_117 + 2] = _h_648;
      e.mem[_t_117 + 3] = _h_649;
      e.mem[_t_117 + 4] = _h_650;
      return term_tsk(FID_VALIDATION, _t_117);
    }
    r0 = _h_646;
    r1 = _h_647;
    r2 = _h_648;
    r3 = _h_649;
    r4 = _h_650;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K234)
  {
    WL_POPN(19);
    Term _h_671 = STK(0);
    Term _h_672 = STK(1);
    Term _h_673 = STK(2);
    Term _h_674 = STK(3);
    Term _h_675 = STK(4);
    Term _h_676 = STK(5);
    Term _h_677 = STK(6);
    Term _h_678 = STK(7);
    Term _h_679 = STK(8);
    Term _h_680 = STK(9);
    Term _h_681 = STK(10);
    Term _h_682 = STK(11);
    Term _h_683 = STK(12);
    Term _h_684 = STK(13);
    Term _h_685 = STK(14);
    Term _h_686 = STK(15);
    Term _h_687 = STK(16);
    Term _h_688 = STK(17);
    Term _h_689 = STK(18);
    Term _h_670 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_671;
      STK(1) = _h_672;
      STK(2) = _h_673;
      STK(3) = _h_674;
      STK(4) = _h_675;
      STK(5) = _h_676;
      STK(6) = _h_677;
      STK(7) = _h_678;
      STK(8) = _h_679;
      STK(9) = _h_680;
      STK(10) = _h_681;
      STK(11) = _h_682;
      STK(12) = _h_683;
      STK(13) = _h_684;
      STK(14) = _h_685;
      STK(15) = _h_686;
      STK(16) = _h_687;
      STK(17) = _h_688;
      STK(18) = _h_689;
      STK(19) = FID_CONTROLS_K235;
      WL_PUSHN(20);
    } else {
      u64 _t_118 = task_node(e, FID_CONTROLS_K235, WL_CONT, WL_IDX, 1);
      e.mem[_t_118 + 0] = _h_671;
      e.mem[_t_118 + 1] = _h_672;
      e.mem[_t_118 + 2] = _h_673;
      e.mem[_t_118 + 3] = _h_674;
      e.mem[_t_118 + 4] = _h_675;
      e.mem[_t_118 + 5] = _h_676;
      e.mem[_t_118 + 6] = _h_677;
      e.mem[_t_118 + 7] = _h_678;
      e.mem[_t_118 + 8] = _h_679;
      e.mem[_t_118 + 9] = _h_680;
      e.mem[_t_118 + 10] = _h_681;
      e.mem[_t_118 + 11] = _h_682;
      e.mem[_t_118 + 12] = _h_683;
      e.mem[_t_118 + 13] = _h_684;
      e.mem[_t_118 + 14] = _h_685;
      e.mem[_t_118 + 15] = _h_686;
      e.mem[_t_118 + 16] = _h_687;
      e.mem[_t_118 + 17] = _h_688;
      e.mem[_t_118 + 18] = _h_689;
      WL_CONT = term_tsk(FID_CONTROLS_K235, _t_118);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_119 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_119 + 0] = term_ctr(CID_SCON, STAT_OFF + 914);
      e.mem[_t_119 + 1] = _h_670;
      return term_tsk(FID_STRING_APPEND, _t_119);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 914);
    r1 = _h_670;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K235)
  {
    WL_POPN(19);
    Term _h_691 = STK(0);
    Term _h_692 = STK(1);
    Term _h_693 = STK(2);
    Term _h_694 = STK(3);
    Term _h_695 = STK(4);
    Term _h_696 = STK(5);
    Term _h_697 = STK(6);
    Term _h_698 = STK(7);
    Term _h_699 = STK(8);
    Term _h_700 = STK(9);
    Term _h_701 = STK(10);
    Term _h_702 = STK(11);
    Term _h_703 = STK(12);
    Term _h_704 = STK(13);
    Term _h_705 = STK(14);
    Term _h_706 = STK(15);
    Term _h_707 = STK(16);
    Term _h_708 = STK(17);
    Term _h_709 = STK(18);
    Term _h_690 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_691;
      STK(1) = _h_692;
      STK(2) = _h_693;
      STK(3) = _h_694;
      STK(4) = _h_695;
      STK(5) = _h_696;
      STK(6) = _h_697;
      STK(7) = _h_698;
      STK(8) = _h_699;
      STK(9) = _h_700;
      STK(10) = _h_701;
      STK(11) = _h_702;
      STK(12) = _h_703;
      STK(13) = _h_704;
      STK(14) = _h_705;
      STK(15) = _h_706;
      STK(16) = _h_707;
      STK(17) = _h_708;
      STK(18) = _h_709;
      STK(19) = _h_690;
      STK(20) = FID_CONTROLS_K236;
      WL_PUSHN(21);
    } else {
      u64 _t_120 = task_node(e, FID_CONTROLS_K236, WL_CONT, WL_IDX, 1);
      e.mem[_t_120 + 0] = _h_691;
      e.mem[_t_120 + 1] = _h_692;
      e.mem[_t_120 + 2] = _h_693;
      e.mem[_t_120 + 3] = _h_694;
      e.mem[_t_120 + 4] = _h_695;
      e.mem[_t_120 + 5] = _h_696;
      e.mem[_t_120 + 6] = _h_697;
      e.mem[_t_120 + 7] = _h_698;
      e.mem[_t_120 + 8] = _h_699;
      e.mem[_t_120 + 9] = _h_700;
      e.mem[_t_120 + 10] = _h_701;
      e.mem[_t_120 + 11] = _h_702;
      e.mem[_t_120 + 12] = _h_703;
      e.mem[_t_120 + 13] = _h_704;
      e.mem[_t_120 + 14] = _h_705;
      e.mem[_t_120 + 15] = _h_706;
      e.mem[_t_120 + 16] = _h_707;
      e.mem[_t_120 + 17] = _h_708;
      e.mem[_t_120 + 18] = _h_709;
      e.mem[_t_120 + 19] = _h_690;
      WL_CONT = term_tsk(FID_CONTROLS_K236, _t_120);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_121 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_121 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_121 + 1] = 0;
      e.mem[_t_121 + 2] = 0;
      e.mem[_t_121 + 3] = term_ctr(CID_SCON, STAT_OFF + 321);
      e.mem[_t_121 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_121 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_121);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 321);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K236)
  {
    WL_POPN(20);
    Term _h_715 = STK(0);
    Term _h_716 = STK(1);
    Term _h_717 = STK(2);
    Term _h_718 = STK(3);
    Term _h_719 = STK(4);
    Term _h_720 = STK(5);
    Term _h_721 = STK(6);
    Term _h_722 = STK(7);
    Term _h_723 = STK(8);
    Term _h_724 = STK(9);
    Term _h_725 = STK(10);
    Term _h_726 = STK(11);
    Term _h_727 = STK(12);
    Term _h_728 = STK(13);
    Term _h_729 = STK(14);
    Term _h_730 = STK(15);
    Term _h_731 = STK(16);
    Term _h_732 = STK(17);
    Term _h_733 = STK(18);
    Term _h_734 = STK(19);
    u32 _h_710 = r0;
    u32 _h_711 = r1;
    u32 _h_712 = r2;
    Term _h_713 = r3;
    Term _h_714 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_715;
      STK(1) = _h_716;
      STK(2) = _h_717;
      STK(3) = _h_718;
      STK(4) = _h_719;
      STK(5) = _h_720;
      STK(6) = _h_721;
      STK(7) = _h_722;
      STK(8) = _h_723;
      STK(9) = _h_724;
      STK(10) = _h_725;
      STK(11) = _h_726;
      STK(12) = _h_727;
      STK(13) = _h_728;
      STK(14) = _h_729;
      STK(15) = _h_730;
      STK(16) = _h_731;
      STK(17) = _h_732;
      STK(18) = _h_733;
      STK(19) = _h_734;
      STK(20) = FID_CONTROLS_K237;
      WL_PUSHN(21);
    } else {
      u64 _t_122 = task_node(e, FID_CONTROLS_K237, WL_CONT, WL_IDX, 1);
      e.mem[_t_122 + 0] = _h_715;
      e.mem[_t_122 + 1] = _h_716;
      e.mem[_t_122 + 2] = _h_717;
      e.mem[_t_122 + 3] = _h_718;
      e.mem[_t_122 + 4] = _h_719;
      e.mem[_t_122 + 5] = _h_720;
      e.mem[_t_122 + 6] = _h_721;
      e.mem[_t_122 + 7] = _h_722;
      e.mem[_t_122 + 8] = _h_723;
      e.mem[_t_122 + 9] = _h_724;
      e.mem[_t_122 + 10] = _h_725;
      e.mem[_t_122 + 11] = _h_726;
      e.mem[_t_122 + 12] = _h_727;
      e.mem[_t_122 + 13] = _h_728;
      e.mem[_t_122 + 14] = _h_729;
      e.mem[_t_122 + 15] = _h_730;
      e.mem[_t_122 + 16] = _h_731;
      e.mem[_t_122 + 17] = _h_732;
      e.mem[_t_122 + 18] = _h_733;
      e.mem[_t_122 + 19] = _h_734;
      WL_CONT = term_tsk(FID_CONTROLS_K237, _t_122);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_123 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_123 + 0] = _h_710;
      e.mem[_t_123 + 1] = _h_711;
      e.mem[_t_123 + 2] = _h_712;
      e.mem[_t_123 + 3] = _h_713;
      e.mem[_t_123 + 4] = _h_714;
      return term_tsk(FID_VALIDATION, _t_123);
    }
    r0 = _h_710;
    r1 = _h_711;
    r2 = _h_712;
    r3 = _h_713;
    r4 = _h_714;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K237)
  {
    WL_POPN(20);
    Term _h_736 = STK(0);
    Term _h_737 = STK(1);
    Term _h_738 = STK(2);
    Term _h_739 = STK(3);
    Term _h_740 = STK(4);
    Term _h_741 = STK(5);
    Term _h_742 = STK(6);
    Term _h_743 = STK(7);
    Term _h_744 = STK(8);
    Term _h_745 = STK(9);
    Term _h_746 = STK(10);
    Term _h_747 = STK(11);
    Term _h_748 = STK(12);
    Term _h_749 = STK(13);
    Term _h_750 = STK(14);
    Term _h_751 = STK(15);
    Term _h_752 = STK(16);
    Term _h_753 = STK(17);
    Term _h_754 = STK(18);
    Term _h_755 = STK(19);
    Term _h_735 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_736;
      STK(1) = _h_737;
      STK(2) = _h_738;
      STK(3) = _h_739;
      STK(4) = _h_740;
      STK(5) = _h_741;
      STK(6) = _h_742;
      STK(7) = _h_743;
      STK(8) = _h_744;
      STK(9) = _h_745;
      STK(10) = _h_746;
      STK(11) = _h_747;
      STK(12) = _h_748;
      STK(13) = _h_749;
      STK(14) = _h_750;
      STK(15) = _h_751;
      STK(16) = _h_752;
      STK(17) = _h_753;
      STK(18) = _h_754;
      STK(19) = _h_755;
      STK(20) = FID_CONTROLS_K238;
      WL_PUSHN(21);
    } else {
      u64 _t_124 = task_node(e, FID_CONTROLS_K238, WL_CONT, WL_IDX, 1);
      e.mem[_t_124 + 0] = _h_736;
      e.mem[_t_124 + 1] = _h_737;
      e.mem[_t_124 + 2] = _h_738;
      e.mem[_t_124 + 3] = _h_739;
      e.mem[_t_124 + 4] = _h_740;
      e.mem[_t_124 + 5] = _h_741;
      e.mem[_t_124 + 6] = _h_742;
      e.mem[_t_124 + 7] = _h_743;
      e.mem[_t_124 + 8] = _h_744;
      e.mem[_t_124 + 9] = _h_745;
      e.mem[_t_124 + 10] = _h_746;
      e.mem[_t_124 + 11] = _h_747;
      e.mem[_t_124 + 12] = _h_748;
      e.mem[_t_124 + 13] = _h_749;
      e.mem[_t_124 + 14] = _h_750;
      e.mem[_t_124 + 15] = _h_751;
      e.mem[_t_124 + 16] = _h_752;
      e.mem[_t_124 + 17] = _h_753;
      e.mem[_t_124 + 18] = _h_754;
      e.mem[_t_124 + 19] = _h_755;
      WL_CONT = term_tsk(FID_CONTROLS_K238, _t_124);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_125 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_125 + 0] = term_ctr(CID_SCON, STAT_OFF + 934);
      e.mem[_t_125 + 1] = _h_735;
      return term_tsk(FID_STRING_APPEND, _t_125);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 934);
    r1 = _h_735;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K238)
  {
    WL_POPN(20);
    Term _h_757 = STK(0);
    Term _h_758 = STK(1);
    Term _h_759 = STK(2);
    Term _h_760 = STK(3);
    Term _h_761 = STK(4);
    Term _h_762 = STK(5);
    Term _h_763 = STK(6);
    Term _h_764 = STK(7);
    Term _h_765 = STK(8);
    Term _h_766 = STK(9);
    Term _h_767 = STK(10);
    Term _h_768 = STK(11);
    Term _h_769 = STK(12);
    Term _h_770 = STK(13);
    Term _h_771 = STK(14);
    Term _h_772 = STK(15);
    Term _h_773 = STK(16);
    Term _h_774 = STK(17);
    Term _h_775 = STK(18);
    Term _h_776 = STK(19);
    Term _h_756 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_757;
      STK(1) = _h_758;
      STK(2) = _h_759;
      STK(3) = _h_760;
      STK(4) = _h_761;
      STK(5) = _h_762;
      STK(6) = _h_763;
      STK(7) = _h_764;
      STK(8) = _h_765;
      STK(9) = _h_766;
      STK(10) = _h_767;
      STK(11) = _h_768;
      STK(12) = _h_769;
      STK(13) = _h_770;
      STK(14) = _h_771;
      STK(15) = _h_772;
      STK(16) = _h_773;
      STK(17) = _h_774;
      STK(18) = _h_775;
      STK(19) = _h_776;
      STK(20) = _h_756;
      STK(21) = FID_CONTROLS_K239;
      WL_PUSHN(22);
    } else {
      u64 _t_126 = task_node(e, FID_CONTROLS_K239, WL_CONT, WL_IDX, 1);
      e.mem[_t_126 + 0] = _h_757;
      e.mem[_t_126 + 1] = _h_758;
      e.mem[_t_126 + 2] = _h_759;
      e.mem[_t_126 + 3] = _h_760;
      e.mem[_t_126 + 4] = _h_761;
      e.mem[_t_126 + 5] = _h_762;
      e.mem[_t_126 + 6] = _h_763;
      e.mem[_t_126 + 7] = _h_764;
      e.mem[_t_126 + 8] = _h_765;
      e.mem[_t_126 + 9] = _h_766;
      e.mem[_t_126 + 10] = _h_767;
      e.mem[_t_126 + 11] = _h_768;
      e.mem[_t_126 + 12] = _h_769;
      e.mem[_t_126 + 13] = _h_770;
      e.mem[_t_126 + 14] = _h_771;
      e.mem[_t_126 + 15] = _h_772;
      e.mem[_t_126 + 16] = _h_773;
      e.mem[_t_126 + 17] = _h_774;
      e.mem[_t_126 + 18] = _h_775;
      e.mem[_t_126 + 19] = _h_776;
      e.mem[_t_126 + 20] = _h_756;
      WL_CONT = term_tsk(FID_CONTROLS_K239, _t_126);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_127 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_127 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_127 + 1] = 0;
      e.mem[_t_127 + 2] = 0;
      e.mem[_t_127 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_127 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_127 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_127);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K239)
  {
    WL_POPN(21);
    Term _h_782 = STK(0);
    Term _h_783 = STK(1);
    Term _h_784 = STK(2);
    Term _h_785 = STK(3);
    Term _h_786 = STK(4);
    Term _h_787 = STK(5);
    Term _h_788 = STK(6);
    Term _h_789 = STK(7);
    Term _h_790 = STK(8);
    Term _h_791 = STK(9);
    Term _h_792 = STK(10);
    Term _h_793 = STK(11);
    Term _h_794 = STK(12);
    Term _h_795 = STK(13);
    Term _h_796 = STK(14);
    Term _h_797 = STK(15);
    Term _h_798 = STK(16);
    Term _h_799 = STK(17);
    Term _h_800 = STK(18);
    Term _h_801 = STK(19);
    Term _h_802 = STK(20);
    u32 _h_777 = r0;
    u32 _h_778 = r1;
    u32 _h_779 = r2;
    Term _h_780 = r3;
    Term _h_781 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_782;
      STK(1) = _h_783;
      STK(2) = _h_784;
      STK(3) = _h_785;
      STK(4) = _h_786;
      STK(5) = _h_787;
      STK(6) = _h_788;
      STK(7) = _h_789;
      STK(8) = _h_790;
      STK(9) = _h_791;
      STK(10) = _h_792;
      STK(11) = _h_793;
      STK(12) = _h_794;
      STK(13) = _h_795;
      STK(14) = _h_796;
      STK(15) = _h_797;
      STK(16) = _h_798;
      STK(17) = _h_799;
      STK(18) = _h_800;
      STK(19) = _h_801;
      STK(20) = _h_802;
      STK(21) = FID_CONTROLS_K240;
      WL_PUSHN(22);
    } else {
      u64 _t_128 = task_node(e, FID_CONTROLS_K240, WL_CONT, WL_IDX, 1);
      e.mem[_t_128 + 0] = _h_782;
      e.mem[_t_128 + 1] = _h_783;
      e.mem[_t_128 + 2] = _h_784;
      e.mem[_t_128 + 3] = _h_785;
      e.mem[_t_128 + 4] = _h_786;
      e.mem[_t_128 + 5] = _h_787;
      e.mem[_t_128 + 6] = _h_788;
      e.mem[_t_128 + 7] = _h_789;
      e.mem[_t_128 + 8] = _h_790;
      e.mem[_t_128 + 9] = _h_791;
      e.mem[_t_128 + 10] = _h_792;
      e.mem[_t_128 + 11] = _h_793;
      e.mem[_t_128 + 12] = _h_794;
      e.mem[_t_128 + 13] = _h_795;
      e.mem[_t_128 + 14] = _h_796;
      e.mem[_t_128 + 15] = _h_797;
      e.mem[_t_128 + 16] = _h_798;
      e.mem[_t_128 + 17] = _h_799;
      e.mem[_t_128 + 18] = _h_800;
      e.mem[_t_128 + 19] = _h_801;
      e.mem[_t_128 + 20] = _h_802;
      WL_CONT = term_tsk(FID_CONTROLS_K240, _t_128);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_129 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_129 + 0] = _h_777;
      e.mem[_t_129 + 1] = _h_778;
      e.mem[_t_129 + 2] = _h_779;
      e.mem[_t_129 + 3] = _h_780;
      e.mem[_t_129 + 4] = _h_781;
      return term_tsk(FID_VALIDATION, _t_129);
    }
    r0 = _h_777;
    r1 = _h_778;
    r2 = _h_779;
    r3 = _h_780;
    r4 = _h_781;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K240)
  {
    WL_POPN(21);
    Term _h_804 = STK(0);
    Term _h_805 = STK(1);
    Term _h_806 = STK(2);
    Term _h_807 = STK(3);
    Term _h_808 = STK(4);
    Term _h_809 = STK(5);
    Term _h_810 = STK(6);
    Term _h_811 = STK(7);
    Term _h_812 = STK(8);
    Term _h_813 = STK(9);
    Term _h_814 = STK(10);
    Term _h_815 = STK(11);
    Term _h_816 = STK(12);
    Term _h_817 = STK(13);
    Term _h_818 = STK(14);
    Term _h_819 = STK(15);
    Term _h_820 = STK(16);
    Term _h_821 = STK(17);
    Term _h_822 = STK(18);
    Term _h_823 = STK(19);
    Term _h_824 = STK(20);
    Term _h_803 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_804;
      STK(1) = _h_805;
      STK(2) = _h_806;
      STK(3) = _h_807;
      STK(4) = _h_808;
      STK(5) = _h_809;
      STK(6) = _h_810;
      STK(7) = _h_811;
      STK(8) = _h_812;
      STK(9) = _h_813;
      STK(10) = _h_814;
      STK(11) = _h_815;
      STK(12) = _h_816;
      STK(13) = _h_817;
      STK(14) = _h_818;
      STK(15) = _h_819;
      STK(16) = _h_820;
      STK(17) = _h_821;
      STK(18) = _h_822;
      STK(19) = _h_823;
      STK(20) = _h_824;
      STK(21) = FID_CONTROLS_K241;
      WL_PUSHN(22);
    } else {
      u64 _t_130 = task_node(e, FID_CONTROLS_K241, WL_CONT, WL_IDX, 1);
      e.mem[_t_130 + 0] = _h_804;
      e.mem[_t_130 + 1] = _h_805;
      e.mem[_t_130 + 2] = _h_806;
      e.mem[_t_130 + 3] = _h_807;
      e.mem[_t_130 + 4] = _h_808;
      e.mem[_t_130 + 5] = _h_809;
      e.mem[_t_130 + 6] = _h_810;
      e.mem[_t_130 + 7] = _h_811;
      e.mem[_t_130 + 8] = _h_812;
      e.mem[_t_130 + 9] = _h_813;
      e.mem[_t_130 + 10] = _h_814;
      e.mem[_t_130 + 11] = _h_815;
      e.mem[_t_130 + 12] = _h_816;
      e.mem[_t_130 + 13] = _h_817;
      e.mem[_t_130 + 14] = _h_818;
      e.mem[_t_130 + 15] = _h_819;
      e.mem[_t_130 + 16] = _h_820;
      e.mem[_t_130 + 17] = _h_821;
      e.mem[_t_130 + 18] = _h_822;
      e.mem[_t_130 + 19] = _h_823;
      e.mem[_t_130 + 20] = _h_824;
      WL_CONT = term_tsk(FID_CONTROLS_K241, _t_130);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_131 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_131 + 0] = term_ctr(CID_SCON, STAT_OFF + 954);
      e.mem[_t_131 + 1] = _h_803;
      return term_tsk(FID_STRING_APPEND, _t_131);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 954);
    r1 = _h_803;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K241)
  {
    WL_POPN(21);
    Term _h_826 = STK(0);
    Term _h_827 = STK(1);
    Term _h_828 = STK(2);
    Term _h_829 = STK(3);
    Term _h_830 = STK(4);
    Term _h_831 = STK(5);
    Term _h_832 = STK(6);
    Term _h_833 = STK(7);
    Term _h_834 = STK(8);
    Term _h_835 = STK(9);
    Term _h_836 = STK(10);
    Term _h_837 = STK(11);
    Term _h_838 = STK(12);
    Term _h_839 = STK(13);
    Term _h_840 = STK(14);
    Term _h_841 = STK(15);
    Term _h_842 = STK(16);
    Term _h_843 = STK(17);
    Term _h_844 = STK(18);
    Term _h_845 = STK(19);
    Term _h_846 = STK(20);
    Term _h_825 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_826;
      STK(1) = _h_827;
      STK(2) = _h_828;
      STK(3) = _h_829;
      STK(4) = _h_830;
      STK(5) = _h_831;
      STK(6) = _h_832;
      STK(7) = _h_833;
      STK(8) = _h_834;
      STK(9) = _h_835;
      STK(10) = _h_836;
      STK(11) = _h_837;
      STK(12) = _h_838;
      STK(13) = _h_839;
      STK(14) = _h_840;
      STK(15) = _h_841;
      STK(16) = _h_842;
      STK(17) = _h_843;
      STK(18) = _h_844;
      STK(19) = _h_845;
      STK(20) = _h_846;
      STK(21) = _h_825;
      STK(22) = FID_CONTROLS_K242;
      WL_PUSHN(23);
    } else {
      u64 _t_132 = task_node(e, FID_CONTROLS_K242, WL_CONT, WL_IDX, 1);
      e.mem[_t_132 + 0] = _h_826;
      e.mem[_t_132 + 1] = _h_827;
      e.mem[_t_132 + 2] = _h_828;
      e.mem[_t_132 + 3] = _h_829;
      e.mem[_t_132 + 4] = _h_830;
      e.mem[_t_132 + 5] = _h_831;
      e.mem[_t_132 + 6] = _h_832;
      e.mem[_t_132 + 7] = _h_833;
      e.mem[_t_132 + 8] = _h_834;
      e.mem[_t_132 + 9] = _h_835;
      e.mem[_t_132 + 10] = _h_836;
      e.mem[_t_132 + 11] = _h_837;
      e.mem[_t_132 + 12] = _h_838;
      e.mem[_t_132 + 13] = _h_839;
      e.mem[_t_132 + 14] = _h_840;
      e.mem[_t_132 + 15] = _h_841;
      e.mem[_t_132 + 16] = _h_842;
      e.mem[_t_132 + 17] = _h_843;
      e.mem[_t_132 + 18] = _h_844;
      e.mem[_t_132 + 19] = _h_845;
      e.mem[_t_132 + 20] = _h_846;
      e.mem[_t_132 + 21] = _h_825;
      WL_CONT = term_tsk(FID_CONTROLS_K242, _t_132);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_133 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_133 + 0] = term_ctr(CID_CON, STAT_OFF + 381);
      e.mem[_t_133 + 1] = 0;
      e.mem[_t_133 + 2] = 0;
      e.mem[_t_133 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_133 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_133 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_133);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 381);
    r1 = 0;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K242)
  {
    WL_POPN(22);
    Term _h_852 = STK(0);
    Term _h_853 = STK(1);
    Term _h_854 = STK(2);
    Term _h_855 = STK(3);
    Term _h_856 = STK(4);
    Term _h_857 = STK(5);
    Term _h_858 = STK(6);
    Term _h_859 = STK(7);
    Term _h_860 = STK(8);
    Term _h_861 = STK(9);
    Term _h_862 = STK(10);
    Term _h_863 = STK(11);
    Term _h_864 = STK(12);
    Term _h_865 = STK(13);
    Term _h_866 = STK(14);
    Term _h_867 = STK(15);
    Term _h_868 = STK(16);
    Term _h_869 = STK(17);
    Term _h_870 = STK(18);
    Term _h_871 = STK(19);
    Term _h_872 = STK(20);
    Term _h_873 = STK(21);
    u32 _h_847 = r0;
    u32 _h_848 = r1;
    u32 _h_849 = r2;
    Term _h_850 = r3;
    Term _h_851 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_852;
      STK(1) = _h_853;
      STK(2) = _h_854;
      STK(3) = _h_855;
      STK(4) = _h_856;
      STK(5) = _h_857;
      STK(6) = _h_858;
      STK(7) = _h_859;
      STK(8) = _h_860;
      STK(9) = _h_861;
      STK(10) = _h_862;
      STK(11) = _h_863;
      STK(12) = _h_864;
      STK(13) = _h_865;
      STK(14) = _h_866;
      STK(15) = _h_867;
      STK(16) = _h_868;
      STK(17) = _h_869;
      STK(18) = _h_870;
      STK(19) = _h_871;
      STK(20) = _h_872;
      STK(21) = _h_873;
      STK(22) = FID_CONTROLS_K243;
      WL_PUSHN(23);
    } else {
      u64 _t_134 = task_node(e, FID_CONTROLS_K243, WL_CONT, WL_IDX, 1);
      e.mem[_t_134 + 0] = _h_852;
      e.mem[_t_134 + 1] = _h_853;
      e.mem[_t_134 + 2] = _h_854;
      e.mem[_t_134 + 3] = _h_855;
      e.mem[_t_134 + 4] = _h_856;
      e.mem[_t_134 + 5] = _h_857;
      e.mem[_t_134 + 6] = _h_858;
      e.mem[_t_134 + 7] = _h_859;
      e.mem[_t_134 + 8] = _h_860;
      e.mem[_t_134 + 9] = _h_861;
      e.mem[_t_134 + 10] = _h_862;
      e.mem[_t_134 + 11] = _h_863;
      e.mem[_t_134 + 12] = _h_864;
      e.mem[_t_134 + 13] = _h_865;
      e.mem[_t_134 + 14] = _h_866;
      e.mem[_t_134 + 15] = _h_867;
      e.mem[_t_134 + 16] = _h_868;
      e.mem[_t_134 + 17] = _h_869;
      e.mem[_t_134 + 18] = _h_870;
      e.mem[_t_134 + 19] = _h_871;
      e.mem[_t_134 + 20] = _h_872;
      e.mem[_t_134 + 21] = _h_873;
      WL_CONT = term_tsk(FID_CONTROLS_K243, _t_134);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_135 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_135 + 0] = _h_847;
      e.mem[_t_135 + 1] = _h_848;
      e.mem[_t_135 + 2] = _h_849;
      e.mem[_t_135 + 3] = _h_850;
      e.mem[_t_135 + 4] = _h_851;
      return term_tsk(FID_VALIDATION, _t_135);
    }
    r0 = _h_847;
    r1 = _h_848;
    r2 = _h_849;
    r3 = _h_850;
    r4 = _h_851;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K243)
  {
    WL_POPN(22);
    Term _h_875 = STK(0);
    Term _h_876 = STK(1);
    Term _h_877 = STK(2);
    Term _h_878 = STK(3);
    Term _h_879 = STK(4);
    Term _h_880 = STK(5);
    Term _h_881 = STK(6);
    Term _h_882 = STK(7);
    Term _h_883 = STK(8);
    Term _h_884 = STK(9);
    Term _h_885 = STK(10);
    Term _h_886 = STK(11);
    Term _h_887 = STK(12);
    Term _h_888 = STK(13);
    Term _h_889 = STK(14);
    Term _h_890 = STK(15);
    Term _h_891 = STK(16);
    Term _h_892 = STK(17);
    Term _h_893 = STK(18);
    Term _h_894 = STK(19);
    Term _h_895 = STK(20);
    Term _h_896 = STK(21);
    Term _h_874 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(23);
      STK(0) = _h_875;
      STK(1) = _h_876;
      STK(2) = _h_877;
      STK(3) = _h_878;
      STK(4) = _h_879;
      STK(5) = _h_880;
      STK(6) = _h_881;
      STK(7) = _h_882;
      STK(8) = _h_883;
      STK(9) = _h_884;
      STK(10) = _h_885;
      STK(11) = _h_886;
      STK(12) = _h_887;
      STK(13) = _h_888;
      STK(14) = _h_889;
      STK(15) = _h_890;
      STK(16) = _h_891;
      STK(17) = _h_892;
      STK(18) = _h_893;
      STK(19) = _h_894;
      STK(20) = _h_895;
      STK(21) = _h_896;
      STK(22) = FID_CONTROLS_K244;
      WL_PUSHN(23);
    } else {
      u64 _t_136 = task_node(e, FID_CONTROLS_K244, WL_CONT, WL_IDX, 1);
      e.mem[_t_136 + 0] = _h_875;
      e.mem[_t_136 + 1] = _h_876;
      e.mem[_t_136 + 2] = _h_877;
      e.mem[_t_136 + 3] = _h_878;
      e.mem[_t_136 + 4] = _h_879;
      e.mem[_t_136 + 5] = _h_880;
      e.mem[_t_136 + 6] = _h_881;
      e.mem[_t_136 + 7] = _h_882;
      e.mem[_t_136 + 8] = _h_883;
      e.mem[_t_136 + 9] = _h_884;
      e.mem[_t_136 + 10] = _h_885;
      e.mem[_t_136 + 11] = _h_886;
      e.mem[_t_136 + 12] = _h_887;
      e.mem[_t_136 + 13] = _h_888;
      e.mem[_t_136 + 14] = _h_889;
      e.mem[_t_136 + 15] = _h_890;
      e.mem[_t_136 + 16] = _h_891;
      e.mem[_t_136 + 17] = _h_892;
      e.mem[_t_136 + 18] = _h_893;
      e.mem[_t_136 + 19] = _h_894;
      e.mem[_t_136 + 20] = _h_895;
      e.mem[_t_136 + 21] = _h_896;
      WL_CONT = term_tsk(FID_CONTROLS_K244, _t_136);
      WL_IDX = 22;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_137 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_137 + 0] = term_ctr(CID_SCON, STAT_OFF + 974);
      e.mem[_t_137 + 1] = _h_874;
      return term_tsk(FID_STRING_APPEND, _t_137);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 974);
    r1 = _h_874;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K244)
  {
    WL_POPN(22);
    Term _h_898 = STK(0);
    Term _h_899 = STK(1);
    Term _h_900 = STK(2);
    Term _h_901 = STK(3);
    Term _h_902 = STK(4);
    Term _h_903 = STK(5);
    Term _h_904 = STK(6);
    Term _h_905 = STK(7);
    Term _h_906 = STK(8);
    Term _h_907 = STK(9);
    Term _h_908 = STK(10);
    Term _h_909 = STK(11);
    Term _h_910 = STK(12);
    Term _h_911 = STK(13);
    Term _h_912 = STK(14);
    Term _h_913 = STK(15);
    Term _h_914 = STK(16);
    Term _h_915 = STK(17);
    Term _h_916 = STK(18);
    Term _h_917 = STK(19);
    Term _h_918 = STK(20);
    Term _h_919 = STK(21);
    Term _h_897 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_898;
      STK(1) = _h_899;
      STK(2) = _h_900;
      STK(3) = _h_901;
      STK(4) = _h_902;
      STK(5) = _h_903;
      STK(6) = _h_904;
      STK(7) = _h_905;
      STK(8) = _h_906;
      STK(9) = _h_907;
      STK(10) = _h_908;
      STK(11) = _h_909;
      STK(12) = _h_910;
      STK(13) = _h_911;
      STK(14) = _h_912;
      STK(15) = _h_913;
      STK(16) = _h_914;
      STK(17) = _h_915;
      STK(18) = _h_916;
      STK(19) = _h_917;
      STK(20) = _h_918;
      STK(21) = _h_919;
      STK(22) = _h_897;
      STK(23) = FID_CONTROLS_K245;
      WL_PUSHN(24);
    } else {
      u64 _t_138 = task_node(e, FID_CONTROLS_K245, WL_CONT, WL_IDX, 1);
      e.mem[_t_138 + 0] = _h_898;
      e.mem[_t_138 + 1] = _h_899;
      e.mem[_t_138 + 2] = _h_900;
      e.mem[_t_138 + 3] = _h_901;
      e.mem[_t_138 + 4] = _h_902;
      e.mem[_t_138 + 5] = _h_903;
      e.mem[_t_138 + 6] = _h_904;
      e.mem[_t_138 + 7] = _h_905;
      e.mem[_t_138 + 8] = _h_906;
      e.mem[_t_138 + 9] = _h_907;
      e.mem[_t_138 + 10] = _h_908;
      e.mem[_t_138 + 11] = _h_909;
      e.mem[_t_138 + 12] = _h_910;
      e.mem[_t_138 + 13] = _h_911;
      e.mem[_t_138 + 14] = _h_912;
      e.mem[_t_138 + 15] = _h_913;
      e.mem[_t_138 + 16] = _h_914;
      e.mem[_t_138 + 17] = _h_915;
      e.mem[_t_138 + 18] = _h_916;
      e.mem[_t_138 + 19] = _h_917;
      e.mem[_t_138 + 20] = _h_918;
      e.mem[_t_138 + 21] = _h_919;
      e.mem[_t_138 + 22] = _h_897;
      WL_CONT = term_tsk(FID_CONTROLS_K245, _t_138);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_139 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_139 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_139 + 1] = 1;
      e.mem[_t_139 + 2] = 0;
      e.mem[_t_139 + 3] = term_ctr(CID_SCON, STAT_OFF + 321);
      e.mem[_t_139 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_139 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_139);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 321);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K245)
  {
    WL_POPN(23);
    Term _h_925 = STK(0);
    Term _h_926 = STK(1);
    Term _h_927 = STK(2);
    Term _h_928 = STK(3);
    Term _h_929 = STK(4);
    Term _h_930 = STK(5);
    Term _h_931 = STK(6);
    Term _h_932 = STK(7);
    Term _h_933 = STK(8);
    Term _h_934 = STK(9);
    Term _h_935 = STK(10);
    Term _h_936 = STK(11);
    Term _h_937 = STK(12);
    Term _h_938 = STK(13);
    Term _h_939 = STK(14);
    Term _h_940 = STK(15);
    Term _h_941 = STK(16);
    Term _h_942 = STK(17);
    Term _h_943 = STK(18);
    Term _h_944 = STK(19);
    Term _h_945 = STK(20);
    Term _h_946 = STK(21);
    Term _h_947 = STK(22);
    u32 _h_920 = r0;
    u32 _h_921 = r1;
    u32 _h_922 = r2;
    Term _h_923 = r3;
    Term _h_924 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_925;
      STK(1) = _h_926;
      STK(2) = _h_927;
      STK(3) = _h_928;
      STK(4) = _h_929;
      STK(5) = _h_930;
      STK(6) = _h_931;
      STK(7) = _h_932;
      STK(8) = _h_933;
      STK(9) = _h_934;
      STK(10) = _h_935;
      STK(11) = _h_936;
      STK(12) = _h_937;
      STK(13) = _h_938;
      STK(14) = _h_939;
      STK(15) = _h_940;
      STK(16) = _h_941;
      STK(17) = _h_942;
      STK(18) = _h_943;
      STK(19) = _h_944;
      STK(20) = _h_945;
      STK(21) = _h_946;
      STK(22) = _h_947;
      STK(23) = FID_CONTROLS_K246;
      WL_PUSHN(24);
    } else {
      u64 _t_140 = task_node(e, FID_CONTROLS_K246, WL_CONT, WL_IDX, 1);
      e.mem[_t_140 + 0] = _h_925;
      e.mem[_t_140 + 1] = _h_926;
      e.mem[_t_140 + 2] = _h_927;
      e.mem[_t_140 + 3] = _h_928;
      e.mem[_t_140 + 4] = _h_929;
      e.mem[_t_140 + 5] = _h_930;
      e.mem[_t_140 + 6] = _h_931;
      e.mem[_t_140 + 7] = _h_932;
      e.mem[_t_140 + 8] = _h_933;
      e.mem[_t_140 + 9] = _h_934;
      e.mem[_t_140 + 10] = _h_935;
      e.mem[_t_140 + 11] = _h_936;
      e.mem[_t_140 + 12] = _h_937;
      e.mem[_t_140 + 13] = _h_938;
      e.mem[_t_140 + 14] = _h_939;
      e.mem[_t_140 + 15] = _h_940;
      e.mem[_t_140 + 16] = _h_941;
      e.mem[_t_140 + 17] = _h_942;
      e.mem[_t_140 + 18] = _h_943;
      e.mem[_t_140 + 19] = _h_944;
      e.mem[_t_140 + 20] = _h_945;
      e.mem[_t_140 + 21] = _h_946;
      e.mem[_t_140 + 22] = _h_947;
      WL_CONT = term_tsk(FID_CONTROLS_K246, _t_140);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_141 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_141 + 0] = _h_920;
      e.mem[_t_141 + 1] = _h_921;
      e.mem[_t_141 + 2] = _h_922;
      e.mem[_t_141 + 3] = _h_923;
      e.mem[_t_141 + 4] = _h_924;
      return term_tsk(FID_VALIDATION, _t_141);
    }
    r0 = _h_920;
    r1 = _h_921;
    r2 = _h_922;
    r3 = _h_923;
    r4 = _h_924;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K246)
  {
    WL_POPN(23);
    Term _h_949 = STK(0);
    Term _h_950 = STK(1);
    Term _h_951 = STK(2);
    Term _h_952 = STK(3);
    Term _h_953 = STK(4);
    Term _h_954 = STK(5);
    Term _h_955 = STK(6);
    Term _h_956 = STK(7);
    Term _h_957 = STK(8);
    Term _h_958 = STK(9);
    Term _h_959 = STK(10);
    Term _h_960 = STK(11);
    Term _h_961 = STK(12);
    Term _h_962 = STK(13);
    Term _h_963 = STK(14);
    Term _h_964 = STK(15);
    Term _h_965 = STK(16);
    Term _h_966 = STK(17);
    Term _h_967 = STK(18);
    Term _h_968 = STK(19);
    Term _h_969 = STK(20);
    Term _h_970 = STK(21);
    Term _h_971 = STK(22);
    Term _h_948 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(24);
      STK(0) = _h_949;
      STK(1) = _h_950;
      STK(2) = _h_951;
      STK(3) = _h_952;
      STK(4) = _h_953;
      STK(5) = _h_954;
      STK(6) = _h_955;
      STK(7) = _h_956;
      STK(8) = _h_957;
      STK(9) = _h_958;
      STK(10) = _h_959;
      STK(11) = _h_960;
      STK(12) = _h_961;
      STK(13) = _h_962;
      STK(14) = _h_963;
      STK(15) = _h_964;
      STK(16) = _h_965;
      STK(17) = _h_966;
      STK(18) = _h_967;
      STK(19) = _h_968;
      STK(20) = _h_969;
      STK(21) = _h_970;
      STK(22) = _h_971;
      STK(23) = FID_CONTROLS_K247;
      WL_PUSHN(24);
    } else {
      u64 _t_142 = task_node(e, FID_CONTROLS_K247, WL_CONT, WL_IDX, 1);
      e.mem[_t_142 + 0] = _h_949;
      e.mem[_t_142 + 1] = _h_950;
      e.mem[_t_142 + 2] = _h_951;
      e.mem[_t_142 + 3] = _h_952;
      e.mem[_t_142 + 4] = _h_953;
      e.mem[_t_142 + 5] = _h_954;
      e.mem[_t_142 + 6] = _h_955;
      e.mem[_t_142 + 7] = _h_956;
      e.mem[_t_142 + 8] = _h_957;
      e.mem[_t_142 + 9] = _h_958;
      e.mem[_t_142 + 10] = _h_959;
      e.mem[_t_142 + 11] = _h_960;
      e.mem[_t_142 + 12] = _h_961;
      e.mem[_t_142 + 13] = _h_962;
      e.mem[_t_142 + 14] = _h_963;
      e.mem[_t_142 + 15] = _h_964;
      e.mem[_t_142 + 16] = _h_965;
      e.mem[_t_142 + 17] = _h_966;
      e.mem[_t_142 + 18] = _h_967;
      e.mem[_t_142 + 19] = _h_968;
      e.mem[_t_142 + 20] = _h_969;
      e.mem[_t_142 + 21] = _h_970;
      e.mem[_t_142 + 22] = _h_971;
      WL_CONT = term_tsk(FID_CONTROLS_K247, _t_142);
      WL_IDX = 23;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_143 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_143 + 0] = term_ctr(CID_SCON, STAT_OFF + 994);
      e.mem[_t_143 + 1] = _h_948;
      return term_tsk(FID_STRING_APPEND, _t_143);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 994);
    r1 = _h_948;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K247)
  {
    WL_POPN(23);
    Term _h_973 = STK(0);
    Term _h_974 = STK(1);
    Term _h_975 = STK(2);
    Term _h_976 = STK(3);
    Term _h_977 = STK(4);
    Term _h_978 = STK(5);
    Term _h_979 = STK(6);
    Term _h_980 = STK(7);
    Term _h_981 = STK(8);
    Term _h_982 = STK(9);
    Term _h_983 = STK(10);
    Term _h_984 = STK(11);
    Term _h_985 = STK(12);
    Term _h_986 = STK(13);
    Term _h_987 = STK(14);
    Term _h_988 = STK(15);
    Term _h_989 = STK(16);
    Term _h_990 = STK(17);
    Term _h_991 = STK(18);
    Term _h_992 = STK(19);
    Term _h_993 = STK(20);
    Term _h_994 = STK(21);
    Term _h_995 = STK(22);
    Term _h_972 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _h_973;
      STK(1) = _h_974;
      STK(2) = _h_975;
      STK(3) = _h_976;
      STK(4) = _h_977;
      STK(5) = _h_978;
      STK(6) = _h_979;
      STK(7) = _h_980;
      STK(8) = _h_981;
      STK(9) = _h_982;
      STK(10) = _h_983;
      STK(11) = _h_984;
      STK(12) = _h_985;
      STK(13) = _h_986;
      STK(14) = _h_987;
      STK(15) = _h_988;
      STK(16) = _h_989;
      STK(17) = _h_990;
      STK(18) = _h_991;
      STK(19) = _h_992;
      STK(20) = _h_993;
      STK(21) = _h_994;
      STK(22) = _h_995;
      STK(23) = _h_972;
      STK(24) = FID_CONTROLS_K248;
      WL_PUSHN(25);
    } else {
      u64 _t_144 = task_node(e, FID_CONTROLS_K248, WL_CONT, WL_IDX, 1);
      e.mem[_t_144 + 0] = _h_973;
      e.mem[_t_144 + 1] = _h_974;
      e.mem[_t_144 + 2] = _h_975;
      e.mem[_t_144 + 3] = _h_976;
      e.mem[_t_144 + 4] = _h_977;
      e.mem[_t_144 + 5] = _h_978;
      e.mem[_t_144 + 6] = _h_979;
      e.mem[_t_144 + 7] = _h_980;
      e.mem[_t_144 + 8] = _h_981;
      e.mem[_t_144 + 9] = _h_982;
      e.mem[_t_144 + 10] = _h_983;
      e.mem[_t_144 + 11] = _h_984;
      e.mem[_t_144 + 12] = _h_985;
      e.mem[_t_144 + 13] = _h_986;
      e.mem[_t_144 + 14] = _h_987;
      e.mem[_t_144 + 15] = _h_988;
      e.mem[_t_144 + 16] = _h_989;
      e.mem[_t_144 + 17] = _h_990;
      e.mem[_t_144 + 18] = _h_991;
      e.mem[_t_144 + 19] = _h_992;
      e.mem[_t_144 + 20] = _h_993;
      e.mem[_t_144 + 21] = _h_994;
      e.mem[_t_144 + 22] = _h_995;
      e.mem[_t_144 + 23] = _h_972;
      WL_CONT = term_tsk(FID_CONTROLS_K248, _t_144);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_145 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_145 + 0] = term_ctr(CID_CON, STAT_OFF + 467);
      e.mem[_t_145 + 1] = 1;
      e.mem[_t_145 + 2] = 0;
      e.mem[_t_145 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_145 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_145 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_145);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 467);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K248)
  {
    WL_POPN(24);
    Term _h_1001 = STK(0);
    Term _h_1002 = STK(1);
    Term _h_1003 = STK(2);
    Term _h_1004 = STK(3);
    Term _h_1005 = STK(4);
    Term _h_1006 = STK(5);
    Term _h_1007 = STK(6);
    Term _h_1008 = STK(7);
    Term _h_1009 = STK(8);
    Term _h_1010 = STK(9);
    Term _h_1011 = STK(10);
    Term _h_1012 = STK(11);
    Term _h_1013 = STK(12);
    Term _h_1014 = STK(13);
    Term _h_1015 = STK(14);
    Term _h_1016 = STK(15);
    Term _h_1017 = STK(16);
    Term _h_1018 = STK(17);
    Term _h_1019 = STK(18);
    Term _h_1020 = STK(19);
    Term _h_1021 = STK(20);
    Term _h_1022 = STK(21);
    Term _h_1023 = STK(22);
    Term _h_1024 = STK(23);
    u32 _h_996 = r0;
    u32 _h_997 = r1;
    u32 _h_998 = r2;
    Term _h_999 = r3;
    Term _h_1000 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _h_1001;
      STK(1) = _h_1002;
      STK(2) = _h_1003;
      STK(3) = _h_1004;
      STK(4) = _h_1005;
      STK(5) = _h_1006;
      STK(6) = _h_1007;
      STK(7) = _h_1008;
      STK(8) = _h_1009;
      STK(9) = _h_1010;
      STK(10) = _h_1011;
      STK(11) = _h_1012;
      STK(12) = _h_1013;
      STK(13) = _h_1014;
      STK(14) = _h_1015;
      STK(15) = _h_1016;
      STK(16) = _h_1017;
      STK(17) = _h_1018;
      STK(18) = _h_1019;
      STK(19) = _h_1020;
      STK(20) = _h_1021;
      STK(21) = _h_1022;
      STK(22) = _h_1023;
      STK(23) = _h_1024;
      STK(24) = FID_CONTROLS_K249;
      WL_PUSHN(25);
    } else {
      u64 _t_146 = task_node(e, FID_CONTROLS_K249, WL_CONT, WL_IDX, 1);
      e.mem[_t_146 + 0] = _h_1001;
      e.mem[_t_146 + 1] = _h_1002;
      e.mem[_t_146 + 2] = _h_1003;
      e.mem[_t_146 + 3] = _h_1004;
      e.mem[_t_146 + 4] = _h_1005;
      e.mem[_t_146 + 5] = _h_1006;
      e.mem[_t_146 + 6] = _h_1007;
      e.mem[_t_146 + 7] = _h_1008;
      e.mem[_t_146 + 8] = _h_1009;
      e.mem[_t_146 + 9] = _h_1010;
      e.mem[_t_146 + 10] = _h_1011;
      e.mem[_t_146 + 11] = _h_1012;
      e.mem[_t_146 + 12] = _h_1013;
      e.mem[_t_146 + 13] = _h_1014;
      e.mem[_t_146 + 14] = _h_1015;
      e.mem[_t_146 + 15] = _h_1016;
      e.mem[_t_146 + 16] = _h_1017;
      e.mem[_t_146 + 17] = _h_1018;
      e.mem[_t_146 + 18] = _h_1019;
      e.mem[_t_146 + 19] = _h_1020;
      e.mem[_t_146 + 20] = _h_1021;
      e.mem[_t_146 + 21] = _h_1022;
      e.mem[_t_146 + 22] = _h_1023;
      e.mem[_t_146 + 23] = _h_1024;
      WL_CONT = term_tsk(FID_CONTROLS_K249, _t_146);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_147 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_147 + 0] = _h_996;
      e.mem[_t_147 + 1] = _h_997;
      e.mem[_t_147 + 2] = _h_998;
      e.mem[_t_147 + 3] = _h_999;
      e.mem[_t_147 + 4] = _h_1000;
      return term_tsk(FID_VALIDATION, _t_147);
    }
    r0 = _h_996;
    r1 = _h_997;
    r2 = _h_998;
    r3 = _h_999;
    r4 = _h_1000;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K249)
  {
    WL_POPN(24);
    Term _h_1026 = STK(0);
    Term _h_1027 = STK(1);
    Term _h_1028 = STK(2);
    Term _h_1029 = STK(3);
    Term _h_1030 = STK(4);
    Term _h_1031 = STK(5);
    Term _h_1032 = STK(6);
    Term _h_1033 = STK(7);
    Term _h_1034 = STK(8);
    Term _h_1035 = STK(9);
    Term _h_1036 = STK(10);
    Term _h_1037 = STK(11);
    Term _h_1038 = STK(12);
    Term _h_1039 = STK(13);
    Term _h_1040 = STK(14);
    Term _h_1041 = STK(15);
    Term _h_1042 = STK(16);
    Term _h_1043 = STK(17);
    Term _h_1044 = STK(18);
    Term _h_1045 = STK(19);
    Term _h_1046 = STK(20);
    Term _h_1047 = STK(21);
    Term _h_1048 = STK(22);
    Term _h_1049 = STK(23);
    Term _h_1025 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _h_1026;
      STK(1) = _h_1027;
      STK(2) = _h_1028;
      STK(3) = _h_1029;
      STK(4) = _h_1030;
      STK(5) = _h_1031;
      STK(6) = _h_1032;
      STK(7) = _h_1033;
      STK(8) = _h_1034;
      STK(9) = _h_1035;
      STK(10) = _h_1036;
      STK(11) = _h_1037;
      STK(12) = _h_1038;
      STK(13) = _h_1039;
      STK(14) = _h_1040;
      STK(15) = _h_1041;
      STK(16) = _h_1042;
      STK(17) = _h_1043;
      STK(18) = _h_1044;
      STK(19) = _h_1045;
      STK(20) = _h_1046;
      STK(21) = _h_1047;
      STK(22) = _h_1048;
      STK(23) = _h_1049;
      STK(24) = FID_CONTROLS_K250;
      WL_PUSHN(25);
    } else {
      u64 _t_148 = task_node(e, FID_CONTROLS_K250, WL_CONT, WL_IDX, 1);
      e.mem[_t_148 + 0] = _h_1026;
      e.mem[_t_148 + 1] = _h_1027;
      e.mem[_t_148 + 2] = _h_1028;
      e.mem[_t_148 + 3] = _h_1029;
      e.mem[_t_148 + 4] = _h_1030;
      e.mem[_t_148 + 5] = _h_1031;
      e.mem[_t_148 + 6] = _h_1032;
      e.mem[_t_148 + 7] = _h_1033;
      e.mem[_t_148 + 8] = _h_1034;
      e.mem[_t_148 + 9] = _h_1035;
      e.mem[_t_148 + 10] = _h_1036;
      e.mem[_t_148 + 11] = _h_1037;
      e.mem[_t_148 + 12] = _h_1038;
      e.mem[_t_148 + 13] = _h_1039;
      e.mem[_t_148 + 14] = _h_1040;
      e.mem[_t_148 + 15] = _h_1041;
      e.mem[_t_148 + 16] = _h_1042;
      e.mem[_t_148 + 17] = _h_1043;
      e.mem[_t_148 + 18] = _h_1044;
      e.mem[_t_148 + 19] = _h_1045;
      e.mem[_t_148 + 20] = _h_1046;
      e.mem[_t_148 + 21] = _h_1047;
      e.mem[_t_148 + 22] = _h_1048;
      e.mem[_t_148 + 23] = _h_1049;
      WL_CONT = term_tsk(FID_CONTROLS_K250, _t_148);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_149 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_149 + 0] = term_ctr(CID_SCON, STAT_OFF + 1014);
      e.mem[_t_149 + 1] = _h_1025;
      return term_tsk(FID_STRING_APPEND, _t_149);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1014);
    r1 = _h_1025;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K250)
  {
    WL_POPN(24);
    Term _h_1051 = STK(0);
    Term _h_1052 = STK(1);
    Term _h_1053 = STK(2);
    Term _h_1054 = STK(3);
    Term _h_1055 = STK(4);
    Term _h_1056 = STK(5);
    Term _h_1057 = STK(6);
    Term _h_1058 = STK(7);
    Term _h_1059 = STK(8);
    Term _h_1060 = STK(9);
    Term _h_1061 = STK(10);
    Term _h_1062 = STK(11);
    Term _h_1063 = STK(12);
    Term _h_1064 = STK(13);
    Term _h_1065 = STK(14);
    Term _h_1066 = STK(15);
    Term _h_1067 = STK(16);
    Term _h_1068 = STK(17);
    Term _h_1069 = STK(18);
    Term _h_1070 = STK(19);
    Term _h_1071 = STK(20);
    Term _h_1072 = STK(21);
    Term _h_1073 = STK(22);
    Term _h_1074 = STK(23);
    Term _h_1050 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _h_1051;
      STK(1) = _h_1052;
      STK(2) = _h_1053;
      STK(3) = _h_1054;
      STK(4) = _h_1055;
      STK(5) = _h_1056;
      STK(6) = _h_1057;
      STK(7) = _h_1058;
      STK(8) = _h_1059;
      STK(9) = _h_1060;
      STK(10) = _h_1061;
      STK(11) = _h_1062;
      STK(12) = _h_1063;
      STK(13) = _h_1064;
      STK(14) = _h_1065;
      STK(15) = _h_1066;
      STK(16) = _h_1067;
      STK(17) = _h_1068;
      STK(18) = _h_1069;
      STK(19) = _h_1070;
      STK(20) = _h_1071;
      STK(21) = _h_1072;
      STK(22) = _h_1073;
      STK(23) = _h_1074;
      STK(24) = _h_1050;
      STK(25) = FID_CONTROLS_K251;
      WL_PUSHN(26);
    } else {
      u64 _t_150 = task_node(e, FID_CONTROLS_K251, WL_CONT, WL_IDX, 1);
      e.mem[_t_150 + 0] = _h_1051;
      e.mem[_t_150 + 1] = _h_1052;
      e.mem[_t_150 + 2] = _h_1053;
      e.mem[_t_150 + 3] = _h_1054;
      e.mem[_t_150 + 4] = _h_1055;
      e.mem[_t_150 + 5] = _h_1056;
      e.mem[_t_150 + 6] = _h_1057;
      e.mem[_t_150 + 7] = _h_1058;
      e.mem[_t_150 + 8] = _h_1059;
      e.mem[_t_150 + 9] = _h_1060;
      e.mem[_t_150 + 10] = _h_1061;
      e.mem[_t_150 + 11] = _h_1062;
      e.mem[_t_150 + 12] = _h_1063;
      e.mem[_t_150 + 13] = _h_1064;
      e.mem[_t_150 + 14] = _h_1065;
      e.mem[_t_150 + 15] = _h_1066;
      e.mem[_t_150 + 16] = _h_1067;
      e.mem[_t_150 + 17] = _h_1068;
      e.mem[_t_150 + 18] = _h_1069;
      e.mem[_t_150 + 19] = _h_1070;
      e.mem[_t_150 + 20] = _h_1071;
      e.mem[_t_150 + 21] = _h_1072;
      e.mem[_t_150 + 22] = _h_1073;
      e.mem[_t_150 + 23] = _h_1074;
      e.mem[_t_150 + 24] = _h_1050;
      WL_CONT = term_tsk(FID_CONTROLS_K251, _t_150);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_151 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_151 + 0] = term_ctr(CID_CON, STAT_OFF + 522);
      e.mem[_t_151 + 1] = 1;
      e.mem[_t_151 + 2] = 0;
      e.mem[_t_151 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_151 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_151 + 5] = 2;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_151);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 522);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 2;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K251)
  {
    WL_POPN(25);
    Term _h_1080 = STK(0);
    Term _h_1081 = STK(1);
    Term _h_1082 = STK(2);
    Term _h_1083 = STK(3);
    Term _h_1084 = STK(4);
    Term _h_1085 = STK(5);
    Term _h_1086 = STK(6);
    Term _h_1087 = STK(7);
    Term _h_1088 = STK(8);
    Term _h_1089 = STK(9);
    Term _h_1090 = STK(10);
    Term _h_1091 = STK(11);
    Term _h_1092 = STK(12);
    Term _h_1093 = STK(13);
    Term _h_1094 = STK(14);
    Term _h_1095 = STK(15);
    Term _h_1096 = STK(16);
    Term _h_1097 = STK(17);
    Term _h_1098 = STK(18);
    Term _h_1099 = STK(19);
    Term _h_1100 = STK(20);
    Term _h_1101 = STK(21);
    Term _h_1102 = STK(22);
    Term _h_1103 = STK(23);
    Term _h_1104 = STK(24);
    u32 _h_1075 = r0;
    u32 _h_1076 = r1;
    u32 _h_1077 = r2;
    Term _h_1078 = r3;
    Term _h_1079 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _h_1080;
      STK(1) = _h_1081;
      STK(2) = _h_1082;
      STK(3) = _h_1083;
      STK(4) = _h_1084;
      STK(5) = _h_1085;
      STK(6) = _h_1086;
      STK(7) = _h_1087;
      STK(8) = _h_1088;
      STK(9) = _h_1089;
      STK(10) = _h_1090;
      STK(11) = _h_1091;
      STK(12) = _h_1092;
      STK(13) = _h_1093;
      STK(14) = _h_1094;
      STK(15) = _h_1095;
      STK(16) = _h_1096;
      STK(17) = _h_1097;
      STK(18) = _h_1098;
      STK(19) = _h_1099;
      STK(20) = _h_1100;
      STK(21) = _h_1101;
      STK(22) = _h_1102;
      STK(23) = _h_1103;
      STK(24) = _h_1104;
      STK(25) = FID_CONTROLS_K252;
      WL_PUSHN(26);
    } else {
      u64 _t_152 = task_node(e, FID_CONTROLS_K252, WL_CONT, WL_IDX, 1);
      e.mem[_t_152 + 0] = _h_1080;
      e.mem[_t_152 + 1] = _h_1081;
      e.mem[_t_152 + 2] = _h_1082;
      e.mem[_t_152 + 3] = _h_1083;
      e.mem[_t_152 + 4] = _h_1084;
      e.mem[_t_152 + 5] = _h_1085;
      e.mem[_t_152 + 6] = _h_1086;
      e.mem[_t_152 + 7] = _h_1087;
      e.mem[_t_152 + 8] = _h_1088;
      e.mem[_t_152 + 9] = _h_1089;
      e.mem[_t_152 + 10] = _h_1090;
      e.mem[_t_152 + 11] = _h_1091;
      e.mem[_t_152 + 12] = _h_1092;
      e.mem[_t_152 + 13] = _h_1093;
      e.mem[_t_152 + 14] = _h_1094;
      e.mem[_t_152 + 15] = _h_1095;
      e.mem[_t_152 + 16] = _h_1096;
      e.mem[_t_152 + 17] = _h_1097;
      e.mem[_t_152 + 18] = _h_1098;
      e.mem[_t_152 + 19] = _h_1099;
      e.mem[_t_152 + 20] = _h_1100;
      e.mem[_t_152 + 21] = _h_1101;
      e.mem[_t_152 + 22] = _h_1102;
      e.mem[_t_152 + 23] = _h_1103;
      e.mem[_t_152 + 24] = _h_1104;
      WL_CONT = term_tsk(FID_CONTROLS_K252, _t_152);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_153 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_153 + 0] = _h_1075;
      e.mem[_t_153 + 1] = _h_1076;
      e.mem[_t_153 + 2] = _h_1077;
      e.mem[_t_153 + 3] = _h_1078;
      e.mem[_t_153 + 4] = _h_1079;
      return term_tsk(FID_VALIDATION, _t_153);
    }
    r0 = _h_1075;
    r1 = _h_1076;
    r2 = _h_1077;
    r3 = _h_1078;
    r4 = _h_1079;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K252)
  {
    WL_POPN(25);
    Term _h_1106 = STK(0);
    Term _h_1107 = STK(1);
    Term _h_1108 = STK(2);
    Term _h_1109 = STK(3);
    Term _h_1110 = STK(4);
    Term _h_1111 = STK(5);
    Term _h_1112 = STK(6);
    Term _h_1113 = STK(7);
    Term _h_1114 = STK(8);
    Term _h_1115 = STK(9);
    Term _h_1116 = STK(10);
    Term _h_1117 = STK(11);
    Term _h_1118 = STK(12);
    Term _h_1119 = STK(13);
    Term _h_1120 = STK(14);
    Term _h_1121 = STK(15);
    Term _h_1122 = STK(16);
    Term _h_1123 = STK(17);
    Term _h_1124 = STK(18);
    Term _h_1125 = STK(19);
    Term _h_1126 = STK(20);
    Term _h_1127 = STK(21);
    Term _h_1128 = STK(22);
    Term _h_1129 = STK(23);
    Term _h_1130 = STK(24);
    Term _h_1105 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _h_1106;
      STK(1) = _h_1107;
      STK(2) = _h_1108;
      STK(3) = _h_1109;
      STK(4) = _h_1110;
      STK(5) = _h_1111;
      STK(6) = _h_1112;
      STK(7) = _h_1113;
      STK(8) = _h_1114;
      STK(9) = _h_1115;
      STK(10) = _h_1116;
      STK(11) = _h_1117;
      STK(12) = _h_1118;
      STK(13) = _h_1119;
      STK(14) = _h_1120;
      STK(15) = _h_1121;
      STK(16) = _h_1122;
      STK(17) = _h_1123;
      STK(18) = _h_1124;
      STK(19) = _h_1125;
      STK(20) = _h_1126;
      STK(21) = _h_1127;
      STK(22) = _h_1128;
      STK(23) = _h_1129;
      STK(24) = _h_1130;
      STK(25) = FID_CONTROLS_K253;
      WL_PUSHN(26);
    } else {
      u64 _t_154 = task_node(e, FID_CONTROLS_K253, WL_CONT, WL_IDX, 1);
      e.mem[_t_154 + 0] = _h_1106;
      e.mem[_t_154 + 1] = _h_1107;
      e.mem[_t_154 + 2] = _h_1108;
      e.mem[_t_154 + 3] = _h_1109;
      e.mem[_t_154 + 4] = _h_1110;
      e.mem[_t_154 + 5] = _h_1111;
      e.mem[_t_154 + 6] = _h_1112;
      e.mem[_t_154 + 7] = _h_1113;
      e.mem[_t_154 + 8] = _h_1114;
      e.mem[_t_154 + 9] = _h_1115;
      e.mem[_t_154 + 10] = _h_1116;
      e.mem[_t_154 + 11] = _h_1117;
      e.mem[_t_154 + 12] = _h_1118;
      e.mem[_t_154 + 13] = _h_1119;
      e.mem[_t_154 + 14] = _h_1120;
      e.mem[_t_154 + 15] = _h_1121;
      e.mem[_t_154 + 16] = _h_1122;
      e.mem[_t_154 + 17] = _h_1123;
      e.mem[_t_154 + 18] = _h_1124;
      e.mem[_t_154 + 19] = _h_1125;
      e.mem[_t_154 + 20] = _h_1126;
      e.mem[_t_154 + 21] = _h_1127;
      e.mem[_t_154 + 22] = _h_1128;
      e.mem[_t_154 + 23] = _h_1129;
      e.mem[_t_154 + 24] = _h_1130;
      WL_CONT = term_tsk(FID_CONTROLS_K253, _t_154);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_155 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_155 + 0] = term_ctr(CID_SCON, STAT_OFF + 1034);
      e.mem[_t_155 + 1] = _h_1105;
      return term_tsk(FID_STRING_APPEND, _t_155);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1034);
    r1 = _h_1105;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K253)
  {
    WL_POPN(25);
    Term _h_1132 = STK(0);
    Term _h_1133 = STK(1);
    Term _h_1134 = STK(2);
    Term _h_1135 = STK(3);
    Term _h_1136 = STK(4);
    Term _h_1137 = STK(5);
    Term _h_1138 = STK(6);
    Term _h_1139 = STK(7);
    Term _h_1140 = STK(8);
    Term _h_1141 = STK(9);
    Term _h_1142 = STK(10);
    Term _h_1143 = STK(11);
    Term _h_1144 = STK(12);
    Term _h_1145 = STK(13);
    Term _h_1146 = STK(14);
    Term _h_1147 = STK(15);
    Term _h_1148 = STK(16);
    Term _h_1149 = STK(17);
    Term _h_1150 = STK(18);
    Term _h_1151 = STK(19);
    Term _h_1152 = STK(20);
    Term _h_1153 = STK(21);
    Term _h_1154 = STK(22);
    Term _h_1155 = STK(23);
    Term _h_1156 = STK(24);
    Term _h_1131 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _h_1132;
      STK(1) = _h_1133;
      STK(2) = _h_1134;
      STK(3) = _h_1135;
      STK(4) = _h_1136;
      STK(5) = _h_1137;
      STK(6) = _h_1138;
      STK(7) = _h_1139;
      STK(8) = _h_1140;
      STK(9) = _h_1141;
      STK(10) = _h_1142;
      STK(11) = _h_1143;
      STK(12) = _h_1144;
      STK(13) = _h_1145;
      STK(14) = _h_1146;
      STK(15) = _h_1147;
      STK(16) = _h_1148;
      STK(17) = _h_1149;
      STK(18) = _h_1150;
      STK(19) = _h_1151;
      STK(20) = _h_1152;
      STK(21) = _h_1153;
      STK(22) = _h_1154;
      STK(23) = _h_1155;
      STK(24) = _h_1156;
      STK(25) = _h_1131;
      STK(26) = FID_CONTROLS_K254;
      WL_PUSHN(27);
    } else {
      u64 _t_156 = task_node(e, FID_CONTROLS_K254, WL_CONT, WL_IDX, 1);
      e.mem[_t_156 + 0] = _h_1132;
      e.mem[_t_156 + 1] = _h_1133;
      e.mem[_t_156 + 2] = _h_1134;
      e.mem[_t_156 + 3] = _h_1135;
      e.mem[_t_156 + 4] = _h_1136;
      e.mem[_t_156 + 5] = _h_1137;
      e.mem[_t_156 + 6] = _h_1138;
      e.mem[_t_156 + 7] = _h_1139;
      e.mem[_t_156 + 8] = _h_1140;
      e.mem[_t_156 + 9] = _h_1141;
      e.mem[_t_156 + 10] = _h_1142;
      e.mem[_t_156 + 11] = _h_1143;
      e.mem[_t_156 + 12] = _h_1144;
      e.mem[_t_156 + 13] = _h_1145;
      e.mem[_t_156 + 14] = _h_1146;
      e.mem[_t_156 + 15] = _h_1147;
      e.mem[_t_156 + 16] = _h_1148;
      e.mem[_t_156 + 17] = _h_1149;
      e.mem[_t_156 + 18] = _h_1150;
      e.mem[_t_156 + 19] = _h_1151;
      e.mem[_t_156 + 20] = _h_1152;
      e.mem[_t_156 + 21] = _h_1153;
      e.mem[_t_156 + 22] = _h_1154;
      e.mem[_t_156 + 23] = _h_1155;
      e.mem[_t_156 + 24] = _h_1156;
      e.mem[_t_156 + 25] = _h_1131;
      WL_CONT = term_tsk(FID_CONTROLS_K254, _t_156);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_157 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_157 + 0] = term_ctr(CID_CON, STAT_OFF + 295);
      e.mem[_t_157 + 1] = 1;
      e.mem[_t_157 + 2] = 0;
      e.mem[_t_157 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_157 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_157 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_157);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 295);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K254)
  {
    WL_POPN(26);
    Term _h_1162 = STK(0);
    Term _h_1163 = STK(1);
    Term _h_1164 = STK(2);
    Term _h_1165 = STK(3);
    Term _h_1166 = STK(4);
    Term _h_1167 = STK(5);
    Term _h_1168 = STK(6);
    Term _h_1169 = STK(7);
    Term _h_1170 = STK(8);
    Term _h_1171 = STK(9);
    Term _h_1172 = STK(10);
    Term _h_1173 = STK(11);
    Term _h_1174 = STK(12);
    Term _h_1175 = STK(13);
    Term _h_1176 = STK(14);
    Term _h_1177 = STK(15);
    Term _h_1178 = STK(16);
    Term _h_1179 = STK(17);
    Term _h_1180 = STK(18);
    Term _h_1181 = STK(19);
    Term _h_1182 = STK(20);
    Term _h_1183 = STK(21);
    Term _h_1184 = STK(22);
    Term _h_1185 = STK(23);
    Term _h_1186 = STK(24);
    Term _h_1187 = STK(25);
    u32 _h_1157 = r0;
    u32 _h_1158 = r1;
    u32 _h_1159 = r2;
    Term _h_1160 = r3;
    Term _h_1161 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _h_1162;
      STK(1) = _h_1163;
      STK(2) = _h_1164;
      STK(3) = _h_1165;
      STK(4) = _h_1166;
      STK(5) = _h_1167;
      STK(6) = _h_1168;
      STK(7) = _h_1169;
      STK(8) = _h_1170;
      STK(9) = _h_1171;
      STK(10) = _h_1172;
      STK(11) = _h_1173;
      STK(12) = _h_1174;
      STK(13) = _h_1175;
      STK(14) = _h_1176;
      STK(15) = _h_1177;
      STK(16) = _h_1178;
      STK(17) = _h_1179;
      STK(18) = _h_1180;
      STK(19) = _h_1181;
      STK(20) = _h_1182;
      STK(21) = _h_1183;
      STK(22) = _h_1184;
      STK(23) = _h_1185;
      STK(24) = _h_1186;
      STK(25) = _h_1187;
      STK(26) = FID_CONTROLS_K255;
      WL_PUSHN(27);
    } else {
      u64 _t_158 = task_node(e, FID_CONTROLS_K255, WL_CONT, WL_IDX, 1);
      e.mem[_t_158 + 0] = _h_1162;
      e.mem[_t_158 + 1] = _h_1163;
      e.mem[_t_158 + 2] = _h_1164;
      e.mem[_t_158 + 3] = _h_1165;
      e.mem[_t_158 + 4] = _h_1166;
      e.mem[_t_158 + 5] = _h_1167;
      e.mem[_t_158 + 6] = _h_1168;
      e.mem[_t_158 + 7] = _h_1169;
      e.mem[_t_158 + 8] = _h_1170;
      e.mem[_t_158 + 9] = _h_1171;
      e.mem[_t_158 + 10] = _h_1172;
      e.mem[_t_158 + 11] = _h_1173;
      e.mem[_t_158 + 12] = _h_1174;
      e.mem[_t_158 + 13] = _h_1175;
      e.mem[_t_158 + 14] = _h_1176;
      e.mem[_t_158 + 15] = _h_1177;
      e.mem[_t_158 + 16] = _h_1178;
      e.mem[_t_158 + 17] = _h_1179;
      e.mem[_t_158 + 18] = _h_1180;
      e.mem[_t_158 + 19] = _h_1181;
      e.mem[_t_158 + 20] = _h_1182;
      e.mem[_t_158 + 21] = _h_1183;
      e.mem[_t_158 + 22] = _h_1184;
      e.mem[_t_158 + 23] = _h_1185;
      e.mem[_t_158 + 24] = _h_1186;
      e.mem[_t_158 + 25] = _h_1187;
      WL_CONT = term_tsk(FID_CONTROLS_K255, _t_158);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_159 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_159 + 0] = _h_1157;
      e.mem[_t_159 + 1] = _h_1158;
      e.mem[_t_159 + 2] = _h_1159;
      e.mem[_t_159 + 3] = _h_1160;
      e.mem[_t_159 + 4] = _h_1161;
      return term_tsk(FID_VALIDATION, _t_159);
    }
    r0 = _h_1157;
    r1 = _h_1158;
    r2 = _h_1159;
    r3 = _h_1160;
    r4 = _h_1161;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K255)
  {
    WL_POPN(26);
    Term _h_1189 = STK(0);
    Term _h_1190 = STK(1);
    Term _h_1191 = STK(2);
    Term _h_1192 = STK(3);
    Term _h_1193 = STK(4);
    Term _h_1194 = STK(5);
    Term _h_1195 = STK(6);
    Term _h_1196 = STK(7);
    Term _h_1197 = STK(8);
    Term _h_1198 = STK(9);
    Term _h_1199 = STK(10);
    Term _h_1200 = STK(11);
    Term _h_1201 = STK(12);
    Term _h_1202 = STK(13);
    Term _h_1203 = STK(14);
    Term _h_1204 = STK(15);
    Term _h_1205 = STK(16);
    Term _h_1206 = STK(17);
    Term _h_1207 = STK(18);
    Term _h_1208 = STK(19);
    Term _h_1209 = STK(20);
    Term _h_1210 = STK(21);
    Term _h_1211 = STK(22);
    Term _h_1212 = STK(23);
    Term _h_1213 = STK(24);
    Term _h_1214 = STK(25);
    Term _h_1188 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _h_1189;
      STK(1) = _h_1190;
      STK(2) = _h_1191;
      STK(3) = _h_1192;
      STK(4) = _h_1193;
      STK(5) = _h_1194;
      STK(6) = _h_1195;
      STK(7) = _h_1196;
      STK(8) = _h_1197;
      STK(9) = _h_1198;
      STK(10) = _h_1199;
      STK(11) = _h_1200;
      STK(12) = _h_1201;
      STK(13) = _h_1202;
      STK(14) = _h_1203;
      STK(15) = _h_1204;
      STK(16) = _h_1205;
      STK(17) = _h_1206;
      STK(18) = _h_1207;
      STK(19) = _h_1208;
      STK(20) = _h_1209;
      STK(21) = _h_1210;
      STK(22) = _h_1211;
      STK(23) = _h_1212;
      STK(24) = _h_1213;
      STK(25) = _h_1214;
      STK(26) = FID_CONTROLS_K256;
      WL_PUSHN(27);
    } else {
      u64 _t_160 = task_node(e, FID_CONTROLS_K256, WL_CONT, WL_IDX, 1);
      e.mem[_t_160 + 0] = _h_1189;
      e.mem[_t_160 + 1] = _h_1190;
      e.mem[_t_160 + 2] = _h_1191;
      e.mem[_t_160 + 3] = _h_1192;
      e.mem[_t_160 + 4] = _h_1193;
      e.mem[_t_160 + 5] = _h_1194;
      e.mem[_t_160 + 6] = _h_1195;
      e.mem[_t_160 + 7] = _h_1196;
      e.mem[_t_160 + 8] = _h_1197;
      e.mem[_t_160 + 9] = _h_1198;
      e.mem[_t_160 + 10] = _h_1199;
      e.mem[_t_160 + 11] = _h_1200;
      e.mem[_t_160 + 12] = _h_1201;
      e.mem[_t_160 + 13] = _h_1202;
      e.mem[_t_160 + 14] = _h_1203;
      e.mem[_t_160 + 15] = _h_1204;
      e.mem[_t_160 + 16] = _h_1205;
      e.mem[_t_160 + 17] = _h_1206;
      e.mem[_t_160 + 18] = _h_1207;
      e.mem[_t_160 + 19] = _h_1208;
      e.mem[_t_160 + 20] = _h_1209;
      e.mem[_t_160 + 21] = _h_1210;
      e.mem[_t_160 + 22] = _h_1211;
      e.mem[_t_160 + 23] = _h_1212;
      e.mem[_t_160 + 24] = _h_1213;
      e.mem[_t_160 + 25] = _h_1214;
      WL_CONT = term_tsk(FID_CONTROLS_K256, _t_160);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_161 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_161 + 0] = term_ctr(CID_SCON, STAT_OFF + 1054);
      e.mem[_t_161 + 1] = _h_1188;
      return term_tsk(FID_STRING_APPEND, _t_161);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1054);
    r1 = _h_1188;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K256)
  {
    WL_POPN(26);
    Term _h_1216 = STK(0);
    Term _h_1217 = STK(1);
    Term _h_1218 = STK(2);
    Term _h_1219 = STK(3);
    Term _h_1220 = STK(4);
    Term _h_1221 = STK(5);
    Term _h_1222 = STK(6);
    Term _h_1223 = STK(7);
    Term _h_1224 = STK(8);
    Term _h_1225 = STK(9);
    Term _h_1226 = STK(10);
    Term _h_1227 = STK(11);
    Term _h_1228 = STK(12);
    Term _h_1229 = STK(13);
    Term _h_1230 = STK(14);
    Term _h_1231 = STK(15);
    Term _h_1232 = STK(16);
    Term _h_1233 = STK(17);
    Term _h_1234 = STK(18);
    Term _h_1235 = STK(19);
    Term _h_1236 = STK(20);
    Term _h_1237 = STK(21);
    Term _h_1238 = STK(22);
    Term _h_1239 = STK(23);
    Term _h_1240 = STK(24);
    Term _h_1241 = STK(25);
    Term _h_1215 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_1216;
      STK(1) = _h_1217;
      STK(2) = _h_1218;
      STK(3) = _h_1219;
      STK(4) = _h_1220;
      STK(5) = _h_1221;
      STK(6) = _h_1222;
      STK(7) = _h_1223;
      STK(8) = _h_1224;
      STK(9) = _h_1225;
      STK(10) = _h_1226;
      STK(11) = _h_1227;
      STK(12) = _h_1228;
      STK(13) = _h_1229;
      STK(14) = _h_1230;
      STK(15) = _h_1231;
      STK(16) = _h_1232;
      STK(17) = _h_1233;
      STK(18) = _h_1234;
      STK(19) = _h_1235;
      STK(20) = _h_1236;
      STK(21) = _h_1237;
      STK(22) = _h_1238;
      STK(23) = _h_1239;
      STK(24) = _h_1240;
      STK(25) = _h_1241;
      STK(26) = _h_1215;
      STK(27) = FID_CONTROLS_K257;
      WL_PUSHN(28);
    } else {
      u64 _t_162 = task_node(e, FID_CONTROLS_K257, WL_CONT, WL_IDX, 1);
      e.mem[_t_162 + 0] = _h_1216;
      e.mem[_t_162 + 1] = _h_1217;
      e.mem[_t_162 + 2] = _h_1218;
      e.mem[_t_162 + 3] = _h_1219;
      e.mem[_t_162 + 4] = _h_1220;
      e.mem[_t_162 + 5] = _h_1221;
      e.mem[_t_162 + 6] = _h_1222;
      e.mem[_t_162 + 7] = _h_1223;
      e.mem[_t_162 + 8] = _h_1224;
      e.mem[_t_162 + 9] = _h_1225;
      e.mem[_t_162 + 10] = _h_1226;
      e.mem[_t_162 + 11] = _h_1227;
      e.mem[_t_162 + 12] = _h_1228;
      e.mem[_t_162 + 13] = _h_1229;
      e.mem[_t_162 + 14] = _h_1230;
      e.mem[_t_162 + 15] = _h_1231;
      e.mem[_t_162 + 16] = _h_1232;
      e.mem[_t_162 + 17] = _h_1233;
      e.mem[_t_162 + 18] = _h_1234;
      e.mem[_t_162 + 19] = _h_1235;
      e.mem[_t_162 + 20] = _h_1236;
      e.mem[_t_162 + 21] = _h_1237;
      e.mem[_t_162 + 22] = _h_1238;
      e.mem[_t_162 + 23] = _h_1239;
      e.mem[_t_162 + 24] = _h_1240;
      e.mem[_t_162 + 25] = _h_1241;
      e.mem[_t_162 + 26] = _h_1215;
      WL_CONT = term_tsk(FID_CONTROLS_K257, _t_162);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_163 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_163 + 0] = term_ctr(CID_CON, STAT_OFF + 591);
      e.mem[_t_163 + 1] = 1;
      e.mem[_t_163 + 2] = 1;
      e.mem[_t_163 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_163 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_163 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_163);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 591);
    r1 = 1;
    r2 = 1;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K257)
  {
    WL_POPN(27);
    Term _h_1247 = STK(0);
    Term _h_1248 = STK(1);
    Term _h_1249 = STK(2);
    Term _h_1250 = STK(3);
    Term _h_1251 = STK(4);
    Term _h_1252 = STK(5);
    Term _h_1253 = STK(6);
    Term _h_1254 = STK(7);
    Term _h_1255 = STK(8);
    Term _h_1256 = STK(9);
    Term _h_1257 = STK(10);
    Term _h_1258 = STK(11);
    Term _h_1259 = STK(12);
    Term _h_1260 = STK(13);
    Term _h_1261 = STK(14);
    Term _h_1262 = STK(15);
    Term _h_1263 = STK(16);
    Term _h_1264 = STK(17);
    Term _h_1265 = STK(18);
    Term _h_1266 = STK(19);
    Term _h_1267 = STK(20);
    Term _h_1268 = STK(21);
    Term _h_1269 = STK(22);
    Term _h_1270 = STK(23);
    Term _h_1271 = STK(24);
    Term _h_1272 = STK(25);
    Term _h_1273 = STK(26);
    u32 _h_1242 = r0;
    u32 _h_1243 = r1;
    u32 _h_1244 = r2;
    Term _h_1245 = r3;
    Term _h_1246 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_1247;
      STK(1) = _h_1248;
      STK(2) = _h_1249;
      STK(3) = _h_1250;
      STK(4) = _h_1251;
      STK(5) = _h_1252;
      STK(6) = _h_1253;
      STK(7) = _h_1254;
      STK(8) = _h_1255;
      STK(9) = _h_1256;
      STK(10) = _h_1257;
      STK(11) = _h_1258;
      STK(12) = _h_1259;
      STK(13) = _h_1260;
      STK(14) = _h_1261;
      STK(15) = _h_1262;
      STK(16) = _h_1263;
      STK(17) = _h_1264;
      STK(18) = _h_1265;
      STK(19) = _h_1266;
      STK(20) = _h_1267;
      STK(21) = _h_1268;
      STK(22) = _h_1269;
      STK(23) = _h_1270;
      STK(24) = _h_1271;
      STK(25) = _h_1272;
      STK(26) = _h_1273;
      STK(27) = FID_CONTROLS_K258;
      WL_PUSHN(28);
    } else {
      u64 _t_164 = task_node(e, FID_CONTROLS_K258, WL_CONT, WL_IDX, 1);
      e.mem[_t_164 + 0] = _h_1247;
      e.mem[_t_164 + 1] = _h_1248;
      e.mem[_t_164 + 2] = _h_1249;
      e.mem[_t_164 + 3] = _h_1250;
      e.mem[_t_164 + 4] = _h_1251;
      e.mem[_t_164 + 5] = _h_1252;
      e.mem[_t_164 + 6] = _h_1253;
      e.mem[_t_164 + 7] = _h_1254;
      e.mem[_t_164 + 8] = _h_1255;
      e.mem[_t_164 + 9] = _h_1256;
      e.mem[_t_164 + 10] = _h_1257;
      e.mem[_t_164 + 11] = _h_1258;
      e.mem[_t_164 + 12] = _h_1259;
      e.mem[_t_164 + 13] = _h_1260;
      e.mem[_t_164 + 14] = _h_1261;
      e.mem[_t_164 + 15] = _h_1262;
      e.mem[_t_164 + 16] = _h_1263;
      e.mem[_t_164 + 17] = _h_1264;
      e.mem[_t_164 + 18] = _h_1265;
      e.mem[_t_164 + 19] = _h_1266;
      e.mem[_t_164 + 20] = _h_1267;
      e.mem[_t_164 + 21] = _h_1268;
      e.mem[_t_164 + 22] = _h_1269;
      e.mem[_t_164 + 23] = _h_1270;
      e.mem[_t_164 + 24] = _h_1271;
      e.mem[_t_164 + 25] = _h_1272;
      e.mem[_t_164 + 26] = _h_1273;
      WL_CONT = term_tsk(FID_CONTROLS_K258, _t_164);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_165 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_165 + 0] = _h_1242;
      e.mem[_t_165 + 1] = _h_1243;
      e.mem[_t_165 + 2] = _h_1244;
      e.mem[_t_165 + 3] = _h_1245;
      e.mem[_t_165 + 4] = _h_1246;
      return term_tsk(FID_VALIDATION, _t_165);
    }
    r0 = _h_1242;
    r1 = _h_1243;
    r2 = _h_1244;
    r3 = _h_1245;
    r4 = _h_1246;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K258)
  {
    WL_POPN(27);
    Term _h_1275 = STK(0);
    Term _h_1276 = STK(1);
    Term _h_1277 = STK(2);
    Term _h_1278 = STK(3);
    Term _h_1279 = STK(4);
    Term _h_1280 = STK(5);
    Term _h_1281 = STK(6);
    Term _h_1282 = STK(7);
    Term _h_1283 = STK(8);
    Term _h_1284 = STK(9);
    Term _h_1285 = STK(10);
    Term _h_1286 = STK(11);
    Term _h_1287 = STK(12);
    Term _h_1288 = STK(13);
    Term _h_1289 = STK(14);
    Term _h_1290 = STK(15);
    Term _h_1291 = STK(16);
    Term _h_1292 = STK(17);
    Term _h_1293 = STK(18);
    Term _h_1294 = STK(19);
    Term _h_1295 = STK(20);
    Term _h_1296 = STK(21);
    Term _h_1297 = STK(22);
    Term _h_1298 = STK(23);
    Term _h_1299 = STK(24);
    Term _h_1300 = STK(25);
    Term _h_1301 = STK(26);
    Term _h_1274 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_1275;
      STK(1) = _h_1276;
      STK(2) = _h_1277;
      STK(3) = _h_1278;
      STK(4) = _h_1279;
      STK(5) = _h_1280;
      STK(6) = _h_1281;
      STK(7) = _h_1282;
      STK(8) = _h_1283;
      STK(9) = _h_1284;
      STK(10) = _h_1285;
      STK(11) = _h_1286;
      STK(12) = _h_1287;
      STK(13) = _h_1288;
      STK(14) = _h_1289;
      STK(15) = _h_1290;
      STK(16) = _h_1291;
      STK(17) = _h_1292;
      STK(18) = _h_1293;
      STK(19) = _h_1294;
      STK(20) = _h_1295;
      STK(21) = _h_1296;
      STK(22) = _h_1297;
      STK(23) = _h_1298;
      STK(24) = _h_1299;
      STK(25) = _h_1300;
      STK(26) = _h_1301;
      STK(27) = FID_CONTROLS_K259;
      WL_PUSHN(28);
    } else {
      u64 _t_166 = task_node(e, FID_CONTROLS_K259, WL_CONT, WL_IDX, 1);
      e.mem[_t_166 + 0] = _h_1275;
      e.mem[_t_166 + 1] = _h_1276;
      e.mem[_t_166 + 2] = _h_1277;
      e.mem[_t_166 + 3] = _h_1278;
      e.mem[_t_166 + 4] = _h_1279;
      e.mem[_t_166 + 5] = _h_1280;
      e.mem[_t_166 + 6] = _h_1281;
      e.mem[_t_166 + 7] = _h_1282;
      e.mem[_t_166 + 8] = _h_1283;
      e.mem[_t_166 + 9] = _h_1284;
      e.mem[_t_166 + 10] = _h_1285;
      e.mem[_t_166 + 11] = _h_1286;
      e.mem[_t_166 + 12] = _h_1287;
      e.mem[_t_166 + 13] = _h_1288;
      e.mem[_t_166 + 14] = _h_1289;
      e.mem[_t_166 + 15] = _h_1290;
      e.mem[_t_166 + 16] = _h_1291;
      e.mem[_t_166 + 17] = _h_1292;
      e.mem[_t_166 + 18] = _h_1293;
      e.mem[_t_166 + 19] = _h_1294;
      e.mem[_t_166 + 20] = _h_1295;
      e.mem[_t_166 + 21] = _h_1296;
      e.mem[_t_166 + 22] = _h_1297;
      e.mem[_t_166 + 23] = _h_1298;
      e.mem[_t_166 + 24] = _h_1299;
      e.mem[_t_166 + 25] = _h_1300;
      e.mem[_t_166 + 26] = _h_1301;
      WL_CONT = term_tsk(FID_CONTROLS_K259, _t_166);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_167 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_167 + 0] = term_ctr(CID_SCON, STAT_OFF + 1074);
      e.mem[_t_167 + 1] = _h_1274;
      return term_tsk(FID_STRING_APPEND, _t_167);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1074);
    r1 = _h_1274;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K259)
  {
    WL_POPN(27);
    Term _h_1303 = STK(0);
    Term _h_1304 = STK(1);
    Term _h_1305 = STK(2);
    Term _h_1306 = STK(3);
    Term _h_1307 = STK(4);
    Term _h_1308 = STK(5);
    Term _h_1309 = STK(6);
    Term _h_1310 = STK(7);
    Term _h_1311 = STK(8);
    Term _h_1312 = STK(9);
    Term _h_1313 = STK(10);
    Term _h_1314 = STK(11);
    Term _h_1315 = STK(12);
    Term _h_1316 = STK(13);
    Term _h_1317 = STK(14);
    Term _h_1318 = STK(15);
    Term _h_1319 = STK(16);
    Term _h_1320 = STK(17);
    Term _h_1321 = STK(18);
    Term _h_1322 = STK(19);
    Term _h_1323 = STK(20);
    Term _h_1324 = STK(21);
    Term _h_1325 = STK(22);
    Term _h_1326 = STK(23);
    Term _h_1327 = STK(24);
    Term _h_1328 = STK(25);
    Term _h_1329 = STK(26);
    Term _h_1302 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_1303;
      STK(1) = _h_1304;
      STK(2) = _h_1305;
      STK(3) = _h_1306;
      STK(4) = _h_1307;
      STK(5) = _h_1308;
      STK(6) = _h_1309;
      STK(7) = _h_1310;
      STK(8) = _h_1311;
      STK(9) = _h_1312;
      STK(10) = _h_1313;
      STK(11) = _h_1314;
      STK(12) = _h_1315;
      STK(13) = _h_1316;
      STK(14) = _h_1317;
      STK(15) = _h_1318;
      STK(16) = _h_1319;
      STK(17) = _h_1320;
      STK(18) = _h_1321;
      STK(19) = _h_1322;
      STK(20) = _h_1323;
      STK(21) = _h_1324;
      STK(22) = _h_1325;
      STK(23) = _h_1326;
      STK(24) = _h_1327;
      STK(25) = _h_1328;
      STK(26) = _h_1329;
      STK(27) = _h_1302;
      STK(28) = FID_CONTROLS_K260;
      WL_PUSHN(29);
    } else {
      u64 _t_168 = task_node(e, FID_CONTROLS_K260, WL_CONT, WL_IDX, 1);
      e.mem[_t_168 + 0] = _h_1303;
      e.mem[_t_168 + 1] = _h_1304;
      e.mem[_t_168 + 2] = _h_1305;
      e.mem[_t_168 + 3] = _h_1306;
      e.mem[_t_168 + 4] = _h_1307;
      e.mem[_t_168 + 5] = _h_1308;
      e.mem[_t_168 + 6] = _h_1309;
      e.mem[_t_168 + 7] = _h_1310;
      e.mem[_t_168 + 8] = _h_1311;
      e.mem[_t_168 + 9] = _h_1312;
      e.mem[_t_168 + 10] = _h_1313;
      e.mem[_t_168 + 11] = _h_1314;
      e.mem[_t_168 + 12] = _h_1315;
      e.mem[_t_168 + 13] = _h_1316;
      e.mem[_t_168 + 14] = _h_1317;
      e.mem[_t_168 + 15] = _h_1318;
      e.mem[_t_168 + 16] = _h_1319;
      e.mem[_t_168 + 17] = _h_1320;
      e.mem[_t_168 + 18] = _h_1321;
      e.mem[_t_168 + 19] = _h_1322;
      e.mem[_t_168 + 20] = _h_1323;
      e.mem[_t_168 + 21] = _h_1324;
      e.mem[_t_168 + 22] = _h_1325;
      e.mem[_t_168 + 23] = _h_1326;
      e.mem[_t_168 + 24] = _h_1327;
      e.mem[_t_168 + 25] = _h_1328;
      e.mem[_t_168 + 26] = _h_1329;
      e.mem[_t_168 + 27] = _h_1302;
      WL_CONT = term_tsk(FID_CONTROLS_K260, _t_168);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_169 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_169 + 0] = term_ctr(CID_CON, STAT_OFF + 632);
      e.mem[_t_169 + 1] = 1;
      e.mem[_t_169 + 2] = 2;
      e.mem[_t_169 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_169 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_169 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_169);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 632);
    r1 = 1;
    r2 = 2;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K260)
  {
    WL_POPN(28);
    Term _h_1335 = STK(0);
    Term _h_1336 = STK(1);
    Term _h_1337 = STK(2);
    Term _h_1338 = STK(3);
    Term _h_1339 = STK(4);
    Term _h_1340 = STK(5);
    Term _h_1341 = STK(6);
    Term _h_1342 = STK(7);
    Term _h_1343 = STK(8);
    Term _h_1344 = STK(9);
    Term _h_1345 = STK(10);
    Term _h_1346 = STK(11);
    Term _h_1347 = STK(12);
    Term _h_1348 = STK(13);
    Term _h_1349 = STK(14);
    Term _h_1350 = STK(15);
    Term _h_1351 = STK(16);
    Term _h_1352 = STK(17);
    Term _h_1353 = STK(18);
    Term _h_1354 = STK(19);
    Term _h_1355 = STK(20);
    Term _h_1356 = STK(21);
    Term _h_1357 = STK(22);
    Term _h_1358 = STK(23);
    Term _h_1359 = STK(24);
    Term _h_1360 = STK(25);
    Term _h_1361 = STK(26);
    Term _h_1362 = STK(27);
    u32 _h_1330 = r0;
    u32 _h_1331 = r1;
    u32 _h_1332 = r2;
    Term _h_1333 = r3;
    Term _h_1334 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_1335;
      STK(1) = _h_1336;
      STK(2) = _h_1337;
      STK(3) = _h_1338;
      STK(4) = _h_1339;
      STK(5) = _h_1340;
      STK(6) = _h_1341;
      STK(7) = _h_1342;
      STK(8) = _h_1343;
      STK(9) = _h_1344;
      STK(10) = _h_1345;
      STK(11) = _h_1346;
      STK(12) = _h_1347;
      STK(13) = _h_1348;
      STK(14) = _h_1349;
      STK(15) = _h_1350;
      STK(16) = _h_1351;
      STK(17) = _h_1352;
      STK(18) = _h_1353;
      STK(19) = _h_1354;
      STK(20) = _h_1355;
      STK(21) = _h_1356;
      STK(22) = _h_1357;
      STK(23) = _h_1358;
      STK(24) = _h_1359;
      STK(25) = _h_1360;
      STK(26) = _h_1361;
      STK(27) = _h_1362;
      STK(28) = FID_CONTROLS_K261;
      WL_PUSHN(29);
    } else {
      u64 _t_170 = task_node(e, FID_CONTROLS_K261, WL_CONT, WL_IDX, 1);
      e.mem[_t_170 + 0] = _h_1335;
      e.mem[_t_170 + 1] = _h_1336;
      e.mem[_t_170 + 2] = _h_1337;
      e.mem[_t_170 + 3] = _h_1338;
      e.mem[_t_170 + 4] = _h_1339;
      e.mem[_t_170 + 5] = _h_1340;
      e.mem[_t_170 + 6] = _h_1341;
      e.mem[_t_170 + 7] = _h_1342;
      e.mem[_t_170 + 8] = _h_1343;
      e.mem[_t_170 + 9] = _h_1344;
      e.mem[_t_170 + 10] = _h_1345;
      e.mem[_t_170 + 11] = _h_1346;
      e.mem[_t_170 + 12] = _h_1347;
      e.mem[_t_170 + 13] = _h_1348;
      e.mem[_t_170 + 14] = _h_1349;
      e.mem[_t_170 + 15] = _h_1350;
      e.mem[_t_170 + 16] = _h_1351;
      e.mem[_t_170 + 17] = _h_1352;
      e.mem[_t_170 + 18] = _h_1353;
      e.mem[_t_170 + 19] = _h_1354;
      e.mem[_t_170 + 20] = _h_1355;
      e.mem[_t_170 + 21] = _h_1356;
      e.mem[_t_170 + 22] = _h_1357;
      e.mem[_t_170 + 23] = _h_1358;
      e.mem[_t_170 + 24] = _h_1359;
      e.mem[_t_170 + 25] = _h_1360;
      e.mem[_t_170 + 26] = _h_1361;
      e.mem[_t_170 + 27] = _h_1362;
      WL_CONT = term_tsk(FID_CONTROLS_K261, _t_170);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_171 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_171 + 0] = _h_1330;
      e.mem[_t_171 + 1] = _h_1331;
      e.mem[_t_171 + 2] = _h_1332;
      e.mem[_t_171 + 3] = _h_1333;
      e.mem[_t_171 + 4] = _h_1334;
      return term_tsk(FID_VALIDATION, _t_171);
    }
    r0 = _h_1330;
    r1 = _h_1331;
    r2 = _h_1332;
    r3 = _h_1333;
    r4 = _h_1334;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K261)
  {
    WL_POPN(28);
    Term _h_1364 = STK(0);
    Term _h_1365 = STK(1);
    Term _h_1366 = STK(2);
    Term _h_1367 = STK(3);
    Term _h_1368 = STK(4);
    Term _h_1369 = STK(5);
    Term _h_1370 = STK(6);
    Term _h_1371 = STK(7);
    Term _h_1372 = STK(8);
    Term _h_1373 = STK(9);
    Term _h_1374 = STK(10);
    Term _h_1375 = STK(11);
    Term _h_1376 = STK(12);
    Term _h_1377 = STK(13);
    Term _h_1378 = STK(14);
    Term _h_1379 = STK(15);
    Term _h_1380 = STK(16);
    Term _h_1381 = STK(17);
    Term _h_1382 = STK(18);
    Term _h_1383 = STK(19);
    Term _h_1384 = STK(20);
    Term _h_1385 = STK(21);
    Term _h_1386 = STK(22);
    Term _h_1387 = STK(23);
    Term _h_1388 = STK(24);
    Term _h_1389 = STK(25);
    Term _h_1390 = STK(26);
    Term _h_1391 = STK(27);
    Term _h_1363 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_1364;
      STK(1) = _h_1365;
      STK(2) = _h_1366;
      STK(3) = _h_1367;
      STK(4) = _h_1368;
      STK(5) = _h_1369;
      STK(6) = _h_1370;
      STK(7) = _h_1371;
      STK(8) = _h_1372;
      STK(9) = _h_1373;
      STK(10) = _h_1374;
      STK(11) = _h_1375;
      STK(12) = _h_1376;
      STK(13) = _h_1377;
      STK(14) = _h_1378;
      STK(15) = _h_1379;
      STK(16) = _h_1380;
      STK(17) = _h_1381;
      STK(18) = _h_1382;
      STK(19) = _h_1383;
      STK(20) = _h_1384;
      STK(21) = _h_1385;
      STK(22) = _h_1386;
      STK(23) = _h_1387;
      STK(24) = _h_1388;
      STK(25) = _h_1389;
      STK(26) = _h_1390;
      STK(27) = _h_1391;
      STK(28) = FID_CONTROLS_K262;
      WL_PUSHN(29);
    } else {
      u64 _t_172 = task_node(e, FID_CONTROLS_K262, WL_CONT, WL_IDX, 1);
      e.mem[_t_172 + 0] = _h_1364;
      e.mem[_t_172 + 1] = _h_1365;
      e.mem[_t_172 + 2] = _h_1366;
      e.mem[_t_172 + 3] = _h_1367;
      e.mem[_t_172 + 4] = _h_1368;
      e.mem[_t_172 + 5] = _h_1369;
      e.mem[_t_172 + 6] = _h_1370;
      e.mem[_t_172 + 7] = _h_1371;
      e.mem[_t_172 + 8] = _h_1372;
      e.mem[_t_172 + 9] = _h_1373;
      e.mem[_t_172 + 10] = _h_1374;
      e.mem[_t_172 + 11] = _h_1375;
      e.mem[_t_172 + 12] = _h_1376;
      e.mem[_t_172 + 13] = _h_1377;
      e.mem[_t_172 + 14] = _h_1378;
      e.mem[_t_172 + 15] = _h_1379;
      e.mem[_t_172 + 16] = _h_1380;
      e.mem[_t_172 + 17] = _h_1381;
      e.mem[_t_172 + 18] = _h_1382;
      e.mem[_t_172 + 19] = _h_1383;
      e.mem[_t_172 + 20] = _h_1384;
      e.mem[_t_172 + 21] = _h_1385;
      e.mem[_t_172 + 22] = _h_1386;
      e.mem[_t_172 + 23] = _h_1387;
      e.mem[_t_172 + 24] = _h_1388;
      e.mem[_t_172 + 25] = _h_1389;
      e.mem[_t_172 + 26] = _h_1390;
      e.mem[_t_172 + 27] = _h_1391;
      WL_CONT = term_tsk(FID_CONTROLS_K262, _t_172);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_173 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_173 + 0] = term_ctr(CID_SCON, STAT_OFF + 1094);
      e.mem[_t_173 + 1] = _h_1363;
      return term_tsk(FID_STRING_APPEND, _t_173);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1094);
    r1 = _h_1363;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K262)
  {
    WL_POPN(28);
    Term _h_1393 = STK(0);
    Term _h_1394 = STK(1);
    Term _h_1395 = STK(2);
    Term _h_1396 = STK(3);
    Term _h_1397 = STK(4);
    Term _h_1398 = STK(5);
    Term _h_1399 = STK(6);
    Term _h_1400 = STK(7);
    Term _h_1401 = STK(8);
    Term _h_1402 = STK(9);
    Term _h_1403 = STK(10);
    Term _h_1404 = STK(11);
    Term _h_1405 = STK(12);
    Term _h_1406 = STK(13);
    Term _h_1407 = STK(14);
    Term _h_1408 = STK(15);
    Term _h_1409 = STK(16);
    Term _h_1410 = STK(17);
    Term _h_1411 = STK(18);
    Term _h_1412 = STK(19);
    Term _h_1413 = STK(20);
    Term _h_1414 = STK(21);
    Term _h_1415 = STK(22);
    Term _h_1416 = STK(23);
    Term _h_1417 = STK(24);
    Term _h_1418 = STK(25);
    Term _h_1419 = STK(26);
    Term _h_1420 = STK(27);
    Term _h_1392 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _h_1393;
      STK(1) = _h_1394;
      STK(2) = _h_1395;
      STK(3) = _h_1396;
      STK(4) = _h_1397;
      STK(5) = _h_1398;
      STK(6) = _h_1399;
      STK(7) = _h_1400;
      STK(8) = _h_1401;
      STK(9) = _h_1402;
      STK(10) = _h_1403;
      STK(11) = _h_1404;
      STK(12) = _h_1405;
      STK(13) = _h_1406;
      STK(14) = _h_1407;
      STK(15) = _h_1408;
      STK(16) = _h_1409;
      STK(17) = _h_1410;
      STK(18) = _h_1411;
      STK(19) = _h_1412;
      STK(20) = _h_1413;
      STK(21) = _h_1414;
      STK(22) = _h_1415;
      STK(23) = _h_1416;
      STK(24) = _h_1417;
      STK(25) = _h_1418;
      STK(26) = _h_1419;
      STK(27) = _h_1420;
      STK(28) = _h_1392;
      STK(29) = FID_CONTROLS_K263;
      WL_PUSHN(30);
    } else {
      u64 _t_174 = task_node(e, FID_CONTROLS_K263, WL_CONT, WL_IDX, 1);
      e.mem[_t_174 + 0] = _h_1393;
      e.mem[_t_174 + 1] = _h_1394;
      e.mem[_t_174 + 2] = _h_1395;
      e.mem[_t_174 + 3] = _h_1396;
      e.mem[_t_174 + 4] = _h_1397;
      e.mem[_t_174 + 5] = _h_1398;
      e.mem[_t_174 + 6] = _h_1399;
      e.mem[_t_174 + 7] = _h_1400;
      e.mem[_t_174 + 8] = _h_1401;
      e.mem[_t_174 + 9] = _h_1402;
      e.mem[_t_174 + 10] = _h_1403;
      e.mem[_t_174 + 11] = _h_1404;
      e.mem[_t_174 + 12] = _h_1405;
      e.mem[_t_174 + 13] = _h_1406;
      e.mem[_t_174 + 14] = _h_1407;
      e.mem[_t_174 + 15] = _h_1408;
      e.mem[_t_174 + 16] = _h_1409;
      e.mem[_t_174 + 17] = _h_1410;
      e.mem[_t_174 + 18] = _h_1411;
      e.mem[_t_174 + 19] = _h_1412;
      e.mem[_t_174 + 20] = _h_1413;
      e.mem[_t_174 + 21] = _h_1414;
      e.mem[_t_174 + 22] = _h_1415;
      e.mem[_t_174 + 23] = _h_1416;
      e.mem[_t_174 + 24] = _h_1417;
      e.mem[_t_174 + 25] = _h_1418;
      e.mem[_t_174 + 26] = _h_1419;
      e.mem[_t_174 + 27] = _h_1420;
      e.mem[_t_174 + 28] = _h_1392;
      WL_CONT = term_tsk(FID_CONTROLS_K263, _t_174);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_175 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_175 + 0] = term_ctr(CID_CON, STAT_OFF + 673);
      e.mem[_t_175 + 1] = 1;
      e.mem[_t_175 + 2] = 3;
      e.mem[_t_175 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_175 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_175 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_175);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 673);
    r1 = 1;
    r2 = 3;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K263)
  {
    WL_POPN(29);
    Term _h_1426 = STK(0);
    Term _h_1427 = STK(1);
    Term _h_1428 = STK(2);
    Term _h_1429 = STK(3);
    Term _h_1430 = STK(4);
    Term _h_1431 = STK(5);
    Term _h_1432 = STK(6);
    Term _h_1433 = STK(7);
    Term _h_1434 = STK(8);
    Term _h_1435 = STK(9);
    Term _h_1436 = STK(10);
    Term _h_1437 = STK(11);
    Term _h_1438 = STK(12);
    Term _h_1439 = STK(13);
    Term _h_1440 = STK(14);
    Term _h_1441 = STK(15);
    Term _h_1442 = STK(16);
    Term _h_1443 = STK(17);
    Term _h_1444 = STK(18);
    Term _h_1445 = STK(19);
    Term _h_1446 = STK(20);
    Term _h_1447 = STK(21);
    Term _h_1448 = STK(22);
    Term _h_1449 = STK(23);
    Term _h_1450 = STK(24);
    Term _h_1451 = STK(25);
    Term _h_1452 = STK(26);
    Term _h_1453 = STK(27);
    Term _h_1454 = STK(28);
    u32 _h_1421 = r0;
    u32 _h_1422 = r1;
    u32 _h_1423 = r2;
    Term _h_1424 = r3;
    Term _h_1425 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _h_1426;
      STK(1) = _h_1427;
      STK(2) = _h_1428;
      STK(3) = _h_1429;
      STK(4) = _h_1430;
      STK(5) = _h_1431;
      STK(6) = _h_1432;
      STK(7) = _h_1433;
      STK(8) = _h_1434;
      STK(9) = _h_1435;
      STK(10) = _h_1436;
      STK(11) = _h_1437;
      STK(12) = _h_1438;
      STK(13) = _h_1439;
      STK(14) = _h_1440;
      STK(15) = _h_1441;
      STK(16) = _h_1442;
      STK(17) = _h_1443;
      STK(18) = _h_1444;
      STK(19) = _h_1445;
      STK(20) = _h_1446;
      STK(21) = _h_1447;
      STK(22) = _h_1448;
      STK(23) = _h_1449;
      STK(24) = _h_1450;
      STK(25) = _h_1451;
      STK(26) = _h_1452;
      STK(27) = _h_1453;
      STK(28) = _h_1454;
      STK(29) = FID_CONTROLS_K264;
      WL_PUSHN(30);
    } else {
      u64 _t_176 = task_node(e, FID_CONTROLS_K264, WL_CONT, WL_IDX, 1);
      e.mem[_t_176 + 0] = _h_1426;
      e.mem[_t_176 + 1] = _h_1427;
      e.mem[_t_176 + 2] = _h_1428;
      e.mem[_t_176 + 3] = _h_1429;
      e.mem[_t_176 + 4] = _h_1430;
      e.mem[_t_176 + 5] = _h_1431;
      e.mem[_t_176 + 6] = _h_1432;
      e.mem[_t_176 + 7] = _h_1433;
      e.mem[_t_176 + 8] = _h_1434;
      e.mem[_t_176 + 9] = _h_1435;
      e.mem[_t_176 + 10] = _h_1436;
      e.mem[_t_176 + 11] = _h_1437;
      e.mem[_t_176 + 12] = _h_1438;
      e.mem[_t_176 + 13] = _h_1439;
      e.mem[_t_176 + 14] = _h_1440;
      e.mem[_t_176 + 15] = _h_1441;
      e.mem[_t_176 + 16] = _h_1442;
      e.mem[_t_176 + 17] = _h_1443;
      e.mem[_t_176 + 18] = _h_1444;
      e.mem[_t_176 + 19] = _h_1445;
      e.mem[_t_176 + 20] = _h_1446;
      e.mem[_t_176 + 21] = _h_1447;
      e.mem[_t_176 + 22] = _h_1448;
      e.mem[_t_176 + 23] = _h_1449;
      e.mem[_t_176 + 24] = _h_1450;
      e.mem[_t_176 + 25] = _h_1451;
      e.mem[_t_176 + 26] = _h_1452;
      e.mem[_t_176 + 27] = _h_1453;
      e.mem[_t_176 + 28] = _h_1454;
      WL_CONT = term_tsk(FID_CONTROLS_K264, _t_176);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_177 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_177 + 0] = _h_1421;
      e.mem[_t_177 + 1] = _h_1422;
      e.mem[_t_177 + 2] = _h_1423;
      e.mem[_t_177 + 3] = _h_1424;
      e.mem[_t_177 + 4] = _h_1425;
      return term_tsk(FID_VALIDATION, _t_177);
    }
    r0 = _h_1421;
    r1 = _h_1422;
    r2 = _h_1423;
    r3 = _h_1424;
    r4 = _h_1425;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K264)
  {
    WL_POPN(29);
    Term _h_1456 = STK(0);
    Term _h_1457 = STK(1);
    Term _h_1458 = STK(2);
    Term _h_1459 = STK(3);
    Term _h_1460 = STK(4);
    Term _h_1461 = STK(5);
    Term _h_1462 = STK(6);
    Term _h_1463 = STK(7);
    Term _h_1464 = STK(8);
    Term _h_1465 = STK(9);
    Term _h_1466 = STK(10);
    Term _h_1467 = STK(11);
    Term _h_1468 = STK(12);
    Term _h_1469 = STK(13);
    Term _h_1470 = STK(14);
    Term _h_1471 = STK(15);
    Term _h_1472 = STK(16);
    Term _h_1473 = STK(17);
    Term _h_1474 = STK(18);
    Term _h_1475 = STK(19);
    Term _h_1476 = STK(20);
    Term _h_1477 = STK(21);
    Term _h_1478 = STK(22);
    Term _h_1479 = STK(23);
    Term _h_1480 = STK(24);
    Term _h_1481 = STK(25);
    Term _h_1482 = STK(26);
    Term _h_1483 = STK(27);
    Term _h_1484 = STK(28);
    Term _h_1455 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _h_1456;
      STK(1) = _h_1457;
      STK(2) = _h_1458;
      STK(3) = _h_1459;
      STK(4) = _h_1460;
      STK(5) = _h_1461;
      STK(6) = _h_1462;
      STK(7) = _h_1463;
      STK(8) = _h_1464;
      STK(9) = _h_1465;
      STK(10) = _h_1466;
      STK(11) = _h_1467;
      STK(12) = _h_1468;
      STK(13) = _h_1469;
      STK(14) = _h_1470;
      STK(15) = _h_1471;
      STK(16) = _h_1472;
      STK(17) = _h_1473;
      STK(18) = _h_1474;
      STK(19) = _h_1475;
      STK(20) = _h_1476;
      STK(21) = _h_1477;
      STK(22) = _h_1478;
      STK(23) = _h_1479;
      STK(24) = _h_1480;
      STK(25) = _h_1481;
      STK(26) = _h_1482;
      STK(27) = _h_1483;
      STK(28) = _h_1484;
      STK(29) = FID_CONTROLS_K265;
      WL_PUSHN(30);
    } else {
      u64 _t_178 = task_node(e, FID_CONTROLS_K265, WL_CONT, WL_IDX, 1);
      e.mem[_t_178 + 0] = _h_1456;
      e.mem[_t_178 + 1] = _h_1457;
      e.mem[_t_178 + 2] = _h_1458;
      e.mem[_t_178 + 3] = _h_1459;
      e.mem[_t_178 + 4] = _h_1460;
      e.mem[_t_178 + 5] = _h_1461;
      e.mem[_t_178 + 6] = _h_1462;
      e.mem[_t_178 + 7] = _h_1463;
      e.mem[_t_178 + 8] = _h_1464;
      e.mem[_t_178 + 9] = _h_1465;
      e.mem[_t_178 + 10] = _h_1466;
      e.mem[_t_178 + 11] = _h_1467;
      e.mem[_t_178 + 12] = _h_1468;
      e.mem[_t_178 + 13] = _h_1469;
      e.mem[_t_178 + 14] = _h_1470;
      e.mem[_t_178 + 15] = _h_1471;
      e.mem[_t_178 + 16] = _h_1472;
      e.mem[_t_178 + 17] = _h_1473;
      e.mem[_t_178 + 18] = _h_1474;
      e.mem[_t_178 + 19] = _h_1475;
      e.mem[_t_178 + 20] = _h_1476;
      e.mem[_t_178 + 21] = _h_1477;
      e.mem[_t_178 + 22] = _h_1478;
      e.mem[_t_178 + 23] = _h_1479;
      e.mem[_t_178 + 24] = _h_1480;
      e.mem[_t_178 + 25] = _h_1481;
      e.mem[_t_178 + 26] = _h_1482;
      e.mem[_t_178 + 27] = _h_1483;
      e.mem[_t_178 + 28] = _h_1484;
      WL_CONT = term_tsk(FID_CONTROLS_K265, _t_178);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_179 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_179 + 0] = term_ctr(CID_SCON, STAT_OFF + 1114);
      e.mem[_t_179 + 1] = _h_1455;
      return term_tsk(FID_STRING_APPEND, _t_179);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1114);
    r1 = _h_1455;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K265)
  {
    WL_POPN(29);
    Term _h_1486 = STK(0);
    Term _h_1487 = STK(1);
    Term _h_1488 = STK(2);
    Term _h_1489 = STK(3);
    Term _h_1490 = STK(4);
    Term _h_1491 = STK(5);
    Term _h_1492 = STK(6);
    Term _h_1493 = STK(7);
    Term _h_1494 = STK(8);
    Term _h_1495 = STK(9);
    Term _h_1496 = STK(10);
    Term _h_1497 = STK(11);
    Term _h_1498 = STK(12);
    Term _h_1499 = STK(13);
    Term _h_1500 = STK(14);
    Term _h_1501 = STK(15);
    Term _h_1502 = STK(16);
    Term _h_1503 = STK(17);
    Term _h_1504 = STK(18);
    Term _h_1505 = STK(19);
    Term _h_1506 = STK(20);
    Term _h_1507 = STK(21);
    Term _h_1508 = STK(22);
    Term _h_1509 = STK(23);
    Term _h_1510 = STK(24);
    Term _h_1511 = STK(25);
    Term _h_1512 = STK(26);
    Term _h_1513 = STK(27);
    Term _h_1514 = STK(28);
    Term _h_1485 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_1486;
      STK(1) = _h_1487;
      STK(2) = _h_1488;
      STK(3) = _h_1489;
      STK(4) = _h_1490;
      STK(5) = _h_1491;
      STK(6) = _h_1492;
      STK(7) = _h_1493;
      STK(8) = _h_1494;
      STK(9) = _h_1495;
      STK(10) = _h_1496;
      STK(11) = _h_1497;
      STK(12) = _h_1498;
      STK(13) = _h_1499;
      STK(14) = _h_1500;
      STK(15) = _h_1501;
      STK(16) = _h_1502;
      STK(17) = _h_1503;
      STK(18) = _h_1504;
      STK(19) = _h_1505;
      STK(20) = _h_1506;
      STK(21) = _h_1507;
      STK(22) = _h_1508;
      STK(23) = _h_1509;
      STK(24) = _h_1510;
      STK(25) = _h_1511;
      STK(26) = _h_1512;
      STK(27) = _h_1513;
      STK(28) = _h_1514;
      STK(29) = _h_1485;
      STK(30) = FID_CONTROLS_K266;
      WL_PUSHN(31);
    } else {
      u64 _t_180 = task_node(e, FID_CONTROLS_K266, WL_CONT, WL_IDX, 1);
      e.mem[_t_180 + 0] = _h_1486;
      e.mem[_t_180 + 1] = _h_1487;
      e.mem[_t_180 + 2] = _h_1488;
      e.mem[_t_180 + 3] = _h_1489;
      e.mem[_t_180 + 4] = _h_1490;
      e.mem[_t_180 + 5] = _h_1491;
      e.mem[_t_180 + 6] = _h_1492;
      e.mem[_t_180 + 7] = _h_1493;
      e.mem[_t_180 + 8] = _h_1494;
      e.mem[_t_180 + 9] = _h_1495;
      e.mem[_t_180 + 10] = _h_1496;
      e.mem[_t_180 + 11] = _h_1497;
      e.mem[_t_180 + 12] = _h_1498;
      e.mem[_t_180 + 13] = _h_1499;
      e.mem[_t_180 + 14] = _h_1500;
      e.mem[_t_180 + 15] = _h_1501;
      e.mem[_t_180 + 16] = _h_1502;
      e.mem[_t_180 + 17] = _h_1503;
      e.mem[_t_180 + 18] = _h_1504;
      e.mem[_t_180 + 19] = _h_1505;
      e.mem[_t_180 + 20] = _h_1506;
      e.mem[_t_180 + 21] = _h_1507;
      e.mem[_t_180 + 22] = _h_1508;
      e.mem[_t_180 + 23] = _h_1509;
      e.mem[_t_180 + 24] = _h_1510;
      e.mem[_t_180 + 25] = _h_1511;
      e.mem[_t_180 + 26] = _h_1512;
      e.mem[_t_180 + 27] = _h_1513;
      e.mem[_t_180 + 28] = _h_1514;
      e.mem[_t_180 + 29] = _h_1485;
      WL_CONT = term_tsk(FID_CONTROLS_K266, _t_180);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_181 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_181 + 0] = term_ctr(CID_CON, STAT_OFF + 714);
      e.mem[_t_181 + 1] = 1;
      e.mem[_t_181 + 2] = 4;
      e.mem[_t_181 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_181 + 4] = term_ctr(CID_SCON, STAT_OFF + 268);
      e.mem[_t_181 + 5] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_181);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 714);
    r1 = 1;
    r2 = 4;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 268);
    r5 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K266)
  {
    WL_POPN(30);
    Term _h_1520 = STK(0);
    Term _h_1521 = STK(1);
    Term _h_1522 = STK(2);
    Term _h_1523 = STK(3);
    Term _h_1524 = STK(4);
    Term _h_1525 = STK(5);
    Term _h_1526 = STK(6);
    Term _h_1527 = STK(7);
    Term _h_1528 = STK(8);
    Term _h_1529 = STK(9);
    Term _h_1530 = STK(10);
    Term _h_1531 = STK(11);
    Term _h_1532 = STK(12);
    Term _h_1533 = STK(13);
    Term _h_1534 = STK(14);
    Term _h_1535 = STK(15);
    Term _h_1536 = STK(16);
    Term _h_1537 = STK(17);
    Term _h_1538 = STK(18);
    Term _h_1539 = STK(19);
    Term _h_1540 = STK(20);
    Term _h_1541 = STK(21);
    Term _h_1542 = STK(22);
    Term _h_1543 = STK(23);
    Term _h_1544 = STK(24);
    Term _h_1545 = STK(25);
    Term _h_1546 = STK(26);
    Term _h_1547 = STK(27);
    Term _h_1548 = STK(28);
    Term _h_1549 = STK(29);
    u32 _h_1515 = r0;
    u32 _h_1516 = r1;
    u32 _h_1517 = r2;
    Term _h_1518 = r3;
    Term _h_1519 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_1520;
      STK(1) = _h_1521;
      STK(2) = _h_1522;
      STK(3) = _h_1523;
      STK(4) = _h_1524;
      STK(5) = _h_1525;
      STK(6) = _h_1526;
      STK(7) = _h_1527;
      STK(8) = _h_1528;
      STK(9) = _h_1529;
      STK(10) = _h_1530;
      STK(11) = _h_1531;
      STK(12) = _h_1532;
      STK(13) = _h_1533;
      STK(14) = _h_1534;
      STK(15) = _h_1535;
      STK(16) = _h_1536;
      STK(17) = _h_1537;
      STK(18) = _h_1538;
      STK(19) = _h_1539;
      STK(20) = _h_1540;
      STK(21) = _h_1541;
      STK(22) = _h_1542;
      STK(23) = _h_1543;
      STK(24) = _h_1544;
      STK(25) = _h_1545;
      STK(26) = _h_1546;
      STK(27) = _h_1547;
      STK(28) = _h_1548;
      STK(29) = _h_1549;
      STK(30) = FID_CONTROLS_K267;
      WL_PUSHN(31);
    } else {
      u64 _t_182 = task_node(e, FID_CONTROLS_K267, WL_CONT, WL_IDX, 1);
      e.mem[_t_182 + 0] = _h_1520;
      e.mem[_t_182 + 1] = _h_1521;
      e.mem[_t_182 + 2] = _h_1522;
      e.mem[_t_182 + 3] = _h_1523;
      e.mem[_t_182 + 4] = _h_1524;
      e.mem[_t_182 + 5] = _h_1525;
      e.mem[_t_182 + 6] = _h_1526;
      e.mem[_t_182 + 7] = _h_1527;
      e.mem[_t_182 + 8] = _h_1528;
      e.mem[_t_182 + 9] = _h_1529;
      e.mem[_t_182 + 10] = _h_1530;
      e.mem[_t_182 + 11] = _h_1531;
      e.mem[_t_182 + 12] = _h_1532;
      e.mem[_t_182 + 13] = _h_1533;
      e.mem[_t_182 + 14] = _h_1534;
      e.mem[_t_182 + 15] = _h_1535;
      e.mem[_t_182 + 16] = _h_1536;
      e.mem[_t_182 + 17] = _h_1537;
      e.mem[_t_182 + 18] = _h_1538;
      e.mem[_t_182 + 19] = _h_1539;
      e.mem[_t_182 + 20] = _h_1540;
      e.mem[_t_182 + 21] = _h_1541;
      e.mem[_t_182 + 22] = _h_1542;
      e.mem[_t_182 + 23] = _h_1543;
      e.mem[_t_182 + 24] = _h_1544;
      e.mem[_t_182 + 25] = _h_1545;
      e.mem[_t_182 + 26] = _h_1546;
      e.mem[_t_182 + 27] = _h_1547;
      e.mem[_t_182 + 28] = _h_1548;
      e.mem[_t_182 + 29] = _h_1549;
      WL_CONT = term_tsk(FID_CONTROLS_K267, _t_182);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_183 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_183 + 0] = _h_1515;
      e.mem[_t_183 + 1] = _h_1516;
      e.mem[_t_183 + 2] = _h_1517;
      e.mem[_t_183 + 3] = _h_1518;
      e.mem[_t_183 + 4] = _h_1519;
      return term_tsk(FID_VALIDATION, _t_183);
    }
    r0 = _h_1515;
    r1 = _h_1516;
    r2 = _h_1517;
    r3 = _h_1518;
    r4 = _h_1519;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K267)
  {
    WL_POPN(30);
    Term _h_1551 = STK(0);
    Term _h_1552 = STK(1);
    Term _h_1553 = STK(2);
    Term _h_1554 = STK(3);
    Term _h_1555 = STK(4);
    Term _h_1556 = STK(5);
    Term _h_1557 = STK(6);
    Term _h_1558 = STK(7);
    Term _h_1559 = STK(8);
    Term _h_1560 = STK(9);
    Term _h_1561 = STK(10);
    Term _h_1562 = STK(11);
    Term _h_1563 = STK(12);
    Term _h_1564 = STK(13);
    Term _h_1565 = STK(14);
    Term _h_1566 = STK(15);
    Term _h_1567 = STK(16);
    Term _h_1568 = STK(17);
    Term _h_1569 = STK(18);
    Term _h_1570 = STK(19);
    Term _h_1571 = STK(20);
    Term _h_1572 = STK(21);
    Term _h_1573 = STK(22);
    Term _h_1574 = STK(23);
    Term _h_1575 = STK(24);
    Term _h_1576 = STK(25);
    Term _h_1577 = STK(26);
    Term _h_1578 = STK(27);
    Term _h_1579 = STK(28);
    Term _h_1580 = STK(29);
    Term _h_1550 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_1551;
      STK(1) = _h_1552;
      STK(2) = _h_1553;
      STK(3) = _h_1554;
      STK(4) = _h_1555;
      STK(5) = _h_1556;
      STK(6) = _h_1557;
      STK(7) = _h_1558;
      STK(8) = _h_1559;
      STK(9) = _h_1560;
      STK(10) = _h_1561;
      STK(11) = _h_1562;
      STK(12) = _h_1563;
      STK(13) = _h_1564;
      STK(14) = _h_1565;
      STK(15) = _h_1566;
      STK(16) = _h_1567;
      STK(17) = _h_1568;
      STK(18) = _h_1569;
      STK(19) = _h_1570;
      STK(20) = _h_1571;
      STK(21) = _h_1572;
      STK(22) = _h_1573;
      STK(23) = _h_1574;
      STK(24) = _h_1575;
      STK(25) = _h_1576;
      STK(26) = _h_1577;
      STK(27) = _h_1578;
      STK(28) = _h_1579;
      STK(29) = _h_1580;
      STK(30) = FID_CONTROLS_K268;
      WL_PUSHN(31);
    } else {
      u64 _t_184 = task_node(e, FID_CONTROLS_K268, WL_CONT, WL_IDX, 1);
      e.mem[_t_184 + 0] = _h_1551;
      e.mem[_t_184 + 1] = _h_1552;
      e.mem[_t_184 + 2] = _h_1553;
      e.mem[_t_184 + 3] = _h_1554;
      e.mem[_t_184 + 4] = _h_1555;
      e.mem[_t_184 + 5] = _h_1556;
      e.mem[_t_184 + 6] = _h_1557;
      e.mem[_t_184 + 7] = _h_1558;
      e.mem[_t_184 + 8] = _h_1559;
      e.mem[_t_184 + 9] = _h_1560;
      e.mem[_t_184 + 10] = _h_1561;
      e.mem[_t_184 + 11] = _h_1562;
      e.mem[_t_184 + 12] = _h_1563;
      e.mem[_t_184 + 13] = _h_1564;
      e.mem[_t_184 + 14] = _h_1565;
      e.mem[_t_184 + 15] = _h_1566;
      e.mem[_t_184 + 16] = _h_1567;
      e.mem[_t_184 + 17] = _h_1568;
      e.mem[_t_184 + 18] = _h_1569;
      e.mem[_t_184 + 19] = _h_1570;
      e.mem[_t_184 + 20] = _h_1571;
      e.mem[_t_184 + 21] = _h_1572;
      e.mem[_t_184 + 22] = _h_1573;
      e.mem[_t_184 + 23] = _h_1574;
      e.mem[_t_184 + 24] = _h_1575;
      e.mem[_t_184 + 25] = _h_1576;
      e.mem[_t_184 + 26] = _h_1577;
      e.mem[_t_184 + 27] = _h_1578;
      e.mem[_t_184 + 28] = _h_1579;
      e.mem[_t_184 + 29] = _h_1580;
      WL_CONT = term_tsk(FID_CONTROLS_K268, _t_184);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_185 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_185 + 0] = term_ctr(CID_SCON, STAT_OFF + 1134);
      e.mem[_t_185 + 1] = _h_1550;
      return term_tsk(FID_STRING_APPEND, _t_185);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1134);
    r1 = _h_1550;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K268)
  {
    WL_POPN(30);
    Term _h_1582 = STK(0);
    Term _h_1583 = STK(1);
    Term _h_1584 = STK(2);
    Term _h_1585 = STK(3);
    Term _h_1586 = STK(4);
    Term _h_1587 = STK(5);
    Term _h_1588 = STK(6);
    Term _h_1589 = STK(7);
    Term _h_1590 = STK(8);
    Term _h_1591 = STK(9);
    Term _h_1592 = STK(10);
    Term _h_1593 = STK(11);
    Term _h_1594 = STK(12);
    Term _h_1595 = STK(13);
    Term _h_1596 = STK(14);
    Term _h_1597 = STK(15);
    Term _h_1598 = STK(16);
    Term _h_1599 = STK(17);
    Term _h_1600 = STK(18);
    Term _h_1601 = STK(19);
    Term _h_1602 = STK(20);
    Term _h_1603 = STK(21);
    Term _h_1604 = STK(22);
    Term _h_1605 = STK(23);
    Term _h_1606 = STK(24);
    Term _h_1607 = STK(25);
    Term _h_1608 = STK(26);
    Term _h_1609 = STK(27);
    Term _h_1610 = STK(28);
    Term _h_1611 = STK(29);
    Term _h_1581 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _h_1582;
      STK(1) = _h_1583;
      STK(2) = _h_1584;
      STK(3) = _h_1585;
      STK(4) = _h_1586;
      STK(5) = _h_1587;
      STK(6) = _h_1588;
      STK(7) = _h_1589;
      STK(8) = _h_1590;
      STK(9) = _h_1591;
      STK(10) = _h_1592;
      STK(11) = _h_1593;
      STK(12) = _h_1594;
      STK(13) = _h_1595;
      STK(14) = _h_1596;
      STK(15) = _h_1597;
      STK(16) = _h_1598;
      STK(17) = _h_1599;
      STK(18) = _h_1600;
      STK(19) = _h_1601;
      STK(20) = _h_1602;
      STK(21) = _h_1603;
      STK(22) = _h_1604;
      STK(23) = _h_1605;
      STK(24) = _h_1606;
      STK(25) = _h_1607;
      STK(26) = _h_1608;
      STK(27) = _h_1609;
      STK(28) = _h_1610;
      STK(29) = _h_1611;
      STK(30) = _h_1581;
      STK(31) = FID_CONTROLS_K269;
      WL_PUSHN(32);
    } else {
      u64 _t_186 = task_node(e, FID_CONTROLS_K269, WL_CONT, WL_IDX, 1);
      e.mem[_t_186 + 0] = _h_1582;
      e.mem[_t_186 + 1] = _h_1583;
      e.mem[_t_186 + 2] = _h_1584;
      e.mem[_t_186 + 3] = _h_1585;
      e.mem[_t_186 + 4] = _h_1586;
      e.mem[_t_186 + 5] = _h_1587;
      e.mem[_t_186 + 6] = _h_1588;
      e.mem[_t_186 + 7] = _h_1589;
      e.mem[_t_186 + 8] = _h_1590;
      e.mem[_t_186 + 9] = _h_1591;
      e.mem[_t_186 + 10] = _h_1592;
      e.mem[_t_186 + 11] = _h_1593;
      e.mem[_t_186 + 12] = _h_1594;
      e.mem[_t_186 + 13] = _h_1595;
      e.mem[_t_186 + 14] = _h_1596;
      e.mem[_t_186 + 15] = _h_1597;
      e.mem[_t_186 + 16] = _h_1598;
      e.mem[_t_186 + 17] = _h_1599;
      e.mem[_t_186 + 18] = _h_1600;
      e.mem[_t_186 + 19] = _h_1601;
      e.mem[_t_186 + 20] = _h_1602;
      e.mem[_t_186 + 21] = _h_1603;
      e.mem[_t_186 + 22] = _h_1604;
      e.mem[_t_186 + 23] = _h_1605;
      e.mem[_t_186 + 24] = _h_1606;
      e.mem[_t_186 + 25] = _h_1607;
      e.mem[_t_186 + 26] = _h_1608;
      e.mem[_t_186 + 27] = _h_1609;
      e.mem[_t_186 + 28] = _h_1610;
      e.mem[_t_186 + 29] = _h_1611;
      e.mem[_t_186 + 30] = _h_1581;
      WL_CONT = term_tsk(FID_CONTROLS_K269, _t_186);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_187 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_187 + 0] = term_ctr(CID_CON, STAT_OFF + 381);
      e.mem[_t_187 + 1] = 1;
      e.mem[_t_187 + 2] = 1;
      e.mem[_t_187 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_187 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_187 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_187);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 381);
    r1 = 1;
    r2 = 1;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K269)
  {
    WL_POPN(31);
    Term _h_1617 = STK(0);
    Term _h_1618 = STK(1);
    Term _h_1619 = STK(2);
    Term _h_1620 = STK(3);
    Term _h_1621 = STK(4);
    Term _h_1622 = STK(5);
    Term _h_1623 = STK(6);
    Term _h_1624 = STK(7);
    Term _h_1625 = STK(8);
    Term _h_1626 = STK(9);
    Term _h_1627 = STK(10);
    Term _h_1628 = STK(11);
    Term _h_1629 = STK(12);
    Term _h_1630 = STK(13);
    Term _h_1631 = STK(14);
    Term _h_1632 = STK(15);
    Term _h_1633 = STK(16);
    Term _h_1634 = STK(17);
    Term _h_1635 = STK(18);
    Term _h_1636 = STK(19);
    Term _h_1637 = STK(20);
    Term _h_1638 = STK(21);
    Term _h_1639 = STK(22);
    Term _h_1640 = STK(23);
    Term _h_1641 = STK(24);
    Term _h_1642 = STK(25);
    Term _h_1643 = STK(26);
    Term _h_1644 = STK(27);
    Term _h_1645 = STK(28);
    Term _h_1646 = STK(29);
    Term _h_1647 = STK(30);
    u32 _h_1612 = r0;
    u32 _h_1613 = r1;
    u32 _h_1614 = r2;
    Term _h_1615 = r3;
    Term _h_1616 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _h_1617;
      STK(1) = _h_1618;
      STK(2) = _h_1619;
      STK(3) = _h_1620;
      STK(4) = _h_1621;
      STK(5) = _h_1622;
      STK(6) = _h_1623;
      STK(7) = _h_1624;
      STK(8) = _h_1625;
      STK(9) = _h_1626;
      STK(10) = _h_1627;
      STK(11) = _h_1628;
      STK(12) = _h_1629;
      STK(13) = _h_1630;
      STK(14) = _h_1631;
      STK(15) = _h_1632;
      STK(16) = _h_1633;
      STK(17) = _h_1634;
      STK(18) = _h_1635;
      STK(19) = _h_1636;
      STK(20) = _h_1637;
      STK(21) = _h_1638;
      STK(22) = _h_1639;
      STK(23) = _h_1640;
      STK(24) = _h_1641;
      STK(25) = _h_1642;
      STK(26) = _h_1643;
      STK(27) = _h_1644;
      STK(28) = _h_1645;
      STK(29) = _h_1646;
      STK(30) = _h_1647;
      STK(31) = FID_CONTROLS_K270;
      WL_PUSHN(32);
    } else {
      u64 _t_188 = task_node(e, FID_CONTROLS_K270, WL_CONT, WL_IDX, 1);
      e.mem[_t_188 + 0] = _h_1617;
      e.mem[_t_188 + 1] = _h_1618;
      e.mem[_t_188 + 2] = _h_1619;
      e.mem[_t_188 + 3] = _h_1620;
      e.mem[_t_188 + 4] = _h_1621;
      e.mem[_t_188 + 5] = _h_1622;
      e.mem[_t_188 + 6] = _h_1623;
      e.mem[_t_188 + 7] = _h_1624;
      e.mem[_t_188 + 8] = _h_1625;
      e.mem[_t_188 + 9] = _h_1626;
      e.mem[_t_188 + 10] = _h_1627;
      e.mem[_t_188 + 11] = _h_1628;
      e.mem[_t_188 + 12] = _h_1629;
      e.mem[_t_188 + 13] = _h_1630;
      e.mem[_t_188 + 14] = _h_1631;
      e.mem[_t_188 + 15] = _h_1632;
      e.mem[_t_188 + 16] = _h_1633;
      e.mem[_t_188 + 17] = _h_1634;
      e.mem[_t_188 + 18] = _h_1635;
      e.mem[_t_188 + 19] = _h_1636;
      e.mem[_t_188 + 20] = _h_1637;
      e.mem[_t_188 + 21] = _h_1638;
      e.mem[_t_188 + 22] = _h_1639;
      e.mem[_t_188 + 23] = _h_1640;
      e.mem[_t_188 + 24] = _h_1641;
      e.mem[_t_188 + 25] = _h_1642;
      e.mem[_t_188 + 26] = _h_1643;
      e.mem[_t_188 + 27] = _h_1644;
      e.mem[_t_188 + 28] = _h_1645;
      e.mem[_t_188 + 29] = _h_1646;
      e.mem[_t_188 + 30] = _h_1647;
      WL_CONT = term_tsk(FID_CONTROLS_K270, _t_188);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_189 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_189 + 0] = _h_1612;
      e.mem[_t_189 + 1] = _h_1613;
      e.mem[_t_189 + 2] = _h_1614;
      e.mem[_t_189 + 3] = _h_1615;
      e.mem[_t_189 + 4] = _h_1616;
      return term_tsk(FID_VALIDATION, _t_189);
    }
    r0 = _h_1612;
    r1 = _h_1613;
    r2 = _h_1614;
    r3 = _h_1615;
    r4 = _h_1616;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K270)
  {
    WL_POPN(31);
    Term _h_1649 = STK(0);
    Term _h_1650 = STK(1);
    Term _h_1651 = STK(2);
    Term _h_1652 = STK(3);
    Term _h_1653 = STK(4);
    Term _h_1654 = STK(5);
    Term _h_1655 = STK(6);
    Term _h_1656 = STK(7);
    Term _h_1657 = STK(8);
    Term _h_1658 = STK(9);
    Term _h_1659 = STK(10);
    Term _h_1660 = STK(11);
    Term _h_1661 = STK(12);
    Term _h_1662 = STK(13);
    Term _h_1663 = STK(14);
    Term _h_1664 = STK(15);
    Term _h_1665 = STK(16);
    Term _h_1666 = STK(17);
    Term _h_1667 = STK(18);
    Term _h_1668 = STK(19);
    Term _h_1669 = STK(20);
    Term _h_1670 = STK(21);
    Term _h_1671 = STK(22);
    Term _h_1672 = STK(23);
    Term _h_1673 = STK(24);
    Term _h_1674 = STK(25);
    Term _h_1675 = STK(26);
    Term _h_1676 = STK(27);
    Term _h_1677 = STK(28);
    Term _h_1678 = STK(29);
    Term _h_1679 = STK(30);
    Term _h_1648 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _h_1649;
      STK(1) = _h_1650;
      STK(2) = _h_1651;
      STK(3) = _h_1652;
      STK(4) = _h_1653;
      STK(5) = _h_1654;
      STK(6) = _h_1655;
      STK(7) = _h_1656;
      STK(8) = _h_1657;
      STK(9) = _h_1658;
      STK(10) = _h_1659;
      STK(11) = _h_1660;
      STK(12) = _h_1661;
      STK(13) = _h_1662;
      STK(14) = _h_1663;
      STK(15) = _h_1664;
      STK(16) = _h_1665;
      STK(17) = _h_1666;
      STK(18) = _h_1667;
      STK(19) = _h_1668;
      STK(20) = _h_1669;
      STK(21) = _h_1670;
      STK(22) = _h_1671;
      STK(23) = _h_1672;
      STK(24) = _h_1673;
      STK(25) = _h_1674;
      STK(26) = _h_1675;
      STK(27) = _h_1676;
      STK(28) = _h_1677;
      STK(29) = _h_1678;
      STK(30) = _h_1679;
      STK(31) = FID_CONTROLS_K271;
      WL_PUSHN(32);
    } else {
      u64 _t_190 = task_node(e, FID_CONTROLS_K271, WL_CONT, WL_IDX, 1);
      e.mem[_t_190 + 0] = _h_1649;
      e.mem[_t_190 + 1] = _h_1650;
      e.mem[_t_190 + 2] = _h_1651;
      e.mem[_t_190 + 3] = _h_1652;
      e.mem[_t_190 + 4] = _h_1653;
      e.mem[_t_190 + 5] = _h_1654;
      e.mem[_t_190 + 6] = _h_1655;
      e.mem[_t_190 + 7] = _h_1656;
      e.mem[_t_190 + 8] = _h_1657;
      e.mem[_t_190 + 9] = _h_1658;
      e.mem[_t_190 + 10] = _h_1659;
      e.mem[_t_190 + 11] = _h_1660;
      e.mem[_t_190 + 12] = _h_1661;
      e.mem[_t_190 + 13] = _h_1662;
      e.mem[_t_190 + 14] = _h_1663;
      e.mem[_t_190 + 15] = _h_1664;
      e.mem[_t_190 + 16] = _h_1665;
      e.mem[_t_190 + 17] = _h_1666;
      e.mem[_t_190 + 18] = _h_1667;
      e.mem[_t_190 + 19] = _h_1668;
      e.mem[_t_190 + 20] = _h_1669;
      e.mem[_t_190 + 21] = _h_1670;
      e.mem[_t_190 + 22] = _h_1671;
      e.mem[_t_190 + 23] = _h_1672;
      e.mem[_t_190 + 24] = _h_1673;
      e.mem[_t_190 + 25] = _h_1674;
      e.mem[_t_190 + 26] = _h_1675;
      e.mem[_t_190 + 27] = _h_1676;
      e.mem[_t_190 + 28] = _h_1677;
      e.mem[_t_190 + 29] = _h_1678;
      e.mem[_t_190 + 30] = _h_1679;
      WL_CONT = term_tsk(FID_CONTROLS_K271, _t_190);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_191 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_191 + 0] = term_ctr(CID_SCON, STAT_OFF + 1154);
      e.mem[_t_191 + 1] = _h_1648;
      return term_tsk(FID_STRING_APPEND, _t_191);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1154);
    r1 = _h_1648;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K271)
  {
    WL_POPN(31);
    Term _h_1681 = STK(0);
    Term _h_1682 = STK(1);
    Term _h_1683 = STK(2);
    Term _h_1684 = STK(3);
    Term _h_1685 = STK(4);
    Term _h_1686 = STK(5);
    Term _h_1687 = STK(6);
    Term _h_1688 = STK(7);
    Term _h_1689 = STK(8);
    Term _h_1690 = STK(9);
    Term _h_1691 = STK(10);
    Term _h_1692 = STK(11);
    Term _h_1693 = STK(12);
    Term _h_1694 = STK(13);
    Term _h_1695 = STK(14);
    Term _h_1696 = STK(15);
    Term _h_1697 = STK(16);
    Term _h_1698 = STK(17);
    Term _h_1699 = STK(18);
    Term _h_1700 = STK(19);
    Term _h_1701 = STK(20);
    Term _h_1702 = STK(21);
    Term _h_1703 = STK(22);
    Term _h_1704 = STK(23);
    Term _h_1705 = STK(24);
    Term _h_1706 = STK(25);
    Term _h_1707 = STK(26);
    Term _h_1708 = STK(27);
    Term _h_1709 = STK(28);
    Term _h_1710 = STK(29);
    Term _h_1711 = STK(30);
    Term _h_1680 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _h_1681;
      STK(1) = _h_1682;
      STK(2) = _h_1683;
      STK(3) = _h_1684;
      STK(4) = _h_1685;
      STK(5) = _h_1686;
      STK(6) = _h_1687;
      STK(7) = _h_1688;
      STK(8) = _h_1689;
      STK(9) = _h_1690;
      STK(10) = _h_1691;
      STK(11) = _h_1692;
      STK(12) = _h_1693;
      STK(13) = _h_1694;
      STK(14) = _h_1695;
      STK(15) = _h_1696;
      STK(16) = _h_1697;
      STK(17) = _h_1698;
      STK(18) = _h_1699;
      STK(19) = _h_1700;
      STK(20) = _h_1701;
      STK(21) = _h_1702;
      STK(22) = _h_1703;
      STK(23) = _h_1704;
      STK(24) = _h_1705;
      STK(25) = _h_1706;
      STK(26) = _h_1707;
      STK(27) = _h_1708;
      STK(28) = _h_1709;
      STK(29) = _h_1710;
      STK(30) = _h_1711;
      STK(31) = _h_1680;
      STK(32) = FID_CONTROLS_K272;
      WL_PUSHN(33);
    } else {
      u64 _t_192 = task_node(e, FID_CONTROLS_K272, WL_CONT, WL_IDX, 1);
      e.mem[_t_192 + 0] = _h_1681;
      e.mem[_t_192 + 1] = _h_1682;
      e.mem[_t_192 + 2] = _h_1683;
      e.mem[_t_192 + 3] = _h_1684;
      e.mem[_t_192 + 4] = _h_1685;
      e.mem[_t_192 + 5] = _h_1686;
      e.mem[_t_192 + 6] = _h_1687;
      e.mem[_t_192 + 7] = _h_1688;
      e.mem[_t_192 + 8] = _h_1689;
      e.mem[_t_192 + 9] = _h_1690;
      e.mem[_t_192 + 10] = _h_1691;
      e.mem[_t_192 + 11] = _h_1692;
      e.mem[_t_192 + 12] = _h_1693;
      e.mem[_t_192 + 13] = _h_1694;
      e.mem[_t_192 + 14] = _h_1695;
      e.mem[_t_192 + 15] = _h_1696;
      e.mem[_t_192 + 16] = _h_1697;
      e.mem[_t_192 + 17] = _h_1698;
      e.mem[_t_192 + 18] = _h_1699;
      e.mem[_t_192 + 19] = _h_1700;
      e.mem[_t_192 + 20] = _h_1701;
      e.mem[_t_192 + 21] = _h_1702;
      e.mem[_t_192 + 22] = _h_1703;
      e.mem[_t_192 + 23] = _h_1704;
      e.mem[_t_192 + 24] = _h_1705;
      e.mem[_t_192 + 25] = _h_1706;
      e.mem[_t_192 + 26] = _h_1707;
      e.mem[_t_192 + 27] = _h_1708;
      e.mem[_t_192 + 28] = _h_1709;
      e.mem[_t_192 + 29] = _h_1710;
      e.mem[_t_192 + 30] = _h_1711;
      e.mem[_t_192 + 31] = _h_1680;
      WL_CONT = term_tsk(FID_CONTROLS_K272, _t_192);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_193 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_193 + 0] = term_ctr(CID_CON, STAT_OFF + 776);
      e.mem[_t_193 + 1] = 1;
      e.mem[_t_193 + 2] = 2;
      e.mem[_t_193 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_193 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_193 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_193);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 776);
    r1 = 1;
    r2 = 2;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K272)
  {
    WL_POPN(32);
    Term _h_1717 = STK(0);
    Term _h_1718 = STK(1);
    Term _h_1719 = STK(2);
    Term _h_1720 = STK(3);
    Term _h_1721 = STK(4);
    Term _h_1722 = STK(5);
    Term _h_1723 = STK(6);
    Term _h_1724 = STK(7);
    Term _h_1725 = STK(8);
    Term _h_1726 = STK(9);
    Term _h_1727 = STK(10);
    Term _h_1728 = STK(11);
    Term _h_1729 = STK(12);
    Term _h_1730 = STK(13);
    Term _h_1731 = STK(14);
    Term _h_1732 = STK(15);
    Term _h_1733 = STK(16);
    Term _h_1734 = STK(17);
    Term _h_1735 = STK(18);
    Term _h_1736 = STK(19);
    Term _h_1737 = STK(20);
    Term _h_1738 = STK(21);
    Term _h_1739 = STK(22);
    Term _h_1740 = STK(23);
    Term _h_1741 = STK(24);
    Term _h_1742 = STK(25);
    Term _h_1743 = STK(26);
    Term _h_1744 = STK(27);
    Term _h_1745 = STK(28);
    Term _h_1746 = STK(29);
    Term _h_1747 = STK(30);
    Term _h_1748 = STK(31);
    u32 _h_1712 = r0;
    u32 _h_1713 = r1;
    u32 _h_1714 = r2;
    Term _h_1715 = r3;
    Term _h_1716 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _h_1717;
      STK(1) = _h_1718;
      STK(2) = _h_1719;
      STK(3) = _h_1720;
      STK(4) = _h_1721;
      STK(5) = _h_1722;
      STK(6) = _h_1723;
      STK(7) = _h_1724;
      STK(8) = _h_1725;
      STK(9) = _h_1726;
      STK(10) = _h_1727;
      STK(11) = _h_1728;
      STK(12) = _h_1729;
      STK(13) = _h_1730;
      STK(14) = _h_1731;
      STK(15) = _h_1732;
      STK(16) = _h_1733;
      STK(17) = _h_1734;
      STK(18) = _h_1735;
      STK(19) = _h_1736;
      STK(20) = _h_1737;
      STK(21) = _h_1738;
      STK(22) = _h_1739;
      STK(23) = _h_1740;
      STK(24) = _h_1741;
      STK(25) = _h_1742;
      STK(26) = _h_1743;
      STK(27) = _h_1744;
      STK(28) = _h_1745;
      STK(29) = _h_1746;
      STK(30) = _h_1747;
      STK(31) = _h_1748;
      STK(32) = FID_CONTROLS_K273;
      WL_PUSHN(33);
    } else {
      u64 _t_194 = task_node(e, FID_CONTROLS_K273, WL_CONT, WL_IDX, 1);
      e.mem[_t_194 + 0] = _h_1717;
      e.mem[_t_194 + 1] = _h_1718;
      e.mem[_t_194 + 2] = _h_1719;
      e.mem[_t_194 + 3] = _h_1720;
      e.mem[_t_194 + 4] = _h_1721;
      e.mem[_t_194 + 5] = _h_1722;
      e.mem[_t_194 + 6] = _h_1723;
      e.mem[_t_194 + 7] = _h_1724;
      e.mem[_t_194 + 8] = _h_1725;
      e.mem[_t_194 + 9] = _h_1726;
      e.mem[_t_194 + 10] = _h_1727;
      e.mem[_t_194 + 11] = _h_1728;
      e.mem[_t_194 + 12] = _h_1729;
      e.mem[_t_194 + 13] = _h_1730;
      e.mem[_t_194 + 14] = _h_1731;
      e.mem[_t_194 + 15] = _h_1732;
      e.mem[_t_194 + 16] = _h_1733;
      e.mem[_t_194 + 17] = _h_1734;
      e.mem[_t_194 + 18] = _h_1735;
      e.mem[_t_194 + 19] = _h_1736;
      e.mem[_t_194 + 20] = _h_1737;
      e.mem[_t_194 + 21] = _h_1738;
      e.mem[_t_194 + 22] = _h_1739;
      e.mem[_t_194 + 23] = _h_1740;
      e.mem[_t_194 + 24] = _h_1741;
      e.mem[_t_194 + 25] = _h_1742;
      e.mem[_t_194 + 26] = _h_1743;
      e.mem[_t_194 + 27] = _h_1744;
      e.mem[_t_194 + 28] = _h_1745;
      e.mem[_t_194 + 29] = _h_1746;
      e.mem[_t_194 + 30] = _h_1747;
      e.mem[_t_194 + 31] = _h_1748;
      WL_CONT = term_tsk(FID_CONTROLS_K273, _t_194);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_195 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_195 + 0] = _h_1712;
      e.mem[_t_195 + 1] = _h_1713;
      e.mem[_t_195 + 2] = _h_1714;
      e.mem[_t_195 + 3] = _h_1715;
      e.mem[_t_195 + 4] = _h_1716;
      return term_tsk(FID_VALIDATION, _t_195);
    }
    r0 = _h_1712;
    r1 = _h_1713;
    r2 = _h_1714;
    r3 = _h_1715;
    r4 = _h_1716;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K273)
  {
    WL_POPN(32);
    Term _h_1750 = STK(0);
    Term _h_1751 = STK(1);
    Term _h_1752 = STK(2);
    Term _h_1753 = STK(3);
    Term _h_1754 = STK(4);
    Term _h_1755 = STK(5);
    Term _h_1756 = STK(6);
    Term _h_1757 = STK(7);
    Term _h_1758 = STK(8);
    Term _h_1759 = STK(9);
    Term _h_1760 = STK(10);
    Term _h_1761 = STK(11);
    Term _h_1762 = STK(12);
    Term _h_1763 = STK(13);
    Term _h_1764 = STK(14);
    Term _h_1765 = STK(15);
    Term _h_1766 = STK(16);
    Term _h_1767 = STK(17);
    Term _h_1768 = STK(18);
    Term _h_1769 = STK(19);
    Term _h_1770 = STK(20);
    Term _h_1771 = STK(21);
    Term _h_1772 = STK(22);
    Term _h_1773 = STK(23);
    Term _h_1774 = STK(24);
    Term _h_1775 = STK(25);
    Term _h_1776 = STK(26);
    Term _h_1777 = STK(27);
    Term _h_1778 = STK(28);
    Term _h_1779 = STK(29);
    Term _h_1780 = STK(30);
    Term _h_1781 = STK(31);
    Term _h_1749 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(33);
      STK(0) = _h_1750;
      STK(1) = _h_1751;
      STK(2) = _h_1752;
      STK(3) = _h_1753;
      STK(4) = _h_1754;
      STK(5) = _h_1755;
      STK(6) = _h_1756;
      STK(7) = _h_1757;
      STK(8) = _h_1758;
      STK(9) = _h_1759;
      STK(10) = _h_1760;
      STK(11) = _h_1761;
      STK(12) = _h_1762;
      STK(13) = _h_1763;
      STK(14) = _h_1764;
      STK(15) = _h_1765;
      STK(16) = _h_1766;
      STK(17) = _h_1767;
      STK(18) = _h_1768;
      STK(19) = _h_1769;
      STK(20) = _h_1770;
      STK(21) = _h_1771;
      STK(22) = _h_1772;
      STK(23) = _h_1773;
      STK(24) = _h_1774;
      STK(25) = _h_1775;
      STK(26) = _h_1776;
      STK(27) = _h_1777;
      STK(28) = _h_1778;
      STK(29) = _h_1779;
      STK(30) = _h_1780;
      STK(31) = _h_1781;
      STK(32) = FID_CONTROLS_K274;
      WL_PUSHN(33);
    } else {
      u64 _t_196 = task_node(e, FID_CONTROLS_K274, WL_CONT, WL_IDX, 1);
      e.mem[_t_196 + 0] = _h_1750;
      e.mem[_t_196 + 1] = _h_1751;
      e.mem[_t_196 + 2] = _h_1752;
      e.mem[_t_196 + 3] = _h_1753;
      e.mem[_t_196 + 4] = _h_1754;
      e.mem[_t_196 + 5] = _h_1755;
      e.mem[_t_196 + 6] = _h_1756;
      e.mem[_t_196 + 7] = _h_1757;
      e.mem[_t_196 + 8] = _h_1758;
      e.mem[_t_196 + 9] = _h_1759;
      e.mem[_t_196 + 10] = _h_1760;
      e.mem[_t_196 + 11] = _h_1761;
      e.mem[_t_196 + 12] = _h_1762;
      e.mem[_t_196 + 13] = _h_1763;
      e.mem[_t_196 + 14] = _h_1764;
      e.mem[_t_196 + 15] = _h_1765;
      e.mem[_t_196 + 16] = _h_1766;
      e.mem[_t_196 + 17] = _h_1767;
      e.mem[_t_196 + 18] = _h_1768;
      e.mem[_t_196 + 19] = _h_1769;
      e.mem[_t_196 + 20] = _h_1770;
      e.mem[_t_196 + 21] = _h_1771;
      e.mem[_t_196 + 22] = _h_1772;
      e.mem[_t_196 + 23] = _h_1773;
      e.mem[_t_196 + 24] = _h_1774;
      e.mem[_t_196 + 25] = _h_1775;
      e.mem[_t_196 + 26] = _h_1776;
      e.mem[_t_196 + 27] = _h_1777;
      e.mem[_t_196 + 28] = _h_1778;
      e.mem[_t_196 + 29] = _h_1779;
      e.mem[_t_196 + 30] = _h_1780;
      e.mem[_t_196 + 31] = _h_1781;
      WL_CONT = term_tsk(FID_CONTROLS_K274, _t_196);
      WL_IDX = 32;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_197 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_197 + 0] = term_ctr(CID_SCON, STAT_OFF + 1174);
      e.mem[_t_197 + 1] = _h_1749;
      return term_tsk(FID_STRING_APPEND, _t_197);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1174);
    r1 = _h_1749;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K274)
  {
    WL_POPN(32);
    Term _h_1783 = STK(0);
    Term _h_1784 = STK(1);
    Term _h_1785 = STK(2);
    Term _h_1786 = STK(3);
    Term _h_1787 = STK(4);
    Term _h_1788 = STK(5);
    Term _h_1789 = STK(6);
    Term _h_1790 = STK(7);
    Term _h_1791 = STK(8);
    Term _h_1792 = STK(9);
    Term _h_1793 = STK(10);
    Term _h_1794 = STK(11);
    Term _h_1795 = STK(12);
    Term _h_1796 = STK(13);
    Term _h_1797 = STK(14);
    Term _h_1798 = STK(15);
    Term _h_1799 = STK(16);
    Term _h_1800 = STK(17);
    Term _h_1801 = STK(18);
    Term _h_1802 = STK(19);
    Term _h_1803 = STK(20);
    Term _h_1804 = STK(21);
    Term _h_1805 = STK(22);
    Term _h_1806 = STK(23);
    Term _h_1807 = STK(24);
    Term _h_1808 = STK(25);
    Term _h_1809 = STK(26);
    Term _h_1810 = STK(27);
    Term _h_1811 = STK(28);
    Term _h_1812 = STK(29);
    Term _h_1813 = STK(30);
    Term _h_1814 = STK(31);
    Term _h_1782 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _h_1783;
      STK(1) = _h_1784;
      STK(2) = _h_1785;
      STK(3) = _h_1786;
      STK(4) = _h_1787;
      STK(5) = _h_1788;
      STK(6) = _h_1789;
      STK(7) = _h_1790;
      STK(8) = _h_1791;
      STK(9) = _h_1792;
      STK(10) = _h_1793;
      STK(11) = _h_1794;
      STK(12) = _h_1795;
      STK(13) = _h_1796;
      STK(14) = _h_1797;
      STK(15) = _h_1798;
      STK(16) = _h_1799;
      STK(17) = _h_1800;
      STK(18) = _h_1801;
      STK(19) = _h_1802;
      STK(20) = _h_1803;
      STK(21) = _h_1804;
      STK(22) = _h_1805;
      STK(23) = _h_1806;
      STK(24) = _h_1807;
      STK(25) = _h_1808;
      STK(26) = _h_1809;
      STK(27) = _h_1810;
      STK(28) = _h_1811;
      STK(29) = _h_1812;
      STK(30) = _h_1813;
      STK(31) = _h_1814;
      STK(32) = _h_1782;
      STK(33) = FID_CONTROLS_K275;
      WL_PUSHN(34);
    } else {
      u64 _t_198 = task_node(e, FID_CONTROLS_K275, WL_CONT, WL_IDX, 1);
      e.mem[_t_198 + 0] = _h_1783;
      e.mem[_t_198 + 1] = _h_1784;
      e.mem[_t_198 + 2] = _h_1785;
      e.mem[_t_198 + 3] = _h_1786;
      e.mem[_t_198 + 4] = _h_1787;
      e.mem[_t_198 + 5] = _h_1788;
      e.mem[_t_198 + 6] = _h_1789;
      e.mem[_t_198 + 7] = _h_1790;
      e.mem[_t_198 + 8] = _h_1791;
      e.mem[_t_198 + 9] = _h_1792;
      e.mem[_t_198 + 10] = _h_1793;
      e.mem[_t_198 + 11] = _h_1794;
      e.mem[_t_198 + 12] = _h_1795;
      e.mem[_t_198 + 13] = _h_1796;
      e.mem[_t_198 + 14] = _h_1797;
      e.mem[_t_198 + 15] = _h_1798;
      e.mem[_t_198 + 16] = _h_1799;
      e.mem[_t_198 + 17] = _h_1800;
      e.mem[_t_198 + 18] = _h_1801;
      e.mem[_t_198 + 19] = _h_1802;
      e.mem[_t_198 + 20] = _h_1803;
      e.mem[_t_198 + 21] = _h_1804;
      e.mem[_t_198 + 22] = _h_1805;
      e.mem[_t_198 + 23] = _h_1806;
      e.mem[_t_198 + 24] = _h_1807;
      e.mem[_t_198 + 25] = _h_1808;
      e.mem[_t_198 + 26] = _h_1809;
      e.mem[_t_198 + 27] = _h_1810;
      e.mem[_t_198 + 28] = _h_1811;
      e.mem[_t_198 + 29] = _h_1812;
      e.mem[_t_198 + 30] = _h_1813;
      e.mem[_t_198 + 31] = _h_1814;
      e.mem[_t_198 + 32] = _h_1782;
      WL_CONT = term_tsk(FID_CONTROLS_K275, _t_198);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_199 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_199 + 0] = term_ctr(CID_CON, STAT_OFF + 802);
      e.mem[_t_199 + 1] = 1;
      e.mem[_t_199 + 2] = 3;
      e.mem[_t_199 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_199 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_199 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_199);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 802);
    r1 = 1;
    r2 = 3;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K275)
  {
    WL_POPN(33);
    Term _h_1820 = STK(0);
    Term _h_1821 = STK(1);
    Term _h_1822 = STK(2);
    Term _h_1823 = STK(3);
    Term _h_1824 = STK(4);
    Term _h_1825 = STK(5);
    Term _h_1826 = STK(6);
    Term _h_1827 = STK(7);
    Term _h_1828 = STK(8);
    Term _h_1829 = STK(9);
    Term _h_1830 = STK(10);
    Term _h_1831 = STK(11);
    Term _h_1832 = STK(12);
    Term _h_1833 = STK(13);
    Term _h_1834 = STK(14);
    Term _h_1835 = STK(15);
    Term _h_1836 = STK(16);
    Term _h_1837 = STK(17);
    Term _h_1838 = STK(18);
    Term _h_1839 = STK(19);
    Term _h_1840 = STK(20);
    Term _h_1841 = STK(21);
    Term _h_1842 = STK(22);
    Term _h_1843 = STK(23);
    Term _h_1844 = STK(24);
    Term _h_1845 = STK(25);
    Term _h_1846 = STK(26);
    Term _h_1847 = STK(27);
    Term _h_1848 = STK(28);
    Term _h_1849 = STK(29);
    Term _h_1850 = STK(30);
    Term _h_1851 = STK(31);
    Term _h_1852 = STK(32);
    u32 _h_1815 = r0;
    u32 _h_1816 = r1;
    u32 _h_1817 = r2;
    Term _h_1818 = r3;
    Term _h_1819 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _h_1820;
      STK(1) = _h_1821;
      STK(2) = _h_1822;
      STK(3) = _h_1823;
      STK(4) = _h_1824;
      STK(5) = _h_1825;
      STK(6) = _h_1826;
      STK(7) = _h_1827;
      STK(8) = _h_1828;
      STK(9) = _h_1829;
      STK(10) = _h_1830;
      STK(11) = _h_1831;
      STK(12) = _h_1832;
      STK(13) = _h_1833;
      STK(14) = _h_1834;
      STK(15) = _h_1835;
      STK(16) = _h_1836;
      STK(17) = _h_1837;
      STK(18) = _h_1838;
      STK(19) = _h_1839;
      STK(20) = _h_1840;
      STK(21) = _h_1841;
      STK(22) = _h_1842;
      STK(23) = _h_1843;
      STK(24) = _h_1844;
      STK(25) = _h_1845;
      STK(26) = _h_1846;
      STK(27) = _h_1847;
      STK(28) = _h_1848;
      STK(29) = _h_1849;
      STK(30) = _h_1850;
      STK(31) = _h_1851;
      STK(32) = _h_1852;
      STK(33) = FID_CONTROLS_K276;
      WL_PUSHN(34);
    } else {
      u64 _t_200 = task_node(e, FID_CONTROLS_K276, WL_CONT, WL_IDX, 1);
      e.mem[_t_200 + 0] = _h_1820;
      e.mem[_t_200 + 1] = _h_1821;
      e.mem[_t_200 + 2] = _h_1822;
      e.mem[_t_200 + 3] = _h_1823;
      e.mem[_t_200 + 4] = _h_1824;
      e.mem[_t_200 + 5] = _h_1825;
      e.mem[_t_200 + 6] = _h_1826;
      e.mem[_t_200 + 7] = _h_1827;
      e.mem[_t_200 + 8] = _h_1828;
      e.mem[_t_200 + 9] = _h_1829;
      e.mem[_t_200 + 10] = _h_1830;
      e.mem[_t_200 + 11] = _h_1831;
      e.mem[_t_200 + 12] = _h_1832;
      e.mem[_t_200 + 13] = _h_1833;
      e.mem[_t_200 + 14] = _h_1834;
      e.mem[_t_200 + 15] = _h_1835;
      e.mem[_t_200 + 16] = _h_1836;
      e.mem[_t_200 + 17] = _h_1837;
      e.mem[_t_200 + 18] = _h_1838;
      e.mem[_t_200 + 19] = _h_1839;
      e.mem[_t_200 + 20] = _h_1840;
      e.mem[_t_200 + 21] = _h_1841;
      e.mem[_t_200 + 22] = _h_1842;
      e.mem[_t_200 + 23] = _h_1843;
      e.mem[_t_200 + 24] = _h_1844;
      e.mem[_t_200 + 25] = _h_1845;
      e.mem[_t_200 + 26] = _h_1846;
      e.mem[_t_200 + 27] = _h_1847;
      e.mem[_t_200 + 28] = _h_1848;
      e.mem[_t_200 + 29] = _h_1849;
      e.mem[_t_200 + 30] = _h_1850;
      e.mem[_t_200 + 31] = _h_1851;
      e.mem[_t_200 + 32] = _h_1852;
      WL_CONT = term_tsk(FID_CONTROLS_K276, _t_200);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_201 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_201 + 0] = _h_1815;
      e.mem[_t_201 + 1] = _h_1816;
      e.mem[_t_201 + 2] = _h_1817;
      e.mem[_t_201 + 3] = _h_1818;
      e.mem[_t_201 + 4] = _h_1819;
      return term_tsk(FID_VALIDATION, _t_201);
    }
    r0 = _h_1815;
    r1 = _h_1816;
    r2 = _h_1817;
    r3 = _h_1818;
    r4 = _h_1819;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K276)
  {
    WL_POPN(33);
    Term _h_1854 = STK(0);
    Term _h_1855 = STK(1);
    Term _h_1856 = STK(2);
    Term _h_1857 = STK(3);
    Term _h_1858 = STK(4);
    Term _h_1859 = STK(5);
    Term _h_1860 = STK(6);
    Term _h_1861 = STK(7);
    Term _h_1862 = STK(8);
    Term _h_1863 = STK(9);
    Term _h_1864 = STK(10);
    Term _h_1865 = STK(11);
    Term _h_1866 = STK(12);
    Term _h_1867 = STK(13);
    Term _h_1868 = STK(14);
    Term _h_1869 = STK(15);
    Term _h_1870 = STK(16);
    Term _h_1871 = STK(17);
    Term _h_1872 = STK(18);
    Term _h_1873 = STK(19);
    Term _h_1874 = STK(20);
    Term _h_1875 = STK(21);
    Term _h_1876 = STK(22);
    Term _h_1877 = STK(23);
    Term _h_1878 = STK(24);
    Term _h_1879 = STK(25);
    Term _h_1880 = STK(26);
    Term _h_1881 = STK(27);
    Term _h_1882 = STK(28);
    Term _h_1883 = STK(29);
    Term _h_1884 = STK(30);
    Term _h_1885 = STK(31);
    Term _h_1886 = STK(32);
    Term _h_1853 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(34);
      STK(0) = _h_1854;
      STK(1) = _h_1855;
      STK(2) = _h_1856;
      STK(3) = _h_1857;
      STK(4) = _h_1858;
      STK(5) = _h_1859;
      STK(6) = _h_1860;
      STK(7) = _h_1861;
      STK(8) = _h_1862;
      STK(9) = _h_1863;
      STK(10) = _h_1864;
      STK(11) = _h_1865;
      STK(12) = _h_1866;
      STK(13) = _h_1867;
      STK(14) = _h_1868;
      STK(15) = _h_1869;
      STK(16) = _h_1870;
      STK(17) = _h_1871;
      STK(18) = _h_1872;
      STK(19) = _h_1873;
      STK(20) = _h_1874;
      STK(21) = _h_1875;
      STK(22) = _h_1876;
      STK(23) = _h_1877;
      STK(24) = _h_1878;
      STK(25) = _h_1879;
      STK(26) = _h_1880;
      STK(27) = _h_1881;
      STK(28) = _h_1882;
      STK(29) = _h_1883;
      STK(30) = _h_1884;
      STK(31) = _h_1885;
      STK(32) = _h_1886;
      STK(33) = FID_CONTROLS_K277;
      WL_PUSHN(34);
    } else {
      u64 _t_202 = task_node(e, FID_CONTROLS_K277, WL_CONT, WL_IDX, 1);
      e.mem[_t_202 + 0] = _h_1854;
      e.mem[_t_202 + 1] = _h_1855;
      e.mem[_t_202 + 2] = _h_1856;
      e.mem[_t_202 + 3] = _h_1857;
      e.mem[_t_202 + 4] = _h_1858;
      e.mem[_t_202 + 5] = _h_1859;
      e.mem[_t_202 + 6] = _h_1860;
      e.mem[_t_202 + 7] = _h_1861;
      e.mem[_t_202 + 8] = _h_1862;
      e.mem[_t_202 + 9] = _h_1863;
      e.mem[_t_202 + 10] = _h_1864;
      e.mem[_t_202 + 11] = _h_1865;
      e.mem[_t_202 + 12] = _h_1866;
      e.mem[_t_202 + 13] = _h_1867;
      e.mem[_t_202 + 14] = _h_1868;
      e.mem[_t_202 + 15] = _h_1869;
      e.mem[_t_202 + 16] = _h_1870;
      e.mem[_t_202 + 17] = _h_1871;
      e.mem[_t_202 + 18] = _h_1872;
      e.mem[_t_202 + 19] = _h_1873;
      e.mem[_t_202 + 20] = _h_1874;
      e.mem[_t_202 + 21] = _h_1875;
      e.mem[_t_202 + 22] = _h_1876;
      e.mem[_t_202 + 23] = _h_1877;
      e.mem[_t_202 + 24] = _h_1878;
      e.mem[_t_202 + 25] = _h_1879;
      e.mem[_t_202 + 26] = _h_1880;
      e.mem[_t_202 + 27] = _h_1881;
      e.mem[_t_202 + 28] = _h_1882;
      e.mem[_t_202 + 29] = _h_1883;
      e.mem[_t_202 + 30] = _h_1884;
      e.mem[_t_202 + 31] = _h_1885;
      e.mem[_t_202 + 32] = _h_1886;
      WL_CONT = term_tsk(FID_CONTROLS_K277, _t_202);
      WL_IDX = 33;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_203 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_203 + 0] = term_ctr(CID_SCON, STAT_OFF + 1194);
      e.mem[_t_203 + 1] = _h_1853;
      return term_tsk(FID_STRING_APPEND, _t_203);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1194);
    r1 = _h_1853;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K277)
  {
    WL_POPN(33);
    Term _h_1888 = STK(0);
    Term _h_1889 = STK(1);
    Term _h_1890 = STK(2);
    Term _h_1891 = STK(3);
    Term _h_1892 = STK(4);
    Term _h_1893 = STK(5);
    Term _h_1894 = STK(6);
    Term _h_1895 = STK(7);
    Term _h_1896 = STK(8);
    Term _h_1897 = STK(9);
    Term _h_1898 = STK(10);
    Term _h_1899 = STK(11);
    Term _h_1900 = STK(12);
    Term _h_1901 = STK(13);
    Term _h_1902 = STK(14);
    Term _h_1903 = STK(15);
    Term _h_1904 = STK(16);
    Term _h_1905 = STK(17);
    Term _h_1906 = STK(18);
    Term _h_1907 = STK(19);
    Term _h_1908 = STK(20);
    Term _h_1909 = STK(21);
    Term _h_1910 = STK(22);
    Term _h_1911 = STK(23);
    Term _h_1912 = STK(24);
    Term _h_1913 = STK(25);
    Term _h_1914 = STK(26);
    Term _h_1915 = STK(27);
    Term _h_1916 = STK(28);
    Term _h_1917 = STK(29);
    Term _h_1918 = STK(30);
    Term _h_1919 = STK(31);
    Term _h_1920 = STK(32);
    Term _h_1887 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _h_1888;
      STK(1) = _h_1889;
      STK(2) = _h_1890;
      STK(3) = _h_1891;
      STK(4) = _h_1892;
      STK(5) = _h_1893;
      STK(6) = _h_1894;
      STK(7) = _h_1895;
      STK(8) = _h_1896;
      STK(9) = _h_1897;
      STK(10) = _h_1898;
      STK(11) = _h_1899;
      STK(12) = _h_1900;
      STK(13) = _h_1901;
      STK(14) = _h_1902;
      STK(15) = _h_1903;
      STK(16) = _h_1904;
      STK(17) = _h_1905;
      STK(18) = _h_1906;
      STK(19) = _h_1907;
      STK(20) = _h_1908;
      STK(21) = _h_1909;
      STK(22) = _h_1910;
      STK(23) = _h_1911;
      STK(24) = _h_1912;
      STK(25) = _h_1913;
      STK(26) = _h_1914;
      STK(27) = _h_1915;
      STK(28) = _h_1916;
      STK(29) = _h_1917;
      STK(30) = _h_1918;
      STK(31) = _h_1919;
      STK(32) = _h_1920;
      STK(33) = _h_1887;
      STK(34) = FID_CONTROLS_K278;
      WL_PUSHN(35);
    } else {
      u64 _t_204 = task_node(e, FID_CONTROLS_K278, WL_CONT, WL_IDX, 1);
      e.mem[_t_204 + 0] = _h_1888;
      e.mem[_t_204 + 1] = _h_1889;
      e.mem[_t_204 + 2] = _h_1890;
      e.mem[_t_204 + 3] = _h_1891;
      e.mem[_t_204 + 4] = _h_1892;
      e.mem[_t_204 + 5] = _h_1893;
      e.mem[_t_204 + 6] = _h_1894;
      e.mem[_t_204 + 7] = _h_1895;
      e.mem[_t_204 + 8] = _h_1896;
      e.mem[_t_204 + 9] = _h_1897;
      e.mem[_t_204 + 10] = _h_1898;
      e.mem[_t_204 + 11] = _h_1899;
      e.mem[_t_204 + 12] = _h_1900;
      e.mem[_t_204 + 13] = _h_1901;
      e.mem[_t_204 + 14] = _h_1902;
      e.mem[_t_204 + 15] = _h_1903;
      e.mem[_t_204 + 16] = _h_1904;
      e.mem[_t_204 + 17] = _h_1905;
      e.mem[_t_204 + 18] = _h_1906;
      e.mem[_t_204 + 19] = _h_1907;
      e.mem[_t_204 + 20] = _h_1908;
      e.mem[_t_204 + 21] = _h_1909;
      e.mem[_t_204 + 22] = _h_1910;
      e.mem[_t_204 + 23] = _h_1911;
      e.mem[_t_204 + 24] = _h_1912;
      e.mem[_t_204 + 25] = _h_1913;
      e.mem[_t_204 + 26] = _h_1914;
      e.mem[_t_204 + 27] = _h_1915;
      e.mem[_t_204 + 28] = _h_1916;
      e.mem[_t_204 + 29] = _h_1917;
      e.mem[_t_204 + 30] = _h_1918;
      e.mem[_t_204 + 31] = _h_1919;
      e.mem[_t_204 + 32] = _h_1920;
      e.mem[_t_204 + 33] = _h_1887;
      WL_CONT = term_tsk(FID_CONTROLS_K278, _t_204);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_205 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_205 + 0] = term_ctr(CID_CON, STAT_OFF + 828);
      e.mem[_t_205 + 1] = 1;
      e.mem[_t_205 + 2] = 4;
      e.mem[_t_205 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_205 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_205 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_205);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 828);
    r1 = 1;
    r2 = 4;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K278)
  {
    WL_POPN(34);
    Term _h_1926 = STK(0);
    Term _h_1927 = STK(1);
    Term _h_1928 = STK(2);
    Term _h_1929 = STK(3);
    Term _h_1930 = STK(4);
    Term _h_1931 = STK(5);
    Term _h_1932 = STK(6);
    Term _h_1933 = STK(7);
    Term _h_1934 = STK(8);
    Term _h_1935 = STK(9);
    Term _h_1936 = STK(10);
    Term _h_1937 = STK(11);
    Term _h_1938 = STK(12);
    Term _h_1939 = STK(13);
    Term _h_1940 = STK(14);
    Term _h_1941 = STK(15);
    Term _h_1942 = STK(16);
    Term _h_1943 = STK(17);
    Term _h_1944 = STK(18);
    Term _h_1945 = STK(19);
    Term _h_1946 = STK(20);
    Term _h_1947 = STK(21);
    Term _h_1948 = STK(22);
    Term _h_1949 = STK(23);
    Term _h_1950 = STK(24);
    Term _h_1951 = STK(25);
    Term _h_1952 = STK(26);
    Term _h_1953 = STK(27);
    Term _h_1954 = STK(28);
    Term _h_1955 = STK(29);
    Term _h_1956 = STK(30);
    Term _h_1957 = STK(31);
    Term _h_1958 = STK(32);
    Term _h_1959 = STK(33);
    u32 _h_1921 = r0;
    u32 _h_1922 = r1;
    u32 _h_1923 = r2;
    Term _h_1924 = r3;
    Term _h_1925 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _h_1926;
      STK(1) = _h_1927;
      STK(2) = _h_1928;
      STK(3) = _h_1929;
      STK(4) = _h_1930;
      STK(5) = _h_1931;
      STK(6) = _h_1932;
      STK(7) = _h_1933;
      STK(8) = _h_1934;
      STK(9) = _h_1935;
      STK(10) = _h_1936;
      STK(11) = _h_1937;
      STK(12) = _h_1938;
      STK(13) = _h_1939;
      STK(14) = _h_1940;
      STK(15) = _h_1941;
      STK(16) = _h_1942;
      STK(17) = _h_1943;
      STK(18) = _h_1944;
      STK(19) = _h_1945;
      STK(20) = _h_1946;
      STK(21) = _h_1947;
      STK(22) = _h_1948;
      STK(23) = _h_1949;
      STK(24) = _h_1950;
      STK(25) = _h_1951;
      STK(26) = _h_1952;
      STK(27) = _h_1953;
      STK(28) = _h_1954;
      STK(29) = _h_1955;
      STK(30) = _h_1956;
      STK(31) = _h_1957;
      STK(32) = _h_1958;
      STK(33) = _h_1959;
      STK(34) = FID_CONTROLS_K279;
      WL_PUSHN(35);
    } else {
      u64 _t_206 = task_node(e, FID_CONTROLS_K279, WL_CONT, WL_IDX, 1);
      e.mem[_t_206 + 0] = _h_1926;
      e.mem[_t_206 + 1] = _h_1927;
      e.mem[_t_206 + 2] = _h_1928;
      e.mem[_t_206 + 3] = _h_1929;
      e.mem[_t_206 + 4] = _h_1930;
      e.mem[_t_206 + 5] = _h_1931;
      e.mem[_t_206 + 6] = _h_1932;
      e.mem[_t_206 + 7] = _h_1933;
      e.mem[_t_206 + 8] = _h_1934;
      e.mem[_t_206 + 9] = _h_1935;
      e.mem[_t_206 + 10] = _h_1936;
      e.mem[_t_206 + 11] = _h_1937;
      e.mem[_t_206 + 12] = _h_1938;
      e.mem[_t_206 + 13] = _h_1939;
      e.mem[_t_206 + 14] = _h_1940;
      e.mem[_t_206 + 15] = _h_1941;
      e.mem[_t_206 + 16] = _h_1942;
      e.mem[_t_206 + 17] = _h_1943;
      e.mem[_t_206 + 18] = _h_1944;
      e.mem[_t_206 + 19] = _h_1945;
      e.mem[_t_206 + 20] = _h_1946;
      e.mem[_t_206 + 21] = _h_1947;
      e.mem[_t_206 + 22] = _h_1948;
      e.mem[_t_206 + 23] = _h_1949;
      e.mem[_t_206 + 24] = _h_1950;
      e.mem[_t_206 + 25] = _h_1951;
      e.mem[_t_206 + 26] = _h_1952;
      e.mem[_t_206 + 27] = _h_1953;
      e.mem[_t_206 + 28] = _h_1954;
      e.mem[_t_206 + 29] = _h_1955;
      e.mem[_t_206 + 30] = _h_1956;
      e.mem[_t_206 + 31] = _h_1957;
      e.mem[_t_206 + 32] = _h_1958;
      e.mem[_t_206 + 33] = _h_1959;
      WL_CONT = term_tsk(FID_CONTROLS_K279, _t_206);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_207 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_207 + 0] = _h_1921;
      e.mem[_t_207 + 1] = _h_1922;
      e.mem[_t_207 + 2] = _h_1923;
      e.mem[_t_207 + 3] = _h_1924;
      e.mem[_t_207 + 4] = _h_1925;
      return term_tsk(FID_VALIDATION, _t_207);
    }
    r0 = _h_1921;
    r1 = _h_1922;
    r2 = _h_1923;
    r3 = _h_1924;
    r4 = _h_1925;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K279)
  {
    WL_POPN(34);
    Term _h_1961 = STK(0);
    Term _h_1962 = STK(1);
    Term _h_1963 = STK(2);
    Term _h_1964 = STK(3);
    Term _h_1965 = STK(4);
    Term _h_1966 = STK(5);
    Term _h_1967 = STK(6);
    Term _h_1968 = STK(7);
    Term _h_1969 = STK(8);
    Term _h_1970 = STK(9);
    Term _h_1971 = STK(10);
    Term _h_1972 = STK(11);
    Term _h_1973 = STK(12);
    Term _h_1974 = STK(13);
    Term _h_1975 = STK(14);
    Term _h_1976 = STK(15);
    Term _h_1977 = STK(16);
    Term _h_1978 = STK(17);
    Term _h_1979 = STK(18);
    Term _h_1980 = STK(19);
    Term _h_1981 = STK(20);
    Term _h_1982 = STK(21);
    Term _h_1983 = STK(22);
    Term _h_1984 = STK(23);
    Term _h_1985 = STK(24);
    Term _h_1986 = STK(25);
    Term _h_1987 = STK(26);
    Term _h_1988 = STK(27);
    Term _h_1989 = STK(28);
    Term _h_1990 = STK(29);
    Term _h_1991 = STK(30);
    Term _h_1992 = STK(31);
    Term _h_1993 = STK(32);
    Term _h_1994 = STK(33);
    Term _h_1960 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(35);
      STK(0) = _h_1961;
      STK(1) = _h_1962;
      STK(2) = _h_1963;
      STK(3) = _h_1964;
      STK(4) = _h_1965;
      STK(5) = _h_1966;
      STK(6) = _h_1967;
      STK(7) = _h_1968;
      STK(8) = _h_1969;
      STK(9) = _h_1970;
      STK(10) = _h_1971;
      STK(11) = _h_1972;
      STK(12) = _h_1973;
      STK(13) = _h_1974;
      STK(14) = _h_1975;
      STK(15) = _h_1976;
      STK(16) = _h_1977;
      STK(17) = _h_1978;
      STK(18) = _h_1979;
      STK(19) = _h_1980;
      STK(20) = _h_1981;
      STK(21) = _h_1982;
      STK(22) = _h_1983;
      STK(23) = _h_1984;
      STK(24) = _h_1985;
      STK(25) = _h_1986;
      STK(26) = _h_1987;
      STK(27) = _h_1988;
      STK(28) = _h_1989;
      STK(29) = _h_1990;
      STK(30) = _h_1991;
      STK(31) = _h_1992;
      STK(32) = _h_1993;
      STK(33) = _h_1994;
      STK(34) = FID_CONTROLS_K280;
      WL_PUSHN(35);
    } else {
      u64 _t_208 = task_node(e, FID_CONTROLS_K280, WL_CONT, WL_IDX, 1);
      e.mem[_t_208 + 0] = _h_1961;
      e.mem[_t_208 + 1] = _h_1962;
      e.mem[_t_208 + 2] = _h_1963;
      e.mem[_t_208 + 3] = _h_1964;
      e.mem[_t_208 + 4] = _h_1965;
      e.mem[_t_208 + 5] = _h_1966;
      e.mem[_t_208 + 6] = _h_1967;
      e.mem[_t_208 + 7] = _h_1968;
      e.mem[_t_208 + 8] = _h_1969;
      e.mem[_t_208 + 9] = _h_1970;
      e.mem[_t_208 + 10] = _h_1971;
      e.mem[_t_208 + 11] = _h_1972;
      e.mem[_t_208 + 12] = _h_1973;
      e.mem[_t_208 + 13] = _h_1974;
      e.mem[_t_208 + 14] = _h_1975;
      e.mem[_t_208 + 15] = _h_1976;
      e.mem[_t_208 + 16] = _h_1977;
      e.mem[_t_208 + 17] = _h_1978;
      e.mem[_t_208 + 18] = _h_1979;
      e.mem[_t_208 + 19] = _h_1980;
      e.mem[_t_208 + 20] = _h_1981;
      e.mem[_t_208 + 21] = _h_1982;
      e.mem[_t_208 + 22] = _h_1983;
      e.mem[_t_208 + 23] = _h_1984;
      e.mem[_t_208 + 24] = _h_1985;
      e.mem[_t_208 + 25] = _h_1986;
      e.mem[_t_208 + 26] = _h_1987;
      e.mem[_t_208 + 27] = _h_1988;
      e.mem[_t_208 + 28] = _h_1989;
      e.mem[_t_208 + 29] = _h_1990;
      e.mem[_t_208 + 30] = _h_1991;
      e.mem[_t_208 + 31] = _h_1992;
      e.mem[_t_208 + 32] = _h_1993;
      e.mem[_t_208 + 33] = _h_1994;
      WL_CONT = term_tsk(FID_CONTROLS_K280, _t_208);
      WL_IDX = 34;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_209 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_209 + 0] = term_ctr(CID_SCON, STAT_OFF + 1214);
      e.mem[_t_209 + 1] = _h_1960;
      return term_tsk(FID_STRING_APPEND, _t_209);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1214);
    r1 = _h_1960;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K280)
  {
    WL_POPN(34);
    Term _h_1996 = STK(0);
    Term _h_1997 = STK(1);
    Term _h_1998 = STK(2);
    Term _h_1999 = STK(3);
    Term _h_2000 = STK(4);
    Term _h_2001 = STK(5);
    Term _h_2002 = STK(6);
    Term _h_2003 = STK(7);
    Term _h_2004 = STK(8);
    Term _h_2005 = STK(9);
    Term _h_2006 = STK(10);
    Term _h_2007 = STK(11);
    Term _h_2008 = STK(12);
    Term _h_2009 = STK(13);
    Term _h_2010 = STK(14);
    Term _h_2011 = STK(15);
    Term _h_2012 = STK(16);
    Term _h_2013 = STK(17);
    Term _h_2014 = STK(18);
    Term _h_2015 = STK(19);
    Term _h_2016 = STK(20);
    Term _h_2017 = STK(21);
    Term _h_2018 = STK(22);
    Term _h_2019 = STK(23);
    Term _h_2020 = STK(24);
    Term _h_2021 = STK(25);
    Term _h_2022 = STK(26);
    Term _h_2023 = STK(27);
    Term _h_2024 = STK(28);
    Term _h_2025 = STK(29);
    Term _h_2026 = STK(30);
    Term _h_2027 = STK(31);
    Term _h_2028 = STK(32);
    Term _h_2029 = STK(33);
    Term _h_1995 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(36);
      STK(0) = _h_1996;
      STK(1) = _h_1997;
      STK(2) = _h_1998;
      STK(3) = _h_1999;
      STK(4) = _h_2000;
      STK(5) = _h_2001;
      STK(6) = _h_2002;
      STK(7) = _h_2003;
      STK(8) = _h_2004;
      STK(9) = _h_2005;
      STK(10) = _h_2006;
      STK(11) = _h_2007;
      STK(12) = _h_2008;
      STK(13) = _h_2009;
      STK(14) = _h_2010;
      STK(15) = _h_2011;
      STK(16) = _h_2012;
      STK(17) = _h_2013;
      STK(18) = _h_2014;
      STK(19) = _h_2015;
      STK(20) = _h_2016;
      STK(21) = _h_2017;
      STK(22) = _h_2018;
      STK(23) = _h_2019;
      STK(24) = _h_2020;
      STK(25) = _h_2021;
      STK(26) = _h_2022;
      STK(27) = _h_2023;
      STK(28) = _h_2024;
      STK(29) = _h_2025;
      STK(30) = _h_2026;
      STK(31) = _h_2027;
      STK(32) = _h_2028;
      STK(33) = _h_2029;
      STK(34) = _h_1995;
      STK(35) = FID_CONTROLS_K281;
      WL_PUSHN(36);
    } else {
      u64 _t_210 = task_node(e, FID_CONTROLS_K281, WL_CONT, WL_IDX, 1);
      e.mem[_t_210 + 0] = _h_1996;
      e.mem[_t_210 + 1] = _h_1997;
      e.mem[_t_210 + 2] = _h_1998;
      e.mem[_t_210 + 3] = _h_1999;
      e.mem[_t_210 + 4] = _h_2000;
      e.mem[_t_210 + 5] = _h_2001;
      e.mem[_t_210 + 6] = _h_2002;
      e.mem[_t_210 + 7] = _h_2003;
      e.mem[_t_210 + 8] = _h_2004;
      e.mem[_t_210 + 9] = _h_2005;
      e.mem[_t_210 + 10] = _h_2006;
      e.mem[_t_210 + 11] = _h_2007;
      e.mem[_t_210 + 12] = _h_2008;
      e.mem[_t_210 + 13] = _h_2009;
      e.mem[_t_210 + 14] = _h_2010;
      e.mem[_t_210 + 15] = _h_2011;
      e.mem[_t_210 + 16] = _h_2012;
      e.mem[_t_210 + 17] = _h_2013;
      e.mem[_t_210 + 18] = _h_2014;
      e.mem[_t_210 + 19] = _h_2015;
      e.mem[_t_210 + 20] = _h_2016;
      e.mem[_t_210 + 21] = _h_2017;
      e.mem[_t_210 + 22] = _h_2018;
      e.mem[_t_210 + 23] = _h_2019;
      e.mem[_t_210 + 24] = _h_2020;
      e.mem[_t_210 + 25] = _h_2021;
      e.mem[_t_210 + 26] = _h_2022;
      e.mem[_t_210 + 27] = _h_2023;
      e.mem[_t_210 + 28] = _h_2024;
      e.mem[_t_210 + 29] = _h_2025;
      e.mem[_t_210 + 30] = _h_2026;
      e.mem[_t_210 + 31] = _h_2027;
      e.mem[_t_210 + 32] = _h_2028;
      e.mem[_t_210 + 33] = _h_2029;
      e.mem[_t_210 + 34] = _h_1995;
      WL_CONT = term_tsk(FID_CONTROLS_K281, _t_210);
      WL_IDX = 35;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0)) {
      u64 _t_211 = task_node(e, FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_211 + 0] = term_ctr(CID_CON, STAT_OFF + 854);
      e.mem[_t_211 + 1] = 1;
      e.mem[_t_211 + 2] = 0;
      e.mem[_t_211 + 3] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_211 + 4] = term_ctr(CID_SCON, STAT_OFF + 146);
      e.mem[_t_211 + 5] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0, _t_211);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 854);
    r1 = 1;
    r2 = 0;
    r3 = term_ctr(CID_SCON, STAT_OFF + 270);
    r4 = term_ctr(CID_SCON, STAT_OFF + 146);
    r5 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_CHECK_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K281)
  {
    WL_POPN(35);
    Term _h_2035 = STK(0);
    Term _h_2036 = STK(1);
    Term _h_2037 = STK(2);
    Term _h_2038 = STK(3);
    Term _h_2039 = STK(4);
    Term _h_2040 = STK(5);
    Term _h_2041 = STK(6);
    Term _h_2042 = STK(7);
    Term _h_2043 = STK(8);
    Term _h_2044 = STK(9);
    Term _h_2045 = STK(10);
    Term _h_2046 = STK(11);
    Term _h_2047 = STK(12);
    Term _h_2048 = STK(13);
    Term _h_2049 = STK(14);
    Term _h_2050 = STK(15);
    Term _h_2051 = STK(16);
    Term _h_2052 = STK(17);
    Term _h_2053 = STK(18);
    Term _h_2054 = STK(19);
    Term _h_2055 = STK(20);
    Term _h_2056 = STK(21);
    Term _h_2057 = STK(22);
    Term _h_2058 = STK(23);
    Term _h_2059 = STK(24);
    Term _h_2060 = STK(25);
    Term _h_2061 = STK(26);
    Term _h_2062 = STK(27);
    Term _h_2063 = STK(28);
    Term _h_2064 = STK(29);
    Term _h_2065 = STK(30);
    Term _h_2066 = STK(31);
    Term _h_2067 = STK(32);
    Term _h_2068 = STK(33);
    Term _h_2069 = STK(34);
    u32 _h_2030 = r0;
    u32 _h_2031 = r1;
    u32 _h_2032 = r2;
    Term _h_2033 = r3;
    Term _h_2034 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(36);
      STK(0) = _h_2035;
      STK(1) = _h_2036;
      STK(2) = _h_2037;
      STK(3) = _h_2038;
      STK(4) = _h_2039;
      STK(5) = _h_2040;
      STK(6) = _h_2041;
      STK(7) = _h_2042;
      STK(8) = _h_2043;
      STK(9) = _h_2044;
      STK(10) = _h_2045;
      STK(11) = _h_2046;
      STK(12) = _h_2047;
      STK(13) = _h_2048;
      STK(14) = _h_2049;
      STK(15) = _h_2050;
      STK(16) = _h_2051;
      STK(17) = _h_2052;
      STK(18) = _h_2053;
      STK(19) = _h_2054;
      STK(20) = _h_2055;
      STK(21) = _h_2056;
      STK(22) = _h_2057;
      STK(23) = _h_2058;
      STK(24) = _h_2059;
      STK(25) = _h_2060;
      STK(26) = _h_2061;
      STK(27) = _h_2062;
      STK(28) = _h_2063;
      STK(29) = _h_2064;
      STK(30) = _h_2065;
      STK(31) = _h_2066;
      STK(32) = _h_2067;
      STK(33) = _h_2068;
      STK(34) = _h_2069;
      STK(35) = FID_CONTROLS_K282;
      WL_PUSHN(36);
    } else {
      u64 _t_212 = task_node(e, FID_CONTROLS_K282, WL_CONT, WL_IDX, 1);
      e.mem[_t_212 + 0] = _h_2035;
      e.mem[_t_212 + 1] = _h_2036;
      e.mem[_t_212 + 2] = _h_2037;
      e.mem[_t_212 + 3] = _h_2038;
      e.mem[_t_212 + 4] = _h_2039;
      e.mem[_t_212 + 5] = _h_2040;
      e.mem[_t_212 + 6] = _h_2041;
      e.mem[_t_212 + 7] = _h_2042;
      e.mem[_t_212 + 8] = _h_2043;
      e.mem[_t_212 + 9] = _h_2044;
      e.mem[_t_212 + 10] = _h_2045;
      e.mem[_t_212 + 11] = _h_2046;
      e.mem[_t_212 + 12] = _h_2047;
      e.mem[_t_212 + 13] = _h_2048;
      e.mem[_t_212 + 14] = _h_2049;
      e.mem[_t_212 + 15] = _h_2050;
      e.mem[_t_212 + 16] = _h_2051;
      e.mem[_t_212 + 17] = _h_2052;
      e.mem[_t_212 + 18] = _h_2053;
      e.mem[_t_212 + 19] = _h_2054;
      e.mem[_t_212 + 20] = _h_2055;
      e.mem[_t_212 + 21] = _h_2056;
      e.mem[_t_212 + 22] = _h_2057;
      e.mem[_t_212 + 23] = _h_2058;
      e.mem[_t_212 + 24] = _h_2059;
      e.mem[_t_212 + 25] = _h_2060;
      e.mem[_t_212 + 26] = _h_2061;
      e.mem[_t_212 + 27] = _h_2062;
      e.mem[_t_212 + 28] = _h_2063;
      e.mem[_t_212 + 29] = _h_2064;
      e.mem[_t_212 + 30] = _h_2065;
      e.mem[_t_212 + 31] = _h_2066;
      e.mem[_t_212 + 32] = _h_2067;
      e.mem[_t_212 + 33] = _h_2068;
      e.mem[_t_212 + 34] = _h_2069;
      WL_CONT = term_tsk(FID_CONTROLS_K282, _t_212);
      WL_IDX = 35;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_213 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_213 + 0] = _h_2030;
      e.mem[_t_213 + 1] = _h_2031;
      e.mem[_t_213 + 2] = _h_2032;
      e.mem[_t_213 + 3] = _h_2033;
      e.mem[_t_213 + 4] = _h_2034;
      return term_tsk(FID_VALIDATION, _t_213);
    }
    r0 = _h_2030;
    r1 = _h_2031;
    r2 = _h_2032;
    r3 = _h_2033;
    r4 = _h_2034;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K282)
  {
    WL_POPN(35);
    Term _h_2071 = STK(0);
    Term _h_2072 = STK(1);
    Term _h_2073 = STK(2);
    Term _h_2074 = STK(3);
    Term _h_2075 = STK(4);
    Term _h_2076 = STK(5);
    Term _h_2077 = STK(6);
    Term _h_2078 = STK(7);
    Term _h_2079 = STK(8);
    Term _h_2080 = STK(9);
    Term _h_2081 = STK(10);
    Term _h_2082 = STK(11);
    Term _h_2083 = STK(12);
    Term _h_2084 = STK(13);
    Term _h_2085 = STK(14);
    Term _h_2086 = STK(15);
    Term _h_2087 = STK(16);
    Term _h_2088 = STK(17);
    Term _h_2089 = STK(18);
    Term _h_2090 = STK(19);
    Term _h_2091 = STK(20);
    Term _h_2092 = STK(21);
    Term _h_2093 = STK(22);
    Term _h_2094 = STK(23);
    Term _h_2095 = STK(24);
    Term _h_2096 = STK(25);
    Term _h_2097 = STK(26);
    Term _h_2098 = STK(27);
    Term _h_2099 = STK(28);
    Term _h_2100 = STK(29);
    Term _h_2101 = STK(30);
    Term _h_2102 = STK(31);
    Term _h_2103 = STK(32);
    Term _h_2104 = STK(33);
    Term _h_2105 = STK(34);
    Term _h_2070 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(36);
      STK(0) = _h_2071;
      STK(1) = _h_2072;
      STK(2) = _h_2073;
      STK(3) = _h_2074;
      STK(4) = _h_2075;
      STK(5) = _h_2076;
      STK(6) = _h_2077;
      STK(7) = _h_2078;
      STK(8) = _h_2079;
      STK(9) = _h_2080;
      STK(10) = _h_2081;
      STK(11) = _h_2082;
      STK(12) = _h_2083;
      STK(13) = _h_2084;
      STK(14) = _h_2085;
      STK(15) = _h_2086;
      STK(16) = _h_2087;
      STK(17) = _h_2088;
      STK(18) = _h_2089;
      STK(19) = _h_2090;
      STK(20) = _h_2091;
      STK(21) = _h_2092;
      STK(22) = _h_2093;
      STK(23) = _h_2094;
      STK(24) = _h_2095;
      STK(25) = _h_2096;
      STK(26) = _h_2097;
      STK(27) = _h_2098;
      STK(28) = _h_2099;
      STK(29) = _h_2100;
      STK(30) = _h_2101;
      STK(31) = _h_2102;
      STK(32) = _h_2103;
      STK(33) = _h_2104;
      STK(34) = _h_2105;
      STK(35) = FID_CONTROLS_K283;
      WL_PUSHN(36);
    } else {
      u64 _t_214 = task_node(e, FID_CONTROLS_K283, WL_CONT, WL_IDX, 1);
      e.mem[_t_214 + 0] = _h_2071;
      e.mem[_t_214 + 1] = _h_2072;
      e.mem[_t_214 + 2] = _h_2073;
      e.mem[_t_214 + 3] = _h_2074;
      e.mem[_t_214 + 4] = _h_2075;
      e.mem[_t_214 + 5] = _h_2076;
      e.mem[_t_214 + 6] = _h_2077;
      e.mem[_t_214 + 7] = _h_2078;
      e.mem[_t_214 + 8] = _h_2079;
      e.mem[_t_214 + 9] = _h_2080;
      e.mem[_t_214 + 10] = _h_2081;
      e.mem[_t_214 + 11] = _h_2082;
      e.mem[_t_214 + 12] = _h_2083;
      e.mem[_t_214 + 13] = _h_2084;
      e.mem[_t_214 + 14] = _h_2085;
      e.mem[_t_214 + 15] = _h_2086;
      e.mem[_t_214 + 16] = _h_2087;
      e.mem[_t_214 + 17] = _h_2088;
      e.mem[_t_214 + 18] = _h_2089;
      e.mem[_t_214 + 19] = _h_2090;
      e.mem[_t_214 + 20] = _h_2091;
      e.mem[_t_214 + 21] = _h_2092;
      e.mem[_t_214 + 22] = _h_2093;
      e.mem[_t_214 + 23] = _h_2094;
      e.mem[_t_214 + 24] = _h_2095;
      e.mem[_t_214 + 25] = _h_2096;
      e.mem[_t_214 + 26] = _h_2097;
      e.mem[_t_214 + 27] = _h_2098;
      e.mem[_t_214 + 28] = _h_2099;
      e.mem[_t_214 + 29] = _h_2100;
      e.mem[_t_214 + 30] = _h_2101;
      e.mem[_t_214 + 31] = _h_2102;
      e.mem[_t_214 + 32] = _h_2103;
      e.mem[_t_214 + 33] = _h_2104;
      e.mem[_t_214 + 34] = _h_2105;
      WL_CONT = term_tsk(FID_CONTROLS_K283, _t_214);
      WL_IDX = 35;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_215 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_215 + 0] = term_ctr(CID_SCON, STAT_OFF + 1234);
      e.mem[_t_215 + 1] = _h_2070;
      return term_tsk(FID_STRING_APPEND, _t_215);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1234);
    r1 = _h_2070;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K283)
  {
    WL_POPN(35);
    Term _h_2107 = STK(0);
    Term _h_2108 = STK(1);
    Term _h_2109 = STK(2);
    Term _h_2110 = STK(3);
    Term _h_2111 = STK(4);
    Term _h_2112 = STK(5);
    Term _h_2113 = STK(6);
    Term _h_2114 = STK(7);
    Term _h_2115 = STK(8);
    Term _h_2116 = STK(9);
    Term _h_2117 = STK(10);
    Term _h_2118 = STK(11);
    Term _h_2119 = STK(12);
    Term _h_2120 = STK(13);
    Term _h_2121 = STK(14);
    Term _h_2122 = STK(15);
    Term _h_2123 = STK(16);
    Term _h_2124 = STK(17);
    Term _h_2125 = STK(18);
    Term _h_2126 = STK(19);
    Term _h_2127 = STK(20);
    Term _h_2128 = STK(21);
    Term _h_2129 = STK(22);
    Term _h_2130 = STK(23);
    Term _h_2131 = STK(24);
    Term _h_2132 = STK(25);
    Term _h_2133 = STK(26);
    Term _h_2134 = STK(27);
    Term _h_2135 = STK(28);
    Term _h_2136 = STK(29);
    Term _h_2137 = STK(30);
    Term _h_2138 = STK(31);
    Term _h_2139 = STK(32);
    Term _h_2140 = STK(33);
    Term _h_2141 = STK(34);
    Term _h_2106 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(37);
      STK(0) = _h_2107;
      STK(1) = _h_2108;
      STK(2) = _h_2109;
      STK(3) = _h_2110;
      STK(4) = _h_2111;
      STK(5) = _h_2112;
      STK(6) = _h_2113;
      STK(7) = _h_2114;
      STK(8) = _h_2115;
      STK(9) = _h_2116;
      STK(10) = _h_2117;
      STK(11) = _h_2118;
      STK(12) = _h_2119;
      STK(13) = _h_2120;
      STK(14) = _h_2121;
      STK(15) = _h_2122;
      STK(16) = _h_2123;
      STK(17) = _h_2124;
      STK(18) = _h_2125;
      STK(19) = _h_2126;
      STK(20) = _h_2127;
      STK(21) = _h_2128;
      STK(22) = _h_2129;
      STK(23) = _h_2130;
      STK(24) = _h_2131;
      STK(25) = _h_2132;
      STK(26) = _h_2133;
      STK(27) = _h_2134;
      STK(28) = _h_2135;
      STK(29) = _h_2136;
      STK(30) = _h_2137;
      STK(31) = _h_2138;
      STK(32) = _h_2139;
      STK(33) = _h_2140;
      STK(34) = _h_2141;
      STK(35) = _h_2106;
      STK(36) = FID_CONTROLS_K284;
      WL_PUSHN(37);
    } else {
      u64 _t_216 = task_node(e, FID_CONTROLS_K284, WL_CONT, WL_IDX, 1);
      e.mem[_t_216 + 0] = _h_2107;
      e.mem[_t_216 + 1] = _h_2108;
      e.mem[_t_216 + 2] = _h_2109;
      e.mem[_t_216 + 3] = _h_2110;
      e.mem[_t_216 + 4] = _h_2111;
      e.mem[_t_216 + 5] = _h_2112;
      e.mem[_t_216 + 6] = _h_2113;
      e.mem[_t_216 + 7] = _h_2114;
      e.mem[_t_216 + 8] = _h_2115;
      e.mem[_t_216 + 9] = _h_2116;
      e.mem[_t_216 + 10] = _h_2117;
      e.mem[_t_216 + 11] = _h_2118;
      e.mem[_t_216 + 12] = _h_2119;
      e.mem[_t_216 + 13] = _h_2120;
      e.mem[_t_216 + 14] = _h_2121;
      e.mem[_t_216 + 15] = _h_2122;
      e.mem[_t_216 + 16] = _h_2123;
      e.mem[_t_216 + 17] = _h_2124;
      e.mem[_t_216 + 18] = _h_2125;
      e.mem[_t_216 + 19] = _h_2126;
      e.mem[_t_216 + 20] = _h_2127;
      e.mem[_t_216 + 21] = _h_2128;
      e.mem[_t_216 + 22] = _h_2129;
      e.mem[_t_216 + 23] = _h_2130;
      e.mem[_t_216 + 24] = _h_2131;
      e.mem[_t_216 + 25] = _h_2132;
      e.mem[_t_216 + 26] = _h_2133;
      e.mem[_t_216 + 27] = _h_2134;
      e.mem[_t_216 + 28] = _h_2135;
      e.mem[_t_216 + 29] = _h_2136;
      e.mem[_t_216 + 30] = _h_2137;
      e.mem[_t_216 + 31] = _h_2138;
      e.mem[_t_216 + 32] = _h_2139;
      e.mem[_t_216 + 33] = _h_2140;
      e.mem[_t_216 + 34] = _h_2141;
      e.mem[_t_216 + 35] = _h_2106;
      WL_CONT = term_tsk(FID_CONTROLS_K284, _t_216);
      WL_IDX = 36;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_217 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_217 + 0] = term_pak(CID_NIL, 0);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_217);
    }
    r0 = term_pak(CID_NIL, 0);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K284)
  {
    WL_POPN(36);
    Term _h_2147 = STK(0);
    Term _h_2148 = STK(1);
    Term _h_2149 = STK(2);
    Term _h_2150 = STK(3);
    Term _h_2151 = STK(4);
    Term _h_2152 = STK(5);
    Term _h_2153 = STK(6);
    Term _h_2154 = STK(7);
    Term _h_2155 = STK(8);
    Term _h_2156 = STK(9);
    Term _h_2157 = STK(10);
    Term _h_2158 = STK(11);
    Term _h_2159 = STK(12);
    Term _h_2160 = STK(13);
    Term _h_2161 = STK(14);
    Term _h_2162 = STK(15);
    Term _h_2163 = STK(16);
    Term _h_2164 = STK(17);
    Term _h_2165 = STK(18);
    Term _h_2166 = STK(19);
    Term _h_2167 = STK(20);
    Term _h_2168 = STK(21);
    Term _h_2169 = STK(22);
    Term _h_2170 = STK(23);
    Term _h_2171 = STK(24);
    Term _h_2172 = STK(25);
    Term _h_2173 = STK(26);
    Term _h_2174 = STK(27);
    Term _h_2175 = STK(28);
    Term _h_2176 = STK(29);
    Term _h_2177 = STK(30);
    Term _h_2178 = STK(31);
    Term _h_2179 = STK(32);
    Term _h_2180 = STK(33);
    Term _h_2181 = STK(34);
    Term _h_2182 = STK(35);
    u32 _h_2142 = r0;
    u32 _h_2143 = r1;
    u32 _h_2144 = r2;
    Term _h_2145 = r3;
    Term _h_2146 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(37);
      STK(0) = _h_2147;
      STK(1) = _h_2148;
      STK(2) = _h_2149;
      STK(3) = _h_2150;
      STK(4) = _h_2151;
      STK(5) = _h_2152;
      STK(6) = _h_2153;
      STK(7) = _h_2154;
      STK(8) = _h_2155;
      STK(9) = _h_2156;
      STK(10) = _h_2157;
      STK(11) = _h_2158;
      STK(12) = _h_2159;
      STK(13) = _h_2160;
      STK(14) = _h_2161;
      STK(15) = _h_2162;
      STK(16) = _h_2163;
      STK(17) = _h_2164;
      STK(18) = _h_2165;
      STK(19) = _h_2166;
      STK(20) = _h_2167;
      STK(21) = _h_2168;
      STK(22) = _h_2169;
      STK(23) = _h_2170;
      STK(24) = _h_2171;
      STK(25) = _h_2172;
      STK(26) = _h_2173;
      STK(27) = _h_2174;
      STK(28) = _h_2175;
      STK(29) = _h_2176;
      STK(30) = _h_2177;
      STK(31) = _h_2178;
      STK(32) = _h_2179;
      STK(33) = _h_2180;
      STK(34) = _h_2181;
      STK(35) = _h_2182;
      STK(36) = FID_CONTROLS_K285;
      WL_PUSHN(37);
    } else {
      u64 _t_218 = task_node(e, FID_CONTROLS_K285, WL_CONT, WL_IDX, 1);
      e.mem[_t_218 + 0] = _h_2147;
      e.mem[_t_218 + 1] = _h_2148;
      e.mem[_t_218 + 2] = _h_2149;
      e.mem[_t_218 + 3] = _h_2150;
      e.mem[_t_218 + 4] = _h_2151;
      e.mem[_t_218 + 5] = _h_2152;
      e.mem[_t_218 + 6] = _h_2153;
      e.mem[_t_218 + 7] = _h_2154;
      e.mem[_t_218 + 8] = _h_2155;
      e.mem[_t_218 + 9] = _h_2156;
      e.mem[_t_218 + 10] = _h_2157;
      e.mem[_t_218 + 11] = _h_2158;
      e.mem[_t_218 + 12] = _h_2159;
      e.mem[_t_218 + 13] = _h_2160;
      e.mem[_t_218 + 14] = _h_2161;
      e.mem[_t_218 + 15] = _h_2162;
      e.mem[_t_218 + 16] = _h_2163;
      e.mem[_t_218 + 17] = _h_2164;
      e.mem[_t_218 + 18] = _h_2165;
      e.mem[_t_218 + 19] = _h_2166;
      e.mem[_t_218 + 20] = _h_2167;
      e.mem[_t_218 + 21] = _h_2168;
      e.mem[_t_218 + 22] = _h_2169;
      e.mem[_t_218 + 23] = _h_2170;
      e.mem[_t_218 + 24] = _h_2171;
      e.mem[_t_218 + 25] = _h_2172;
      e.mem[_t_218 + 26] = _h_2173;
      e.mem[_t_218 + 27] = _h_2174;
      e.mem[_t_218 + 28] = _h_2175;
      e.mem[_t_218 + 29] = _h_2176;
      e.mem[_t_218 + 30] = _h_2177;
      e.mem[_t_218 + 31] = _h_2178;
      e.mem[_t_218 + 32] = _h_2179;
      e.mem[_t_218 + 33] = _h_2180;
      e.mem[_t_218 + 34] = _h_2181;
      e.mem[_t_218 + 35] = _h_2182;
      WL_CONT = term_tsk(FID_CONTROLS_K285, _t_218);
      WL_IDX = 36;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_219 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_219 + 0] = _h_2142;
      e.mem[_t_219 + 1] = _h_2143;
      e.mem[_t_219 + 2] = _h_2144;
      e.mem[_t_219 + 3] = _h_2145;
      e.mem[_t_219 + 4] = _h_2146;
      return term_tsk(FID_VALIDATION, _t_219);
    }
    r0 = _h_2142;
    r1 = _h_2143;
    r2 = _h_2144;
    r3 = _h_2145;
    r4 = _h_2146;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K285)
  {
    WL_POPN(36);
    Term _h_2184 = STK(0);
    Term _h_2185 = STK(1);
    Term _h_2186 = STK(2);
    Term _h_2187 = STK(3);
    Term _h_2188 = STK(4);
    Term _h_2189 = STK(5);
    Term _h_2190 = STK(6);
    Term _h_2191 = STK(7);
    Term _h_2192 = STK(8);
    Term _h_2193 = STK(9);
    Term _h_2194 = STK(10);
    Term _h_2195 = STK(11);
    Term _h_2196 = STK(12);
    Term _h_2197 = STK(13);
    Term _h_2198 = STK(14);
    Term _h_2199 = STK(15);
    Term _h_2200 = STK(16);
    Term _h_2201 = STK(17);
    Term _h_2202 = STK(18);
    Term _h_2203 = STK(19);
    Term _h_2204 = STK(20);
    Term _h_2205 = STK(21);
    Term _h_2206 = STK(22);
    Term _h_2207 = STK(23);
    Term _h_2208 = STK(24);
    Term _h_2209 = STK(25);
    Term _h_2210 = STK(26);
    Term _h_2211 = STK(27);
    Term _h_2212 = STK(28);
    Term _h_2213 = STK(29);
    Term _h_2214 = STK(30);
    Term _h_2215 = STK(31);
    Term _h_2216 = STK(32);
    Term _h_2217 = STK(33);
    Term _h_2218 = STK(34);
    Term _h_2219 = STK(35);
    Term _h_2183 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(37);
      STK(0) = _h_2184;
      STK(1) = _h_2185;
      STK(2) = _h_2186;
      STK(3) = _h_2187;
      STK(4) = _h_2188;
      STK(5) = _h_2189;
      STK(6) = _h_2190;
      STK(7) = _h_2191;
      STK(8) = _h_2192;
      STK(9) = _h_2193;
      STK(10) = _h_2194;
      STK(11) = _h_2195;
      STK(12) = _h_2196;
      STK(13) = _h_2197;
      STK(14) = _h_2198;
      STK(15) = _h_2199;
      STK(16) = _h_2200;
      STK(17) = _h_2201;
      STK(18) = _h_2202;
      STK(19) = _h_2203;
      STK(20) = _h_2204;
      STK(21) = _h_2205;
      STK(22) = _h_2206;
      STK(23) = _h_2207;
      STK(24) = _h_2208;
      STK(25) = _h_2209;
      STK(26) = _h_2210;
      STK(27) = _h_2211;
      STK(28) = _h_2212;
      STK(29) = _h_2213;
      STK(30) = _h_2214;
      STK(31) = _h_2215;
      STK(32) = _h_2216;
      STK(33) = _h_2217;
      STK(34) = _h_2218;
      STK(35) = _h_2219;
      STK(36) = FID_CONTROLS_K286;
      WL_PUSHN(37);
    } else {
      u64 _t_220 = task_node(e, FID_CONTROLS_K286, WL_CONT, WL_IDX, 1);
      e.mem[_t_220 + 0] = _h_2184;
      e.mem[_t_220 + 1] = _h_2185;
      e.mem[_t_220 + 2] = _h_2186;
      e.mem[_t_220 + 3] = _h_2187;
      e.mem[_t_220 + 4] = _h_2188;
      e.mem[_t_220 + 5] = _h_2189;
      e.mem[_t_220 + 6] = _h_2190;
      e.mem[_t_220 + 7] = _h_2191;
      e.mem[_t_220 + 8] = _h_2192;
      e.mem[_t_220 + 9] = _h_2193;
      e.mem[_t_220 + 10] = _h_2194;
      e.mem[_t_220 + 11] = _h_2195;
      e.mem[_t_220 + 12] = _h_2196;
      e.mem[_t_220 + 13] = _h_2197;
      e.mem[_t_220 + 14] = _h_2198;
      e.mem[_t_220 + 15] = _h_2199;
      e.mem[_t_220 + 16] = _h_2200;
      e.mem[_t_220 + 17] = _h_2201;
      e.mem[_t_220 + 18] = _h_2202;
      e.mem[_t_220 + 19] = _h_2203;
      e.mem[_t_220 + 20] = _h_2204;
      e.mem[_t_220 + 21] = _h_2205;
      e.mem[_t_220 + 22] = _h_2206;
      e.mem[_t_220 + 23] = _h_2207;
      e.mem[_t_220 + 24] = _h_2208;
      e.mem[_t_220 + 25] = _h_2209;
      e.mem[_t_220 + 26] = _h_2210;
      e.mem[_t_220 + 27] = _h_2211;
      e.mem[_t_220 + 28] = _h_2212;
      e.mem[_t_220 + 29] = _h_2213;
      e.mem[_t_220 + 30] = _h_2214;
      e.mem[_t_220 + 31] = _h_2215;
      e.mem[_t_220 + 32] = _h_2216;
      e.mem[_t_220 + 33] = _h_2217;
      e.mem[_t_220 + 34] = _h_2218;
      e.mem[_t_220 + 35] = _h_2219;
      WL_CONT = term_tsk(FID_CONTROLS_K286, _t_220);
      WL_IDX = 36;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_221 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_221 + 0] = term_ctr(CID_SCON, STAT_OFF + 1270);
      e.mem[_t_221 + 1] = _h_2183;
      return term_tsk(FID_STRING_APPEND, _t_221);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1270);
    r1 = _h_2183;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K286)
  {
    WL_POPN(36);
    Term _h_2221 = STK(0);
    Term _h_2222 = STK(1);
    Term _h_2223 = STK(2);
    Term _h_2224 = STK(3);
    Term _h_2225 = STK(4);
    Term _h_2226 = STK(5);
    Term _h_2227 = STK(6);
    Term _h_2228 = STK(7);
    Term _h_2229 = STK(8);
    Term _h_2230 = STK(9);
    Term _h_2231 = STK(10);
    Term _h_2232 = STK(11);
    Term _h_2233 = STK(12);
    Term _h_2234 = STK(13);
    Term _h_2235 = STK(14);
    Term _h_2236 = STK(15);
    Term _h_2237 = STK(16);
    Term _h_2238 = STK(17);
    Term _h_2239 = STK(18);
    Term _h_2240 = STK(19);
    Term _h_2241 = STK(20);
    Term _h_2242 = STK(21);
    Term _h_2243 = STK(22);
    Term _h_2244 = STK(23);
    Term _h_2245 = STK(24);
    Term _h_2246 = STK(25);
    Term _h_2247 = STK(26);
    Term _h_2248 = STK(27);
    Term _h_2249 = STK(28);
    Term _h_2250 = STK(29);
    Term _h_2251 = STK(30);
    Term _h_2252 = STK(31);
    Term _h_2253 = STK(32);
    Term _h_2254 = STK(33);
    Term _h_2255 = STK(34);
    Term _h_2256 = STK(35);
    Term _h_2220 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(38);
      STK(0) = _h_2221;
      STK(1) = _h_2222;
      STK(2) = _h_2223;
      STK(3) = _h_2224;
      STK(4) = _h_2225;
      STK(5) = _h_2226;
      STK(6) = _h_2227;
      STK(7) = _h_2228;
      STK(8) = _h_2229;
      STK(9) = _h_2230;
      STK(10) = _h_2231;
      STK(11) = _h_2232;
      STK(12) = _h_2233;
      STK(13) = _h_2234;
      STK(14) = _h_2235;
      STK(15) = _h_2236;
      STK(16) = _h_2237;
      STK(17) = _h_2238;
      STK(18) = _h_2239;
      STK(19) = _h_2240;
      STK(20) = _h_2241;
      STK(21) = _h_2242;
      STK(22) = _h_2243;
      STK(23) = _h_2244;
      STK(24) = _h_2245;
      STK(25) = _h_2246;
      STK(26) = _h_2247;
      STK(27) = _h_2248;
      STK(28) = _h_2249;
      STK(29) = _h_2250;
      STK(30) = _h_2251;
      STK(31) = _h_2252;
      STK(32) = _h_2253;
      STK(33) = _h_2254;
      STK(34) = _h_2255;
      STK(35) = _h_2256;
      STK(36) = _h_2220;
      STK(37) = FID_CONTROLS_K287;
      WL_PUSHN(38);
    } else {
      u64 _t_222 = task_node(e, FID_CONTROLS_K287, WL_CONT, WL_IDX, 1);
      e.mem[_t_222 + 0] = _h_2221;
      e.mem[_t_222 + 1] = _h_2222;
      e.mem[_t_222 + 2] = _h_2223;
      e.mem[_t_222 + 3] = _h_2224;
      e.mem[_t_222 + 4] = _h_2225;
      e.mem[_t_222 + 5] = _h_2226;
      e.mem[_t_222 + 6] = _h_2227;
      e.mem[_t_222 + 7] = _h_2228;
      e.mem[_t_222 + 8] = _h_2229;
      e.mem[_t_222 + 9] = _h_2230;
      e.mem[_t_222 + 10] = _h_2231;
      e.mem[_t_222 + 11] = _h_2232;
      e.mem[_t_222 + 12] = _h_2233;
      e.mem[_t_222 + 13] = _h_2234;
      e.mem[_t_222 + 14] = _h_2235;
      e.mem[_t_222 + 15] = _h_2236;
      e.mem[_t_222 + 16] = _h_2237;
      e.mem[_t_222 + 17] = _h_2238;
      e.mem[_t_222 + 18] = _h_2239;
      e.mem[_t_222 + 19] = _h_2240;
      e.mem[_t_222 + 20] = _h_2241;
      e.mem[_t_222 + 21] = _h_2242;
      e.mem[_t_222 + 22] = _h_2243;
      e.mem[_t_222 + 23] = _h_2244;
      e.mem[_t_222 + 24] = _h_2245;
      e.mem[_t_222 + 25] = _h_2246;
      e.mem[_t_222 + 26] = _h_2247;
      e.mem[_t_222 + 27] = _h_2248;
      e.mem[_t_222 + 28] = _h_2249;
      e.mem[_t_222 + 29] = _h_2250;
      e.mem[_t_222 + 30] = _h_2251;
      e.mem[_t_222 + 31] = _h_2252;
      e.mem[_t_222 + 32] = _h_2253;
      e.mem[_t_222 + 33] = _h_2254;
      e.mem[_t_222 + 34] = _h_2255;
      e.mem[_t_222 + 35] = _h_2256;
      e.mem[_t_222 + 36] = _h_2220;
      WL_CONT = term_tsk(FID_CONTROLS_K287, _t_222);
      WL_IDX = 37;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_223 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_223 + 0] = term_ctr(CID_CON, STAT_OFF + 1274);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_223);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 1274);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K287)
  {
    WL_POPN(37);
    Term _h_2262 = STK(0);
    Term _h_2263 = STK(1);
    Term _h_2264 = STK(2);
    Term _h_2265 = STK(3);
    Term _h_2266 = STK(4);
    Term _h_2267 = STK(5);
    Term _h_2268 = STK(6);
    Term _h_2269 = STK(7);
    Term _h_2270 = STK(8);
    Term _h_2271 = STK(9);
    Term _h_2272 = STK(10);
    Term _h_2273 = STK(11);
    Term _h_2274 = STK(12);
    Term _h_2275 = STK(13);
    Term _h_2276 = STK(14);
    Term _h_2277 = STK(15);
    Term _h_2278 = STK(16);
    Term _h_2279 = STK(17);
    Term _h_2280 = STK(18);
    Term _h_2281 = STK(19);
    Term _h_2282 = STK(20);
    Term _h_2283 = STK(21);
    Term _h_2284 = STK(22);
    Term _h_2285 = STK(23);
    Term _h_2286 = STK(24);
    Term _h_2287 = STK(25);
    Term _h_2288 = STK(26);
    Term _h_2289 = STK(27);
    Term _h_2290 = STK(28);
    Term _h_2291 = STK(29);
    Term _h_2292 = STK(30);
    Term _h_2293 = STK(31);
    Term _h_2294 = STK(32);
    Term _h_2295 = STK(33);
    Term _h_2296 = STK(34);
    Term _h_2297 = STK(35);
    Term _h_2298 = STK(36);
    u32 _h_2257 = r0;
    u32 _h_2258 = r1;
    u32 _h_2259 = r2;
    Term _h_2260 = r3;
    Term _h_2261 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(38);
      STK(0) = _h_2262;
      STK(1) = _h_2263;
      STK(2) = _h_2264;
      STK(3) = _h_2265;
      STK(4) = _h_2266;
      STK(5) = _h_2267;
      STK(6) = _h_2268;
      STK(7) = _h_2269;
      STK(8) = _h_2270;
      STK(9) = _h_2271;
      STK(10) = _h_2272;
      STK(11) = _h_2273;
      STK(12) = _h_2274;
      STK(13) = _h_2275;
      STK(14) = _h_2276;
      STK(15) = _h_2277;
      STK(16) = _h_2278;
      STK(17) = _h_2279;
      STK(18) = _h_2280;
      STK(19) = _h_2281;
      STK(20) = _h_2282;
      STK(21) = _h_2283;
      STK(22) = _h_2284;
      STK(23) = _h_2285;
      STK(24) = _h_2286;
      STK(25) = _h_2287;
      STK(26) = _h_2288;
      STK(27) = _h_2289;
      STK(28) = _h_2290;
      STK(29) = _h_2291;
      STK(30) = _h_2292;
      STK(31) = _h_2293;
      STK(32) = _h_2294;
      STK(33) = _h_2295;
      STK(34) = _h_2296;
      STK(35) = _h_2297;
      STK(36) = _h_2298;
      STK(37) = FID_CONTROLS_K288;
      WL_PUSHN(38);
    } else {
      u64 _t_224 = task_node(e, FID_CONTROLS_K288, WL_CONT, WL_IDX, 1);
      e.mem[_t_224 + 0] = _h_2262;
      e.mem[_t_224 + 1] = _h_2263;
      e.mem[_t_224 + 2] = _h_2264;
      e.mem[_t_224 + 3] = _h_2265;
      e.mem[_t_224 + 4] = _h_2266;
      e.mem[_t_224 + 5] = _h_2267;
      e.mem[_t_224 + 6] = _h_2268;
      e.mem[_t_224 + 7] = _h_2269;
      e.mem[_t_224 + 8] = _h_2270;
      e.mem[_t_224 + 9] = _h_2271;
      e.mem[_t_224 + 10] = _h_2272;
      e.mem[_t_224 + 11] = _h_2273;
      e.mem[_t_224 + 12] = _h_2274;
      e.mem[_t_224 + 13] = _h_2275;
      e.mem[_t_224 + 14] = _h_2276;
      e.mem[_t_224 + 15] = _h_2277;
      e.mem[_t_224 + 16] = _h_2278;
      e.mem[_t_224 + 17] = _h_2279;
      e.mem[_t_224 + 18] = _h_2280;
      e.mem[_t_224 + 19] = _h_2281;
      e.mem[_t_224 + 20] = _h_2282;
      e.mem[_t_224 + 21] = _h_2283;
      e.mem[_t_224 + 22] = _h_2284;
      e.mem[_t_224 + 23] = _h_2285;
      e.mem[_t_224 + 24] = _h_2286;
      e.mem[_t_224 + 25] = _h_2287;
      e.mem[_t_224 + 26] = _h_2288;
      e.mem[_t_224 + 27] = _h_2289;
      e.mem[_t_224 + 28] = _h_2290;
      e.mem[_t_224 + 29] = _h_2291;
      e.mem[_t_224 + 30] = _h_2292;
      e.mem[_t_224 + 31] = _h_2293;
      e.mem[_t_224 + 32] = _h_2294;
      e.mem[_t_224 + 33] = _h_2295;
      e.mem[_t_224 + 34] = _h_2296;
      e.mem[_t_224 + 35] = _h_2297;
      e.mem[_t_224 + 36] = _h_2298;
      WL_CONT = term_tsk(FID_CONTROLS_K288, _t_224);
      WL_IDX = 37;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_225 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_225 + 0] = _h_2257;
      e.mem[_t_225 + 1] = _h_2258;
      e.mem[_t_225 + 2] = _h_2259;
      e.mem[_t_225 + 3] = _h_2260;
      e.mem[_t_225 + 4] = _h_2261;
      return term_tsk(FID_VALIDATION, _t_225);
    }
    r0 = _h_2257;
    r1 = _h_2258;
    r2 = _h_2259;
    r3 = _h_2260;
    r4 = _h_2261;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K288)
  {
    WL_POPN(37);
    Term _h_2300 = STK(0);
    Term _h_2301 = STK(1);
    Term _h_2302 = STK(2);
    Term _h_2303 = STK(3);
    Term _h_2304 = STK(4);
    Term _h_2305 = STK(5);
    Term _h_2306 = STK(6);
    Term _h_2307 = STK(7);
    Term _h_2308 = STK(8);
    Term _h_2309 = STK(9);
    Term _h_2310 = STK(10);
    Term _h_2311 = STK(11);
    Term _h_2312 = STK(12);
    Term _h_2313 = STK(13);
    Term _h_2314 = STK(14);
    Term _h_2315 = STK(15);
    Term _h_2316 = STK(16);
    Term _h_2317 = STK(17);
    Term _h_2318 = STK(18);
    Term _h_2319 = STK(19);
    Term _h_2320 = STK(20);
    Term _h_2321 = STK(21);
    Term _h_2322 = STK(22);
    Term _h_2323 = STK(23);
    Term _h_2324 = STK(24);
    Term _h_2325 = STK(25);
    Term _h_2326 = STK(26);
    Term _h_2327 = STK(27);
    Term _h_2328 = STK(28);
    Term _h_2329 = STK(29);
    Term _h_2330 = STK(30);
    Term _h_2331 = STK(31);
    Term _h_2332 = STK(32);
    Term _h_2333 = STK(33);
    Term _h_2334 = STK(34);
    Term _h_2335 = STK(35);
    Term _h_2336 = STK(36);
    Term _h_2299 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(38);
      STK(0) = _h_2300;
      STK(1) = _h_2301;
      STK(2) = _h_2302;
      STK(3) = _h_2303;
      STK(4) = _h_2304;
      STK(5) = _h_2305;
      STK(6) = _h_2306;
      STK(7) = _h_2307;
      STK(8) = _h_2308;
      STK(9) = _h_2309;
      STK(10) = _h_2310;
      STK(11) = _h_2311;
      STK(12) = _h_2312;
      STK(13) = _h_2313;
      STK(14) = _h_2314;
      STK(15) = _h_2315;
      STK(16) = _h_2316;
      STK(17) = _h_2317;
      STK(18) = _h_2318;
      STK(19) = _h_2319;
      STK(20) = _h_2320;
      STK(21) = _h_2321;
      STK(22) = _h_2322;
      STK(23) = _h_2323;
      STK(24) = _h_2324;
      STK(25) = _h_2325;
      STK(26) = _h_2326;
      STK(27) = _h_2327;
      STK(28) = _h_2328;
      STK(29) = _h_2329;
      STK(30) = _h_2330;
      STK(31) = _h_2331;
      STK(32) = _h_2332;
      STK(33) = _h_2333;
      STK(34) = _h_2334;
      STK(35) = _h_2335;
      STK(36) = _h_2336;
      STK(37) = FID_CONTROLS_K289;
      WL_PUSHN(38);
    } else {
      u64 _t_226 = task_node(e, FID_CONTROLS_K289, WL_CONT, WL_IDX, 1);
      e.mem[_t_226 + 0] = _h_2300;
      e.mem[_t_226 + 1] = _h_2301;
      e.mem[_t_226 + 2] = _h_2302;
      e.mem[_t_226 + 3] = _h_2303;
      e.mem[_t_226 + 4] = _h_2304;
      e.mem[_t_226 + 5] = _h_2305;
      e.mem[_t_226 + 6] = _h_2306;
      e.mem[_t_226 + 7] = _h_2307;
      e.mem[_t_226 + 8] = _h_2308;
      e.mem[_t_226 + 9] = _h_2309;
      e.mem[_t_226 + 10] = _h_2310;
      e.mem[_t_226 + 11] = _h_2311;
      e.mem[_t_226 + 12] = _h_2312;
      e.mem[_t_226 + 13] = _h_2313;
      e.mem[_t_226 + 14] = _h_2314;
      e.mem[_t_226 + 15] = _h_2315;
      e.mem[_t_226 + 16] = _h_2316;
      e.mem[_t_226 + 17] = _h_2317;
      e.mem[_t_226 + 18] = _h_2318;
      e.mem[_t_226 + 19] = _h_2319;
      e.mem[_t_226 + 20] = _h_2320;
      e.mem[_t_226 + 21] = _h_2321;
      e.mem[_t_226 + 22] = _h_2322;
      e.mem[_t_226 + 23] = _h_2323;
      e.mem[_t_226 + 24] = _h_2324;
      e.mem[_t_226 + 25] = _h_2325;
      e.mem[_t_226 + 26] = _h_2326;
      e.mem[_t_226 + 27] = _h_2327;
      e.mem[_t_226 + 28] = _h_2328;
      e.mem[_t_226 + 29] = _h_2329;
      e.mem[_t_226 + 30] = _h_2330;
      e.mem[_t_226 + 31] = _h_2331;
      e.mem[_t_226 + 32] = _h_2332;
      e.mem[_t_226 + 33] = _h_2333;
      e.mem[_t_226 + 34] = _h_2334;
      e.mem[_t_226 + 35] = _h_2335;
      e.mem[_t_226 + 36] = _h_2336;
      WL_CONT = term_tsk(FID_CONTROLS_K289, _t_226);
      WL_IDX = 37;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_227 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_227 + 0] = term_ctr(CID_SCON, STAT_OFF + 1302);
      e.mem[_t_227 + 1] = _h_2299;
      return term_tsk(FID_STRING_APPEND, _t_227);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1302);
    r1 = _h_2299;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K289)
  {
    WL_POPN(37);
    Term _h_2338 = STK(0);
    Term _h_2339 = STK(1);
    Term _h_2340 = STK(2);
    Term _h_2341 = STK(3);
    Term _h_2342 = STK(4);
    Term _h_2343 = STK(5);
    Term _h_2344 = STK(6);
    Term _h_2345 = STK(7);
    Term _h_2346 = STK(8);
    Term _h_2347 = STK(9);
    Term _h_2348 = STK(10);
    Term _h_2349 = STK(11);
    Term _h_2350 = STK(12);
    Term _h_2351 = STK(13);
    Term _h_2352 = STK(14);
    Term _h_2353 = STK(15);
    Term _h_2354 = STK(16);
    Term _h_2355 = STK(17);
    Term _h_2356 = STK(18);
    Term _h_2357 = STK(19);
    Term _h_2358 = STK(20);
    Term _h_2359 = STK(21);
    Term _h_2360 = STK(22);
    Term _h_2361 = STK(23);
    Term _h_2362 = STK(24);
    Term _h_2363 = STK(25);
    Term _h_2364 = STK(26);
    Term _h_2365 = STK(27);
    Term _h_2366 = STK(28);
    Term _h_2367 = STK(29);
    Term _h_2368 = STK(30);
    Term _h_2369 = STK(31);
    Term _h_2370 = STK(32);
    Term _h_2371 = STK(33);
    Term _h_2372 = STK(34);
    Term _h_2373 = STK(35);
    Term _h_2374 = STK(36);
    Term _h_2337 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(39);
      STK(0) = _h_2338;
      STK(1) = _h_2339;
      STK(2) = _h_2340;
      STK(3) = _h_2341;
      STK(4) = _h_2342;
      STK(5) = _h_2343;
      STK(6) = _h_2344;
      STK(7) = _h_2345;
      STK(8) = _h_2346;
      STK(9) = _h_2347;
      STK(10) = _h_2348;
      STK(11) = _h_2349;
      STK(12) = _h_2350;
      STK(13) = _h_2351;
      STK(14) = _h_2352;
      STK(15) = _h_2353;
      STK(16) = _h_2354;
      STK(17) = _h_2355;
      STK(18) = _h_2356;
      STK(19) = _h_2357;
      STK(20) = _h_2358;
      STK(21) = _h_2359;
      STK(22) = _h_2360;
      STK(23) = _h_2361;
      STK(24) = _h_2362;
      STK(25) = _h_2363;
      STK(26) = _h_2364;
      STK(27) = _h_2365;
      STK(28) = _h_2366;
      STK(29) = _h_2367;
      STK(30) = _h_2368;
      STK(31) = _h_2369;
      STK(32) = _h_2370;
      STK(33) = _h_2371;
      STK(34) = _h_2372;
      STK(35) = _h_2373;
      STK(36) = _h_2374;
      STK(37) = _h_2337;
      STK(38) = FID_CONTROLS_K290;
      WL_PUSHN(39);
    } else {
      u64 _t_228 = task_node(e, FID_CONTROLS_K290, WL_CONT, WL_IDX, 1);
      e.mem[_t_228 + 0] = _h_2338;
      e.mem[_t_228 + 1] = _h_2339;
      e.mem[_t_228 + 2] = _h_2340;
      e.mem[_t_228 + 3] = _h_2341;
      e.mem[_t_228 + 4] = _h_2342;
      e.mem[_t_228 + 5] = _h_2343;
      e.mem[_t_228 + 6] = _h_2344;
      e.mem[_t_228 + 7] = _h_2345;
      e.mem[_t_228 + 8] = _h_2346;
      e.mem[_t_228 + 9] = _h_2347;
      e.mem[_t_228 + 10] = _h_2348;
      e.mem[_t_228 + 11] = _h_2349;
      e.mem[_t_228 + 12] = _h_2350;
      e.mem[_t_228 + 13] = _h_2351;
      e.mem[_t_228 + 14] = _h_2352;
      e.mem[_t_228 + 15] = _h_2353;
      e.mem[_t_228 + 16] = _h_2354;
      e.mem[_t_228 + 17] = _h_2355;
      e.mem[_t_228 + 18] = _h_2356;
      e.mem[_t_228 + 19] = _h_2357;
      e.mem[_t_228 + 20] = _h_2358;
      e.mem[_t_228 + 21] = _h_2359;
      e.mem[_t_228 + 22] = _h_2360;
      e.mem[_t_228 + 23] = _h_2361;
      e.mem[_t_228 + 24] = _h_2362;
      e.mem[_t_228 + 25] = _h_2363;
      e.mem[_t_228 + 26] = _h_2364;
      e.mem[_t_228 + 27] = _h_2365;
      e.mem[_t_228 + 28] = _h_2366;
      e.mem[_t_228 + 29] = _h_2367;
      e.mem[_t_228 + 30] = _h_2368;
      e.mem[_t_228 + 31] = _h_2369;
      e.mem[_t_228 + 32] = _h_2370;
      e.mem[_t_228 + 33] = _h_2371;
      e.mem[_t_228 + 34] = _h_2372;
      e.mem[_t_228 + 35] = _h_2373;
      e.mem[_t_228 + 36] = _h_2374;
      e.mem[_t_228 + 37] = _h_2337;
      WL_CONT = term_tsk(FID_CONTROLS_K290, _t_228);
      WL_IDX = 38;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_229 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_229 + 0] = term_ctr(CID_CON, STAT_OFF + 1325);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_229);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 1325);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K290)
  {
    WL_POPN(38);
    Term _h_2380 = STK(0);
    Term _h_2381 = STK(1);
    Term _h_2382 = STK(2);
    Term _h_2383 = STK(3);
    Term _h_2384 = STK(4);
    Term _h_2385 = STK(5);
    Term _h_2386 = STK(6);
    Term _h_2387 = STK(7);
    Term _h_2388 = STK(8);
    Term _h_2389 = STK(9);
    Term _h_2390 = STK(10);
    Term _h_2391 = STK(11);
    Term _h_2392 = STK(12);
    Term _h_2393 = STK(13);
    Term _h_2394 = STK(14);
    Term _h_2395 = STK(15);
    Term _h_2396 = STK(16);
    Term _h_2397 = STK(17);
    Term _h_2398 = STK(18);
    Term _h_2399 = STK(19);
    Term _h_2400 = STK(20);
    Term _h_2401 = STK(21);
    Term _h_2402 = STK(22);
    Term _h_2403 = STK(23);
    Term _h_2404 = STK(24);
    Term _h_2405 = STK(25);
    Term _h_2406 = STK(26);
    Term _h_2407 = STK(27);
    Term _h_2408 = STK(28);
    Term _h_2409 = STK(29);
    Term _h_2410 = STK(30);
    Term _h_2411 = STK(31);
    Term _h_2412 = STK(32);
    Term _h_2413 = STK(33);
    Term _h_2414 = STK(34);
    Term _h_2415 = STK(35);
    Term _h_2416 = STK(36);
    Term _h_2417 = STK(37);
    u32 _h_2375 = r0;
    u32 _h_2376 = r1;
    u32 _h_2377 = r2;
    Term _h_2378 = r3;
    Term _h_2379 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(39);
      STK(0) = _h_2380;
      STK(1) = _h_2381;
      STK(2) = _h_2382;
      STK(3) = _h_2383;
      STK(4) = _h_2384;
      STK(5) = _h_2385;
      STK(6) = _h_2386;
      STK(7) = _h_2387;
      STK(8) = _h_2388;
      STK(9) = _h_2389;
      STK(10) = _h_2390;
      STK(11) = _h_2391;
      STK(12) = _h_2392;
      STK(13) = _h_2393;
      STK(14) = _h_2394;
      STK(15) = _h_2395;
      STK(16) = _h_2396;
      STK(17) = _h_2397;
      STK(18) = _h_2398;
      STK(19) = _h_2399;
      STK(20) = _h_2400;
      STK(21) = _h_2401;
      STK(22) = _h_2402;
      STK(23) = _h_2403;
      STK(24) = _h_2404;
      STK(25) = _h_2405;
      STK(26) = _h_2406;
      STK(27) = _h_2407;
      STK(28) = _h_2408;
      STK(29) = _h_2409;
      STK(30) = _h_2410;
      STK(31) = _h_2411;
      STK(32) = _h_2412;
      STK(33) = _h_2413;
      STK(34) = _h_2414;
      STK(35) = _h_2415;
      STK(36) = _h_2416;
      STK(37) = _h_2417;
      STK(38) = FID_CONTROLS_K291;
      WL_PUSHN(39);
    } else {
      u64 _t_230 = task_node(e, FID_CONTROLS_K291, WL_CONT, WL_IDX, 1);
      e.mem[_t_230 + 0] = _h_2380;
      e.mem[_t_230 + 1] = _h_2381;
      e.mem[_t_230 + 2] = _h_2382;
      e.mem[_t_230 + 3] = _h_2383;
      e.mem[_t_230 + 4] = _h_2384;
      e.mem[_t_230 + 5] = _h_2385;
      e.mem[_t_230 + 6] = _h_2386;
      e.mem[_t_230 + 7] = _h_2387;
      e.mem[_t_230 + 8] = _h_2388;
      e.mem[_t_230 + 9] = _h_2389;
      e.mem[_t_230 + 10] = _h_2390;
      e.mem[_t_230 + 11] = _h_2391;
      e.mem[_t_230 + 12] = _h_2392;
      e.mem[_t_230 + 13] = _h_2393;
      e.mem[_t_230 + 14] = _h_2394;
      e.mem[_t_230 + 15] = _h_2395;
      e.mem[_t_230 + 16] = _h_2396;
      e.mem[_t_230 + 17] = _h_2397;
      e.mem[_t_230 + 18] = _h_2398;
      e.mem[_t_230 + 19] = _h_2399;
      e.mem[_t_230 + 20] = _h_2400;
      e.mem[_t_230 + 21] = _h_2401;
      e.mem[_t_230 + 22] = _h_2402;
      e.mem[_t_230 + 23] = _h_2403;
      e.mem[_t_230 + 24] = _h_2404;
      e.mem[_t_230 + 25] = _h_2405;
      e.mem[_t_230 + 26] = _h_2406;
      e.mem[_t_230 + 27] = _h_2407;
      e.mem[_t_230 + 28] = _h_2408;
      e.mem[_t_230 + 29] = _h_2409;
      e.mem[_t_230 + 30] = _h_2410;
      e.mem[_t_230 + 31] = _h_2411;
      e.mem[_t_230 + 32] = _h_2412;
      e.mem[_t_230 + 33] = _h_2413;
      e.mem[_t_230 + 34] = _h_2414;
      e.mem[_t_230 + 35] = _h_2415;
      e.mem[_t_230 + 36] = _h_2416;
      e.mem[_t_230 + 37] = _h_2417;
      WL_CONT = term_tsk(FID_CONTROLS_K291, _t_230);
      WL_IDX = 38;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_231 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_231 + 0] = _h_2375;
      e.mem[_t_231 + 1] = _h_2376;
      e.mem[_t_231 + 2] = _h_2377;
      e.mem[_t_231 + 3] = _h_2378;
      e.mem[_t_231 + 4] = _h_2379;
      return term_tsk(FID_VALIDATION, _t_231);
    }
    r0 = _h_2375;
    r1 = _h_2376;
    r2 = _h_2377;
    r3 = _h_2378;
    r4 = _h_2379;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K291)
  {
    WL_POPN(38);
    Term _h_2419 = STK(0);
    Term _h_2420 = STK(1);
    Term _h_2421 = STK(2);
    Term _h_2422 = STK(3);
    Term _h_2423 = STK(4);
    Term _h_2424 = STK(5);
    Term _h_2425 = STK(6);
    Term _h_2426 = STK(7);
    Term _h_2427 = STK(8);
    Term _h_2428 = STK(9);
    Term _h_2429 = STK(10);
    Term _h_2430 = STK(11);
    Term _h_2431 = STK(12);
    Term _h_2432 = STK(13);
    Term _h_2433 = STK(14);
    Term _h_2434 = STK(15);
    Term _h_2435 = STK(16);
    Term _h_2436 = STK(17);
    Term _h_2437 = STK(18);
    Term _h_2438 = STK(19);
    Term _h_2439 = STK(20);
    Term _h_2440 = STK(21);
    Term _h_2441 = STK(22);
    Term _h_2442 = STK(23);
    Term _h_2443 = STK(24);
    Term _h_2444 = STK(25);
    Term _h_2445 = STK(26);
    Term _h_2446 = STK(27);
    Term _h_2447 = STK(28);
    Term _h_2448 = STK(29);
    Term _h_2449 = STK(30);
    Term _h_2450 = STK(31);
    Term _h_2451 = STK(32);
    Term _h_2452 = STK(33);
    Term _h_2453 = STK(34);
    Term _h_2454 = STK(35);
    Term _h_2455 = STK(36);
    Term _h_2456 = STK(37);
    Term _h_2418 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(39);
      STK(0) = _h_2419;
      STK(1) = _h_2420;
      STK(2) = _h_2421;
      STK(3) = _h_2422;
      STK(4) = _h_2423;
      STK(5) = _h_2424;
      STK(6) = _h_2425;
      STK(7) = _h_2426;
      STK(8) = _h_2427;
      STK(9) = _h_2428;
      STK(10) = _h_2429;
      STK(11) = _h_2430;
      STK(12) = _h_2431;
      STK(13) = _h_2432;
      STK(14) = _h_2433;
      STK(15) = _h_2434;
      STK(16) = _h_2435;
      STK(17) = _h_2436;
      STK(18) = _h_2437;
      STK(19) = _h_2438;
      STK(20) = _h_2439;
      STK(21) = _h_2440;
      STK(22) = _h_2441;
      STK(23) = _h_2442;
      STK(24) = _h_2443;
      STK(25) = _h_2444;
      STK(26) = _h_2445;
      STK(27) = _h_2446;
      STK(28) = _h_2447;
      STK(29) = _h_2448;
      STK(30) = _h_2449;
      STK(31) = _h_2450;
      STK(32) = _h_2451;
      STK(33) = _h_2452;
      STK(34) = _h_2453;
      STK(35) = _h_2454;
      STK(36) = _h_2455;
      STK(37) = _h_2456;
      STK(38) = FID_CONTROLS_K292;
      WL_PUSHN(39);
    } else {
      u64 _t_232 = task_node(e, FID_CONTROLS_K292, WL_CONT, WL_IDX, 1);
      e.mem[_t_232 + 0] = _h_2419;
      e.mem[_t_232 + 1] = _h_2420;
      e.mem[_t_232 + 2] = _h_2421;
      e.mem[_t_232 + 3] = _h_2422;
      e.mem[_t_232 + 4] = _h_2423;
      e.mem[_t_232 + 5] = _h_2424;
      e.mem[_t_232 + 6] = _h_2425;
      e.mem[_t_232 + 7] = _h_2426;
      e.mem[_t_232 + 8] = _h_2427;
      e.mem[_t_232 + 9] = _h_2428;
      e.mem[_t_232 + 10] = _h_2429;
      e.mem[_t_232 + 11] = _h_2430;
      e.mem[_t_232 + 12] = _h_2431;
      e.mem[_t_232 + 13] = _h_2432;
      e.mem[_t_232 + 14] = _h_2433;
      e.mem[_t_232 + 15] = _h_2434;
      e.mem[_t_232 + 16] = _h_2435;
      e.mem[_t_232 + 17] = _h_2436;
      e.mem[_t_232 + 18] = _h_2437;
      e.mem[_t_232 + 19] = _h_2438;
      e.mem[_t_232 + 20] = _h_2439;
      e.mem[_t_232 + 21] = _h_2440;
      e.mem[_t_232 + 22] = _h_2441;
      e.mem[_t_232 + 23] = _h_2442;
      e.mem[_t_232 + 24] = _h_2443;
      e.mem[_t_232 + 25] = _h_2444;
      e.mem[_t_232 + 26] = _h_2445;
      e.mem[_t_232 + 27] = _h_2446;
      e.mem[_t_232 + 28] = _h_2447;
      e.mem[_t_232 + 29] = _h_2448;
      e.mem[_t_232 + 30] = _h_2449;
      e.mem[_t_232 + 31] = _h_2450;
      e.mem[_t_232 + 32] = _h_2451;
      e.mem[_t_232 + 33] = _h_2452;
      e.mem[_t_232 + 34] = _h_2453;
      e.mem[_t_232 + 35] = _h_2454;
      e.mem[_t_232 + 36] = _h_2455;
      e.mem[_t_232 + 37] = _h_2456;
      WL_CONT = term_tsk(FID_CONTROLS_K292, _t_232);
      WL_IDX = 38;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_233 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_233 + 0] = term_ctr(CID_SCON, STAT_OFF + 1383);
      e.mem[_t_233 + 1] = _h_2418;
      return term_tsk(FID_STRING_APPEND, _t_233);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1383);
    r1 = _h_2418;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K292)
  {
    WL_POPN(38);
    Term _h_2458 = STK(0);
    Term _h_2459 = STK(1);
    Term _h_2460 = STK(2);
    Term _h_2461 = STK(3);
    Term _h_2462 = STK(4);
    Term _h_2463 = STK(5);
    Term _h_2464 = STK(6);
    Term _h_2465 = STK(7);
    Term _h_2466 = STK(8);
    Term _h_2467 = STK(9);
    Term _h_2468 = STK(10);
    Term _h_2469 = STK(11);
    Term _h_2470 = STK(12);
    Term _h_2471 = STK(13);
    Term _h_2472 = STK(14);
    Term _h_2473 = STK(15);
    Term _h_2474 = STK(16);
    Term _h_2475 = STK(17);
    Term _h_2476 = STK(18);
    Term _h_2477 = STK(19);
    Term _h_2478 = STK(20);
    Term _h_2479 = STK(21);
    Term _h_2480 = STK(22);
    Term _h_2481 = STK(23);
    Term _h_2482 = STK(24);
    Term _h_2483 = STK(25);
    Term _h_2484 = STK(26);
    Term _h_2485 = STK(27);
    Term _h_2486 = STK(28);
    Term _h_2487 = STK(29);
    Term _h_2488 = STK(30);
    Term _h_2489 = STK(31);
    Term _h_2490 = STK(32);
    Term _h_2491 = STK(33);
    Term _h_2492 = STK(34);
    Term _h_2493 = STK(35);
    Term _h_2494 = STK(36);
    Term _h_2495 = STK(37);
    Term _h_2457 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(40);
      STK(0) = _h_2458;
      STK(1) = _h_2459;
      STK(2) = _h_2460;
      STK(3) = _h_2461;
      STK(4) = _h_2462;
      STK(5) = _h_2463;
      STK(6) = _h_2464;
      STK(7) = _h_2465;
      STK(8) = _h_2466;
      STK(9) = _h_2467;
      STK(10) = _h_2468;
      STK(11) = _h_2469;
      STK(12) = _h_2470;
      STK(13) = _h_2471;
      STK(14) = _h_2472;
      STK(15) = _h_2473;
      STK(16) = _h_2474;
      STK(17) = _h_2475;
      STK(18) = _h_2476;
      STK(19) = _h_2477;
      STK(20) = _h_2478;
      STK(21) = _h_2479;
      STK(22) = _h_2480;
      STK(23) = _h_2481;
      STK(24) = _h_2482;
      STK(25) = _h_2483;
      STK(26) = _h_2484;
      STK(27) = _h_2485;
      STK(28) = _h_2486;
      STK(29) = _h_2487;
      STK(30) = _h_2488;
      STK(31) = _h_2489;
      STK(32) = _h_2490;
      STK(33) = _h_2491;
      STK(34) = _h_2492;
      STK(35) = _h_2493;
      STK(36) = _h_2494;
      STK(37) = _h_2495;
      STK(38) = _h_2457;
      STK(39) = FID_CONTROLS_K293;
      WL_PUSHN(40);
    } else {
      u64 _t_234 = task_node(e, FID_CONTROLS_K293, WL_CONT, WL_IDX, 1);
      e.mem[_t_234 + 0] = _h_2458;
      e.mem[_t_234 + 1] = _h_2459;
      e.mem[_t_234 + 2] = _h_2460;
      e.mem[_t_234 + 3] = _h_2461;
      e.mem[_t_234 + 4] = _h_2462;
      e.mem[_t_234 + 5] = _h_2463;
      e.mem[_t_234 + 6] = _h_2464;
      e.mem[_t_234 + 7] = _h_2465;
      e.mem[_t_234 + 8] = _h_2466;
      e.mem[_t_234 + 9] = _h_2467;
      e.mem[_t_234 + 10] = _h_2468;
      e.mem[_t_234 + 11] = _h_2469;
      e.mem[_t_234 + 12] = _h_2470;
      e.mem[_t_234 + 13] = _h_2471;
      e.mem[_t_234 + 14] = _h_2472;
      e.mem[_t_234 + 15] = _h_2473;
      e.mem[_t_234 + 16] = _h_2474;
      e.mem[_t_234 + 17] = _h_2475;
      e.mem[_t_234 + 18] = _h_2476;
      e.mem[_t_234 + 19] = _h_2477;
      e.mem[_t_234 + 20] = _h_2478;
      e.mem[_t_234 + 21] = _h_2479;
      e.mem[_t_234 + 22] = _h_2480;
      e.mem[_t_234 + 23] = _h_2481;
      e.mem[_t_234 + 24] = _h_2482;
      e.mem[_t_234 + 25] = _h_2483;
      e.mem[_t_234 + 26] = _h_2484;
      e.mem[_t_234 + 27] = _h_2485;
      e.mem[_t_234 + 28] = _h_2486;
      e.mem[_t_234 + 29] = _h_2487;
      e.mem[_t_234 + 30] = _h_2488;
      e.mem[_t_234 + 31] = _h_2489;
      e.mem[_t_234 + 32] = _h_2490;
      e.mem[_t_234 + 33] = _h_2491;
      e.mem[_t_234 + 34] = _h_2492;
      e.mem[_t_234 + 35] = _h_2493;
      e.mem[_t_234 + 36] = _h_2494;
      e.mem[_t_234 + 37] = _h_2495;
      e.mem[_t_234 + 38] = _h_2457;
      WL_CONT = term_tsk(FID_CONTROLS_K293, _t_234);
      WL_IDX = 39;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_235 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_235 + 0] = term_ctr(CID_CON, STAT_OFF + 1408);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_235);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 1408);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K293)
  {
    WL_POPN(39);
    Term _h_2501 = STK(0);
    Term _h_2502 = STK(1);
    Term _h_2503 = STK(2);
    Term _h_2504 = STK(3);
    Term _h_2505 = STK(4);
    Term _h_2506 = STK(5);
    Term _h_2507 = STK(6);
    Term _h_2508 = STK(7);
    Term _h_2509 = STK(8);
    Term _h_2510 = STK(9);
    Term _h_2511 = STK(10);
    Term _h_2512 = STK(11);
    Term _h_2513 = STK(12);
    Term _h_2514 = STK(13);
    Term _h_2515 = STK(14);
    Term _h_2516 = STK(15);
    Term _h_2517 = STK(16);
    Term _h_2518 = STK(17);
    Term _h_2519 = STK(18);
    Term _h_2520 = STK(19);
    Term _h_2521 = STK(20);
    Term _h_2522 = STK(21);
    Term _h_2523 = STK(22);
    Term _h_2524 = STK(23);
    Term _h_2525 = STK(24);
    Term _h_2526 = STK(25);
    Term _h_2527 = STK(26);
    Term _h_2528 = STK(27);
    Term _h_2529 = STK(28);
    Term _h_2530 = STK(29);
    Term _h_2531 = STK(30);
    Term _h_2532 = STK(31);
    Term _h_2533 = STK(32);
    Term _h_2534 = STK(33);
    Term _h_2535 = STK(34);
    Term _h_2536 = STK(35);
    Term _h_2537 = STK(36);
    Term _h_2538 = STK(37);
    Term _h_2539 = STK(38);
    u32 _h_2496 = r0;
    u32 _h_2497 = r1;
    u32 _h_2498 = r2;
    Term _h_2499 = r3;
    Term _h_2500 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(40);
      STK(0) = _h_2501;
      STK(1) = _h_2502;
      STK(2) = _h_2503;
      STK(3) = _h_2504;
      STK(4) = _h_2505;
      STK(5) = _h_2506;
      STK(6) = _h_2507;
      STK(7) = _h_2508;
      STK(8) = _h_2509;
      STK(9) = _h_2510;
      STK(10) = _h_2511;
      STK(11) = _h_2512;
      STK(12) = _h_2513;
      STK(13) = _h_2514;
      STK(14) = _h_2515;
      STK(15) = _h_2516;
      STK(16) = _h_2517;
      STK(17) = _h_2518;
      STK(18) = _h_2519;
      STK(19) = _h_2520;
      STK(20) = _h_2521;
      STK(21) = _h_2522;
      STK(22) = _h_2523;
      STK(23) = _h_2524;
      STK(24) = _h_2525;
      STK(25) = _h_2526;
      STK(26) = _h_2527;
      STK(27) = _h_2528;
      STK(28) = _h_2529;
      STK(29) = _h_2530;
      STK(30) = _h_2531;
      STK(31) = _h_2532;
      STK(32) = _h_2533;
      STK(33) = _h_2534;
      STK(34) = _h_2535;
      STK(35) = _h_2536;
      STK(36) = _h_2537;
      STK(37) = _h_2538;
      STK(38) = _h_2539;
      STK(39) = FID_CONTROLS_K294;
      WL_PUSHN(40);
    } else {
      u64 _t_236 = task_node(e, FID_CONTROLS_K294, WL_CONT, WL_IDX, 1);
      e.mem[_t_236 + 0] = _h_2501;
      e.mem[_t_236 + 1] = _h_2502;
      e.mem[_t_236 + 2] = _h_2503;
      e.mem[_t_236 + 3] = _h_2504;
      e.mem[_t_236 + 4] = _h_2505;
      e.mem[_t_236 + 5] = _h_2506;
      e.mem[_t_236 + 6] = _h_2507;
      e.mem[_t_236 + 7] = _h_2508;
      e.mem[_t_236 + 8] = _h_2509;
      e.mem[_t_236 + 9] = _h_2510;
      e.mem[_t_236 + 10] = _h_2511;
      e.mem[_t_236 + 11] = _h_2512;
      e.mem[_t_236 + 12] = _h_2513;
      e.mem[_t_236 + 13] = _h_2514;
      e.mem[_t_236 + 14] = _h_2515;
      e.mem[_t_236 + 15] = _h_2516;
      e.mem[_t_236 + 16] = _h_2517;
      e.mem[_t_236 + 17] = _h_2518;
      e.mem[_t_236 + 18] = _h_2519;
      e.mem[_t_236 + 19] = _h_2520;
      e.mem[_t_236 + 20] = _h_2521;
      e.mem[_t_236 + 21] = _h_2522;
      e.mem[_t_236 + 22] = _h_2523;
      e.mem[_t_236 + 23] = _h_2524;
      e.mem[_t_236 + 24] = _h_2525;
      e.mem[_t_236 + 25] = _h_2526;
      e.mem[_t_236 + 26] = _h_2527;
      e.mem[_t_236 + 27] = _h_2528;
      e.mem[_t_236 + 28] = _h_2529;
      e.mem[_t_236 + 29] = _h_2530;
      e.mem[_t_236 + 30] = _h_2531;
      e.mem[_t_236 + 31] = _h_2532;
      e.mem[_t_236 + 32] = _h_2533;
      e.mem[_t_236 + 33] = _h_2534;
      e.mem[_t_236 + 34] = _h_2535;
      e.mem[_t_236 + 35] = _h_2536;
      e.mem[_t_236 + 36] = _h_2537;
      e.mem[_t_236 + 37] = _h_2538;
      e.mem[_t_236 + 38] = _h_2539;
      WL_CONT = term_tsk(FID_CONTROLS_K294, _t_236);
      WL_IDX = 39;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_237 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_237 + 0] = _h_2496;
      e.mem[_t_237 + 1] = _h_2497;
      e.mem[_t_237 + 2] = _h_2498;
      e.mem[_t_237 + 3] = _h_2499;
      e.mem[_t_237 + 4] = _h_2500;
      return term_tsk(FID_VALIDATION, _t_237);
    }
    r0 = _h_2496;
    r1 = _h_2497;
    r2 = _h_2498;
    r3 = _h_2499;
    r4 = _h_2500;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K294)
  {
    WL_POPN(39);
    Term _h_2541 = STK(0);
    Term _h_2542 = STK(1);
    Term _h_2543 = STK(2);
    Term _h_2544 = STK(3);
    Term _h_2545 = STK(4);
    Term _h_2546 = STK(5);
    Term _h_2547 = STK(6);
    Term _h_2548 = STK(7);
    Term _h_2549 = STK(8);
    Term _h_2550 = STK(9);
    Term _h_2551 = STK(10);
    Term _h_2552 = STK(11);
    Term _h_2553 = STK(12);
    Term _h_2554 = STK(13);
    Term _h_2555 = STK(14);
    Term _h_2556 = STK(15);
    Term _h_2557 = STK(16);
    Term _h_2558 = STK(17);
    Term _h_2559 = STK(18);
    Term _h_2560 = STK(19);
    Term _h_2561 = STK(20);
    Term _h_2562 = STK(21);
    Term _h_2563 = STK(22);
    Term _h_2564 = STK(23);
    Term _h_2565 = STK(24);
    Term _h_2566 = STK(25);
    Term _h_2567 = STK(26);
    Term _h_2568 = STK(27);
    Term _h_2569 = STK(28);
    Term _h_2570 = STK(29);
    Term _h_2571 = STK(30);
    Term _h_2572 = STK(31);
    Term _h_2573 = STK(32);
    Term _h_2574 = STK(33);
    Term _h_2575 = STK(34);
    Term _h_2576 = STK(35);
    Term _h_2577 = STK(36);
    Term _h_2578 = STK(37);
    Term _h_2579 = STK(38);
    Term _h_2540 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(40);
      STK(0) = _h_2541;
      STK(1) = _h_2542;
      STK(2) = _h_2543;
      STK(3) = _h_2544;
      STK(4) = _h_2545;
      STK(5) = _h_2546;
      STK(6) = _h_2547;
      STK(7) = _h_2548;
      STK(8) = _h_2549;
      STK(9) = _h_2550;
      STK(10) = _h_2551;
      STK(11) = _h_2552;
      STK(12) = _h_2553;
      STK(13) = _h_2554;
      STK(14) = _h_2555;
      STK(15) = _h_2556;
      STK(16) = _h_2557;
      STK(17) = _h_2558;
      STK(18) = _h_2559;
      STK(19) = _h_2560;
      STK(20) = _h_2561;
      STK(21) = _h_2562;
      STK(22) = _h_2563;
      STK(23) = _h_2564;
      STK(24) = _h_2565;
      STK(25) = _h_2566;
      STK(26) = _h_2567;
      STK(27) = _h_2568;
      STK(28) = _h_2569;
      STK(29) = _h_2570;
      STK(30) = _h_2571;
      STK(31) = _h_2572;
      STK(32) = _h_2573;
      STK(33) = _h_2574;
      STK(34) = _h_2575;
      STK(35) = _h_2576;
      STK(36) = _h_2577;
      STK(37) = _h_2578;
      STK(38) = _h_2579;
      STK(39) = FID_CONTROLS_K295;
      WL_PUSHN(40);
    } else {
      u64 _t_238 = task_node(e, FID_CONTROLS_K295, WL_CONT, WL_IDX, 1);
      e.mem[_t_238 + 0] = _h_2541;
      e.mem[_t_238 + 1] = _h_2542;
      e.mem[_t_238 + 2] = _h_2543;
      e.mem[_t_238 + 3] = _h_2544;
      e.mem[_t_238 + 4] = _h_2545;
      e.mem[_t_238 + 5] = _h_2546;
      e.mem[_t_238 + 6] = _h_2547;
      e.mem[_t_238 + 7] = _h_2548;
      e.mem[_t_238 + 8] = _h_2549;
      e.mem[_t_238 + 9] = _h_2550;
      e.mem[_t_238 + 10] = _h_2551;
      e.mem[_t_238 + 11] = _h_2552;
      e.mem[_t_238 + 12] = _h_2553;
      e.mem[_t_238 + 13] = _h_2554;
      e.mem[_t_238 + 14] = _h_2555;
      e.mem[_t_238 + 15] = _h_2556;
      e.mem[_t_238 + 16] = _h_2557;
      e.mem[_t_238 + 17] = _h_2558;
      e.mem[_t_238 + 18] = _h_2559;
      e.mem[_t_238 + 19] = _h_2560;
      e.mem[_t_238 + 20] = _h_2561;
      e.mem[_t_238 + 21] = _h_2562;
      e.mem[_t_238 + 22] = _h_2563;
      e.mem[_t_238 + 23] = _h_2564;
      e.mem[_t_238 + 24] = _h_2565;
      e.mem[_t_238 + 25] = _h_2566;
      e.mem[_t_238 + 26] = _h_2567;
      e.mem[_t_238 + 27] = _h_2568;
      e.mem[_t_238 + 28] = _h_2569;
      e.mem[_t_238 + 29] = _h_2570;
      e.mem[_t_238 + 30] = _h_2571;
      e.mem[_t_238 + 31] = _h_2572;
      e.mem[_t_238 + 32] = _h_2573;
      e.mem[_t_238 + 33] = _h_2574;
      e.mem[_t_238 + 34] = _h_2575;
      e.mem[_t_238 + 35] = _h_2576;
      e.mem[_t_238 + 36] = _h_2577;
      e.mem[_t_238 + 37] = _h_2578;
      e.mem[_t_238 + 38] = _h_2579;
      WL_CONT = term_tsk(FID_CONTROLS_K295, _t_238);
      WL_IDX = 39;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_239 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_239 + 0] = term_ctr(CID_SCON, STAT_OFF + 1476);
      e.mem[_t_239 + 1] = _h_2540;
      return term_tsk(FID_STRING_APPEND, _t_239);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1476);
    r1 = _h_2540;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K295)
  {
    WL_POPN(39);
    Term _h_2581 = STK(0);
    Term _h_2582 = STK(1);
    Term _h_2583 = STK(2);
    Term _h_2584 = STK(3);
    Term _h_2585 = STK(4);
    Term _h_2586 = STK(5);
    Term _h_2587 = STK(6);
    Term _h_2588 = STK(7);
    Term _h_2589 = STK(8);
    Term _h_2590 = STK(9);
    Term _h_2591 = STK(10);
    Term _h_2592 = STK(11);
    Term _h_2593 = STK(12);
    Term _h_2594 = STK(13);
    Term _h_2595 = STK(14);
    Term _h_2596 = STK(15);
    Term _h_2597 = STK(16);
    Term _h_2598 = STK(17);
    Term _h_2599 = STK(18);
    Term _h_2600 = STK(19);
    Term _h_2601 = STK(20);
    Term _h_2602 = STK(21);
    Term _h_2603 = STK(22);
    Term _h_2604 = STK(23);
    Term _h_2605 = STK(24);
    Term _h_2606 = STK(25);
    Term _h_2607 = STK(26);
    Term _h_2608 = STK(27);
    Term _h_2609 = STK(28);
    Term _h_2610 = STK(29);
    Term _h_2611 = STK(30);
    Term _h_2612 = STK(31);
    Term _h_2613 = STK(32);
    Term _h_2614 = STK(33);
    Term _h_2615 = STK(34);
    Term _h_2616 = STK(35);
    Term _h_2617 = STK(36);
    Term _h_2618 = STK(37);
    Term _h_2619 = STK(38);
    Term _h_2580 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(41);
      STK(0) = _h_2581;
      STK(1) = _h_2582;
      STK(2) = _h_2583;
      STK(3) = _h_2584;
      STK(4) = _h_2585;
      STK(5) = _h_2586;
      STK(6) = _h_2587;
      STK(7) = _h_2588;
      STK(8) = _h_2589;
      STK(9) = _h_2590;
      STK(10) = _h_2591;
      STK(11) = _h_2592;
      STK(12) = _h_2593;
      STK(13) = _h_2594;
      STK(14) = _h_2595;
      STK(15) = _h_2596;
      STK(16) = _h_2597;
      STK(17) = _h_2598;
      STK(18) = _h_2599;
      STK(19) = _h_2600;
      STK(20) = _h_2601;
      STK(21) = _h_2602;
      STK(22) = _h_2603;
      STK(23) = _h_2604;
      STK(24) = _h_2605;
      STK(25) = _h_2606;
      STK(26) = _h_2607;
      STK(27) = _h_2608;
      STK(28) = _h_2609;
      STK(29) = _h_2610;
      STK(30) = _h_2611;
      STK(31) = _h_2612;
      STK(32) = _h_2613;
      STK(33) = _h_2614;
      STK(34) = _h_2615;
      STK(35) = _h_2616;
      STK(36) = _h_2617;
      STK(37) = _h_2618;
      STK(38) = _h_2619;
      STK(39) = _h_2580;
      STK(40) = FID_CONTROLS_K296;
      WL_PUSHN(41);
    } else {
      u64 _t_240 = task_node(e, FID_CONTROLS_K296, WL_CONT, WL_IDX, 1);
      e.mem[_t_240 + 0] = _h_2581;
      e.mem[_t_240 + 1] = _h_2582;
      e.mem[_t_240 + 2] = _h_2583;
      e.mem[_t_240 + 3] = _h_2584;
      e.mem[_t_240 + 4] = _h_2585;
      e.mem[_t_240 + 5] = _h_2586;
      e.mem[_t_240 + 6] = _h_2587;
      e.mem[_t_240 + 7] = _h_2588;
      e.mem[_t_240 + 8] = _h_2589;
      e.mem[_t_240 + 9] = _h_2590;
      e.mem[_t_240 + 10] = _h_2591;
      e.mem[_t_240 + 11] = _h_2592;
      e.mem[_t_240 + 12] = _h_2593;
      e.mem[_t_240 + 13] = _h_2594;
      e.mem[_t_240 + 14] = _h_2595;
      e.mem[_t_240 + 15] = _h_2596;
      e.mem[_t_240 + 16] = _h_2597;
      e.mem[_t_240 + 17] = _h_2598;
      e.mem[_t_240 + 18] = _h_2599;
      e.mem[_t_240 + 19] = _h_2600;
      e.mem[_t_240 + 20] = _h_2601;
      e.mem[_t_240 + 21] = _h_2602;
      e.mem[_t_240 + 22] = _h_2603;
      e.mem[_t_240 + 23] = _h_2604;
      e.mem[_t_240 + 24] = _h_2605;
      e.mem[_t_240 + 25] = _h_2606;
      e.mem[_t_240 + 26] = _h_2607;
      e.mem[_t_240 + 27] = _h_2608;
      e.mem[_t_240 + 28] = _h_2609;
      e.mem[_t_240 + 29] = _h_2610;
      e.mem[_t_240 + 30] = _h_2611;
      e.mem[_t_240 + 31] = _h_2612;
      e.mem[_t_240 + 32] = _h_2613;
      e.mem[_t_240 + 33] = _h_2614;
      e.mem[_t_240 + 34] = _h_2615;
      e.mem[_t_240 + 35] = _h_2616;
      e.mem[_t_240 + 36] = _h_2617;
      e.mem[_t_240 + 37] = _h_2618;
      e.mem[_t_240 + 38] = _h_2619;
      e.mem[_t_240 + 39] = _h_2580;
      WL_CONT = term_tsk(FID_CONTROLS_K296, _t_240);
      WL_IDX = 40;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_241 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_241 + 0] = term_ctr(CID_CON, STAT_OFF + 1498);
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_241);
    }
    r0 = term_ctr(CID_CON, STAT_OFF + 1498);
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K296)
  {
    WL_POPN(40);
    Term _h_2625 = STK(0);
    Term _h_2626 = STK(1);
    Term _h_2627 = STK(2);
    Term _h_2628 = STK(3);
    Term _h_2629 = STK(4);
    Term _h_2630 = STK(5);
    Term _h_2631 = STK(6);
    Term _h_2632 = STK(7);
    Term _h_2633 = STK(8);
    Term _h_2634 = STK(9);
    Term _h_2635 = STK(10);
    Term _h_2636 = STK(11);
    Term _h_2637 = STK(12);
    Term _h_2638 = STK(13);
    Term _h_2639 = STK(14);
    Term _h_2640 = STK(15);
    Term _h_2641 = STK(16);
    Term _h_2642 = STK(17);
    Term _h_2643 = STK(18);
    Term _h_2644 = STK(19);
    Term _h_2645 = STK(20);
    Term _h_2646 = STK(21);
    Term _h_2647 = STK(22);
    Term _h_2648 = STK(23);
    Term _h_2649 = STK(24);
    Term _h_2650 = STK(25);
    Term _h_2651 = STK(26);
    Term _h_2652 = STK(27);
    Term _h_2653 = STK(28);
    Term _h_2654 = STK(29);
    Term _h_2655 = STK(30);
    Term _h_2656 = STK(31);
    Term _h_2657 = STK(32);
    Term _h_2658 = STK(33);
    Term _h_2659 = STK(34);
    Term _h_2660 = STK(35);
    Term _h_2661 = STK(36);
    Term _h_2662 = STK(37);
    Term _h_2663 = STK(38);
    Term _h_2664 = STK(39);
    u32 _h_2620 = r0;
    u32 _h_2621 = r1;
    u32 _h_2622 = r2;
    Term _h_2623 = r3;
    Term _h_2624 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(41);
      STK(0) = _h_2625;
      STK(1) = _h_2626;
      STK(2) = _h_2627;
      STK(3) = _h_2628;
      STK(4) = _h_2629;
      STK(5) = _h_2630;
      STK(6) = _h_2631;
      STK(7) = _h_2632;
      STK(8) = _h_2633;
      STK(9) = _h_2634;
      STK(10) = _h_2635;
      STK(11) = _h_2636;
      STK(12) = _h_2637;
      STK(13) = _h_2638;
      STK(14) = _h_2639;
      STK(15) = _h_2640;
      STK(16) = _h_2641;
      STK(17) = _h_2642;
      STK(18) = _h_2643;
      STK(19) = _h_2644;
      STK(20) = _h_2645;
      STK(21) = _h_2646;
      STK(22) = _h_2647;
      STK(23) = _h_2648;
      STK(24) = _h_2649;
      STK(25) = _h_2650;
      STK(26) = _h_2651;
      STK(27) = _h_2652;
      STK(28) = _h_2653;
      STK(29) = _h_2654;
      STK(30) = _h_2655;
      STK(31) = _h_2656;
      STK(32) = _h_2657;
      STK(33) = _h_2658;
      STK(34) = _h_2659;
      STK(35) = _h_2660;
      STK(36) = _h_2661;
      STK(37) = _h_2662;
      STK(38) = _h_2663;
      STK(39) = _h_2664;
      STK(40) = FID_CONTROLS_K297;
      WL_PUSHN(41);
    } else {
      u64 _t_242 = task_node(e, FID_CONTROLS_K297, WL_CONT, WL_IDX, 1);
      e.mem[_t_242 + 0] = _h_2625;
      e.mem[_t_242 + 1] = _h_2626;
      e.mem[_t_242 + 2] = _h_2627;
      e.mem[_t_242 + 3] = _h_2628;
      e.mem[_t_242 + 4] = _h_2629;
      e.mem[_t_242 + 5] = _h_2630;
      e.mem[_t_242 + 6] = _h_2631;
      e.mem[_t_242 + 7] = _h_2632;
      e.mem[_t_242 + 8] = _h_2633;
      e.mem[_t_242 + 9] = _h_2634;
      e.mem[_t_242 + 10] = _h_2635;
      e.mem[_t_242 + 11] = _h_2636;
      e.mem[_t_242 + 12] = _h_2637;
      e.mem[_t_242 + 13] = _h_2638;
      e.mem[_t_242 + 14] = _h_2639;
      e.mem[_t_242 + 15] = _h_2640;
      e.mem[_t_242 + 16] = _h_2641;
      e.mem[_t_242 + 17] = _h_2642;
      e.mem[_t_242 + 18] = _h_2643;
      e.mem[_t_242 + 19] = _h_2644;
      e.mem[_t_242 + 20] = _h_2645;
      e.mem[_t_242 + 21] = _h_2646;
      e.mem[_t_242 + 22] = _h_2647;
      e.mem[_t_242 + 23] = _h_2648;
      e.mem[_t_242 + 24] = _h_2649;
      e.mem[_t_242 + 25] = _h_2650;
      e.mem[_t_242 + 26] = _h_2651;
      e.mem[_t_242 + 27] = _h_2652;
      e.mem[_t_242 + 28] = _h_2653;
      e.mem[_t_242 + 29] = _h_2654;
      e.mem[_t_242 + 30] = _h_2655;
      e.mem[_t_242 + 31] = _h_2656;
      e.mem[_t_242 + 32] = _h_2657;
      e.mem[_t_242 + 33] = _h_2658;
      e.mem[_t_242 + 34] = _h_2659;
      e.mem[_t_242 + 35] = _h_2660;
      e.mem[_t_242 + 36] = _h_2661;
      e.mem[_t_242 + 37] = _h_2662;
      e.mem[_t_242 + 38] = _h_2663;
      e.mem[_t_242 + 39] = _h_2664;
      WL_CONT = term_tsk(FID_CONTROLS_K297, _t_242);
      WL_IDX = 40;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_243 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_243 + 0] = _h_2620;
      e.mem[_t_243 + 1] = _h_2621;
      e.mem[_t_243 + 2] = _h_2622;
      e.mem[_t_243 + 3] = _h_2623;
      e.mem[_t_243 + 4] = _h_2624;
      return term_tsk(FID_VALIDATION, _t_243);
    }
    r0 = _h_2620;
    r1 = _h_2621;
    r2 = _h_2622;
    r3 = _h_2623;
    r4 = _h_2624;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K297)
  {
    WL_POPN(40);
    Term _h_2666 = STK(0);
    Term _h_2667 = STK(1);
    Term _h_2668 = STK(2);
    Term _h_2669 = STK(3);
    Term _h_2670 = STK(4);
    Term _h_2671 = STK(5);
    Term _h_2672 = STK(6);
    Term _h_2673 = STK(7);
    Term _h_2674 = STK(8);
    Term _h_2675 = STK(9);
    Term _h_2676 = STK(10);
    Term _h_2677 = STK(11);
    Term _h_2678 = STK(12);
    Term _h_2679 = STK(13);
    Term _h_2680 = STK(14);
    Term _h_2681 = STK(15);
    Term _h_2682 = STK(16);
    Term _h_2683 = STK(17);
    Term _h_2684 = STK(18);
    Term _h_2685 = STK(19);
    Term _h_2686 = STK(20);
    Term _h_2687 = STK(21);
    Term _h_2688 = STK(22);
    Term _h_2689 = STK(23);
    Term _h_2690 = STK(24);
    Term _h_2691 = STK(25);
    Term _h_2692 = STK(26);
    Term _h_2693 = STK(27);
    Term _h_2694 = STK(28);
    Term _h_2695 = STK(29);
    Term _h_2696 = STK(30);
    Term _h_2697 = STK(31);
    Term _h_2698 = STK(32);
    Term _h_2699 = STK(33);
    Term _h_2700 = STK(34);
    Term _h_2701 = STK(35);
    Term _h_2702 = STK(36);
    Term _h_2703 = STK(37);
    Term _h_2704 = STK(38);
    Term _h_2705 = STK(39);
    Term _h_2665 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(41);
      STK(0) = _h_2666;
      STK(1) = _h_2667;
      STK(2) = _h_2668;
      STK(3) = _h_2669;
      STK(4) = _h_2670;
      STK(5) = _h_2671;
      STK(6) = _h_2672;
      STK(7) = _h_2673;
      STK(8) = _h_2674;
      STK(9) = _h_2675;
      STK(10) = _h_2676;
      STK(11) = _h_2677;
      STK(12) = _h_2678;
      STK(13) = _h_2679;
      STK(14) = _h_2680;
      STK(15) = _h_2681;
      STK(16) = _h_2682;
      STK(17) = _h_2683;
      STK(18) = _h_2684;
      STK(19) = _h_2685;
      STK(20) = _h_2686;
      STK(21) = _h_2687;
      STK(22) = _h_2688;
      STK(23) = _h_2689;
      STK(24) = _h_2690;
      STK(25) = _h_2691;
      STK(26) = _h_2692;
      STK(27) = _h_2693;
      STK(28) = _h_2694;
      STK(29) = _h_2695;
      STK(30) = _h_2696;
      STK(31) = _h_2697;
      STK(32) = _h_2698;
      STK(33) = _h_2699;
      STK(34) = _h_2700;
      STK(35) = _h_2701;
      STK(36) = _h_2702;
      STK(37) = _h_2703;
      STK(38) = _h_2704;
      STK(39) = _h_2705;
      STK(40) = FID_CONTROLS_K298;
      WL_PUSHN(41);
    } else {
      u64 _t_244 = task_node(e, FID_CONTROLS_K298, WL_CONT, WL_IDX, 1);
      e.mem[_t_244 + 0] = _h_2666;
      e.mem[_t_244 + 1] = _h_2667;
      e.mem[_t_244 + 2] = _h_2668;
      e.mem[_t_244 + 3] = _h_2669;
      e.mem[_t_244 + 4] = _h_2670;
      e.mem[_t_244 + 5] = _h_2671;
      e.mem[_t_244 + 6] = _h_2672;
      e.mem[_t_244 + 7] = _h_2673;
      e.mem[_t_244 + 8] = _h_2674;
      e.mem[_t_244 + 9] = _h_2675;
      e.mem[_t_244 + 10] = _h_2676;
      e.mem[_t_244 + 11] = _h_2677;
      e.mem[_t_244 + 12] = _h_2678;
      e.mem[_t_244 + 13] = _h_2679;
      e.mem[_t_244 + 14] = _h_2680;
      e.mem[_t_244 + 15] = _h_2681;
      e.mem[_t_244 + 16] = _h_2682;
      e.mem[_t_244 + 17] = _h_2683;
      e.mem[_t_244 + 18] = _h_2684;
      e.mem[_t_244 + 19] = _h_2685;
      e.mem[_t_244 + 20] = _h_2686;
      e.mem[_t_244 + 21] = _h_2687;
      e.mem[_t_244 + 22] = _h_2688;
      e.mem[_t_244 + 23] = _h_2689;
      e.mem[_t_244 + 24] = _h_2690;
      e.mem[_t_244 + 25] = _h_2691;
      e.mem[_t_244 + 26] = _h_2692;
      e.mem[_t_244 + 27] = _h_2693;
      e.mem[_t_244 + 28] = _h_2694;
      e.mem[_t_244 + 29] = _h_2695;
      e.mem[_t_244 + 30] = _h_2696;
      e.mem[_t_244 + 31] = _h_2697;
      e.mem[_t_244 + 32] = _h_2698;
      e.mem[_t_244 + 33] = _h_2699;
      e.mem[_t_244 + 34] = _h_2700;
      e.mem[_t_244 + 35] = _h_2701;
      e.mem[_t_244 + 36] = _h_2702;
      e.mem[_t_244 + 37] = _h_2703;
      e.mem[_t_244 + 38] = _h_2704;
      e.mem[_t_244 + 39] = _h_2705;
      WL_CONT = term_tsk(FID_CONTROLS_K298, _t_244);
      WL_IDX = 40;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_245 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_245 + 0] = term_ctr(CID_SCON, STAT_OFF + 1560);
      e.mem[_t_245 + 1] = _h_2665;
      return term_tsk(FID_STRING_APPEND, _t_245);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1560);
    r1 = _h_2665;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CONTROLS_K298)
  {
    WL_POPN(40);
    Term _h_2707 = STK(0);
    Term _h_2708 = STK(1);
    Term _h_2709 = STK(2);
    Term _h_2710 = STK(3);
    Term _h_2711 = STK(4);
    Term _h_2712 = STK(5);
    Term _h_2713 = STK(6);
    Term _h_2714 = STK(7);
    Term _h_2715 = STK(8);
    Term _h_2716 = STK(9);
    Term _h_2717 = STK(10);
    Term _h_2718 = STK(11);
    Term _h_2719 = STK(12);
    Term _h_2720 = STK(13);
    Term _h_2721 = STK(14);
    Term _h_2722 = STK(15);
    Term _h_2723 = STK(16);
    Term _h_2724 = STK(17);
    Term _h_2725 = STK(18);
    Term _h_2726 = STK(19);
    Term _h_2727 = STK(20);
    Term _h_2728 = STK(21);
    Term _h_2729 = STK(22);
    Term _h_2730 = STK(23);
    Term _h_2731 = STK(24);
    Term _h_2732 = STK(25);
    Term _h_2733 = STK(26);
    Term _h_2734 = STK(27);
    Term _h_2735 = STK(28);
    Term _h_2736 = STK(29);
    Term _h_2737 = STK(30);
    Term _h_2738 = STK(31);
    Term _h_2739 = STK(32);
    Term _h_2740 = STK(33);
    Term _h_2741 = STK(34);
    Term _h_2742 = STK(35);
    Term _h_2743 = STK(36);
    Term _h_2744 = STK(37);
    Term _h_2745 = STK(38);
    Term _h_2746 = STK(39);
    Term _h_2706 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_2706);
    e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, _h_2746);
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h_2745);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_1));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h_2744);
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_2743);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, _h_2742);
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _h_2741);
    e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_5));
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, _h_2740);
    e.mem[_nd_7 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_6));
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, _h_2739);
    e.mem[_nd_8 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_7));
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, _h_2738);
    e.mem[_nd_9 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_8));
    u64 _nd_10 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_10 + 0] = rfc_seal(e, _h_2737);
    e.mem[_nd_10 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_9));
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, _h_2736);
    e.mem[_nd_11 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_10));
    u64 _nd_12 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_12 + 0] = rfc_seal(e, _h_2735);
    e.mem[_nd_12 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_11));
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, _h_2734);
    e.mem[_nd_13 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_12));
    u64 _nd_14 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_14 + 0] = rfc_seal(e, _h_2733);
    e.mem[_nd_14 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_13));
    u64 _nd_15 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_15 + 0] = rfc_seal(e, _h_2732);
    e.mem[_nd_15 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_14));
    u64 _nd_16 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_16 + 0] = rfc_seal(e, _h_2731);
    e.mem[_nd_16 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_15));
    u64 _nd_17 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_17 + 0] = rfc_seal(e, _h_2730);
    e.mem[_nd_17 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_16));
    u64 _nd_18 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_18 + 0] = rfc_seal(e, _h_2729);
    e.mem[_nd_18 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_17));
    u64 _nd_19 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_19 + 0] = rfc_seal(e, _h_2728);
    e.mem[_nd_19 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_18));
    u64 _nd_20 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_20 + 0] = rfc_seal(e, _h_2727);
    e.mem[_nd_20 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_19));
    u64 _nd_21 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_21 + 0] = rfc_seal(e, _h_2726);
    e.mem[_nd_21 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_20));
    u64 _nd_22 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_22 + 0] = rfc_seal(e, _h_2725);
    e.mem[_nd_22 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_21));
    u64 _nd_23 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_23 + 0] = rfc_seal(e, _h_2724);
    e.mem[_nd_23 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_22));
    u64 _nd_24 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_24 + 0] = rfc_seal(e, _h_2723);
    e.mem[_nd_24 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_23));
    u64 _nd_25 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_25 + 0] = rfc_seal(e, _h_2722);
    e.mem[_nd_25 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_24));
    u64 _nd_26 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_26 + 0] = rfc_seal(e, _h_2721);
    e.mem[_nd_26 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_25));
    u64 _nd_27 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_27 + 0] = rfc_seal(e, _h_2720);
    e.mem[_nd_27 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_26));
    u64 _nd_28 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_28 + 0] = rfc_seal(e, _h_2719);
    e.mem[_nd_28 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_27));
    u64 _nd_29 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_29 + 0] = rfc_seal(e, _h_2718);
    e.mem[_nd_29 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_28));
    u64 _nd_30 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_30 + 0] = rfc_seal(e, _h_2717);
    e.mem[_nd_30 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_29));
    u64 _nd_31 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_31 + 0] = rfc_seal(e, _h_2716);
    e.mem[_nd_31 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_30));
    u64 _nd_32 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_32 + 0] = rfc_seal(e, _h_2715);
    e.mem[_nd_32 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_31));
    u64 _nd_33 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_33 + 0] = rfc_seal(e, _h_2714);
    e.mem[_nd_33 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_32));
    u64 _nd_34 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_34 + 0] = rfc_seal(e, _h_2713);
    e.mem[_nd_34 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_33));
    u64 _nd_35 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_35 + 0] = rfc_seal(e, _h_2712);
    e.mem[_nd_35 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_34));
    u64 _nd_36 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_36 + 0] = rfc_seal(e, _h_2711);
    e.mem[_nd_36 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_35));
    u64 _nd_37 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_37 + 0] = rfc_seal(e, _h_2710);
    e.mem[_nd_37 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_36));
    u64 _nd_38 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_38 + 0] = rfc_seal(e, _h_2709);
    e.mem[_nd_38 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_37));
    u64 _nd_39 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_39 + 0] = rfc_seal(e, _h_2708);
    e.mem[_nd_39 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_38));
    u64 _nd_40 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_40 + 0] = rfc_seal(e, _h_2707);
    e.mem[_nd_40 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_39));
    r0 = term_ctr(CID_CON, _nd_40);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY)
  {
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _o_0[1];
    if (spin_11(e, _o_0, term_ctr(CID_SCON, STAT_OFF + 146)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_1 = _v_2;
    _v_1 = term_keep(e, _v_1, 1);
    u64 _nd_0 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_0 + 0] = rfc_seal(e, 1);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_1);
    e.mem[_nd_0 + 3] = rfc_seal(e, 1);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_3 = 0;
    Term _o_1[1];
    if (spin_18(e, _o_1, term_ctr(CID_CON, _nd_1)) == 0) {
      return 0;
    }
    _v_3 = _o_1[0];
    _v_0 = _v_3;
    Term _v_4 = 0;
    Term _key_0 = term_ctr(CID_SCON, STAT_OFF + 268);
    _key_0 = term_keep(e, _key_0, 1);
    u64 _nd_2 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_2 + 0] = rfc_seal(e, 0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _key_0);
    e.mem[_nd_2 + 2] = rfc_seal(e, _key_0);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, _nd_2));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_5 = 0;
    Term _o_2[1];
    if (spin_17(e, _o_2, term_ctr(CID_CON, _nd_3)) == 0) {
      return 0;
    }
    _v_5 = _o_2[0];
    _v_4 = _v_5;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ORDINARY_K300;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_ORDINARY_K300, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ORDINARY_K300, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      e.mem[_t_1 + 1] = _v_4;
      return term_tsk(FID_LIST_APPEND, _t_1);
    }
    r0 = _v_0;
    r1 = _v_4;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K300)
  {
    Term _h_0 = r0;
    WL_OPEN
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _o_3[1];
    if (spin_11(e, _o_3, term_ctr(CID_SCON, STAT_OFF + 146)) == 0) {
      return 0;
    }
    _v_8 = _o_3[0];
    _v_7 = _v_8;
    _v_7 = term_keep(e, _v_7, 1);
    u64 _nd_4 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_4 + 0] = rfc_seal(e, 0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _v_7);
    e.mem[_nd_4 + 2] = rfc_seal(e, _v_7);
    e.mem[_nd_4 + 3] = rfc_seal(e, 0);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_4));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_9 = 0;
    Term _o_4[1];
    if (spin_17(e, _o_4, term_ctr(CID_CON, _nd_5)) == 0) {
      return 0;
    }
    _v_9 = _o_4[0];
    _v_6 = _v_9;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_ORDINARY_K301;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_ORDINARY_K301, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_ORDINARY_K301, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_3 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _v_6;
      e.mem[_t_3 + 1] = _h_0;
      return term_tsk(FID_LIST_APPEND, _t_3);
    }
    r0 = _v_6;
    r1 = _h_0;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K301)
  {
    Term _values_0 = r0;
    WL_OPEN
    _values_0 = term_keep(e, _values_0, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _values_0;
      STK(1) = FID_ORDINARY_K302;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_ORDINARY_K302, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _values_0;
      WL_CONT = term_tsk(FID_ORDINARY_K302, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ENTRIES)) {
      u64 _t_5 = task_node(e, FID_ENTRIES, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _values_0;
      return term_tsk(FID_ENTRIES, _t_5);
    }
    r0 = _values_0;
    WL_JMP(FID_ENTRIES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K302)
  {
    WL_POPN(1);
    Term _values_1 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _values_1;
      STK(1) = FID_ORDINARY_K303;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_ORDINARY_K303, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _values_1;
      WL_CONT = term_tsk(FID_ORDINARY_K303, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 1566);
      e.mem[_t_7 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1566);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K303)
  {
    WL_POPN(1);
    Term _values_2 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    _values_2 = term_keep(e, _values_2, 1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _values_2;
      STK(1) = _h_2;
      STK(2) = FID_ORDINARY_K304;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID_ORDINARY_K304, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _values_2;
      e.mem[_t_8 + 1] = _h_2;
      WL_CONT = term_tsk(FID_ORDINARY_K304, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0)) {
      u64 _t_9 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _values_2;
      e.mem[_t_9 + 1] = 0;
      return term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, _t_9);
    }
    r0 = _values_2;
    r1 = 0;
    WL_JMP(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K304)
  {
    WL_POPN(2);
    Term _values_3 = STK(0);
    Term _h_4 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _values_3;
      STK(1) = _h_4;
      STK(2) = FID_ORDINARY_K305;
      WL_PUSHN(3);
    } else {
      u64 _t_10 = task_node(e, FID_ORDINARY_K305, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _values_3;
      e.mem[_t_10 + 1] = _h_4;
      WL_CONT = term_tsk(FID_ORDINARY_K305, _t_10);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ENTRIES)) {
      u64 _t_11 = task_node(e, FID_ENTRIES, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_3;
      return term_tsk(FID_ENTRIES, _t_11);
    }
    r0 = _h_3;
    WL_JMP(FID_ENTRIES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K305)
  {
    WL_POPN(2);
    Term _values_4 = STK(0);
    Term _h_6 = STK(1);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _values_4;
      STK(1) = _h_6;
      STK(2) = FID_ORDINARY_K306;
      WL_PUSHN(3);
    } else {
      u64 _t_12 = task_node(e, FID_ORDINARY_K306, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _values_4;
      e.mem[_t_12 + 1] = _h_6;
      WL_CONT = term_tsk(FID_ORDINARY_K306, _t_12);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 1582);
      e.mem[_t_13 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1582);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K306)
  {
    WL_POPN(2);
    Term _values_5 = STK(0);
    Term _h_8 = STK(1);
    Term _h_7 = r0;
    WL_OPEN
    _values_5 = term_keep(e, _values_5, 1);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _values_5;
      STK(1) = _h_8;
      STK(2) = _h_7;
      STK(3) = FID_ORDINARY_K307;
      WL_PUSHN(4);
    } else {
      u64 _t_14 = task_node(e, FID_ORDINARY_K307, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _values_5;
      e.mem[_t_14 + 1] = _h_8;
      e.mem[_t_14 + 2] = _h_7;
      WL_CONT = term_tsk(FID_ORDINARY_K307, _t_14);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0)) {
      u64 _t_15 = task_node(e, FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _values_5;
      e.mem[_t_15 + 1] = 1;
      return term_tsk(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0, _t_15);
    }
    r0 = _values_5;
    r1 = 1;
    WL_JMP(FID_SCHEMA_FRAGMENTS_FILTER_KIND_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K307)
  {
    WL_POPN(3);
    Term _values_6 = STK(0);
    Term _h_10 = STK(1);
    Term _h_11 = STK(2);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _values_6;
      STK(1) = _h_10;
      STK(2) = _h_11;
      STK(3) = FID_ORDINARY_K308;
      WL_PUSHN(4);
    } else {
      u64 _t_16 = task_node(e, FID_ORDINARY_K308, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _values_6;
      e.mem[_t_16 + 1] = _h_10;
      e.mem[_t_16 + 2] = _h_11;
      WL_CONT = term_tsk(FID_ORDINARY_K308, _t_16);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ENTRIES)) {
      u64 _t_17 = task_node(e, FID_ENTRIES, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_9;
      return term_tsk(FID_ENTRIES, _t_17);
    }
    r0 = _h_9;
    WL_JMP(FID_ENTRIES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K308)
  {
    WL_POPN(3);
    Term _values_7 = STK(0);
    Term _h_13 = STK(1);
    Term _h_14 = STK(2);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _values_7;
      STK(1) = _h_13;
      STK(2) = _h_14;
      STK(3) = FID_ORDINARY_K309;
      WL_PUSHN(4);
    } else {
      u64 _t_18 = task_node(e, FID_ORDINARY_K309, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _values_7;
      e.mem[_t_18 + 1] = _h_13;
      e.mem[_t_18 + 2] = _h_14;
      WL_CONT = term_tsk(FID_ORDINARY_K309, _t_18);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_ctr(CID_SCON, STAT_OFF + 1424);
      e.mem[_t_19 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1424);
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K309)
  {
    WL_POPN(3);
    Term _values_8 = STK(0);
    Term _h_16 = STK(1);
    Term _h_17 = STK(2);
    Term _h_15 = r0;
    WL_OPEN
    _values_8 = term_keep(e, _values_8, 1);
    if (seq) {
      WL_ROOM(5);
      STK(0) = _values_8;
      STK(1) = _h_16;
      STK(2) = _h_17;
      STK(3) = _h_15;
      STK(4) = FID_ORDINARY_K310;
      WL_PUSHN(5);
    } else {
      u64 _t_20 = task_node(e, FID_ORDINARY_K310, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _values_8;
      e.mem[_t_20 + 1] = _h_16;
      e.mem[_t_20 + 2] = _h_17;
      e.mem[_t_20 + 3] = _h_15;
      WL_CONT = term_tsk(FID_ORDINARY_K310, _t_20);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_21 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _values_8;
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_21);
    }
    r0 = _values_8;
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K310)
  {
    WL_POPN(4);
    Term _values_9 = STK(0);
    Term _h_23 = STK(1);
    Term _h_24 = STK(2);
    Term _h_25 = STK(3);
    u32 _h_18 = r0;
    u32 _h_19 = r1;
    u32 _h_20 = r2;
    Term _h_21 = r3;
    Term _h_22 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _values_9;
      STK(1) = _h_23;
      STK(2) = _h_24;
      STK(3) = _h_25;
      STK(4) = FID_ORDINARY_K311;
      WL_PUSHN(5);
    } else {
      u64 _t_22 = task_node(e, FID_ORDINARY_K311, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _values_9;
      e.mem[_t_22 + 1] = _h_23;
      e.mem[_t_22 + 2] = _h_24;
      e.mem[_t_22 + 3] = _h_25;
      WL_CONT = term_tsk(FID_ORDINARY_K311, _t_22);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_23 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_18;
      e.mem[_t_23 + 1] = _h_19;
      e.mem[_t_23 + 2] = _h_20;
      e.mem[_t_23 + 3] = _h_21;
      e.mem[_t_23 + 4] = _h_22;
      return term_tsk(FID_VALIDATION, _t_23);
    }
    r0 = _h_18;
    r1 = _h_19;
    r2 = _h_20;
    r3 = _h_21;
    r4 = _h_22;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K311)
  {
    WL_POPN(4);
    Term _values_10 = STK(0);
    Term _h_27 = STK(1);
    Term _h_28 = STK(2);
    Term _h_29 = STK(3);
    Term _h_26 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _values_10;
      STK(1) = _h_27;
      STK(2) = _h_28;
      STK(3) = _h_29;
      STK(4) = FID_ORDINARY_K312;
      WL_PUSHN(5);
    } else {
      u64 _t_24 = task_node(e, FID_ORDINARY_K312, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _values_10;
      e.mem[_t_24 + 1] = _h_27;
      e.mem[_t_24 + 2] = _h_28;
      e.mem[_t_24 + 3] = _h_29;
      WL_CONT = term_tsk(FID_ORDINARY_K312, _t_24);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 1592);
      e.mem[_t_25 + 1] = _h_26;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1592);
    r1 = _h_26;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K312)
  {
    WL_POPN(4);
    Term _values_11 = STK(0);
    Term _h_31 = STK(1);
    Term _h_32 = STK(2);
    Term _h_33 = STK(3);
    Term _h_30 = r0;
    WL_OPEN
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _o_5[1];
    if (spin_11(e, _o_5, term_ctr(CID_SCON, STAT_OFF + 146)) == 0) {
      return 0;
    }
    _v_12 = _o_5[0];
    _v_11 = _v_12;
    _v_11 = term_keep(e, _v_11, 1);
    u64 _nd_6 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_6 + 0] = rfc_seal(e, 0);
    e.mem[_nd_6 + 1] = rfc_seal(e, _v_11);
    e.mem[_nd_6 + 2] = rfc_seal(e, _v_11);
    e.mem[_nd_6 + 3] = rfc_seal(e, 0);
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_6));
    e.mem[_nd_7 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_13 = 0;
    Term _o_6[1];
    if (spin_17(e, _o_6, term_ctr(CID_CON, _nd_7)) == 0) {
      return 0;
    }
    _v_13 = _o_6[0];
    _v_10 = _v_13;
    Term _v_14 = 0;
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _o_7[1];
    if (spin_11(e, _o_7, term_ctr(CID_SCON, STAT_OFF + 146)) == 0) {
      return 0;
    }
    _v_16 = _o_7[0];
    _v_15 = _v_16;
    _v_15 = term_keep(e, _v_15, 1);
    u64 _nd_8 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_8 + 0] = rfc_seal(e, 0);
    e.mem[_nd_8 + 1] = rfc_seal(e, _v_15);
    e.mem[_nd_8 + 2] = rfc_seal(e, _v_15);
    e.mem[_nd_8 + 3] = rfc_seal(e, 0);
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_8));
    e.mem[_nd_9 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_17 = 0;
    Term _o_8[1];
    if (spin_17(e, _o_8, term_ctr(CID_CON, _nd_9)) == 0) {
      return 0;
    }
    _v_17 = _o_8[0];
    _v_14 = _v_17;
    if (seq) {
      WL_ROOM(6);
      STK(0) = _values_11;
      STK(1) = _h_31;
      STK(2) = _h_32;
      STK(3) = _h_33;
      STK(4) = _h_30;
      STK(5) = FID_ORDINARY_K313;
      WL_PUSHN(6);
    } else {
      u64 _t_26 = task_node(e, FID_ORDINARY_K313, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _values_11;
      e.mem[_t_26 + 1] = _h_31;
      e.mem[_t_26 + 2] = _h_32;
      e.mem[_t_26 + 3] = _h_33;
      e.mem[_t_26 + 4] = _h_30;
      WL_CONT = term_tsk(FID_ORDINARY_K313, _t_26);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_27 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _v_10;
      e.mem[_t_27 + 1] = _v_14;
      return term_tsk(FID_LIST_APPEND, _t_27);
    }
    r0 = _v_10;
    r1 = _v_14;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K313)
  {
    WL_POPN(5);
    Term _values_12 = STK(0);
    Term _h_35 = STK(1);
    Term _h_36 = STK(2);
    Term _h_37 = STK(3);
    Term _h_38 = STK(4);
    Term _h_34 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _values_12;
      STK(1) = _h_35;
      STK(2) = _h_36;
      STK(3) = _h_37;
      STK(4) = _h_38;
      STK(5) = FID_ORDINARY_K314;
      WL_PUSHN(6);
    } else {
      u64 _t_28 = task_node(e, FID_ORDINARY_K314, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _values_12;
      e.mem[_t_28 + 1] = _h_35;
      e.mem[_t_28 + 2] = _h_36;
      e.mem[_t_28 + 3] = _h_37;
      e.mem[_t_28 + 4] = _h_38;
      WL_CONT = term_tsk(FID_ORDINARY_K314, _t_28);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_VALIDATE_0)) {
      u64 _t_29 = task_node(e, FID_SCHEMA_FRAGMENTS_VALIDATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _h_34;
      return term_tsk(FID_SCHEMA_FRAGMENTS_VALIDATE_0, _t_29);
    }
    r0 = _h_34;
    WL_JMP(FID_SCHEMA_FRAGMENTS_VALIDATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K314)
  {
    WL_POPN(5);
    Term _values_13 = STK(0);
    Term _h_44 = STK(1);
    Term _h_45 = STK(2);
    Term _h_46 = STK(3);
    Term _h_47 = STK(4);
    u32 _h_39 = r0;
    u32 _h_40 = r1;
    u32 _h_41 = r2;
    Term _h_42 = r3;
    Term _h_43 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _values_13;
      STK(1) = _h_44;
      STK(2) = _h_45;
      STK(3) = _h_46;
      STK(4) = _h_47;
      STK(5) = FID_ORDINARY_K315;
      WL_PUSHN(6);
    } else {
      u64 _t_30 = task_node(e, FID_ORDINARY_K315, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _values_13;
      e.mem[_t_30 + 1] = _h_44;
      e.mem[_t_30 + 2] = _h_45;
      e.mem[_t_30 + 3] = _h_46;
      e.mem[_t_30 + 4] = _h_47;
      WL_CONT = term_tsk(FID_ORDINARY_K315, _t_30);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_31 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_39;
      e.mem[_t_31 + 1] = _h_40;
      e.mem[_t_31 + 2] = _h_41;
      e.mem[_t_31 + 3] = _h_42;
      e.mem[_t_31 + 4] = _h_43;
      return term_tsk(FID_VALIDATION, _t_31);
    }
    r0 = _h_39;
    r1 = _h_40;
    r2 = _h_41;
    r3 = _h_42;
    r4 = _h_43;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K315)
  {
    WL_POPN(5);
    Term _values_14 = STK(0);
    Term _h_49 = STK(1);
    Term _h_50 = STK(2);
    Term _h_51 = STK(3);
    Term _h_52 = STK(4);
    Term _h_48 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _values_14;
      STK(1) = _h_49;
      STK(2) = _h_50;
      STK(3) = _h_51;
      STK(4) = _h_52;
      STK(5) = FID_ORDINARY_K316;
      WL_PUSHN(6);
    } else {
      u64 _t_32 = task_node(e, FID_ORDINARY_K316, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _values_14;
      e.mem[_t_32 + 1] = _h_49;
      e.mem[_t_32 + 2] = _h_50;
      e.mem[_t_32 + 3] = _h_51;
      e.mem[_t_32 + 4] = _h_52;
      WL_CONT = term_tsk(FID_ORDINARY_K316, _t_32);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_33 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = term_ctr(CID_SCON, STAT_OFF + 1608);
      e.mem[_t_33 + 1] = _h_48;
      return term_tsk(FID_STRING_APPEND, _t_33);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1608);
    r1 = _h_48;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K316)
  {
    WL_POPN(5);
    Term _values_15 = STK(0);
    Term _h_54 = STK(1);
    Term _h_55 = STK(2);
    Term _h_56 = STK(3);
    Term _h_57 = STK(4);
    Term _h_53 = r0;
    WL_OPEN
    _values_15 = term_keep(e, _values_15, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _values_15;
      STK(1) = _h_54;
      STK(2) = _h_55;
      STK(3) = _h_56;
      STK(4) = _h_57;
      STK(5) = _h_53;
      STK(6) = FID_ORDINARY_K317;
      WL_PUSHN(7);
    } else {
      u64 _t_34 = task_node(e, FID_ORDINARY_K317, WL_CONT, WL_IDX, 1);
      e.mem[_t_34 + 0] = _values_15;
      e.mem[_t_34 + 1] = _h_54;
      e.mem[_t_34 + 2] = _h_55;
      e.mem[_t_34 + 3] = _h_56;
      e.mem[_t_34 + 4] = _h_57;
      e.mem[_t_34 + 5] = _h_53;
      WL_CONT = term_tsk(FID_ORDINARY_K317, _t_34);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0)) {
      u64 _t_35 = task_node(e, FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _values_15;
      return term_tsk(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0, _t_35);
    }
    r0 = _values_15;
    WL_JMP(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K317)
  {
    WL_POPN(6);
    Term _values_16 = STK(0);
    Term _h_59 = STK(1);
    Term _h_60 = STK(2);
    Term _h_61 = STK(3);
    Term _h_62 = STK(4);
    Term _h_63 = STK(5);
    Term _h_58 = r0;
    WL_OPEN
    _values_16 = term_keep(e, _values_16, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _values_16;
      STK(1) = _h_59;
      STK(2) = _h_60;
      STK(3) = _h_61;
      STK(4) = _h_62;
      STK(5) = _h_63;
      STK(6) = FID_ORDINARY_K318;
      WL_PUSHN(7);
    } else {
      u64 _t_36 = task_node(e, FID_ORDINARY_K318, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _values_16;
      e.mem[_t_36 + 1] = _h_59;
      e.mem[_t_36 + 2] = _h_60;
      e.mem[_t_36 + 3] = _h_61;
      e.mem[_t_36 + 4] = _h_62;
      e.mem[_t_36 + 5] = _h_63;
      WL_CONT = term_tsk(FID_ORDINARY_K318, _t_36);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0)) {
      u64 _t_37 = task_node(e, FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = _h_58;
      e.mem[_t_37 + 1] = _values_16;
      return term_tsk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0, _t_37);
    }
    r0 = _h_58;
    r1 = _values_16;
    WL_JMP(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K318)
  {
    WL_POPN(6);
    Term _values_17 = STK(0);
    Term _h_69 = STK(1);
    Term _h_70 = STK(2);
    Term _h_71 = STK(3);
    Term _h_72 = STK(4);
    Term _h_73 = STK(5);
    u32 _h_64 = r0;
    u32 _h_65 = r1;
    u32 _h_66 = r2;
    Term _h_67 = r3;
    Term _h_68 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _values_17;
      STK(1) = _h_69;
      STK(2) = _h_70;
      STK(3) = _h_71;
      STK(4) = _h_72;
      STK(5) = _h_73;
      STK(6) = FID_ORDINARY_K319;
      WL_PUSHN(7);
    } else {
      u64 _t_38 = task_node(e, FID_ORDINARY_K319, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _values_17;
      e.mem[_t_38 + 1] = _h_69;
      e.mem[_t_38 + 2] = _h_70;
      e.mem[_t_38 + 3] = _h_71;
      e.mem[_t_38 + 4] = _h_72;
      e.mem[_t_38 + 5] = _h_73;
      WL_CONT = term_tsk(FID_ORDINARY_K319, _t_38);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_39 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _h_64;
      e.mem[_t_39 + 1] = _h_65;
      e.mem[_t_39 + 2] = _h_66;
      e.mem[_t_39 + 3] = _h_67;
      e.mem[_t_39 + 4] = _h_68;
      return term_tsk(FID_VALIDATION, _t_39);
    }
    r0 = _h_64;
    r1 = _h_65;
    r2 = _h_66;
    r3 = _h_67;
    r4 = _h_68;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K319)
  {
    WL_POPN(6);
    Term _values_18 = STK(0);
    Term _h_75 = STK(1);
    Term _h_76 = STK(2);
    Term _h_77 = STK(3);
    Term _h_78 = STK(4);
    Term _h_79 = STK(5);
    Term _h_74 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _values_18;
      STK(1) = _h_75;
      STK(2) = _h_76;
      STK(3) = _h_77;
      STK(4) = _h_78;
      STK(5) = _h_79;
      STK(6) = FID_ORDINARY_K320;
      WL_PUSHN(7);
    } else {
      u64 _t_40 = task_node(e, FID_ORDINARY_K320, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _values_18;
      e.mem[_t_40 + 1] = _h_75;
      e.mem[_t_40 + 2] = _h_76;
      e.mem[_t_40 + 3] = _h_77;
      e.mem[_t_40 + 4] = _h_78;
      e.mem[_t_40 + 5] = _h_79;
      WL_CONT = term_tsk(FID_ORDINARY_K320, _t_40);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_41 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = term_ctr(CID_SCON, STAT_OFF + 1632);
      e.mem[_t_41 + 1] = _h_74;
      return term_tsk(FID_STRING_APPEND, _t_41);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1632);
    r1 = _h_74;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K320)
  {
    WL_POPN(6);
    Term _values_19 = STK(0);
    Term _h_81 = STK(1);
    Term _h_82 = STK(2);
    Term _h_83 = STK(3);
    Term _h_84 = STK(4);
    Term _h_85 = STK(5);
    Term _h_80 = r0;
    WL_OPEN
    _values_19 = term_keep(e, _values_19, 1);
    if (seq) {
      WL_ROOM(8);
      STK(0) = _values_19;
      STK(1) = _h_81;
      STK(2) = _h_82;
      STK(3) = _h_83;
      STK(4) = _h_84;
      STK(5) = _h_85;
      STK(6) = _h_80;
      STK(7) = FID_ORDINARY_K321;
      WL_PUSHN(8);
    } else {
      u64 _t_42 = task_node(e, FID_ORDINARY_K321, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _values_19;
      e.mem[_t_42 + 1] = _h_81;
      e.mem[_t_42 + 2] = _h_82;
      e.mem[_t_42 + 3] = _h_83;
      e.mem[_t_42 + 4] = _h_84;
      e.mem[_t_42 + 5] = _h_85;
      e.mem[_t_42 + 6] = _h_80;
      WL_CONT = term_tsk(FID_ORDINARY_K321, _t_42);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0)) {
      u64 _t_43 = task_node(e, FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _values_19;
      return term_tsk(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0, _t_43);
    }
    r0 = _values_19;
    WL_JMP(FID_SCHEMA_FRAGMENTS_BARE_ENTRIES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K321)
  {
    WL_POPN(7);
    Term _values_20 = STK(0);
    Term _h_87 = STK(1);
    Term _h_88 = STK(2);
    Term _h_89 = STK(3);
    Term _h_90 = STK(4);
    Term _h_91 = STK(5);
    Term _h_92 = STK(6);
    Term _h_86 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_87;
      STK(1) = _h_88;
      STK(2) = _h_89;
      STK(3) = _h_90;
      STK(4) = _h_91;
      STK(5) = _h_92;
      STK(6) = FID_ORDINARY_K322;
      WL_PUSHN(7);
    } else {
      u64 _t_44 = task_node(e, FID_ORDINARY_K322, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _h_87;
      e.mem[_t_44 + 1] = _h_88;
      e.mem[_t_44 + 2] = _h_89;
      e.mem[_t_44 + 3] = _h_90;
      e.mem[_t_44 + 4] = _h_91;
      e.mem[_t_44 + 5] = _h_92;
      WL_CONT = term_tsk(FID_ORDINARY_K322, _t_44);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0)) {
      u64 _t_45 = task_node(e, FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _values_20;
      e.mem[_t_45 + 1] = _h_86;
      return term_tsk(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0, _t_45);
    }
    r0 = _values_20;
    r1 = _h_86;
    WL_JMP(FID_SCHEMA_FRAGMENTS_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K322)
  {
    WL_POPN(6);
    Term _h_98 = STK(0);
    Term _h_99 = STK(1);
    Term _h_100 = STK(2);
    Term _h_101 = STK(3);
    Term _h_102 = STK(4);
    Term _h_103 = STK(5);
    u32 _h_93 = r0;
    u32 _h_94 = r1;
    u32 _h_95 = r2;
    Term _h_96 = r3;
    Term _h_97 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_98;
      STK(1) = _h_99;
      STK(2) = _h_100;
      STK(3) = _h_101;
      STK(4) = _h_102;
      STK(5) = _h_103;
      STK(6) = FID_ORDINARY_K323;
      WL_PUSHN(7);
    } else {
      u64 _t_46 = task_node(e, FID_ORDINARY_K323, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _h_98;
      e.mem[_t_46 + 1] = _h_99;
      e.mem[_t_46 + 2] = _h_100;
      e.mem[_t_46 + 3] = _h_101;
      e.mem[_t_46 + 4] = _h_102;
      e.mem[_t_46 + 5] = _h_103;
      WL_CONT = term_tsk(FID_ORDINARY_K323, _t_46);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_VALIDATION)) {
      u64 _t_47 = task_node(e, FID_VALIDATION, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = _h_93;
      e.mem[_t_47 + 1] = _h_94;
      e.mem[_t_47 + 2] = _h_95;
      e.mem[_t_47 + 3] = _h_96;
      e.mem[_t_47 + 4] = _h_97;
      return term_tsk(FID_VALIDATION, _t_47);
    }
    r0 = _h_93;
    r1 = _h_94;
    r2 = _h_95;
    r3 = _h_96;
    r4 = _h_97;
    WL_JMP(FID_VALIDATION);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K323)
  {
    WL_POPN(6);
    Term _h_105 = STK(0);
    Term _h_106 = STK(1);
    Term _h_107 = STK(2);
    Term _h_108 = STK(3);
    Term _h_109 = STK(4);
    Term _h_110 = STK(5);
    Term _h_104 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _h_105;
      STK(1) = _h_106;
      STK(2) = _h_107;
      STK(3) = _h_108;
      STK(4) = _h_109;
      STK(5) = _h_110;
      STK(6) = FID_ORDINARY_K324;
      WL_PUSHN(7);
    } else {
      u64 _t_48 = task_node(e, FID_ORDINARY_K324, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _h_105;
      e.mem[_t_48 + 1] = _h_106;
      e.mem[_t_48 + 2] = _h_107;
      e.mem[_t_48 + 3] = _h_108;
      e.mem[_t_48 + 4] = _h_109;
      e.mem[_t_48 + 5] = _h_110;
      WL_CONT = term_tsk(FID_ORDINARY_K324, _t_48);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_49 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = term_ctr(CID_SCON, STAT_OFF + 1668);
      e.mem[_t_49 + 1] = _h_104;
      return term_tsk(FID_STRING_APPEND, _t_49);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 1668);
    r1 = _h_104;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K324)
  {
    WL_POPN(6);
    Term _h_112 = STK(0);
    Term _h_113 = STK(1);
    Term _h_114 = STK(2);
    Term _h_115 = STK(3);
    Term _h_116 = STK(4);
    Term _h_117 = STK(5);
    Term _h_111 = r0;
    WL_OPEN
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _o_9[1];
    if (spin_11(e, _o_9, term_ctr(CID_SCON, STAT_OFF + 146)) == 0) {
      return 0;
    }
    _v_20 = _o_9[0];
    _v_19 = _v_20;
    _v_19 = term_keep(e, _v_19, 1);
    u64 _nd_10 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_10 + 0] = rfc_seal(e, 1);
    e.mem[_nd_10 + 1] = rfc_seal(e, _v_19);
    e.mem[_nd_10 + 2] = rfc_seal(e, _v_19);
    e.mem[_nd_10 + 3] = rfc_seal(e, 1);
    u64 _nd_11 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_10));
    e.mem[_nd_11 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_21 = 0;
    Term _o_10[1];
    if (spin_18(e, _o_10, term_ctr(CID_CON, _nd_11)) == 0) {
      return 0;
    }
    _v_21 = _o_10[0];
    _v_18 = _v_21;
    Term _v_22 = 0;
    Term _key_1 = term_ctr(CID_SCON, STAT_OFF + 268);
    _key_1 = term_keep(e, _key_1, 1);
    u64 _nd_12 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_12 + 0] = rfc_seal(e, 0);
    e.mem[_nd_12 + 1] = rfc_seal(e, _key_1);
    e.mem[_nd_12 + 2] = rfc_seal(e, _key_1);
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_ENTRY, _nd_12));
    e.mem[_nd_13 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_23 = 0;
    Term _o_11[1];
    if (spin_17(e, _o_11, term_ctr(CID_CON, _nd_13)) == 0) {
      return 0;
    }
    _v_23 = _o_11[0];
    _v_22 = _v_23;
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_112;
      STK(1) = _h_113;
      STK(2) = _h_114;
      STK(3) = _h_115;
      STK(4) = _h_116;
      STK(5) = _h_117;
      STK(6) = _h_111;
      STK(7) = FID_ORDINARY_K325;
      WL_PUSHN(8);
    } else {
      u64 _t_50 = task_node(e, FID_ORDINARY_K325, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _h_112;
      e.mem[_t_50 + 1] = _h_113;
      e.mem[_t_50 + 2] = _h_114;
      e.mem[_t_50 + 3] = _h_115;
      e.mem[_t_50 + 4] = _h_116;
      e.mem[_t_50 + 5] = _h_117;
      e.mem[_t_50 + 6] = _h_111;
      WL_CONT = term_tsk(FID_ORDINARY_K325, _t_50);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_51 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = _v_18;
      e.mem[_t_51 + 1] = _v_22;
      return term_tsk(FID_LIST_APPEND, _t_51);
    }
    r0 = _v_18;
    r1 = _v_22;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K325)
  {
    WL_POPN(7);
    Term _h_119 = STK(0);
    Term _h_120 = STK(1);
    Term _h_121 = STK(2);
    Term _h_122 = STK(3);
    Term _h_123 = STK(4);
    Term _h_124 = STK(5);
    Term _h_125 = STK(6);
    Term _h_118 = r0;
    WL_OPEN
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _o_12[1];
    if (spin_11(e, _o_12, term_ctr(CID_SCON, STAT_OFF + 146)) == 0) {
      return 0;
    }
    _v_26 = _o_12[0];
    _v_25 = _v_26;
    _v_25 = term_keep(e, _v_25, 1);
    u64 _nd_14 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_14 + 0] = rfc_seal(e, 0);
    e.mem[_nd_14 + 1] = rfc_seal(e, _v_25);
    e.mem[_nd_14 + 2] = rfc_seal(e, _v_25);
    e.mem[_nd_14 + 3] = rfc_seal(e, 0);
    u64 _nd_15 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_15 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_14));
    e.mem[_nd_15 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_27 = 0;
    Term _o_13[1];
    if (spin_17(e, _o_13, term_ctr(CID_CON, _nd_15)) == 0) {
      return 0;
    }
    _v_27 = _o_13[0];
    _v_24 = _v_27;
    Term _fv_0[1];
    _fv_0[0] = 41ull;
    Term _fv_1[1];
    _fv_1[0] = 43ull;
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_119;
      STK(1) = _h_120;
      STK(2) = _h_121;
      STK(3) = _h_122;
      STK(4) = _h_123;
      STK(5) = _h_124;
      STK(6) = _h_125;
      STK(7) = FID_ORDINARY_K326;
      WL_PUSHN(8);
    } else {
      u64 _t_52 = task_node(e, FID_ORDINARY_K326, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _h_119;
      e.mem[_t_52 + 1] = _h_120;
      e.mem[_t_52 + 2] = _h_121;
      e.mem[_t_52 + 3] = _h_122;
      e.mem[_t_52 + 4] = _h_123;
      e.mem[_t_52 + 5] = _h_124;
      e.mem[_t_52 + 6] = _h_125;
      WL_CONT = term_tsk(FID_ORDINARY_K326, _t_52);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_MERGE_0)) {
      u64 _t_53 = task_node(e, FID_SCHEMA_FRAGMENTS_MERGE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = _v_24;
      e.mem[_t_53 + 1] = blk_new(e, 0, 0, 0, 1, _fv_0);
      e.mem[_t_53 + 2] = _h_118;
      e.mem[_t_53 + 3] = blk_new(e, 0, 0, 0, 1, _fv_1);
      return term_tsk(FID_SCHEMA_FRAGMENTS_MERGE_0, _t_53);
    }
    r0 = _v_24;
    r1 = blk_new(e, 0, 0, 0, 1, _fv_0);
    r2 = _h_118;
    r3 = blk_new(e, 0, 0, 0, 1, _fv_1);
    WL_JMP(FID_SCHEMA_FRAGMENTS_MERGE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K326)
  {
    WL_POPN(7);
    Term _h_135 = STK(0);
    Term _h_136 = STK(1);
    Term _h_137 = STK(2);
    Term _h_138 = STK(3);
    Term _h_139 = STK(4);
    Term _h_140 = STK(5);
    Term _h_141 = STK(6);
    u32 _h_126 = r0;
    Term _h_127 = r1;
    Term _h_128 = r2;
    Term _h_129 = r3;
    Term _h_130 = r4;
    Term _h_131 = r5;
    Term _h_132 = r6;
    Term _h_133 = r7;
    Term _h_134 = r8;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _h_135;
      STK(1) = _h_136;
      STK(2) = _h_137;
      STK(3) = _h_138;
      STK(4) = _h_139;
      STK(5) = _h_140;
      STK(6) = _h_141;
      STK(7) = FID_ORDINARY_K327;
      WL_PUSHN(8);
    } else {
      u64 _t_54 = task_node(e, FID_ORDINARY_K327, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _h_135;
      e.mem[_t_54 + 1] = _h_136;
      e.mem[_t_54 + 2] = _h_137;
      e.mem[_t_54 + 3] = _h_138;
      e.mem[_t_54 + 4] = _h_139;
      e.mem[_t_54 + 5] = _h_140;
      e.mem[_t_54 + 6] = _h_141;
      WL_CONT = term_tsk(FID_ORDINARY_K327, _t_54);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MERGE)) {
      u64 _t_55 = task_node(e, FID_MERGE, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = _h_126;
      e.mem[_t_55 + 1] = _h_127;
      e.mem[_t_55 + 2] = _h_128;
      e.mem[_t_55 + 3] = _h_129;
      e.mem[_t_55 + 4] = _h_130;
      e.mem[_t_55 + 5] = _h_131;
      e.mem[_t_55 + 6] = _h_132;
      e.mem[_t_55 + 7] = _h_133;
      e.mem[_t_55 + 8] = _h_134;
      return term_tsk(FID_MERGE, _t_55);
    }
    r0 = _h_126;
    r1 = _h_127;
    r2 = _h_128;
    r3 = _h_129;
    r4 = _h_130;
    r5 = _h_131;
    r6 = _h_132;
    r7 = _h_133;
    r8 = _h_134;
    WL_JMP(FID_MERGE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K327)
  {
    WL_POPN(7);
    Term _h_152 = STK(0);
    Term _h_153 = STK(1);
    Term _h_154 = STK(2);
    Term _h_155 = STK(3);
    Term _h_156 = STK(4);
    Term _h_157 = STK(5);
    Term _h_158 = STK(6);
    u32 _h_142 = r0;
    Term _h_143 = r1;
    Term _h_144 = r2;
    Term _h_145 = r3;
    Term _h_146 = r4;
    Term _h_147 = r5;
    Term _h_148 = r6;
    Term _h_149 = r7;
    Term _h_150 = r8;
    Term _h_151 = r9;
    WL_OPEN
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _o_14[1];
    if (spin_11(e, _o_14, term_ctr(CID_SCON, STAT_OFF + 146)) == 0) {
      return 0;
    }
    _v_30 = _o_14[0];
    _v_29 = _v_30;
    _v_29 = term_keep(e, _v_29, 1);
    u64 _nd_16 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_16 + 0] = rfc_seal(e, 0);
    e.mem[_nd_16 + 1] = rfc_seal(e, _v_29);
    e.mem[_nd_16 + 2] = rfc_seal(e, _v_29);
    e.mem[_nd_16 + 3] = rfc_seal(e, 0);
    u64 _nd_17 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_17 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_16));
    e.mem[_nd_17 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_31 = 0;
    Term _o_15[1];
    if (spin_17(e, _o_15, term_ctr(CID_CON, _nd_17)) == 0) {
      return 0;
    }
    _v_31 = _o_15[0];
    _v_28 = _v_31;
    Term _fv_2[1];
    _fv_2[0] = 41ull;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _o_16[1];
    if (spin_11(e, _o_16, term_ctr(CID_SCON, STAT_OFF + 146)) == 0) {
      return 0;
    }
    _v_34 = _o_16[0];
    _v_33 = _v_34;
    _v_33 = term_keep(e, _v_33, 1);
    u64 _nd_18 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_18 + 0] = rfc_seal(e, 0);
    e.mem[_nd_18 + 1] = rfc_seal(e, _v_33);
    e.mem[_nd_18 + 2] = rfc_seal(e, _v_33);
    e.mem[_nd_18 + 3] = rfc_seal(e, 0);
    u64 _nd_19 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_19 + 0] = rfc_seal(e, term_ctr(CID_SCHEMA_FRAGMENTS_CLASSIFIED, _nd_18));
    e.mem[_nd_19 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _v_35 = 0;
    Term _o_17[1];
    if (spin_17(e, _o_17, term_ctr(CID_CON, _nd_19)) == 0) {
      return 0;
    }
    _v_35 = _o_17[0];
    _v_32 = _v_35;
    Term _fv_3[1];
    _fv_3[0] = 43ull;
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_152;
      STK(1) = _h_153;
      STK(2) = _h_154;
      STK(3) = _h_155;
      STK(4) = _h_156;
      STK(5) = _h_157;
      STK(6) = _h_158;
      STK(7) = _h_142;
      STK(8) = _h_143;
      STK(9) = _h_144;
      STK(10) = _h_145;
      STK(11) = _h_146;
      STK(12) = _h_147;
      STK(13) = _h_148;
      STK(14) = _h_149;
      STK(15) = _h_150;
      STK(16) = _h_151;
      STK(17) = FID_ORDINARY_K328;
      WL_PUSHN(18);
    } else {
      u64 _t_56 = task_node(e, FID_ORDINARY_K328, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_152;
      e.mem[_t_56 + 1] = _h_153;
      e.mem[_t_56 + 2] = _h_154;
      e.mem[_t_56 + 3] = _h_155;
      e.mem[_t_56 + 4] = _h_156;
      e.mem[_t_56 + 5] = _h_157;
      e.mem[_t_56 + 6] = _h_158;
      e.mem[_t_56 + 7] = _h_142;
      e.mem[_t_56 + 8] = _h_143;
      e.mem[_t_56 + 9] = _h_144;
      e.mem[_t_56 + 10] = _h_145;
      e.mem[_t_56 + 11] = _h_146;
      e.mem[_t_56 + 12] = _h_147;
      e.mem[_t_56 + 13] = _h_148;
      e.mem[_t_56 + 14] = _h_149;
      e.mem[_t_56 + 15] = _h_150;
      e.mem[_t_56 + 16] = _h_151;
      WL_CONT = term_tsk(FID_ORDINARY_K328, _t_56);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_SCHEMA_FRAGMENTS_MERGE_0)) {
      u64 _t_57 = task_node(e, FID_SCHEMA_FRAGMENTS_MERGE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = _v_28;
      e.mem[_t_57 + 1] = blk_new(e, 0, 0, 0, 1, _fv_2);
      e.mem[_t_57 + 2] = _v_32;
      e.mem[_t_57 + 3] = blk_new(e, 0, 0, 0, 1, _fv_3);
      return term_tsk(FID_SCHEMA_FRAGMENTS_MERGE_0, _t_57);
    }
    r0 = _v_28;
    r1 = blk_new(e, 0, 0, 0, 1, _fv_2);
    r2 = _v_32;
    r3 = blk_new(e, 0, 0, 0, 1, _fv_3);
    WL_JMP(FID_SCHEMA_FRAGMENTS_MERGE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K328)
  {
    WL_POPN(17);
    Term _h_168 = STK(0);
    Term _h_169 = STK(1);
    Term _h_170 = STK(2);
    Term _h_171 = STK(3);
    Term _h_172 = STK(4);
    Term _h_173 = STK(5);
    Term _h_174 = STK(6);
    u32 _h_175 = STK(7);
    Term _h_176 = STK(8);
    Term _h_177 = STK(9);
    Term _h_178 = STK(10);
    Term _h_179 = STK(11);
    Term _h_180 = STK(12);
    Term _h_181 = STK(13);
    Term _h_182 = STK(14);
    Term _h_183 = STK(15);
    Term _h_184 = STK(16);
    u32 _h_159 = r0;
    Term _h_160 = r1;
    Term _h_161 = r2;
    Term _h_162 = r3;
    Term _h_163 = r4;
    Term _h_164 = r5;
    Term _h_165 = r6;
    Term _h_166 = r7;
    Term _h_167 = r8;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_168;
      STK(1) = _h_169;
      STK(2) = _h_170;
      STK(3) = _h_171;
      STK(4) = _h_172;
      STK(5) = _h_173;
      STK(6) = _h_174;
      STK(7) = _h_175;
      STK(8) = _h_176;
      STK(9) = _h_177;
      STK(10) = _h_178;
      STK(11) = _h_179;
      STK(12) = _h_180;
      STK(13) = _h_181;
      STK(14) = _h_182;
      STK(15) = _h_183;
      STK(16) = _h_184;
      STK(17) = FID_ORDINARY_K329;
      WL_PUSHN(18);
    } else {
      u64 _t_58 = task_node(e, FID_ORDINARY_K329, WL_CONT, WL_IDX, 1);
      e.mem[_t_58 + 0] = _h_168;
      e.mem[_t_58 + 1] = _h_169;
      e.mem[_t_58 + 2] = _h_170;
      e.mem[_t_58 + 3] = _h_171;
      e.mem[_t_58 + 4] = _h_172;
      e.mem[_t_58 + 5] = _h_173;
      e.mem[_t_58 + 6] = _h_174;
      e.mem[_t_58 + 7] = _h_175;
      e.mem[_t_58 + 8] = _h_176;
      e.mem[_t_58 + 9] = _h_177;
      e.mem[_t_58 + 10] = _h_178;
      e.mem[_t_58 + 11] = _h_179;
      e.mem[_t_58 + 12] = _h_180;
      e.mem[_t_58 + 13] = _h_181;
      e.mem[_t_58 + 14] = _h_182;
      e.mem[_t_58 + 15] = _h_183;
      e.mem[_t_58 + 16] = _h_184;
      WL_CONT = term_tsk(FID_ORDINARY_K329, _t_58);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID_MERGE)) {
      u64 _t_59 = task_node(e, FID_MERGE, WL_CONT, WL_IDX, 0);
      e.mem[_t_59 + 0] = _h_159;
      e.mem[_t_59 + 1] = _h_160;
      e.mem[_t_59 + 2] = _h_161;
      e.mem[_t_59 + 3] = _h_162;
      e.mem[_t_59 + 4] = _h_163;
      e.mem[_t_59 + 5] = _h_164;
      e.mem[_t_59 + 6] = _h_165;
      e.mem[_t_59 + 7] = _h_166;
      e.mem[_t_59 + 8] = _h_167;
      return term_tsk(FID_MERGE, _t_59);
    }
    r0 = _h_159;
    r1 = _h_160;
    r2 = _h_161;
    r3 = _h_162;
    r4 = _h_163;
    r5 = _h_164;
    r6 = _h_165;
    r7 = _h_166;
    r8 = _h_167;
    WL_JMP(FID_MERGE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_ORDINARY_K329)
  {
    WL_POPN(17);
    Term _h_195 = STK(0);
    Term _h_196 = STK(1);
    Term _h_197 = STK(2);
    Term _h_198 = STK(3);
    Term _h_199 = STK(4);
    Term _h_200 = STK(5);
    Term _h_201 = STK(6);
    u32 _h_202 = STK(7);
    Term _h_203 = STK(8);
    Term _h_204 = STK(9);
    Term _h_205 = STK(10);
    Term _h_206 = STK(11);
    Term _h_207 = STK(12);
    Term _h_208 = STK(13);
    Term _h_209 = STK(14);
    Term _h_210 = STK(15);
    Term _h_211 = STK(16);
    u32 _h_185 = r0;
    Term _h_186 = r1;
    Term _h_187 = r2;
    Term _h_188 = r3;
    Term _h_189 = r4;
    Term _h_190 = r5;
    Term _h_191 = r6;
    Term _h_192 = r7;
    Term _h_193 = r8;
    Term _h_194 = r9;
    WL_OPEN
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _o_18[1];
    if (spin_19(e, _o_18, _h_202, _h_203, _h_204, _h_205, _h_206, _h_207, _h_208, _h_209, _h_210, _h_211) == 0) {
      return 0;
    }
    _v_37 = _o_18[0];
    _v_36 = _v_37;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _o_19[1];
    if (spin_19(e, _o_19, _h_185, _h_186, _h_187, _h_188, _h_189, _h_190, _h_191, _h_192, _h_193, _h_194) == 0) {
      return 0;
    }
    _v_40 = _o_19[0];
    _v_39 = _v_40;
    u64 _nd_20 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_20 + 0] = rfc_seal(e, _v_39);
    e.mem[_nd_20 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u64 _nd_21 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_21 + 0] = rfc_seal(e, _v_36);
    e.mem[_nd_21 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_20));
    u64 _nd_22 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_22 + 0] = rfc_seal(e, _h_201);
    e.mem[_nd_22 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_21));
    u64 _nd_23 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_23 + 0] = rfc_seal(e, _h_200);
    e.mem[_nd_23 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_22));
    u64 _nd_24 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_24 + 0] = rfc_seal(e, _h_199);
    e.mem[_nd_24 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_23));
    u64 _nd_25 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_25 + 0] = rfc_seal(e, _h_198);
    e.mem[_nd_25 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_24));
    u64 _nd_26 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_26 + 0] = rfc_seal(e, _h_197);
    e.mem[_nd_26 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_25));
    u64 _nd_27 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_27 + 0] = rfc_seal(e, _h_196);
    e.mem[_nd_27 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_26));
    u64 _nd_28 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_28 + 0] = rfc_seal(e, _h_195);
    e.mem[_nd_28 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_27));
    r0 = term_ctr(CID_CON, _nd_28);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = _ys_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_APPEND_K331;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_APPEND_K331, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_APPEND_K331, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _ys_0;
      _xs_0 = r0;
      _ys_0 = r1;
      WL_AGAIN(FID_LIST_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND_K331)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K333;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K333, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K333, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_ORDINARY)) {
      u64 _t_1 = task_node(e, FID_ORDINARY, WL_CONT, WL_IDX, 0);
      return term_tsk(FID_ORDINARY, _t_1);
    }
    WL_JMP(FID_ORDINARY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K333)
  {
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_MAIN_K334;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_MAIN_K334, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_MAIN_K334, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CONTROLS)) {
      u64 _t_3 = task_node(e, FID_CONTROLS, WL_CONT, WL_IDX, 0);
      return term_tsk(FID_CONTROLS, _t_3);
    }
    WL_JMP(FID_CONTROLS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K334)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_4 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      return term_tsk(FID_LIST_APPEND, _t_4);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========



// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
