function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $main$() {
  return $List$append$(($ordinary$()), ($controls$()));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $ordinary$() {
  const _values_0 = ($List$append$(($plain$()), ($List$append$(($transient$()), ($bare$())))));
  const _x_0 = ($entries$(_values_0));
  const _x_1 = ($entries$(($schema$045fragments$058filter_kind$1260$(_values_0, {$: "schema-fragments.Component"}))));
  const _x_2 = ($entries$(($schema$045fragments$058filter_kind$1260$(_values_0, {$: "schema-fragments.Resource"}))));
  const _x_3 = ($validation$(($schema$045fragments$058validate$1260$(_values_0))));
  const _x_4 = ($validation$(($schema$045fragments$058validate$1260$(($List$append$(($plain$()), ($plain$())))))));
  const _x_5 = ($validation$(run_loop($schema$045fragments$058requirements$1260$(($schema$045fragments$058bare_entries$1260$(_values_0)), _values_0))));
  const _x_6 = ($validation$(run_loop($schema$045fragments$058requirements$1260$(_values_0, ($schema$045fragments$058bare_entries$1260$(_values_0))))));
  return {$: "Con", "head": ("all=" + _x_0), "tail": {$: "Con", "head": ("component=" + _x_1), "tail": {$: "Con", "head": ("resource=" + _x_2), "tail": {$: "Con", "head": ("valid=" + _x_3), "tail": {$: "Con", "head": ("duplicate=" + _x_4), "tail": {$: "Con", "head": ("required-bare=" + _x_5), "tail": {$: "Con", "head": ("required-classified=" + _x_6), "tail": {$: "Con", "head": ($observed$(($merge$(($schema$045fragments$058merge$1260$({$: "schema-fragments.Fragment", "entries": ($plain$()), "owners": [41]}, {$: "schema-fragments.Fragment", "entries": ($List$append$(($transient$()), ($bare$()))), "owners": [43]})))))), "tail": {$: "Con", "head": ($observed$(($merge$(($schema$045fragments$058merge$1260$({$: "schema-fragments.Fragment", "entries": ($plain$()), "owners": [41]}, {$: "schema-fragments.Fragment", "entries": ($plain$()), "owners": [43]})))))), "tail": {$: "Nil"}}}}}}}}}};
}

function $controls$() {
  const _x_0 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Nil"}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}))));
  const _x_1 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "B"}))));
  const _x_2 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "b", "name": "A"}))));
  const _x_3 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}))));
  const _x_4 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "B"}))));
  const _x_5 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "b", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_6 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Constructed"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_7 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "x", "name": "X"}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Constructed"}}))));
  const _x_8 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_9 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_10 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Event"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Event"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_11 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Relation"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Relation"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_12 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Service"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Service"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_13 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_14 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Event"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_15 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Event"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Relation"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_16 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Relation"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Service"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_17 = ($validation$(($schema$045fragments$058check_one_bare$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Service"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_18 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Nil"}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}))));
  const _x_19 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "B"}))));
  const _x_20 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "b", "name": "A"}))));
  const _x_21 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}))));
  const _x_22 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "B"}))));
  const _x_23 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "b", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_24 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Constructed"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_25 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "x", "name": "X"}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Constructed"}}))));
  const _x_26 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_27 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_28 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Event"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Event"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_29 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Relation"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Relation"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_30 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Service"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Service"}, "key": "a", "name": "B", "persistence": {$: "schema-fragments.Plain"}}))));
  const _x_31 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_32 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Event"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_33 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Event"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Relation"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_34 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Relation"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Service"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_35 = ($validation$(($schema$045fragments$058check_one$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Service"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}, {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}))));
  const _x_36 = ($validation$(($schema$045fragments$058validate$1260$({$: "Nil"}))));
  const _x_37 = ($validation$(($schema$045fragments$058validate$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Transient"}}, "tail": {$: "Nil"}}}))));
  const _x_38 = ($validation$(($schema$045fragments$058validate$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "b", "name": "B", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "c", "name": "B", "persistence": {$: "schema-fragments.Transient"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "C"}, "tail": {$: "Nil"}}}}}))));
  const _x_39 = ($validation$(($schema$045fragments$058validate$1260$({$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Resource"}, "key": "r", "name": "R"}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": "r", "name": "S", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "a", "name": "A", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": "b", "name": "A", "persistence": {$: "schema-fragments.Transient"}}, "tail": {$: "Nil"}}}}}))));
  const _x_40 = ($validation$(($schema$045fragments$058validate$1260$({$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Service"}, "key": "s", "name": "S", "persistence": {$: "schema-fragments.Constructed"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Event"}, "key": "e", "name": "E", "persistence": {$: "schema-fragments.Transient"}}, "tail": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Relation"}, "key": "r", "name": "R", "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}}}))));
  return {$: "Con", "head": ("bare:empty=" + _x_0), "tail": {$: "Con", "head": ("bare:key-only=" + _x_1), "tail": {$: "Con", "head": ("bare:name-only=" + _x_2), "tail": {$: "Con", "head": ("bare:both-key-wins=" + _x_3), "tail": {$: "Con", "head": ("bare:classified-seen=" + _x_4), "tail": {$: "Con", "head": ("bare:classified-item=" + _x_5), "tail": {$: "Con", "head": ("bare:classified-both=" + _x_6), "tail": {$: "Con", "head": ("bare:mixed-later=" + _x_7), "tail": {$: "Con", "head": ("bare:same-domain-0=" + _x_8), "tail": {$: "Con", "head": ("bare:same-domain-1=" + _x_9), "tail": {$: "Con", "head": ("bare:same-domain-2=" + _x_10), "tail": {$: "Con", "head": ("bare:same-domain-3=" + _x_11), "tail": {$: "Con", "head": ("bare:same-domain-4=" + _x_12), "tail": {$: "Con", "head": ("bare:cross-domain-0=" + _x_13), "tail": {$: "Con", "head": ("bare:cross-domain-1=" + _x_14), "tail": {$: "Con", "head": ("bare:cross-domain-2=" + _x_15), "tail": {$: "Con", "head": ("bare:cross-domain-3=" + _x_16), "tail": {$: "Con", "head": ("bare:cross-domain-4=" + _x_17), "tail": {$: "Con", "head": ("normalized:empty=" + _x_18), "tail": {$: "Con", "head": ("normalized:key-only=" + _x_19), "tail": {$: "Con", "head": ("normalized:name-only=" + _x_20), "tail": {$: "Con", "head": ("normalized:both-key-wins=" + _x_21), "tail": {$: "Con", "head": ("normalized:classified-seen=" + _x_22), "tail": {$: "Con", "head": ("normalized:classified-item=" + _x_23), "tail": {$: "Con", "head": ("normalized:classified-both=" + _x_24), "tail": {$: "Con", "head": ("normalized:mixed-later=" + _x_25), "tail": {$: "Con", "head": ("normalized:same-domain-0=" + _x_26), "tail": {$: "Con", "head": ("normalized:same-domain-1=" + _x_27), "tail": {$: "Con", "head": ("normalized:same-domain-2=" + _x_28), "tail": {$: "Con", "head": ("normalized:same-domain-3=" + _x_29), "tail": {$: "Con", "head": ("normalized:same-domain-4=" + _x_30), "tail": {$: "Con", "head": ("normalized:cross-domain-0=" + _x_31), "tail": {$: "Con", "head": ("normalized:cross-domain-1=" + _x_32), "tail": {$: "Con", "head": ("normalized:cross-domain-2=" + _x_33), "tail": {$: "Con", "head": ("normalized:cross-domain-3=" + _x_34), "tail": {$: "Con", "head": ("normalized:cross-domain-4=" + _x_35), "tail": {$: "Con", "head": ("validate:empty-order=" + _x_36), "tail": {$: "Con", "head": ("validate:mixed-order=" + _x_37), "tail": {$: "Con", "head": ("validate:name-before-later-key=" + _x_38), "tail": {$: "Con", "head": ("validate:component-before-resource=" + _x_39), "tail": {$: "Con", "head": ("validate:retained-classification=" + _x_40), "tail": {$: "Nil"}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}};
}

function $plain$() {
  return $ordinary$045schema$058entries$1260$(($ordinary$045schema$058component_plain$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058plain$1260$()))));
}

function $transient$() {
  return $ordinary$045schema$058entries$1261$(($ordinary$045schema$058resource_transient$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058transient$1260$()))));
}

function $bare$() {
  return $ordinary$045schema$058entries$1260$(($ordinary$045schema$058component$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1260$("B")))));
}

function $entries$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "end";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($entries$(_rest_0));
    const _x_1 = ($entry$(_value_0));
    const _x_2 = (";" + _x_0);
    return (_x_1 + _x_2);
  }
}

function $schema$045fragments$058filter_kind$1260$(_xs_0, _kind_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _xs_0["head"];
    if (_t_0.$ === "schema-fragments.Entry") {
      const _itemKind_0 = _t_0["kind"];
      const _key_0 = _t_0["key"];
      const _name_0 = _t_0["name"];
      const _rest_0 = _xs_0["tail"];
      return $schema$045fragments$058filter_kind_done$1260$(($schema$045fragments$058same_kind$(_kind_0, _itemKind_0)), {$: "schema-fragments.Entry", "kind": _itemKind_0, "key": _key_0, "name": _name_0}, ($schema$045fragments$058filter_kind$1260$(_rest_0, _kind_0)));
    } else {
      const _itemKind_1 = _t_0["kind"];
      const _key_1 = _t_0["key"];
      const _name_1 = _t_0["name"];
      const _persistence_0 = _t_0["persistence"];
      const _rest_1 = _xs_0["tail"];
      return $schema$045fragments$058filter_kind_done$1260$(($schema$045fragments$058same_kind$(_kind_0, _itemKind_1)), {$: "schema-fragments.Classified", "kind": _itemKind_1, "key": _key_1, "name": _name_1, "persistence": _persistence_0}, ($schema$045fragments$058filter_kind$1260$(_rest_1, _kind_0)));
    }
  }
}

function $validation$(_value_0) {
  if (_value_0.$ === "schema-fragments.Valid") {
    return "Valid";
  } else {
    const _reason_0 = _value_0["error"];
    return $error$(_reason_0);
  }
}

function $schema$045fragments$058validate$1260$(_entries_0) {
  return $schema$045fragments$058first_failure$(run_loop($schema$045fragments$058validate_loop$1260$(($schema$045fragments$058filter_kind$1260$(_entries_0, {$: "schema-fragments.Component"})), {$: "Nil"})), ($schema$045fragments$058first_failure$(run_loop($schema$045fragments$058validate_loop$1260$(($schema$045fragments$058filter_kind$1260$(_entries_0, {$: "schema-fragments.Resource"})), {$: "Nil"})), ($schema$045fragments$058first_failure$(run_loop($schema$045fragments$058validate_loop$1260$(($schema$045fragments$058filter_kind$1260$(_entries_0, {$: "schema-fragments.Event"})), {$: "Nil"})), ($schema$045fragments$058first_failure$(run_loop($schema$045fragments$058validate_loop$1260$(($schema$045fragments$058filter_kind$1260$(_entries_0, {$: "schema-fragments.Relation"})), {$: "Nil"})), run_loop($schema$045fragments$058validate_loop$1260$(($schema$045fragments$058filter_kind$1260$(_entries_0, {$: "schema-fragments.Service"})), {$: "Nil"})))))))));
}

function $schema$045fragments$058requirements$1260$(_required_0, _entries_0) {
  if (_required_0.$ === "Nil") {
    return {$: "schema-fragments.Valid"};
  } else {
    const _item_0 = _required_0["head"];
    const _rest_0 = _required_0["tail"];
    return $schema$045fragments$058required_continue$(($schema$045fragments$058required_check$1260$(($schema$045fragments$058descriptor_present$1260$(_entries_0, _item_0)), _item_0)), run_clo((_x_0) => {
  return $schema$045fragments$058requirements$1260$(_rest_0, _entries_0);
}));
  }
}

function $schema$045fragments$058bare_entries$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    return {$: "Con", "head": ($schema$045fragments$058bare_entry$1260$(_head_0)), "tail": ($schema$045fragments$058bare_entries$1260$(_rest_0))};
  }
}

function $observed$(_result_0) {
  const _text_0 = _result_0["snd"];
  return _text_0;
}

function $merge$(_value_0) {
  if (_value_0.$ === "schema-fragments.Merged") {
    const _t_0 = _value_0["fragment"];
    const _values_0 = _t_0["entries"];
    const _t_1 = _t_0["owners"];
    const _left_0 = _t_1["fst"];
    const _right_0 = _t_1["snd"];
    return $merged$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058array$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058array$(_right_0)));
  } else {
    const _reason_0 = _value_0["error"];
    const _left_1 = _value_0["left"];
    const _right_1 = _value_0["right"];
    return $rejected$(_reason_0, ($fragment$(_left_1)), ($fragment$(_right_1)));
  }
}

function $schema$045fragments$058merge$1260$(_left_0, _right_0) {
  const _le_0 = _left_0["entries"];
  const _l_0 = _left_0["owners"];
  const _re_0 = _right_0["entries"];
  const _r_0 = _right_0["owners"];
  return $schema$045fragments$058merge_checked$1260$(($schema$045fragments$058first_failure$(($schema$045fragments$058validate$1260$(_le_0)), ($schema$045fragments$058first_failure$(($schema$045fragments$058validate$1260$(_re_0)), ($schema$045fragments$058validate$1260$(($List$append$(_le_0, _re_0)))))))), ($List$append$(_le_0, _re_0)), {$: "schema-fragments.Fragment", "entries": _le_0, "owners": _l_0}, {$: "schema-fragments.Fragment", "entries": _re_0, "owners": _r_0});
}

function $schema$045fragments$058check_one_bare$1260$(_seen_0, _item_0) {
  if (_item_0.$ === "schema-fragments.Entry") {
    const _kind_0 = _item_0["kind"];
    const _key_0 = _item_0["key"];
    const _name_0 = _item_0["name"];
    return $schema$045fragments$058check_entry$(false, ($schema$045fragments$058name_exists_bare$1260$(_seen_0, _kind_0, _name_0)), _kind_0, _key_0, _name_0);
  } else {
    const _kind_1 = _item_0["kind"];
    const _key_1 = _item_0["key"];
    const _name_1 = _item_0["name"];
    return $schema$045fragments$058check_entry$(false, ($schema$045fragments$058name_exists_bare$1260$(_seen_0, _kind_1, _name_1)), _kind_1, _key_1, _name_1);
  }
}

function $schema$045fragments$058check_one$1260$(_seen_0, _item_0) {
  return $schema$045fragments$058check_one_bare$1260$(($schema$045fragments$058bare_entries$1260$(_seen_0)), ($schema$045fragments$058bare_entry$1260$(_item_0)));
}

function $ordinary$045schema$058entries$1260$(_value_0) {
  const _entries_0 = _value_0["entries"];
  return _entries_0;
}

function $ordinary$045schema$058component_plain$1260$(_extension_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($identity$())));
  return {$: "ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Component"}, "key": _key_0, "name": _key_0, "persistence": {$: "schema-fragments.Plain"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058plain$1260$() {
  return {$: "../../../../../../../../../../../../../bendvy/src/ecs/persistence-declaration.Plain"};
}

function $ordinary$045schema$058entries$1261$(_value_0) {
  const _entries_0 = _value_0["entries"];
  return _entries_0;
}

function $ordinary$045schema$058resource_transient$1260$(_extension_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(($identity$())));
  return {$: "ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "schema-fragments.Classified", "kind": {$: "schema-fragments.Resource"}, "key": _key_0, "name": _key_0, "persistence": {$: "schema-fragments.Transient"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047persistence$045declaration$058transient$1260$() {
  return {$: "../../../../../../../../../../../../../bendvy/src/ecs/persistence-declaration.Transient"};
}

function $ordinary$045schema$058component$1260$(_declaration_0) {
  const _key_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(_declaration_0));
  return {$: "ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "schema-fragments.Entry", "kind": {$: "schema-fragments.Component"}, "key": _key_0, "name": _key_0}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1260$(_key_0) {
  return {$: "../../../../../../../../../../../../../bendvy/src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $entry$(_value_0) {
  if (_value_0.$ === "schema-fragments.Entry") {
    const _tag_0 = _value_0["kind"];
    const _key_0 = _value_0["key"];
    const _name_0 = _value_0["name"];
    const _x_0 = (_name_0 + ":bare");
    const _x_1 = (":" + _x_0);
    const _x_2 = (_key_0 + _x_1);
    const _x_3 = ($kind$(_tag_0));
    const _x_4 = (":" + _x_2);
    return (_x_3 + _x_4);
  } else {
    const _tag_1 = _value_0["kind"];
    const _key_1 = _value_0["key"];
    const _name_1 = _value_0["name"];
    const _extension_0 = _value_0["persistence"];
    const _x_5 = ($persistence$(_extension_0));
    const _x_6 = (":" + _x_5);
    const _x_7 = (_name_1 + _x_6);
    const _x_8 = (":" + _x_7);
    const _x_9 = (_key_1 + _x_8);
    const _x_10 = ($kind$(_tag_1));
    const _x_11 = (":" + _x_9);
    return (_x_10 + _x_11);
  }
}

function $schema$045fragments$058filter_kind_done$1260$(_selected_0, _item_0, _rest_0) {
  if (_selected_0) {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $schema$045fragments$058same_kind$(_a_0, _b_0) {
  if (_a_0.$ === "schema-fragments.Component") {
    if (_b_0.$ === "schema-fragments.Component") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "schema-fragments.Resource") {
    if (_b_0.$ === "schema-fragments.Resource") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "schema-fragments.Event") {
    if (_b_0.$ === "schema-fragments.Event") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "schema-fragments.Relation") {
    if (_b_0.$ === "schema-fragments.Relation") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_b_0.$ === "schema-fragments.Service") {
      return true;
    } else {
      return false;
    }
  }
}

function $error$(_value_0) {
  if (_value_0.$ === "schema-fragments.DuplicateKey") {
    const _tag_0 = _value_0["kind"];
    const _key_0 = _value_0["key"];
    const _x_0 = ($kind$(_tag_0));
    const _x_1 = (":" + _key_0);
    const _x_2 = (_x_0 + _x_1);
    return ("DuplicateKey:" + _x_2);
  } else if (_value_0.$ === "schema-fragments.DuplicateName") {
    const _tag_1 = _value_0["kind"];
    const _name_0 = _value_0["name"];
    const _x_3 = ($kind$(_tag_1));
    const _x_4 = (":" + _name_0);
    const _x_5 = (_x_3 + _x_4);
    return ("DuplicateName:" + _x_5);
  } else {
    const _tag_2 = _value_0["kind"];
    const _key_1 = _value_0["key"];
    const _name_1 = _value_0["name"];
    const _x_6 = (":" + _name_1);
    const _x_7 = (_key_1 + _x_6);
    const _x_8 = ($kind$(_tag_2));
    const _x_9 = (":" + _x_7);
    const _x_10 = (_x_8 + _x_9);
    return ("Undeclared:" + _x_10);
  }
}

function $schema$045fragments$058first_failure$(_first_0, _second_0) {
  if (_first_0.$ === "schema-fragments.Invalid") {
    const _error_0 = _first_0["error"];
    return {$: "schema-fragments.Invalid", "error": _error_0};
  } else {
    return _second_0;
  }
}

function $schema$045fragments$058validate_loop$1260$(_xs_0, _seen_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "schema-fragments.Valid"};
  } else {
    const _item_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $schema$045fragments$058validation_continue$1260$(($schema$045fragments$058check_one$1260$(_seen_0, _item_0)), run_clo((_x_0) => {
  return $schema$045fragments$058validate_loop$1260$(_rest_0, {$: "Con", "head": _item_0, "tail": _seen_0});
}));
  }
}

function $schema$045fragments$058required_continue$(_result_0, _next_0) {
  if (_result_0.$ === "schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "schema-fragments.Invalid", "error": _error_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $schema$045fragments$058required_check$1260$(_present_0, _item_0) {
  return $schema$045fragments$058required_check_bare$1260$(_present_0, ($schema$045fragments$058bare_entry$1260$(_item_0)));
}

function $schema$045fragments$058descriptor_present$1260$(_xs_0, _item_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($schema$045fragments$058descriptor_equal$1260$(($schema$045fragments$058bare_entry$1260$(_head_0)), ($schema$045fragments$058bare_entry$1260$(_item_0))));
    const _x_1 = ($schema$045fragments$058descriptor_present$1260$(_rest_0, _item_0));
    return (_x_0 || _x_1);
  }
}

function $schema$045fragments$058bare_entry$1260$(_value_0) {
  if (_value_0.$ === "schema-fragments.Entry") {
    const _kind_0 = _value_0["kind"];
    const _key_0 = _value_0["key"];
    const _name_0 = _value_0["name"];
    return {$: "schema-fragments.Entry", "kind": _kind_0, "key": _key_0, "name": _name_0};
  } else {
    const _kind_1 = _value_0["kind"];
    const _key_1 = _value_0["key"];
    const _name_1 = _value_0["name"];
    return {$: "schema-fragments.Entry", "kind": _kind_1, "key": _key_1, "name": _name_1};
  }
}

function $merged$(_values_0, _left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  const _x_0 = ("|right=" + _b_0);
  const _x_1 = (_a_0 + _x_0);
  const _x_2 = ($entries$(_values_0));
  const _x_3 = ("|left=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return {$: "Tuple", "fst": {$: "schema-fragments.Merged", "fragment": {$: "schema-fragments.Fragment", "entries": _values_0, "owners": {$: "Tuple", "fst": _left_1, "snd": _right_1}}}, "snd": ("Merged:" + _x_4)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058array$(_value_0) {
  if (_value_0.length === 1) {
    const _value_1 = _value_0[0];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058leaf$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058u32$(_value_1)));
  } else {
    const _left_0 = _value_0.slice(0, _value_0.length >> 1);
    const _right_0 = _value_0.slice(_value_0.length >> 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058node$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058array$(_left_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058array$(_right_0)));
  }
}

function $rejected$(_reason_0, _left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  const _x_0 = ("|right=" + _b_0);
  const _x_1 = (_a_0 + _x_0);
  const _x_2 = ($error$(_reason_0));
  const _x_3 = ("|left=" + _x_1);
  return {$: "Tuple", "fst": {$: "schema-fragments.Rejected", "error": _reason_0, "left": _left_1, "right": _right_1}, "snd": (_x_2 + _x_3)};
}

function $fragment$(_value_0) {
  const _values_0 = _value_0["entries"];
  const _owner_0 = _value_0["owners"];
  return $fragment_observed$(_values_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058array$(_owner_0)));
}

function $schema$045fragments$058merge_checked$1260$(_result_0, _entries_0, _left_0, _right_0) {
  if (_result_0.$ === "schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "schema-fragments.Rejected", "error": _error_0, "left": _left_0, "right": _right_0};
  } else {
    const _l_0 = _left_0["owners"];
    const _r_0 = _right_0["owners"];
    return {$: "schema-fragments.Merged", "fragment": {$: "schema-fragments.Fragment", "entries": _entries_0, "owners": {$: "Tuple", "fst": _l_0, "snd": _r_0}}};
  }
}

function $schema$045fragments$058check_entry$(_keyConflict_0, _nameConflict_0, _kind_0, _key_0, _name_0) {
  if (_keyConflict_0) {
    return {$: "schema-fragments.Invalid", "error": {$: "schema-fragments.DuplicateKey", "kind": _kind_0, "key": _key_0}};
  } else {
    if (_nameConflict_0) {
      return {$: "schema-fragments.Invalid", "error": {$: "schema-fragments.DuplicateName", "kind": _kind_0, "name": _name_0}};
    } else {
      return {$: "schema-fragments.Valid"};
    }
  }
}

function $schema$045fragments$058name_exists_bare$1260$(_xs_0, _kind_0, _name_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    if (_t_0.$ === "schema-fragments.Entry") {
      const _other_0 = _t_0["kind"];
      const _otherName_0 = _t_0["name"];
      const _rest_0 = _xs_0["tail"];
      const _x_0 = ($Bool$and$(($schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_name_0, _otherName_0))));
      const _x_1 = ($schema$045fragments$058name_exists_bare$1260$(_rest_0, _kind_0, _name_0));
      return (_x_0 || _x_1);
    } else {
      const _other_1 = _t_0["kind"];
      const _otherName_1 = _t_0["name"];
      const _rest_1 = _xs_0["tail"];
      const _x_2 = ($Bool$and$(($schema$045fragments$058same_kind$(_kind_0, _other_1)), ($String$eq$(_name_0, _otherName_1))));
      const _x_3 = ($schema$045fragments$058name_exists_bare$1260$(_rest_1, _kind_0, _name_0));
      return (_x_2 || _x_3);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058key$1260$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $identity$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045declaration$058component$1260$("A");
}

function $kind$(_value_0) {
  if (_value_0.$ === "schema-fragments.Component") {
    return "Component";
  } else if (_value_0.$ === "schema-fragments.Resource") {
    return "Resource";
  } else if (_value_0.$ === "schema-fragments.Event") {
    return "Event";
  } else if (_value_0.$ === "schema-fragments.Relation") {
    return "Relation";
  } else {
    return "Service";
  }
}

function $persistence$(_value_0) {
  if (_value_0.$ === "schema-fragments.Plain") {
    return "Plain";
  } else if (_value_0.$ === "schema-fragments.Transient") {
    return "Transient";
  } else {
    return "Constructed";
  }
}

function $schema$045fragments$058validation_continue$1260$(_result_0, _next_0) {
  if (_result_0.$ === "schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "schema-fragments.Invalid", "error": _error_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $schema$045fragments$058required_check_bare$1260$(_present_0, _item_0) {
  if (_present_0) {
    return {$: "schema-fragments.Valid"};
  } else {
    if (_item_0.$ === "schema-fragments.Entry") {
      const _kind_0 = _item_0["kind"];
      const _key_0 = _item_0["key"];
      const _name_0 = _item_0["name"];
      return {$: "schema-fragments.Invalid", "error": {$: "schema-fragments.UndeclaredDescriptor", "kind": _kind_0, "key": _key_0, "name": _name_0}};
    } else {
      const _kind_1 = _item_0["kind"];
      const _key_1 = _item_0["key"];
      const _name_1 = _item_0["name"];
      return {$: "schema-fragments.Invalid", "error": {$: "schema-fragments.UndeclaredDescriptor", "kind": _kind_1, "key": _key_1, "name": _name_1}};
    }
  }
}

function $schema$045fragments$058descriptor_equal$1260$(_a_0, _b_0) {
  if (_a_0.$ === "schema-fragments.Entry") {
    const _ak_0 = _a_0["kind"];
    const _ax_0 = _a_0["key"];
    const _an_0 = _a_0["name"];
    if (_b_0.$ === "schema-fragments.Entry") {
      const _bk_0 = _b_0["kind"];
      const _bx_0 = _b_0["key"];
      const _bn_0 = _b_0["name"];
      return $Bool$and$(($schema$045fragments$058same_kind$(_ak_0, _bk_0)), ($Bool$and$(($String$eq$(_ax_0, _bx_0)), ($String$eq$(_an_0, _bn_0)))));
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058leaf$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": [_value_0], "snd": ("leaf:" + _text_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058u32$(_value_0) {
  const _value_1 = _value_0;
  return {$: "Tuple", "fst": _value_1, "snd": ($U32$show$(_value_1))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047bendvy$047src$047ecs$047ordinary$045dump$045builtin$058node$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _a_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _b_0 = _right_0["snd"];
  const _x_0 = (_b_0 + ")");
  const _x_1 = ("," + _x_0);
  const _x_2 = (_a_0 + _x_1);
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ("node(" + _x_2)};
}

function $fragment_observed$(_values_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  const _x_0 = ($entries$(_values_0));
  const _x_1 = ("|owner=" + _text_0);
  return {$: "Tuple", "fst": {$: "schema-fragments.Fragment", "entries": _values_0, "owners": _owner_0}, "snd": (_x_0 + _x_1)};
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, [[7,1,2,0,0,0,1,1,0,2,1,0,15,1,0,4],["Nil","Con"]]);