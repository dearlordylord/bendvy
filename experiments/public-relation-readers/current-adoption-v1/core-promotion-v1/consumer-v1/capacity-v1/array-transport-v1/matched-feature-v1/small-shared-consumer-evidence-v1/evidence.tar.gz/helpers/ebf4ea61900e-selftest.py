#!/usr/bin/env python3
"""Deterministic checks for the source-derived small consumer oracle."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("oracle", HERE / "generate_expected.py")
assert SPEC is not None and SPEC.loader is not None
ORACLE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ORACLE)

BASIS = json.loads((HERE / "SOURCE-BASIS.json").read_text())
SOURCE_ROOT = Path(BASIS["producerRoot"])
assert BASIS["format"] == "bendvy-independent-source-basis-v1"
assert BASIS["runtimeOutputConsulted"] is False
source_rows = BASIS["sourceFiles"]
source_by_path = {row["path"]: row for row in source_rows}
assert len(source_by_path) == len(source_rows) == BASIS["moduleImportClosureCount"]
for path, row in source_by_path.items():
    content = (SOURCE_ROOT / path).read_bytes()
    assert len(content) == row["bytes"], f"source size drift: {path}"
    assert hashlib.sha256(content).hexdigest() == row["sha256"], f"source hash drift: {path}"

# Reconstruct the ordinary relative .bend import closure to ensure the pinned
# source list covers the consumer and every filesystem module it reaches.
entry = SOURCE_ROOT / BASIS["entrypoint"]
seen: set[Path] = set()
pending = [entry.resolve()]
while pending:
    path = pending.pop()
    if path in seen:
        continue
    seen.add(path)
    for line in path.read_text().splitlines():
        match = re.match(r"^import\s+([^\s]+)", line)
        if not match:
            continue
        imported = match.group(1)
        if imported == "Base" or not imported.endswith(".bend"):
            continue
        resolved = (path.parent / imported).resolve()
        assert resolved.is_file(), f"unresolved source import: {path} -> {imported}"
        pending.append(resolved)
actual_closure = {path.relative_to(SOURCE_ROOT.resolve()).as_posix() for path in seen}
assert actual_closure == set(source_by_path), "pinned source list differs from consumer import closure"

actual = ORACLE.expected_bytes()
committed = (HERE / "expected.stdout").read_bytes()
assert actual == committed, "generated oracle differs from expected.stdout"
records = ORACLE.expected_records()
assert [row["phase"] for row in records] == [
    "A-fail", "A-retry", "A-repeat", "B-first", "B-repeat"
]
assert [row["clock"] for row in records] == [1, 2, 3, 4, 5]
assert [row["queryCursor"] for row in records] == [0, 2, 3, 4, 5]
assert records[0]["status"] == "failed" and records[0]["error"] == 7
assert records[0]["view"] == records[1]["view"], "failed callback must preserve prepared readings"
assert records[2]["view"]["eventA"]["values"] == []
assert records[3]["view"]["eventA"]["values"] == ORACLE.event_view(True)["values"]
assert records[3]["view"]["eventB"]["values"] == ORACLE.event_view(True)["values"]
assert records[2]["view"]["relations"] == ORACLE.relation_view(False)
assert records[4]["view"]["relations"] == ORACLE.relation_view(False)
assert records[0]["view"]["eventA"]["values"] == ORACLE.event_view(True)["values"]
assert records[0]["view"]["eventB"]["values"] == ORACLE.event_view(True)["values"]
assert records[0]["view"]["eventA"]["values"] == [ORACLE.VALUE_NOTICE]
assert records[0]["view"]["eventB"]["values"] == [ORACLE.VALUE_NOTICE]
assert records[0]["view"]["removals"] == [ORACLE.REMOVAL]
assert records[4]["view"]["removals"] == []
print(f"PASS source-derived oracle: {len(committed)} bytes sha256={hashlib.sha256(committed).hexdigest()}")
