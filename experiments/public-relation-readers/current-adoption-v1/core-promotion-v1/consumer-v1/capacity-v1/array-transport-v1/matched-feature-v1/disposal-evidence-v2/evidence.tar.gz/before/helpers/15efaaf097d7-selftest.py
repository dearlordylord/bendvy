#!/usr/bin/env python3
"""Verify the frozen source basis and derived disposal observation only."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
BASIS = json.loads((HERE / "SOURCE-BASIS.json").read_text())
SPEC = importlib.util.spec_from_file_location("disposal_oracle", HERE / "generate_expected.py")
assert SPEC is not None and SPEC.loader is not None
ORACLE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ORACLE)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text())


def verify_source_pins(source_root: Path, manifest_path: Path) -> None:
    assert BASIS["format"] == "bendvy-disposal-source-basis-v1"
    assert BASIS["runtimeOutputConsulted"] is False
    assert BASIS["foreignContextProvenance"] == (
        "trusted seeded W.Factory{2}; not ordinary WorldIO origin"
    )
    manifest_bytes = manifest_path.read_bytes()
    assert sha256(manifest_bytes) == BASIS["sourcePinManifestSha256"]
    manifest = load_json(manifest_path)
    rows = BASIS["sources"]
    assert len(rows) == BASIS["sourcePinCount"] == 63
    assert len({row["path"] for row in rows}) == len(rows)
    assert {row["path"]: row["sha256"] for row in rows} == manifest
    for row in rows:
        content = (source_root / row["path"]).read_bytes()
        assert len(content) == row["bytes"], f"source size drift: {row['path']}"
        assert sha256(content) == row["sha256"], f"source hash drift: {row['path']}"
    entry = next(row for row in rows if row["path"].endswith("ordinary-disposal-consumer.bend"))
    assert entry["sha256"] == "7b45c990472360ed72e9010ed715edaa555c631b6a2e1b270f422ab94d934f9b"


def assert_context_state(context: dict[str, Any], *, clock: int, system_ids: list[int],
                         event_positions: list[tuple[int, int, int]],
                         relation_readers: list[int], relation_positions: list[tuple[int, int, int]],
                         journal_values: list[dict[str, Any]]) -> None:
    world = context["world"]
    assert world["clock"] == clock
    assert [row["id"] for row in world["registrations"]] == system_ids
    typed = context["shared"]["typed"]
    assert [(p["id"], p["cursor"], p["registeredAt"]) for p in typed["stream"]["positions"]] == event_positions
    assert typed["stream"]["batches"][0]["values"] == [ORACLE.BASE.VALUE_NOTICE]
    assert typed["journal"] == [{"tick": 1, "values": journal_values}]
    queue = context["shared"]["relationFailures"]
    assert [reader for domain in queue["domains"] for reader in domain["readers"]] == relation_readers
    assert [(p["id"], p["cursor"], p["registeredAt"]) for p in queue["positions"]] == relation_positions
    assert queue["tick"] == clock


def verify_observations() -> None:
    data = load_json(HERE / "expected.stdout")
    assert set(data) == {"aRunView", "disposeA", "bRunView", "contextAfterB", "foreignRefusal", "disposeB"}
    assert data["aRunView"] == data["bRunView"]
    assert data["aRunView"]["eventA"] == {"values": [ORACLE.BASE.VALUE_NOTICE], "lagged": False}
    assert data["aRunView"]["eventB"] == {"values": [ORACLE.BASE.VALUE_NOTICE], "lagged": False}
    assert data["aRunView"]["removals"] == [ORACLE.BASE.REMOVAL]
    assert data["aRunView"]["relations"] == ORACLE.relation_view()

    dispose_a = data["disposeA"]
    assert [r["id"] for r in dispose_a["before"]["world"]["registrations"]] == [2, 1]
    assert [r["id"] for r in dispose_a["after"]["world"]["registrations"]] == [2]
    assert dispose_a["providerBPreserved"] is True
    assert dispose_a["providerBBefore"] == dispose_a["providerBAfter"]
    assert [p["id"] for p in dispose_a["before"]["shared"]["typed"]["stream"]["positions"]] == [2, 1]
    assert dispose_a["after"]["shared"]["typed"]["stream"]["positions"] == []
    assert_context_state(
        dispose_a["before"],
        clock=1,
        system_ids=[2, 1],
        event_positions=[(2, 0, 0), (1, 0, 0)],
        relation_readers=[1],
        relation_positions=[(1, 1, 1)],
        journal_values=[ORACLE.VALUE_PUBLICATION, ORACLE.REMOVED_PUBLICATION],
    )
    assert_context_state(
        dispose_a["after"],
        clock=1,
        system_ids=[2],
        event_positions=[],
        relation_readers=[],
        relation_positions=[],
        journal_values=[ORACLE.VALUE_PUBLICATION, ORACLE.REMOVED_PUBLICATION],
    )
    # B is still registered, so A's disposal must retain B's unread removal.
    assert dispose_a["after"]["world"]["events"][-1] == ORACLE.REMOVAL_NOTICE
    assert dispose_a["after"]["shared"]["typed"]["journal"][0]["values"] == [
        ORACLE.VALUE_PUBLICATION, ORACLE.REMOVED_PUBLICATION
    ]

    context_b = data["contextAfterB"]
    assert_context_state(
        context_b,
        clock=2,
        system_ids=[2],
        event_positions=[(4, 1, 0), (3, 1, 0)],
        relation_readers=[2],
        relation_positions=[(2, 1, 1)],
        journal_values=[ORACLE.VALUE_PUBLICATION, ORACLE.REMOVED_PUBLICATION],
    )
    assert context_b["world"]["events"] == [ORACLE.BASE.VALUE_NOTICE, ORACLE.REMOVAL_NOTICE]
    assert data["bRunView"]["removals"] == [ORACLE.BASE.REMOVAL]
    assert data["bRunView"]["relations"] == ORACLE.relation_view()

    foreign = data["foreignRefusal"]
    assert foreign["status"] == "rejected"
    assert foreign["before"] == foreign["after"]
    assert foreign["providerBefore"] == foreign["providerAfter"]
    assert foreign["contextPreserved"] and foreign["providerPreserved"]
    assert foreign["before"]["world"]["namespace"] == 2
    assert foreign["before"]["world"]["capacity"] == 1

    dispose_b = data["disposeB"]
    assert [r["id"] for r in dispose_b["before"]["world"]["registrations"]] == [2]
    assert dispose_b["provider"]["registry"]["id"] == 2
    after_b = dispose_b["after"]
    assert after_b["world"]["registrations"] == []
    assert after_b["world"]["events"] == [ORACLE.BASE.VALUE_NOTICE]
    assert after_b["shared"]["typed"]["journal"] == [
        {"tick": 1, "values": [ORACLE.VALUE_PUBLICATION]}
    ]
    assert after_b["shared"]["typed"]["stream"]["positions"] == []
    # Historical relation-failure queue data remains while all reader owners are released.
    assert after_b["shared"]["relationFailures"]["domains"][0]["queue"] == (
        context_b["shared"]["relationFailures"]["domains"][0]["queue"]
    )
    assert after_b["shared"]["relationFailures"]["domains"][0]["readers"] == []
    assert after_b["shared"]["relationFailures"]["positions"] == []
    assert after_b["world"]["clock"] == 2
    assert dispose_b["before"]["world"]["events"][-1] == ORACLE.REMOVAL_NOTICE
    assert dispose_b["before"]["shared"]["typed"]["journal"][0]["values"] == [
        ORACLE.VALUE_PUBLICATION, ORACLE.REMOVED_PUBLICATION
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, default=Path(BASIS["sourceSnapshotRoot"]))
    parser.add_argument(
        "--source-manifest", type=Path, default=Path(BASIS["sourcePinManifestPath"])
    )
    args = parser.parse_args()
    verify_source_pins(args.source_root, args.source_manifest)
    verify_observations()
    assert ORACLE.expected_bytes() == (HERE / "expected.stdout").read_bytes()
    print("PASS: 63 source pins, deterministic stdout, disposal/ownership invariants")


if __name__ == "__main__":
    main()
