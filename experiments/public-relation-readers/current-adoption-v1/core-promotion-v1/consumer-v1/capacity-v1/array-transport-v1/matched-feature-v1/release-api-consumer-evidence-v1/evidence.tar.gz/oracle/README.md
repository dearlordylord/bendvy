# Small shared-reader consumer oracle

`expected.stdout` is a source-derived model of the five observations emitted by
`ordinary-combined-consumer.bend`: A failure, A retry, A repeat, then the first
and repeated invocation of separately registered B. The model uses the
consumer's JSON field order and compact ASCII rendering.

The setup includes both a value and a removal publication. The reached
`sync_events` callback maps the mixed world's original notices to publications,
then `original_values` forwards `Value` and filters out `Removed`; each typed
event parameter therefore sees only the value at its first read. The removal
parameter separately projects the retained removal notice from the World.
Relation output retains one keyed reading for the declared `Parent` descriptor
after its value is consumed, with an empty values list and `lagged: false`.

This is an independent expected-output artifact. It was derived from the
pinned consumer and ECS source listed in `SOURCE-BASIS.json`; it has not been
compared with a runtime output. In particular, it is not backend acceptance or
proof of general transaction/reader behavior. The A failure and retry model
keeps the attempt clock advance while preserving all callback-owned reader
cursors; successful A consumption does not consume B's independent owners.

`SOURCE-BASIS.json` pins the consumer and its complete 61-file relative
`.bend` import closure by content hash, including working-tree source bytes
that were not represented by the producer checkout's `HEAD`. The self-test
rechecks each hash and reconstructs the closure before checking the retained
oracle and the retry/independence facts.

Run `python3 selftest.py` to perform those deterministic checks.
`python3 generate_expected.py` writes the JSON array to stdout for inspection.

`MUTATION.json` and `wrong-reader-advance.expected.stdout` record a separate
source-derived counter-model for changing the `Stream.advance` reader id in
`event_advanced_selected` from `id` to `id+1`. The counter-model simulates the
four registered event owners in source initialization and commit order. Its
self-test requires the complete counter output to differ from the unchanged
baseline while all non-event fields remain the same. It is an oracle
sensitivity check only; no mutant source or runtime output was executed.
