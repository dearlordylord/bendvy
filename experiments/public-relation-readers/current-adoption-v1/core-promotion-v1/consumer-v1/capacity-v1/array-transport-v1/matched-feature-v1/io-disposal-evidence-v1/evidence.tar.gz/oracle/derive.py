#!/usr/bin/env python3
"""Source-only WorldIO provenance and ordinary provider disposal oracle."""
import copy
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ACCESS=["value","values:read","values:read","removal","value","Parent:read"]
NAME="io-disposal"

class Allocator:
    def __init__(self):
        # C atomic static=1; JS Symbol state absent in a fresh host realm.
        self.next=1
    def fresh(self):
        if self.next>=0xffffffff:
            return 0
        current=self.next
        self.next+=1
        return current

def context(namespace, registered=False):
    registrations=[{"id":1,"name":NAME,"access":ACCESS}] if registered else []
    return {"world":{"namespace":namespace,"nextId":1,"highWater":0,
                     "capacity":1,"depth":0,"clock":0,"events":[],
                     "registrations":copy.deepcopy(registrations)},
            "routeTick":0,"shared":{
                "typed":{"stream":{"domain":"values","batches":[],"positions":[],
                                   "nextReader":3 if registered else 1,"frameStart":0,
                                   "boundary":0,"capacity":65536,"dropped":0},
                         "journal":[],"frameStart":0},
                "relationFailures":{"domains":[],"positions":[],"tick":0,
                                    "frameStart":0,"boundary":0,"capacity":65536,
                                    "nextReader":2 if registered else 1}}}

def provider(namespace):
    facts={"namespace":namespace,"id":1,"name":NAME,"access":ACCESS}
    return {"registry":dict(facts,cursor=0),"readers":{
                "eventA":{"facts":copy.deepcopy(facts),
                          "reader":{"namespace":namespace,"id":1,"registryId":1}},
                "eventB":{"facts":copy.deepcopy(facts),
                          "reader":{"namespace":namespace,"id":2,"registryId":1}},
                "removal":{"facts":copy.deepcopy(facts),
                           "reader":{"namespace":namespace,"id":1,"name":"value","cursor":0}},
                "relation":{"facts":copy.deepcopy(facts),"id":1,"keys":[1]}}}

def dispose(value, owner):
    image=copy.deepcopy(value)
    handle=copy.deepcopy(owner)
    registry=handle["registry"]
    allowed=registry["namespace"]==image["world"]["namespace"] and any(
        all(registration[key]==registry[key] for key in ["id","name","access"])
        for registration in image["world"]["registrations"])
    if not allowed:
        return False,image,handle
    image["world"]["registrations"]=[registration for registration in image["world"]["registrations"]
        if not all(registration[key]==registry[key] for key in ["id","name","access"])]
    # RP.release is called only after Sys.Disposed. Here no callback activated
    # reader retention and all payload/journal lists were empty. Releases consume
    # actual owners and never reset allocation counters or unrelated state.
    stream=image["shared"]["typed"]["stream"]
    stream["positions"]=[p for p in stream["positions"] if p["id"] not in [1,2]]
    failures=image["shared"]["relationFailures"]
    failures["positions"]=[p for p in failures["positions"] if p["id"]!=1]
    assert failures["domains"]==[]
    return True,image,None

def derive():
    host=Allocator()
    own_namespace=host.fresh()
    foreign_namespace=host.fresh()
    assert own_namespace==1 and foreign_namespace==2 and own_namespace!=foreign_namespace
    # WIO.with_namespace checks nonzero and excludes UINT32_MAX.
    assert 0<own_namespace<0xffffffff and 0<foreign_namespace<0xffffffff
    own=context(own_namespace,True)
    foreign=context(foreign_namespace)
    owner=provider(own_namespace)
    before_context,before_provider=copy.deepcopy(foreign),copy.deepcopy(owner)
    allowed,foreign_after,provider_after=dispose(foreign,owner)
    assert not allowed and foreign_after==before_context and provider_after==before_provider
    foreign_record={"status":"rejected","contextBefore":before_context,
                    "contextAfter":foreign_after,"providerBefore":before_provider,
                    "providerAfter":provider_after,"contextPreserved":True,"providerPreserved":True}
    allowed,own_after,consumed=dispose(own,provider_after)
    assert allowed and consumed is None
    assert own_after["world"]["registrations"]==[]
    expected_own_after=copy.deepcopy(own)
    expected_own_after["world"]["registrations"]=[]
    assert own_after==expected_own_after, "empty disposal changes only registration observation"
    assert own_after["shared"]["typed"]["stream"]["nextReader"]==3
    assert own_after["shared"]["relationFailures"]["nextReader"]==2
    assert foreign_after["shared"]["typed"]["stream"]["nextReader"]==1
    assert foreign_after["shared"]["relationFailures"]["nextReader"]==1
    assert owner["readers"]["eventA"]["reader"]["id"]!=owner["readers"]["eventB"]["reader"]["id"]
    assert all(value["facts"]["namespace"]==own_namespace for value in owner["readers"].values())
    assert all(image["world"]["events"]==[] and image["routeTick"]==image["world"]["clock"]==0
               for image in [own,own_after,foreign,foreign_after])
    assert all(image["shared"]["relationFailures"]["positions"]==[] and
               image["shared"]["typed"]["stream"]["positions"]==[]
               for image in [own,own_after,foreign,foreign_after])
    result={"foreign":foreign_record,"own":{"status":"disposed","contextBefore":own,"contextAfter":own_after}}
    # All renderer fields are ASCII; Core.list_json and concatenation use compact
    # JSON punctuation. Base.IO.print appends one LF in each actual effect body.
    return (json.dumps(result,separators=(",",":"))+"\n").encode()

def verify_pins():
    pins=json.loads((HERE/"source-pins.json").read_text())
    for path,expected in pins.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected,path
    return len(pins)

if __name__=="__main__":
    data=derive()
    if "--write" in sys.argv:
        (HERE/"expected.stdout").write_bytes(data)
    else:
        assert (HERE/"expected.stdout").read_bytes()==data
    count=verify_pins()
    print(json.dumps({"sourceFilesVerified":count,"bytes":len(data),
                      "sha256":hashlib.sha256(data).hexdigest(),"stateInvariants":"passed"}))
