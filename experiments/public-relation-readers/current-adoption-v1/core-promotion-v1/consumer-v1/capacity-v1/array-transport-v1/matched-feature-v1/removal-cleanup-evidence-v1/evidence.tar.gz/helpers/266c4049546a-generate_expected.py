#!/usr/bin/env python3
"""Render the source-derived two-view removal-cleanup oracle.

The model uses only the pinned cleanup consumer/source snapshot and the
existing source-derived view constants. It does not read candidate output.
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE_PATH = HERE.parent / "generate_expected.py"
SPEC = importlib.util.spec_from_file_location("small_shared_oracle", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def compact(value: object) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"))


def value_notice(number: int) -> dict[str, object]:
    return {
        "kind": "original",
        "event": {"kind": "value", "value": number},
    }


def view(values: list[dict[str, object]], removals: list[dict[str, object]]) -> dict[str, object]:
    return {
        "query": BASE.QUERY,
        "eventA": {"values": values, "lagged": False},
        "eventB": {"values": values, "lagged": False},
        "removals": removals,
        "relations": BASE.relation_view(True),
    }


def expected_records() -> list[dict[str, object]]:
    # B was registered before A ran. Its event and removal cursors are
    # independent, so after A is disposed it still reads Value{11} and the
    # pending removal. Once B is disposed, last-reader removal cleanup strips
    # only the Removed notice/publication, leaving Value{11} aligned in both
    # the world log and typed publication journal. C is registered afterward;
    # its run appends Value{99} without the stale journal count dropping it.
    # Relation-failure queues are independent of removal cleanup and retain the
    # one unframed self-relation failure for the newly registered reader.
    b = view([BASE.VALUE_NOTICE], [BASE.REMOVAL])
    c = view([BASE.VALUE_NOTICE, value_notice(99)], [])
    return [b, c]


def expected_bytes() -> bytes:
    return (compact(expected_records()) + "\n").encode("ascii")


def main() -> None:
    print(compact(expected_records()))


if __name__ == "__main__":
    main()
