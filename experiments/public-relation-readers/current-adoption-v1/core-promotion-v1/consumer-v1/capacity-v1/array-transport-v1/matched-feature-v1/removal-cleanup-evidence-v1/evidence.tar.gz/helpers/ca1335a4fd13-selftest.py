#!/usr/bin/env python3
"""Check the cleanup oracle and its regression-sensitive observations."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("cleanup_oracle", HERE / "generate_expected.py")
assert SPEC is not None and SPEC.loader is not None
ORACLE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ORACLE)

basis = json.loads((HERE / "SOURCE-BASIS.json").read_text())
assert basis["format"] == "bendvy-source-derived-cleanup-oracle-v1"
assert basis["runtimeOutputConsulted"] is False
assert basis["entrypointSha256"] == basis["sourceFiles"][0]["sha256"]
assert len({row["path"] for row in basis["sourceFiles"]}) == len(basis["sourceFiles"])
snapshot_root = Path(basis["snapshotRoot"])
for row in basis["sourceFiles"]:
    source = snapshot_root / row["path"]
    content = source.read_bytes()
    assert hashlib.sha256(content).hexdigest() == row["sha256"], f"source drift: {row['path']}"
model_dependency = HERE / basis["modelDependency"]["path"]
assert hashlib.sha256(model_dependency.read_bytes()).hexdigest() == basis["modelDependency"]["sha256"]

expected = (HERE / "expected.stdout").read_bytes()
assert ORACLE.expected_bytes() == expected
views = json.loads(expected)
assert len(views) == 2
b, c = views
assert set(b) == set(c) == {"query", "eventA", "eventB", "removals", "relations"}
assert b["query"] == c["query"] == ORACLE.BASE.QUERY
assert b["eventA"]["values"] == b["eventB"]["values"] == [ORACLE.BASE.VALUE_NOTICE]
assert b["removals"] == [ORACLE.BASE.REMOVAL]
assert b["relations"] == c["relations"] == ORACLE.BASE.relation_view(True)
assert c["eventA"]["values"] == c["eventB"]["values"] == [
    ORACLE.BASE.VALUE_NOTICE,
    ORACLE.value_notice(99),
]
assert c["removals"] == []
print(f"PASS cleanup oracle {len(expected)} bytes sha256={hashlib.sha256(expected).hexdigest()}")
