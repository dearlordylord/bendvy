# Provider disposal source model

`expected.stdout` is the source-derived observation for the checked
`ordinary-disposal-consumer.bend` sequence. It covers A and B registration,
successful A execution and disposal while B remains registered, B's later
read of retained notices, rejection of disposal against a foreign context,
and successful final disposal of B.

The model pins the 63-file source snapshot in `SOURCE-BASIS.json`. Its foreign
context is constructed with the fixture's trusted seeded `W.Factory{2}`; this
does not establish ordinary `WorldIO` origin. No runtime output was consulted
to derive the model.

Run the deterministic source and observation checks with:

```sh
python3 selftest.py
```

The default source snapshot and pin-manifest paths are the retained `/tmp`
snapshot used for this derivation. Pass `--source-root` and `--source-manifest`
to validate an equivalent preserved snapshot at another location.
