#!/usr/bin/env python3
"""Render a source-derived counter-oracle for advancing event reader id + 1.

This models only the one-call-site mutant recorded in MUTATION.json. It starts
from the baseline consumer scenario and simulates the four registered event
reader positions; it never reads backend output.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

import generate_expected as baseline


def compact(value: object) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"))


def counter_records() -> list[dict[str, object]]:
    # EventOwner registrations share one stream and receive ids in nested
    # initialization order: A.eventA=1, A.eventB=2, B.eventA=3, B.eventB=4.
    # There is one original value batch at typed-stream tick 1. Reading uses
    # the strict cursor < batch.tick predicate from event-runtime.since.
    positions: dict[int, int] = {}
    records = copy.deepcopy(baseline.expected_records())
    for record in records:
        phase = record["phase"]
        if phase.startswith("A-"):
            reader_ids = (1, 2)
        else:
            reader_ids = (3, 4)

        for slot, reader_id in zip(("eventA", "eventB"), reader_ids):
            cursor = positions.get(reader_id, 0)
            has_value_batch = cursor < 1
            record["view"][slot]["values"] = (
                [copy.deepcopy(baseline.VALUE_NOTICE)] if has_value_batch else []
            )

        # The failed callback does not commit any parameter. On success, each
        # Event Param commits left-to-right and the mutant passes id+1 into
        # Stream.advance. A commit at attempt clock n writes that target
        # position's cursor through n-1, matching prepare_event's readThrough.
        if record["status"] == "completed":
            read_through = record["clock"] - 1
            for reader_id in reader_ids:
                positions[reader_id + 1] = read_through
    return records


def expected_bytes() -> bytes:
    return (compact(counter_records()) + "\n").encode("ascii")


def main() -> None:
    print(compact(counter_records()))


if __name__ == "__main__":
    main()
