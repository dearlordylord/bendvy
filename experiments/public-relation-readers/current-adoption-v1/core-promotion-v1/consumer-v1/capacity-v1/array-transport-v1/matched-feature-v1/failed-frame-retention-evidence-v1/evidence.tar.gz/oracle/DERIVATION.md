# First failed relation reader across frames

This is an independent source-only oracle for sibling
`ordinary-failed-frame-consumer.bend`, source commit
`e3a9f331bc40bc67b955ac94c068c562ec0a3ac6`, SHA256
`7ef2ef6589deb87815f39f158931f3936756ffbb5178b0d775278c3c4e633270`.
No runtime output, generated JS/C, backend receipt, or prior expected bytes was
consulted. Prior frozen oracles remain unchanged.

`expected.stdout` is the accepted existing failed-first-reader contract:5320
bytes, SHA256 `5ca28434e0b92396ba05496fea0e6fbec1ff9d87ba734aec1c60f359a1bb988f`.
`predicted-current-defect.stdout` is a **rejected diagnostic prediction**,4506
bytes, SHA256 `cc45b20f46af39cb8d06275cf058647433db9f83ec498c7da20c6ade228bc18b`.
The latter must never be used as accepted golden output. Both are complete JSON
objects followed by one LF from `IO.print`.

## Existing contract and precise missing transition

`docs/design/public-event-readers.md` states that retention activates on the
first actual registered run and failed valid first runs retain their original
cursor. `docs/design/s-integrate-reader-implementation.md`, Dispatcher hooks,
requires a missing slot with registeredAt=old tick and saved positions0 before
invocation; registration survives first failure and failure does not advance it.
These existing rules supply the contract; no new law or numerical requirement
is proposed here.

The actual standalone implementation provides the exact transition:
`src/ecs/relation-failure-runtime.bend` `run_identified` uses `position_or` at
its previous read tick; `outcome` calls `failed_clocked` on failure. That function
returns `Read.activate(keys,domains,id)` and `Ev.activate(positions,id,previous)`.
`internal/relation-failures/readings.bend` `activate` attaches the holder only to
its declared key; `event-runtime.bend` `activate` inserts cursor0 and preserves
an existing position without advancing it. For this ordinary consumer's first
read, ingestion establishes positive failure epoch1 before prepare, so the
missing holder is descriptor1/readers `[1]` and position
`{id:1,cursor:0,registeredAt:1}`. Successful retry later changes only cursor to2.

The frozen current ordinary `ordinary-reader-stream-parameter.bend`
`relation_prepared` computes the fallback position and detached reading but
returns shared domains/positions unchanged. `ordinary-reader-system.bend`
`callback_failure` commits no reader delta, so first failure leaves no holder.
This does not implement the existing first-run contract. The accepted oracle
retains activation metadata while preserving unread cursor0. This can be
implemented before callback or on failure, provided complete observations agree.

## Complete operation and serializer derivation

All referenced source files and renderer bodies are hash-pinned.

1. `Core.setup` is the actual imported scheduled consumer setup: one World,
   namespace1/entity1, live component42, and original Value11 followed by original
   removal(entity1,value). Store contains the actual empty relation graph.
   Only provider A is defined, with leaf IDs1/2, removal registry1, keyed ID1;
   next failure reader2. Initial route/failure clocks and all cursor state are0.
2. `Core.schedule_relation` calls the real Writable relation provider twice.
   `transaction.bend` `finish_world` commits the first staged closure; Failure77
   discards the second. Both queue statuses are Queued. `Core.barrier_context`
   calls actual `world.bend` `barrier`; its single command invokes
   `relation-commands.bend` `apply_relate`/`publish_relate`. The hierarchy
   self-relation validator rejects live entity1 as its own target, retains both
   graph arrays, and publishes exactly one complete relationFailure notice.
   The initial observation therefore has clock0/pending0 and three World events
   in order, while shared failure domains/positions remain empty.
3. `Core.run_all(...,True)` first ingests at epoch1 using
   `event-notice-runtime.bend` `before_state`. It journals both originals,
   forwards only Value11 through `Core.sync_events` to the message stream, and
   routes the one error to descriptor1 queue back batch `{tick:1,count:1,...}`.
   World retains the two originals. The actual attempt advances World clock1,
   route tick2, leaving failure tick1. Both message readers, removal, query,
   and relation reading are fully rendered. With(value) query projects Unit
   as null; the affine component owner remains42. Failure7 leaves query/removal
   cursors0. Under the existing contract, it retains descriptor membership `[1]`
   and position `(1,0,1)`; queue size1/dropped0 is unchanged.
4. `Mixed.frame_failures` detaches the standalone failure runtime and calls
   `relation-failure-runtime.bend` `frame` twice. `domains.bend` `boundary` uses
   min(old frameStart, declared holder cursor). `queue.bend` `trim` normalizes
   the back list to front before retaining/removing oldest whole batches.
   Frame1 uses boundary0: queue becomes front[batch1], back[], size1/dropped0;
   frameStart becomes1 and exposed boundary0. Frame2 uses min(1,0)=0:
   the same batch survives, frameStart1/boundary1. Neither frame advances World
   clock, route tick, failure tick, provider cursor, or performs a typed frame.
5. Retry ingests at route epoch2, increments World clock2/route tick3, and reads
   the retained relation batch via cursor0/registeredAt1. The complete retry view
   equals the first failed callback view, including full error and false lag.
   Success commits removal count2, message cursors2, keyed cursor2 while keeping
   registeredAt1, and provider query cursor2. `after_success` ingests at route
   tick3 without duplication: final failure tick3, frameStart1/boundary1,
   descriptor readers[1], position `(1,2,1)`, front[batch1], size1/dropped0.
6. The consumer's `phase_record_cursor` defines exact field order:
   phase/status/error/queryCursor/view/state; `snapshot_state` emits shared/world.
   `failure_image_json` orders routeTick/tick/frameStart/boundary/capacity/
   nextReader/positions/domains. Domain fields are key/readers/queue; queue is
   front/back/size/dropped. `Core.world_observation_json` retains complete
   namespace/clock/pending/graph/events. Core JSON helpers retain full nested
   descriptor, operation, source/target and SelfRelationNotAllowed error fields.
   No array is replaced with counts or checksums. `final_output` orders mutation
   then observations. Installed Base print.js/print.c append the sole final LF.

## Rejected source-current prediction

With no holder/position after first failure, frame1 still retains/normalizes
batch1 (old frameStart0). Frame2 trims against1, removes batch1, leaves size0 and
records dropped1. Retry has no position and fabricates fallback registeredAt2;
its relation values are empty, and lag is silently false because
`max(cursor0,registeredAt2) < dropped1` is false. Success then activates
`(1,2,2)` and descriptor readers[1] over the empty/dropped queue. This complete
prediction is retained separately to diagnose the current implementation; it
does not weaken the accepted preservation and first-registration rules.

## Pinning, checks, and scope

`source-pins.json` binds the64 actual recursively imported Bend bodies, installed
Base plus two print effect bodies, both existing design references, and the Rust
Bevy message cursor reference (70 files). It uses immutable-content hashes over
actual source-worktree paths; the implementation may acquire a separately pinned
successor after the expected mismatch is demonstrated. The oracle must not be
rewritten to accept a known defect.

Reference priority remains Rust Bevy first, Bend constraints second, bevy-ts
inventory third. The Bevy reference is the manifest revision
`ad678262ce53b5d142fe49ee5e08caff6f00ab60`; per-reader cursor state lives in
`crates/bevy_ecs/src/message/message_cursor.rs`. The explicit ordinary-product
commit-on-success protocol and existing standalone Bend failure retention supply
this exact expected metadata; no implicit rollback of a directly used Bevy cursor
is claimed.

Run `python3 derive.py`: verifies all70 pins, both independently calculated full
byte artifacts, first-error publication/order, first-failure cursor preservation,
frame normalization/retention, positive epochs, belowcapacity size, full retry
view equality, false lag with no drop, no duplicate journal publication, complete
World event arrays, final successful cursor updates, and the rejected defect's
specific silent-loss divergence. `--write` regenerates solely from the model.
Python source checks also pass. No backend was invoked.

This qualifies an expected contract for one first-failure/two-frame/retry
consumer. Backend execution, cleanup/disposal, capacity overflow behavior,
performance, and the combined regression remain separate gates. The serializer
observes complete declared WorldObservation and failure-state fields; it does
not expose every affine World field or the reader owner internals directly.
