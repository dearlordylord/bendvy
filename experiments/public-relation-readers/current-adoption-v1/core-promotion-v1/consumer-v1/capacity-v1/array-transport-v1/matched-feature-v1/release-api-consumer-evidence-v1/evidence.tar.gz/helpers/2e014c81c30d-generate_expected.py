#!/usr/bin/env python3
"""Render the source-derived five-step shared-reader consumer oracle.

This model intentionally consumes no candidate stdout or runtime artifact. It
encodes the selected setup notices, mixed-ingest boundary, and five calls from
the pinned Bend sources into the consumer's declared JSON projection. The
reached sync callback filters removal publications out of the typed event
stream; the removal parameter projects those World notices separately.
"""
from __future__ import annotations

import json
from pathlib import Path

ENTITY = {"namespace": 1, "id": 1}
QUERY = [{"entity": ENTITY, "value": None}]
VALUE_NOTICE = {"kind": "original", "event": {"kind": "value", "value": 11}}
REMOVAL = {"entity": ENTITY, "component": "value"}
RELATION_FAILURE = {
    "key": 1,
    "values": [
        {
            "kind": "relationFailure",
            "failure": {
                "relation": {
                    "key": 1,
                    "name": "Parent",
                    "inverse": "Children",
                    "kind": "hierarchy",
                },
                "operation": "relate",
                "source": 1,
                "target": 1,
                "error": {"kind": "self", "source": 1, "relation": "Parent"},
            },
        }
    ],
    "lagged": False,
}


def compact(value: object) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"))


def event_view(published: bool) -> dict[str, object]:
    return {"values": [VALUE_NOTICE] if published else [], "lagged": False}


def relation_view(published: bool) -> list[dict[str, object]]:
    values = [RELATION_FAILURE["values"][0]] if published else []
    # Read.all returns one KeyReading per declared relation key even after its
    # queue is consumed; an empty reading still carries key and lag metadata.
    return [{"key": 1, "values": values, "lagged": False}]


def observation(
    phase: str,
    status: str,
    error: int | None,
    clock: int,
    query_cursor: int,
    *,
    event_a: bool,
    event_b: bool,
    removal: bool,
    relation_a: bool,
) -> dict[str, object]:
    # `eventB` is a separately registered event owner, not an alias of A.
    return {
        "phase": phase,
        "status": status,
        "error": error,
        "clock": clock,
        "queryCursor": query_cursor,
        "view": {
            "query": QUERY,
            "eventA": event_view(event_a),
            "eventB": event_view(event_b),
            "removals": [REMOVAL] if removal else [],
            "relations": relation_view(relation_a),
        },
    }


def expected_records() -> list[dict[str, object]]:
    # The first A callback fails after preparing every parameter. That advances
    # the attempt/world clock but commits no system, event, removal, or relation
    # reader cursor. A retry therefore sees the same histories and then commits
    # through tick/count 2. B was separately registered at cursor zero, so its
    # first read remains independent of A's successful consumption.
    return [
        observation(
            "A-fail", "failed", 7, 1, 0,
            event_a=True, event_b=True, removal=True, relation_a=True,
        ),
        observation(
            "A-retry", "completed", None, 2, 2,
            event_a=True, event_b=True, removal=True, relation_a=True,
        ),
        observation(
            "A-repeat", "completed", None, 3, 3,
            event_a=False, event_b=False, removal=False, relation_a=False,
        ),
        observation(
            "B-first", "completed", None, 4, 4,
            event_a=True, event_b=True, removal=True, relation_a=True,
        ),
        observation(
            "B-repeat", "completed", None, 5, 5,
            event_a=False, event_b=False, removal=False, relation_a=False,
        ),
    ]


def expected_bytes() -> bytes:
    return (compact(expected_records()) + "\n").encode("ascii")


def main() -> None:
    print(compact(expected_records()))


if __name__ == "__main__":
    main()
