#!/usr/bin/env python3
"""Deterministic checks for the source-derived small consumer oracle."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import posixpath
import re
import tarfile

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("oracle", HERE / "generate_expected.py")
assert SPEC is not None and SPEC.loader is not None
ORACLE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ORACLE)
COUNTER_SPEC = importlib.util.spec_from_file_location(
    "counter_oracle", HERE / "generate_wrong_reader_advance.py"
)
assert COUNTER_SPEC is not None and COUNTER_SPEC.loader is not None
COUNTER = importlib.util.module_from_spec(COUNTER_SPEC)
COUNTER_SPEC.loader.exec_module(COUNTER)

BASIS = json.loads((HERE / "SOURCE-BASIS.json").read_text())
SOURCE_ROOT = Path(BASIS["producerRoot"])
assert BASIS["format"] == "bendvy-independent-source-basis-v1"
assert BASIS["runtimeOutputConsulted"] is False
source_rows = BASIS["sourceFiles"]
source_by_path = {row["path"]: row for row in source_rows}
assert len(source_by_path) == len(source_rows) == BASIS["moduleImportClosureCount"]

# Read only the source members from the already-retained producer archive.
# The live producer worktree can advance independently; SOURCE-BASIS remains
# bound to its original 61 source bodies and is never rebound to that drift.
ARCHIVE_PIN = json.loads((HERE / "SOURCE-ARCHIVE.json").read_text())
assert ARCHIVE_PIN["sourceBasisSha256"] == hashlib.sha256(
    (HERE / "SOURCE-BASIS.json").read_bytes()
).hexdigest()
archive_path = SOURCE_ROOT / ARCHIVE_PIN["evidenceArchivePath"]
archive = tarfile.open(archive_path, "r:gz")
source_members = {
    name for name in archive.getnames() if name.startswith(ARCHIVE_PIN["sourceMemberPrefix"])
}
expected_members = {ARCHIVE_PIN["sourceMemberPrefix"] + path for path in source_by_path}
assert source_members == expected_members, "retained archive source-member set differs from SOURCE-BASIS"
source_bytes: dict[str, bytes] = {}
for path, row in source_by_path.items():
    member = archive.getmember(ARCHIVE_PIN["sourceMemberPrefix"] + path)
    assert member.isfile(), f"pinned source is not a regular file: {path}"
    stream = archive.extractfile(member)
    assert stream is not None, f"cannot read pinned source member: {path}"
    content = stream.read()
    assert len(content) == row["bytes"], f"source size drift: {path}"
    assert hashlib.sha256(content).hexdigest() == row["sha256"], f"source hash drift: {path}"
    source_bytes[path] = content
archive.close()

# Reconstruct the ordinary relative .bend import closure to ensure the pinned
# source list covers the consumer and every filesystem module it reaches.
seen: set[str] = set()
pending = [BASIS["entrypoint"]]
while pending:
    path = pending.pop()
    if path in seen:
        continue
    seen.add(path)
    for line in source_bytes[path].decode("utf-8").splitlines():
        match = re.match(r"^import\s+([^\s]+)", line)
        if not match:
            continue
        imported = match.group(1)
        if imported == "Base" or not imported.endswith(".bend"):
            continue
        resolved = posixpath.normpath(posixpath.join(posixpath.dirname(path), imported))
        assert resolved in source_bytes, f"unresolved source import: {path} -> {imported}"
        pending.append(resolved)
actual_closure = seen
assert actual_closure == set(source_by_path), "pinned source list differs from consumer import closure"

actual = ORACLE.expected_bytes()
committed = (HERE / "expected.stdout").read_bytes()
assert actual == committed, "generated oracle differs from expected.stdout"
records = ORACLE.expected_records()
assert [row["phase"] for row in records] == [
    "A-fail", "A-retry", "A-repeat", "B-first", "B-repeat"
]
assert [row["clock"] for row in records] == [1, 2, 3, 4, 5]
assert [row["queryCursor"] for row in records] == [0, 2, 3, 4, 5]
assert records[0]["status"] == "failed" and records[0]["error"] == 7
assert records[0]["view"] == records[1]["view"], "failed callback must preserve prepared readings"
assert records[2]["view"]["eventA"]["values"] == []
assert records[3]["view"]["eventA"]["values"] == ORACLE.event_view(True)["values"]
assert records[3]["view"]["eventB"]["values"] == ORACLE.event_view(True)["values"]
assert records[2]["view"]["relations"] == ORACLE.relation_view(False)
assert records[4]["view"]["relations"] == ORACLE.relation_view(False)
assert records[0]["view"]["eventA"]["values"] == ORACLE.event_view(True)["values"]
assert records[0]["view"]["eventB"]["values"] == ORACLE.event_view(True)["values"]
assert records[0]["view"]["eventA"]["values"] == [ORACLE.VALUE_NOTICE]
assert records[0]["view"]["eventB"]["values"] == [ORACLE.VALUE_NOTICE]
assert records[0]["view"]["removals"] == [ORACLE.REMOVAL]
assert records[4]["view"]["removals"] == []

# Bind the counter-model to the exact source expression it mutates. The input
# bytes are already covered by the complete SOURCE-BASIS hash check above.
mutation = json.loads((HERE / "MUTATION.json").read_text())
assert mutation["runtimeOutputConsulted"] is False
mutation_source = source_by_path[mutation["mutation"]["sourcePath"]]
assert mutation_source["sha256"] == mutation["mutation"]["sourceSha256"]
mutation_text = source_bytes[mutation["mutation"]["sourcePath"]].decode("utf-8")
assert mutation["mutation"]["call"] in mutation_text
assert "Stream{domain,[],[],1,0n,0n,capacity,0n}" in (
    source_bytes["src/ecs/event-stream.bend"].decode("utf-8")
)

counter = COUNTER.counter_records()
counter_committed = (HERE / "wrong-reader-advance.expected.stdout").read_bytes()
assert COUNTER.expected_bytes() == counter_committed
assert counter_committed != committed, "wrong-reader advancement must falsify the baseline oracle"
assert [row["phase"] for row in counter] == [row["phase"] for row in records]
assert [
    (bool(row["view"]["eventA"]["values"]), bool(row["view"]["eventB"]["values"]))
    for row in counter
] == [(True, True), (True, True), (True, False), (False, True), (False, False)]
for baseline_row, counter_row in zip(records, counter):
    counter_without_events = json.loads(json.dumps(counter_row))
    counter_without_events["view"]["eventA"] = baseline_row["view"]["eventA"]
    counter_without_events["view"]["eventB"] = baseline_row["view"]["eventB"]
    assert counter_without_events == baseline_row, "mutation may affect only event views"
print(
    f"PASS source-derived baseline: {len(committed)} bytes "
    f"sha256={hashlib.sha256(committed).hexdigest()}"
)
print(
    f"PASS wrong-reader counter-oracle: {len(counter_committed)} bytes "
    f"sha256={hashlib.sha256(counter_committed).hexdigest()}"
)
