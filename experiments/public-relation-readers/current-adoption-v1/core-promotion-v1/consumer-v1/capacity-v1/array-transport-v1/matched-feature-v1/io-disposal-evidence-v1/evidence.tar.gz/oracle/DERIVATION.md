# IO-origin ordinary provider disposal oracle

This source-only model derives the complete JSON+LF output of
`ordinary-io-disposal-consumer.bend`, producer commit
`fe9b625a5fa97cd3a94f547458c2427f1492e74b`, source SHA256
`cf77e9e60df512a72f968cb33eb777780208e35bbf0e902c014e60b468f6df31`.
It consults no runtime output, generated JS/C, or backend receipt and invokes no
backend. Imported source C/JS effect bodies are read as source, not generated
artifacts. Earlier oracle artifacts are unchanged.

`expected.stdout` is3814 bytes, SHA256
`2cce1591d07c2c3b45eea5006a2a38d66bd68f911f5728ad0bf945c9bc11432e`.
It preserves every rendered Context/Provider field and array, both preservation
booleans, the full rejected-disposal snapshots and successful own-disposal
snapshots, with exact compact JSON punctuation and a single LF.

## Derivation and source basis

All paths below are source-pinned; ECS functions are in the actual helper
worktree's `src/ecs/`. `source-pins.json` covers66 actual recursively imported
Bend files, installed Base, both actual world-namespace effects, and both Base
print effects (71 files). It includes actual uncommitted dependency bodies,
rather than assuming the producer commit alone binds dependencies.

- Main's `main` calls `WIO.create` and passes its result to `first_world`.
  Only after the first Created result, `first_world` calls the second create via
  `IO.bind`. `world-io.bend` `create` binds `world-namespace.bend` `fresh`, then
  `with_namespace` accepts only `0 < namespace < UINT32_MAX`. Neither call uses
  the literal seeded `W.Factory{2}` in the imported disposal fixture's unused
  `foreign_context` function. No other fresh effect runs in this callgraph.
- Actual `world-namespace.c` starts its process atomic at1, returns old on a
  successful compare-exchange and increments it. Actual `world-namespace.js`
  stores the counter under `Symbol.for("bendvy.world.namespace.v1")` in the
  shared realm, initializes absent state to next1, returns next++, and refuses
  exhaustion instead of wrapping. Thus one fresh standalone Native process or
  fresh JS realm derives namespaces1 then2 from actual effects. Their distinct
  provenance is operational, not a fabricated namespace assertion in the Bend
  fixture. The model's small sequential allocator implements these source
  transitions without executing either effect.
- `world.bend` `create_checked` initializes empty worlds: nextId1, highWater0,
  capacity1/depth0, clock0, empty events/registrations, nextSystemId1. No entities
  are reserved or activated. Core `empty_store` is the empty column; no callback
  or query executes. `context_from_world` calls `Mixed.start` with an empty
  values stream, empty journal, route tick0; standalone failure start copies
  clock0, creates no domains/positions and nextReader1.
- Main `run` calls `Core.define_all(own,"io-disposal")` only on the first World.
  `ordinary-reader-system.bend` definition registers one actual affine provider.
  `reader-parameter.bend` pair initialization follows query, eventA, eventB,
  removal, relation. Query owner is Unit. Two message IDs1/2 are allocated from
  the same stream, so stream nextReader3 while positions remain empty. Removal
  owns registry1/name value/cursor0. Relation reserves ID1 independently, so
  failure nextReader2 while domains/positions remain empty. Each reader's facts
  retain namespace1/id1/name io-disposal and the complete ordered access list
  `[value,values:read,values:read,removal,value,Parent:read]`.
  Registry cursor remains0; no reader has run or activated retention.
- `attempt_foreign` captures actual own/foreign Contexts and Provider using
  `Disposal.context_keep` and `provider_keep`, then calls `Disposal.dispose_all`
  with the namespace2 Context. `ordinary-reader-system.bend`
  `provider_dispose_parts` delegates to `Sys.dispose`. `registration.bend`
  `remove` checks both namespace equality and exact registration metadata.
  Namespace1 != namespace2 rejects removal. `provider_disposal_result` returns
  the same joined Context and reconstructed actual Provider, without invoking
  `RP.release`. The foreign World has no matching registration anyway. Both
  complete serialized snapshots remain byte-identical and both booleans aretrue.
- `foreign_rejected_snapshots` passes the returned actual Provider to
  `Disposal.dispose_all(provider,own)`. Here exact namespace/id/name/access match,
  so the registration is removed. Only on `Sys.Disposed`, `RP.release` consumes
  the reader owners. Query release preserves Context. Event release removes
  any matching positions (none exist). Removal release finds no remaining
  removal registration and cleans matching history (all lists were empty).
  Relation release removes matching membership/position (none exist).
  Allocators are not reset: own stream nextReader remains3 and failure
  nextReader2, distinct from untouched foreign allocators1/1. Clocks stay0;
  no value/event/retention payload or position is introduced. The owned provider
  is consumed on success and is not serialized as if it survived disposal.
- The imported disposal serializer specifies complete observable ordering.
  `world_keep`: namespace/nextId/highWater/capacity/depth/clock/events/registrations.
  `context_keep_parts`: world/routeTick/shared. `mixed_state_keep_family`:
  typed/relationFailures. `family_state_keep`: stream/journal/frameStart.
  `family_stream_json`: domain/batches/positions/nextReader/frameStart/boundary/
  capacity/dropped. `failure_state_json`: domains/positions/tick/frameStart/
  boundary/capacity/nextReader. `provider_keep_results`: registry/readers;
  registry namespace/id/name/access/cursor; readers eventA/eventB/removal/relation.
  Facts and actual reader identities are rendered completely by their named
  helper renderers. Main orders foreign then own; foreign status/contextBefore/
  contextAfter/providerBefore/providerAfter/contextPreserved/providerPreserved;
  own status/contextBefore/contextAfter. All names are frozen ASCII.
  `Core.list_json` inserts compact commas and each actual Base print effect
  appends exactly one LF.

## Verification, host assumptions, and limits

`python3 derive.py` verifies all71 pins and complete expected bytes, namespace
allocation/order/distinctness, exact metadata refusal, complete foreign Context
and Provider preservation, successful owner consumption, only registration
observation changing on own disposal, monotonic reader allocators, independent
message IDs, preserved zero clocks/cursors, empty retention metadata, and no
callback publication. `--write` regenerates the full expected output from this
model. Python source checks pass. No candidate or backend execution occurs.

The source helper pin is `ordinary-reader-stream-parameter.bend`
`3cbb45cc68dc9ba74fe2e1d68b4f6b436defb8645a70cbc6c6f84bbe52b1b58a`;
provider module `ordinary-reader-system.bend`
`fc77436d07307f4d6df1682cbd106d9c4052ba9d1e71fe25c92dadf9c60a833c`.
A separately pinned prepare-only first-callback retention successor has no
reachable effect in this fixture because no callback runs; that observation
cannot substitute for recording its actual successor source hash.

The fresh process/realm precondition matters: a pre-populated shared JS host
symbol counter need not begin at1. Native atomic and JS realm scope are actual
host provenance boundaries, not a mathematical proof of process-global identity
in arbitrary linking arrangements. The supplied source-check status is reported
as type/affine clean with the expected unsafe/foreign verdict for WorldIO effects;
this model does not treat a check-only exit1 as backend acceptance or change any
flags. The reference Bend `bend2/main.ts` `cli_verdict` explicitly returns1 when
outside-Base definitions rely on foreign code; actual execution uses the existing
approved WorldIO backend lane.

This expectation covers exactly the empty two-WorldIO-world disposal control.
It does not qualify nonempty cleanup, callback failure retention, generated
backend correctness, performance, or combined regression. The source serializer
preserves but does not render affine live/store/resource/pending owner values
or nextSystemId; the oracle adds no invented fields or disposal extension to
that observable contract. No new laws, limits, dependencies, or contracts are
introduced.
