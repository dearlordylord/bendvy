#!/usr/bin/env python3
"""Render the source-derived ordinary-provider disposal observation.

This model is derived from the pinned consumer and ECS source closure. It does
not read candidate output, compiler artifacts, or runtime receipts.
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
BASE_PATH = HERE.parent / "generate_expected.py"
SPEC = importlib.util.spec_from_file_location("small_shared_oracle", BASE_PATH)
assert SPEC is not None and SPEC.loader is not None
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)

ACCESS = ["value", "values:read", "values:read", "removal", "value", "Parent:read"]
VALUE_PUBLICATION = {"kind": "value", "value": 11}
REMOVED_PUBLICATION = {"kind": "removed", "record": BASE.REMOVAL}
REMOVAL_NOTICE = {"kind": "original", "event": REMOVED_PUBLICATION}
RELATION_NOTICE = BASE.RELATION_FAILURE["values"][0]


def compact(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"))


def position(reader_id: int, cursor: int, registered_at: int) -> dict[str, int]:
    return {"id": reader_id, "cursor": cursor, "registeredAt": registered_at}


def event_view() -> dict[str, Any]:
    return {"values": [BASE.VALUE_NOTICE], "lagged": False}


def relation_view() -> list[dict[str, Any]]:
    return BASE.relation_view(True)


def observed_view() -> dict[str, Any]:
    return {
        "query": BASE.QUERY,
        "eventA": event_view(),
        "eventB": event_view(),
        "removals": [BASE.REMOVAL],
        "relations": relation_view(),
    }


def registration(system_id: int, name: str) -> dict[str, Any]:
    return {"id": system_id, "name": name, "access": ACCESS}


def facts(system_id: int, name: str) -> dict[str, Any]:
    return {"namespace": 1, "id": system_id, "name": name, "access": ACCESS}


def event_owner(system_id: int, name: str, event_reader_id: int) -> dict[str, Any]:
    return {
        "facts": facts(system_id, name),
        "reader": {"namespace": 1, "id": event_reader_id, "registryId": system_id},
    }


def removal_owner(system_id: int, name: str, cursor: int) -> dict[str, Any]:
    return {
        "facts": facts(system_id, name),
        "reader": {"namespace": 1, "id": system_id, "name": "value", "cursor": cursor},
    }


def relation_owner(system_id: int, name: str) -> dict[str, Any]:
    return {"facts": facts(system_id, name), "id": system_id, "keys": [1]}


def provider(system_id: int, name: str, cursor: int, event_a_id: int,
             event_b_id: int, removal_cursor: int) -> dict[str, Any]:
    return {
        "registry": {
            "namespace": 1,
            "id": system_id,
            "name": name,
            "access": ACCESS,
            "cursor": cursor,
        },
        "readers": {
            "eventA": event_owner(system_id, name, event_a_id),
            "eventB": event_owner(system_id, name, event_b_id),
            "removal": removal_owner(system_id, name, removal_cursor),
            "relation": relation_owner(system_id, name),
        },
    }


def failure_queue() -> dict[str, Any]:
    return {
        "front": [],
        "back": [{"tick": 1, "count": 1, "values": [RELATION_NOTICE]}],
        "size": 1,
        "dropped": 0,
    }


def typed_state(event_positions: list[dict[str, int]], *, removal_retained: bool) -> dict[str, Any]:
    publications = [VALUE_PUBLICATION]
    if removal_retained:
        publications.append(REMOVED_PUBLICATION)
    return {
        "stream": {
            "domain": "values",
            "batches": [{"tick": 1, "values": [BASE.VALUE_NOTICE]}],
            "positions": event_positions,
            "nextReader": 5,
            "frameStart": 0,
            "boundary": 0,
            "capacity": 65536,
            "dropped": 0,
        },
        "journal": [{"tick": 1, "values": publications}],
        "frameStart": 0,
    }


def relation_failures(readers: list[int], positions: list[dict[str, int]], tick: int) -> dict[str, Any]:
    return {
        "domains": [{"key": 1, "queue": failure_queue(), "readers": readers}],
        "positions": positions,
        "tick": tick,
        "frameStart": 0,
        "boundary": 0,
        "capacity": 65536,
        "nextReader": 3,
    }


def world(clock: int, events: list[dict[str, Any]], registrations: list[dict[str, Any]],
          *, namespace: int = 1, next_id: int = 2, high_water: int = 1,
          capacity: int = 2, depth: int = 1, next_system_id: int = 3) -> dict[str, Any]:
    return {
        "namespace": namespace,
        "nextId": next_id,
        "highWater": high_water,
        "capacity": capacity,
        "depth": depth,
        "clock": clock,
        "events": events,
        "registrations": registrations,
    }


def context(*, clock: int, route_tick: int, events: list[dict[str, Any]],
            registrations: list[dict[str, Any]], event_positions: list[dict[str, int]],
            failure_readers: list[int], failure_positions: list[dict[str, int]],
            failure_tick: int, removal_retained: bool, namespace: int = 1,
            next_id: int = 2, high_water: int = 1, capacity: int = 2,
            depth: int = 1, next_system_id: int = 3) -> dict[str, Any]:
    return {
        "world": world(clock, events, registrations, namespace=namespace, next_id=next_id,
                       high_water=high_water, capacity=capacity, depth=depth,
                       next_system_id=next_system_id),
        "routeTick": route_tick,
        "shared": {
            "typed": typed_state(event_positions, removal_retained=removal_retained),
            "relationFailures": relation_failures(failure_readers, failure_positions, failure_tick),
        },
    }


def foreign_context() -> dict[str, Any]:
    return {
        "world": world(0, [], [], namespace=2, next_id=1, high_water=0,
                       capacity=1, depth=0, next_system_id=1),
        "routeTick": 0,
        "shared": {
            "typed": {
                "stream": {
                    "domain": "values",
                    "batches": [],
                    "positions": [],
                    "nextReader": 1,
                    "frameStart": 0,
                    "boundary": 0,
                    "capacity": 65536,
                    "dropped": 0,
                },
                "journal": [],
                "frameStart": 0,
            },
            "relationFailures": {
                "domains": [],
                "positions": [],
                "tick": 0,
                "frameStart": 0,
                "boundary": 0,
                "capacity": 65536,
                "nextReader": 1,
            },
        },
    }


def expected_records() -> dict[str, Any]:
    reg_a, reg_b = registration(1, "A"), registration(2, "B")
    events_with_removal = [BASE.VALUE_NOTICE, REMOVAL_NOTICE]
    events_without_removal = [BASE.VALUE_NOTICE]

    after_a_run = context(
        clock=1, route_tick=1, events=events_with_removal, registrations=[reg_b, reg_a],
        event_positions=[position(2, 0, 0), position(1, 0, 0)],
        failure_readers=[1], failure_positions=[position(1, 1, 1)], failure_tick=1,
        removal_retained=True,
    )
    after_a_dispose = context(
        clock=1, route_tick=1, events=events_with_removal, registrations=[reg_b],
        event_positions=[], failure_readers=[], failure_positions=[], failure_tick=1,
        removal_retained=True,
    )
    after_b_run = context(
        clock=2, route_tick=2, events=events_with_removal, registrations=[reg_b],
        event_positions=[position(4, 1, 0), position(3, 1, 0)],
        failure_readers=[2], failure_positions=[position(2, 1, 1)], failure_tick=2,
        removal_retained=True,
    )
    after_b_dispose = context(
        clock=2, route_tick=2, events=events_without_removal, registrations=[],
        event_positions=[], failure_readers=[], failure_positions=[], failure_tick=2,
        removal_retained=False,
    )

    provider_a = provider(1, "A", 1, 1, 2, 2)
    provider_b_before = provider(2, "B", 0, 3, 4, 0)
    provider_b_after = provider(2, "B", 1, 3, 4, 2)
    foreign = foreign_context()

    return {
        "aRunView": observed_view(),
        "disposeA": {
            "before": after_a_run,
            "after": after_a_dispose,
            "providerA": provider_a,
            "providerBBefore": provider_b_before,
            "providerBAfter": provider_b_before,
            "providerBPreserved": True,
        },
        "bRunView": observed_view(),
        "contextAfterB": after_b_run,
        "foreignRefusal": {
            "status": "rejected",
            "before": foreign,
            "after": foreign,
            "providerBefore": provider_b_after,
            "providerAfter": provider_b_after,
            "contextPreserved": True,
            "providerPreserved": True,
        },
        "disposeB": {
            "before": after_b_run,
            "provider": provider_b_after,
            "after": after_b_dispose,
        },
    }


def expected_bytes() -> bytes:
    return (compact(expected_records()) + "\n").encode("ascii")


def main() -> None:
    print(compact(expected_records()))


if __name__ == "__main__":
    main()
