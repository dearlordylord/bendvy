function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return (_x_0) => $IO$print$(($setup_ready$(($ordinary$045scheduled$045reader$045consumer$058setup$()))), _x_0);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $setup_ready$(_state_0) {
  if (_state_0.$ === "ordinary-scheduled-reader-consumer.Ready") {
    const _context_0 = _state_0["context"];
    const _entity_0 = _state_0["entity"];
    return $define_result$(_entity_0, ($ordinary$045scheduled$045reader$045consumer$058define_all$(_context_0, "A")));
  } else {
    return "{\"status\":\"setupFailed\"}";
  }
}

function $ordinary$045scheduled$045reader$045consumer$058setup$() {
  return $ordinary$045scheduled$045reader$045consumer$058setup_created$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "Unit"})));
}

function $define_result$(_entity_0, _defined_0) {
  if (_defined_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.DefinitionRegistered") {
    const _context_0 = _defined_0["context"];
    const _provider_0 = _defined_0["provider"];
    return $scheduled_observation$(_provider_0, ($ordinary$045scheduled$045reader$045consumer$058schedule_relation$(_context_0, _entity_0)));
  } else if (_defined_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.DefinitionRejected") {
    return "{\"status\":\"definitionRejected\"}";
  } else {
    return "{\"status\":\"definitionDisposalRejected\"}";
  }
}

function $ordinary$045scheduled$045reader$045consumer$058define_all$(_context_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058define_mixed$1260$(($ordinary$045scheduled$045reader$045consumer$058all_parameter$()), {$: "Unit"}, _context_0, _name_0);
}

function $ordinary$045scheduled$045reader$045consumer$058setup_created$(_created_0) {
  if (_created_0.$ === "../../../../../../../../src/ecs/world.CreateRejected") {
    return {$: "ordinary-scheduled-reader-consumer.SetupFailed"};
  } else {
    const _world_0 = _created_0["world"];
    return $ordinary$045scheduled$045reader$045consumer$058setup_reserved$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../../../../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $scheduled_observation$(_provider_0, _scheduled_0) {
  const _context_0 = _scheduled_0["fst"];
  const _report_0 = _scheduled_0["snd"];
  return $after_barrier$(($ordinary$045scheduled$045reader$045consumer$058barrier_context$(_context_0)), _provider_0, _report_0);
}

function $ordinary$045scheduled$045reader$045consumer$058schedule_relation$(_context_0, _entity_0) {
  return $ordinary$045scheduled$045reader$045consumer$058schedule_relation_first$(_entity_0, ($ordinary$045scheduled$045reader$045consumer$058submit_relation$(_context_0, _entity_0, {$: "../../../../../../../../src/ecs/transaction.Success"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058define_mixed$1260$(_descriptor_0, _declaration_0, _context_0, _name_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058define_access$1260$(_declaration_0, _context_0, _name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058access$1260$(_descriptor_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058all_parameter$() {
  return $ordinary$045scheduled$045reader$045consumer$058pair_all$(($ordinary$045scheduled$045reader$045consumer$058q_parameter$()), ($ordinary$045scheduled$045reader$045consumer$058eemr_parameter$()));
}

function $ordinary$045scheduled$045reader$045consumer$058setup_reserved$(_reserved_0) {
  const __0 = _reserved_0["fst"];
  const _t_0 = _reserved_0["snd"];
  if (_t_0.$ === "../../../../../../../../src/ecs/world.ReservationRejected") {
    return {$: "ordinary-scheduled-reader-consumer.SetupFailed"};
  } else {
    const _entity_0 = _t_0["handle"];
    return $ordinary$045scheduled$045reader$045consumer$058setup_activated$(_entity_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(__0, _entity_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../../../../../src/ecs/world.Created", "factory": {$: "../../../../../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($ordinary$045scheduled$045reader$045consumer$058empty_store$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $after_barrier$(_context_0, _provider_0, _report_0) {
  return $first_barrier_record$(_report_0, ($phase_record$(_context_0, _provider_0, "after-real-barrier-before-first-callback", "published", "null", "null")));
}

function $ordinary$045scheduled$045reader$045consumer$058barrier_context$(_context_0) {
  return $ordinary$045scheduled$045reader$045consumer$058barrier_context_parts$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(_context_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058schedule_relation_first$(_entity_0, _first_0) {
  const _context_0 = _first_0["fst"];
  const _t_0 = _first_0["snd"];
  const _status_0 = _t_0["fst"];
  const _outcome_0 = _t_0["snd"];
  return $ordinary$045scheduled$045reader$045consumer$058mutate_prior_and_rollback$(_context_0, _entity_0, _status_0, _outcome_0);
}

function $ordinary$045scheduled$045reader$045consumer$058submit_relation$(_context_0, _entity_0, _outcome_0) {
  return $ordinary$045scheduled$045reader$045consumer$058submit_relation_parts$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(_context_0)), _entity_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058define_access$1260$(_declaration_0, _context_0, _name_0, _accessed_0) {
  const _descriptor_0 = _accessed_0["fst"];
  const _access_0 = _accessed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058define_world$1260$(_descriptor_0, _declaration_0, _name_0, _access_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(_context_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058access$1260$(_param_0) {
  const _access_0 = _param_0["access"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": _access_0}, "snd": _access_0};
}

function $ordinary$045scheduled$045reader$045consumer$058pair_all$(_left_0, _right_0) {
  const _a_0 = _left_0["access"];
  const _b_0 = _right_0["access"];
  return {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": ($List$append$(_a_0, _b_0))};
}

function $ordinary$045scheduled$045reader$045consumer$058q_parameter$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058from_observable$1260$();
}

function $ordinary$045scheduled$045reader$045consumer$058eemr_parameter$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1262$(($ordinary$045scheduled$045reader$045consumer$058e_parameter$()), ($ordinary$045scheduled$045reader$045consumer$058emr_parameter$()));
}

function $ordinary$045scheduled$045reader$045consumer$058setup_activated$(_entity_0, _activated_0) {
  const __0 = _activated_0["fst"];
  const _t_0 = _activated_0["snd"];
  if (_t_0.$ === "../../../../../../../../src/ecs/world.Rejected") {
    return {$: "ordinary-scheduled-reader-consumer.SetupFailed"};
  } else {
    return $ordinary$045scheduled$045reader$045consumer$058setup_stored$(_entity_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $ordinary$045scheduled$045reader$045consumer$058seed_column$(_x_0, ($ordinary$045scheduled$045reader$045consumer$058entity_id$(_entity_0)));
}), __0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $ordinary$045scheduled$045reader$045consumer$058empty_store$(__0) {
  return {$: "../../../../../../../../src/ecs/relation-commands.Store", "components": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1260$()), "graph": {$: "../../../../../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $first_barrier_record$(_report_0, _observed_0) {
  const _context_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _provider_0 = _t_0["fst"];
  const _row_0 = _t_0["snd"];
  return $first_failed_run$(_report_0, _row_0, ($ordinary$045scheduled$045reader$045consumer$058run_all$(_provider_0, _context_0, true)));
}

function $phase_record$(_context_0, _provider_0, _phase_0, _status_0, _error_0, _view_0) {
  return $phase_record_join$(($snapshot_context$(_context_0)), ($ordinary$045scheduled$045reader$045consumer$058provider_cursor$(_provider_0)), _phase_0, _status_0, _error_0, _view_0);
}

function $ordinary$045scheduled$045reader$045consumer$058barrier_context_parts$(_parts_0) {
  const _world_0 = _parts_0["fst"];
  const _metadata_0 = _parts_0["snd"];
  return $ordinary$045scheduled$045reader$045consumer$058barrier_context_join$(_metadata_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _state_0 = _runtime_0["family"];
  const _tick_0 = _runtime_0["tick"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _state_0, "snd": _tick_0}};
}

function $ordinary$045scheduled$045reader$045consumer$058mutate_prior_and_rollback$(_context_0, _entity_0, _committedStatus_0, _committedOutcome_0) {
  return $ordinary$045scheduled$045reader$045consumer$058mutation_report_done$(_committedStatus_0, _committedOutcome_0, ($ordinary$045scheduled$045reader$045consumer$058submit_relation$(_context_0, _entity_0, {$: "../../../../../../../../src/ecs/transaction.Failure", "error": 77})));
}

function $ordinary$045scheduled$045reader$045consumer$058submit_relation_parts$(_parts_0, _entity_0, _outcome_0) {
  const _world_0 = _parts_0["fst"];
  const _metadata_0 = _parts_0["snd"];
  return $ordinary$045scheduled$045reader$045consumer$058submitted_context$(_metadata_0, ($ordinary$045scheduled$045reader$045consumer$058relation_attempt$(_world_0, _entity_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058define_world$1260$(_descriptor_0, _declaration_0, _name_0, _access_0, _parts_0) {
  const _world_0 = _parts_0["fst"];
  const _meta_0 = _parts_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058registered_parts$1260$(_descriptor_0, _declaration_0, _meta_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058from_observable$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058make$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058access_of$1260$(($ordinary$045scheduled$045reader$045consumer$058query_declaration$()))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1262$(_left_0, _right_0) {
  return {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access$1262$(_left_0, _right_0))};
}

function $ordinary$045scheduled$045reader$045consumer$058e_parameter$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_param$1260$();
}

function $ordinary$045scheduled$045reader$045consumer$058emr_parameter$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1261$(($ordinary$045scheduled$045reader$045consumer$058e_parameter$()), ($ordinary$045scheduled$045reader$045consumer$058mr_parameter$()));
}

function $ordinary$045scheduled$045reader$045consumer$058setup_stored$(_entity_0, _stored_0) {
  const _world_0 = _stored_0["fst"];
  const _t_0 = _stored_0["snd"];
  if (!_t_0) {
    return {$: "ordinary-scheduled-reader-consumer.SetupFailed"};
  } else {
    return {$: "ordinary-scheduled-reader-consumer.Ready", "context": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058start$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-commands.Original", "event": {$: "ordinary-scheduled-reader-consumer.Value", "value": 11}}, "tail": {$: "Con", "head": ($ordinary$045scheduled$045reader$045consumer$058inject_removal$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058component$1260$("value")), _entity_0)), "tail": {$: "Nil"}}})), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058provision$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045event$045declaration$058domain$1260$("values")), 65536)), {$: "Unit"})), "entity": _entity_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $ordinary$045scheduled$045reader$045consumer$058seed_column$(_store_0, _id_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $ordinary$045scheduled$045reader$045consumer$058seeded_column$(_graph_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_components_0, _id_0, {$: "Some", "value": 42})));
}

function $ordinary$045scheduled$045reader$045consumer$058entity_id$(_entity_0) {
  const _id_0 = _entity_0["id"];
  return _id_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../src/ecs/world.Reserved", "handle": {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1260$() {
  return {$: "../../../../../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $first_failed_run$(_report_0, _rows_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.RunFailed") {
    const _context_0 = _result_0["context"];
    const _provider_0 = _result_0["provider"];
    const _error_0 = _result_0["error"];
    const _output_0 = _result_0["output"];
    return $first_failed_record$(_report_0, _rows_0, ($phase_record$(_context_0, _provider_0, "A-first-after-barrier", "failed", ($U32$show$(_error_0)), ($ordinary$045scheduled$045reader$045consumer$058view_json$(_output_0)))));
  } else if (_result_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.RunCompleted") {
    const _output_1 = _result_0["output"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058view_json$(_output_1));
    const _x_1 = (_x_0 + "}");
    return $final_output$(_report_0, ($append_row$(_rows_0, ("{\"phase\":\"A-first-after-barrier\",\"status\":\"unexpectedlyCompleted\",\"view\":" + _x_1))));
  } else if (_result_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.RunInvalidReader") {
    return $final_output$(_report_0, ($append_row$(_rows_0, "{\"phase\":\"A-first-after-barrier\",\"status\":\"invalidReader\"}")));
  } else if (_result_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.RunRegistrationRejected") {
    return $final_output$(_report_0, ($append_row$(_rows_0, "{\"phase\":\"A-first-after-barrier\",\"status\":\"registrationRejected\"}")));
  } else {
    return $final_output$(_report_0, ($append_row$(_rows_0, "{\"phase\":\"A-first-after-barrier\",\"status\":\"skipped\"}")));
  }
}

function $ordinary$045scheduled$045reader$045consumer$058run_all$(_provider_0, _context_0, _fail_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_mixed$1260$(_provider_0, _context_0, _fail_0);
}

function $phase_record_join$(_snapshot_0, _cursor_0, _phase_0, _status_0, _error_0, _view_0) {
  const _context_0 = _snapshot_0["fst"];
  const _state_0 = _snapshot_0["snd"];
  return $phase_record_cursor$(_context_0, _state_0, _cursor_0, _phase_0, _status_0, _error_0, _view_0);
}

function $snapshot_context$(_context_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _routeTick_0 = _context_0["tick"];
  return $snapshot_parts$(($ordinary$045scheduled$045reader$045consumer$058world_snapshot$(_world_0)), ($state_image$(_state_0, _routeTick_0)), _routeTick_0);
}

function $ordinary$045scheduled$045reader$045consumer$058provider_cursor$(_provider_0) {
  const _t_0 = _provider_0["registry"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _reader_0 = _provider_0["reader"];
  const _parameter_0 = _provider_0["parameter"];
  const _declaration_0 = _provider_0["declaration"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Provider", "registry": {$: "../../../../../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0}, "snd": _cursor_0};
}

function $ordinary$045scheduled$045reader$045consumer$058barrier_context_join$(_metadata_0, _world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _metadata_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $ordinary$045scheduled$045reader$045consumer$058mutation_report_done$(_committedStatus_0, _committedOutcome_0, _rolledBack_0) {
  const _context_0 = _rolledBack_0["fst"];
  const _t_0 = _rolledBack_0["snd"];
  const _status_0 = _t_0["fst"];
  const _outcome_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _context_0, "snd": {$: "ordinary-scheduled-reader-consumer.MutationReport", "committedStatus": _committedStatus_0, "committedOutcome": _committedOutcome_0, "rolledBackStatus": _status_0, "rolledBackOutcome": _outcome_0}};
}

function $ordinary$045scheduled$045reader$045consumer$058submitted_context$(_metadata_0, _attempt_0) {
  const _world_0 = _attempt_0["fst"];
  const _result_0 = _attempt_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _metadata_0)), "snd": _result_0};
}

function $ordinary$045scheduled$045reader$045consumer$058relation_attempt$(_world_0, _entity_0, _outcome_0) {
  return $ordinary$045scheduled$045reader$045consumer$058relation_finish$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1260$(($ordinary$045scheduled$045reader$045consumer$058self_targets$(_entity_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))), _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058registered_parts$1260$(_descriptor_0, _declaration_0, _meta_0, _result_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058registration_result$1260$(_descriptor_0, _declaration_0, _meta_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058make$1260$(_access_0) {
  return {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": _access_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058access_of$1260$(_declaration_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058access_clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045declaration$058clauses$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058operational$1260$(_declaration_0)))));
}

function $ordinary$045scheduled$045reader$045consumer$058query_declaration$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058with_component$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access$1262$(_left_0, _right_0) {
  const _access_0 = _left_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access_second$1262$(_access_0, _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_param$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058make$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_access$1260$(($ordinary$045scheduled$045reader$045consumer$058event_declaration$()))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1261$(_left_0, _right_0) {
  return {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access$1261$(_left_0, _right_0))};
}

function $ordinary$045scheduled$045reader$045consumer$058mr_parameter$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1260$(($ordinary$045scheduled$045reader$045consumer$058m_parameter$()), ($ordinary$045scheduled$045reader$045consumer$058r_parameter$()));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058start$1260$(_world_0, _family_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058started$1260$({$: "../../../../../../../../src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_0, "journal": {$: "Nil"}, "frameStart": 0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058start$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $ordinary$045scheduled$045reader$045consumer$058inject_removal$(_identity_0, _handle_0) {
  return {$: "../../../../../../../../src/ecs/relation-commands.Original", "event": {$: "ordinary-scheduled-reader-consumer.Removed", "record": {$: "../../../../../../../../src/ecs/removals.Removed", "entity": _handle_0, "family": _identity_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058component$1260$(_key_0) {
  return {$: "../../../../../../../../src/ecs/ordinary-declaration.Declaration", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058provision$1260$(_domain_0, _capacity_0) {
  return {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045event$045declaration$058domain$1260$(_key_0) {
  return {$: "../../../../../../../../src/ecs/ordinary-event-declaration.Domain", "key": _key_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $ordinary$045scheduled$045reader$045consumer$058seeded_column$(_graph_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/relation-commands.Store", "components": _column_0, "graph": _graph_0}, "snd": true};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/relation-commands.Store", "components": _column_1, "graph": _graph_0}, "snd": false};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../src/ecs/world.Rejected", "error": {$: "../../../../../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../src/ecs/world.Accepted"}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $first_failed_record$(_report_0, _rows_0, _observed_0) {
  const _context_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _provider_0 = _t_0["fst"];
  const _row_0 = _t_0["snd"];
  return $apply_first_frame$(_report_0, ($append_row$(_rows_0, _row_0)), _context_0, _provider_0);
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $ordinary$045scheduled$045reader$045consumer$058view_json$(_value_0) {
  const _query_0 = _value_0["left"];
  const _t_0 = _value_0["right"];
  const _eventA_0 = _t_0["left"];
  const _t_1 = _t_0["right"];
  const _eventB_0 = _t_1["left"];
  const _t_2 = _t_1["right"];
  const _removals_0 = _t_2["left"];
  const _relations_0 = _t_2["right"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058relations_json$(_relations_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058removals_json$(_removals_0));
  const _x_3 = (",\"relations\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($ordinary$045scheduled$045reader$045consumer$058event_json$(_eventB_0));
  const _x_6 = (",\"removals\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($ordinary$045scheduled$045reader$045consumer$058event_json$(_eventA_0));
  const _x_9 = (",\"eventB\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($ordinary$045scheduled$045reader$045consumer$058query_json$(_query_0));
  const _x_12 = (",\"eventA\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  return ("{\"query\":" + _x_13);
}

function $final_output$(_report_0, _rows_0) {
  const _x_0 = (_rows_0 + "]}");
  const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058mutation_json$(_report_0));
  const _x_2 = (",\"observations\":[" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("{\"mutation\":" + _x_3);
}

function $append_row$(_rows_0, _row_0) {
  if (_rows_0 === "") {
    return _row_0;
  } else {
    const _x_0 = ("," + _row_0);
    return (_rows_0 + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_mixed$1260$(_provider_0, _context_0, _args_0) {
  const _registry_0 = _provider_0["registry"];
  const _reader_0 = _provider_0["reader"];
  const _parameter_0 = _provider_0["parameter"];
  const _declaration_0 = _provider_0["declaration"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_raw_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_registered_mixed$1260$(_registry_0, _context_0, _reader_0, _parameter_0, _declaration_0, _args_0)));
}

function $phase_record_cursor$(_context_0, _state_0, _cursor_0, _phase_0, _status_0, _error_0, _view_0) {
  const _provider_0 = _cursor_0["fst"];
  const _queryCursor_0 = _cursor_0["snd"];
  const _x_0 = (_state_0 + "}");
  const _x_1 = (",\"state\":" + _x_0);
  const _x_2 = (_view_0 + _x_1);
  const _x_3 = ($U32$show$(_queryCursor_0));
  const _x_4 = (",\"view\":" + _x_2);
  const _x_5 = (_x_3 + _x_4);
  const _x_6 = (",\"queryCursor\":" + _x_5);
  const _x_7 = (_error_0 + _x_6);
  const _x_8 = ($quoted$(_status_0));
  const _x_9 = (",\"error\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($quoted$(_phase_0));
  const _x_12 = (",\"status\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  return {$: "Tuple", "fst": _context_0, "snd": {$: "Tuple", "fst": _provider_0, "snd": ("{\"phase\":" + _x_13)}};
}

function $snapshot_parts$(_world_0, _state_0, _routeTick_0) {
  const _world_1 = _world_0["fst"];
  const _worldImage_0 = _world_0["snd"];
  return $snapshot_state$(_world_1, _worldImage_0, _state_0, _routeTick_0);
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot$(_world_0) {
  return $ordinary$045scheduled$045reader$045consumer$058world_snapshot_namespace$(($ordinary$045scheduled$045reader$045consumer$058world_snapshot_clock$(($ordinary$045scheduled$045reader$045consumer$058world_snapshot_pending$(($ordinary$045scheduled$045reader$045consumer$058world_snapshot_events$(($ordinary$045scheduled$045reader$045consumer$058world_graph_read$(_world_0)))))))));
}

function $state_image$(_state_0, _routeTick_0) {
  const _typed_0 = _state_0["typed"];
  const _failures_0 = _state_0["failures"];
  return $failure_image$(_typed_0, _failures_0, _routeTick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _metadata_0) {
  const _state_0 = _metadata_0["fst"];
  const _tick_0 = _metadata_0["snd"];
  return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $ordinary$045scheduled$045reader$045consumer$058relation_finish$(_queued_0, _outcome_0) {
  const _tx_0 = _queued_0["fst"];
  const _status_0 = _queued_0["snd"];
  return $ordinary$045scheduled$045reader$045consumer$058relation_finished$(_status_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058invoke_write$1260$(_args_0, _tx_0) {
  return $ordinary$045scheduled$045reader$045consumer$058relation_body$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058provide_write$1260$()), _args_0, _tx_0);
}

function $ordinary$045scheduled$045reader$045consumer$058self_targets$(_entity_0) {
  const _namespace_0 = _entity_0["namespace"];
  const _id_0 = _entity_0["id"];
  return {$: "../../../../../../../../src/ecs/relation-providers.Targets", "source": {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "target": {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058registration_result$1260$(_descriptor_0, _declaration_0, _meta_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.DefinitionRejected", "context": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), "parameter": _descriptor_0, "declaration": _declaration_0};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058initialized_provider$1260$(_descriptor_0, _declaration_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_1, _meta_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058registration_facts$1260$(_registry_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058access_clauses$1260$(_clauses_0) {
  if (_clauses_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _clauses_0["head"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _clauses_0["tail"];
    return {$: "Con", "head": _name_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058access_clauses$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045declaration$058clauses$1260$(_declaration_0) {
  const _clauses_0 = _declaration_0["clauses"];
  return _clauses_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058operational$1260$(_declaration_0) {
  const _operational_0 = _declaration_0["operational"];
  return _operational_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058with_component$1260$() {
  return {$: "../../../../../../../../src/ecs/ordinary-query-observable.Declaration", "operational": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045declaration$058with_component$1260$()), "inspection": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058constrain$1260$())};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access_second$1262$(_first_0, _second_0) {
  const _access_0 = _second_0["access"];
  return $List$append$(_first_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058make$1261$(_access_0) {
  return {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": _access_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_access$1260$(_declaration_0) {
  return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045event$045declaration$058access$1260$(_declaration_0)), "tail": {$: "Nil"}};
}

function $ordinary$045scheduled$045reader$045consumer$058event_declaration$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045event$045declaration$058read$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045event$045declaration$058domain$1260$("values")));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access$1261$(_left_0, _right_0) {
  const _access_0 = _left_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access_second$1261$(_access_0, _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1260$(_left_0, _right_0) {
  return {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access$1260$(_left_0, _right_0))};
}

function $ordinary$045scheduled$045reader$045consumer$058m_parameter$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_param$1260$();
}

function $ordinary$045scheduled$045reader$045consumer$058r_parameter$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_param$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058started$1260$(_typed_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058start$1260$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $apply_first_frame$(_report_0, _rows_0, _context_0, _provider_0) {
  return $first_frame_observed$(_report_0, _rows_0, ($frame_record$(($frame_both$(_context_0)), _provider_0, "frame-1")));
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $ordinary$045scheduled$045reader$045consumer$058query_json$(_value_0) {
  const _rows_0 = _value_0["rows"];
  return $ordinary$045scheduled$045reader$045consumer$058list_json$1266$(_rows_0);
}

function $ordinary$045scheduled$045reader$045consumer$058event_json$(_value_0) {
  const _t_0 = _value_0["reading"];
  const _values_0 = _t_0["values"];
  const _lagged_0 = _t_0["lagged"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058boolean$(_lagged_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1265$(_values_0));
  const _x_3 = (",\"lagged\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("{\"values\":" + _x_4);
}

function $ordinary$045scheduled$045reader$045consumer$058removals_json$(_value_0) {
  const _records_0 = _value_0["records"];
  return $ordinary$045scheduled$045reader$045consumer$058list_json$1267$(_records_0);
}

function $ordinary$045scheduled$045reader$045consumer$058relations_json$(_value_0) {
  const _readings_0 = _value_0["readings"];
  return $ordinary$045scheduled$045reader$045consumer$058list_json$1268$(_readings_0);
}

function $ordinary$045scheduled$045reader$045consumer$058mutation_json$(_value_0) {
  const _committedStatus_0 = _value_0["committedStatus"];
  const _committedOutcome_0 = _value_0["committedOutcome"];
  const _rolledBackStatus_0 = _value_0["rolledBackStatus"];
  const _rolledBackOutcome_0 = _value_0["rolledBackOutcome"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058outcome_json$(_rolledBackOutcome_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058queue_status_json$(_rolledBackStatus_0));
  const _x_3 = (",\"rolledBackOutcome\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($ordinary$045scheduled$045reader$045consumer$058outcome_json$(_committedOutcome_0));
  const _x_6 = (",\"rolledBackQueue\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($ordinary$045scheduled$045reader$045consumer$058queue_status_json$(_committedStatus_0));
  const _x_9 = (",\"committedOutcome\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return ("{\"committedQueue\":" + _x_10);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_raw_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_rejected_result$1260$(_registry_0, _world_0, _args_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_outcome_result$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_registered_mixed$1260$(_registry_0, _context_0, _reader_0, _parameter_0, _declaration_0, _args_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_registered$1260$(_registry_0, _world_0, {$: "Tuple", "fst": _state_0, "snd": _tick_0}, _reader_0, _parameter_0, _declaration_0, _args_0);
}

function $quoted$(_value_0) {
  const _x_0 = (_value_0 + "\"");
  return ("\"" + _x_0);
}

function $snapshot_state$(_world_0, _worldImage_0, _state_0, _routeTick_0) {
  const _state_1 = _state_0["fst"];
  const _image_0 = _state_0["snd"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058world_observation_json$(_worldImage_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($failure_image_json$(_image_0));
  const _x_3 = (",\"world\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_1, "tick": _routeTick_0}, "snd": ("{\"shared\":" + _x_4)};
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot_namespace$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _graph_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _events_0 = _t_1["fst"];
  const _t_2 = _t_1["snd"];
  const _pending_0 = _t_2["fst"];
  const _clock_0 = _t_2["snd"];
  return $ordinary$045scheduled$045reader$045consumer$058world_snapshot_namespace_join$(_graph_0, _events_0, _pending_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot_clock$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _graph_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _events_0 = _t_1["fst"];
  const _pending_0 = _t_1["snd"];
  return $ordinary$045scheduled$045reader$045consumer$058world_snapshot_clock_join$(_graph_0, _events_0, _pending_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot_pending$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _graph_0 = _t_0["fst"];
  const _events_0 = _t_0["snd"];
  return $ordinary$045scheduled$045reader$045consumer$058world_snapshot_pending_join$(_graph_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot_events$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _graph_0 = _result_0["snd"];
  return $ordinary$045scheduled$045reader$045consumer$058world_snapshot_events_join$(_graph_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058world_graph_read$(_world_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1264$(run_clo((_x_0) => {
  return $ordinary$045scheduled$045reader$045consumer$058world_graph_store$(_x_0);
}), _world_0);
}

function $failure_image$(_typed_0, _failures_0, _routeTick_0) {
  const _domains_0 = _failures_0["domains"];
  const _positions_0 = _failures_0["positions"];
  const _tick_0 = _failures_0["tick"];
  const _frameStart_0 = _failures_0["frameStart"];
  const _boundary_0 = _failures_0["boundary"];
  const _capacity_0 = _failures_0["capacity"];
  const _nextReader_0 = _failures_0["nextReader"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "snd": {$: "FailureImage", "routeTick": _routeTick_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0, "domains": _domains_0, "positions": _positions_0}};
}

function $ordinary$045scheduled$045reader$045consumer$058relation_finished$(_status_0, _returned_0) {
  const _world_0 = _returned_0["world"];
  const _outcome_0 = _returned_0["outcome"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _status_0, "snd": _outcome_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $ordinary$045scheduled$045reader$045consumer$058relation_body$(_caps_0, _targets_0, _owner_0) {
  const _t_0 = _caps_0["relate"];
  const _relate_0 = _t_0["run"];
  return run_tail(_relate_0(_owner_0), _targets_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058provide_write$1260$() {
  return {$: "../../../../../../../../src/ecs/relation-providers.Writable", "inverse": {$: "../../../../../../../../src/ecs/capabilities.Request", "run": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx$1260$(_x_0, _x_1);
});
})}, "relate": {$: "../../../../../../../../src/ecs/capabilities.Request", "run": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_tx$1260$(_x_2, _x_3);
});
})}, "unrelate": {$: "../../../../../../../../src/ecs/capabilities.Request", "run": run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058clear_tx$1260$(_x_4, _x_5);
});
})}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058initialized_provider$1260$(_descriptor_0, _declaration_0, _context_0, _registered_0) {
  const _registry_0 = _registered_0["fst"];
  const _facts_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058initialized_values$1260$(_descriptor_0, _declaration_0, _registry_0, ($ordinary$045scheduled$045reader$045consumer$058all_initialize$(_context_0, _facts_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058registration_facts$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": {$: "../../../../../../../../src/ecs/reader-parameter.RegistrationFacts", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045declaration$058with_component$1260$() {
  return {$: "../../../../../../../../src/ecs/ordinary-query-declaration.Declaration", "grant": {$: "Unit"}, "select": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058family_match$1260$(_x_0);
}), "clauses": {$: "Con", "head": {$: "../../../../../../../../src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045component$045binding$058identity$1260$(($ordinary$045scheduled$045reader$045consumer$058binding$()))))), "mode": {$: "../../../../../../../../src/ecs/ordinary-query-declaration.With"}}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058constrain$1260$() {
  return {$: "../../../../../../../../src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058constrained$1260$(_x_0, _x_1);
});
}), "project": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045event$045declaration$058access$1260$(_declaration_0) {
  const _t_0 = _declaration_0["domain"];
  const _key_0 = _t_0["key"];
  const _t_1 = _declaration_0["mode"];
  if (_t_1.$ === "../../../../../../../../src/ecs/ordinary-event-declaration.Read") {
    return $String$concat$({$: "Con", "head": _key_0, "tail": {$: "Con", "head": ":read", "tail": {$: "Nil"}}});
  } else {
    return $String$concat$({$: "Con", "head": _key_0, "tail": {$: "Con", "head": ":write", "tail": {$: "Nil"}}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045event$045declaration$058read$1260$(_domain_0) {
  return {$: "../../../../../../../../src/ecs/ordinary-event-declaration.Declaration", "domain": _domain_0, "mode": {$: "../../../../../../../../src/ecs/ordinary-event-declaration.Read"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access_second$1261$(_first_0, _second_0) {
  const _access_0 = _second_0["access"];
  return $List$append$(_first_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access$1260$(_left_0, _right_0) {
  const _access_0 = _left_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access_second$1260$(_access_0, _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_param$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058make$1262$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_access$1260$(($ordinary$045scheduled$045reader$045consumer$058removal_selection$()))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_param$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058make$1263$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_access$1260$(($ordinary$045scheduled$045reader$045consumer$058relation_declarations$()))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1260$(_clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../../../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": _clock_0, "frameStart": 0, "boundary": 0, "capacity": 65536, "nextReader": 1};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $first_frame_observed$(_report_0, _rows_0, _observed_0) {
  const _context_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _provider_0 = _t_0["fst"];
  const _row_0 = _t_0["snd"];
  return $apply_second_frame$(_report_0, ($append_row$(_rows_0, _row_0)), _context_0, _provider_0);
}

function $frame_record$(_context_0, _provider_0, _phase_0) {
  return $phase_record$(_context_0, _provider_0, _phase_0, "frame", "null", "null");
}

function $frame_both$(_context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058frame_failures$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058frame$1260$(_context_0)));
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1266$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1266$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058row_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1265$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1265$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058notice_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058boolean$(_value_0) {
  if (_value_0) {
    return "true";
  } else {
    return "false";
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1267$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1267$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058removal_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1268$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1268$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058key_reading_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058queue_status_json$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/relation-commands.Queued") {
    return "\"queued\"";
  } else {
    return "\"missingEntity\"";
  }
}

function $ordinary$045scheduled$045reader$045consumer$058outcome_json$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/transaction.Success") {
    return "\"success\"";
  } else {
    const _error_0 = _value_0["error"];
    const _x_0 = ($U32$show$(_error_0));
    const _x_1 = (_x_0 + "}");
    return ("{\"failure\":" + _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_rejected_result$1260$(_registry_0, _world_0, _invocation_0) {
  const _meta_0 = _invocation_0["meta"];
  const _reader_0 = _invocation_0["reader"];
  const _parameter_0 = _invocation_0["parameter"];
  const _declaration_0 = _invocation_0["declaration"];
  const _args_0 = _invocation_0["args"];
  return {$: "../../../../../../../../src/ecs/ordinary-reader-system.RunRegistrationRejected", "context": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), "provider": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Provider", "registry": _registry_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0}, "args": _args_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_outcome_result$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../src/ecs/system.Failed") {
    const _error_0 = _outcome_0["error"];
    return $Empty$absurd$(_error_0);
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_envelope_result$1260$(_registry_0, _world_1, _output_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_registered$1260$(_registry_0, _world_0, _meta_0, _reader_0, _parameter_0, _declaration_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_selected$1260$(_world_0, _meta_0, _reader_0, _parameter_0, _declaration_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor$1260$(_registry_0)));
}

function $failure_image_json$(_value_0) {
  const _routeTick_0 = _value_0["routeTick"];
  const _tick_0 = _value_0["tick"];
  const _frameStart_0 = _value_0["frameStart"];
  const _boundary_0 = _value_0["boundary"];
  const _capacity_0 = _value_0["capacity"];
  const _nextReader_0 = _value_0["nextReader"];
  const _domains_0 = _value_0["domains"];
  const _positions_0 = _value_0["positions"];
  const _x_0 = ($domains_json$(_domains_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($positions_json$(_positions_0));
  const _x_3 = (",\"domains\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_nextReader_0));
  const _x_6 = (",\"positions\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($Nat$show$(_capacity_0));
  const _x_9 = (",\"nextReader\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($Nat$show$(_boundary_0));
  const _x_12 = (",\"capacity\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  const _x_14 = ($Nat$show$(_frameStart_0));
  const _x_15 = (",\"boundary\":" + _x_13);
  const _x_16 = (_x_14 + _x_15);
  const _x_17 = ($Nat$show$(_tick_0));
  const _x_18 = (",\"frameStart\":" + _x_16);
  const _x_19 = (_x_17 + _x_18);
  const _x_20 = ($Nat$show$(_routeTick_0));
  const _x_21 = (",\"tick\":" + _x_19);
  const _x_22 = (_x_20 + _x_21);
  return ("{\"routeTick\":" + _x_22);
}

function $ordinary$045scheduled$045reader$045consumer$058world_observation_json$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _clock_0 = _value_0["clock"];
  const _pending_0 = _value_0["pending"];
  const _graph_0 = _value_0["graph"];
  const _events_0 = _value_0["events"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1265$(_events_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058graph_json$(_graph_0));
  const _x_3 = (",\"events\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_pending_0));
  const _x_6 = (",\"graph\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_clock_0));
  const _x_9 = (",\"pending\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($U32$show$(_namespace_0));
  const _x_12 = (",\"clock\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  return ("{\"namespace\":" + _x_13);
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot_namespace_join$(_graph_0, _events_0, _pending_0, _clock_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _namespace_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "ordinary-scheduled-reader-consumer.WorldObservation", "namespace": _namespace_0, "clock": _clock_0, "pending": _pending_0, "graph": _graph_0, "events": _events_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot_clock_join$(_graph_0, _events_0, _pending_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _graph_0, "snd": {$: "Tuple", "fst": _events_0, "snd": {$: "Tuple", "fst": _pending_0, "snd": _clock_0}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot_pending_join$(_graph_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _pending_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _graph_0, "snd": {$: "Tuple", "fst": _events_0, "snd": _pending_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058world_snapshot_events_join$(_graph_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _events_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _graph_0, "snd": _events_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1264$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $ordinary$045scheduled$045reader$045consumer$058world_graph_store$(_store_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058graph_read$1260$(_store_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx$1260$(_tx_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  const _ns_0 = _target_0["namespace"];
  const _id_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx_done$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_handles$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse$1260$(_world_0, ($ordinary$045scheduled$045reader$045consumer$058relation_descriptor$()), {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _ns_0, "id": _id_0})), _undo_0, _commands_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058relate_tx$1260$(_tx_0, _targets_0) {
  const _source_0 = _targets_0["source"];
  const _target_0 = _targets_0["target"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, ($ordinary$045scheduled$045reader$045consumer$058relation_descriptor$()), _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058clear_tx$1260$(_tx_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_unrelate$1260$(_tx_0, ($ordinary$045scheduled$045reader$045consumer$058relation_descriptor$()), _source_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058initialized_values$1260$(_descriptor_0, _declaration_0, _registry_0, _initialized_0) {
  const _context_0 = _initialized_0["fst"];
  const _t_0 = _initialized_0["snd"];
  const _reader_0 = _t_0["fst"];
  const _parameter_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058initialized_checked$1260$(_descriptor_0, _declaration_0, _registry_0, _parameter_0, ($ordinary$045scheduled$045reader$045consumer$058validate_all$(_context_0, _reader_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058all_initialize$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair$1263$(_context_0, _facts_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058family_match$1260$(_frame_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1260$({$: "../../../../../../../../src/ecs/compose.Present"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058get$1260$(_frame_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058key$1260$(_declaration_0) {
  const _key_0 = _declaration_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045component$045binding$058identity$1260$(_binding_0) {
  const _identity_0 = _binding_0["identity"];
  return _identity_0;
}

function $ordinary$045scheduled$045reader$045consumer$058binding$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045component$045binding$058bind$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058component$1260$("value")));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058constrained$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058constrained_target$1260$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1260$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1260$() {
  return {$: "../../../../../../../../src/ecs/inspector-query-projection.DeclaredSelection", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1260$(_x_0, _x_1);
});
}), "project": run_clo((_x_2) => {
  return run_clo((_x_3) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1260$(_x_2, _x_3);
});
})};
}

function $String$concat$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    const _x_0 = ($String$concat$(_t_0));
    return (_h_0 + _x_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_access_second$1260$(_first_0, _second_0) {
  const _access_0 = _second_0["access"];
  return $List$append$(_first_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058make$1262$(_access_0) {
  return {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": _access_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_access$1260$(_selection_0) {
  return {$: "Con", "head": "removal", "tail": {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_name$1260$(_selection_0)), "tail": {$: "Nil"}}};
}

function $ordinary$045scheduled$045reader$045consumer$058removal_selection$() {
  return {$: "../../../../../../../../src/ecs/ordinary-removal-provision.Selection", "identity": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058component$1260$("value"))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058make$1263$(_access_0) {
  return {$: "../../../../../../../../src/ecs/reader-parameter.Param", "access": _access_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_access$1260$(_declarations_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058accesses$1260$(_declarations_0);
}

function $ordinary$045scheduled$045reader$045consumer$058relation_declarations$() {
  return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1260$(($ordinary$045scheduled$045reader$045consumer$058relation_descriptor$()))), "tail": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../../../../../src/ecs/column.Rejected", "column": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../../../../../src/ecs/column.Accepted", "column": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $apply_second_frame$(_report_0, _rows_0, _context_0, _provider_0) {
  return $second_frame_observed$(_report_0, _rows_0, ($frame_record$(($frame_both$(_context_0)), _provider_0, "frame-2")));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058frame_failures$1260$(_runtime_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058failure_framed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058failure_runtime$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058frame$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _t_0 = _runtime_0["family"];
  const _t_1 = _t_0["typed"];
  const _family_0 = _t_1["family"];
  const _owners_0 = _t_1["owners"];
  const _journal_0 = _t_1["journal"];
  const _failures_0 = _t_0["failures"];
  const _tick_0 = _runtime_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058framed$1260$(_owners_0, _failures_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retention$1260$(_journal_0, ($typed_frame$(_family_0, _tick_0)))));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $ordinary$045scheduled$045reader$045consumer$058row_json$(_value_0) {
  const _entity_0 = _value_0["entity"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058handle_json$(_entity_0));
  const _x_1 = (_x_0 + ",\"value\":null}");
  return ("{\"entity\":" + _x_1);
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1266$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058row_json$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1266$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058notice_json$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/relation-commands.Original") {
    const _event_0 = _value_0["event"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058publication_json$(_event_0));
    const _x_1 = (_x_0 + "}");
    return ("{\"kind\":\"original\",\"event\":" + _x_1);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-commands.RelationFailed") {
    const _failure_0 = _value_0["failure"];
    const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058failure_json$(_failure_0));
    const _x_3 = (_x_2 + "}");
    return ("{\"kind\":\"relationFailure\",\"failure\":" + _x_3);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-commands.ComponentRemoved") {
    const _id_0 = _value_0["id"];
    const _x_4 = ($U32$show$(_id_0));
    const _x_5 = (_x_4 + "}");
    return ("{\"kind\":\"componentRemoved\",\"id\":" + _x_5);
  } else {
    const _frames_0 = _value_0["frames"];
    const _x_6 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1262$(_frames_0));
    const _x_7 = (_x_6 + "}");
    return ("{\"kind\":\"cleanupPaused\",\"frames\":" + _x_7);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1265$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058notice_json$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1265$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058removal_json$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/removals.Removed") {
    const _entity_0 = _value_0["entity"];
    const _identity_0 = _value_0["family"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058key$1260$(_identity_0))));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058handle_json$(_entity_0));
    const _x_3 = (",\"component\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    return ("{\"entity\":" + _x_4);
  } else {
    const _entity_1 = _value_0["entity"];
    const _x_5 = ($ordinary$045scheduled$045reader$045consumer$058handle_json$(_entity_1));
    const _x_6 = (_x_5 + "}");
    return ("{\"kind\":\"despawned\",\"entity\":" + _x_6);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1267$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058removal_json$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1267$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058key_reading_json$(_value_0) {
  const _t_0 = _value_0["key"];
  const _key_0 = _t_0["id"];
  const _values_0 = _value_0["values"];
  const _lagged_0 = _value_0["lagged"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058boolean$(_lagged_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1265$(_values_0));
  const _x_3 = (",\"lagged\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (",\"values\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"key\":" + _x_7);
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1268$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058key_reading_json$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1268$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $Empty$absurd$(_e_0) {
  throw "bend: runtime fail-stop";
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_envelope_result$1260$(_registry_0, _world_0, _envelope_0) {
  const _meta_0 = _envelope_0["meta"];
  const _reader_0 = _envelope_0["reader"];
  const _parameter_0 = _envelope_0["parameter"];
  const _declaration_0 = _envelope_0["declaration"];
  const _t_0 = _envelope_0["completion"];
  if (_t_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.CallbackCompleted") {
    const _output_0 = _t_0["output"];
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.RunCompleted", "context": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), "provider": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Provider", "registry": _registry_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0}, "output": _output_0};
  } else if (_t_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.CallbackFailed") {
    const _error_0 = _t_0["error"];
    const _output_1 = _t_0["output"];
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.RunFailed", "context": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), "provider": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Provider", "registry": _registry_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0}, "error": _error_0, "output": _output_1};
  } else {
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.RunInvalidReader", "context": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), "provider": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Provider", "registry": _registry_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_selected$1260$(_world_0, _meta_0, _reader_0, _parameter_0, _declaration_0, _args_0, _selected_0) {
  const _registry_0 = _selected_0["fst"];
  const _queryCursor_0 = _selected_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058cursor_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, {$: "../../../../../../../../src/ecs/ordinary-reader-system.Invocation", "meta": _meta_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0, "args": _args_0, "queryCursor": _queryCursor_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _cursor_0};
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $positions_json$(_values_0) {
  return $list_json$1260$(_values_0);
}

function $domains_json$(_values_0) {
  return $list_json$1264$(_values_0);
}

function $ordinary$045scheduled$045reader$045consumer$058graph_json$(_value_0) {
  const _edges_0 = _value_0["edges"];
  const _inverses_0 = _value_0["inverses"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1264$(_inverses_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1263$(_edges_0));
  const _x_3 = (",\"inverses\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("{\"edges\":" + _x_4);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058graph_read$1260$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_tx_done$1260$(_result_0, _undo_0, _commands_0, _events_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058inverse_handles$1260$(_result_0, _target_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _ns_0 = _target_0["namespace"];
  return {$: "Tuple", "fst": _world_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_snapshot$1260$(_value_0, _ns_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse$1260$(_world_0, _descriptor_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _target_0)), _descriptor_0, _target_0);
}

function $ordinary$045scheduled$045reader$045consumer$058relation_descriptor$() {
  return {$: "../../../../../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../../../../../src/ecs/relation-types.Hierarchy"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_unrelate$1260$(_tx_0, _descriptor_0, _source_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_namespaced$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058initialized_checked$1260$(_descriptor_0, _declaration_0, _registry_0, _parameter_0, _checked_0) {
  const _context_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  const _reader_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  if (_t_1) {
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.DefinitionRegistered", "context": _context_0, "provider": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Provider", "registry": _registry_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058definition_cleanup_result$1260$(_descriptor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058dispose_provider$1260$({$: "../../../../../../../../src/ecs/ordinary-reader-system.Provider", "registry": _registry_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0}, _context_0)));
  }
}

function $ordinary$045scheduled$045reader$045consumer$058validate_all$(_context_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_fn$1260$(_context_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair$1263$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_after_first$1263$(_facts_0, ($ordinary$045scheduled$045reader$045consumer$058q_initialize$(_context_0, _facts_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058selected_join$1260$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058get$1260$(_frame_0) {
  const _tx_0 = _frame_0["tx"];
  const _handle_0 = _frame_0["handle"];
  const _error_0 = _frame_0["error"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_get$1260$({$: "../../../../../../../../src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045component$045binding$058identity$1260$(($ordinary$045scheduled$045reader$045consumer$058binding$())))))}, _tx_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045component$045binding$058bind$1260$(_identity_0) {
  return {$: "../../../../../../../../src/ecs/ordinary-component-binding.Binding", "identity": _identity_0, "family": {$: "../../../../../../../../src/ecs/component.Family", "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058key$1260$(_identity_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058constrained_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058predicate_right$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058yes$1260$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058empty_value$1260$(_owner_0, _target_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_name$1260$(_selection_0) {
  const _identity_0 = _selection_0["identity"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058key$1260$(_identity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058accesses$1260$(_declarations_0) {
  if (_declarations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _declaration_0 = _declarations_0["head"];
    const _rest_0 = _declarations_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058access$1260$(_declaration_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058accesses$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058relation$1260$(_descriptor_0) {
  return {$: "../../../../../../../../src/ecs/relation-failure-reader.Declaration", "descriptor": _descriptor_0};
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../../../../../src/ecs/column.Indexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $second_frame_observed$(_report_0, _rows_0, _observed_0) {
  const _context_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _provider_0 = _t_0["fst"];
  const _row_0 = _t_0["snd"];
  return $second_frame$(_report_0, ($append_row$(_rows_0, _row_0)), _context_0, _provider_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058failure_framed$1260$(_detached_0) {
  const _runtime_0 = _detached_0["fst"];
  const _held_0 = _detached_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058failure_returned$1260$(_held_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058frame$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058failure_runtime$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _t_0 = _runtime_0["family"];
  const _typed_0 = _t_0["typed"];
  const _t_1 = _t_0["failures"];
  const _domains_0 = _t_1["domains"];
  const _positions_0 = _t_1["positions"];
  const _tick_0 = _t_1["tick"];
  const _frameStart_0 = _t_1["frameStart"];
  const _boundary_0 = _t_1["boundary"];
  const _capacity_0 = _t_1["capacity"];
  const _nextReader_0 = _t_1["nextReader"];
  const _typedTick_0 = _runtime_0["tick"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}, "snd": {$: "Tuple", "fst": _typed_0, "snd": _typedTick_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058framed$1260$(_owners_0, _failures_0, _tick_0, _observed_0, _returned_0) {
  const _world_0 = _observed_0["fst"];
  const _notices_0 = _observed_0["snd"];
  const _family_0 = _returned_0["family"];
  const _journal_0 = _returned_0["journal"];
  const _slots_0 = _returned_0["slots"];
  return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_notices_0, _slots_0)))), "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": {$: "../../../../../../../../src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_0, "journal": _journal_0, "frameStart": _tick_0}, "failures": _failures_0}, "tick": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retention$1260$(_journal_0, _family_0) {
  if (_journal_0.$ === "Nil") {
    return {$: "../../../../../../../../src/ecs/event-notice-runtime.Retention", "family": _family_0, "journal": {$: "Nil"}, "slots": {$: "Nil"}};
  } else {
    const _t_0 = _journal_0["head"];
    const _tick_0 = _t_0["tick"];
    const _records_0 = _t_0["values"];
    const _rest_0 = _journal_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_batch_head$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retention$1260$(_rest_0, _x_0);
}), _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_records$1260$(_records_0, _family_0, _tick_0)));
  }
}

function $typed_frame$(_family_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058frame$1260$(_family_0, _tick_0);
}

function $ordinary$045scheduled$045reader$045consumer$058handle_json$(_value_0) {
  const _namespace_0 = _value_0["namespace"];
  const _id_0 = _value_0["id"];
  const _x_0 = ($U32$show$(_id_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_namespace_0));
  const _x_3 = (",\"id\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  return ("{\"namespace\":" + _x_4);
}

function $ordinary$045scheduled$045reader$045consumer$058publication_json$(_value_0) {
  if (_value_0.$ === "ordinary-scheduled-reader-consumer.Value") {
    const _number_0 = _value_0["value"];
    const _x_0 = ($U32$show$(_number_0));
    const _x_1 = (_x_0 + "}");
    return ("{\"kind\":\"value\",\"value\":" + _x_1);
  } else {
    const _record_0 = _value_0["record"];
    const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058removal_json$(_record_0));
    const _x_3 = (_x_2 + "}");
    return ("{\"kind\":\"removed\",\"record\":" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058failure_json$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _operation_0 = _value_0["operation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _error_0 = _value_0["error"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058error_json$(_error_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_target_0));
  const _x_3 = (",\"error\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_source_0));
  const _x_6 = (",\"target\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($ordinary$045scheduled$045reader$045consumer$058operation_json$(_operation_0));
  const _x_9 = (",\"source\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  const _x_11 = ($ordinary$045scheduled$045reader$045consumer$058descriptor_json$(_relation_0));
  const _x_12 = (",\"operation\":" + _x_10);
  const _x_13 = (_x_11 + _x_12);
  return ("{\"relation\":" + _x_13);
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1262$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1262$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058frame_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058quoted$(_value_0) {
  const _x_0 = (_value_0 + "\"");
  return ("\"" + _x_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058cursor_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058cursor_completion$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $list_json$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($list_tail$1260$(_rest_0));
    const _x_1 = ($position_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $list_json$1264$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($list_tail$1264$(_rest_0));
    const _x_1 = ($domain_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1263$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1263$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058edge_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1264$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1264$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058inverse_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_snapshot$1260$(_value_0, _namespace_0) {
  if (_value_0.$ === "None") {
    return {$: "None"};
  } else {
    const _ids_0 = _value_0["value"];
    return {$: "Some", "value": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_ids_0, _namespace_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_checked$1260$(_checked_0, _descriptor_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "None"}};
  } else {
    const _id_0 = _target_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_present$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_inverse$1260$(_x_0, _descriptor_0, _id_0);
}), _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_checked$1260$((_namespace_0 === _sn_0), {$: "../../../../../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058definition_cleanup_result$1260$(_descriptor_0, _disposed_0) {
  if (_disposed_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.ProviderDisposed") {
    const _context_0 = _disposed_0["context"];
    const _declaration_0 = _disposed_0["declaration"];
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.DefinitionRejected", "context": _context_0, "parameter": _descriptor_0, "declaration": _declaration_0};
  } else {
    const _context_1 = _disposed_0["context"];
    const _provider_0 = _disposed_0["provider"];
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.DefinitionDisposalRejected", "context": _context_1, "provider": _provider_0, "parameter": _descriptor_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058dispose_provider$1260$(_provider_0, _context_0) {
  const _registry_0 = _provider_0["registry"];
  const _reader_0 = _provider_0["reader"];
  const _parameter_0 = _provider_0["parameter"];
  const _declaration_0 = _provider_0["declaration"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058provider_dispose_parts$1260$(_registry_0, _reader_0, _parameter_0, _declaration_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(_context_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_fn$1260$(_world_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_after_left$1260$(_ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058validate_context$1260$(_world_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_after_first$1263$(_facts_0, _initializedA_0) {
  const _contextAfterA_0 = _initializedA_0["fst"];
  const _t_0 = _initializedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _paramA_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_finish$1263$(_ownerA_0, _paramA_0, ($ordinary$045scheduled$045reader$045consumer$058eemr_initialize$(_contextAfterA_0, _facts_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058q_initialize$(_context_0, __0) {
  return {$: "Tuple", "fst": _context_0, "snd": {$: "Tuple", "fst": {$: "Unit"}, "snd": ($ordinary$045scheduled$045reader$045consumer$058q_parameter$())}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058selected_value$1260$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../../../../../src/ecs/compose.Required") {
    if (_value_0.$ === "../../../../../../../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../src/ecs/compose.Present") {
    if (_value_0.$ === "../../../../../../../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../src/ecs/compose.Absent") {
    if (_value_0.$ === "../../../../../../../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../../../../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../../../../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058read_join$1260$(_handle_0, _error_0, _cursor_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/compose.Frame", "tx": _tx_0, "handle": _handle_0, "error": _error_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_get$1260$(_family_0, _tx_0, _handle_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058predicate_right$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _owner_0, "snd": false};
  } else {
    return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058predicate_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045selections$058inspect_with$1260$())))(_owner_0), _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1260$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058access$1260$(_declaration_0) {
  const _t_0 = _declaration_0["descriptor"];
  const _name_0 = _t_0["name"];
  return $String$concat$({$: "Con", "head": _name_0, "tail": {$: "Con", "head": ":read", "tail": {$: "Nil"}}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $second_frame$(_report_0, _rows_0, _context_0, _provider_0) {
  return $retry_result$(_report_0, _rows_0, ($ordinary$045scheduled$045reader$045consumer$058run_all$(_provider_0, _context_0, false)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058failure_returned$1260$(_held_0, _runtime_0) {
  const _typed_0 = _held_0["fst"];
  const _typedTick_0 = _held_0["snd"];
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": _typedTick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058frame$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  return {$: "../../../../../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058trim$1260$(_domains_0, _positions_0, _frameStart_0, _capacity_0)), "positions": _positions_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0, "nextReader": _nextReader_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$($0, $1) {
  for (;;) {
    {
      const _notices_0 = $0;
      const _slots_0 = $1;
      if (_notices_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _notices_0["head"];
        if (_t_0.$ === "../../../../../../../../src/ecs/relation-commands.Original") {
          const _rest_0 = _notices_0["tail"];
          if (_slots_0.$ === "Nil") {
            $0 = _rest_0;
            $1 = {$: "Nil"};
            continue;
          } else {
            const _head_0 = _slots_0["head"];
            const _tail_0 = _slots_0["tail"];
            return $List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058original_notices$1260$(_head_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_rest_0, _tail_0)));
          }
        } else if (_t_0.$ === "../../../../../../../../src/ecs/relation-commands.RelationFailed") {
          const _failure_0 = _t_0["failure"];
          const _rest_1 = _notices_0["tail"];
          return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-commands.RelationFailed", "failure": _failure_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_rest_1, _slots_0))};
        } else if (_t_0.$ === "../../../../../../../../src/ecs/relation-commands.ComponentRemoved") {
          const _id_0 = _t_0["id"];
          const _rest_2 = _notices_0["tail"];
          return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-commands.ComponentRemoved", "id": _id_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_rest_2, _slots_0))};
        } else {
          const _frames_0 = _t_0["frames"];
          const _rest_3 = _notices_0["tail"];
          return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-commands.CleanupPaused", "frames": _frames_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058rebuilt$1260$(_rest_3, _slots_0))};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_batch_head$1260$(_rest_0, _tick_0, _returned_0) {
  const _family_0 = _returned_0["fst"];
  const _t_0 = _returned_0["snd"];
  const _records_0 = _t_0["fst"];
  const _slots_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_batch_join$1260$(_tick_0, _records_0, _slots_0, _rest_0(_family_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_records$1260$(_records_0, _family_0, _tick_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Tuple", "fst": _family_0, "snd": {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}}};
  } else {
    const _head_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_record_head$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_records$1260$(_rest_0, _x_0, _tick_0);
}), ($keep_publications$(_family_0, _tick_0, {$: "Con", "head": _head_0, "tail": {$: "Nil"}})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058frame$1260$(_stream_0, _tick_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058trimmed$1260$(_domain_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _capacity_0, run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_capacity$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$(_positions_0, _frameStart_0)), _dropped_0)), _capacity_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058descriptor_json$(_value_0) {
  const _key_0 = _value_0["key"];
  const _name_0 = _value_0["name"];
  const _inverse_0 = _value_0["inverseName"];
  const _kind_0 = _value_0["kind"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058kind_json$(_kind_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_inverse_0));
  const _x_3 = (",\"kind\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_name_0));
  const _x_6 = (",\"inverse\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($U32$show$(_key_0));
  const _x_9 = (",\"name\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return ("{\"key\":" + _x_10);
}

function $ordinary$045scheduled$045reader$045consumer$058operation_json$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.Relate") {
    return "\"relate\"";
  } else {
    return "\"reorder\"";
  }
}

function $ordinary$045scheduled$045reader$045consumer$058error_json$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.MissingEntity") {
    const _source_0 = _value_0["source"];
    const _x_0 = ($U32$show$(_source_0));
    const _x_1 = (_x_0 + "}");
    return ("{\"kind\":\"missingEntity\",\"source\":" + _x_1);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.MissingTargetEntity") {
    const _source_1 = _value_0["source"];
    const _target_0 = _value_0["target"];
    const _relation_0 = _value_0["relation"];
    const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_relation_0));
    const _x_3 = (_x_2 + "}");
    const _x_4 = ($U32$show$(_target_0));
    const _x_5 = (",\"relation\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($U32$show$(_source_1));
    const _x_8 = (",\"target\":" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    return ("{\"kind\":\"missingTarget\",\"source\":" + _x_9);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.SelfRelationNotAllowed") {
    const _source_2 = _value_0["source"];
    const _relation_1 = _value_0["relation"];
    const _x_10 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_relation_1));
    const _x_11 = (_x_10 + "}");
    const _x_12 = ($U32$show$(_source_2));
    const _x_13 = (",\"relation\":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    return ("{\"kind\":\"self\",\"source\":" + _x_14);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.HierarchyCycle") {
    const _source_3 = _value_0["source"];
    const _target_1 = _value_0["target"];
    const _relation_2 = _value_0["relation"];
    const _x_15 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_relation_2));
    const _x_16 = (_x_15 + "}");
    const _x_17 = ($U32$show$(_target_1));
    const _x_18 = (",\"relation\":" + _x_16);
    const _x_19 = (_x_17 + _x_18);
    const _x_20 = ($U32$show$(_source_3));
    const _x_21 = (",\"target\":" + _x_19);
    const _x_22 = (_x_20 + _x_21);
    return ("{\"kind\":\"cycle\",\"source\":" + _x_22);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.MissingChildEntity") {
    const _source_4 = _value_0["source"];
    const _child_0 = _value_0["child"];
    const _relation_3 = _value_0["relation"];
    const _x_23 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_relation_3));
    const _x_24 = (_x_23 + "}");
    const _x_25 = ($U32$show$(_child_0));
    const _x_26 = (",\"relation\":" + _x_24);
    const _x_27 = (_x_25 + _x_26);
    const _x_28 = ($U32$show$(_source_4));
    const _x_29 = (",\"child\":" + _x_27);
    const _x_30 = (_x_28 + _x_29);
    return ("{\"kind\":\"missingChild\",\"source\":" + _x_30);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.DuplicateChild") {
    const _source_5 = _value_0["source"];
    const _child_1 = _value_0["child"];
    const _relation_4 = _value_0["relation"];
    const _x_31 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_relation_4));
    const _x_32 = (_x_31 + "}");
    const _x_33 = ($U32$show$(_child_1));
    const _x_34 = (",\"relation\":" + _x_32);
    const _x_35 = (_x_33 + _x_34);
    const _x_36 = ($U32$show$(_source_5));
    const _x_37 = (",\"child\":" + _x_35);
    const _x_38 = (_x_36 + _x_37);
    return ("{\"kind\":\"duplicateChild\",\"source\":" + _x_38);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.ChildNotRelatedToParent") {
    const _source_6 = _value_0["source"];
    const _child_2 = _value_0["child"];
    const _relation_5 = _value_0["relation"];
    const _x_39 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_relation_5));
    const _x_40 = (_x_39 + "}");
    const _x_41 = ($U32$show$(_child_2));
    const _x_42 = (",\"relation\":" + _x_40);
    const _x_43 = (_x_41 + _x_42);
    const _x_44 = ($U32$show$(_source_6));
    const _x_45 = (",\"child\":" + _x_43);
    const _x_46 = (_x_44 + _x_45);
    return ("{\"kind\":\"unrelatedChild\",\"source\":" + _x_46);
  } else {
    const _source_7 = _value_0["source"];
    const _relation_6 = _value_0["relation"];
    const _x_47 = ($ordinary$045scheduled$045reader$045consumer$058quoted$(_relation_6));
    const _x_48 = (_x_47 + "}");
    const _x_49 = ($U32$show$(_source_7));
    const _x_50 = (",\"relation\":" + _x_48);
    const _x_51 = (_x_49 + _x_50);
    return ("{\"kind\":\"childSetMismatch\",\"source\":" + _x_51);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058frame_json$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.CleanupEnter") {
    const _id_0 = _value_0["id"];
    const _x_0 = ($U32$show$(_id_0));
    const _x_1 = (_x_0 + "}");
    return ("{\"kind\":\"enter\",\"id\":" + _x_1);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.CleanupDescriptors") {
    const _id_1 = _value_0["id"];
    const _remaining_0 = _value_0["remaining"];
    const _x_2 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1260$(_remaining_0));
    const _x_3 = (_x_2 + "}");
    const _x_4 = ($U32$show$(_id_1));
    const _x_5 = (",\"remaining\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    return ("{\"kind\":\"descriptors\",\"id\":" + _x_6);
  } else if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.CleanupChildren") {
    const _id_2 = _value_0["id"];
    const _descriptor_0 = _value_0["descriptor"];
    const _remaining_1 = _value_0["remainingDescriptors"];
    const _children_0 = _value_0["remainingChildren"];
    const _x_7 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1261$(_children_0));
    const _x_8 = (_x_7 + "}");
    const _x_9 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1260$(_remaining_1));
    const _x_10 = (",\"children\":" + _x_8);
    const _x_11 = (_x_9 + _x_10);
    const _x_12 = ($ordinary$045scheduled$045reader$045consumer$058descriptor_json$(_descriptor_0));
    const _x_13 = (",\"remaining\":" + _x_11);
    const _x_14 = (_x_12 + _x_13);
    const _x_15 = ($U32$show$(_id_2));
    const _x_16 = (",\"descriptor\":" + _x_14);
    const _x_17 = (_x_15 + _x_16);
    return ("{\"kind\":\"children\",\"id\":" + _x_17);
  } else {
    const _id_3 = _value_0["id"];
    const _x_18 = ($U32$show$(_id_3));
    const _x_19 = (_x_18 + "}");
    return ("{\"kind\":\"finish\",\"id\":" + _x_19);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1262$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058frame_json$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1262$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058cursor_completion$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _t_0 = _outcome_0["output"];
    const _meta_0 = _t_0["meta"];
    const _reader_0 = _t_0["reader"];
    const _parameter_0 = _t_0["parameter"];
    const _declaration_0 = _t_0["declaration"];
    const _t_1 = _t_0["completion"];
    if (_t_1.$ === "../../../../../../../../src/ecs/ordinary-reader-system.CallbackCompleted") {
      const _output_0 = _t_1["output"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058cursor_success$1260$(_registry_0, {$: "../../../../../../../../src/ecs/ordinary-reader-system.Envelope", "meta": _meta_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0, "completion": {$: "../../../../../../../../src/ecs/ordinary-reader-system.CallbackCompleted", "output": _output_0}}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
    } else if (_t_1.$ === "../../../../../../../../src/ecs/ordinary-reader-system.CallbackFailed") {
      const _error_1 = _t_1["error"];
      const _output_1 = _t_1["output"];
      return {$: "../../../../../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../src/ecs/system.Succeeded", "world": _world_1, "output": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Envelope", "meta": _meta_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0, "completion": {$: "../../../../../../../../src/ecs/ordinary-reader-system.CallbackFailed", "error": _error_1, "output": _output_1}}}};
    } else {
      return {$: "../../../../../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../src/ecs/system.Succeeded", "world": _world_1, "output": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Envelope", "meta": _meta_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0, "completion": {$: "../../../../../../../../src/ecs/ordinary-reader-system.CallbackInvalidReader"}}}};
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $position_json$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registeredAt_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registeredAt_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Nat$show$(_cursor_0));
  const _x_3 = (",\"registeredAt\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_id_0));
  const _x_6 = (",\"cursor\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"id\":" + _x_7);
}

function $list_tail$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($position_json$(_value_0));
    const _x_1 = ($list_tail$1260$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $domain_json$(_value_0) {
  const _key_0 = _value_0["key"];
  const _queue_0 = _value_0["queue"];
  const _readers_0 = _value_0["readers"];
  const _x_0 = ($queue_json$(_queue_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($list_json$1263$(_readers_0));
  const _x_3 = (",\"queue\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($domain_key_json$(_key_0));
  const _x_6 = (",\"readers\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"key\":" + _x_7);
}

function $list_tail$1264$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($domain_json$(_value_0));
    const _x_1 = ($list_tail$1264$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058edge_json$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _source_0 = _value_0["source"];
  const _target_0 = _value_0["target"];
  const _x_0 = ($U32$show$(_target_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_source_0));
  const _x_3 = (",\"target\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($ordinary$045scheduled$045reader$045consumer$058descriptor_json$(_relation_0));
  const _x_6 = (",\"source\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"relation\":" + _x_7);
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1263$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058edge_json$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1263$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058inverse_json$(_value_0) {
  const _relation_0 = _value_0["relation"];
  const _target_0 = _value_0["target"];
  const _sources_0 = _value_0["sources"];
  const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_json$1261$(_sources_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($U32$show$(_target_0));
  const _x_3 = (",\"sources\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($ordinary$045scheduled$045reader$045consumer$058descriptor_json$(_relation_0));
  const _x_6 = (",\"target\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"relation\":" + _x_7);
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1264$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058inverse_json$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1264$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_ids_0, _namespace_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045providers$058handle_ids$1260$(_rest_0, _namespace_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058inverse_present$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _sources_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Some", "value": _sources_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_inverse$1260$(_store_0, _descriptor_0, _target_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_clear_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_x_0, _descriptor_0, _source_0);
}))), "snd": {$: "../../../../../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058provider_dispose_parts$1260$(_registry_0, _reader_0, _parameter_0, _declaration_0, _parts_0) {
  const _world_0 = _parts_0["fst"];
  const _meta_0 = _parts_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058provider_disposal_result$1260$(_reader_0, _parameter_0, _declaration_0, _meta_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose$1260$(_registry_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_after_left$1260$(_ownerB_0, _validatedA_0) {
  const _world_0 = _validatedA_0["fst"];
  const _t_0 = _validatedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _left_valid_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_join$1260$(_left_valid_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_fn$1261$(_world_0, _ownerB_0)), _ownerA_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058validate_context$1260$(_context_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "snd": {$: "Tuple", "fst": _owner_0, "snd": true}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_finish$1263$(_ownerA_0, _paramA_0, _initializedB_0) {
  const _contextB_0 = _initializedB_0["fst"];
  const _t_0 = _initializedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _paramB_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _contextB_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": ($ordinary$045scheduled$045reader$045consumer$058pair_all$(_paramA_0, _paramB_0))}};
}

function $ordinary$045scheduled$045reader$045consumer$058eemr_initialize$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair$1262$(_context_0, _facts_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058tx_get_join$1260$(_undo_0, _commands_0, _events_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058predicate_field$1260$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045selections$058inspect_with$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_with$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $retry_result$(_report_0, _rows_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.RunCompleted") {
    const _context_0 = _result_0["context"];
    const _provider_0 = _result_0["provider"];
    const _output_0 = _result_0["output"];
    return $retry_completed_run$(_report_0, _rows_0, _context_0, _provider_0, _output_0);
  } else if (_result_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.RunFailed") {
    const _context_1 = _result_0["context"];
    const _provider_1 = _result_0["provider"];
    const _error_0 = _result_0["error"];
    const _output_1 = _result_0["output"];
    return $retry_failed$(_report_0, _rows_0, _context_1, _provider_1, _error_0, _output_1);
  } else if (_result_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.RunInvalidReader") {
    return $final_output$(_report_0, ($append_row$(_rows_0, "{\"phase\":\"retry\",\"status\":\"invalidReader\"}")));
  } else if (_result_0.$ === "../../../../../../../../src/ecs/ordinary-reader-system.RunRegistrationRejected") {
    return $final_output$(_report_0, ($append_row$(_rows_0, "{\"phase\":\"retry\",\"status\":\"registrationRejected\"}")));
  } else {
    return $final_output$(_report_0, ($append_row$(_rows_0, "{\"phase\":\"retry\",\"status\":\"skipped\"}")));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058trim$1260$(_domains_0, _positions_0, _fallback_0, _capacity_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _domain_0 = _domains_0["head"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058trim_domain$1260$(_domain_0, _positions_0, _fallback_0, _capacity_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058trim$1260$(_rest_0, _positions_0, _fallback_0, _capacity_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058original_notices$1260$(_records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-commands.Original", "event": _head_0}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058original_notices$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_batch_join$1260$(_tick_0, _records_0, _slots_0, _returned_0) {
  const _family_0 = _returned_0["family"];
  const _journal_0 = _returned_0["journal"];
  const _tail_0 = _returned_0["slots"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1261$(_records_0));
  return {$: "../../../../../../../../src/ecs/event-notice-runtime.Retention", "family": _family_0, "journal": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045family$045runtime$058kept_batch$1260$((0 < _x_0), _tick_0, _records_0, _journal_0)), "slots": ($List$append$(_slots_0, _tail_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_record_head$1260$(_rest_0, _returned_0) {
  const _family_0 = _returned_0["fst"];
  const _head_0 = _returned_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_record$1260$(_head_0, _rest_0(_family_0));
}

function $keep_publications$(_family_0, _tick_0, _publications_0) {
  return {$: "Tuple", "fst": _family_0, "snd": _publications_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058trimmed$1260$(_domain_0, _positions_0, _nextReader_0, _frameStart_0, _boundary_0, _capacity_0, _trimmed_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058trim_capacity$1260$(_trimmed_0, _capacity_0) {
  const _batches_0 = _trimmed_0["batches"];
  const _dropped_0 = _trimmed_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_window$1260$(_batches_0, _boundary_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_checked$1260$(($Nat$is_le$(_tick_0, _boundary_0)), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_window$1260$(_rest_0, _boundary_0, _x_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $ordinary$045scheduled$045reader$045consumer$058kind_json$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/relation-types.Ordinary") {
    return "\"ordinary\"";
  } else {
    return "\"hierarchy\"";
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1260$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058descriptor_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_json$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1261$(_rest_0));
    const _x_1 = ($U32$show$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058cursor_success$1260$(_registry_0, _envelope_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _nextCursor_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _envelope_0}, _registry_0, _nextCursor_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $domain_key_json$(_value_0) {
  const _id_0 = _value_0["id"];
  return $U32$show$(_id_0);
}

function $list_json$1263$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($list_tail$1263$(_rest_0));
    const _x_1 = ($U32$show$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $queue_json$(_value_0) {
  const _front_0 = _value_0["front"];
  const _back_0 = _value_0["back"];
  const _size_0 = _value_0["size"];
  const _dropped_0 = _value_0["dropped"];
  const _x_0 = ($Nat$show$(_dropped_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Nat$show$(_size_0));
  const _x_3 = (",\"dropped\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($batches_json$(_back_0));
  const _x_6 = (",\"size\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  const _x_8 = ($batches_json$(_front_0));
  const _x_9 = (",\"back\":" + _x_7);
  const _x_10 = (_x_8 + _x_9);
  return ("{\"front\":" + _x_10);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse$1260$(_graph_0, _descriptor_0, _target_0) {
  const _entries_0 = _graph_0["inverses"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_unrelate$1260$(_world_0, _descriptor_0, _source_0) {
  const _id_0 = _source_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058discard_unit$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_unrelate$1260$(_x_0, _descriptor_0, _id_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058provider_disposal_result$1260$(_reader_0, _parameter_0, _declaration_0, _meta_0, _disposed_0) {
  if (_disposed_0.$ === "../../../../../../../../src/ecs/system.Disposed") {
    const _world_0 = _disposed_0["world"];
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.ProviderDisposed", "context": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058release$1260$(_parameter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), _reader_0)), "declaration": _declaration_0};
  } else {
    const _world_1 = _disposed_0["world"];
    const _registry_0 = _disposed_0["registry"];
    return {$: "../../../../../../../../src/ecs/ordinary-reader-system.ProviderDisposalRejected", "context": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_1, _meta_0)), "provider": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Provider", "registry": _registry_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose$1260$(_registry_0, _world_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose_returned$1260$({$: "../../../../../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove$1260$(_world_0, _namespace_0, _id_0, _name_0, _access_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_join$1260$(_left_valid_0, _validatedB_0, _ownerA_0) {
  const _world_0 = _validatedB_0["fst"];
  const _t_0 = _validatedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _right_valid_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": ($Bool$and$(_left_valid_0, _right_valid_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_fn$1261$(_world_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_after_left$1261$(_ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058validate_event$1260$(_world_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair$1262$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_after_first$1262$(_facts_0, ($ordinary$045scheduled$045reader$045consumer$058e_initialize$(_context_0, _facts_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../../../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, ($ordinary$045scheduled$045reader$045consumer$058take_values$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_with$1260$() {
  return {$: "../../../../../../../../src/ecs/inspector-query-projection.Predicate", "matches": run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_matches$1260$(_x_0, _x_1);
});
})};
}

function $retry_completed_run$(_report_0, _rows_0, _context_0, _provider_0, _view_0) {
  return $retry_completed$(_report_0, _rows_0, ($phase_record$(_context_0, _provider_0, "retry", "completed", "null", ($ordinary$045scheduled$045reader$045consumer$058view_json$(_view_0)))));
}

function $retry_failed$(_report_0, _rows_0, _context_0, _provider_0, _error_0, _view_0) {
  return $retry_completed$(_report_0, _rows_0, ($phase_record$(_context_0, _provider_0, "retry", "failed", ($U32$show$(_error_0)), ($ordinary$045scheduled$045reader$045consumer$058view_json$(_view_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058trim_domain$1260$(_domain_0, _positions_0, _fallback_0, _capacity_0) {
  const _key_0 = _domain_0["key"];
  const _queue_0 = _domain_0["queue"];
  const _ids_0 = _domain_0["readers"];
  return {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim$1260$(_queue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058boundary$(_positions_0, _ids_0, _fallback_0)), _capacity_0)), "readers": _ids_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045family$045runtime$058kept_batch$1260$(_keep_0, _tick_0, _records_0, _journal_0) {
  if (!_keep_0) {
    return _journal_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _records_0}, "tail": _journal_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058retained_record$1260$(_head_0, _returned_0) {
  const _family_0 = _returned_0["fst"];
  const _t_0 = _returned_0["snd"];
  const _records_0 = _t_0["fst"];
  const _slots_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _family_0, "snd": {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1263$(_head_0, _records_0)), "snd": {$: "Con", "head": _head_0, "tail": _slots_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_batches_0, _capacity_0, _dropped_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "../../../../../../../../src/ecs/event-runtime.Trimmed", "batches": {$: "Nil"}, "dropped": _dropped_0};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1261$({$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058capacity_checked$1260$((_capacity_0 < _x_0), _tick_0, _items_0, _rest_0, _dropped_0, run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058at_capacity$1260$(_rest_0, _capacity_0, _x_1);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058past_checked$1260$(_remove_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../../../../../../src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1260$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058descriptor_json$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1260$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $ordinary$045scheduled$045reader$045consumer$058list_tail$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($U32$show$(_value_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058list_tail$1261$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../../../../../src/ecs/system.Completed", "registry": {$: "../../../../../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $list_tail$1263$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($U32$show$(_value_0));
    const _x_1 = ($list_tail$1263$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $batches_json$(_values_0) {
  return $list_json$1262$(_values_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_entries_0, _descriptor_0, _target_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _sources_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_entries$1260$(_rest_0, _descriptor_0, _target_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058discard_unit$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_unrelate$1260$(_store_0, _descriptor_0, _source_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058unrelate$1260$(_graph_0, _descriptor_0, _source_0))}, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058release$1260$(_param_0, _world_0, _owner_0) {
  return $ordinary$045scheduled$045reader$045consumer$058release_all$(_world_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose_returned$1260$(_registry_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0) {
    return {$: "../../../../../../../../src/ecs/system.Disposed", "world": _world_0};
  } else {
    return {$: "../../../../../../../../src/ecs/system.DisposalRejected", "world": _world_0, "registry": _registry_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove$1260$(_world_0, _namespace_0, _id_0, _name_0, _access_0) {
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove_checked$1260$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../../../../../../src/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _id_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_after_left$1261$(_ownerB_0, _validatedA_0) {
  const _world_0 = _validatedA_0["fst"];
  const _t_0 = _validatedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _left_valid_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_join$1261$(_left_valid_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_fn$1262$(_world_0, _ownerB_0)), _ownerA_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058validate_event$1260$(_context_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  const _facts_0 = _owner_0["facts"];
  const _reader_0 = _owner_0["reader"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_validate_join$1260$(_tick_0, _facts_0, _reader_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058registered_context$1260$(_world_0, _facts_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_selected_domain$1260$(($ordinary$045scheduled$045reader$045consumer$058event_declaration$()), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058take$1260$(_state_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_after_first$1262$(_facts_0, _initializedA_0) {
  const _contextAfterA_0 = _initializedA_0["fst"];
  const _t_0 = _initializedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _paramA_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_finish$1262$(_ownerA_0, _paramA_0, ($ordinary$045scheduled$045reader$045consumer$058emr_initialize$(_contextAfterA_0, _facts_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058e_initialize$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058initialize_event$1260$(_context_0, _facts_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058take_values$(_store_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": _graph_0, "snd": _components_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_matches$1260$(_frame_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_matched$1260$({$: "../../../../../../../../src/ecs/compose.Present"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_presence$1260$(_frame_0, _target_0)));
}

function $retry_completed$(_report_0, _rows_0, _observed_0) {
  const _t_0 = _observed_0["snd"];
  const _row_0 = _t_0["snd"];
  return $final_output$(_report_0, ($append_row$(_rows_0, _row_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim$1260$(_queue_0, _boundary_0, _capacity_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim_loop$1260$(nat_chk(_size_0 + 1), {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058boundary$($0, $1, $2) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _ids_0 = $1;
      const _acc_0 = $2;
      if (_positions_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _id_0 = _t_0["id"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = _ids_0;
        $2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058select_boundary$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _id_0)), _cursor_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1263$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1263$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058capacity_checked$1260$(_overflow_0, _tick_0, _items_0, _rest_0, _dropped_0, _ih_0) {
  if (!_overflow_0) {
    return {$: "../../../../../../../../src/ecs/event-runtime.Trimmed", "batches": {$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _items_0}, "tail": _rest_0}, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1261$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1261$(_batches_0, 0);
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $list_json$1262$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($list_tail$1262$(_rest_0));
    const _x_1 = ($batch_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058unrelate$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  return {$: "../../../../../../../../src/ecs/relation-types.Graph", "edges": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), "inverses": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0))};
}

function $ordinary$045scheduled$045reader$045consumer$058release_all$(_context_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_fn$1260$(_context_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove_checked$1260$(_allowed_0, _world_0, _id_0, _name_0, _access_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0)), "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_join$1261$(_left_valid_0, _validatedB_0, _ownerA_0) {
  const _world_0 = _validatedB_0["fst"];
  const _t_0 = _validatedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _right_valid_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": ($Bool$and$(_left_valid_0, _right_valid_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_fn$1262$(_world_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_after_left$1262$(_ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058validate_event$1260$(_world_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_validate_join$1260$(_tick_0, _facts_0, _reader_0, _registeredContext_0, _selectedDomain_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_validate_registered$1260$(_tick_0, _facts_0, _reader_0, _registeredContext_0, _selectedDomain_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058registered_context$1260$(_world_0, _facts_0) {
  const _namespace_0 = _facts_0["namespace"];
  const _id_0 = _facts_0["id"];
  const _name_0 = _facts_0["name"];
  const _access_0 = _facts_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058registered_context_named$1260$(_id_0, _name_0, _access_0, _namespace_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_selected_domain$1260$(_declaration_0, _selected_0) {
  const _state_0 = _selected_0["fst"];
  const _stream_0 = _selected_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058put$1260$(_state_0, _stream_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_domain_matches$1260$(_declaration_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058domain$1260$(_stream_0))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058take$1260$(_state_0) {
  const _typed_0 = _state_0["typed"];
  const _failures_0 = _state_0["failures"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058selected$1260$(_failures_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045family$045runtime$058take$1260$(_typed_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_finish$1262$(_ownerA_0, _paramA_0, _initializedB_0) {
  const _contextB_0 = _initializedB_0["fst"];
  const _t_0 = _initializedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _paramB_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _contextB_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": ($ordinary$045scheduled$045reader$045consumer$058pair_eemr$(_paramA_0, _paramB_0))}};
}

function $ordinary$045scheduled$045reader$045consumer$058emr_initialize$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair$1261$(_context_0, _facts_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058initialize_event$1260$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058initialize_event_selected$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_readable$1260$(($ordinary$045scheduled$045reader$045consumer$058event_declaration$()))), _context_0, _facts_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($ordinary$045scheduled$045reader$045consumer$058put_values$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_matched$1260$(_mode_0, _observed_0) {
  const _frame_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _frame_0, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058selected_value$1261$(_mode_0, _value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_presence$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_allowed$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _target_0)), _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim_loop$1260$(_fuel_0, _queue_0, _boundary_0, _capacity_0) {
  if (_fuel_0 === 0) {
    return _queue_0;
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim_normalized$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058normalize$1260$(_queue_0)), _boundary_0, _capacity_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim_loop$1260$(_rest_0, _x_0, _boundary_0, _capacity_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058select_boundary$(_registered_0, _cursor_0, _boundary_0) {
  if (!_registered_0) {
    return _boundary_0;
  } else {
    return (_cursor_0 < _boundary_0 ? _cursor_0 : _boundary_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_id_0 === _wanted_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_rest_0, _wanted_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1263$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1261$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058shared_runner$1260$(_world_0, _args_0)));
  }
}

function $batch_json$(_value_0) {
  const _tick_0 = _value_0["tick"];
  const _count_0 = _value_0["count"];
  const _values_0 = _value_0["values"];
  const _x_0 = ($list_json$1261$(_values_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Nat$show$(_count_0));
  const _x_3 = (",\"values\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($Nat$show$(_tick_0));
  const _x_6 = (",\"count\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"tick\":" + _x_7);
}

function $list_tail$1262$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($batch_json$(_value_0));
    const _x_1 = ($list_tail$1262$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_fn$1260$(_context_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_after_left$1260$(_ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058release_context$1260$(_context_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$(($Bool$not$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0)))), _meta_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_rest_0, _id_0, _name_0, _access_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_after_left$1262$(_ownerB_0, _validatedA_0) {
  const _world_0 = _validatedA_0["fst"];
  const _t_0 = _validatedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _left_valid_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_join$1262$(_left_valid_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_fn$1263$(_world_0, _ownerB_0)), _ownerA_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_validate_registered$1260$(_tick_0, _facts_0, _reader_0, _registered_0, _selected_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_validate_domain$1260$(_tick_0, _facts_0, _reader_0, _registered_0, _selected_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058registered_context_named$1260$(_id_0, _name_0, _access_0, _factsNamespace_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _currentNamespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058registered_context_checked$1260$(_factsNamespace_0, _currentNamespace_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058put$1260$(_state_0, _stream_0) {
  const _typed_0 = _state_0["typed"];
  const _failures_0 = _state_0["failures"];
  return {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045family$045runtime$058put$1260$(_typed_0, _stream_0)), "failures": _failures_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_domain_matches$1260$(_declaration_0, _domain_0) {
  const _t_0 = _declaration_0["domain"];
  const _expected_0 = _t_0["key"];
  const _t_1 = _declaration_0["mode"];
  if (_t_1.$ === "../../../../../../../../src/ecs/ordinary-event-declaration.Read") {
    const _actual_0 = _domain_0["key"];
    return $String$eq$(_expected_0, _actual_0);
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058domain$1260$(_stream_0) {
  const _domain_0 = _stream_0["domain"];
  return _domain_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058selected$1260$(_failures_0, _returned_0) {
  const _typed_0 = _returned_0["fst"];
  const _stream_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": _failures_0}, "snd": _stream_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045family$045runtime$058take$1260$(_state_0) {
  const _family_0 = _state_0["family"];
  const _owners_0 = _state_0["owners"];
  const _journal_0 = _state_0["journal"];
  const _frameStart_0 = _state_0["frameStart"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045family$045runtime$058selected_state$1260$(_owners_0, _journal_0, _frameStart_0, ($ordinary$045scheduled$045reader$045consumer$058take_events$(_family_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058pair_eemr$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1262$(_left_0, _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair$1261$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_after_first$1261$(_facts_0, ($ordinary$045scheduled$045reader$045consumer$058e_initialize$(_context_0, _facts_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058initialize_event_selected$1260$(_readable_0, _context_0, _facts_0) {
  if (!_readable_0) {
    const _world_0 = _context_0["world"];
    const _state_0 = _context_0["family"];
    const _tick_0 = _context_0["tick"];
    const _namespace_0 = _facts_0["namespace"];
    const _registryId_0 = _facts_0["id"];
    const __0 = _facts_0["name"];
    const __1 = _facts_0["access"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.EventOwner", "facts": {$: "../../../../../../../../src/ecs/reader-parameter.RegistrationFacts", "namespace": _namespace_0, "id": _registryId_0, "name": __0, "access": __1}, "reader": {$: "../../../../../../../../src/ecs/event-family-routing.Reader", "namespace": _namespace_0, "id": 0, "registryId": _registryId_0}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_param$1260$())}};
  } else {
    const _world_1 = _context_0["world"];
    const _state_1 = _context_0["family"];
    const _tick_1 = _context_0["tick"];
    const _namespace_1 = _facts_0["namespace"];
    const _registryId_1 = _facts_0["id"];
    const __2 = _facts_0["name"];
    const __3 = _facts_0["access"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_initialized_registered$1260$(_world_1, _tick_1, {$: "../../../../../../../../src/ecs/reader-parameter.RegistrationFacts", "namespace": _namespace_1, "id": _registryId_1, "name": __2, "access": __3}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_registered$1260$(_state_1, _tick_1)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_readable$1260$(_declaration_0) {
  const _t_0 = _declaration_0["mode"];
  if (_t_0.$ === "../../../../../../../../src/ecs/ordinary-event-declaration.Read") {
    return true;
  } else {
    return false;
  }
}

function $ordinary$045scheduled$045reader$045consumer$058put_values$(_graph_0, _column_0) {
  return {$: "../../../../../../../../src/ecs/relation-commands.Store", "components": _column_0, "graph": _graph_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../../../../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047compose$058selected_value$1261$(_mode_0, _value_0) {
  if (_mode_0.$ === "../../../../../../../../src/ecs/compose.Required") {
    if (_value_0.$ === "../../../../../../../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../src/ecs/compose.Present") {
    if (_value_0.$ === "../../../../../../../../src/ecs/component.Found") {
      return true;
    } else {
      return false;
    }
  } else if (_mode_0.$ === "../../../../../../../../src/ecs/compose.Absent") {
    if (_value_0.$ === "../../../../../../../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_value_0.$ === "../../../../../../../../src/ecs/component.Found") {
      return true;
    } else if (_value_0.$ === "../../../../../../../../src/ecs/component.ComponentAbsent") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045families$058inspect_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_allowed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../src/ecs/component.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_world$1260$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim_normalized$1260$(_queue_0, _boundary_0, _capacity_0, _ih_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Nil"}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _t_1 = _t_0["head"];
    const _tick_0 = _t_1["tick"];
    const _count_0 = _t_1["count"];
    const _items_0 = _t_1["values"];
    const _rest_0 = _t_0["tail"];
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    const _x_0 = ($Nat$is_le$(_tick_0, _boundary_0));
    const _x_1 = (_capacity_0 < _size_1);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim_step$1260$((_x_0 || _x_1), _tick_0, _count_0, _items_0, _rest_0, _back_1, _size_1, _dropped_1, _ih_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058normalize$1260$(_queue_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": ($List$reverse$(_back_0)), "back": {$: "Nil"}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    return {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _t_0, "back": _back_1, "size": _size_1, "dropped": _dropped_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058shared_runner$1260$(_world_0, _input_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058runner$1260$(_world_0, _input_0);
}

function $list_json$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($list_tail$1261$(_rest_0));
    const _x_1 = ($ordinary$045scheduled$045reader$045consumer$058notice_json$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_after_left$1260$(_ownerB_0, _context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_fn$1261$(_context_0, _ownerB_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058release_context$1260$(_context_0, _owner_0) {
  return _context_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$(_keep_0, _meta_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _meta_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_join$1262$(_left_valid_0, _validatedB_0, _ownerA_0) {
  const _world_0 = _validatedB_0["fst"];
  const _t_0 = _validatedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _right_valid_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": ($Bool$and$(_left_valid_0, _right_valid_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_fn$1263$(_world_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_after_left$1263$(_ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058validate_removal$1260$(_world_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_validate_domain$1260$(_tick_0, _facts_0, _reader_0, _registered_0, _selected_0) {
  const _world_0 = _registered_0["fst"];
  const _isRegistered_0 = _registered_0["snd"];
  const _state_0 = _selected_0["fst"];
  const _domainMatches_0 = _selected_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_validate_values$1260$(_tick_0, _facts_0, _reader_0, _world_0, _isRegistered_0, _state_0, _domainMatches_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058registered_context_checked$1260$(_namespace_0, _currentNamespace_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _matched_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($Bool$and$((_namespace_0 === _currentNamespace_0), _matched_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045family$045runtime$058put$1260$(_state_0, _stream_0) {
  const _family_0 = _state_0["family"];
  const _owners_0 = _state_0["owners"];
  const _journal_0 = _state_0["journal"];
  const _frameStart_0 = _state_0["frameStart"];
  return {$: "../../../../../../../../src/ecs/event-family-runtime.State", "family": ($ordinary$045scheduled$045reader$045consumer$058put_events$(_family_0, _stream_0)), "owners": _owners_0, "journal": _journal_0, "frameStart": _frameStart_0};
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045family$045runtime$058selected_state$1260$(_owners_0, _journal_0, _frameStart_0, _returned_0) {
  const _family_0 = _returned_0["fst"];
  const _stream_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_0, "journal": _journal_0, "frameStart": _frameStart_0}, "snd": _stream_0};
}

function $ordinary$045scheduled$045reader$045consumer$058take_events$(_family_0) {
  return $ordinary$045scheduled$045reader$045consumer$058copy_events$(_family_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_after_first$1261$(_facts_0, _initializedA_0) {
  const _contextAfterA_0 = _initializedA_0["fst"];
  const _t_0 = _initializedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _paramA_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_finish$1261$(_ownerA_0, _paramA_0, ($ordinary$045scheduled$045reader$045consumer$058mr_initialize$(_contextAfterA_0, _facts_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_initialized_registered$1260$(_world_0, _tick_0, _facts_0, _registered_0) {
  const _namespace_0 = _facts_0["namespace"];
  const _registryId_0 = _facts_0["id"];
  const __0 = _facts_0["name"];
  const __1 = _facts_0["access"];
  const _state_0 = _registered_0["fst"];
  const _id_0 = _registered_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.EventOwner", "facts": {$: "../../../../../../../../src/ecs/reader-parameter.RegistrationFacts", "namespace": _namespace_0, "id": _registryId_0, "name": __0, "access": __1}, "reader": {$: "../../../../../../../../src/ecs/event-family-routing.Reader", "namespace": _namespace_0, "id": _id_0, "registryId": _registryId_0}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_param$1260$())}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_registered$1260$(_state_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_registered_selected$1260$(_tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058take$1260$(_state_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_world$1260$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, ($ordinary$045scheduled$045reader$045consumer$058take_values$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058trim_step$1260$(_remove_0, _tick_0, _count_0, _items_0, _rest_0, _back_0, _size_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _rest_0}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _rest_0, "back": _back_0, "size": (_size_0 < _count_0 ? 0 : _size_0 - _count_0), "dropped": (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0)});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058runner$1260$(_world_0, _input_0) {
  const _meta_0 = _input_0["meta"];
  const _reader_0 = _input_0["reader"];
  const _parameter_0 = _input_0["parameter"];
  const _declaration_0 = _input_0["declaration"];
  const _args_0 = _input_0["args"];
  const _queryCursor_0 = _input_0["queryCursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058validated$1260$(_parameter_0, _declaration_0, _args_0, _queryCursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058validate$1260$(_parameter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), _reader_0)));
}

function $list_tail$1261$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($ordinary$045scheduled$045reader$045consumer$058notice_json$(_value_0));
    const _x_1 = ($list_tail$1261$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "../../../../../../../../src/ecs/relation-types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "../../../../../../../../src/ecs/relation-types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "../../../../../../../../src/ecs/relation-types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "../../../../../../../../src/ecs/relation-types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "../../../../../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_fn$1261$(_context_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_after_left$1261$(_ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058release_event$1260$(_context_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_after_left$1263$(_ownerB_0, _validatedA_0) {
  const _world_0 = _validatedA_0["fst"];
  const _t_0 = _validatedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _left_valid_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_join$1263$(_left_valid_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058validate_relation$1260$(_world_0, _ownerB_0)), _ownerA_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058validate_removal$1260$(_context_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  const _facts_0 = _owner_0["facts"];
  const _reader_0 = _owner_0["reader"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_validate_checked$1260$(_state_0, _tick_0, _facts_0, _reader_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058registered_context$1260$(_world_0, _facts_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_validate_values$1260$(_tick_0, _facts_0, _reader_0, _world_0, _registered_0, _state_0, _domainMatches_0) {
  const _expectedNamespace_0 = _facts_0["namespace"];
  const _registryIdExpected_0 = _facts_0["id"];
  const __0 = _facts_0["name"];
  const _access_0 = _facts_0["access"];
  const _namespace_0 = _reader_0["namespace"];
  const _readerId_0 = _reader_0["id"];
  const _registryId_0 = _reader_0["registryId"];
  const _valid_0 = ($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_readable$1260$(($ordinary$045scheduled$045reader$045consumer$058event_declaration$()))), ($Bool$and$(_registered_0, ($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058access_subset$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_access$1260$(($ordinary$045scheduled$045reader$045consumer$058event_declaration$()))), _access_0)), ($Bool$and$((_namespace_0 === _expectedNamespace_0), ($Bool$and$((_readerId_0 > 0), ($Bool$and$((_registryId_0 === _registryIdExpected_0), _domainMatches_0))))))))))));
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.EventOwner", "facts": {$: "../../../../../../../../src/ecs/reader-parameter.RegistrationFacts", "namespace": _expectedNamespace_0, "id": _registryIdExpected_0, "name": __0, "access": _access_0}, "reader": {$: "../../../../../../../../src/ecs/event-family-routing.Reader", "namespace": _namespace_0, "id": _readerId_0, "registryId": _registryId_0}}, "snd": _valid_0}};
}

function $ordinary$045scheduled$045reader$045consumer$058put_events$(__0, _stream_0) {
  return _stream_0;
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058copy_events$(_family_0) {
  return {$: "Tuple", "fst": _family_0, "snd": _family_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_finish$1261$(_ownerA_0, _paramA_0, _initializedB_0) {
  const _contextB_0 = _initializedB_0["fst"];
  const _t_0 = _initializedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _paramB_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _contextB_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": ($ordinary$045scheduled$045reader$045consumer$058pair_emr$(_paramA_0, _paramB_0))}};
}

function $ordinary$045scheduled$045reader$045consumer$058mr_initialize$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair$1260$(_context_0, _facts_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_registered_selected$1260$(_tick_0, _selected_0) {
  const _state_0 = _selected_0["fst"];
  const _stream_0 = _selected_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_registered_leaf$1260$(_state_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058registered$1260$(_stream_0, _tick_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($ordinary$045scheduled$045reader$045consumer$058presence$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($ordinary$045scheduled$045reader$045consumer$058presence$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($ordinary$045scheduled$045reader$045consumer$058presence$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058validated$1260$(_parameter_0, _declaration_0, _args_0, _queryCursor_0, _observed_0) {
  const _context_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _reader_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  if (!_t_1) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058invalid_reader$1260$(_declaration_0, _parameter_0, _context_0, _reader_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_validated$1260$(_reader_0, _parameter_0, _declaration_0, _args_0, _queryCursor_0, _context_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058validate$1260$(_param_0, _world_0, _owner_0) {
  return $ordinary$045scheduled$045reader$045consumer$058validate_all$(_world_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_after_left$1261$(_ownerB_0, _context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_fn$1262$(_context_0, _ownerB_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058release_event$1260$(_context_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  const _t_0 = _owner_0["reader"];
  const _readerId_0 = _t_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_release_validated$1260$({$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, _readerId_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_validate_join$1263$(_left_valid_0, _validatedB_0, _ownerA_0) {
  const _world_0 = _validatedB_0["fst"];
  const _t_0 = _validatedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _right_valid_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": ($Bool$and$(_left_valid_0, _right_valid_0))}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058validate_relation$1260$(_context_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  const _facts_0 = _owner_0["facts"];
  const _id_0 = _owner_0["id"];
  const _keys_0 = _owner_0["keys"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_validated$1260$(_state_0, _tick_0, _facts_0, _id_0, _keys_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058registered_context$1260$(_world_0, _facts_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_validate_checked$1260$(_state_0, _tick_0, _facts_0, _reader_0, _registered_0) {
  const _expectedNamespace_0 = _facts_0["namespace"];
  const _expectedId_0 = _facts_0["id"];
  const __0 = _facts_0["name"];
  const _access_0 = _facts_0["access"];
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _name_0 = _reader_0["name"];
  const _cursor_0 = _reader_0["cursor"];
  const _world_0 = _registered_0["fst"];
  const _isRegistered_0 = _registered_0["snd"];
  const _expected_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_access$1260$(($ordinary$045scheduled$045reader$045consumer$058removal_selection$())));
  const _valid_0 = ($Bool$and$(_isRegistered_0, ($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058access_subset$(_expected_0, _access_0)), ($Bool$and$((_namespace_0 === _expectedNamespace_0), ($Bool$and$((_id_0 === _expectedId_0), ($String$eq$(_name_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_name$1260$(($ordinary$045scheduled$045reader$045consumer$058removal_selection$())))))))))))));
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RemovalOwner", "facts": {$: "../../../../../../../../src/ecs/reader-parameter.RegistrationFacts", "namespace": _expectedNamespace_0, "id": _expectedId_0, "name": __0, "access": _access_0}, "reader": {$: "../../../../../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}}, "snd": _valid_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058access_subset$(_wanted_0, _access_0) {
  if (_wanted_0.$ === "Nil") {
    return true;
  } else {
    const _name_0 = _wanted_0["head"];
    const _rest_0 = _wanted_0["tail"];
    return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058access_member$(_name_0, _access_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058access_subset$(_rest_0, _access_0)));
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $ordinary$045scheduled$045reader$045consumer$058pair_emr$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1261$(_left_0, _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair$1260$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_after_first$1260$(_facts_0, ($ordinary$045scheduled$045reader$045consumer$058m_initialize$(_context_0, _facts_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_registered_leaf$1260$(_selected_0, _registered_0) {
  const _stream_0 = _registered_0["fst"];
  const _id_0 = _registered_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058put$1260$(_selected_0, _stream_0)), "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058registered$1260$(_stream_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058registered_checked$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058can_register$1260$(_stream_0)), _stream_0, _tick_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $ordinary$045scheduled$045reader$045consumer$058presence$(_value_0) {
  return {$: "Tuple", "fst": _value_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(($ordinary$045scheduled$045reader$045consumer$058presence$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($ordinary$045scheduled$045reader$045consumer$058presence$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($ordinary$045scheduled$045reader$045consumer$058presence$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($ordinary$045scheduled$045reader$045consumer$058presence$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($ordinary$045scheduled$045reader$045consumer$058put_values$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1261$(_value_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058invalid_reader$1260$(_declaration_0, _parameter_0, _context_0, _reader_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058invalid_parts$1260$(_declaration_0, _parameter_0, _reader_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(_context_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058run_validated$1260$(_reader_0, _parameter_0, _declaration_0, _args_0, _queryCursor_0, _context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared_context$1260$(_parameter_0, _declaration_0, _args_0, _reader_0, _queryCursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_before_attempt$1260$(_context_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((_x_0 === _id_0), _x_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_fn$1262$(_context_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_after_left$1262$(_ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058release_event$1260$(_context_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_release_validated$1260$(_context_0, _readerId_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_release_decided$1260$((_readerId_0 > 0), _context_0, _readerId_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_validated$1260$(_state_0, _tick_0, _facts_0, _id_0, _keys_0, _registered_0) {
  const __0 = _facts_0["namespace"];
  const __1 = _facts_0["id"];
  const __2 = _facts_0["name"];
  const _access_0 = _facts_0["access"];
  const _world_0 = _registered_0["fst"];
  const _isRegistered_0 = _registered_0["snd"];
  const _expected_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_access$1260$(($ordinary$045scheduled$045reader$045consumer$058relation_declarations$())));
  const _valid_0 = ($Bool$and$(_isRegistered_0, ($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058access_subset$(_expected_0, _access_0)), ($Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_keys_equal$1260$(_keys_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058keys$1260$(($ordinary$045scheduled$045reader$045consumer$058relation_declarations$()))))), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058has_reader$(_id_0))))))));
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationOwner", "facts": {$: "../../../../../../../../src/ecs/reader-parameter.RegistrationFacts", "namespace": __0, "id": __1, "name": __2, "access": _access_0}, "id": _id_0, "keys": _keys_0}, "snd": _valid_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058access_member$(_wanted_0, _access_0) {
  if (_access_0.$ === "Nil") {
    return false;
  } else {
    const _name_0 = _access_0["head"];
    const _rest_0 = _access_0["tail"];
    const _x_0 = ($String$eq$(_wanted_0, _name_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058access_member$(_wanted_0, _rest_0));
    return (_x_0 || _x_1);
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_after_first$1260$(_facts_0, _initializedA_0) {
  const _contextAfterA_0 = _initializedA_0["fst"];
  const _t_0 = _initializedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _paramA_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_finish$1260$(_ownerA_0, _paramA_0, ($ordinary$045scheduled$045reader$045consumer$058r_initialize$(_contextAfterA_0, _facts_0)));
}

function $ordinary$045scheduled$045reader$045consumer$058m_initialize$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058initialize_removal$1260$(_context_0, _facts_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058registered_checked$1260$(_available_0, _stream_0, _tick_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _stream_0, "snd": 0};
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058increment_reader$1260$(_stream_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058can_register$1260$(_stream_0) {
  const _nextReader_0 = _stream_0["nextReader"];
  return (_nextReader_0 < 4294967295);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1261$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../../../../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../../../../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058invalid_parts$1260$(_declaration_0, _parameter_0, _reader_0, _parts_0) {
  const _world_0 = _parts_0["fst"];
  const _meta_0 = _parts_0["snd"];
  return {$: "../../../../../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Envelope", "meta": _meta_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0, "completion": {$: "../../../../../../../../src/ecs/ordinary-reader-system.CallbackInvalidReader"}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared_context$1260$(_parameter_0, _declaration_0, _args_0, _reader_0, _queryCursor_0, _context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared_context_parts$1260$(_parameter_0, _declaration_0, _args_0, _reader_0, _queryCursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(_context_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_before_attempt$1260$(_context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058before_attempt$1260$(_context_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_after_left$1262$(_ownerB_0, _context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_fn$1263$(_context_0, _ownerB_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_release_decided$1260$(_allowed_0, _context_0, _readerId_0) {
  if (!_allowed_0) {
    return _context_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_release_ready$1260$(_readerId_0, _context_0);
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_keys_equal$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const _a_0 = _left_0["head"];
    const _restA_0 = _left_0["tail"];
    if (_right_0.$ === "Nil") {
      return false;
    } else {
      const _b_0 = _right_0["head"];
      const _restB_0 = _right_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_a_0, _b_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_keys_equal$1260$(_restA_0, _restB_0)));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058keys$1260$(_declarations_0) {
  if (_declarations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _declaration_0 = _declarations_0["head"];
    const _rest_0 = _declarations_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058key$1260$(_declaration_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058keys$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058has_reader$(_id_0) {
  if (_id_0.$ === "None") {
    return false;
  } else {
    return true;
  }
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058initialize_pair_finish$1260$(_ownerA_0, _paramA_0, _initializedB_0) {
  const _contextB_0 = _initializedB_0["fst"];
  const _t_0 = _initializedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _paramB_0 = _t_0["snd"];
  return {$: "Tuple", "fst": _contextB_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": ($ordinary$045scheduled$045reader$045consumer$058pair_mr$(_paramA_0, _paramB_0))}};
}

function $ordinary$045scheduled$045reader$045consumer$058r_initialize$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058initialize_relation$1260$(_context_0, _facts_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058initialize_removal$1260$(_context_0, _facts_0) {
  const _namespace_0 = _facts_0["namespace"];
  const _id_0 = _facts_0["id"];
  const __0 = _facts_0["name"];
  const __1 = _facts_0["access"];
  return {$: "Tuple", "fst": _context_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RemovalOwner", "facts": {$: "../../../../../../../../src/ecs/reader-parameter.RegistrationFacts", "namespace": _namespace_0, "id": _id_0, "name": __0, "access": __1}, "reader": {$: "../../../../../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045declaration$058key$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_identity$1260$(($ordinary$045scheduled$045reader$045consumer$058removal_selection$()))))), "cursor": 0}}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_param$1260$())}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058increment_reader$1260$(_stream_0, _tick_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": _positions_0, "nextReader": ((_nextReader_0 + 1) >>> 0), "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0}, "snd": _nextReader_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared_context_parts$1260$(_parameter_0, _declaration_0, _args_0, _reader_0, _queryCursor_0, _parts_0) {
  const _world_0 = _parts_0["fst"];
  const _meta_0 = _parts_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared_context_clock$1260$(_parameter_0, _declaration_0, _args_0, _reader_0, _queryCursor_0, _meta_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058before_attempt$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _state_0 = _runtime_0["family"];
  const _tick_0 = _runtime_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058before_clocked$1260$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_fn$1263$(_context_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_after_left$1263$(_ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058release_removal$1260$(_context_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_release_ready$1260$(_readerId_0, _context_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_release_stream$1260$(_readerId_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058take$1260$(_state_0)))), "tick": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058key$1260$(_declaration_0) {
  const _t_0 = _declaration_0["descriptor"];
  const _id_0 = _t_0["key"];
  return {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.DeclaredKey", "id": _id_0};
}

function $ordinary$045scheduled$045reader$045consumer$058pair_mr$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair$1260$(_left_0, _right_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058initialize_relation$1260$(_context_0, _facts_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_initialized$1260$(_facts_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058reserve_failure_reader$1260$(_context_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_identity$1260$(_selection_0) {
  const _identity_0 = _selection_0["identity"];
  return _identity_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058present$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058present$1260$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058present$1260$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared_context_clock$1260$(_parameter_0, _declaration_0, _args_0, _reader_0, _queryCursor_0, _meta_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _attemptCursor_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared$1260$(_parameter_0, _declaration_0, _attemptCursor_0, _args_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058prepare$1260$(_parameter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), _queryCursor_0, _reader_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058before_clocked$1260$(_state_0, _tick_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058before_state$1260$(_state_0, _tick_0, _world_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_release_after_left$1263$(_ownerB_0, _context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058release_relation$1260$(_context_0, _ownerB_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058release_removal$1260$(_context_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_release_context_checked$1260$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_world_retained$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_release_stream$1260$(_id_0, _tick_0, _selected_0) {
  const _state_0 = _selected_0["fst"];
  const _t_0 = _selected_0["snd"];
  const _domain_0 = _t_0["domain"];
  const _batches_0 = _t_0["batches"];
  const _positions_0 = _t_0["positions"];
  const _nextReader_0 = _t_0["nextReader"];
  const _frameStart_0 = _t_0["frameStart"];
  const _boundary_0 = _t_0["boundary"];
  const _capacity_0 = _t_0["capacity"];
  const _dropped_0 = _t_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058put$1260$(_state_0, {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, true)), "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_initialized$1260$(_facts_0, _reserved_0) {
  const _context_0 = _reserved_0["fst"];
  const _id_0 = _reserved_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_initialized_id$1260$(_context_0, _facts_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058reserve_failure_reader$1260$(_runtime_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058reserve_failure_reader_detached$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058failure_runtime$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058present$1260$(_owner_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": true};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058present$1260$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058present$1260$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Prepared", "state": {$: "../../../../../../../../src/ecs/column.Owned", "state": {$: "../../../../../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058present$1260$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058present$1260$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared$1260$(_parameter_0, _declaration_0, _cursor_0, _args_0, _observed_0) {
  const _context_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _reader_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _view_0 = _t_1["fst"];
  const _delta_0 = _t_1["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared_split$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _args_0, _view_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(_context_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058prepare$1260$(_param_0, _world_0, _cursor_0, _owner_0) {
  return $ordinary$045scheduled$045reader$045consumer$058prepare_all$(_world_0, _cursor_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058before_state$1260$(_state_0, _tick_0, _world_0, _clock_0) {
  const _typed_0 = _state_0["typed"];
  const _t_0 = _state_0["failures"];
  const _domains_0 = _t_0["domains"];
  const _positions_0 = _t_0["positions"];
  const _failureTick_0 = _t_0["tick"];
  const _start_0 = _t_0["frameStart"];
  const _boundary_0 = _t_0["boundary"];
  const _capacity_0 = _t_0["capacity"];
  const _nextReader_0 = _t_0["nextReader"];
  const _x_0 = (_failureTick_0 > _clock_0 ? _failureTick_0 : _clock_0);
  const _x_1 = (_tick_0 > _x_0 ? _tick_0 : _x_0);
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058attempt_ingested$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058ingest$1260$((1 > _x_1 ? 1 : _x_1), {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _failureTick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": _tick_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058release_relation$1260$(_context_0, _owner_0) {
  const _id_0 = _owner_0["id"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_release_selected$1260$(_context_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_release_context_checked$1260$(_state_0, _tick_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _retained_0 = _checked_0["snd"];
  return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_release_world_checked$1260$(_retained_0, _world_0)), "family": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_release_state_checked$1260$(_retained_0, _state_0)), "tick": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_world_retained$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_registration_remains$(_registrations_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_initialized_id$1260$(_context_0, _facts_0, _id_0) {
  return {$: "Tuple", "fst": _context_0, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationOwner", "facts": _facts_0, "id": _id_0, "keys": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045reader$058keys$1260$(($ordinary$045scheduled$045reader$045consumer$058relation_declarations$())))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_param$1260$())}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058reserve_failure_reader_detached$1260$(_detached_0) {
  const _runtime_0 = _detached_0["fst"];
  const _held_0 = _detached_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058reserved_failure_reader$1260$(_held_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader$1260$(_runtime_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058prepared_split$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _args_0, _view_0, _parts_0) {
  const _world_0 = _parts_0["fst"];
  const _meta_0 = _parts_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058invoke_body$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _meta_0, _args_0, _world_0, _view_0);
}

function $ordinary$045scheduled$045reader$045consumer$058prepare_all$(_context_0, _cursor_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_fn$1260$(_context_0, _cursor_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058attempt_ingested$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _state_0 = _runtime_0["family"];
  const _tick_0 = _runtime_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058attempt_clocked$1260$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058ingest$1260$(_tick_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _state_0 = _runtime_0["family"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058ingested_typed$1260$(_tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058synchronize$1260$(_world_0, _state_0, _tick_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_release_selected$1260$(_context_0, _id_0) {
  const _world_0 = _context_0["world"];
  const _t_0 = _context_0["family"];
  const _typed_0 = _t_0["typed"];
  const _t_1 = _t_0["failures"];
  const _domains_0 = _t_1["domains"];
  const _positions_0 = _t_1["positions"];
  const _tick_0 = _t_1["tick"];
  const _frameStart_0 = _t_1["frameStart"];
  const _boundary_0 = _t_1["boundary"];
  const _capacity_0 = _t_1["capacity"];
  const _nextReader_0 = _t_1["nextReader"];
  const _routeTick_0 = _context_0["tick"];
  if (_id_0.$ === "None") {
    return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": _routeTick_0};
  } else {
    const _readerId_0 = _id_0["value"];
    return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058release$1260$(_domains_0, _readerId_0)), "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _readerId_0, _tick_0, true)), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": _routeTick_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_release_world_checked$1260$(_retained_0, _world_0) {
  if (_retained_0) {
    return _world_0;
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_events_kept$1260$(_events_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_release_state_checked$1260$(_retained_0, _state_0) {
  if (_retained_0) {
    return _state_0;
  } else {
    const _t_0 = _state_0["typed"];
    const _family_0 = _t_0["family"];
    const _owners_0 = _t_0["owners"];
    const _journal_0 = _t_0["journal"];
    const _frameStart_0 = _t_0["frameStart"];
    const _failures_0 = _state_0["failures"];
    return {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": {$: "../../../../../../../../src/ecs/event-family-runtime.State", "family": _family_0, "owners": _owners_0, "journal": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_batches_kept$1260$(_journal_0)), "frameStart": _frameStart_0}, "failures": _failures_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_registration_remains$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _entries_0["head"];
    const _access_0 = _t_0["access"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_access_member$(_access_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_registration_remains$(_rest_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058reserved_failure_reader$1260$(_held_0, _result_0) {
  const _runtime_0 = _result_0["fst"];
  const _id_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058failure_returned$1260$(_held_0, _runtime_0)), "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader_checked$1260$((_nextReader_0 < 4294967295), {$: "../../../../../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058invoke_body$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _meta_0, _args_0, _world_0, _view_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058callback_returned$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _meta_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke_owned$1260$({$: "Tuple", "fst": _view_0, "snd": _args_0}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_fn$1260$(_world_0, _cursor_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_after_left$1260$(_cursor_0, _ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058prepare_context$1260$(_world_0, _cursor_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058attempt_clocked$1260$(_state_0, _tick_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": nat_chk(_tick_0 + 1)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058ingested_typed$1260$(_tick_0, _returned_0) {
  const _world_0 = _returned_0["fst"];
  const _t_0 = _returned_0["snd"];
  const _typed_0 = _t_0["typed"];
  const _t_1 = _t_0["failures"];
  const _domains_0 = _t_1["domains"];
  const _positions_0 = _t_1["positions"];
  const _start_0 = _t_1["frameStart"];
  const _boundary_0 = _t_1["boundary"];
  const _capacity_0 = _t_1["capacity"];
  const _nextReader_0 = _t_1["nextReader"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058ingested_failures$1260$(_typed_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _nextReader_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _tick_0, _domains_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058synchronize$1260$(_world_0, _state_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058synchronized$1260$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058release$1260$(_domains_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058remove$(_ids_0, _id_0))}, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058release$1260$(_rest_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_events_kept$1260$(_events_0) {
  if (_events_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _event_0 = _events_0["head"];
    const _rest_0 = _events_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_event_kept$1260$(_event_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_events_kept$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_batches_kept$1260$(_batches_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _batch_0 = _batches_0["head"];
    const _rest_0 = _batches_0["tail"];
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_batch_kept$1260$(_batch_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_batches_kept$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_access_member$(_access_0) {
  if (_access_0.$ === "Nil") {
    return false;
  } else {
    const _first_0 = _access_0["head"];
    const _rest_0 = _access_0["tail"];
    const _x_0 = ($String$eq$("removal", _first_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_access_member$(_rest_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader_checked$1260$(_available_0, _runtime_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _runtime_0, "snd": {$: "None"}};
  } else {
    const _world_0 = _runtime_0["world"];
    const _domains_0 = _runtime_0["domains"];
    const _positions_0 = _runtime_0["positions"];
    const _tick_0 = _runtime_0["tick"];
    const _frameStart_0 = _runtime_0["frameStart"];
    const _boundary_0 = _runtime_0["boundary"];
    const _capacity_0 = _runtime_0["capacity"];
    const _nextReader_0 = _runtime_0["nextReader"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": ((_nextReader_0 + 1) >>> 0)}, "snd": {$: "Some", "value": _nextReader_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058callback_returned$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _meta_0, _observed_0) {
  const _tx_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _outcome_0 = _t_0["fst"];
  const _output_0 = _t_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058transaction_returned$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _meta_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047capabilities$058invoke_owned$1260$(_args_0, _ctx_0) {
  return $ordinary$045scheduled$045reader$045consumer$058callback$1260$(_args_0, _ctx_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_after_left$1260$(_cursor_0, _ownerB_0, _preparedA_0) {
  const _world_0 = _preparedA_0["fst"];
  const _t_0 = _preparedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _viewA_0 = _t_1["fst"];
  const _deltaA_0 = _t_1["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_join$1260$(_ownerA_0, _viewA_0, _deltaA_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_fn$1261$(_world_0, _cursor_0, _ownerB_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058prepare_context$1260$(_context_0, _cursor_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058with_query_rows$1260$(_state_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058rows_observed$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1260$({$: "../../../../../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0})))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058ingested_failures$1260$(_typed_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _nextReader_0, _returned_0) {
  const _world_0 = _returned_0["fst"];
  const _domains_0 = _returned_0["snd"];
  return {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": _tick_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _tick_0, _domains_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058synchronized$1260$(_state_0, _tick_0, _observed_0) {
  const _t_0 = _state_0["typed"];
  const _family_0 = _t_0["family"];
  const _owners_0 = _t_0["owners"];
  const _journal_0 = _t_0["journal"];
  const _frameStart_0 = _t_0["frameStart"];
  const _failures_0 = _state_0["failures"];
  const _world_0 = _observed_0["fst"];
  const _records_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058originals$1260$(_records_0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_journal_0))));
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1261$(_published_0));
  return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": {$: "../../../../../../../../src/ecs/event-family-runtime.State", "family": ($ordinary$045scheduled$045reader$045consumer$058sync_events$(_family_0, _tick_0, _published_0)), "owners": _owners_0, "journal": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1261$((0 < _x_0), _journal_0, _tick_0, _published_0)), "frameStart": _frameStart_0}, "failures": _failures_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058remove$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058keep$((_id_0 === _wanted_0), _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058remove$(_rest_0, _wanted_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_event_kept$1260$(_event_0, _rest_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_event_selected$1260$(($ordinary$045scheduled$045reader$045consumer$058select_removal$(_event_0)), _event_0, _rest_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_batch_kept$1260$(_batch_0) {
  const _tick_0 = _batch_0["tick"];
  const _values_0 = _batch_0["values"];
  return {$: "../../../../../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publications_kept$1260$(_values_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058transaction_returned$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _meta_0, _output_0, _finished_0) {
  const _world_0 = _finished_0["world"];
  const _outcome_0 = _finished_0["outcome"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058inner_outcome$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _meta_0, _output_0, _outcome_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $ordinary$045scheduled$045reader$045consumer$058callback$1260$(_input_0, _owner_0) {
  const _view_0 = _input_0["fst"];
  const _fail_0 = _input_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Tuple", "fst": ($ordinary$045scheduled$045reader$045consumer$058callback_outcome$(_fail_0)), "snd": _view_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_join$1260$(_ownerA_0, _viewA_0, _deltaA_0, _preparedB_0) {
  const _world_0 = _preparedB_0["fst"];
  const _t_0 = _preparedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _viewB_0 = _t_1["fst"];
  const _deltaB_0 = _t_1["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/reader-parameter.ViewPair", "left": _viewA_0, "right": _viewB_0}, "snd": {$: "Tuple", "fst": _deltaA_0, "snd": _deltaB_0}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_fn$1261$(_world_0, _cursor_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_after_left$1261$(_cursor_0, _ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058prepare_event$1260$(_world_0, _cursor_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058with_query_rows$1260$(_state_0, _tick_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  const _owner_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _rows_0 = _t_1["fst"];
  const _delta_0 = _t_1["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "snd": {$: "Tuple", "fst": _owner_0, "snd": {$: "Tuple", "fst": _rows_0, "snd": _delta_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058rows_observed$1260$(_observed_0) {
  const _t_0 = _observed_0["fst"];
  const _world_0 = _t_0["world"];
  const _rows_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Unit"}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-query-parameter.Rows", "rows": _rows_0}, "snd": {$: "Unit"}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058each_composed$1260$(_owner_0) {
  return run_tail(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058inspect_query$1260$()))), _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1260$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1260$(_world_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1260$(_items_0, {$: "../../../../../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $List$drop$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _n_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        if (_n_0 === 0) {
          return {$: "Con", "head": _h_0, "tail": _t_0};
        } else {
          const _p_0 = (_n_0 - 1);
          $0 = _t_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058originals$1260$($0) {
  for (;;) {
    {
      const _records_0 = $0;
      if (_records_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _records_0["head"];
        if (_t_0.$ === "../../../../../../../../src/ecs/relation-commands.Original") {
          const _event_0 = _t_0["event"];
          const _rest_0 = _records_0["tail"];
          return {$: "Con", "head": _event_0, "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058originals$1260$(_rest_0))};
        } else if (_t_0.$ === "../../../../../../../../src/ecs/relation-commands.RelationFailed") {
          const _rest_1 = _records_0["tail"];
          $0 = _rest_1;
          continue;
        } else if (_t_0.$ === "../../../../../../../../src/ecs/relation-commands.ComponentRemoved") {
          const _rest_2 = _records_0["tail"];
          $0 = _rest_2;
          continue;
        } else {
          const _rest_3 = _records_0["tail"];
          $0 = _rest_3;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1260$(_batches_0, 0);
}

function $ordinary$045scheduled$045reader$045consumer$058sync_events$(_family_0, _tick_0, _values_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058append$1260$(_family_0, _tick_0, ($ordinary$045scheduled$045reader$045consumer$058original_values$(_values_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1261$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1262$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058keep$(_found_0, _id_0, _rest_0) {
  if (_found_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_event_selected$1260$(_selected_0, _event_0, _rest_0) {
  if (_selected_0.$ === "None") {
    return {$: "Con", "head": _event_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $ordinary$045scheduled$045reader$045consumer$058select_removal$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/relation-commands.Original") {
    const _value_1 = _value_0["event"];
    return $ordinary$045scheduled$045reader$045consumer$058select_removed$(_value_1);
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publications_kept$1260$(_publications_0) {
  if (_publications_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _publication_0 = _publications_0["head"];
    const _rest_0 = _publications_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publication_retain$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publication_kept$1260$(_publication_0)), _publication_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publications_kept$1260$(_rest_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058inner_outcome$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _meta_0, _output_0, _outcome_0, _world_0) {
  if (_outcome_0.$ === "../../../../../../../../src/ecs/transaction.Success") {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058commit_success$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _output_0, _world_0, _meta_0);
  } else {
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058callback_failure$1260$(_reader_0, _parameter_0, _declaration_0, _error_0, _output_0, _world_0, _meta_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $ordinary$045scheduled$045reader$045consumer$058callback_outcome$(_fail_0) {
  if (_fail_0) {
    return {$: "../../../../../../../../src/ecs/transaction.Failure", "error": 7};
  } else {
    return {$: "../../../../../../../../src/ecs/transaction.Success"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_after_left$1261$(_cursor_0, _ownerB_0, _preparedA_0) {
  const _world_0 = _preparedA_0["fst"];
  const _t_0 = _preparedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _viewA_0 = _t_1["fst"];
  const _deltaA_0 = _t_1["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_join$1261$(_ownerA_0, _viewA_0, _deltaA_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_fn$1262$(_world_0, _cursor_0, _ownerB_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058prepare_event$1260$(_context_0, _cursor_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  const _facts_0 = _owner_0["facts"];
  const _t_0 = _owner_0["reader"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _registryId_0 = _t_0["registryId"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_prepared$1260$(_world_0, _tick_0, {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.EventOwner", "facts": _facts_0, "reader": {$: "../../../../../../../../src/ecs/event-family-routing.Reader", "namespace": _namespace_0, "id": _id_0, "registryId": _registryId_0}}, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_read_selected$1260$(_state_0, _id_0, _tick_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_each_field$1260$(_value_0) {
  const _each_composed_0 = _value_0["each_composed"];
  return _each_composed_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058inspect_query$1260$() {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed$1260$();
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1260$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1260$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1260$(($ordinary$045scheduled$045reader$045consumer$058classify$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058append$1260$(_stream_0, _tick_0, _values_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(_values_0));
  return {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1260$((0 < _x_0), _batches_0, _tick_0, _values_0)), "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $ordinary$045scheduled$045reader$045consumer$058original_values$($0) {
  for (;;) {
    {
      const _values_0 = $0;
      if (_values_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _t_0 = _values_0["head"];
        if (_t_0.$ === "ordinary-scheduled-reader-consumer.Value") {
          const _value_0 = _t_0["value"];
          const _rest_0 = _values_0["tail"];
          return {$: "Con", "head": {$: "../../../../../../../../src/ecs/relation-commands.Original", "event": {$: "ordinary-scheduled-reader-consumer.Value", "value": _value_0}}, "tail": ($ordinary$045scheduled$045reader$045consumer$058original_values$(_rest_0))};
        } else {
          const _rest_1 = _values_0["tail"];
          $0 = _rest_1;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1262$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1262$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $ordinary$045scheduled$045reader$045consumer$058select_removed$(_value_0) {
  if (_value_0.$ === "ordinary-scheduled-reader-consumer.Removed") {
    const _record_0 = _value_0["record"];
    return {$: "Some", "value": _record_0};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publication_retain$1260$(_keep_0, _publication_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _publication_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publication_kept$1260$(_publication_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publication_selected_value$1260$(($ordinary$045scheduled$045reader$045consumer$058select_removal$({$: "../../../../../../../../src/ecs/relation-commands.Original", "event": _publication_0})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058commit_success$1260$(_reader_0, _parameter_0, _declaration_0, _delta_0, _cursor_0, _output_0, _world_0, _meta_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058success_context$1260$(_parameter_0, _declaration_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058commit$1260$(_parameter_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058join$1260$(_world_0, _meta_0)), _reader_0, _delta_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058callback_failure$1260$(_reader_0, _parameter_0, _declaration_0, _error_0, _output_0, _world_0, _meta_0) {
  return {$: "../../../../../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Envelope", "meta": _meta_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0, "completion": {$: "../../../../../../../../src/ecs/ordinary-reader-system.CallbackFailed", "error": _error_0, "output": _output_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_join$1261$(_ownerA_0, _viewA_0, _deltaA_0, _preparedB_0) {
  const _world_0 = _preparedB_0["fst"];
  const _t_0 = _preparedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _viewB_0 = _t_1["fst"];
  const _deltaB_0 = _t_1["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/reader-parameter.ViewPair", "left": _viewA_0, "right": _viewB_0}, "snd": {$: "Tuple", "fst": _deltaA_0, "snd": _deltaB_0}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_fn$1262$(_world_0, _cursor_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_after_left$1262$(_cursor_0, _ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058prepare_event$1260$(_world_0, _cursor_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_prepared$1260$(_world_0, _tick_0, _owner_0, _selected_0) {
  const _facts_0 = _owner_0["facts"];
  const _t_0 = _owner_0["reader"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _registryId_0 = _t_0["registryId"];
  const _state_0 = _selected_0["fst"];
  const _t_1 = _selected_0["snd"];
  const _stream_0 = _t_1["fst"];
  const _reading_0 = _t_1["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058put$1260$(_state_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058completed$1260$(_stream_0, _id_0, (_tick_0 < 1 ? 0 : _tick_0 - 1), false)))), "tick": _tick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.EventOwner", "facts": _facts_0, "reader": {$: "../../../../../../../../src/ecs/event-family-routing.Reader", "namespace": _namespace_0, "id": _id_0, "registryId": _registryId_0}}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.EventView", "reading": _reading_0}, "snd": (_tick_0 < 1 ? 0 : _tick_0 - 1)}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_read_selected$1260$(_state_0, _id_0, _tick_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_read_selected_from$1260$(_id_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058take$1260$(_state_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058grant_composed$1260$() {
  return {$: "../../../../../../../../src/ecs/inspector-query.ComposedReadQuery", "each_composed": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_enumerate$1260$(_x_0);
}), "get_composed": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1260$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../../../../../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../../../../../../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_batches_0, _wanted_0, _item_0))};
  }
}

function $ordinary$045scheduled$045reader$045consumer$058classify$(_value_0) {
  if (_value_0.$ === "../../../../../../../../src/ecs/relation-commands.RelationFailed") {
    const _t_0 = _value_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    return {$: "Some", "value": {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.DeclaredKey", "id": _key_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1260$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_batches_0, {$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, 0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1262$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_publication_selected_value$1260$(_selected_0) {
  if (_selected_0.$ === "None") {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058success_context$1260$(_parameter_0, _declaration_0, _output_0, _committed_0) {
  const _context_0 = _committed_0["fst"];
  const _reader_0 = _committed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058success_succeeded$1260$(_reader_0, _parameter_0, _declaration_0, _output_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058split$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_after_success$1260$(_context_0)))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058commit$1260$(_param_0, _world_0, _owner_0, _delta_0, _cursor_0) {
  return $ordinary$045scheduled$045reader$045consumer$058commit_all$(_world_0, _owner_0, _delta_0, _cursor_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1262$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_after_left$1262$(_cursor_0, _ownerB_0, _preparedA_0) {
  const _world_0 = _preparedA_0["fst"];
  const _t_0 = _preparedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _viewA_0 = _t_1["fst"];
  const _deltaA_0 = _t_1["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_join$1262$(_ownerA_0, _viewA_0, _deltaA_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_fn$1263$(_world_0, _cursor_0, _ownerB_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058completed$1260$(_stream_0, _id_0, _tick_0, _success_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  return {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058completed_positions$(_success_0, _positions_0, _id_0, _tick_0)), "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_read_selected_from$1260$(_id_0, _tick_0, _selected_0) {
  const _held_0 = _selected_0["fst"];
  const _stream_0 = _selected_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_reading_loaded$1260$(_held_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058reading$1260$(_stream_0, _id_0, _tick_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_enumerate$1260$(_owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scanned$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_world$1260$())))(_owner_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_target$1260$(_owner_0, _target_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058success_succeeded$1260$(_reader_0, _parameter_0, _declaration_0, _output_0, _parts_0) {
  const _world_0 = _parts_0["fst"];
  const _meta_0 = _parts_0["snd"];
  return {$: "../../../../../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "../../../../../../../../src/ecs/ordinary-reader-system.Envelope", "meta": _meta_0, "reader": _reader_0, "parameter": _parameter_0, "declaration": _declaration_0, "completion": {$: "../../../../../../../../src/ecs/ordinary-reader-system.CallbackCompleted", "output": _output_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045system$058mixed_after_success$1260$(_context_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058after_success$1260$(_context_0);
}

function $ordinary$045scheduled$045reader$045consumer$058commit_all$(_context_0, _owner_0, _delta_0, _cursor_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_fn$1260$(_context_0, _owner_0, _delta_0, _cursor_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1262$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1262$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_join$1262$(_ownerA_0, _viewA_0, _deltaA_0, _preparedB_0) {
  const _world_0 = _preparedB_0["fst"];
  const _t_0 = _preparedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _viewB_0 = _t_1["fst"];
  const _deltaB_0 = _t_1["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/reader-parameter.ViewPair", "left": _viewA_0, "right": _viewB_0}, "snd": {$: "Tuple", "fst": _deltaA_0, "snd": _deltaB_0}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_fn$1263$(_world_0, _cursor_0, _owners_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_after_left$1263$(_cursor_0, _ownerB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058prepare_removal$1260$(_world_0, _cursor_0, _ownerA_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058completed_positions$(_success_0, _positions_0, _id_0, _tick_0) {
  if (!_success_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, (_tick_0 < 1 ? 0 : _tick_0 - 1));
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _id_0, _tick_0, false);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_reading_loaded$1260$(_selected_0, _viewed_0) {
  const _stream_0 = _viewed_0["fst"];
  const _reading_0 = _viewed_0["snd"];
  return {$: "Tuple", "fst": _selected_0, "snd": {$: "Tuple", "fst": _stream_0, "snd": _reading_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058reading$1260$(_stream_0, _id_0, _tick_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058read_position$1260$({$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0}, _id_0, _tick_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scanned$1260$(_observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _targets_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$(run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scan$1260$(_targets_0, _owner_0, {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_handles_field$1260$(_value_0) {
  const _handles_0 = _value_0["handles"];
  return _handles_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_world$1260$() {
  return {$: "../../../../../../../../src/ecs/inspector-query.WorldRead", "handles": run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_handles$1260$(_x_0);
}), "valid": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_valid$1260$(_x_1, _x_2);
});
})};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_target$1260$(_owner_0, _target_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_valid$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_world$1260$())))(_owner_0)(_target_0));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$(_items_0, 0));
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1260$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$(_items_0, 0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$() {
  return {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1260$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1260$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058after_success$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _state_0 = _runtime_0["family"];
  const _tick_0 = _runtime_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058ingest$1260$(_tick_0, {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_fn$1260$(_world_0, _owners_0, _deltas_0, _cursor_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  const _deltaA_0 = _deltas_0["fst"];
  const _deltaB_0 = _deltas_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_after_left$1260$(_cursor_0, _ownerB_0, _deltaB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058commit_context$1260$(_world_0, _ownerA_0, _deltaA_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1262$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_after_left$1263$(_cursor_0, _ownerB_0, _preparedA_0) {
  const _world_0 = _preparedA_0["fst"];
  const _t_0 = _preparedA_0["snd"];
  const _ownerA_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _viewA_0 = _t_1["fst"];
  const _deltaA_0 = _t_1["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_join$1263$(_ownerA_0, _viewA_0, _deltaA_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058prepare_relation$1260$(_world_0, _cursor_0, _ownerB_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058prepare_removal$1260$(_context_0, _cursor_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_prepared$1260$(_state_0, _tick_0, _owner_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058read_position$1260$(_stream_0, _id_0, _tick_0, _position_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  if (_position_0.$ === "Some") {
    const _position_1 = _position_0["value"];
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0))};
  } else {
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../../../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_unwrap_scan$1260$($0) {
  for (;;) {
    {
      const _result_0 = $0;
      if (_result_0.$ === "../../../../../../../../src/ecs/inspector-query.ScanResult") {
        const _owner_0 = _result_0["owner"];
        const _rows_0 = _result_0["rows"];
        return {$: "Tuple", "fst": _owner_0, "snd": _rows_0};
      } else {
        const _next_0 = _result_0["next"];
        $0 = _next_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scan$1260$(_targets_0, _owner_0, _rows_0) {
  if (_targets_0.$ === "Nil") {
    return {$: "../../../../../../../../src/ecs/inspector-query.ScanResult", "owner": _owner_0, "rows": ($List$reverse$(_rows_0))};
  } else {
    const _target_0 = _targets_0["head"];
    const _rest_0 = _targets_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scan_matched$1260$(_target_0, _rows_0, run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scan$1260$(_rest_0, _x_0, _x_1);
});
}), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(($ordinary$045scheduled$045reader$045consumer$058query_declaration$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_handles$1260$(_frame_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_handles_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_valid$1260$(_frame_0, _target_0) {
  const _world_0 = _frame_0["world"];
  const _cursor_0 = _frame_0["cursor"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_valid_joined$1260$(_cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1262$(_world_0, _target_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_valid$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_matched$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(($ordinary$045scheduled$045reader$045consumer$058query_declaration$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_valid_field$1260$(_value_0) {
  const _valid_0 = _value_0["valid"];
  return _valid_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1260$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_after_left$1260$(_cursor_0, _ownerB_0, _deltaB_0, _committedA_0) {
  const _world_0 = _committedA_0["fst"];
  const _ownerA_0 = _committedA_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_join$1260$(_ownerA_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_fn$1261$(_world_0, _ownerB_0, _deltaB_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045query$045parameter$058commit_context$1260$(_context_0, _owner_0, _delta_0, _cursor_0) {
  return {$: "Tuple", "fst": _context_0, "snd": _owner_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_prepare_join$1263$(_ownerA_0, _viewA_0, _deltaA_0, _preparedB_0) {
  const _world_0 = _preparedB_0["fst"];
  const _t_0 = _preparedB_0["snd"];
  const _ownerB_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _viewB_0 = _t_1["fst"];
  const _deltaB_0 = _t_1["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/reader-parameter.ViewPair", "left": _viewA_0, "right": _viewB_0}, "snd": {$: "Tuple", "fst": _deltaA_0, "snd": _deltaB_0}}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058prepare_relation$1260$(_context_0, _cursor_0, _owner_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_prepared$1260$(_context_0, _owner_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058removal_prepared$1260$(_state_0, _tick_0, _owner_0, _observed_0) {
  const _facts_0 = _owner_0["facts"];
  const _t_0 = _owner_0["reader"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _cursor_0 = _t_0["cursor"];
  const _world_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  const _records_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1260$(_values_0, _cursor_0));
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": _state_0, "tick": _tick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RemovalOwner", "facts": _facts_0, "reader": {$: "../../../../../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RemovalView", "records": _records_0}, "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1260$(_values_0))}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../../../../../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scan_matched$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return run_tail(_continue_0(_owner_0), _rows_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(($ordinary$045scheduled$045reader$045consumer$058query_declaration$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058matches_field$1261$(_value_0) {
  const _matches_0 = _value_0["matches"];
  return _matches_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(_declaration_0) {
  const _inspection_0 = _declaration_0["inspection"];
  return _inspection_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_handles_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058handles$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1260$(_highWater_0, _namespace_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045world$058inspect_valid_joined$1260$(_cursor_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/inspector.Frame", "world": _world_0, "cursor": _cursor_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1262$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1262$(_handle_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1262$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_missing$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../src/ecs/inspector-query.MissingEntity", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_matched$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0);
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045query$045observable$058inspection$1260$(($ordinary$045scheduled$045reader$045consumer$058query_declaration$())))))(_owner_0)(_target_0));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_join$1260$(_ownerA_0, _committedB_0) {
  const _world_0 = _committedB_0["fst"];
  const _ownerB_0 = _committedB_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_fn$1261$(_world_0, _owners_0, _deltas_0, _cursor_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  const _deltaA_0 = _deltas_0["fst"];
  const _deltaB_0 = _deltas_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_after_left$1261$(_cursor_0, _ownerB_0, _deltaB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058commit_event$1260$(_world_0, _ownerA_0, _deltaA_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_prepared$1260$(_context_0, _owner_0) {
  const _world_0 = _context_0["world"];
  const _t_0 = _context_0["family"];
  const _typed_0 = _t_0["typed"];
  const _t_1 = _t_0["failures"];
  const _domains_0 = _t_1["domains"];
  const _positions_0 = _t_1["positions"];
  const _tick_0 = _t_1["tick"];
  const _frameStart_0 = _t_1["frameStart"];
  const _boundary_0 = _t_1["boundary"];
  const _capacity_0 = _t_1["capacity"];
  const _nextReader_0 = _t_1["nextReader"];
  const _routeTick_0 = _context_0["tick"];
  const _facts_0 = _owner_0["facts"];
  const _t_2 = _owner_0["id"];
  if (_t_2.$ === "None") {
    const _keys_0 = _owner_0["keys"];
    const _readThrough_0 = _tick_0;
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": _routeTick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationOwner", "facts": _facts_0, "id": {$: "None"}, "keys": _keys_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationView", "readings": {$: "Nil"}}, "snd": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationDelta", "id": {$: "None"}, "readThrough": _readThrough_0}}}};
  } else {
    const _readerId_0 = _t_2["value"];
    const _keys_1 = _owner_0["keys"];
    const _position_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058position_or$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _readerId_0)), _readerId_0, _tick_0));
    const _readings_0 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_keys_1, _domains_0, _position_0));
    const _readThrough_1 = _tick_0;
    return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$(_keys_1, _domains_0, _readerId_0)), "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, _tick_0)), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": _routeTick_0}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationOwner", "facts": _facts_0, "id": {$: "Some", "value": _readerId_0}, "keys": _keys_1}, "snd": {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationView", "readings": _readings_0}, "snd": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationDelta", "id": {$: "Some", "value": _readerId_0}, "readThrough": _readThrough_1}}}};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1260$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _cursor_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const __0 = _xs_0["head"];
        const _rest_0 = _xs_0["tail"];
        if (_cursor_0 === 0) {
          return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047removals$058include$1260$(($ordinary$045scheduled$045reader$045consumer$058select_removal$(__0)), ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1260$(_rest_0, 0)));
        } else {
          const _p_0 = (_cursor_0 - 1);
          $0 = _rest_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _xs_0["tail"];
    return nat_chk(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1260$(_rest_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_scan_projected$1260$(_target_0, _rows_0, _continue_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return run_tail(_continue_0(_owner_0), {$: "Con", "head": {$: "../../../../../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}, "tail": _rows_0});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$045projection$058project_field$1261$(_value_0) {
  const _project_0 = _value_0["project"];
  return _project_0;
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058handles_tail_finish$1260$(_scanned_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _scanned_0["live"];
  const _handles_0 = _scanned_0["handles"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _handles_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail$1260$(_remaining_0, _namespace_0, _live_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1260$(nat_chk(2 * _remaining_0), _remaining_0, _namespace_0, {$: "../../../../../../../../src/ecs/world.WorldTailScanReady", "live": _live_0, "handles": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1262$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1262$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1262$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_mismatched$1260$(_target_0, _owner_0) {
  const _id_0 = _target_0["id"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Fail", "error": {$: "../../../../../../../../src/ecs/inspector-query.QueryMismatch", "entityId": _id_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047inspector$045query$058composed_lookup_projected$1260$(_target_0, _observed_0) {
  const _owner_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "Done", "value": {$: "../../../../../../../../src/ecs/inspector-query.ProjectedRow", "entity": _target_0, "data": _value_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_after_left$1261$(_cursor_0, _ownerB_0, _deltaB_0, _committedA_0) {
  const _world_0 = _committedA_0["fst"];
  const _ownerA_0 = _committedA_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_join$1261$(_ownerA_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_fn$1262$(_world_0, _ownerB_0, _deltaB_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058commit_event$1260$(_context_0, _owner_0, _readThrough_0, _cursor_0) {
  const _world_0 = _context_0["world"];
  const _state_0 = _context_0["family"];
  const _tick_0 = _context_0["tick"];
  const _facts_0 = _owner_0["facts"];
  const _t_0 = _owner_0["reader"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _registryId_0 = _t_0["registryId"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_advanced$1260$(_state_0, _id_0, _readThrough_0)), "tick": _tick_0}, "snd": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.EventOwner", "facts": _facts_0, "reader": {$: "../../../../../../../../src/ecs/event-family-routing.Reader", "namespace": _namespace_0, "id": _id_0, "registryId": _registryId_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../../../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_domains_0, _key_0, _position_0)), "tail": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_rest_0, _domains_0, _position_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047removals$058include$1260$(_item_0, _rest_0) {
  if (_item_0.$ === "None") {
    return _rest_0;
  } else {
    const _value_0 = _item_0["value"];
    return {$: "Con", "head": _value_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_tail_loop$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _remaining_0 = $1;
      const _namespace_0 = $2;
      const _phase_0 = $3;
      if (_fuel_0 === 0) {
        if (_phase_0.$ === "../../../../../../../../src/ecs/world.WorldTailScanReady") {
          const _live_0 = _phase_0["live"];
          const _handles_0 = _phase_0["handles"];
          return {$: "../../../../../../../../src/ecs/world.HandleScan", "live": _live_0, "handles": _handles_0};
        } else {
          const _t_0 = _phase_0["checked"];
          const _live_1 = _t_0["fst"];
          const _handles_1 = _phase_0["handles"];
          return {$: "../../../../../../../../src/ecs/world.HandleScan", "live": _live_1, "handles": _handles_1};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0 === 0) {
          if (_phase_0.$ === "../../../../../../../../src/ecs/world.WorldTailScanReady") {
            const _live_2 = _phase_0["live"];
            const _handles_2 = _phase_0["handles"];
            return {$: "../../../../../../../../src/ecs/world.HandleScan", "live": _live_2, "handles": _handles_2};
          } else {
            const _t_1 = _phase_0["checked"];
            const _live_3 = _t_1["fst"];
            const _handles_3 = _phase_0["handles"];
            return {$: "../../../../../../../../src/ecs/world.HandleScan", "live": _live_3, "handles": _handles_3};
          }
        } else {
          const _rest_0 = (_remaining_0 - 1);
          if (_phase_0.$ === "../../../../../../../../src/ecs/world.WorldTailScanReady") {
            const _live_4 = _phase_0["live"];
            const _handles_4 = _phase_0["handles"];
            const _x_0 = nat_chk(_rest_0 + 1);
            const _x_1 = (_x_0 >>> 0);
            $0 = _more_0;
            $1 = nat_chk(_rest_0 + 1);
            $2 = _namespace_0;
            $3 = {$: "../../../../../../../../src/ecs/world.WorldTailScanRead", "checked": {$: "Tuple", fst: _live_4, snd: _live_4[_x_1 % _live_4.length]}, "handles": _handles_4};
            continue;
          } else {
            const _t_2 = _phase_0["checked"];
            const _live_5 = _t_2["fst"];
            const _present_0 = _t_2["snd"];
            const _handles_5 = _phase_0["handles"];
            const _x_2 = nat_chk(_rest_0 + 1);
            $0 = _more_0;
            $1 = _rest_0;
            $2 = _namespace_0;
            $3 = {$: "../../../../../../../../src/ecs/world.WorldTailScanReady", "live": _live_5, "handles": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, (_x_2 >>> 0), _handles_5))};
            continue;
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1262$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1262$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_join$1261$(_ownerA_0, _committedB_0) {
  const _world_0 = _committedB_0["fst"];
  const _ownerB_0 = _committedB_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_fn$1262$(_world_0, _owners_0, _deltas_0, _cursor_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  const _deltaA_0 = _deltas_0["fst"];
  const _deltaB_0 = _deltas_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_after_left$1262$(_cursor_0, _ownerB_0, _deltaB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058commit_event$1260$(_world_0, _ownerA_0, _deltaA_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_advanced$1260$(_state_0, _id_0, _readThrough_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_advanced_selected$1260$(_id_0, _readThrough_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058take$1260$(_state_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../../../../../../../../src/ecs/internal/relation-failures/readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058select$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1260$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058collect_checked$1260$(_present_0, _namespace_0, _id_0, _handles_0) {
  if (!_present_0) {
    return _handles_0;
  } else {
    return {$: "Con", "head": {$: "../../../../../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, "tail": _handles_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1262$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_after_left$1262$(_cursor_0, _ownerB_0, _deltaB_0, _committedA_0) {
  const _world_0 = _committedA_0["fst"];
  const _ownerA_0 = _committedA_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_join$1262$(_ownerA_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_fn$1263$(_world_0, _ownerB_0, _deltaB_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058event_advanced_selected$1260$(_id_0, _readThrough_0, _selected_0) {
  const _state_0 = _selected_0["fst"];
  const _stream_0 = _selected_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045notice$045runtime$058put$1260$(_state_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058advance$1260$(_stream_0, _id_0, _readThrough_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058select$1260$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1260$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1260$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_join$1262$(_ownerA_0, _committedB_0) {
  const _world_0 = _committedB_0["fst"];
  const _ownerB_0 = _committedB_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_fn$1263$(_world_0, _owners_0, _deltas_0, _cursor_0) {
  const _ownerA_0 = _owners_0["fst"];
  const _ownerB_0 = _owners_0["snd"];
  const _deltaA_0 = _deltas_0["fst"];
  const _deltaB_0 = _deltas_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_after_left$1263$(_cursor_0, _ownerB_0, _deltaB_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058commit_removal$1260$(_world_0, _ownerA_0, _deltaA_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045stream$058advance$1260$(_stream_0, _id_0, _tick_0) {
  const _domain_0 = _stream_0["domain"];
  const _batches_0 = _stream_0["batches"];
  const _positions_0 = _stream_0["positions"];
  const _nextReader_0 = _stream_0["nextReader"];
  const _frameStart_0 = _stream_0["frameStart"];
  const _boundary_0 = _stream_0["boundary"];
  const _capacity_0 = _stream_0["capacity"];
  const _dropped_0 = _stream_0["dropped"];
  return {$: "../../../../../../../../src/ecs/event-stream.Stream", "domain": _domain_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _id_0, _tick_0, false)), "nextReader": _nextReader_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../../../../../src/ecs/internal/relation-failures/readings.KeyReading", "key": _key_0, "values": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read$1260$({$: "../../../../../../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1260$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../../../../../../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_after_left$1263$(_cursor_0, _ownerB_0, _deltaB_0, _committedA_0) {
  const _world_0 = _committedA_0["fst"];
  const _ownerA_0 = _committedA_0["snd"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_join$1263$(_ownerA_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058commit_relation$1260$(_world_0, _ownerB_0, _deltaB_0, _cursor_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058commit_removal$1260$(_context_0, _owner_0, _observedCount_0, _cursor_0) {
  const _facts_0 = _owner_0["facts"];
  const _t_0 = _owner_0["reader"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  return {$: "Tuple", "fst": _context_0, "snd": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RemovalOwner", "facts": _facts_0, "reader": {$: "../../../../../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _observedCount_0}}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read$1260$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0) {
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add_checked$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _id_0)), _ids_0, _id_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047reader$045parameter$058pair_commit_join$1263$(_ownerA_0, _committedB_0) {
  const _world_0 = _committedB_0["fst"];
  const _ownerB_0 = _committedB_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": _ownerA_0, "snd": _ownerB_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058commit_relation$1260$(_context_0, _owner_0, _delta_0, _cursor_0) {
  const _world_0 = _context_0["world"];
  const _t_0 = _context_0["family"];
  const _typed_0 = _t_0["typed"];
  const _failures_0 = _t_0["failures"];
  const _routeTick_0 = _context_0["tick"];
  const _facts_0 = _owner_0["facts"];
  const _id_0 = _owner_0["id"];
  const _keys_0 = _owner_0["keys"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_commit_state$1260$(_world_0, _typed_0, _failures_0, _routeTick_0, _facts_0, _id_0, _keys_0, _delta_0);
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$(($List$reverse$(_back_0)), _cursor_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add_checked$(_found_0, _ids_0, _id_0) {
  if (_found_0) {
    return _ids_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _ids_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_commit_state$1260$(_world_0, _typed_0, _failures_0, _routeTick_0, _facts_0, _id_0, _keys_0, _delta_0) {
  const _domains_0 = _failures_0["domains"];
  const _positions_0 = _failures_0["positions"];
  const _tick_0 = _failures_0["tick"];
  const _frameStart_0 = _failures_0["frameStart"];
  const _boundary_0 = _failures_0["boundary"];
  const _capacity_0 = _failures_0["capacity"];
  const _nextReader_0 = _failures_0["nextReader"];
  return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_commit_updated$1260$(_world_0, _typed_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0, _routeTick_0, _facts_0, _id_0, _keys_0, ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_commit_selected$1260$(_domains_0, _positions_0, _keys_0, _id_0, _delta_0)));
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1260$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_commit_updated$1260$(_world_0, _typed_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0, _routeTick_0, _facts_0, _id_0, _keys_0, _updated_0) {
  const _updatedDomains_0 = _updated_0["fst"];
  const _updatedPositions_0 = _updated_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../../../../../src/ecs/event-family-routing.Runtime", "world": _world_0, "family": {$: "../../../../../../../../src/ecs/event-notice-runtime.State", "typed": _typed_0, "failures": {$: "../../../../../../../../src/ecs/event-notice-runtime.Failures", "domains": _updatedDomains_0, "positions": _updatedPositions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}}, "tick": _routeTick_0}, "snd": {$: "../../../../../../../../src/ecs/ordinary-reader-stream-parameter.RelationOwner", "facts": _facts_0, "id": _id_0, "keys": _keys_0}};
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_commit_selected$1260$(_domains_0, _positions_0, _keys_0, _id_0, _delta_0) {
  if (_id_0.$ === "Some") {
    const _readerId_0 = _id_0["value"];
    const _t_0 = _delta_0["id"];
    if (_t_0.$ === "Some") {
      const _deltaId_0 = _t_0["value"];
      const _readThrough_0 = _delta_0["readThrough"];
      return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_commit_match$1260$(_domains_0, _positions_0, _keys_0, _readerId_0, _readThrough_0, (_readerId_0 === _deltaId_0));
    } else {
      return {$: "Tuple", "fst": _domains_0, "snd": _positions_0};
    }
  } else {
    return {$: "Tuple", "fst": _domains_0, "snd": _positions_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1260$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1260$(_items_0, _acc_0);
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047ordinary$045reader$045stream$045parameter$058relation_commit_match$1260$(_domains_0, _positions_0, _keys_0, _readerId_0, _readThrough_0, _matched_0) {
  if (_matched_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$(_keys_0, _domains_0, _readerId_0)), "snd": ($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, _readThrough_0)), _readerId_0, _readThrough_0, false))};
  } else {
    return {$: "Tuple", "fst": _domains_0, "snd": _positions_0};
  }
}

function $$$$047$$$047$$$047$$$047$$$047$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);