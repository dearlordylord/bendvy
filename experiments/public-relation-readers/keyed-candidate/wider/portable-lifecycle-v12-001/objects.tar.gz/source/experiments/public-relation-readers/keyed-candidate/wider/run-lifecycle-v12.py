"""Prepare-only by default; exact frozen development cohort, no acceptance claim."""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT))
from scripts.task_runner import Inputs,Runner,IMPLEMENTATION_SHA256
spec=importlib.util.spec_from_file_location('receipt_logs',ROOT/'scripts/receipt-logs.py')
logs_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(logs_module)
W=Path(__file__).resolve().parent
F=W/'freeze-lifecycle-v12-001';STAGE=W/'lifecycle-v12-001';PLAN=F/'execution-plan.json'
tool_spec=importlib.util.spec_from_file_location('lifecycle_owned_tools',ROOT/'scripts/owned-tool-pins.py')
owned_tools=importlib.util.module_from_spec(tool_spec);tool_spec.loader.exec_module(owned_tools)
CLANG=Path('/tmp/bendvy-clang19-diagnostic/root')
ENV=dict(os.environ,BEND_NO_TELEMETRY='1',BENDVY_CLANG19_ROOT=str(CLANG),LD_LIBRARY_PATH=':'.join(map(str,[CLANG/'usr/lib/aarch64-linux-gnu',CLANG/'usr/lib/llvm-19/lib',Path('/home/node/.local/opt/dnd-clang14/usr/lib/aarch64-linux-gnu')])))
def tool_configuration(execute=None):
 return {'execute':execute or __import__('scripts.task_runner',fromlist=['execute_result']).execute_result,'tools':{'bend':'/home/node/.bend/bin/bend','node':'/home/node/.local/share/mise/installs/node/24.20.0/bin/node','python':sys.executable,'taskset':'/usr/bin/taskset','clang-wrapper':'/tmp/bendvy-clang19-diagnostic/clang19','clang':str(CLANG/'usr/lib/llvm-19/bin/clang')},'resource_roots':['/home/node/.bend/bend2',str(CLANG/'usr/lib/llvm-19/lib/clang/19')],'ldd':'/usr/bin/ldd','taskset':'/usr/bin/taskset','cpu':5,'env':dict(ENV),'skip_ldd':['clang-wrapper'],'capture_mode':'split'}
def encode(value):
 if isinstance(value,bytes):return {'rawBase64':base64.b64encode(value).decode()}
 raise TypeError(type(value))
def decode(value):
 if isinstance(value,dict):
  if set(value)=={'rawBase64'}:return base64.b64decode(value['rawBase64'])
  return {k:decode(v) for k,v in value.items()}
 if isinstance(value,list):return [decode(v) for v in value]
 return value
def configurations(paths):
 roots={ROOT,Path.cwd(),F,STAGE,Path('/home/node/.bend')}|{Path(p).parent for p in paths}
 configs={ancestor/name for root in roots for ancestor in [root,*root.parents] for name in ['check.json','bend.json','bender.json']}
 states={str(p):{'present':os.path.lexists(p),'symlink':str(p.readlink()) if p.is_symlink() else None,'sha256':sha(p) if p.is_file() else None} for p in sorted(configs)}
 for p in configs:
  if p.is_file():
   value=json.loads(p.read_text())
   if 'checkLimit' in value:assert value['checkLimit']==5, 'checkLimit must remain five seconds'
 return states
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def envsha():return hashlib.sha256(json.dumps(ENV,sort_keys=True).encode()).hexdigest()
def prepare():
 assert not F.exists() and not STAGE.exists()
 consumed=set()
 def visit(p):
  p=p.resolve()
  if p in consumed:return
  consumed.add(p)
  if p.suffix=='.bend':
   for name in re.findall(r'^import\s+(\S+)',p.read_text(),re.M):
    if name!='Base':visit(p.parent/name)
 visit(W/'lifecycle-v11.bend')
 for name in ['lifecycle-oracle-v11.mjs','lifecycle-consumer-v11.mjs','lifecycle-native-consumer-v11.mjs','codec-memo.mjs']:consumed.add(W/name)
 for name in ['docs/SPEC.md','.references/sources.json','CODING_STANDARDS.md','scripts/task_runner.py','scripts/receipt-logs.py','scripts/owned-tool-pins.py']:consumed.add(ROOT/name)
 consumed.add(Path(__file__).resolve())
 source=F/'source';source.mkdir(parents=True)
 for p in sorted(consumed):
  dest=source/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
 probes=F/'prepared-tool-probes';probes.mkdir()
 probe_names=['bend','node','python','taskset','clang']
 probe_logs=logs_module.CommandLogs(probes,['prepare-ldd-'+n for n in probe_names])
 probe_inputs=Inputs(files=[*consumed,ROOT/'scripts/owned-tool-pins.py'],directories=[source])
 probe_runner=Runner(probe_logs,inputs=probe_inputs,env=ENV,cwd=ROOT,capture='split');probe_index=[0]
 def probe_execute(argv,limit,env):
  assert env==ENV and limit==5
  name=probe_names[probe_index[0]];probe_index[0]+=1
  label='prepare-ldd-'+name
  result=probe_runner.run(label,argv,limit)
  (probes/(label+'.json')).write_text(json.dumps(dict(command=argv,timeout=limit,exit=result['exit'],failure=result['failure']),indent=2)+'\n')
  return result
 current_tools=owned_tools.snapshot(**tool_configuration(probe_execute));tools=current_tools['pins']
 assert probe_index[0]==5
 inputs=Inputs(files=[*consumed,*map(Path,tools)],directories=[source,probes])
 bend='/home/node/.bend/bin/bend';node='/home/node/.local/share/mise/installs/node/24.20.0/bin/node';clang='/tmp/bendvy-clang19-diagnostic/clang19'
 for tool in [bend,node,clang]:assert str(Path(tool).resolve()) in tools,tool
 entry=source/(W/'lifecycle-v11.bend').relative_to(ROOT);helper=source/W.relative_to(ROOT)
 commands=[('source-check',[bend,str(entry),'--check-only'],5,None),('emit-js',[bend,str(entry),'-o',str(STAGE/'lifecycle.mjs')],30,'lifecycle.mjs'),('consume-js',[node,str(helper/'lifecycle-consumer-v11.mjs'),str(STAGE/'lifecycle.mjs')],5,None),('emit-c',[bend,str(entry),'-o',str(STAGE/'lifecycle.c')],30,'lifecycle.c'),('compile',[clang,'-O3',str(STAGE/'lifecycle.c'),'-pthread','-lm','-o',str(STAGE/'lifecycle-native')],120,'lifecycle-native'),('native',[str(STAGE/'lifecycle-native'),'--threads','1','--gpu','off'],5,None),('consume-native',[node,str(helper/'lifecycle-native-consumer-v11.mjs'),str(STAGE/'native.stdout')],5,None)]
 plan={'developmentOnly':True,'acceptance':False,'completeIssue43':False,'scope':'two-schema actual public schedule false-condition registered never/activated skip + successful disposal; mixed-clock/rejected disposal/native timing not claimed','tools':current_tools,'prepareProbeLabels':['prepare-ldd-'+n for n in probe_names],'executionProbeLabels':['guard-'+str(i)+'-ldd-'+n for i in range(14) for n in probe_names],'configurationRoots':[str(p) for p in [*inputs.files,*source.rglob('*.bend'),*source.rglob('*.mjs')]],'configurationStates':configurations([*inputs.files,*source.rglob('*.bend'),*source.rglob('*.mjs')]),'runnerSHA256':IMPLEMENTATION_SHA256,'inputs':inputs.expected,'envSHA256':envsha(),'cwd':str(ROOT),'stage':str(STAGE),'commands':[{'label':label,'argv':argv,'limit':limit,'generated':generated} for label,argv,limit,generated in commands],'prospectiveRaw':[label+suffix for label,_,_,_ in commands for suffix in ['.stdout','.stderr','.json']]}
 PLAN.write_text(json.dumps(plan,indent=2,default=encode)+'\n');print('PREPARED',sha(PLAN))
def execute():
 plan=decode(json.loads(PLAN.read_text()));assert envsha()==plan['envSHA256'];assert not STAGE.exists()
 files=[p for p,v in plan['inputs'].items() if isinstance(v,str)];dirs=[p for p,v in plan['inputs'].items() if isinstance(v,dict)]
 inputs=Inputs(files=[*files,PLAN],directories=dirs)
 for p,v in plan['inputs'].items():assert inputs.expected[p]==v,p
 STAGE.mkdir();probe_dir=STAGE/'tool-probes';probe_dir.mkdir();probe_names=['bend','node','python','taskset','clang'];probe_counter=[0];probe_receipts={};probe_logs=logs_module.CommandLogs(probe_dir,plan['executionProbeLabels']);probe_runner=Runner(probe_logs,inputs=inputs,env=ENV,cwd=ROOT,capture='split')
 def probe_execute(argv,limit,env):
  assert env==ENV and limit==5
  i=probe_counter[0];assert i<70;label=plan['executionProbeLabels'][i];probe_counter[0]+=1
  result=probe_runner.run(label,argv,limit)
  p=probe_dir/(label+'.json');p.write_text(json.dumps(dict(command=argv,timeout=limit,exit=result['exit'],failure=result['failure']),indent=2)+'\n');probe_receipts[str(p)]=sha(p)
  return result
 logs=logs_module.CommandLogs(STAGE,[r['label'] for r in plan['commands']]);runner=Runner(logs,inputs=inputs,env=ENV,cwd=ROOT,capture='split');generated={};receipts={}
 def guard():
  inputs.guard();logs.guard()
  assert configurations(plan['configurationRoots'])==plan['configurationStates'],'configuration membership/bytes changed'
  owned_tools.verify(plan['tools'],**tool_configuration(probe_execute))
  probe_logs.guard()
  for p,h in probe_receipts.items():assert sha(p)==h,p
  assert {str(p) for p in probe_dir.iterdir()}==set(probe_receipts)|{str(probe_dir/n) for n in probe_logs.hashes},'probe output membership changed'
  for p,h in generated.items():assert sha(p)==h,p
  for p,h in receipts.items():assert sha(p)==h,p
  actual={str(p) for p in STAGE.iterdir()}
  expected=set(generated)|set(receipts)|{str(STAGE/n) for n in logs.hashes}|{str(probe_dir)}
  assert actual==expected,'output membership changed'
 for row in plan['commands']:
  guard()
  try:result=runner.run(row['label'],row['argv'],row['limit'])
  except Exception as error:
   result=error.result
   for channel in ['stdout','stderr']:result.pop(channel,None)
   (STAGE/(row['label']+'.json')).write_text(json.dumps(dict(result,command=row['argv'],timeout=row['limit'],developmentOnly=True,acceptance=False),indent=2)+'\n')
   raise
  if row['generated']:
   p=STAGE/row['generated'];assert p.is_file();generated[str(p)]=sha(p)
  result.pop('stdout');result.pop('stderr');p=STAGE/(row['label']+'.json');p.write_text(json.dumps(dict(result,command=row['argv'],timeout=row['limit'],planSHA256=sha(PLAN),developmentOnly=True,acceptance=False),indent=2)+'\n');receipts[str(p)]=sha(p)
  guard()
 assert probe_counter[0]==70
 (STAGE/'receipt.json').write_text(json.dumps({'developmentOnly':True,'acceptance':False,'completeIssue43':False,'status':'LIFECYCLE_DEVELOPMENT_PASS','planSHA256':sha(PLAN),'rawPins':logs.hashes,'generatedPins':generated,'receiptPins':receipts,'toolProbeRawPins':probe_logs.hashes,'toolProbeReceiptPins':probe_receipts},indent=2)+'\n')
 print('LIFECYCLE_DEVELOPMENT_PASS')
if __name__=='__main__':
 if sys.argv[1:]==['--prepare-only']:prepare()
 elif sys.argv[1:]==['--execute']:execute()
 else:raise SystemExit('use --prepare-only or --execute')
