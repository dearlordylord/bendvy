import {deepStrictEqual} from 'node:assert';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {normalize} from './codec-memo.mjs';
import {expected} from './lifecycle-oracle-v11.mjs';
const {default:api}=await import(pathToFileURL(resolve(process.argv[2])));
const observed=normalize(api.main());
deepStrictEqual(observed,expected());
console.log(JSON.stringify({developmentOnly:true,acceptance:false,completeIssue43:false,observed}));
