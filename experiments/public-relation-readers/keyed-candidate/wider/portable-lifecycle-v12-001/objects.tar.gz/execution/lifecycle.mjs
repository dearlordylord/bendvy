function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058registration_equal$(_id_0, _name_0, _access_0, _otherId_0, _otherName_0, _otherAccess_0) {
  return $Bool$and$((_id_0 === _otherId_0), ($Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_name_0, _otherName_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(_access_0, _otherAccess_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$(_keep_0, _meta_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _meta_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$(($Bool$not$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0)))), _meta_0, ($$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_rest_0, _id_0, _name_0, _access_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047domains$058member$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_id_0 === _wanted_0);
    const _x_1 = ($$$$047domains$058member$(_rest_0, _wanted_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047domains$058add_checked$(_found_0, _ids_0, _id_0) {
  if (_found_0) {
    return _ids_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _ids_0};
  }
}

function $$$$047domains$058add$(_ids_0, _id_0) {
  return $$$$047domains$058add_checked$(($$$$047domains$058member$(_ids_0, _id_0)), _ids_0, _id_0);
}

function $$$$047domains$058select_boundary$(_registered_0, _cursor_0, _boundary_0) {
  if (!_registered_0) {
    return _boundary_0;
  } else {
    return (_cursor_0 < _boundary_0 ? _cursor_0 : _boundary_0);
  }
}

function $$$$047domains$058boundary$($0, $1, $2) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _ids_0 = $1;
      const _acc_0 = $2;
      if (_positions_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _id_0 = _t_0["id"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = _ids_0;
        $2 = ($$$$047domains$058select_boundary$(($$$$047domains$058member$(_ids_0, _id_0)), _cursor_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047runtime$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((_x_0 === _id_0), _x_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $$$$047driven$058cells$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $List$append$(($$$$047driven$058cells$(_left_0)), ($$$$047driven$058cells$(_right_0)));
  }
}

function $$$$047driven$058private_observed$(_cloned_0) {
  const _owner_0 = _cloned_0["fst"];
  const _copy_0 = _cloned_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($$$$047driven$058cells$(_copy_0))};
}

function $runtime$045v2$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $disposal$058keep$(_found_0, _id_0, _rest_0) {
  if (_found_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $disposal$058remove$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return $disposal$058keep$((_id_0 === _wanted_0), _id_0, ($disposal$058remove$(_rest_0, _wanted_0)));
  }
}

function $observe$045v2$058bool_cells$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $List$append$(($observe$045v2$058bool_cells$(_left_0)), ($observe$045v2$058bool_cells$(_right_0)));
  }
}

function $observe$045v2$058main$() {
  return {$: "Tuple", "fst": ($observe$045v2$058observed$1260$(($application$045v2$058application$1260$(65537)))), "snd": ($observe$045v2$058observed$1261$(($application$045v2$058application$1261$(65537))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $bool_cells$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $List$append$(($bool_cells$(_left_0)), ($bool_cells$(_right_0)));
  }
}

function $main$() {
  return {$: "Tuple", "fst": ($cases$1260$()), "snd": ($cases$1261$())};
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $observe$045v2$058observed$1260$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _t_1 = _t_0["runtime"];
    const _t_2 = _t_1["world"];
    const _namespace_0 = _t_2["namespace"];
    const _nextId_0 = _t_2["nextId"];
    const _highWater_0 = _t_2["highWater"];
    const _live_0 = _t_2["live"];
    const _capacity_0 = _t_2["capacity"];
    const _depth_0 = _t_2["depth"];
    const _t_3 = _t_2["store"];
    const _t_4 = _t_3["components"];
    const _left_0 = _t_4["left"];
    const _right_0 = _t_4["right"];
    const _graph_0 = _t_3["graph"];
    const _t_5 = _t_2["resource"];
    const _baseline_0 = _t_5["baseline"];
    const _returned_0 = _t_5["returned"];
    const _events_0 = _t_2["events"];
    const _pending_0 = _t_2["pending"];
    const _registrations_0 = _t_2["registrations"];
    const _nextSystemId_0 = _t_2["nextSystemId"];
    const _clock_0 = _t_2["clock"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _frameStart_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _retentionCapacity_0 = _t_1["capacity"];
    const _t_6 = _t_0["alpha"];
    const _alphaPrivate_0 = _t_6["private"];
    const _t_7 = _t_0["beta"];
    const _betaPrivate_0 = _t_7["private"];
    const _t_8 = _t_0["both"];
    const _bothPrivate_0 = _t_8["private"];
    const _deliveries_0 = _t_0["deliveries"];
    return {$: "Some", "value": {$: "observe-v2.Final", "deliveries": ($List$reverse$(_deliveries_0)), "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "retentionCapacity": _retentionCapacity_0, "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": ($observe$045v2$058bool_cells$(_live_0)), "capacity": _capacity_0, "depth": _depth_0, "left": ($$$$047driven$058cells$(_left_0)), "right": ($$$$047driven$058cells$(_right_0)), "graph": _graph_0, "baseline": ($$$$047driven$058cells$(_baseline_0)), "returned": ($observe$045v2$058mailbox$1260$(_returned_0)), "events": _events_0, "pendingCount": ($observe$045v2$058pending_count$1260$(_pending_0, 0)), "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0, "alphaPrivate": ($$$$047driven$058cells$(_alphaPrivate_0)), "betaPrivate": ($$$$047driven$058cells$(_betaPrivate_0)), "bothPrivate": ($$$$047driven$058cells$(_bothPrivate_0))}};
  }
}

function $application$045v2$058application$1260$(_count_0) {
  return $application$045v2$058triple$1260$(($application$045v2$058publication$1260$(($application$045v2$058triple$1260$(($application$045v2$058seeded$1260$(($$$$047application$058seeded$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "../application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})))))))), _count_0)));
}

function $observe$045v2$058observed$1261$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _t_1 = _t_0["runtime"];
    const _t_2 = _t_1["world"];
    const _namespace_0 = _t_2["namespace"];
    const _nextId_0 = _t_2["nextId"];
    const _highWater_0 = _t_2["highWater"];
    const _live_0 = _t_2["live"];
    const _capacity_0 = _t_2["capacity"];
    const _depth_0 = _t_2["depth"];
    const _t_3 = _t_2["store"];
    const _t_4 = _t_3["components"];
    const _left_0 = _t_4["left"];
    const _right_0 = _t_4["right"];
    const _graph_0 = _t_3["graph"];
    const _t_5 = _t_2["resource"];
    const _baseline_0 = _t_5["baseline"];
    const _returned_0 = _t_5["returned"];
    const _events_0 = _t_2["events"];
    const _pending_0 = _t_2["pending"];
    const _registrations_0 = _t_2["registrations"];
    const _nextSystemId_0 = _t_2["nextSystemId"];
    const _clock_0 = _t_2["clock"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _frameStart_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _retentionCapacity_0 = _t_1["capacity"];
    const _t_6 = _t_0["alpha"];
    const _alphaPrivate_0 = _t_6["private"];
    const _t_7 = _t_0["beta"];
    const _betaPrivate_0 = _t_7["private"];
    const _t_8 = _t_0["both"];
    const _bothPrivate_0 = _t_8["private"];
    const _deliveries_0 = _t_0["deliveries"];
    return {$: "Some", "value": {$: "observe-v2.Final", "deliveries": ($List$reverse$(_deliveries_0)), "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "retentionCapacity": _retentionCapacity_0, "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": ($observe$045v2$058bool_cells$(_live_0)), "capacity": _capacity_0, "depth": _depth_0, "left": ($$$$047driven$058cells$(_left_0)), "right": ($$$$047driven$058cells$(_right_0)), "graph": _graph_0, "baseline": ($$$$047driven$058cells$(_baseline_0)), "returned": ($observe$045v2$058mailbox$1261$(_returned_0)), "events": _events_0, "pendingCount": ($observe$045v2$058pending_count$1261$(_pending_0, 0)), "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0, "alphaPrivate": ($$$$047driven$058cells$(_alphaPrivate_0)), "betaPrivate": ($$$$047driven$058cells$(_betaPrivate_0)), "bothPrivate": ($$$$047driven$058cells$(_bothPrivate_0))}};
  }
}

function $application$045v2$058application$1261$(_count_0) {
  return $application$045v2$058triple$1261$(($application$045v2$058publication$1261$(($application$045v2$058triple$1261$(($application$045v2$058seeded$1261$(($$$$047application$058seeded$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "../application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})))))))), _count_0)));
}

function $cases$1260$() {
  return {$: "Cases", "neverActivatedSkip": ($scheduled$1260$(($seed$1260$()))), "activatedSkip": ($scheduled$1260$(($application$045v2$058application$1260$(3)))), "successfulDisposal": ($disposed$1260$(($application$045v2$058application$1260$(3))))};
}

function $cases$1261$() {
  return {$: "Cases", "neverActivatedSkip": ($scheduled$1261$(($seed$1261$()))), "activatedSkip": ($scheduled$1261$(($application$045v2$058application$1261$(3)))), "successfulDisposal": ($disposed$1261$(($application$045v2$058application$1261$(3))))};
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $observe$045v2$058mailbox$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["private"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": ($$$$047driven$058cells$(_owner_0)), "tail": ($observe$045v2$058mailbox$1260$(_rest_0))};
  }
}

function $observe$045v2$058pending_count$1260$($0, $1) {
  for (;;) {
    {
      const _pending_0 = $0;
      const _acc_0 = $1;
      if (_pending_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _pending_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $application$045v2$058triple$1260$(_app_0) {
  return $application$045v2$058step$1260$(($application$045v2$058step$1260$(($application$045v2$058step$1260$(_app_0)))));
}

function $application$045v2$058publication$1260$(_app_0, _count_0) {
  if (_app_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _app_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _alpha_0 = _t_0["alpha"];
    const _beta_0 = _t_0["beta"];
    const _both_0 = _t_0["both"];
    const _deliveries_0 = _t_0["deliveries"];
    return {$: "Some", "value": ($application$045v2$058published$1260$(($runtime$045v2$058with_world$1260$(run_clo((_x_0) => {
  return $application$045v2$058publish$1260$(_count_0, _x_0);
}), _runtime_0)), _alpha_0, _beta_0, _both_0, _deliveries_0))};
  }
}

function $application$045v2$058seeded$1260$(_start_0) {
  if (_start_0.$ === "../application.Started") {
    const _runtime_0 = _start_0["runtime"];
    return $application$045v2$058from_old$1260$(_runtime_0);
  } else {
    return {$: "None"};
  }
}

function $$$$047application$058seeded$1260$(_created_0) {
  if (_created_0.$ === "../../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../application.Started", "runtime": ($$$$047runtime$058start$1260$(($$$$047application$058reserved$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0))))))};
  } else {
    const _factory_0 = _created_0["factory"];
    const _resource_0 = _created_0["resource"];
    return {$: "../application.StartRejected", "factory": _factory_0, "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $observe$045v2$058mailbox$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["private"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": ($$$$047driven$058cells$(_owner_0)), "tail": ($observe$045v2$058mailbox$1261$(_rest_0))};
  }
}

function $observe$045v2$058pending_count$1261$($0, $1) {
  for (;;) {
    {
      const _pending_0 = $0;
      const _acc_0 = $1;
      if (_pending_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _pending_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $application$045v2$058triple$1261$(_app_0) {
  return $application$045v2$058step$1261$(($application$045v2$058step$1261$(($application$045v2$058step$1261$(_app_0)))));
}

function $application$045v2$058publication$1261$(_app_0, _count_0) {
  if (_app_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _app_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _alpha_0 = _t_0["alpha"];
    const _beta_0 = _t_0["beta"];
    const _both_0 = _t_0["both"];
    const _deliveries_0 = _t_0["deliveries"];
    return {$: "Some", "value": ($application$045v2$058published$1261$(($runtime$045v2$058with_world$1261$(run_clo((_x_0) => {
  return $application$045v2$058publish$1261$(_count_0, _x_0);
}), _runtime_0)), _alpha_0, _beta_0, _both_0, _deliveries_0))};
  }
}

function $application$045v2$058seeded$1261$(_start_0) {
  if (_start_0.$ === "../application.Started") {
    const _runtime_0 = _start_0["runtime"];
    return $application$045v2$058from_old$1261$(_runtime_0);
  } else {
    return {$: "None"};
  }
}

function $$$$047application$058seeded$1261$(_created_0) {
  if (_created_0.$ === "../../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../application.Started", "runtime": ($$$$047runtime$058start$1261$(($$$$047application$058reserved$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0))))))};
  } else {
    const _factory_0 = _created_0["factory"];
    const _resource_0 = _created_0["resource"];
    return {$: "../application.StartRejected", "factory": _factory_0, "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $scheduled$1260$(_app_0) {
  if (_app_0.$ === "None") {
    return {$: "Scheduled", "final": {$: "None"}, "observations": {$: "Nil"}};
  } else {
    const _t_0 = _app_0["value"];
    const _t_1 = _t_0["runtime"];
    const _world_0 = _t_1["world"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _frameStart_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _capacity_0 = _t_1["capacity"];
    const _alpha_0 = _t_0["alpha"];
    const _beta_0 = _t_0["beta"];
    const _both_0 = _t_0["both"];
    const _deliveries_0 = _t_0["deliveries"];
    return $schedule_named$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), {$: "Owners", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "alpha": _alpha_0, "beta": _beta_0, "both": _both_0, "deliveries": _deliveries_0});
  }
}

function $seed$1260$() {
  return $application$045v2$058seeded$1260$(($$$$047application$058seeded$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "../application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})))));
}

function $disposed$1260$(_app_0) {
  if (_app_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _app_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _t_1 = _t_0["alpha"];
    const _reader_0 = _t_1["reader"];
    const _private_0 = _t_1["private"];
    const _beta_0 = _t_0["beta"];
    const _both_0 = _t_0["both"];
    const _deliveries_0 = _t_0["deliveries"];
    return $disposal_result$1260$(($disposal$058dispose$1260$(_runtime_0, _reader_0)), ($$$$047driven$058cells$(_private_0)), _beta_0, _both_0, _deliveries_0);
  }
}

function $scheduled$1261$(_app_0) {
  if (_app_0.$ === "None") {
    return {$: "Scheduled", "final": {$: "None"}, "observations": {$: "Nil"}};
  } else {
    const _t_0 = _app_0["value"];
    const _t_1 = _t_0["runtime"];
    const _world_0 = _t_1["world"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _frameStart_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _capacity_0 = _t_1["capacity"];
    const _alpha_0 = _t_0["alpha"];
    const _beta_0 = _t_0["beta"];
    const _both_0 = _t_0["both"];
    const _deliveries_0 = _t_0["deliveries"];
    return $schedule_named$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), {$: "Owners", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "alpha": _alpha_0, "beta": _beta_0, "both": _both_0, "deliveries": _deliveries_0});
  }
}

function $seed$1261$() {
  return $application$045v2$058seeded$1261$(($$$$047application$058seeded$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "../application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})))));
}

function $disposed$1261$(_app_0) {
  if (_app_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _app_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _t_1 = _t_0["alpha"];
    const _reader_0 = _t_1["reader"];
    const _private_0 = _t_1["private"];
    const _beta_0 = _t_0["beta"];
    const _both_0 = _t_0["both"];
    const _deliveries_0 = _t_0["deliveries"];
    return $disposal_result$1261$(($disposal$058dispose$1261$(_runtime_0, _reader_0)), ($$$$047driven$058cells$(_private_0)), _beta_0, _both_0, _deliveries_0);
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $application$045v2$058step$1260$(_app_0) {
  if (_app_0.$ === "None") {
    return {$: "None"};
  } else {
    const _app_1 = _app_0["value"];
    return $application$045v2$058next$1260$(_app_1);
  }
}

function $application$045v2$058published$1260$(_result_0, _alpha_0, _beta_0, _both_0, _deliveries_0) {
  const _runtime_0 = _result_0["fst"];
  return {$: "application-v2.WideApp", "runtime": ($runtime$045v2$058frame$1260$(($runtime$045v2$058barrier$1260$(_runtime_0)))), "alpha": _alpha_0, "beta": _beta_0, "both": _both_0, "deliveries": _deliveries_0};
}

function $runtime$045v2$058with_world$1260$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v2$058with_world_result$1260$(run_loop($runtime$045v2$058effect_clocked$1260$(_effect_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $application$045v2$058publish$1260$(_count_0, _world_0) {
  return $application$045v2$058publish_named$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _count_0);
}

function $application$045v2$058from_old$1260$(_old_0) {
  const _world_0 = _old_0["world"];
  return $application$045v2$058first$1260$(($application$045v2$058register$1260$(($runtime$045v2$058start$1260$(_world_0)), {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "alpha")));
}

function $$$$047runtime$058start$1260$(_world_0) {
  return {$: "../runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047application$058reserved$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047application$058activated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047application$058empty$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $application$045v2$058step$1261$(_app_0) {
  if (_app_0.$ === "None") {
    return {$: "None"};
  } else {
    const _app_1 = _app_0["value"];
    return $application$045v2$058next$1261$(_app_1);
  }
}

function $application$045v2$058published$1261$(_result_0, _alpha_0, _beta_0, _both_0, _deliveries_0) {
  const _runtime_0 = _result_0["fst"];
  return {$: "application-v2.WideApp", "runtime": ($runtime$045v2$058frame$1261$(($runtime$045v2$058barrier$1261$(_runtime_0)))), "alpha": _alpha_0, "beta": _beta_0, "both": _both_0, "deliveries": _deliveries_0};
}

function $runtime$045v2$058with_world$1261$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v2$058with_world_result$1261$(run_loop($runtime$045v2$058effect_clocked$1261$(_effect_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $application$045v2$058publish$1261$(_count_0, _world_0) {
  return $application$045v2$058publish_named$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _count_0);
}

function $application$045v2$058from_old$1261$(_old_0) {
  const _world_0 = _old_0["world"];
  return $application$045v2$058first$1261$(($application$045v2$058register$1261$(($runtime$045v2$058start$1261$(_world_0)), {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "alpha")));
}

function $$$$047runtime$058start$1261$(_world_0) {
  return {$: "../runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047application$058reserved$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $$$$047application$058activated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($$$$047application$058empty$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $schedule_named$1260$(_named_0, _owners_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $schedule_built$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, "false-alpha", {$: "Con", "head": {$: "../../../../src/ecs/schedule.System", "id": 1, "condition": 0}, "tail": {$: "Nil"}}, {$: "Con", "head": 1, "tail": {$: "Nil"}}, _owners_0)), _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $disposal_result$1260$(_result_0, _alphaPrivate_0, _beta_0, _both_0, _deliveries_0) {
  if (_result_0.$ === "disposal.ReaderDisposed") {
    const _runtime_0 = _result_0["runtime"];
    const _betaPrivate_0 = _beta_0["private"];
    const _bothPrivate_0 = _both_0["private"];
    return $snapshot$1260$(_runtime_0, _alphaPrivate_0, ($$$$047driven$058cells$(_betaPrivate_0)), ($$$$047driven$058cells$(_bothPrivate_0)), _deliveries_0);
  } else {
    return {$: "None"};
  }
}

function $disposal$058dispose$1260$(_runtime_0, _reader_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $disposal$058identified$1260$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _keys_0);
}

function $schedule_named$1261$(_named_0, _owners_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $schedule_built$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build$1261$(_namespace_0, "false-alpha", {$: "Con", "head": {$: "../../../../src/ecs/schedule.System", "id": 1, "condition": 0}, "tail": {$: "Nil"}}, {$: "Con", "head": 1, "tail": {$: "Nil"}}, _owners_0)), _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $disposal_result$1261$(_result_0, _alphaPrivate_0, _beta_0, _both_0, _deliveries_0) {
  if (_result_0.$ === "disposal.ReaderDisposed") {
    const _runtime_0 = _result_0["runtime"];
    const _betaPrivate_0 = _beta_0["private"];
    const _bothPrivate_0 = _both_0["private"];
    return $snapshot$1261$(_runtime_0, _alphaPrivate_0, ($$$$047driven$058cells$(_betaPrivate_0)), ($$$$047driven$058cells$(_bothPrivate_0)), _deliveries_0);
  } else {
    return {$: "None"};
  }
}

function $disposal$058dispose$1261$(_runtime_0, _reader_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $disposal$058identified$1261$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0)), _keys_0);
}

function $application$045v2$058next$1260$(_app_0) {
  const _runtime_0 = _app_0["runtime"];
  const _alpha_0 = _app_0["alpha"];
  const _beta_0 = _app_0["beta"];
  const _both_0 = _app_0["both"];
  const _deliveries_0 = _app_0["deliveries"];
  return $application$045v2$058restore$1260$(($application$045v2$058completed$1260$(($application$045v2$058run_slot$1260$(_runtime_0, _alpha_0)))), _beta_0, _both_0, _deliveries_0);
}

function $runtime$045v2$058frame$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "runtime-v2.Runtime", "world": _world_0, "domains": ($$$$047domains$058trim$1260$(_domains_0, _positions_0, _frameStart_0, _capacity_0)), "positions": _positions_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0};
}

function $runtime$045v2$058barrier$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v2$058barrier_join$1260$(($barrier$058barrier$1260$(_world_0, _domains_0)), _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v2$058with_world_result$1260$(_result_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$045v2$058with_world_collected$1260$(($$$$047routing$058collect$1260$(_world_0, nat_chk(_tick_0 + 1), _domains_0)), _output_0, _positions_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v2$058effect_clocked$1260$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $application$045v2$058publish_named$1260$(_named_0, _count_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "Tuple", "fst": run_loop($application$045v2$058queue_alpha$1260$(($$$$047application$058queue$1260$(($$$$047application$058descriptor$1260$(1)), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, _world_0)), _namespace_0, _count_0)), "snd": {$: "Unit"}};
}

function $application$045v2$058first$1260$(_registered_0) {
  if (_registered_0.$ === "runtime-v2.Registered") {
    const _runtime_0 = _registered_0["runtime"];
    const _reader_0 = _registered_0["reader"];
    return $application$045v2$058second$1260$(($application$045v2$058register$1260$(_runtime_0, {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 2}, "tail": {$: "Nil"}}, "beta")), {$: "application-v2.Slot", "reader": _reader_0, "private": array_node([501], [502])});
  } else {
    return {$: "None"};
  }
}

function $application$045v2$058register$1260$(_runtime_0, _keys_0, _name_0) {
  return $runtime$045v2$058register$1260$(_runtime_0, _keys_0, _name_0, {$: "Nil"});
}

function $runtime$045v2$058start$1260$(_world_0) {
  return {$: "runtime-v2.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047application$058activated$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047application$058empty$1260$(__0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1260$({$: "../application.CellOwners", "left": array_node([11], [12]), "right": array_node([21], [22])});
}

function $application$045v2$058next$1261$(_app_0) {
  const _runtime_0 = _app_0["runtime"];
  const _alpha_0 = _app_0["alpha"];
  const _beta_0 = _app_0["beta"];
  const _both_0 = _app_0["both"];
  const _deliveries_0 = _app_0["deliveries"];
  return $application$045v2$058restore$1261$(($application$045v2$058completed$1261$(($application$045v2$058run_slot$1261$(_runtime_0, _alpha_0)))), _beta_0, _both_0, _deliveries_0);
}

function $runtime$045v2$058frame$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "runtime-v2.Runtime", "world": _world_0, "domains": ($$$$047domains$058trim$1261$(_domains_0, _positions_0, _frameStart_0, _capacity_0)), "positions": _positions_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0};
}

function $runtime$045v2$058barrier$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v2$058barrier_join$1261$(($barrier$058barrier$1261$(_world_0, _domains_0)), _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v2$058with_world_result$1261$(_result_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$045v2$058with_world_collected$1261$(($$$$047routing$058collect$1261$(_world_0, nat_chk(_tick_0 + 1), _domains_0)), _output_0, _positions_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v2$058effect_clocked$1261$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $application$045v2$058publish_named$1261$(_named_0, _count_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "Tuple", "fst": run_loop($application$045v2$058queue_alpha$1261$(($$$$047application$058queue$1261$(($$$$047application$058descriptor$1261$(1)), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, _world_0)), _namespace_0, _count_0)), "snd": {$: "Unit"}};
}

function $application$045v2$058first$1261$(_registered_0) {
  if (_registered_0.$ === "runtime-v2.Registered") {
    const _runtime_0 = _registered_0["runtime"];
    const _reader_0 = _registered_0["reader"];
    return $application$045v2$058second$1261$(($application$045v2$058register$1261$(_runtime_0, {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 2}, "tail": {$: "Nil"}}, "beta")), {$: "application-v2.Slot", "reader": _reader_0, "private": array_node([501], [502])});
  } else {
    return {$: "None"};
  }
}

function $application$045v2$058register$1261$(_runtime_0, _keys_0, _name_0) {
  return $runtime$045v2$058register$1261$(_runtime_0, _keys_0, _name_0, {$: "Nil"});
}

function $runtime$045v2$058start$1261$(_world_0) {
  return {$: "runtime-v2.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047application$058activated$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $$$$047application$058empty$1261$(__0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1261$({$: "../application.CellOwners", "left": array_node([11], [12]), "right": array_node([21], [22])});
}

function $schedule_built$1260$(_built_0, _world_0) {
  if (_built_0.$ === "../../../../src/ecs/schedule.Invalid") {
    return {$: "Scheduled", "final": {$: "None"}, "observations": {$: "Nil"}};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return $schedule_finished$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_with_skip$1260$(_schedule_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $snapshot$1260$(_runtime_0, _alphaPrivate_0, _betaPrivate_0, _bothPrivate_0, _deliveries_0) {
  const _t_0 = _runtime_0["world"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _t_1 = _t_0["store"];
  const _t_2 = _t_1["components"];
  const _left_0 = _t_2["left"];
  const _right_0 = _t_2["right"];
  const _graph_0 = _t_1["graph"];
  const _t_3 = _t_0["resource"];
  const _baseline_0 = _t_3["baseline"];
  const _returned_0 = _t_3["returned"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _retentionCapacity_0 = _runtime_0["capacity"];
  return {$: "Some", "value": {$: "observe-v2.Final", "deliveries": ($List$reverse$(_deliveries_0)), "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "retentionCapacity": _retentionCapacity_0, "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": ($bool_cells$(_live_0)), "capacity": _capacity_0, "depth": _depth_0, "left": ($$$$047driven$058cells$(_left_0)), "right": ($$$$047driven$058cells$(_right_0)), "graph": _graph_0, "baseline": ($$$$047driven$058cells$(_baseline_0)), "returned": ($mailbox$1260$(_returned_0)), "events": _events_0, "pendingCount": ($pending_count$1260$(_pending_0, 0)), "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0, "alphaPrivate": _alphaPrivate_0, "betaPrivate": _betaPrivate_0, "bothPrivate": _bothPrivate_0}};
}

function $disposal$058identified$1260$(_runtime_0, _identity_0, _keys_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identity_0["fst"];
  const _id_0 = _identity_0["snd"];
  return $disposal$058completed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose$1260$(_registry_0, _world_0)), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $schedule_built$1261$(_built_0, _world_0) {
  if (_built_0.$ === "../../../../src/ecs/schedule.Invalid") {
    return {$: "Scheduled", "final": {$: "None"}, "observations": {$: "Nil"}};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return $schedule_finished$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_with_skip$1261$(_schedule_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build$1261$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $snapshot$1261$(_runtime_0, _alphaPrivate_0, _betaPrivate_0, _bothPrivate_0, _deliveries_0) {
  const _t_0 = _runtime_0["world"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _t_1 = _t_0["store"];
  const _t_2 = _t_1["components"];
  const _left_0 = _t_2["left"];
  const _right_0 = _t_2["right"];
  const _graph_0 = _t_1["graph"];
  const _t_3 = _t_0["resource"];
  const _baseline_0 = _t_3["baseline"];
  const _returned_0 = _t_3["returned"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _retentionCapacity_0 = _runtime_0["capacity"];
  return {$: "Some", "value": {$: "observe-v2.Final", "deliveries": ($List$reverse$(_deliveries_0)), "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "retentionCapacity": _retentionCapacity_0, "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": ($bool_cells$(_live_0)), "capacity": _capacity_0, "depth": _depth_0, "left": ($$$$047driven$058cells$(_left_0)), "right": ($$$$047driven$058cells$(_right_0)), "graph": _graph_0, "baseline": ($$$$047driven$058cells$(_baseline_0)), "returned": ($mailbox$1261$(_returned_0)), "events": _events_0, "pendingCount": ($pending_count$1261$(_pending_0, 0)), "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0, "alphaPrivate": _alphaPrivate_0, "betaPrivate": _betaPrivate_0, "bothPrivate": _bothPrivate_0}};
}

function $disposal$058identified$1261$(_runtime_0, _identity_0, _keys_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identity_0["fst"];
  const _id_0 = _identity_0["snd"];
  return $disposal$058completed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose$1261$(_registry_0, _world_0)), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $application$045v2$058restore$1260$(_done_0, _first_0, _second_0, _deliveries_0) {
  if (_done_0.$ === "Some") {
    const _t_0 = _done_0["value"];
    const _runtime_0 = _t_0["fst"];
    const _t_1 = _t_0["snd"];
    const _last_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": {$: "application-v2.WideApp", "runtime": _runtime_0, "alpha": _first_0, "beta": _second_0, "both": _last_0, "deliveries": {$: "Con", "head": _readings_0, "tail": _deliveries_0}}};
  } else {
    return {$: "None"};
  }
}

function $application$045v2$058completed$1260$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "runtime-v2.Succeeded") {
    const _t_1 = _t_0["output"];
    const _private_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": {$: "Tuple", "fst": _runtime_0, "snd": {$: "Tuple", "fst": {$: "application-v2.Slot", "reader": _reader_0, "private": _private_0}, "snd": _readings_0}}};
  } else {
    return {$: "None"};
  }
}

function $application$045v2$058run_slot$1260$(_runtime_0, _slot_0) {
  const _reader_0 = _slot_0["reader"];
  const _private_0 = _slot_0["private"];
  return $runtime$045v2$058run$1260$(_runtime_0, _reader_0, _private_0);
}

function $$$$047domains$058trim$1260$(_domains_0, _positions_0, _fallback_0, _capacity_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _domain_0 = _domains_0["head"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": ($$$$047domains$058trim_domain$1260$(_domain_0, _positions_0, _fallback_0, _capacity_0)), "tail": ($$$$047domains$058trim$1260$(_rest_0, _positions_0, _fallback_0, _capacity_0))};
  }
}

function $runtime$045v2$058barrier_join$1260$(_state_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $barrier$058barrier$1260$(_world_0, _domains_0) {
  return $barrier$058opened$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)), _domains_0);
}

function $runtime$045v2$058with_world_collected$1260$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $$$$047routing$058collect$1260$(_world_0, _tick_0, _domains_0) {
  return $$$$047routing$058collect_view$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _tick_0, _domains_0);
}

function $application$045v2$058queue_alpha$1260$(_result_0, _namespace_0, _count_0) {
  const _world_0 = _result_0["fst"];
  return $application$045v2$058queue_loop$1260$(_count_0, _world_0, _namespace_0, 1000);
}

function $$$$047application$058queue$1260$(_descriptor_0, _source_0, _target_0, _world_0) {
  return $$$$047application$058queued$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), _descriptor_0, _source_0, _target_0)));
}

function $$$$047application$058descriptor$1260$(_key_0) {
  if (_key_0 == 1) {
    return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
  } else {
    return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 2, "name": "ParentB", "inverseName": "ChildrenB", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
  }
}

function $application$045v2$058second$1260$(_registered_0, _alpha_0) {
  if (_registered_0.$ === "runtime-v2.Registered") {
    const _runtime_0 = _registered_0["runtime"];
    const _reader_0 = _registered_0["reader"];
    return $application$045v2$058third$1260$(($application$045v2$058register$1260$(_runtime_0, {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 1}, "tail": {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 2}, "tail": {$: "Nil"}}}, "both")), _alpha_0, {$: "application-v2.Slot", "reader": _reader_0, "private": array_node([601], [602])});
  } else {
    return {$: "None"};
  }
}

function $runtime$045v2$058register$1260$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v2$058registered_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1260$(_components_0) {
  return {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $application$045v2$058restore$1261$(_done_0, _first_0, _second_0, _deliveries_0) {
  if (_done_0.$ === "Some") {
    const _t_0 = _done_0["value"];
    const _runtime_0 = _t_0["fst"];
    const _t_1 = _t_0["snd"];
    const _last_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": {$: "application-v2.WideApp", "runtime": _runtime_0, "alpha": _first_0, "beta": _second_0, "both": _last_0, "deliveries": {$: "Con", "head": _readings_0, "tail": _deliveries_0}}};
  } else {
    return {$: "None"};
  }
}

function $application$045v2$058completed$1261$(_result_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "runtime-v2.Succeeded") {
    const _t_1 = _t_0["output"];
    const _private_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": {$: "Tuple", "fst": _runtime_0, "snd": {$: "Tuple", "fst": {$: "application-v2.Slot", "reader": _reader_0, "private": _private_0}, "snd": _readings_0}}};
  } else {
    return {$: "None"};
  }
}

function $application$045v2$058run_slot$1261$(_runtime_0, _slot_0) {
  const _reader_0 = _slot_0["reader"];
  const _private_0 = _slot_0["private"];
  return $runtime$045v2$058run$1261$(_runtime_0, _reader_0, _private_0);
}

function $$$$047domains$058trim$1261$(_domains_0, _positions_0, _fallback_0, _capacity_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _domain_0 = _domains_0["head"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": ($$$$047domains$058trim_domain$1261$(_domain_0, _positions_0, _fallback_0, _capacity_0)), "tail": ($$$$047domains$058trim$1261$(_rest_0, _positions_0, _fallback_0, _capacity_0))};
  }
}

function $runtime$045v2$058barrier_join$1261$(_state_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $barrier$058barrier$1261$(_world_0, _domains_0) {
  return $barrier$058opened$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)), _domains_0);
}

function $runtime$045v2$058with_world_collected$1261$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $$$$047routing$058collect$1261$(_world_0, _tick_0, _domains_0) {
  return $$$$047routing$058collect_view$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _tick_0, _domains_0);
}

function $application$045v2$058queue_alpha$1261$(_result_0, _namespace_0, _count_0) {
  const _world_0 = _result_0["fst"];
  return $application$045v2$058queue_loop$1261$(_count_0, _world_0, _namespace_0, 1000);
}

function $$$$047application$058queue$1261$(_descriptor_0, _source_0, _target_0, _world_0) {
  return $$$$047application$058queued$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), _descriptor_0, _source_0, _target_0)));
}

function $$$$047application$058descriptor$1261$(_key_0) {
  if (_key_0 == 1) {
    return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
  } else {
    return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 2, "name": "ParentB", "inverseName": "ChildrenB", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
  }
}

function $application$045v2$058second$1261$(_registered_0, _alpha_0) {
  if (_registered_0.$ === "runtime-v2.Registered") {
    const _runtime_0 = _registered_0["runtime"];
    const _reader_0 = _registered_0["reader"];
    return $application$045v2$058third$1261$(($application$045v2$058register$1261$(_runtime_0, {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 1}, "tail": {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 2}, "tail": {$: "Nil"}}}, "both")), _alpha_0, {$: "application-v2.Slot", "reader": _reader_0, "private": array_node([601], [602])});
  } else {
    return {$: "None"};
  }
}

function $runtime$045v2$058register$1261$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v2$058registered_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1261$(_components_0) {
  return {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $schedule_finished$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _t_1 = _t_0["owners"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _frameStart_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _capacity_0 = _t_1["capacity"];
    const _alpha_0 = _t_1["alpha"];
    const _beta_0 = _t_1["beta"];
    const _both_0 = _t_1["both"];
    const _deliveries_0 = _t_1["deliveries"];
    const _world_0 = _result_0["world"];
    const _observations_0 = _result_0["observations"];
    return {$: "Scheduled", "final": ($observe$045v2$058observed$1260$({$: "Some", "value": {$: "application-v2.WideApp", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "alpha": _alpha_0, "beta": _beta_0, "both": _both_0, "deliveries": _deliveries_0}})), "observations": _observations_0};
  } else if (_result_0.$ === "../../../../src/ecs/schedule.Failed") {
    const _observations_1 = _result_0["observations"];
    return {$: "Scheduled", "final": {$: "None"}, "observations": _observations_1};
  } else {
    return {$: "Scheduled", "final": {$: "None"}, "observations": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_with_skip$1260$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_namespace_skip$1260$(_schedule_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../src/ecs/schedule.Built", "schedule": {$: "../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $mailbox$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["private"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": ($$$$047driven$058cells$(_owner_0)), "tail": ($mailbox$1260$(_rest_0))};
  }
}

function $pending_count$1260$($0, $1) {
  for (;;) {
    {
      const _pending_0 = $0;
      const _acc_0 = $1;
      if (_pending_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _pending_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $disposal$058completed$1260$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.Disposed") {
    const _world_0 = _result_0["world"];
    return {$: "disposal.ReaderDisposed", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": ($disposal$058release$1260$(_domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, true)), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "disposal.ReaderDisposalRejected", "runtime": {$: "runtime-v2.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose$1260$(_registry_0, _world_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose_returned$1260$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove$1260$(_world_0, _namespace_0, _id_0, _name_0, _access_0)));
}

function $schedule_finished$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _t_1 = _t_0["owners"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _frameStart_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _capacity_0 = _t_1["capacity"];
    const _alpha_0 = _t_1["alpha"];
    const _beta_0 = _t_1["beta"];
    const _both_0 = _t_1["both"];
    const _deliveries_0 = _t_1["deliveries"];
    const _world_0 = _result_0["world"];
    const _observations_0 = _result_0["observations"];
    return {$: "Scheduled", "final": ($observe$045v2$058observed$1261$({$: "Some", "value": {$: "application-v2.WideApp", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "alpha": _alpha_0, "beta": _beta_0, "both": _both_0, "deliveries": _deliveries_0}})), "observations": _observations_0};
  } else if (_result_0.$ === "../../../../src/ecs/schedule.Failed") {
    const _observations_1 = _result_0["observations"];
    return {$: "Scheduled", "final": {$: "None"}, "observations": _observations_1};
  } else {
    return {$: "Scheduled", "final": {$: "None"}, "observations": {$: "Nil"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_with_skip$1261$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_namespace_skip$1261$(_schedule_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1261$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../../src/ecs/schedule.Built", "schedule": {$: "../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $mailbox$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["private"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": ($$$$047driven$058cells$(_owner_0)), "tail": ($mailbox$1261$(_rest_0))};
  }
}

function $pending_count$1261$($0, $1) {
  for (;;) {
    {
      const _pending_0 = $0;
      const _acc_0 = $1;
      if (_pending_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _pending_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $disposal$058completed$1261$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.Disposed") {
    const _world_0 = _result_0["world"];
    return {$: "disposal.ReaderDisposed", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": ($disposal$058release$1261$(_domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, true)), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "disposal.ReaderDisposalRejected", "runtime": {$: "runtime-v2.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose$1261$(_registry_0, _world_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose_returned$1261$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove$1261$(_world_0, _namespace_0, _id_0, _name_0, _access_0)));
}

function $runtime$045v2$058run$1260$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $runtime$045v2$058run_identified$1260$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _keys_0, _args_0);
}

function $$$$047domains$058trim_domain$1260$(_domain_0, _positions_0, _fallback_0, _capacity_0) {
  const _key_0 = _domain_0["key"];
  const _queue_0 = _domain_0["queue"];
  const _ids_0 = _domain_0["readers"];
  return {$: "../domains.Domain", "key": _key_0, "queue": run_loop($$$$047queue$058trim$1260$(_queue_0, ($$$$047domains$058boundary$(_positions_0, _ids_0, _fallback_0)), _capacity_0)), "readers": _ids_0};
}

function $barrier$058opened$1260$(_advanced_0, _domains_0) {
  const _t_0 = _advanced_0["fst"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _tick_0 = _advanced_0["snd"];
  return $barrier$058drain$1260$(($List$reverse$(_pending_0)), {$: "barrier.BarrierState", "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "tick": _tick_0});
}

function $$$$047routing$058collect_view$1260$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047routing$058collected$1260$(_world_0, ($$$$047routing$058partition_loop$1260$(_items_0, {$: "../routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $application$045v2$058queue_loop$1260$(_count_0, _world_0, _namespace_0, _target_0) {
  if (_count_0 === 0) {
    return _world_0;
  } else {
    const _rest_0 = (_count_0 - 1);
    return $application$045v2$058queue_result$1260$(($$$$047application$058queue$1260$(($$$$047application$058descriptor$1260$(2)), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _target_0}, _world_0)), run_clo((_x_0) => {
  return $application$045v2$058queue_loop$1260$(_rest_0, _x_0, _namespace_0, ((_target_0 + 1) >>> 0));
}));
  }
}

function $$$$047application$058queued$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $$$$047application$058queue_finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../../src/ecs/transaction.Success"})), _status_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $application$045v2$058third$1260$(_registered_0, _alpha_0, _beta_0) {
  if (_registered_0.$ === "runtime-v2.Registered") {
    const _runtime_0 = _registered_0["runtime"];
    const _reader_0 = _registered_0["reader"];
    return {$: "Some", "value": {$: "application-v2.WideApp", "runtime": _runtime_0, "alpha": _alpha_0, "beta": _beta_0, "both": {$: "application-v2.Slot", "reader": _reader_0, "private": array_node([701], [702])}, "deliveries": {$: "Nil"}}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v2$058registered_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "runtime-v2.RegistrationFailed", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "runtime-v2.Registered", "runtime": {$: "runtime-v2.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $runtime$045v2$058run$1261$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $runtime$045v2$058run_identified$1261$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0)), _keys_0, _args_0);
}

function $$$$047domains$058trim_domain$1261$(_domain_0, _positions_0, _fallback_0, _capacity_0) {
  const _key_0 = _domain_0["key"];
  const _queue_0 = _domain_0["queue"];
  const _ids_0 = _domain_0["readers"];
  return {$: "../domains.Domain", "key": _key_0, "queue": run_loop($$$$047queue$058trim$1261$(_queue_0, ($$$$047domains$058boundary$(_positions_0, _ids_0, _fallback_0)), _capacity_0)), "readers": _ids_0};
}

function $barrier$058opened$1261$(_advanced_0, _domains_0) {
  const _t_0 = _advanced_0["fst"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _tick_0 = _advanced_0["snd"];
  return $barrier$058drain$1261$(($List$reverse$(_pending_0)), {$: "barrier.BarrierState", "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "tick": _tick_0});
}

function $$$$047routing$058collect_view$1261$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047routing$058collected$1261$(_world_0, ($$$$047routing$058partition_loop$1261$(_items_0, {$: "../routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $application$045v2$058queue_loop$1261$(_count_0, _world_0, _namespace_0, _target_0) {
  if (_count_0 === 0) {
    return _world_0;
  } else {
    const _rest_0 = (_count_0 - 1);
    return $application$045v2$058queue_result$1261$(($$$$047application$058queue$1261$(($$$$047application$058descriptor$1261$(2)), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _target_0}, _world_0)), run_clo((_x_0) => {
  return $application$045v2$058queue_loop$1261$(_rest_0, _x_0, _namespace_0, ((_target_0 + 1) >>> 0));
}));
  }
}

function $$$$047application$058queued$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $$$$047application$058queue_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../../../src/ecs/transaction.Success"})), _status_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $application$045v2$058third$1261$(_registered_0, _alpha_0, _beta_0) {
  if (_registered_0.$ === "runtime-v2.Registered") {
    const _runtime_0 = _registered_0["runtime"];
    const _reader_0 = _registered_0["reader"];
    return {$: "Some", "value": {$: "application-v2.WideApp", "runtime": _runtime_0, "alpha": _alpha_0, "beta": _beta_0, "both": {$: "application-v2.Slot", "reader": _reader_0, "private": array_node([701], [702])}, "deliveries": {$: "Nil"}}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v2$058registered_result$1261$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "runtime-v2.RegistrationFailed", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "runtime-v2.Registered", "runtime": {$: "runtime-v2.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_namespace_skip$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_actual_skip$1260$(_schedule_0, _world_0, _actual_0);
}

function $disposal$058release$1260$(_domains_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($disposal$058remove$(_ids_0, _id_0))}, "tail": ($disposal$058release$1260$(_rest_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose_returned$1260$(_registry_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0) {
    return {$: "../../../../src/ecs/system.Disposed", "world": _world_0};
  } else {
    return {$: "../../../../src/ecs/system.DisposalRejected", "world": _world_0, "registry": _registry_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove$1260$(_world_0, _namespace_0, _id_0, _name_0, _access_0) {
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove_checked$1260$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../../src/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _id_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_namespace_skip$1261$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_actual_skip$1261$(_schedule_0, _world_0, _actual_0);
}

function $disposal$058release$1261$(_domains_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($disposal$058remove$(_ids_0, _id_0))}, "tail": ($disposal$058release$1261$(_rest_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058dispose_returned$1261$(_registry_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0) {
    return {$: "../../../../src/ecs/system.Disposed", "world": _world_0};
  } else {
    return {$: "../../../../src/ecs/system.DisposalRejected", "world": _world_0, "registry": _registry_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove$1261$(_world_0, _namespace_0, _id_0, _name_0, _access_0) {
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove_checked$1261$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../../src/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _id_0, _name_0, _access_0);
}

function $runtime$045v2$058run_identified$1260$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $runtime$045v2$058run_result$1260$(($runtime$045v2$058run_clocked$1260$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)), {$: "runtime-v2.Input", "readings": ($$$$047readings$058all$1260$(_keys_0, _domains_0, ($runtime$045v2$058position_or$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047queue$058trim$1260$(_queue_0, _boundary_0, _capacity_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return $$$$047queue$058trim_loop$1260$(nat_chk(_size_0 + 1), {$: "../queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _boundary_0, _capacity_0);
}

function $barrier$058drain$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _state_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($barrier$058command_collected$1260$(_command_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047routing$058collected$1260$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047routing$058publish_batches$1260$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047routing$058partition_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047routing$058partition_selected$1260$(($$$$047application$058classify$1260$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $application$045v2$058queue_result$1260$(_result_0, _ih_0) {
  const _world_0 = _result_0["fst"];
  return run_tail(_ih_0, _world_0);
}

function $$$$047application$058queue_finish$1260$(_result_0, _status_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $runtime$045v2$058run_identified$1261$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $runtime$045v2$058run_result$1261$(($runtime$045v2$058run_clocked$1261$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)), {$: "runtime-v2.Input", "readings": ($$$$047readings$058all$1261$(_keys_0, _domains_0, ($runtime$045v2$058position_or$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047queue$058trim$1261$(_queue_0, _boundary_0, _capacity_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return $$$$047queue$058trim_loop$1261$(nat_chk(_size_0 + 1), {$: "../queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _boundary_0, _capacity_0);
}

function $barrier$058drain$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _state_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($barrier$058command_collected$1261$(_command_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047routing$058collected$1261$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047routing$058publish_batches$1261$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047routing$058partition_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047routing$058partition_selected$1261$(($$$$047application$058classify$1261$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $application$045v2$058queue_result$1261$(_result_0, _ih_0) {
  const _world_0 = _result_0["fst"];
  return run_tail(_ih_0, _world_0);
}

function $$$$047application$058queue_finish$1261$(_result_0, _status_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_actual_skip$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_checked_skip$1260$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove_checked$1260$(_allowed_0, _world_0, _id_0, _name_0, _access_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": ($$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0)), "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_actual_skip$1261$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_checked_skip$1261$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058remove_checked$1261$(_allowed_0, _world_0, _id_0, _name_0, _access_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": ($$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0)), "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": true};
  }
}

function $runtime$045v2$058run_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "runtime-v2.Ran", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v2.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $runtime$045v2$058outcome$1260$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $runtime$045v2$058run_clocked$1260$(_registry_0, _advanced_0, _input_0) {
  const _world_0 = _advanced_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _input_0);
}

function $$$$047readings$058all$1260$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047readings$058one$1260$(_domains_0, _key_0, _position_0)), "tail": ($$$$047readings$058all$1260$(_rest_0, _domains_0, _position_0))};
  }
}

function $$$$047queue$058trim_loop$1260$(_fuel_0, _queue_0, _boundary_0, _capacity_0) {
  if (_fuel_0 === 0) {
    return _queue_0;
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047queue$058trim_normalized$1260$(($$$$047queue$058normalize$1260$(_queue_0)), _boundary_0, _capacity_0, run_clo((_x_0) => {
  return $$$$047queue$058trim_loop$1260$(_rest_0, _x_0, _boundary_0, _capacity_0);
}));
  }
}

function $barrier$058command_collected$1260$(_command_0, _state_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return $barrier$058collected$1260$(($$$$047routing$058collect$1260$(_command_0(_world_0), _tick_0, _domains_0)), _tick_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047routing$058publish_batches$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047routing$058publish_one$1260$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047routing$058partition_selected$1260$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047routing$058group$1260$(_batches_0, _wanted_0, _item_0))};
  }
}

function $$$$047application$058classify$1260$(_notice_0) {
  if (_notice_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    return {$: "Some", "value": {$: "../domains.DeclaredKey", "id": _key_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $runtime$045v2$058run_result$1261$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "runtime-v2.Ran", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v2.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $runtime$045v2$058outcome$1261$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $runtime$045v2$058run_clocked$1261$(_registry_0, _advanced_0, _input_0) {
  const _world_0 = _advanced_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _input_0);
}

function $$$$047readings$058all$1261$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047readings$058one$1261$(_domains_0, _key_0, _position_0)), "tail": ($$$$047readings$058all$1261$(_rest_0, _domains_0, _position_0))};
  }
}

function $$$$047queue$058trim_loop$1261$(_fuel_0, _queue_0, _boundary_0, _capacity_0) {
  if (_fuel_0 === 0) {
    return _queue_0;
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $$$$047queue$058trim_normalized$1261$(($$$$047queue$058normalize$1261$(_queue_0)), _boundary_0, _capacity_0, run_clo((_x_0) => {
  return $$$$047queue$058trim_loop$1261$(_rest_0, _x_0, _boundary_0, _capacity_0);
}));
  }
}

function $barrier$058command_collected$1261$(_command_0, _state_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return $barrier$058collected$1261$(($$$$047routing$058collect$1261$(_command_0(_world_0), _tick_0, _domains_0)), _tick_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047routing$058publish_batches$1261$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047routing$058publish_one$1261$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047routing$058partition_selected$1261$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047routing$058group$1261$(_batches_0, _wanted_0, _item_0))};
  }
}

function $$$$047application$058classify$1261$(_notice_0) {
  if (_notice_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    return {$: "Some", "value": {$: "../domains.DeclaredKey", "id": _key_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_checked_skip$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute_skip$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058run_checked_skip$1261$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute_skip$1261$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $runtime$045v2$058outcome$1260$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "runtime-v2.Ran", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": ($$$$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "tick": nat_chk(_tick_0 + 1), "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v2.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $runtime$045v2$058succeeded_collected$1260$(($$$$047routing$058collect$1260$(_world_1, nat_chk(_tick_0 + 1), ($$$$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), _id_0, nat_chk(_tick_0 + 1), false)), nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047readings$058one$1260$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047readings$058select$1260$(($$$$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047readings$058one$1260$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $$$$047queue$058trim_normalized$1260$(_queue_0, _boundary_0, _capacity_0, _ih_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "../queue.Queue", "front": {$: "Nil"}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _t_1 = _t_0["head"];
    const _tick_0 = _t_1["tick"];
    const _count_0 = _t_1["count"];
    const _items_0 = _t_1["values"];
    const _rest_0 = _t_0["tail"];
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    const _x_0 = ($Nat$is_le$(_tick_0, _boundary_0));
    const _x_1 = (_capacity_0 < _size_1);
    return $$$$047queue$058trim_step$1260$((_x_0 || _x_1), _tick_0, _count_0, _items_0, _rest_0, _back_1, _size_1, _dropped_1, _ih_0);
  }
}

function $$$$047queue$058normalize$1260$(_queue_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "../queue.Queue", "front": ($List$reverse$(_back_0)), "back": {$: "Nil"}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    return {$: "../queue.Queue", "front": _t_0, "back": _back_1, "size": _size_1, "dropped": _dropped_1};
  }
}

function $barrier$058collected$1260$(_joined_0, _tick_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "barrier.BarrierState", "world": _world_0, "domains": _domains_0, "tick": _tick_0};
}

function $$$$047routing$058publish_one$1260$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _wanted_0, "queue": ($$$$047queue$058publish$1260$(($$$$047queue$058empty$1260$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047routing$058publish_found$1260$(($$$$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047routing$058publish_one$1260$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047routing$058group$1260$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047routing$058group_found$1260$(($$$$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047routing$058group$1260$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $runtime$045v2$058outcome$1261$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "runtime-v2.Ran", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": ($$$$047readings$058activate$1261$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "tick": nat_chk(_tick_0 + 1), "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v2.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $runtime$045v2$058succeeded_collected$1261$(($$$$047routing$058collect$1261$(_world_1, nat_chk(_tick_0 + 1), ($$$$047readings$058activate$1261$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), _id_0, nat_chk(_tick_0 + 1), false)), nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $$$$047readings$058one$1261$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047readings$058select$1261$(($$$$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047readings$058one$1261$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $$$$047queue$058trim_normalized$1261$(_queue_0, _boundary_0, _capacity_0, _ih_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "../queue.Queue", "front": {$: "Nil"}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _t_1 = _t_0["head"];
    const _tick_0 = _t_1["tick"];
    const _count_0 = _t_1["count"];
    const _items_0 = _t_1["values"];
    const _rest_0 = _t_0["tail"];
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    const _x_0 = ($Nat$is_le$(_tick_0, _boundary_0));
    const _x_1 = (_capacity_0 < _size_1);
    return $$$$047queue$058trim_step$1261$((_x_0 || _x_1), _tick_0, _count_0, _items_0, _rest_0, _back_1, _size_1, _dropped_1, _ih_0);
  }
}

function $$$$047queue$058normalize$1261$(_queue_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "../queue.Queue", "front": ($List$reverse$(_back_0)), "back": {$: "Nil"}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    return {$: "../queue.Queue", "front": _t_0, "back": _back_1, "size": _size_1, "dropped": _dropped_1};
  }
}

function $barrier$058collected$1261$(_joined_0, _tick_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "barrier.BarrierState", "world": _world_0, "domains": _domains_0, "tick": _tick_0};
}

function $$$$047routing$058publish_one$1261$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _wanted_0, "queue": ($$$$047queue$058publish$1261$(($$$$047queue$058empty$1261$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047routing$058publish_found$1261$(($$$$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047routing$058publish_one$1261$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047routing$058group$1261$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047routing$058group_found$1261$(($$$$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047routing$058group$1261$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute_skip$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../src/ecs/schedule.Finished", "schedule": {$: "../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_condition_skip$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute_skip$1260$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($false_condition$1260$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute_skip$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../../src/ecs/schedule.Finished", "schedule": {$: "../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _owners_0;
          $2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0));
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}}));
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_condition_skip$1261$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058execute_skip$1261$(_rest_2, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($false_condition$1261$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047readings$058activate$1260$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047domains$058activate_one$1260$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $runtime$045v2$058succeeded_collected$1260$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "runtime-v2.Ran", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v2.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047readings$058select$1260$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047domains$058key_equal$1260$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $$$$047queue$058trim_step$1260$(_remove_0, _tick_0, _count_0, _items_0, _rest_0, _back_0, _size_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../queue.Queue", "front": {$: "Con", "head": {$: "../queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _rest_0}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, {$: "../queue.Queue", "front": _rest_0, "back": _back_0, "size": (_size_0 < _count_0 ? 0 : _size_0 - _count_0), "dropped": (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0)});
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $$$$047queue$058publish$1260$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047queue$058count_loop$1260$(_items_0, 0));
  return $$$$047queue$058publish_checked$1260$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047queue$058count_loop$1260$(_items_0, 0)));
}

function $$$$047queue$058empty$1260$() {
  return {$: "../queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047routing$058publish_found$1260$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": ($$$$047queue$058publish$1260$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047routing$058group_found$1260$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047readings$058activate$1261$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047domains$058activate_one$1261$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $runtime$045v2$058succeeded_collected$1261$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "runtime-v2.Ran", "runtime": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v2.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047readings$058select$1261$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047readings$058queue_reading$1261$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047domains$058key_equal$1261$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $$$$047queue$058trim_step$1261$(_remove_0, _tick_0, _count_0, _items_0, _rest_0, _back_0, _size_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "../queue.Queue", "front": {$: "Con", "head": {$: "../queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _rest_0}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, {$: "../queue.Queue", "front": _rest_0, "back": _back_0, "size": (_size_0 < _count_0 ? 0 : _size_0 - _count_0), "dropped": (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0)});
  }
}

function $$$$047queue$058publish$1261$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047queue$058count_loop$1261$(_items_0, 0));
  return $$$$047queue$058publish_checked$1261$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047queue$058count_loop$1261$(_items_0, 0)));
}

function $$$$047queue$058empty$1261$() {
  return {$: "../queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047routing$058publish_found$1261$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": ($$$$047queue$058publish$1261$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047routing$058group_found$1261$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_pending_0, {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_condition_skip$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058conditioned_skip$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $false_condition$1260$(_world_0, __0) {
  return {$: "Tuple", "fst": _world_0, "snd": false};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058barrier$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_pending_0, {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_condition_skip$1261$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058conditioned_skip$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $false_condition$1261$(_world_0, __0) {
  return {$: "Tuple", "fst": _world_0, "snd": false};
}

function $$$$047domains$058activate_one$1260$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _wanted_0, "queue": ($$$$047queue$058empty$1260$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047domains$058activate_walk$1260$(($$$$047domains$058key_equal$1260$(_key_0, _wanted_0)), {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047domains$058activate_one$1260$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../readings.KeyReading", "key": _key_0, "values": ($$$$047queue$058read$1260$({$: "../queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $$$$047queue$058publish_checked$1260$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047queue$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047domains$058activate_one$1261$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _wanted_0, "queue": ($$$$047queue$058empty$1261$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047domains$058activate_walk$1261$(($$$$047domains$058key_equal$1261$(_key_0, _wanted_0)), {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047domains$058activate_one$1261$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047readings$058queue_reading$1261$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../readings.KeyReading", "key": _key_0, "values": ($$$$047queue$058read$1261$({$: "../queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047queue$058publish_checked$1261$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047queue$058publish_nonempty$1261$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047queue$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1260$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058conditioned_skip$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_skip$1260$(_next_0, ($registered_skip$1260$(_owners_0, _world_0, _id_0)), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($unexpected_dispatch$1260$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_commands_0, _world_0) {
  if (_commands_0.$ === "Nil") {
    return _world_0;
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return run_tail(_command_0, run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058drain_fifo$1261$(_rest_0, _world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058conditioned_skip$1261$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_skip$1261$(_next_0, ($registered_skip$1261$(_owners_0, _world_0, _id_0)), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, ($unexpected_dispatch$1261$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047domains$058activate_walk$1260$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047domains$058activate_domain$1260$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047queue$058read$1260$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0);
}

function $$$$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047domains$058activate_walk$1261$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047domains$058activate_domain$1261$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047queue$058read$1261$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047queue$058read_back$1261$(_front_0, _back_0, _cursor_0);
}

function $$$$047queue$058publish_nonempty$1261$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_skip$1260$(_next_0, _returned_0, _observations_0) {
  const _owners_0 = _returned_0["fst"];
  const _world_0 = _returned_0["snd"];
  return run_tail(_next_0(_owners_0)(_world_0), _observations_0);
}

function $registered_skip$1260$(_owners_0, _world_0, __0) {
  const _domains_0 = _owners_0["domains"];
  const _positions_0 = _owners_0["positions"];
  const _tick_0 = _owners_0["tick"];
  const _frameStart_0 = _owners_0["frameStart"];
  const _boundary_0 = _owners_0["boundary"];
  const _capacity_0 = _owners_0["capacity"];
  const _t_0 = _owners_0["alpha"];
  const _reader_0 = _t_0["reader"];
  const _private_0 = _t_0["private"];
  const _beta_0 = _owners_0["beta"];
  const _both_0 = _owners_0["both"];
  const _deliveries_0 = _owners_0["deliveries"];
  return $skip_rejoined$1260$(($runtime$045v2$058skip$1260$({$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, _reader_0)), _private_0, _beta_0, _both_0, _deliveries_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $unexpected_dispatch$1260$(_owners_0, _world_0, __0) {
  return {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": 999}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_skip$1261$(_next_0, _returned_0, _observations_0) {
  const _owners_0 = _returned_0["fst"];
  const _world_0 = _returned_0["snd"];
  return run_tail(_next_0(_owners_0)(_world_0), _observations_0);
}

function $registered_skip$1261$(_owners_0, _world_0, __0) {
  const _domains_0 = _owners_0["domains"];
  const _positions_0 = _owners_0["positions"];
  const _tick_0 = _owners_0["tick"];
  const _frameStart_0 = _owners_0["frameStart"];
  const _boundary_0 = _owners_0["boundary"];
  const _capacity_0 = _owners_0["capacity"];
  const _t_0 = _owners_0["alpha"];
  const _reader_0 = _t_0["reader"];
  const _private_0 = _t_0["private"];
  const _beta_0 = _owners_0["beta"];
  const _both_0 = _owners_0["both"];
  const _deliveries_0 = _owners_0["deliveries"];
  return $skip_rejoined$1261$(($runtime$045v2$058skip$1261$({$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, _reader_0)), _private_0, _beta_0, _both_0, _deliveries_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1261$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $unexpected_dispatch$1261$(_owners_0, _world_0, __0) {
  return {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": 999}};
}

function $$$$047domains$058activate_domain$1260$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047queue$058read_loop$1260$(($List$reverse$(_back_0)), _cursor_0, ($$$$047queue$058read_loop$1260$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047domains$058activate_domain$1261$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047queue$058read_back$1261$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047queue$058read_loop$1261$(($List$reverse$(_back_0)), _cursor_0, ($$$$047queue$058read_loop$1261$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $skip_rejoined$1260$(_joined_0, _private_0, _beta_0, _both_0, _deliveries_0) {
  const _t_0 = _joined_0["fst"];
  const _world_0 = _t_0["world"];
  const _domains_0 = _t_0["domains"];
  const _positions_0 = _t_0["positions"];
  const _tick_0 = _t_0["tick"];
  const _frameStart_0 = _t_0["frameStart"];
  const _boundary_0 = _t_0["boundary"];
  const _capacity_0 = _t_0["capacity"];
  const _reader_0 = _joined_0["snd"];
  return {$: "Tuple", "fst": {$: "Owners", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "alpha": {$: "application-v2.Slot", "reader": _reader_0, "private": _private_0}, "beta": _beta_0, "both": _both_0, "deliveries": _deliveries_0}, "snd": _world_0};
}

function $runtime$045v2$058skip$1260$(_runtime_0, _reader_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v2$058skip_named$1260$(_reader_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/schedule.Failed", "schedule": {$: "../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $skip_rejoined$1261$(_joined_0, _private_0, _beta_0, _both_0, _deliveries_0) {
  const _t_0 = _joined_0["fst"];
  const _world_0 = _t_0["world"];
  const _domains_0 = _t_0["domains"];
  const _positions_0 = _t_0["positions"];
  const _tick_0 = _t_0["tick"];
  const _frameStart_0 = _t_0["frameStart"];
  const _boundary_0 = _t_0["boundary"];
  const _capacity_0 = _t_0["capacity"];
  const _reader_0 = _joined_0["snd"];
  return {$: "Tuple", "fst": {$: "Owners", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "alpha": {$: "application-v2.Slot", "reader": _reader_0, "private": _private_0}, "beta": _beta_0, "both": _both_0, "deliveries": _deliveries_0}, "snd": _world_0};
}

function $runtime$045v2$058skip$1261$(_runtime_0, _reader_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v2$058skip_named$1261$(_reader_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1261$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/schedule.Failed", "schedule": {$: "../../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($application$045v2$058body$1260$(_world_0, _args_0)));
  }
}

function $$$$047queue$058read_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047queue$058visible_items$1260$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($application$045v2$058body$1261$(_world_0, _args_0)));
  }
}

function $$$$047queue$058read_loop$1261$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047queue$058visible_items$1261$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(($List$length$(_edges_0)), {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $runtime$045v2$058skip_named$1260$(_reader_0, _named_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _t_0 = _reader_0["registry"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _keys_0 = _reader_0["keys"];
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $runtime$045v2$058skip_namespace$1260$((_namespace_0 === _actual_0), _world_0, {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v2$058skip_named$1261$(_reader_0, _named_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _t_0 = _reader_0["registry"];
  const _namespace_0 = _t_0["namespace"];
  const _id_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _keys_0 = _reader_0["keys"];
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $runtime$045v2$058skip_namespace$1261$((_namespace_0 === _actual_0), _world_0, {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $application$045v2$058body$1260$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _private_0 = _input_0["args"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Tuple", "fst": _private_0, "snd": _readings_0}};
}

function $$$$047queue$058visible_items$1260$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047queue$058prepend_items$1260$(_items_0, _acc_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $application$045v2$058body$1261$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _private_0 = _input_0["args"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Tuple", "fst": _private_0, "snd": _readings_0}};
}

function $$$$047queue$058visible_items$1261$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047queue$058prepend_items$1261$(_items_0, _acc_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $runtime$045v2$058skip_namespace$1260$(_same_0, _world_0, _registry_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $runtime$045v2$058skip_meta$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _id_0);
  }
}

function $runtime$045v2$058skip_namespace$1261$(_same_0, _world_0, _registry_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $runtime$045v2$058skip_meta$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _id_0);
  }
}

function $$$$047queue$058prepend_items$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047queue$058prepend_items$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $runtime$045v2$058skip_meta$1260$(_checked_0, _registry_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $runtime$045v2$058skipped_checked$1260$(_allowed_0, {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}, _id_0);
}

function $runtime$045v2$058skip_meta$1261$(_checked_0, _registry_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $runtime$045v2$058skipped_checked$1261$(_allowed_0, {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, {$: "runtime-v2.Reader", "registry": _registry_0, "keys": _keys_0}, _id_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $runtime$045v2$058skipped_checked$1260$(_allowed_0, _runtime_0, _reader_0, _id_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _runtime_0, "snd": _reader_0};
  } else {
    const _world_0 = _runtime_0["world"];
    const _domains_0 = _runtime_0["domains"];
    const _positions_0 = _runtime_0["positions"];
    const _tick_0 = _runtime_0["tick"];
    const _frameStart_0 = _runtime_0["frameStart"];
    const _boundary_0 = _runtime_0["boundary"];
    const _capacity_0 = _runtime_0["capacity"];
    return {$: "Tuple", "fst": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _reader_0};
  }
}

function $runtime$045v2$058skipped_checked$1261$(_allowed_0, _runtime_0, _reader_0, _id_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _runtime_0, "snd": _reader_0};
  } else {
    const _world_0 = _runtime_0["world"];
    const _domains_0 = _runtime_0["domains"];
    const _positions_0 = _runtime_0["positions"];
    const _tick_0 = _runtime_0["tick"];
    const _frameStart_0 = _runtime_0["frameStart"];
    const _boundary_0 = _runtime_0["boundary"];
    const _capacity_0 = _runtime_0["capacity"];
    return {$: "Tuple", "fst": {$: "runtime-v2.Runtime", "world": _world_0, "domains": _domains_0, "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, false)), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _reader_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $0m0(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.Growth": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.Growth has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.Growth); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m2(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": nat_host(v["cursor"]), "registeredAt": nat_host(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m1(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m2(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m4(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": BigInt(v["cursor"]), "registeredAt": BigInt(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m3(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m4(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m5(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m2(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m6(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m4(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m14(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../queue.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"]), "count": BigInt(v["count"])}; return top[0];
      default: throw "bend: ../queue.Batch has no tag " + v?.$ + " (its tags: ../queue.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m13(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m14(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m12(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../queue.Queue": at = at[key] = {...v, "front": $0m13(v["front"]), "back": $0m13(v["back"]), "size": BigInt(v["size"]), "dropped": BigInt(v["dropped"])}; return top[0];
      default: throw "bend: ../queue.Queue has no tag " + v?.$ + " (its tags: ../queue.Queue); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m11(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../domains.Domain": at = at[key] = {...v, "queue": $0m12(v["queue"])}; return top[0];
      default: throw "bend: ../domains.Domain has no tag " + v?.$ + " (its tags: ../domains.Domain); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m10(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m11(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m9(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "observe-v2.Final": at = at[key] = {...v, "domains": $0m10(v["domains"]), "positions": $0m3(v["positions"]), "tick": BigInt(v["tick"]), "frameStart": BigInt(v["frameStart"]), "boundary": BigInt(v["boundary"]), "retentionCapacity": BigInt(v["retentionCapacity"]), "depth": BigInt(v["depth"]), "pendingCount": BigInt(v["pendingCount"])}; return top[0];
      default: throw "bend: observe-v2.Final has no tag " + v?.$ + " (its tags: observe-v2.Final); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m8(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m9(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m21(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../queue.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"]), "count": BigInt(v["count"])}; return top[0];
      default: throw "bend: ../queue.Batch has no tag " + v?.$ + " (its tags: ../queue.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m20(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m21(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m19(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../queue.Queue": at = at[key] = {...v, "front": $0m20(v["front"]), "back": $0m20(v["back"]), "size": BigInt(v["size"]), "dropped": BigInt(v["dropped"])}; return top[0];
      default: throw "bend: ../queue.Queue has no tag " + v?.$ + " (its tags: ../queue.Queue); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m18(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../domains.Domain": at = at[key] = {...v, "queue": $0m19(v["queue"])}; return top[0];
      default: throw "bend: ../domains.Domain has no tag " + v?.$ + " (its tags: ../domains.Domain); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m17(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m18(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m16(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "observe-v2.Final": at = at[key] = {...v, "domains": $0m17(v["domains"]), "positions": $0m3(v["positions"]), "tick": BigInt(v["tick"]), "frameStart": BigInt(v["frameStart"]), "boundary": BigInt(v["boundary"]), "retentionCapacity": BigInt(v["retentionCapacity"]), "depth": BigInt(v["depth"]), "pendingCount": BigInt(v["pendingCount"])}; return top[0];
      default: throw "bend: observe-v2.Final has no tag " + v?.$ + " (its tags: observe-v2.Final); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m15(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m16(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m7(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m8(v["fst"]), "snd": $0m15(v["snd"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m24(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Scheduled": at = at[key] = {...v, "final": $0m8(v["final"])}; return top[0];
      default: throw "bend: Scheduled has no tag " + v?.$ + " (its tags: Scheduled); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m23(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Cases": at = at[key] = {...v, "neverActivatedSkip": $0m24(v["neverActivatedSkip"]), "activatedSkip": $0m24(v["activatedSkip"]), "successfulDisposal": $0m8(v["successfulDisposal"])}; return top[0];
      default: throw "bend: Cases has no tag " + v?.$ + " (its tags: Cases); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m26(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Scheduled": at = at[key] = {...v, "final": $0m15(v["final"])}; return top[0];
      default: throw "bend: Scheduled has no tag " + v?.$ + " (its tags: Scheduled); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m25(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Cases": at = at[key] = {...v, "neverActivatedSkip": $0m26(v["neverActivatedSkip"]), "activatedSkip": $0m26(v["activatedSkip"]), "successfulDisposal": $0m15(v["successfulDisposal"])}; return top[0];
      default: throw "bend: Cases has no tag " + v?.$ + " (its tags: Cases); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m22(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m23(v["fst"]), "snd": $0m25(v["snd"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}
export default {
  "../../../../src/ecs/string-equality.equal_walk": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/string-equality.equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/string-equality.access_equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/string-equality.registration_equal": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058registration_equal$((a0), (a1), (a2), (a3), (a4), (a5)))); (a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "../../../../src/ecs/world.factory": run_lib(() => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()));  return r; }, 0),
  "../../../../src/ecs/world.grow_live": run_lib((a0, a1, a2, a3) => { const r = $0m0(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(nat_host(a0), (a1), nat_host(a2), (a3)))); BigInt(a0); (a1); BigInt(a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.access_equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/world.matching_access": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/world.matching_id": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../../../../src/ecs/world.registration_meta_matches": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.registration_list_walk": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../../../../src/ecs/world.registration_list_matches": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.next_clock": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/registration.retained": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/registration.without": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.hold_boundary": run_lib((a0, a1) => { const r = BigInt(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0m1(a0), nat_host(a1)))); $0m3(a0); BigInt(a1); return r; }, 2),
  "../../../../src/ecs/event-runtime.update_checked": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((a0), (a1), (a2), nat_host(a3), nat_host(a4), $0m1(a5), nat_host(a6)))); (a0); (a1); (a2); BigInt(a3); BigInt(a4); $0m3(a5); BigInt(a6); return r; }, 7),
  "../../../../src/ecs/event-runtime.update": run_lib((a0, a1, a2, a3) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$($0m1(a0), (a1), nat_host(a2), (a3)))); $0m3(a0); (a1); BigInt(a2); (a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.choose_position": run_lib((a0, a1, a2) => { const r = $0m6(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((a0), $0m2(a1), $0m5(a2)))); (a0); $0m4(a1); $0m6(a2); return r; }, 3),
  "../../../../src/ecs/event-runtime.lookup_checked": run_lib((a0, a1, a2) => { const r = $0m6(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$($0m2(a0), (a1), $0m5(a2)))); $0m4(a0); (a1); $0m6(a2); return r; }, 3),
  "../../../../src/ecs/event-runtime.lookup": run_lib((a0, a1) => { const r = $0m6(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$($0m1(a0), (a1)))); $0m3(a0); (a1); return r; }, 2),
  "../../../../src/ecs/event-runtime.activation": run_lib((a0, a1, a2, a3) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$($0m5(a0), $0m1(a1), (a2), nat_host(a3)))); $0m6(a0); $0m3(a1); (a2); BigInt(a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.activate": run_lib((a0, a1, a2) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$($0m1(a0), (a1), nat_host(a2)))); $0m3(a0); (a1); BigInt(a2); return r; }, 3),
  "../domains.member": run_lib((a0, a1) => { const r = (run_loop($$$$047domains$058member$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../domains.add_checked": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047domains$058add_checked$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../domains.add": run_lib((a0, a1) => { const r = (run_loop($$$$047domains$058add$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../domains.select_boundary": run_lib((a0, a1, a2) => { const r = BigInt(run_loop($$$$047domains$058select_boundary$((a0), nat_host(a1), nat_host(a2)))); (a0); BigInt(a1); BigInt(a2); return r; }, 3),
  "../domains.boundary": run_lib((a0, a1, a2) => { const r = BigInt(run_loop($$$$047domains$058boundary$($0m1(a0), (a1), nat_host(a2)))); $0m3(a0); (a1); BigInt(a2); return r; }, 3),
  "../runtime.position_or": run_lib((a0, a1, a2) => { const r = $0m4(run_loop($$$$047runtime$058position_or$($0m5(a0), (a1), nat_host(a2)))); $0m6(a0); (a1); BigInt(a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.contains": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/relation-graph.removed_id": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.remove_id": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/relation-graph.chosen_target": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.chosen_inverse": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.appended_source": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.validation": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$((a0), (a1), (a2), (a3), (a4), (a5), (a6)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "../../../../src/ecs/relation-graph.already": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../driven.cells": run_lib((a0) => { const r = (run_loop($$$$047driven$058cells$((a0)))); (a0); return r; }, 1),
  "../driven.private_observed": run_lib((a0) => { const r = (run_loop($$$$047driven$058private_observed$((a0)))); (a0); return r; }, 1),
  "runtime-v2.position_or": run_lib((a0, a1, a2) => { const r = $0m4(run_loop($runtime$045v2$058position_or$($0m5(a0), (a1), nat_host(a2)))); $0m6(a0); (a1); BigInt(a2); return r; }, 3),
  "disposal.keep": run_lib((a0, a1, a2) => { const r = (run_loop($disposal$058keep$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "disposal.remove": run_lib((a0, a1) => { const r = (run_loop($disposal$058remove$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "observe-v2.bool_cells": run_lib((a0) => { const r = (run_loop($observe$045v2$058bool_cells$((a0)))); (a0); return r; }, 1),
  "observe-v2.main": run_lib(() => { const r = $0m7(run_loop($observe$045v2$058main$()));  return r; }, 0),
  "../../../../src/ecs/schedule.contains": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058contains$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/schedule.valid": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047schedule$058valid$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "bool_cells": run_lib((a0) => { const r = (run_loop($bool_cells$((a0)))); (a0); return r; }, 1),
  "main": run_lib(() => { const r = $0m22(run_loop($main$()));  return r; }, 0),
};
