// Supplementary cross-language shared observation; full Bend snapshot is separately checked.
// TS fixture has no affine private-owner API; no claim projects those owned Bend cells away.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {compareJson} from './compare-json.mjs';
const bend=JSON.parse(fs.readFileSync(process.argv[2],'utf8')).observed;
const ts=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
assert.equal(ts.capacity,65536);assert.equal(ts.publications,65537);
function encode(notice){
 assert.equal(notice.$,'RelationFailed');const f=notice.failure;
 const relation=f.relation.key===1?'Alpha':'Beta';
 assert.equal(f.operation.$,'Relate');assert.equal(f.relation.kind.$,'Hierarchy');
 assert.equal(f.relation.name,f.relation.key===1?'Parent':'ParentB');assert.equal(f.relation.inverseName,f.relation.key===1?'Children':'ChildrenB');
 assert.ok(['SelfRelationNotAllowed','MissingTargetEntity'].includes(f.error.$));
 const error=f.error.$==='SelfRelationNotAllowed'?{_tag:'SelfRelationNotAllowed',entityId:f.error.source,relation}:{_tag:'MissingTargetEntity',entityId:f.error.source,targetId:f.error.target,relation};
 return {operation:'relate',relation,source:f.source,target:f.target,error};
}
for(const [index,root] of ['ReadersAlpha','ReadersBeta'].entries()){
 const actual=bend[index];assert.equal(actual.clock,8);assert.equal(actual.retentionCapacity,65536);
 const find=label=>{const checkpoint=ts.output.find(x=>x.root===root&&x.label===label);assert.ok(checkpoint);return checkpoint;};
 const labels=['alpha-not-lagged','beta-exact-ordered','shared-independent-lag'];
 for(const [slot,label] of labels.entries()){
  const record=find(label);const delivery=record.deliveries[0];assert.equal(record.deliveries.length,1);
  const shared={reader:slot===0?'only-alpha':slot===1?'only-beta':'both'};
  for(const reading of actual.deliveries[slot+3])shared[reading.key.id===1?'alpha':'beta']={lagged:reading.lagged,values:reading.values.map(encode)};
  compareJson(shared,delivery);
  compareJson({Left:actual.left,Right:actual.right},record.world.entities[0].components);
  compareJson({Baseline:actual.baseline},record.world.resources);
  assert.equal(record.world.entityCount,1);assert.equal(record.world.entities[0].id,1);
  compareJson(record.world.entities[0].relations,{});compareJson(record.world.machines,{});compareJson(record.world.pendingCommands,[]);
 }
 compareJson(actual.graph,{$:'Graph',edges:[],inverses:[]});compareJson(actual.events,[]);assert.equal(actual.pendingCount,0);
}
console.log(JSON.stringify({developmentOnly:true,roots:2,sharedFullOrderedDeliveries:6,retainedPerBetaReader:65536,privateOwners:'full Bend oracle only; no TS affine private API in this fixture'}));
