// Complete value normalization; memoization only reuses already normalized identities.
export function normalize(root){
 const seen=new WeakMap();
 function visit(value){
  if(typeof value==='bigint')return Number(value);
  if(value===null||typeof value!=='object')return value;
  if(seen.has(value))return seen.get(value);
  const tag=value.$?.split('.').at(-1);let output;
  if(tag==='Nil')output=[];
  else if(tag==='Con'){output=[];for(let node=value;node.$==='Con';node=node.tail)output.push(visit(node.head));}
  else if(tag==='Queue'){const front=visit(value.front),back=visit(value.back);output={$:'Queue',batches:[...front,...back.slice().reverse()],size:visit(value.size),dropped:visit(value.dropped)};}
  else if(tag==='Some')output=visit(value.value);
  else if(tag==='None')output=null;
  else if(tag==='Tuple')output=[visit(value.fst),visit(value.snd)];
  else{output={};for(const [key,item]of Object.entries(value))output[key]=key==='$'?tag:visit(item);}
  seen.set(value,output);return output;
 }
 return visit(root);
}
