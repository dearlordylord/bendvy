"""Immutable development checks only; this is not source-review or acceptance."""
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from scripts.task_runner import execute_result, IMPLEMENTATION_SHA256

CANDIDATE = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(stage, name, command, limit, env=None):
    result = execute_result(command, limit, env=env, cwd=ROOT, capture='split')
    (stage / (name + '.stdout')).write_bytes(result.pop('stdout'))
    (stage / (name + '.stderr')).write_bytes(result.pop('stderr'))
    receipt = dict(result, command=list(map(str, command)), timeout=limit,
                   runnerSHA256=IMPLEMENTATION_SHA256,
                   developmentOnly=True)
    (stage / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    if result['exit'] != 0 or result['failure']:
        raise RuntimeError(f'{name}: inspect retained raw attempt in {stage}')


def main():
    base = CANDIDATE / 'development-attempts'
    base.mkdir(exist_ok=True)
    index = 1
    while (base / f'run-{index:03d}').exists():
        index += 1
    stage = base / f'run-{index:03d}'
    stage.mkdir()
    sources = {str(p.relative_to(ROOT)): digest(p) for p in CANDIDATE.iterdir()
               if p.suffix in ('.bend', '.mjs', '.py', '.md')}
    sources.update({str(p.relative_to(ROOT)): digest(p) for p in (ROOT / 'src/ecs').glob('*.bend')})
    sources['scripts/task_runner.py'] = IMPLEMENTATION_SHA256
    (stage / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
    run(stage, 'check', ['bend', CANDIDATE / 'observe.bend', '--check-only'], 5)
    run(stage, 'emit-js', ['bend', CANDIDATE / 'observe.bend', '-o', stage / 'observe.mjs'], 30)
    run(stage, 'consume-js', ['node', CANDIDATE / 'consumer.mjs', stage / 'observe.mjs'], 5)
    run(stage, 'reference', ['node', CANDIDATE / 'driven-reference.mjs'], 5)
    run(stage, 'compare-shared', ['node', CANDIDATE / 'compare-shared.mjs', stage / 'consume-js.stdout', stage / 'reference.stdout'], 5)
    run(stage, 'foreign-check', ['bend', CANDIDATE / 'foreign.bend', '--check-only'], 5)
    run(stage, 'foreign-emit-js', ['bend', CANDIDATE / 'foreign.bend', '-o', stage / 'foreign.mjs'], 30)
    run(stage, 'foreign-consume-js', ['node', CANDIDATE / 'consumer.mjs', stage / 'foreign.mjs', '--foreign'], 5)
    if '--native' in sys.argv:
        run(stage, 'emit-c', ['bend', CANDIDATE / 'observe.bend', '-o', stage / 'observe.c'], 30)
        env = os.environ.copy()
        env['BENDVY_CLANG19_ROOT'] = '/tmp/bendvy-clang19-diagnostic/root'
        run(stage, 'compile', ['/tmp/bendvy-clang19-diagnostic/clang19', '-O3', stage / 'observe.c', '-pthread', '-lm', '-o', stage / 'observe-native'], 120, env)
        run(stage, 'native', [stage / 'observe-native', '--threads', '1', '--gpu', 'off'], 5)
        run(stage, 'consume-native', ['node', CANDIDATE / 'native-consumer.mjs', stage / 'native.stdout'], 5)
    if any(digest(ROOT / path) != sha for path, sha in sources.items()):
        raise RuntimeError('source changed during development check')
    (stage / 'result.json').write_text(json.dumps(dict(developmentOnly=True,
        completeFiniteOracle=True, acceptance=False, sourcesUnchanged=True), indent=2) + '\n')
    print(stage.relative_to(ROOT))

if __name__ == '__main__':
    main()
