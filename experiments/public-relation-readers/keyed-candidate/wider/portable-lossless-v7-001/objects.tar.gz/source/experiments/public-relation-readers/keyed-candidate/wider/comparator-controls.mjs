import assert from 'node:assert/strict';
import {expected} from './oracle-v2.mjs';
import {compareJson} from './compare-json.mjs';
const baseline=expected(),subject=structuredClone(baseline);
const choice=process.argv[2];
const last=65535;
const controls={
 'last-payload':{apply:()=>{subject[1].deliveries[5][1].values[last].failure.target=777777;},witness:'VALUE_MISMATCH:$.1.deliveries.4.0.values.65535.failure.target'},
 'last-queue-entry':{apply:()=>{subject[1].domains[1].queue.batches[last].tick=777;},witness:'VALUE_MISMATCH:$.1.domains.1.queue.batches.65535.tick'},
 'private-array':{apply:()=>{subject[1].bothPrivate[1]=777;},witness:'VALUE_MISMATCH:$.1.bothPrivate.1'},
 'tick':{apply:()=>{subject[1].tick=777;},witness:'VALUE_MISMATCH:$.1.tick'},
 'missing-key':{apply:()=>{delete subject[1].clock;},witness:'KEYSET_MISMATCH:$.1'},
 'extra-key':{apply:()=>{subject[1].extra=null;},witness:'KEYSET_MISMATCH:$.1'},
 'root2-only':{apply:()=>{subject[1].left[1]=777;},witness:'VALUE_MISMATCH:$.1.left.1'}
};
const control=controls[choice];assert.ok(control,'named control required');control.apply();
compareJson(subject[0],baseline[0]);
assert.throws(()=>compareJson(subject,baseline),error=>error.message===control.witness);
console.log(JSON.stringify({developmentOnly:true,control:choice,witness:control.witness,root1Unchanged:true}));
