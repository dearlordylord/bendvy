import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const bend=JSON.parse(readFileSync(process.argv[2],'utf8')).observed;
const ts=JSON.parse(readFileSync(process.argv[3],'utf8')).observations;
const labels=['register','register','before-barrier','before-barrier','published','failure','retry','fast-empty'];
function failure(notice){
 assert.equal(notice.$,'RelationFailed');const f=notice.failure;
 const error=f.error.$==='SelfRelationNotAllowed'?{_tag:f.error.$,entityId:f.error.source,relation:f.error.relation}:{_tag:f.error.$,entityId:f.error.source,targetId:f.error.target,relation:f.error.relation};
 return {operation:f.operation.$==='Relate'?'relate':f.operation.$,relation:f.relation.name,source:f.source,target:f.target,error};
}
for(const [index,root] of ['ReadersAlpha','ReadersBeta'].entries()){
 const observed=bend[index];const checkpoints=ts.filter(x=>x.root===root);assert.equal(checkpoints.length,7);
 const deliveries=observed.deliveries.map((d,i)=>({label:labels[i],who:d.who,lagged:d.readings[0].lagged,failures:d.readings[0].values.map(failure)}));
 assert.deepEqual(deliveries,checkpoints.at(-1).deliveries);
 for(const checkpoint of checkpoints){
  const entities=checkpoint.world.entities;
  assert.deepEqual(entities,[{id:1,components:{Left:observed.left,Right:observed.right},relations:{}}]);
  assert.deepEqual(checkpoint.world.resources,{Baseline:observed.baseline});
  assert.deepEqual(checkpoint.world.machines,{});
  assert.deepEqual(checkpoint.privateOwners,{fast:observed.fastPrivate,slow:observed.slowPrivate});
 }
 assert.deepEqual(observed.graph,{$:'Graph',edges:[],inverses:[]});
 assert.deepEqual(observed.live,[false,true]);assert.equal(observed.highWater,1);
 assert.deepEqual(observed.events,[]);assert.deepEqual(observed.returned,[]);
 assert.equal(observed.pendingCount,0);assert.deepEqual(checkpoints.at(-1).world.pendingCommands,[]);
 assert.ok(checkpoints.at(-1).streams.every(s=>s.size===0));
 assert.equal(checkpoints.find(x=>x.label==='before-barrier').world.pendingCommands.length,3);
 assert.deepEqual(checkpoints.find(x=>x.label==='failure').mailbox,[observed.slowPrivate]);
 assert.deepEqual(checkpoints.find(x=>x.label==='retry').mailbox,[]);
}
console.log(JSON.stringify({developmentOnly:true,roots:['ReadersAlpha','ReadersBeta'],orderedSharedDeliveries:16,completeFailurePayloads:true,allAuthoredCellsCompared:true,affinePrivateIdentity:'Bend checked owner + TS explicit identity adapter',acceptance:false}));
