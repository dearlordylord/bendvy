# Unapproved descriptor-keyed stream law subjects

These are exact candidate subjects, not approved laws or proofs. No falsification execution has occurred during the integration timing window.

1. Routing the actual committed World notice list partitions it into descriptor-keyed failure batches and the unchanged ordered nonfailure notice list. Every routed failure retains descriptor, operation, source, target and exact error; no uncommitted deferred request is a failure publication.
2. A key's retained batches and lag watermark depend only on that key's publications, its registered member positions and the common age/capacity contract. Publications or readers of another key cannot hold, drop or lag this key.
3. A reader has no stream position/memberships before its first actual activation. On activation only declared keys register; successful run and activated condition skip advance its shared stream cursor, failed run preserves it, initial skip preserves absence.
4. Each declared key delivers exactly its retained entries with publication tick greater than the prior cursor, oldest first, with lag iff its droppedThrough exceeds max(cursor,registeredAt).

Planted defect plan: global-key matching, registration on initial skip, advancing a different reader, advancing on failed outcome, shared dropped watermark, and premature publication from queueing. Each must be reached through the actual public multi-schema application; constructor-only or manually populated log witnesses do not qualify those application claims. Approval remains required before any ECS proof.
