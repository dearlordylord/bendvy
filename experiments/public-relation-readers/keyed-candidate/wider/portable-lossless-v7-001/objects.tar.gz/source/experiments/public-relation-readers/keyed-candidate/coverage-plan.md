# Current executable coverage plan

| Subject | Actual reference | Candidate public operation | Full observation |
| --- | --- | --- | --- |
| Independent fast/slow, expected failure retry | existing18-row reference | registered keyed runner through same actual relation commands and barrier | ordered descriptor/operation/source/target/error records and full returned World |
| Activated condition skip | existing12-row condition reference | registered schedule condition/owned skip | stream cursor advances, component/removal cursor remains independent |
| Never-activated skip/aged first read | existing12 full debug checkpoints | lazy membership, frame trim, first actual run | absent initial position/member, no false lag, one later delivery |
| Descriptor-local retention | new key-independence-reference.mjs | Alpha-only holding reader, unheld Beta aging | complete keyed logs/member positions plus World/graph/queues |
| Default capacity isolation | same public multi-key reference,65,537 actual Beta commands | actual pending FIFO drain, per-key whole-batch trim | all65,536 retained Beta records, Alpha record unchanged/not lagged; Beta and shared Alpha/Beta reader lag separately |
| Foreign command refusal | delivered #42 public command contract | actual independent same-schema World creation and relation queue call | MissingEntity, unchanged pending command owner sequence and complete component/graph owners |
| Ordinary events and removals | delivered #35 domain handoff | actual mixed Notice publications and owned readers | separate cursor/retention/payload output and failure records, no conflated SystemFailure |
| Supplemental disposal | Bend-only owned behavior | actual system disposal + membership release | retained reader on refusal, one-time success, key backlog cleanup; no TS public-disposal claim |
| Abstract grants | current Compose/provider pattern | closed nominal key selections + universal H reader consumer | intended undeclared-key/schema/read-write/duplicated-owner diagnostics |
| Reached wrong advancement/publication | planted defects from law subject drafts | full registered application | wrong-reader/success-on-failure cursor witness and queue-time publication witness on JS/Native |

All application roots carry arbitrary affine component/resource Array owners alongside the maintained relation graph. Snapshot projections materialize complete authored payload cells; no Data-only component scope is introduced. State/source/runtime guards will be qualified only after the complete candidate is ready; initial checker5s development is not task acceptance.
