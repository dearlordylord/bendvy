import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {normalize} from '../codec.mjs';
import {expected} from './oracle.mjs';
const {default:api}=await import(pathToFileURL(resolve(process.argv[2])));
const observed=normalize(api.main());
assert.deepEqual(observed,expected());
console.log(JSON.stringify({developmentOnly:true,capacity:65536,publishedPerRoot:65537,observed}));
