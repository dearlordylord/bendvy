// Full-value comparison for immutable, plain, acyclic JSON-shaped DAG snapshots.
// Cache is local to one comparison and records only fully verified object pairs.
export function compareJson(actual,expected){
 const verified=new WeakMap();
 function visit(a,b,path){
  if(Object.is(a,b))return;
  if(typeof a!==typeof b||a===null||b===null||typeof a!=='object')throw new Error(`VALUE_MISMATCH:${path}`);
  if(Object.getPrototypeOf(a)!==Object.getPrototypeOf(b))throw new Error(`TYPE_MISMATCH:${path}`);
  if(verified.get(a)?.has(b))return;
  if(Array.isArray(a)){
   if(a.length!==b.length)throw new Error(`LENGTH_MISMATCH:${path}`);
  }else if(Object.getPrototypeOf(a)!==Object.prototype)throw new Error(`NON_JSON_OBJECT:${path}`);
  const ak=Object.keys(a),bk=Object.keys(b);
  if(ak.length!==bk.length)throw new Error(`KEYSET_MISMATCH:${path}`);
  for(const key of ak){
   if(!Object.hasOwn(b,key))throw new Error(`KEYSET_MISMATCH:${path}.${key}`);
   visit(a[key],b[key],`${path}.${key}`);
  }
  let pair=verified.get(a);if(!pair){pair=new WeakSet();verified.set(a,pair);}pair.add(b);
 }
 visit(actual,expected,'$');
}
