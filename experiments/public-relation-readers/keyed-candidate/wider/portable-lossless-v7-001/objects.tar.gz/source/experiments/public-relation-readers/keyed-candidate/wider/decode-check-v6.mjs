import fs from 'node:fs';
import {deserialize} from 'node:v8';
import {compareJson} from './compare-json.mjs';
import {expected} from './oracle-v2.mjs';
const observed=deserialize(fs.readFileSync(process.argv[2]));
console.error('checkpoint:lossless-snapshot-decoded');
compareJson(observed,expected());
console.error('checkpoint:decoded-full-oracle-pass');
console.log(JSON.stringify({developmentOnly:true,decodedCompleteOraclePass:true,completeIssue43:false,completeSnapshotRetainedAs:'Node-version-dependent v8 binary',originalFullJSONGate:'UNMET'}));
