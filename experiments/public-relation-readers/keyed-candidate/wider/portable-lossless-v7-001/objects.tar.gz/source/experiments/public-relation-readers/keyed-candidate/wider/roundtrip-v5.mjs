import assert from 'node:assert/strict';
import fs from 'node:fs';
import {serialize,deserialize} from 'node:v8';
import {compareJson} from './compare-json.mjs';
import {expected} from './oracle-v2.mjs';
const original=deserialize(fs.readFileSync(process.argv[2]));
const copied=deserialize(serialize(original));
compareJson(copied,expected());
assert.notStrictEqual(copied,original);
for(let root=0;root<2;root++){
 assert.strictEqual(copied[root].deliveries[4][0].values[65535],copied[root].deliveries[5][1].values[65535]);
 assert.strictEqual(copied[root].deliveries[4][0].values[65535],copied[root].domains[1].queue.batches[65535].values[0]);
 assert.notStrictEqual(copied[root].deliveries[4][0].values[65535],original[root].deliveries[4][0].values[65535]);
}
assert.notStrictEqual(copied[0],copied[1]);assert.notStrictEqual(copied[0].bothPrivate,copied[1].bothPrivate);
console.log(JSON.stringify({developmentOnly:true,roundtripCompleteOracle:true,retainedFailureAliasesPreserved:true,sourceAndRootsIndependent:true}));
