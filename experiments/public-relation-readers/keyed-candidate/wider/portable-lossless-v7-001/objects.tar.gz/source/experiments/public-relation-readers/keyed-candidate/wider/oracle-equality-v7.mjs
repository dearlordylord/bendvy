import {expected as oldExpected} from './oracle-v2.mjs';
import {expected} from './oracle-frozen-v7.mjs';
import {compareJson} from './compare-json-v7.mjs';
compareJson(expected(),oldExpected());
console.log(JSON.stringify({developmentOnly:true,oldNewCompleteTwoRootValueEquality:true}));
