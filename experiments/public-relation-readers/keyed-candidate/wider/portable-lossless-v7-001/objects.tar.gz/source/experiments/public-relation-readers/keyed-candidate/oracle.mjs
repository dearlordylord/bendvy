// Independently authored finite fixture contract; no Bend execution or receipt is read.
const key=id=>({$:'DeclaredKey',id});
const failure=(id,target)=>{
 const name=id===1?'Parent':'ParentB';
 return {$:'RelationFailed',failure:{$:'Failure',relation:{$:'Descriptor',key:id,name,inverseName:id===1?'Children':'ChildrenB',kind:{$:'Hierarchy'}},operation:{$:'Relate'},source:1,target,error:target===1?{$:'SelfRelationNotAllowed',source:1,relation:name}:{$:'MissingTargetEntity',source:1,target,relation:name}}};
};
const self=failure(1,1),missing=failure(1,99),beta=failure(2,1);
const batch=(tick,value)=>({$:'Batch',tick,count:1,values:[value]});
const domain=(id,batches,readers,dropped=0)=>({$:'Domain',key:key(id),queue:{$:'Queue',batches,size:batches.reduce((n,b)=>n+b.count,0),dropped},readers});
const position=(id,cursor)=>({$:'Position',id,cursor,registeredAt:id-1});
const positions=(fast,slow)=>slow===undefined?[position(1,fast)]:[position(2,slow),position(1,fast)];
const emptyDomains=readers=>[domain(1,[],readers)];
const publishedDomains=()=>[domain(1,[batch(8,self),batch(9,missing)],[2,1]),domain(2,[batch(10,beta)],[])];
const reading=values=>[{$:'KeyReading',key:key(1),values,lagged:false}];
const delivery=(who,result,values,domains,pos)=>({$:'Delivery',who,result,readings:reading(values),privateCells:who==='fast'?[101,102]:[201,202],domains,positions:pos});
export function expectedFinal(){
 return {$:'Final',deliveries:[
  delivery('fast',0,[],emptyDomains([1]),positions(1)),
  delivery('slow',0,[],emptyDomains([2,1]),positions(1,2)),
  delivery('fast',0,[],emptyDomains([2,1]),positions(6,2)),
  delivery('slow',0,[],emptyDomains([2,1]),positions(6,7)),
  delivery('fast',0,[self,missing],publishedDomains(),positions(11,7)),
  delivery('slow',77,[self,missing],publishedDomains(),positions(11,7)),
  delivery('slow',0,[self,missing],publishedDomains(),positions(11,13)),
  delivery('fast',0,[],publishedDomains(),positions(14,13))
 ],domains:[domain(1,[],[2,1],9),domain(2,[],[],10)],positions:positions(14,13),tick:14,frameStart:14,boundary:14,retentionCapacity:65536,namespace:1,nextId:2,highWater:1,live:[false,true],capacity:2,depth:1,left:[11,12],right:[21,22],graph:{$:'Graph',edges:[],inverses:[]},baseline:[301,302],returned:[],events:[],pendingCount:0,registrations:[{$:'RegistrationMeta',id:2,name:'slow',access:['Parent:read']},{$:'RegistrationMeta',id:1,name:'fast',access:['Parent:read']}],nextSystemId:3,clock:0,fastPrivate:[101,102],slowPrivate:[201,202]};
}
export const expected=()=>[expectedFinal(),expectedFinal()];
export function expectedForeign(){
 const source={...expectedFinal(),deliveries:[],domains:[],positions:[],tick:0,frameStart:0,boundary:0};
 const receiver={...source,namespace:2,tick:3,domains:[domain(1,[batch(3,self)],[])]};
 return [{$:'ForeignResult',status:{$:'MissingEntity'},before:1,after:1,source,receiver},{$:'ForeignResult',status:{$:'MissingEntity'},before:1,after:1,source,receiver}];
}
