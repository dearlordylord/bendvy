import assert from 'node:assert/strict';
import {expected} from './oracle-frozen-v7.mjs';
const frozen=expected(),pending=[frozen],seen=new WeakSet();let nodes=0;
while(pending.length){const value=pending.pop();if(value===null||typeof value!=='object'||seen.has(value))continue;seen.add(value);assert.equal(Object.isFrozen(value),true);nodes++;for(const child of Object.values(value))pending.push(child);}
assert.throws(()=>{frozen[1].deliveries[5][1].values[65535].failure.target=777777;},TypeError);
assert.throws(()=>{frozen[1].bothPrivate[1]=777;},TypeError);
assert.throws(()=>{delete frozen[1].clock;},TypeError);
assert.throws(()=>{frozen[1].extra=null;},TypeError);
console.log(JSON.stringify({developmentOnly:true,everyDAGNodeFrozen:true,nodes,root2WritesRejected:true}));
