// Freeze every reachable node in the authored immutable, plain JSON DAG.
export function freezeJson(root){
 const pending=[root],seen=new WeakSet();
 while(pending.length){
  const value=pending.pop();if(value===null||typeof value!=='object'||seen.has(value))continue;
  seen.add(value);for(const item of Object.values(value))pending.push(item);Object.freeze(value);
 }
 return root;
}
