import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {expected,expectedForeign} from './oracle.mjs';
// Parse the compiler's structural value printer; no native result is inferred
// from the JS backend or checksum. Constructor fields follow authored types.
const fields={
 ForeignResult:['status','before','after','source','receiver'],MissingEntity:[],
 Final:['deliveries','domains','positions','tick','frameStart','boundary','retentionCapacity','namespace','nextId','highWater','live','capacity','depth','left','right','graph','baseline','returned','events','pendingCount','registrations','nextSystemId','clock','fastPrivate','slowPrivate'],
 Delivery:['who','result','readings','privateCells','domains','positions'],
 KeyReading:['key','values','lagged'],DeclaredKey:['id'],Domain:['key','queue','readers'],Queue:['front','back','size','dropped'],Batch:['tick','count','values'],Position:['id','cursor','registeredAt'],Graph:['edges','inverses'],Edge:['relation','source','target'],Inverse:['relation','target','sources'],RegistrationMeta:['id','name','access'],RelationFailed:['failure'],Failure:['relation','operation','source','target','error'],Descriptor:['key','name','inverseName','kind'],Hierarchy:[],Relate:[],SelfRelationNotAllowed:['source','relation'],MissingTargetEntity:['source','target','relation'],Original:['event'],ComponentRemoved:['id'],CleanupPaused:['frames']
};
const source=readFileSync(process.argv[2],'utf8');let offset=0;
const ws=()=>{while(/\s/.test(source[offset]??'')&&offset<source.length)offset++;};
const take=char=>{ws();assert.equal(source[offset++],char);};
function sequence(end){const values=[];ws();if(source[offset]===end){offset++;return values;}for(;;){values.push(parse());ws();if(source[offset]===end){offset++;return values;}take(',');}}
function parse(){
 ws();const char=source[offset++];
 if(char==='[')return sequence(']');
 if(char==='(')return sequence(')');
 if(char==='"'){let end=offset;for(;end<source.length;end++){if(source[end]==='\\'){end++;continue;}if(source[end]==='"')break;}const text=JSON.parse(source.slice(offset-1,end+1));offset=end+1;return text;}
 offset--;
 const number=/^\d+n?/.exec(source.slice(offset));if(number){offset+=number[0].length;return Number(number[0].replace(/n$/,''));}
 const constructor=/^[A-Za-z_./-][A-Za-z0-9_./-]*/.exec(source.slice(offset));assert.ok(constructor,`expected value at ${offset}`);offset+=constructor[0].length;const tag=constructor[0].split('.').at(-1);take('{');const values=sequence('}');
 if(tag==='True'||tag==='False'){assert.equal(values.length,0);return tag==='True';}
 if(tag==='Some'){assert.equal(values.length,1);return values[0];}
 if(tag==='None'){assert.equal(values.length,0);return null;}
 assert.ok(fields[tag],`unknown constructor ${tag}`);assert.equal(values.length,fields[tag].length,tag);const value=Object.fromEntries([['$',tag],...fields[tag].map((key,index)=>[key,values[index]])]);
 if(tag==='Queue'){const {front,back,size,dropped}=value;return {$:tag,batches:[...front,...back.reverse()],size,dropped};}
 return value;
}
const observed=parse();ws();assert.equal(offset,source.length);assert.deepEqual(observed,(process.argv.includes('--foreign')?expectedForeign:expected)());
console.log(JSON.stringify({developmentOnly:true,roots:['ReadersAlpha','ReadersBeta'],observed}));
