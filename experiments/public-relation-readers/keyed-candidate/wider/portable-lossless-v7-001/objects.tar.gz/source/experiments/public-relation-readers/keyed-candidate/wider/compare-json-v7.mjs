// Complete JSON-DAG equality, local verified pairs and lazy witness formatting.
export function compareJson(actual,expected){
 const verified=new WeakMap(),path=[];
 const fail=kind=>{throw new Error(`${kind}:$${path.map(key=>'.'+key).join('')}`);};
 function visit(a,b){
  if(Object.is(a,b))return;
  if(typeof a!==typeof b||a===null||b===null||typeof a!=='object')fail('VALUE_MISMATCH');
  if(Object.getPrototypeOf(a)!==Object.getPrototypeOf(b))fail('TYPE_MISMATCH');
  if(verified.get(a)===b)return;
  if(Array.isArray(a)){if(a.length!==b.length)fail('LENGTH_MISMATCH');}
  else if(Object.getPrototypeOf(a)!==Object.prototype)fail('NON_JSON_OBJECT');
  const ak=Object.keys(a),bk=Object.keys(b);if(ak.length!==bk.length)fail('KEYSET_MISMATCH');
  for(const key of ak){
   path.push(key);if(!Object.hasOwn(b,key))fail('KEYSET_MISMATCH');visit(a[key],b[key]);path.pop();
  }
  // A new expected identity replaces the prior cache entry. This conservatively
  // repeats comparisons if a source identity maps to multiple expected nodes.
  verified.set(a,b);
 }
 visit(actual,expected);
}
