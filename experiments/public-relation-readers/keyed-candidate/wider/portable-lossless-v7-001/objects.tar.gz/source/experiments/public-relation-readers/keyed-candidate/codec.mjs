export function normalize(value) {
 if(typeof value==='bigint') return Number(value);
 if(value===null||typeof value!=='object') return value;
 const tag=value.$?.split('.').at(-1);
 if(tag==='Nil') return [];
 if(tag==='Con') {const items=[];for(let node=value;node.$==='Con';node=node.tail)items.push(normalize(node.head));return items;}
 if(tag==='Queue') {const front=normalize(value.front),back=normalize(value.back);return {$:'Queue',batches:[...front,...back.reverse()],size:normalize(value.size),dropped:normalize(value.dropped)};}
 if(tag==='Some')return normalize(value.value);
 if(tag==='None')return null;
 if(tag==='Tuple')return [normalize(value.fst),normalize(value.snd)];
 return Object.fromEntries(Object.entries(value).map(([key,item])=>[key,key==='$'?tag:normalize(item)]));
}
