"""Reached JS development mutants; not a qualification cohort."""
import hashlib
import json
import os
from pathlib import Path
import sys

CANDIDATE = Path(__file__).resolve().parent
ROOT = CANDIDATE.parents[2]
sys.path.insert(0, str(ROOT))
from scripts.task_runner import execute_result

MUTATIONS = {
    'advance-on-failure': ('runtime.bend',
        'Ev.activate(positions,id,tick),Nat.add(tick,1n),frameStart,boundary,capacity},Reader{registry,keys},Failed{error}',
        'Ev.update(Ev.activate(positions,id,tick),id,Nat.add(tick,1n),False{}),Nat.add(tick,1n),frameStart,boundary,capacity},Reader{registry,keys},Failed{error}'),
    'advance-wrong-reader': ('runtime.bend',
        'Ev.update(Ev.activate(positions,id,tick),id,Nat.add(tick,1n),False{})',
        'Ev.update(Ev.activate(positions,id,tick),2,Nat.add(tick,1n),False{})'),
    'publish-before-barrier': ('application.bend',
        'X.begin(~W.World<S,RC.Store<S,CellOwners>,Resources<S>,RC.Notice<S,U32>>,~RC.Notice<S,U32>,world),descriptor,source,target)',
        'X.begin(~W.World<S,RC.Store<S,CellOwners>,Resources<S>,RC.Notice<S,U32>>,~RC.Notice<S,U32>,RC.apply_relate(~S,~CellOwners,~Resources<S>,~U32,world,descriptor,source,target)),descriptor,source,target)')
}


def main():
    base = CANDIDATE / 'development-attempts'
    index = 1
    while (base / f'controls-{index:03d}').exists():
        index += 1
    cohort = base / f'controls-{index:03d}'
    cohort.mkdir()
    sources = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
               for p in CANDIDATE.glob('*.bend')}
    (cohort / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
    for name, (filename, before, after) in MUTATIONS.items():
        stage = cohort / name
        stage.mkdir()
        prefix = os.path.relpath(ROOT / 'src', stage)
        for source in CANDIDATE.glob('*.bend'):
            text = source.read_text().replace('../../../src/', prefix + '/')
            if source.name == filename:
                # The premature publication target changes one call; the cursor
                # controls change one exact outcome seam, not a synthetic trace.
                assert text.count(before) == 1, (name, text.count(before))
                text = text.replace(before, after)
            (stage / source.name).write_text(text)
        commands = [('check', ['bend', stage / 'observe.bend', '--check-only'], 5),
                    ('emit', ['bend', stage / 'observe.bend', '-o', stage / 'observe.mjs'], 30),
                    ('consume', ['node', CANDIDATE / 'consumer.mjs', stage / 'observe.mjs'], 5)]
        for label, command, limit in commands:
            result = execute_result(command, limit, cwd=ROOT, capture='split')
            (stage / f'{label}.stdout').write_bytes(result.pop('stdout'))
            stderr = result.pop('stderr')
            (stage / f'{label}.stderr').write_bytes(stderr)
            (stage / f'{label}.json').write_text(json.dumps(dict(result,
                command=list(map(str, command)), timeout=limit,
                developmentOnly=True), indent=2) + '\n')
            assert result['failure'] is None, (name, label, result)
            if label == 'consume':
                assert result['exit'] != 0 and b'AssertionError' in stderr, (name, result)
            else:
                assert result['exit'] == 0, (name, label, result)
        (stage / 'result.json').write_text(json.dumps(dict(developmentOnly=True,
             typechecked=True, emitted=True, reachedConsumer=True,
             completeOracleRejected=True, acceptance=False), indent=2) + '\n')
    print(cohort.relative_to(ROOT))

if __name__ == '__main__':
    main()
