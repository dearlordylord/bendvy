import {deepStrictEqual,throws} from 'node:assert';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {normalize} from './codec-memo.mjs';
import {expected} from './mixed-oracle-v16.mjs';
const {default:api}=await import(pathToFileURL(resolve(process.argv[2])));
const name=process.argv[3];const observed=normalize(api.main());
throws(()=>deepStrictEqual(observed,expected()),{name:'AssertionError'});
const mutated=expected();
for(const root of mutated){
 if(name==='clock')root.marks.find(x=>x.stage==='inserted').relationTick=2;
 else if(name==='cursor'){
  root.relationRegistry.cursor=0;
  for(const m of root.marks.filter(x=>x.stage==='registered')){m.cursor=0;m.added=m.stamp.added>0;m.changed=m.stamp.changed>0;}
 } else if(name==='queue')root.beforePartition=[root.beforePartition[2],root.beforePartition[0],root.beforePartition[1]];
 else throw Error('unknown mutant');
}
deepStrictEqual(observed,mutated);
console.log(JSON.stringify({developmentOnly:true,acceptance:false,completeIssue43:false,killed:true,mutant:name,witness:name==='clock'?'inserted actual world clock diverges from runtime tick':name==='cursor'?'repeated real registered component read incorrectly replays added/changed': 'real deferred queue publishes removal before ordinary events',observed}));
