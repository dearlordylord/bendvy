function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$(_found_0, _stamp_0, _other_0) {
  if (_found_0) {
    return _stamp_0;
  } else {
    return _other_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$((_key_0 === _id_0), _stamp_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$(_equal_0, _entry_0, _rest_0) {
  if (_equal_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _entry_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _entries_0["head"];
    const _key_0 = _t_0["id"];
    const _stamp_0 = _t_0["stamp"];
    const _rest_0 = _entries_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((_key_0 === _id_0), {$: "../../../../src/ecs/lifecycle.Entry", "id": _key_0, "stamp": _stamp_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_entries_0, _id_0, _stamp_0) {
  return {$: "Con", "head": {$: "../../../../src/ecs/lifecycle.Entry", "id": _id_0, "stamp": _stamp_0}, "tail": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_entries_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0) {
  if (!_wasPresent_0) {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": _tick_0, "changed": _tick_0};
  } else {
    const _added_0 = _stamp_0["added"];
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": _added_0, "changed": _tick_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0) {
  if (!_incoming_0) {
    return {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$(_wasPresent_0, _stamp_0, _tick_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058added$(_stamp_0, _cursor_0) {
  const _value_0 = _stamp_0["added"];
  return (_value_0 > _cursor_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058changed$(_stamp_0, _cursor_0) {
  const _value_0 = _stamp_0["changed"];
  return (_value_0 > _cursor_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058selected$(_selection_0, _flag_0) {
  if (_selection_0.$ === "../../../../src/ecs/owner-handoff.Present") {
    if (_flag_0.$ === "None") {
      return false;
    } else {
      return true;
    }
  } else if (_selection_0.$ === "../../../../src/ecs/owner-handoff.Absent") {
    if (_flag_0.$ === "Some") {
      return false;
    } else {
      return true;
    }
  } else {
    return true;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, _result_0) {
  const _main_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "../../../../src/ecs/owner-handoff.PrototypeHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": _values_0};
  } else {
    const _owner_0 = _t_0["value"];
    return {$: "../../../../src/ecs/owner-handoff.PrototypeHandoffState", "main": _main_0, "aux": _aux_0, "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0, "values": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _values_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_inspect_state$(_id_0, _namespace_0, _main_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0) {
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "None"};
  return $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_restore_state$(_id_0, _namespace_0, _aux_0, _live_0, _flags_0, _added_0, _changed_0, _values_0, array_rmw(_main_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_finish_forward$(_capacity_0, _depth_0, _high_0, _state_0) {
  const _main_0 = _state_0["main"];
  const _aux_0 = _state_0["aux"];
  const _live_0 = _state_0["live"];
  const _flags_0 = _state_0["flags"];
  const _added_0 = _state_0["added"];
  const _changed_0 = _state_0["changed"];
  const _values_0 = _state_0["values"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/owner-handoff.Rows", "main": _main_0, "aux": _aux_0, "metadata": {$: "../../../../src/ecs/owner-handoff.MetadataColumns", "live": _live_0, "flags": _flags_0, "added": _added_0, "changed": _changed_0}, "capacity": _capacity_0, "depth": _depth_0, "high_water": _high_0}, "snd": _values_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover_go$($0, $1, $2) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _columns_0 = $1;
      const _ids_0 = $2;
      if (_rows_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
        return {$: "Tuple", "fst": _columns_0, "snd": ($List$reverse$(_ids_0))};
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_columns_0[_x_0 % _columns_0.length] = _x_1, _columns_0);
        $2 = {$: "Con", "head": _id_0, "tail": _ids_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover$(_rows_0, _columns_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover_go$(_rows_0, _columns_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$() {
  return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": [0], "changed": [0], "capacity": 1, "depth": 0, "exceptional": {$: "Nil"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0) {
  return $Bool$and$((_id_0 > 0), (_id_0 <= 131072));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, _observed_0) {
  const _changed_0 = _observed_0["fst"];
  const _last_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": _first_0, "changed": _last_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _observed_0) {
  const _added_0 = _observed_0["fst"];
  const _first_0 = _observed_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$(_added_0, _capacity_0, _depth_0, _exceptional_0, _first_0, {$: "Tuple", fst: _changed_0, snd: _changed_0[_x_0 % _changed_0.length]});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0}, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
    } else {
      const _x_0 = ((_id_0 - 1) >>> 0);
      return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$(_id_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "Tuple", fst: _added_0, snd: _added_0[_x_0 % _added_0.length]});
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0) {
  const _first_0 = _stamp_0["added"];
  const _last_0 = _stamp_0["changed"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = ((_id_0 - 1) >>> 0);
  return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": (_added_0[_x_0 % _added_0.length] = _first_0, _added_0), "changed": (_changed_0[_x_1 % _changed_0.length] = _last_0, _changed_0), "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _id_0 = $1;
      const _stamp_0 = $2;
      const _added_0 = $3;
      const _changed_0 = $4;
      const _capacity_0 = $5;
      const _depth_0 = $6;
      const _exceptional_0 = $7;
      const _fits_0 = $8;
      if (_fuel_0 === 0) {
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_fits_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _stamp_0);
        } else {
          const _next_0 = ((_capacity_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _stamp_0;
          $3 = array_node(_added_0, array_new(_depth_0, 0));
          $4 = array_node(_changed_0, array_new(_depth_0, 0));
          $5 = _next_0;
          $6 = nat_chk(_depth_0 + 1);
          $7 = _exceptional_0;
          $8 = (_id_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0) {
  if (!_isnormal_0) {
    return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_exceptional_0, _id_0, _stamp_0))};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(17, _id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, (_id_0 <= _capacity_0));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, _stamp_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$(_id_0, _stamp_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, _isnormal_0, _fits_0) {
  if (!_isnormal_0) {
    return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_exceptional_0, _id_0))};
  } else {
    if (!_fits_0) {
      return {$: "../../../../src/ecs/indexed-lifecycle.Metadata", "added": _added_0, "changed": _changed_0, "capacity": _capacity_0, "depth": _depth_0, "exceptional": _exceptional_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0});
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0) {
  const _added_0 = _metadata_0["added"];
  const _changed_0 = _metadata_0["changed"];
  const _capacity_0 = _metadata_0["capacity"];
  const _depth_0 = _metadata_0["depth"];
  const _exceptional_0 = _metadata_0["exceptional"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$(_id_0, _added_0, _changed_0, _capacity_0, _depth_0, _exceptional_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$(_id_0)), (_id_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$($0, $1) {
  for (;;) {
    {
      const _rows_0 = $0;
      const _values_0 = $1;
      if (_rows_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
        return _values_0;
      } else {
        const _id_0 = _rows_0["id"];
        const _owner_0 = _rows_0["owner"];
        const _rest_0 = _rows_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        const _x_1 = {$: "Some", "value": _owner_0};
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _x_1, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058registration_equal$(_id_0, _name_0, _access_0, _otherId_0, _otherName_0, _otherAccess_0) {
  return $Bool$and$((_id_0 === _otherId_0), ($Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_name_0, _otherName_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(_access_0, _otherAccess_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$(_keep_0, _meta_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _meta_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$(($Bool$not$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0)))), _meta_0, ($$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$(_rest_0, _id_0, _name_0, _access_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047domains$058member$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_id_0 === _wanted_0);
    const _x_1 = ($$$$047domains$058member$(_rest_0, _wanted_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047domains$058add_checked$(_found_0, _ids_0, _id_0) {
  if (_found_0) {
    return _ids_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _ids_0};
  }
}

function $$$$047domains$058add$(_ids_0, _id_0) {
  return $$$$047domains$058add_checked$(($$$$047domains$058member$(_ids_0, _id_0)), _ids_0, _id_0);
}

function $$$$047domains$058select_boundary$(_registered_0, _cursor_0, _boundary_0) {
  if (!_registered_0) {
    return _boundary_0;
  } else {
    return (_cursor_0 < _boundary_0 ? _cursor_0 : _boundary_0);
  }
}

function $$$$047domains$058boundary$($0, $1, $2) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _ids_0 = $1;
      const _acc_0 = $2;
      if (_positions_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _id_0 = _t_0["id"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = _ids_0;
        $2 = ($$$$047domains$058select_boundary$(($$$$047domains$058member$(_ids_0, _id_0)), _cursor_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047runtime$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((_x_0 === _id_0), _x_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "../../../../src/ecs/relation-types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $runtime$045v14$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(_allowed_0, _id_0, _live_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _live_0, "snd": false};
  } else {
    return {$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$(_clock_0, _allowed_0) {
  if (!_allowed_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058removal_access$(_access_0) {
  if (_access_0.$ === "Nil") {
    return false;
  } else {
    const _first_0 = _access_0["head"];
    return $String$eq$(_first_0, "removal");
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058readers_remain$(_entries_0) {
  if (_entries_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _entries_0["head"];
    const _access_0 = _t_0["access"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047removals$058removal_access$(_access_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047removals$058readers_remain$(_rest_0));
    return (_x_0 || _x_1);
  }
}

function $mixed$045components$045v13$058array_join$(_left_0, _right_0) {
  const _left_1 = _left_0["fst"];
  const _xs_0 = _left_0["snd"];
  const _right_1 = _right_0["fst"];
  const _ys_0 = _right_0["snd"];
  return {$: "Tuple", "fst": array_node(_left_1, _right_1), "snd": ($List$append$(_xs_0, _ys_0))};
}

function $mixed$045components$045v13$058array_project$(_cells_0) {
  if (_cells_0.length === 1) {
    const _value_0 = _cells_0[0];
    return {$: "Tuple", "fst": [_value_0], "snd": {$: "Con", "head": _value_0, "tail": {$: "Nil"}}};
  } else {
    const _left_0 = _cells_0.slice(0, _cells_0.length >> 1);
    const _right_0 = _cells_0.slice(_cells_0.length >> 1);
    return $mixed$045components$045v13$058array_join$(($mixed$045components$045v13$058array_project$(_left_0)), ($mixed$045components$045v13$058array_project$(_right_0)));
  }
}

function $mixed$045components$045v13$058project_join$(_observed_0) {
  const _cells_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "mixed-components-v13.Payload", "cells": _cells_0}, "snd": _values_0};
}

function $mixed$045components$045v13$058project$(_owner_0) {
  const _cells_0 = _owner_0["cells"];
  return $mixed$045components$045v13$058project_join$(($mixed$045components$045v13$058array_project$(_cells_0)));
}

function $cells$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $List$append$(($cells$(_left_0)), ($cells$(_right_0)));
  }
}

function $bool_cells$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $List$append$(($bool_cells$(_left_0)), ($bool_cells$(_right_0)));
  }
}

function $payload$(_owner_0) {
  const _values_0 = _owner_0["cells"];
  return $cells$(_values_0);
}

function $optional$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "None"};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Some", "value": ($payload$(_owner_1))};
  }
}

function $column_values$(_values_0) {
  if (_values_0.length === 1) {
    const _owner_0 = _values_0[0];
    return {$: "Con", "head": ($optional$(_owner_0)), "tail": {$: "Nil"}};
  } else {
    const _left_0 = _values_0.slice(0, _values_0.length >> 1);
    const _right_0 = _values_0.slice(_values_0.length >> 1);
    return $List$append$(($column_values$(_left_0)), ($column_values$(_right_0)));
  }
}

function $retired$(_owners_0) {
  if (_owners_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _owner_0 = _owners_0["head"];
    const _rest_0 = _owners_0["tail"];
    return {$: "Con", "head": ($payload$(_owner_0)), "tail": ($retired$(_rest_0))};
  }
}

function $main$() {
  return {$: "Tuple", "fst": ($snapshot$1260$(($application$1260$()))), "snd": ($snapshot$1261$(($application$1261$())))};
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $snapshot$1260$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _t_1 = _t_0["runtime"];
    const _t_2 = _t_1["world"];
    const _namespace_0 = _t_2["namespace"];
    const _nextId_0 = _t_2["nextId"];
    const _highWater_0 = _t_2["highWater"];
    const _live_0 = _t_2["live"];
    const _capacity_0 = _t_2["capacity"];
    const _depth_0 = _t_2["depth"];
    const _store_0 = _t_2["store"];
    const _resource_0 = _t_2["resource"];
    const _events_0 = _t_2["events"];
    const _commands_0 = _t_2["pending"];
    const _registrations_0 = _t_2["registrations"];
    const _nextSystemId_0 = _t_2["nextSystemId"];
    const _clock_0 = _t_2["clock"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _start_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _cap_0 = _t_1["capacity"];
    const _reader_0 = _t_0["reader"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $synced$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1260$(run_clo((_x_0) => {
  return $identity_world$1260$(_x_0);
}), ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058start$1260$({$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, 65536)))), {$: "Held", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "start": _start_0, "boundary": _boundary_0, "capacity": _cap_0, "reader": _reader_0, "private": _private_0, "deliveries": _deliveries_0, "marks": _marks_0, "beforePartition": _events_0});
  }
}

function $application$1260$() {
  return $mark$1260$(($run$1260$(($publication$1260$(($run$1260$(($run$1260$(($inserted_application$1260$()))))))))), "published");
}

function $snapshot$1261$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _t_1 = _t_0["runtime"];
    const _t_2 = _t_1["world"];
    const _namespace_0 = _t_2["namespace"];
    const _nextId_0 = _t_2["nextId"];
    const _highWater_0 = _t_2["highWater"];
    const _live_0 = _t_2["live"];
    const _capacity_0 = _t_2["capacity"];
    const _depth_0 = _t_2["depth"];
    const _store_0 = _t_2["store"];
    const _resource_0 = _t_2["resource"];
    const _events_0 = _t_2["events"];
    const _commands_0 = _t_2["pending"];
    const _registrations_0 = _t_2["registrations"];
    const _nextSystemId_0 = _t_2["nextSystemId"];
    const _clock_0 = _t_2["clock"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _start_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _cap_0 = _t_1["capacity"];
    const _reader_0 = _t_0["reader"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $synced$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1261$(run_clo((_x_0) => {
  return $identity_world$1261$(_x_0);
}), ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058start$1261$({$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _commands_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, 65536)))), {$: "Held", "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "start": _start_0, "boundary": _boundary_0, "capacity": _cap_0, "reader": _reader_0, "private": _private_0, "deliveries": _deliveries_0, "marks": _marks_0, "beforePartition": _events_0});
  }
}

function $application$1261$() {
  return $mark$1261$(($run$1261$(($publication$1261$(($run$1261$(($run$1261$(($inserted_application$1261$()))))))))), "published");
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $synced$1260$(_result_0, _held_0) {
  const _runtime_0 = _result_0["fst"];
  return $separated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recover$1260$(_runtime_0, {$: "Nil"})), _held_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1260$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1260$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $identity_world$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058start$1260$(_world_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $mark$1260$(_state_0, _stage_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _t_1 = _t_0["runtime"];
    const _world_0 = _t_1["world"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _start_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _capacity_0 = _t_1["capacity"];
    const _reader_0 = _t_0["reader"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $mark_restore$1260$(($marked_named$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _stage_0, _tick_0)), _domains_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _reader_0, _private_0, _deliveries_0, _marks_0);
  }
}

function $run$1260$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _t_1 = _t_0["reader"];
    const _registry_0 = _t_1["registry"];
    const _keys_0 = _t_1["keys"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $run_cursor$1260$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor$1260$(_registry_0)), _keys_0, _private_0, _deliveries_0, _marks_0);
  }
}

function $publication$1260$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _reader_0 = _t_0["reader"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $publication_done$1260$(($runtime$045v14$058with_world$1260$(run_clo((_x_0) => {
  return $queue$1260$(_x_0);
}), _runtime_0)), _reader_0, _private_0, _deliveries_0, _marks_0);
  }
}

function $inserted_application$1260$() {
  return $mark$1260$(($insertion$1260$(($mark$1260$(($run$1260$(($initial$1260$()))), "activated")))), "inserted");
}

function $synced$1261$(_result_0, _held_0) {
  const _runtime_0 = _result_0["fst"];
  return $separated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recover$1261$(_runtime_0, {$: "Nil"})), _held_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world$1261$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1261$(_effect_0(_world_0), _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $identity_world$1261$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058start$1261$(_world_0, _capacity_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058start_named$1261$(_capacity_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)));
}

function $mark$1261$(_state_0, _stage_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _t_1 = _t_0["runtime"];
    const _world_0 = _t_1["world"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _start_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _capacity_0 = _t_1["capacity"];
    const _reader_0 = _t_0["reader"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $mark_restore$1261$(($marked_named$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)), _stage_0, _tick_0)), _domains_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _reader_0, _private_0, _deliveries_0, _marks_0);
  }
}

function $run$1261$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _t_1 = _t_0["reader"];
    const _registry_0 = _t_1["registry"];
    const _keys_0 = _t_1["keys"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $run_cursor$1261$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor$1261$(_registry_0)), _keys_0, _private_0, _deliveries_0, _marks_0);
  }
}

function $publication$1261$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _reader_0 = _t_0["reader"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $publication_done$1261$(($runtime$045v14$058with_world$1262$(run_clo((_x_0) => {
  return $queue$1261$(_x_0);
}), _runtime_0)), _reader_0, _private_0, _deliveries_0, _marks_0);
  }
}

function $inserted_application$1261$() {
  return $mark$1261$(($insertion$1261$(($mark$1261$(($run$1261$(($initial$1261$()))), "activated")))), "inserted");
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $separated$1260$(_result_0, _held_0) {
  const _world_0 = _result_0["world"];
  const _events_0 = _result_0["events"];
  return $removal_registered$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047removals$058register$1260$(_world_0, "removals")), _events_0, _held_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recover$1260$(_runtime_0, _old_removals_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recovery_view$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1260$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058start_named$1260$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $mark_restore$1260$(_marked_0, _domains_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _reader_0, _private_0, _deliveries_0, _marks_0) {
  const _world_0 = _marked_0["fst"];
  const _mark_0 = _marked_0["snd"];
  return {$: "Some", "value": {$: "State", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": _reader_0, "private": _private_0, "deliveries": _deliveries_0, "marks": {$: "Con", "head": _mark_0, "tail": _marks_0}}};
}

function $marked_named$1260$(_named_0, _stage_0, _tick_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $marked_get$1260$(($mixed$045components$045v13$058get$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1})), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, _stage_0, _tick_0);
}

function $run_cursor$1260$(_runtime_0, _identified_0, _keys_0, _private_0, _deliveries_0, _marks_0) {
  const _registry_0 = _identified_0["fst"];
  const _cursor_0 = _identified_0["snd"];
  return $completed$1260$(($runtime$045v14$058run$1260$(_runtime_0, {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}, {$: "Args", "private": _private_0, "cursor": _cursor_0})), _deliveries_0, _marks_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _cursor_0};
}

function $publication_done$1260$(_result_0, _reader_0, _private_0, _deliveries_0, _marks_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return {$: "Some", "value": {$: "State", "runtime": ($runtime$045v14$058barrier$1260$(_runtime_0)), "reader": _reader_0, "private": _private_0, "deliveries": _deliveries_0, "marks": _marks_0}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v14$058with_world$1260$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v14$058with_world_result$1260$(run_loop($runtime$045v14$058effect_clocked$1260$(_effect_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $queue$1260$(_world_0) {
  return $queue_named$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $insertion$1260$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _reader_0 = _t_0["reader"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $inserted$1260$(($runtime$045v14$058with_world$1261$(run_clo((_x_0) => {
  return $insert$1260$(_x_0);
}), _runtime_0)), _reader_0, _private_0, _deliveries_0, _marks_0);
  }
}

function $initial$1260$() {
  return $seeded$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), array_node([301], [302]))));
}

function $separated$1261$(_result_0, _held_0) {
  const _world_0 = _result_0["world"];
  const _events_0 = _result_0["events"];
  return $removal_registered$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047removals$058register$1261$(_world_0, "removals")), _events_0, _held_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recover$1261$(_runtime_0, _old_removals_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recovery_view$1261$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058with_world_result$1261$(_returned_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _returned_0["fst"];
  const _output_0 = _returned_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058start_named$1261$(_capacity_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": {$: "Nil"}, "positions": {$: "Nil"}, "nextReader": 1, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": _capacity_0, "droppedThrough": 0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $mark_restore$1261$(_marked_0, _domains_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _reader_0, _private_0, _deliveries_0, _marks_0) {
  const _world_0 = _marked_0["fst"];
  const _mark_0 = _marked_0["snd"];
  return {$: "Some", "value": {$: "State", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": _reader_0, "private": _private_0, "deliveries": _deliveries_0, "marks": {$: "Con", "head": _mark_0, "tail": _marks_0}}};
}

function $marked_named$1261$(_named_0, _stage_0, _tick_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $marked_get$1261$(($mixed$045components$045v13$058get$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1})), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, _stage_0, _tick_0);
}

function $run_cursor$1261$(_runtime_0, _identified_0, _keys_0, _private_0, _deliveries_0, _marks_0) {
  const _registry_0 = _identified_0["fst"];
  const _cursor_0 = _identified_0["snd"];
  return $completed$1261$(($runtime$045v14$058run$1261$(_runtime_0, {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}, {$: "Args", "private": _private_0, "cursor": _cursor_0})), _deliveries_0, _marks_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _cursor_0};
}

function $publication_done$1261$(_result_0, _reader_0, _private_0, _deliveries_0, _marks_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/relation-commands.Queued") {
    return {$: "Some", "value": {$: "State", "runtime": ($runtime$045v14$058barrier$1261$(_runtime_0)), "reader": _reader_0, "private": _private_0, "deliveries": _deliveries_0, "marks": _marks_0}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v14$058with_world$1262$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v14$058with_world_result$1262$(run_loop($runtime$045v14$058effect_clocked$1262$(_effect_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $queue$1261$(_world_0) {
  return $queue_named$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)));
}

function $insertion$1261$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _runtime_0 = _t_0["runtime"];
    const _reader_0 = _t_0["reader"];
    const _private_0 = _t_0["private"];
    const _deliveries_0 = _t_0["deliveries"];
    const _marks_0 = _t_0["marks"];
    return $inserted$1261$(($runtime$045v14$058with_world$1263$(run_clo((_x_0) => {
  return $insert$1261$(_x_0);
}), _runtime_0)), _reader_0, _private_0, _deliveries_0, _marks_0);
  }
}

function $initial$1261$() {
  return $seeded$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()), array_node([301], [302]))));
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $removal_registered$1260$(_result_0, _events_0, _held_0) {
  if (_result_0.$ === "../../../../src/ecs/removals.Registered") {
    const _world_0 = _result_0["world"];
    const _reader_0 = _result_0["reader"];
    return $removed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047removals$058run$1260$(_reader_0, _world_0)), _events_0, _held_0);
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register$1260$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_named$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recovery_view$1260$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recovered$1260$(_world_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split$1260$(_values_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _all_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_all_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0))));
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(_published_0));
  return {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1260$((0 < _x_0), _batches_0, _tick_0, _published_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $marked_get$1260$(_observed_0, _handle_0, _stage_0, _tick_0) {
  const _world_0 = _observed_0["fst"];
  const _component_0 = _observed_0["snd"];
  return $marked_stamp$1260$(($mixed$045components$045v13$058lifecycle$1260$(_world_0, _handle_0)), _stage_0, _tick_0, _component_0);
}

function $mixed$045components$045v13$058get$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1260$(($mixed$045components$045v13$058family$1260$()), _world_0, _handle_0);
}

function $completed$1260$(_result_0, _deliveries_0, _marks_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "runtime-v14.Succeeded") {
    const _t_1 = _t_0["output"];
    const _private_0 = _t_1["fst"];
    const _t_2 = _t_1["snd"];
    const _readings_0 = _t_2["fst"];
    const _capture_0 = _t_2["snd"];
    return {$: "Some", "value": {$: "State", "runtime": _runtime_0, "reader": _reader_0, "private": _private_0, "deliveries": {$: "Con", "head": _readings_0, "tail": _deliveries_0}, "marks": {$: "Con", "head": _capture_0, "tail": _marks_0}}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v14$058run$1260$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $runtime$045v14$058run_identified$1260$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0)), _keys_0, _args_0);
}

function $runtime$045v14$058barrier$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v14$058barrier_join$1260$(($barrier$058barrier$1260$(_world_0, _domains_0)), _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v14$058with_world_result$1260$(_result_0, _domains_0, _positions_0, __0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$045v14$058with_world_clocked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)), _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v14$058effect_clocked$1260$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $queue_named$1260$(_named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $queued_commands$1260$(($queue_done$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), ($descriptor$1260$()), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 999})))), _namespace_0);
}

function $inserted$1260$(_result_0, _reader_0, _private_0, _deliveries_0, _marks_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0) {
    return {$: "Some", "value": {$: "State", "runtime": _runtime_0, "reader": _reader_0, "private": _private_0, "deliveries": _deliveries_0, "marks": _marks_0}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v14$058with_world$1261$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v14$058with_world_result$1261$(run_loop($runtime$045v14$058effect_clocked$1261$(_effect_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $insert$1260$(_world_0) {
  return $insert_named$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $seeded$1260$(_created_0) {
  if (_created_0.$ === "../../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return $reserved$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $removal_registered$1261$(_result_0, _events_0, _held_0) {
  if (_result_0.$ === "../../../../src/ecs/removals.Registered") {
    const _world_0 = _result_0["world"];
    const _reader_0 = _result_0["reader"];
    return $removed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047removals$058run$1261$(_reader_0, _world_0)), _events_0, _held_0);
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register$1261$(_world_0, _name_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_named$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)), _name_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recovery_view$1261$(_namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _values_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recovered$1261$(_world_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split$1261$(_values_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(_observed_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _world_0 = _observed_0["fst"];
  const _all_0 = _observed_0["snd"];
  const _published_0 = ($List$drop$(_all_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1261$(_batches_0))));
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1261$(_published_0));
  return {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1261$((0 < _x_0), _batches_0, _tick_0, _published_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $marked_get$1261$(_observed_0, _handle_0, _stage_0, _tick_0) {
  const _world_0 = _observed_0["fst"];
  const _component_0 = _observed_0["snd"];
  return $marked_stamp$1261$(($mixed$045components$045v13$058lifecycle$1261$(_world_0, _handle_0)), _stage_0, _tick_0, _component_0);
}

function $mixed$045components$045v13$058get$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1261$(($mixed$045components$045v13$058family$1261$()), _world_0, _handle_0);
}

function $completed$1261$(_result_0, _deliveries_0, _marks_0) {
  const _runtime_0 = _result_0["runtime"];
  const _reader_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "runtime-v14.Succeeded") {
    const _t_1 = _t_0["output"];
    const _private_0 = _t_1["fst"];
    const _t_2 = _t_1["snd"];
    const _readings_0 = _t_2["fst"];
    const _capture_0 = _t_2["snd"];
    return {$: "Some", "value": {$: "State", "runtime": _runtime_0, "reader": _reader_0, "private": _private_0, "deliveries": {$: "Con", "head": _readings_0, "tail": _deliveries_0}, "marks": {$: "Con", "head": _capture_0, "tail": _marks_0}}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v14$058run$1261$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $runtime$045v14$058run_identified$1261$(_runtime_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1263$(_registry_0)), _keys_0, _args_0);
}

function $runtime$045v14$058barrier$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v14$058barrier_join$1261$(($barrier$058barrier$1261$(_world_0, _domains_0)), _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v14$058with_world_result$1262$(_result_0, _domains_0, _positions_0, __0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$045v14$058with_world_clocked$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)), _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v14$058effect_clocked$1262$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $queue_named$1261$(_named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $queued_commands$1261$(($queue_done$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), ($descriptor$1261$()), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 999})))), _namespace_0);
}

function $inserted$1261$(_result_0, _reader_0, _private_0, _deliveries_0, _marks_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0) {
    return {$: "Some", "value": {$: "State", "runtime": _runtime_0, "reader": _reader_0, "private": _private_0, "deliveries": _deliveries_0, "marks": _marks_0}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v14$058with_world$1263$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v14$058with_world_result$1263$(run_loop($runtime$045v14$058effect_clocked$1263$(_effect_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $insert$1261$(_world_0) {
  return $insert_named$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)));
}

function $seeded$1261$(_created_0) {
  if (_created_0.$ === "../../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return $reserved$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $removed$1260$(_result_0, _events_0, _held_0) {
  if (_result_0.$ === "../../../../src/ecs/removals.Completed") {
    const _t_0 = _result_0["reader"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _cursor_0 = _t_0["cursor"];
    const _t_1 = _result_0["outcome"];
    if (_t_1.$ === "../../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_1["world"];
      const _records_0 = _t_1["output"];
      return $event_registered$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058register$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058attach$1260$(_events_0, _world_0)), "ordinary", {$: "Nil"})), _held_0, _records_0, {$: "RemovalSnapshot", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0});
    } else {
      return {$: "None"};
    }
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058run$1260$(_reader_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058named$1260$(_reader_0, {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _ns_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_named$1260$(_named_0, _name_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_view$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _namespace_0, _name_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recovered$1260$(_world_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, _partition_0) {
  const _values_0 = _partition_0["fst"];
  const _fresh_removals_0 = _partition_0["snd"];
  return {$: "../../../../src/ecs/reader-domains.Detached", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_old_removals_0, _fresh_removals_0)))), "events": {$: "../../../../src/ecs/reader-domains.Events", "namespace": _namespace_0, "batches": ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batches$1260$(_batches_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0, "values": _values_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split$1260$(_values_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split_loop$1260$(_values_0, {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}});
}

function $List$drop$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _n_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        if (_n_0 === 0) {
          return {$: "Con", "head": _h_0, "tail": _t_0};
        } else {
          const _p_0 = (_n_0 - 1);
          $0 = _t_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1260$(_batches_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1260$(_batches_0, 0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1260$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_batches_0, {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1260$(_items_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, 0);
}

function $marked_stamp$1260$(_stamped_0, _stage_0, _tick_0, _component_0) {
  const _world_0 = _stamped_0["fst"];
  const _stamp_0 = _stamped_0["snd"];
  return $marked_clock$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)), _stage_0, _tick_0, _stamp_0, _component_0);
}

function $mixed$045components$045v13$058lifecycle$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1260$(($mixed$045components$045v13$058family$1260$()), _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1260$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $mixed$045components$045v13$058family$1260$() {
  return {$: "../../../../src/ecs/component.Family", "name": "Stock"};
}

function $runtime$045v14$058run_identified$1260$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $runtime$045v14$058run_result$1260$(($runtime$045v14$058run_clocked$1260$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)), {$: "runtime-v14.Input", "readings": ($$$$047readings$058all$1260$(_keys_0, _domains_0, ($runtime$045v14$058position_or$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $runtime$045v14$058barrier_join$1260$(_state_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $barrier$058barrier$1260$(_world_0, _domains_0) {
  return $barrier$058opened$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)), _domains_0);
}

function $runtime$045v14$058with_world_clocked$1260$(_clocked_0, _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $runtime$045v14$058with_world_collected$1260$(($$$$047routing$058collect$1260$(_world_0, _clock_0, _domains_0)), _output_0, _positions_0, _clock_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $queued_commands$1260$(_result_0, _namespace_0) {
  const _world_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($mixed$045components$045v13$058enqueue_clear$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_x_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.Original", "event": {$: "mixed-components-v13.Ordinary", "value": 31}}, "tail": {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.Original", "event": {$: "mixed-components-v13.Ordinary", "value": 32}}, "tail": {$: "Nil"}}});
}))), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1})), "snd": _status_0};
}

function $queue_done$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $queue_finished$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../../src/ecs/transaction.Success"})), _status_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $descriptor$1260$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
}

function $runtime$045v14$058with_world_result$1261$(_result_0, _domains_0, _positions_0, __0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$045v14$058with_world_clocked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)), _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v14$058effect_clocked$1261$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $insert_named$1260$(_named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $replaced$1260$(($mixed$045components$045v13$058replace$1260$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "Some", "value": {$: "mixed-components-v13.Payload", "cells": array_node(array_node([11], [12]), array_node([13], [14]))}})));
}

function $reserved$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $activated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($mixed$045components$045v13$058empty$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $removed$1261$(_result_0, _events_0, _held_0) {
  if (_result_0.$ === "../../../../src/ecs/removals.Completed") {
    const _t_0 = _result_0["reader"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _cursor_0 = _t_0["cursor"];
    const _t_1 = _result_0["outcome"];
    if (_t_1.$ === "../../../../src/ecs/system.Succeeded") {
      const _world_0 = _t_1["world"];
      const _records_0 = _t_1["output"];
      return $event_registered$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058register$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058attach$1261$(_events_0, _world_0)), "ordinary", {$: "Nil"})), _held_0, _records_0, {$: "RemovalSnapshot", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0});
    } else {
      return {$: "None"};
    }
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058run$1261$(_reader_0, _world_0) {
  const _ns_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058named$1261$(_reader_0, {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _ns_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_named$1261$(_named_0, _name_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_view$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _namespace_0, _name_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058recovered$1261$(_world_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0, _old_removals_0, _partition_0) {
  const _values_0 = _partition_0["fst"];
  const _fresh_removals_0 = _partition_0["snd"];
  return {$: "../../../../src/ecs/reader-domains.Detached", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1263$(_old_removals_0, _fresh_removals_0)))), "events": {$: "../../../../src/ecs/reader-domains.Events", "namespace": _namespace_0, "batches": ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batches$1261$(_batches_0)), "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "dropped": _dropped_0, "values": _values_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split$1261$(_values_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split_loop$1261$(_values_0, {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size$1261$(_batches_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1261$(_batches_0, 0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_checked$1261$(_nonempty_0, _batches_0, _tick_0, _published_0) {
  if (!_nonempty_0) {
    return _batches_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1262$(_batches_0, {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _published_0}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count$1261$(_items_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, 0);
}

function $marked_stamp$1261$(_stamped_0, _stage_0, _tick_0, _component_0) {
  const _world_0 = _stamped_0["fst"];
  const _stamp_0 = _stamped_0["snd"];
  return $marked_clock$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)), _stage_0, _tick_0, _stamp_0, _component_0);
}

function $mixed$045components$045v13$058lifecycle$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1261$(($mixed$045components$045v13$058family$1261$()), _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get$1261$(_family_0, _world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$(($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0))))), _id_0, _live_0)), _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $mixed$045components$045v13$058family$1261$() {
  return {$: "../../../../src/ecs/component.Family", "name": "Stock"};
}

function $runtime$045v14$058run_identified$1261$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $runtime$045v14$058run_result$1261$(($runtime$045v14$058run_clocked$1261$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)), {$: "runtime-v14.Input", "readings": ($$$$047readings$058all$1261$(_keys_0, _domains_0, ($runtime$045v14$058position_or$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1263$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $runtime$045v14$058barrier_join$1261$(_state_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $barrier$058barrier$1261$(_world_0, _domains_0) {
  return $barrier$058opened$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)), _domains_0);
}

function $runtime$045v14$058with_world_clocked$1262$(_clocked_0, _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $runtime$045v14$058with_world_collected$1262$(($$$$047routing$058collect$1261$(_world_0, _clock_0, _domains_0)), _output_0, _positions_0, _clock_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $queued_commands$1261$(_result_0, _namespace_0) {
  const _world_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($mixed$045components$045v13$058enqueue_clear$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1262$(_x_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.Original", "event": {$: "mixed-components-v13.Ordinary", "value": 31}}, "tail": {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.Original", "event": {$: "mixed-components-v13.Ordinary", "value": 32}}, "tail": {$: "Nil"}}});
}))), {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1})), "snd": _status_0};
}

function $queue_done$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $queue_finished$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../../../src/ecs/transaction.Success"})), _status_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1263$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $descriptor$1261$() {
  return {$: "../../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}};
}

function $runtime$045v14$058with_world_result$1263$(_result_0, _domains_0, _positions_0, __0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$045v14$058with_world_clocked$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)), _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v14$058effect_clocked$1263$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $insert_named$1261$(_named_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $replaced$1261$(($mixed$045components$045v13$058replace$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "Some", "value": {$: "mixed-components-v13.Payload", "cells": array_node(array_node([11], [12]), array_node([13], [14]))}})));
}

function $reserved$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $activated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../../src/ecs/world.CreateRejected", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../../src/ecs/world.Created", "factory": {$: "../../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($mixed$045components$045v13$058empty$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $event_registered$1260$(_result_0, _held_0, _removed_0, _removal_0) {
  if (_result_0.$ === "../../../../src/ecs/event-runtime.Registered") {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    const _registry_0 = _result_0["registry"];
    return $final$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run$1260$(_runtime_0, _reader_0, _registry_0, {$: "Unit"})), _held_0, _removed_0, _removal_0);
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058register$1260$(_runtime_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058attach$1260$(_events_0, _world_0) {
  const _ns_0 = _events_0["namespace"];
  const _batches_0 = _events_0["batches"];
  const _positions_0 = _events_0["positions"];
  const _next_0 = _events_0["nextReader"];
  const _tick_0 = _events_0["tick"];
  const _start_0 = _events_0["frameStart"];
  const _boundary_0 = _events_0["boundary"];
  const _capacity_0 = _events_0["capacity"];
  const _dropped_0 = _events_0["dropped"];
  const _values_0 = _events_0["values"];
  return {$: "../../../../src/ecs/event-runtime.Runtime", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _values_0)), "namespace": _ns_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _next_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058named$1260$(_reader_0, _world_0, _actual_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _name_0 = _reader_0["name"];
  const _cursor_0 = _reader_0["cursor"];
  const _ns_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058checked$1260$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, {$: "Con", "head": "removal", "tail": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}})))), {$: "../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}, {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _cursor_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_view$1260$(_viewed_0, _namespace_0, _name_0) {
  const _world_0 = _viewed_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, {$: "Con", "head": "removal", "tail": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}})), _namespace_0, _name_0, 0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batches$1260$(_batches_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batches_loop$1260$(_batches_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split_loop$1260$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split_reverse$1260$(_acc_0);
      } else {
        const _value_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        const _events_0 = _acc_0["fst"];
        const _removals_0 = _acc_0["snd"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058choose$1260$(($mixed$045components$045v13$058is_event$1260$(_value_0)), _value_0, _events_0, _removals_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1260$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $marked_clock$1260$(_clocked_0, _stage_0, _tick_0, _stamp_0, _component_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "ClockMark", "stage": _stage_0, "relationTick": _tick_0, "worldClock": _clock_0, "stamp": _stamp_0, "component": _component_0, "cursor": {$: "None"}, "added": {$: "None"}, "changed": {$: "None"}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1260$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1260$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, ($mixed$045components$045v13$058take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $runtime$045v14$058run_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "runtime-v14.Ran", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v14.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $runtime$045v14$058outcome$1260$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $runtime$045v14$058run_clocked$1260$(_registry_0, _advanced_0, _input_0) {
  const _world_0 = _advanced_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _input_0);
}

function $$$$047readings$058all$1260$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047readings$058one$1260$(_domains_0, _key_0, _position_0)), "tail": ($$$$047readings$058all$1260$(_rest_0, _domains_0, _position_0))};
  }
}

function $barrier$058opened$1260$(_advanced_0, _domains_0) {
  const _t_0 = _advanced_0["fst"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _tick_0 = _advanced_0["snd"];
  return $barrier$058drain$1260$(($List$reverse$(_pending_0)), {$: "barrier.BarrierState", "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "tick": _tick_0});
}

function $runtime$045v14$058with_world_collected$1260$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $$$$047routing$058collect$1260$(_world_0, _tick_0, _domains_0) {
  return $$$$047routing$058collect_view$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _tick_0, _domains_0);
}

function $mixed$045components$045v13$058enqueue_clear$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058enqueue$1260$(_world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $queue_finished$1260$(_result_0, _status_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $runtime$045v14$058with_world_clocked$1261$(_clocked_0, _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $runtime$045v14$058with_world_collected$1261$(($$$$047routing$058collect$1260$(_world_0, _clock_0, _domains_0)), _output_0, _positions_0, _clock_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $replaced$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _world_0, "snd": true};
    } else {
      return {$: "Tuple", "fst": _world_0, "snd": false};
    }
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": false};
  }
}

function $mixed$045components$045v13$058replace$1260$(_world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1260$(($mixed$045components$045v13$058family$1260$()), _world_0, _handle_0, _incoming_0);
}

function $activated$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return $registered$1260$(($runtime$045v14$058register$1260$(($runtime$045v14$058start$1260$(_world_0)), {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "relation", {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $mixed$045components$045v13$058empty$1260$(__0) {
  return {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1260$()), "retired": {$: "Nil"}}, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $event_registered$1261$(_result_0, _held_0, _removed_0, _removal_0) {
  if (_result_0.$ === "../../../../src/ecs/event-runtime.Registered") {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    const _registry_0 = _result_0["registry"];
    return $final$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run$1261$(_runtime_0, _reader_0, _registry_0, {$: "Unit"})), _held_0, _removed_0, _removal_0);
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058register$1261$(_runtime_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058attach$1261$(_events_0, _world_0) {
  const _ns_0 = _events_0["namespace"];
  const _batches_0 = _events_0["batches"];
  const _positions_0 = _events_0["positions"];
  const _next_0 = _events_0["nextReader"];
  const _tick_0 = _events_0["tick"];
  const _start_0 = _events_0["frameStart"];
  const _boundary_0 = _events_0["boundary"];
  const _capacity_0 = _events_0["capacity"];
  const _dropped_0 = _events_0["dropped"];
  const _values_0 = _events_0["values"];
  return {$: "../../../../src/ecs/event-runtime.Runtime", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, _values_0)), "namespace": _ns_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _next_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058named$1261$(_reader_0, _world_0, _actual_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _name_0 = _reader_0["name"];
  const _cursor_0 = _reader_0["cursor"];
  const _ns_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058checked$1261$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, {$: "Con", "head": "removal", "tail": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}})))), {$: "../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}, {$: "../../../../src/ecs/world.World", "namespace": _ns_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _cursor_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_view$1261$(_viewed_0, _namespace_0, _name_0) {
  const _world_0 = _viewed_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, {$: "Con", "head": "removal", "tail": {$: "Con", "head": _name_0, "tail": {$: "Nil"}}})), _namespace_0, _name_0, 0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1263$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1263$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batches$1261$(_batches_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batches_loop$1261$(_batches_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split_loop$1261$($0, $1) {
  for (;;) {
    {
      const _values_0 = $0;
      const _acc_0 = $1;
      if (_values_0.$ === "Nil") {
        return $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split_reverse$1261$(_acc_0);
      } else {
        const _value_0 = _values_0["head"];
        const _rest_0 = _values_0["tail"];
        const _events_0 = _acc_0["fst"];
        const _removals_0 = _acc_0["snd"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058choose$1261$(($mixed$045components$045v13$058is_event$1261$(_value_0)), _value_0, _events_0, _removals_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058size_loop$1261$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1261$(_items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1262$(_left_0, _right_0) {
  if (_left_0.$ === "Nil") {
    if (_right_0.$ === "Nil") {
      return {$: "Nil"};
    } else {
      return _right_0;
    }
  } else {
    if (_right_0.$ === "Nil") {
      return _left_0;
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1262$(($List$reverse$(_left_0)), _right_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $marked_clock$1261$(_clocked_0, _stage_0, _tick_0, _stamp_0, _component_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "ClockMark", "stage": _stage_0, "relationTick": _tick_0, "worldClock": _clock_0, "stamp": _stamp_0, "component": _component_0, "cursor": {$: "None"}, "added": {$: "None"}, "changed": {$: "None"}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle$1261$(_family_0, _world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1262$(_world_0, _handle_0)), _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_owned$1261$(_id_0, _observed_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/component.MissingEntity"}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, ($mixed$045components$045v13$058take$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $runtime$045v14$058run_result$1261$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "runtime-v14.Ran", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v14.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $runtime$045v14$058outcome$1261$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $runtime$045v14$058run_clocked$1261$(_registry_0, _advanced_0, _input_0) {
  const _world_0 = _advanced_0["fst"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _input_0);
}

function $$$$047readings$058all$1261$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047readings$058one$1261$(_domains_0, _key_0, _position_0)), "tail": ($$$$047readings$058all$1261$(_rest_0, _domains_0, _position_0))};
  }
}

function $barrier$058opened$1261$(_advanced_0, _domains_0) {
  const _t_0 = _advanced_0["fst"];
  const _namespace_0 = _t_0["namespace"];
  const _nextId_0 = _t_0["nextId"];
  const _highWater_0 = _t_0["highWater"];
  const _live_0 = _t_0["live"];
  const _capacity_0 = _t_0["capacity"];
  const _depth_0 = _t_0["depth"];
  const _store_0 = _t_0["store"];
  const _resource_0 = _t_0["resource"];
  const _events_0 = _t_0["events"];
  const _pending_0 = _t_0["pending"];
  const _registrations_0 = _t_0["registrations"];
  const _nextSystemId_0 = _t_0["nextSystemId"];
  const _clock_0 = _t_0["clock"];
  const _tick_0 = _advanced_0["snd"];
  return $barrier$058drain$1261$(($List$reverse$(_pending_0)), {$: "barrier.BarrierState", "world": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "tick": _tick_0});
}

function $runtime$045v14$058with_world_collected$1262$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $$$$047routing$058collect$1261$(_world_0, _tick_0, _domains_0) {
  return $$$$047routing$058collect_view$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _tick_0, _domains_0);
}

function $mixed$045components$045v13$058enqueue_clear$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058enqueue$1261$(_world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1262$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1262$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $queue_finished$1261$(_result_0, _status_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _status_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1263$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $runtime$045v14$058with_world_clocked$1263$(_clocked_0, _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $runtime$045v14$058with_world_collected$1263$(($$$$047routing$058collect$1261$(_world_0, _clock_0, _domains_0)), _output_0, _positions_0, _clock_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $replaced$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/component.Replaced") {
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _world_0, "snd": true};
    } else {
      return {$: "Tuple", "fst": _world_0, "snd": false};
    }
  } else {
    const _world_1 = _result_0["world"];
    return {$: "Tuple", "fst": _world_1, "snd": false};
  }
}

function $mixed$045components$045v13$058replace$1261$(_world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1261$(($mixed$045components$045v13$058family$1261$()), _world_0, _handle_0, _incoming_0);
}

function $activated$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return $registered$1261$(($runtime$045v14$058register$1261$(($runtime$045v14$058start$1261$(_world_0)), {$: "Con", "head": {$: "../domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "relation", {$: "Nil"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1262$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.ReservationRejected", "error": {$: "../../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $mixed$045components$045v13$058empty$1261$(__0) {
  return {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1261$()), "retired": {$: "Nil"}}, "graph": {$: "../../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $final$1260$(_result_0, _held_0, _removed_0, _removal_0) {
  const _t_0 = _result_0["runtime"];
  const _t_1 = _t_0["world"];
  const _namespace_0 = _t_1["namespace"];
  const _nextId_0 = _t_1["nextId"];
  const _highWater_0 = _t_1["highWater"];
  const _live_0 = _t_1["live"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _t_2 = _t_1["store"];
  const _t_3 = _t_2["components"];
  const _owners_0 = _t_3["column"];
  const _mailbox_0 = _t_3["retired"];
  const _graph_0 = _t_2["graph"];
  const _resource_0 = _t_1["resource"];
  const _worldEvents_0 = _t_1["events"];
  const _commands_0 = _t_1["pending"];
  const _registrations_0 = _t_1["registrations"];
  const _nextSystemId_0 = _t_1["nextSystemId"];
  const _clock_0 = _t_1["clock"];
  const _eventBatches_0 = _t_0["batches"];
  const _eventPositions_0 = _t_0["positions"];
  const _eventTick_0 = _t_0["tick"];
  const _eventStart_0 = _t_0["frameStart"];
  const _eventBoundary_0 = _t_0["boundary"];
  const _eventCapacity_0 = _t_0["capacity"];
  const _eventDropped_0 = _t_0["droppedThrough"];
  const _t_4 = _result_0["registry"];
  const _en_0 = _t_4["namespace"];
  const _ei_0 = _t_4["id"];
  const _ename_0 = _t_4["name"];
  const _eaccess_0 = _t_4["access"];
  const _ecursor_0 = _t_4["cursor"];
  const _t_5 = _result_0["completion"];
  if (_t_5.$ === "../../../../src/ecs/event-runtime.Succeeded") {
    const _eventReading_0 = _t_5["output"];
    const _domains_0 = _held_0["domains"];
    const _positions_0 = _held_0["positions"];
    const _tick_0 = _held_0["tick"];
    const _start_0 = _held_0["start"];
    const _boundary_0 = _held_0["boundary"];
    const _cap_0 = _held_0["capacity"];
    const _t_6 = _held_0["reader"];
    const _t_7 = _t_6["registry"];
    const _rn_0 = _t_7["namespace"];
    const _ri_0 = _t_7["id"];
    const _rname_0 = _t_7["name"];
    const _raccess_0 = _t_7["access"];
    const _rcursor_0 = _t_7["cursor"];
    const _keys_0 = _t_6["keys"];
    const _private_0 = _held_0["private"];
    const _deliveries_0 = _held_0["deliveries"];
    const _marks_0 = _held_0["marks"];
    const _beforePartition_0 = _held_0["beforePartition"];
    return {$: "Some", "value": {$: "Final", "marks": ($List$reverse$(_marks_0)), "deliveries": ($List$reverse$(_deliveries_0)), "relationDomains": _domains_0, "relationPositions": _positions_0, "relationTick": _tick_0, "relationStart": _start_0, "relationBoundary": _boundary_0, "relationCapacity": _cap_0, "relationRegistry": {$: "RegistrySnapshot", "namespace": _rn_0, "id": _ri_0, "name": _rname_0, "access": _raccess_0, "cursor": _rcursor_0}, "relationKeys": _keys_0, "private": ($cells$(_private_0)), "beforePartition": _beforePartition_0, "removed": _removed_0, "removalReader": _removal_0, "eventReading": _eventReading_0, "eventBatches": _eventBatches_0, "eventPositions": _eventPositions_0, "eventTick": _eventTick_0, "eventStart": _eventStart_0, "eventBoundary": _eventBoundary_0, "eventCapacity": _eventCapacity_0, "eventDropped": _eventDropped_0, "eventRegistry": {$: "RegistrySnapshot", "namespace": _en_0, "id": _ei_0, "name": _ename_0, "access": _eaccess_0, "cursor": _ecursor_0}, "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": ($bool_cells$(_live_0)), "capacity": _capacity_0, "depth": _depth_0, "column": ($column$1260$(_owners_0)), "retired": ($retired$(_mailbox_0)), "graph": _graph_0, "resources": ($cells$(_resource_0)), "worldEvents": _worldEvents_0, "pendingCount": ($pending$1260$(_commands_0)), "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run$1260$(_runtime_0, _reader_0, _registry_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identified$1260$(_runtime_0, _reader_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_result$1260$(_result_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../src/ecs/event-runtime.RegisterFailed", "runtime": {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_identity$1260$(_world_1, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058checked$1260$(_allowed_0, _reader_0, _world_0, _cursor_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/removals.Invalid", "reader": _reader_0, "world": _world_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058viewed$1260$(_reader_0, _cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_result$1260$(_registered_0, _namespace_0, _name_0, _cursor_0) {
  const _world_0 = _registered_0["fst"];
  const _t_0 = _registered_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Registered") {
    const _id_0 = _t_0["id"];
    return {$: "../../../../src/ecs/removals.Registered", "world": _world_0, "reader": {$: "../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}};
  } else {
    return {$: "../../../../src/ecs/removals.Rejected", "world": _world_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batches_loop$1260$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batch$1260$(_tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split$1260$(_items_0)), _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split_reverse$1260$(_pair_0) {
  const _events_0 = _pair_0["fst"];
  const _removals_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": ($List$reverse$(_events_0)), "snd": ($List$reverse$(_removals_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058choose$1260$(_selected_0, _value_0, _events_0, _removals_0) {
  if (_selected_0) {
    return {$: "Tuple", "fst": {$: "Con", "head": _value_0, "tail": _events_0}, "snd": _removals_0};
  } else {
    return {$: "Tuple", "fst": _events_0, "snd": {$: "Con", "head": _value_0, "tail": _removals_0}};
  }
}

function $mixed$045components$045v13$058is_event$1260$(_event_0) {
  if (_event_0.$ === "../../../../src/ecs/relation-commands.Original") {
    const _t_0 = _event_0["event"];
    if (_t_0.$ === "mixed-components-v13.Ordinary") {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1260$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0)));
}

function $mixed$045components$045v13$058take$1260$(_store_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _retired_0 = _t_0["retired"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "mixed-components-v13.Rest", "graph": _graph_0, "retired": _retired_0}, "snd": _column_0};
}

function $runtime$045v14$058outcome$1260$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $runtime$045v14$058failed_clocked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _error_0);
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $runtime$045v14$058succeeded_clocked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0)));
}

function $$$$047readings$058one$1260$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047readings$058select$1260$(($$$$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047readings$058one$1260$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $barrier$058drain$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _state_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($barrier$058command_collected$1260$(_command_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047routing$058collect_view$1260$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047routing$058collected$1260$(_world_0, ($$$$047routing$058partition_loop$1260$(_items_0, {$: "../routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058enqueue$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058queued$1260$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $runtime$045v14$058with_world_collected$1261$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1260$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $registered$1260$(_result_0) {
  if (_result_0.$ === "runtime-v14.Registered") {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    return {$: "Some", "value": {$: "State", "runtime": _runtime_0, "reader": _reader_0, "private": array_node([501], [502]), "deliveries": {$: "Nil"}, "marks": {$: "Nil"}}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v14$058register$1260$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v14$058registered_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v14$058start$1260$(_world_0) {
  return $runtime$045v14$058started_clocked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1260$() {
  return {$: "../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $final$1261$(_result_0, _held_0, _removed_0, _removal_0) {
  const _t_0 = _result_0["runtime"];
  const _t_1 = _t_0["world"];
  const _namespace_0 = _t_1["namespace"];
  const _nextId_0 = _t_1["nextId"];
  const _highWater_0 = _t_1["highWater"];
  const _live_0 = _t_1["live"];
  const _capacity_0 = _t_1["capacity"];
  const _depth_0 = _t_1["depth"];
  const _t_2 = _t_1["store"];
  const _t_3 = _t_2["components"];
  const _owners_0 = _t_3["column"];
  const _mailbox_0 = _t_3["retired"];
  const _graph_0 = _t_2["graph"];
  const _resource_0 = _t_1["resource"];
  const _worldEvents_0 = _t_1["events"];
  const _commands_0 = _t_1["pending"];
  const _registrations_0 = _t_1["registrations"];
  const _nextSystemId_0 = _t_1["nextSystemId"];
  const _clock_0 = _t_1["clock"];
  const _eventBatches_0 = _t_0["batches"];
  const _eventPositions_0 = _t_0["positions"];
  const _eventTick_0 = _t_0["tick"];
  const _eventStart_0 = _t_0["frameStart"];
  const _eventBoundary_0 = _t_0["boundary"];
  const _eventCapacity_0 = _t_0["capacity"];
  const _eventDropped_0 = _t_0["droppedThrough"];
  const _t_4 = _result_0["registry"];
  const _en_0 = _t_4["namespace"];
  const _ei_0 = _t_4["id"];
  const _ename_0 = _t_4["name"];
  const _eaccess_0 = _t_4["access"];
  const _ecursor_0 = _t_4["cursor"];
  const _t_5 = _result_0["completion"];
  if (_t_5.$ === "../../../../src/ecs/event-runtime.Succeeded") {
    const _eventReading_0 = _t_5["output"];
    const _domains_0 = _held_0["domains"];
    const _positions_0 = _held_0["positions"];
    const _tick_0 = _held_0["tick"];
    const _start_0 = _held_0["start"];
    const _boundary_0 = _held_0["boundary"];
    const _cap_0 = _held_0["capacity"];
    const _t_6 = _held_0["reader"];
    const _t_7 = _t_6["registry"];
    const _rn_0 = _t_7["namespace"];
    const _ri_0 = _t_7["id"];
    const _rname_0 = _t_7["name"];
    const _raccess_0 = _t_7["access"];
    const _rcursor_0 = _t_7["cursor"];
    const _keys_0 = _t_6["keys"];
    const _private_0 = _held_0["private"];
    const _deliveries_0 = _held_0["deliveries"];
    const _marks_0 = _held_0["marks"];
    const _beforePartition_0 = _held_0["beforePartition"];
    return {$: "Some", "value": {$: "Final", "marks": ($List$reverse$(_marks_0)), "deliveries": ($List$reverse$(_deliveries_0)), "relationDomains": _domains_0, "relationPositions": _positions_0, "relationTick": _tick_0, "relationStart": _start_0, "relationBoundary": _boundary_0, "relationCapacity": _cap_0, "relationRegistry": {$: "RegistrySnapshot", "namespace": _rn_0, "id": _ri_0, "name": _rname_0, "access": _raccess_0, "cursor": _rcursor_0}, "relationKeys": _keys_0, "private": ($cells$(_private_0)), "beforePartition": _beforePartition_0, "removed": _removed_0, "removalReader": _removal_0, "eventReading": _eventReading_0, "eventBatches": _eventBatches_0, "eventPositions": _eventPositions_0, "eventTick": _eventTick_0, "eventStart": _eventStart_0, "eventBoundary": _eventBoundary_0, "eventCapacity": _eventCapacity_0, "eventDropped": _eventDropped_0, "eventRegistry": {$: "RegistrySnapshot", "namespace": _en_0, "id": _ei_0, "name": _ename_0, "access": _eaccess_0, "cursor": _ecursor_0}, "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": ($bool_cells$(_live_0)), "capacity": _capacity_0, "depth": _depth_0, "column": ($column$1261$(_owners_0)), "retired": ($retired$(_mailbox_0)), "graph": _graph_0, "resources": ($cells$(_resource_0)), "worldEvents": _worldEvents_0, "pendingCount": ($pending$1261$(_commands_0)), "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run$1261$(_runtime_0, _reader_0, _registry_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identified$1261$(_runtime_0, _reader_0, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1262$(_registry_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_result$1261$(_result_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../../src/ecs/event-runtime.RegisterFailed", "runtime": {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_identity$1261$(_world_1, ($$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1262$(_registry_0)), _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1262$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058checked$1261$(_allowed_0, _reader_0, _world_0, _cursor_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/removals.Invalid", "reader": _reader_0, "world": _world_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058viewed$1261$(_reader_0, _cursor_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058register_result$1261$(_registered_0, _namespace_0, _name_0, _cursor_0) {
  const _world_0 = _registered_0["fst"];
  const _t_0 = _registered_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/world.Registered") {
    const _id_0 = _t_0["id"];
    return {$: "../../../../src/ecs/removals.Registered", "world": _world_0, "reader": {$: "../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _cursor_0}};
  } else {
    return {$: "../../../../src/ecs/removals.Rejected", "world": _world_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1263$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batches_loop$1261$($0, $1) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _acc_0 = $1;
      if (_batches_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batch$1261$(_tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split$1261$(_items_0)), _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058split_reverse$1261$(_pair_0) {
  const _events_0 = _pair_0["fst"];
  const _removals_0 = _pair_0["snd"];
  return {$: "Tuple", "fst": ($List$reverse$(_events_0)), "snd": ($List$reverse$(_removals_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058choose$1261$(_selected_0, _value_0, _events_0, _removals_0) {
  if (_selected_0) {
    return {$: "Tuple", "fst": {$: "Con", "head": _value_0, "tail": _events_0}, "snd": _removals_0};
  } else {
    return {$: "Tuple", "fst": _events_0, "snd": {$: "Con", "head": _value_0, "tail": _removals_0}};
  }
}

function $mixed$045components$045v13$058is_event$1261$(_event_0) {
  if (_event_0.$ === "../../../../src/ecs/relation-commands.Original") {
    const _t_0 = _event_0["event"];
    if (_t_0.$ === "mixed-components-v13.Ordinary") {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append_loop$1262$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_allowed$1261$(_checked_0, _handle_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/lifecycle.Stamp", "added": 0, "changed": 0}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1262$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1262$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1262$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1266$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0)));
}

function $mixed$045components$045v13$058take$1261$(_store_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _retired_0 = _t_0["retired"];
  const _graph_0 = _store_0["graph"];
  return {$: "Tuple", "fst": {$: "mixed-components-v13.Rest", "graph": _graph_0, "retired": _retired_0}, "snd": _column_0};
}

function $runtime$045v14$058outcome$1261$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $runtime$045v14$058failed_clocked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _error_0);
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $runtime$045v14$058succeeded_clocked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0)));
}

function $$$$047readings$058one$1261$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047readings$058select$1261$(($$$$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047readings$058one$1261$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $barrier$058drain$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _state_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($barrier$058command_collected$1261$(_command_0, _state_0));
        continue;
      }
    }
  }
}

function $$$$047routing$058collect_view$1261$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047routing$058collected$1261$(_world_0, ($$$$047routing$058partition_loop$1261$(_items_0, {$: "../routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058enqueue$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058queued$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1262$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1262$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1262$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../../src/ecs/relation-commands.Queued"}};
  }
}

function $runtime$045v14$058with_world_collected$1263$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace$1261$(_family_0, _world_0, _handle_0, _incoming_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1262$(_world_0, _handle_0)), _handle_0, _incoming_0);
}

function $registered$1261$(_result_0) {
  if (_result_0.$ === "runtime-v14.Registered") {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    return {$: "Some", "value": {$: "State", "runtime": _runtime_0, "reader": _reader_0, "private": array_node([501], [502]), "deliveries": {$: "Nil"}, "marks": {$: "Nil"}}};
  } else {
    return {$: "None"};
  }
}

function $runtime$045v14$058register$1261$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$045v14$058registered_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$045v14$058start$1261$(_world_0) {
  return $runtime$045v14$058started_clocked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1262$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Reserved", "handle": {$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058empty$1261$() {
  return {$: "../../../../src/ecs/column.Column", "values": [{$: "None"}], "stamps": {$: "Nil"}};
}

function $column$1260$(_owner_0) {
  if (_owner_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return {$: "Some", "value": {$: "ColumnSnapshot", "values": ($column_values$(_values_0)), "stamps": _stamps_0}};
  } else {
    return {$: "None"};
  }
}

function $pending$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _commands_0["tail"];
    return nat_chk(($pending$1260$(_rest_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identified$1260$(_runtime_0, _reader_0, _identified_0, _args_0) {
  const _registry_0 = _identified_0["fst"];
  const _actual_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identity$1260$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_identity$1260$(_world_0, _identity_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _registry_0 = _identity_0["fst"];
  const _registryId_0 = _identity_0["snd"];
  return {$: "../../../../src/ecs/event-runtime.Registered", "runtime": {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": ((_nextReader_0 + 1) >>> 0), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": {$: "../../../../src/ecs/event-runtime.Reader", "namespace": _namespace_0, "id": _nextReader_0, "registryId": _registryId_0}, "registry": _registry_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058viewed$1260$(_reader_0, _cursor_0, _viewed_0) {
  const _world_0 = _viewed_0["fst"];
  const _values_0 = _viewed_0["snd"];
  const _result_0 = ($consume_removals$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1260$(_values_0, _cursor_0))));
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058consumed$1260$(_reader_0, ($$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1260$(_values_0)), _world_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batch$1260$(_tick_0, _filtered_0, _rest_0) {
  const _t_0 = _filtered_0["fst"];
  if (_t_0.$ === "Nil") {
    return _rest_0;
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _t_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1260$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, ($mixed$045components$045v13$058take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($mixed$045components$045v13$058put$1260$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $runtime$045v14$058failed_clocked$1260$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _error_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "runtime-v14.Ran", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": ($$$$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), "tick": _clock_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v14.Failed", "error": _error_0}};
}

function $runtime$045v14$058succeeded_clocked$1260$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $runtime$045v14$058succeeded_collected$1260$(($$$$047routing$058collect$1260$(_world_0, _clock_0, ($$$$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), _id_0, _clock_0, false)), _clock_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047readings$058select$1260$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047domains$058key_equal$1260$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $barrier$058command_collected$1260$(_command_0, _state_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return $barrier$058collected$1260$(($$$$047routing$058collect$1260$(_command_0(_world_0), _tick_0, _domains_0)), _tick_0);
}

function $$$$047routing$058collected$1260$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047routing$058publish_batches$1260$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047routing$058partition_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047routing$058partition_selected$1260$(($classify$1260$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058queued$1260$(_handle_0, _valid_0) {
  const _world_0 = _valid_0["fst"];
  const _t_0 = _valid_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058remove$1260$(_x_0, _handle_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1260$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $runtime$045v14$058registered_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "runtime-v14.RegistrationFailed", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "runtime-v14.Registered", "runtime": {$: "runtime-v14.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $runtime$045v14$058started_clocked$1260$(_clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "runtime-v14.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": _clock_0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $column$1261$(_owner_0) {
  if (_owner_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _owner_0["values"];
    const _stamps_0 = _owner_0["stamps"];
    return {$: "Some", "value": {$: "ColumnSnapshot", "values": ($column_values$(_values_0)), "stamps": _stamps_0}};
  } else {
    return {$: "None"};
  }
}

function $pending$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _commands_0["tail"];
    return nat_chk(($pending$1261$(_rest_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identified$1261$(_runtime_0, _reader_0, _identified_0, _args_0) {
  const _registry_0 = _identified_0["fst"];
  const _actual_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identity$1261$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058identity$1262$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058registered_identity$1261$(_world_0, _identity_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _registry_0 = _identity_0["fst"];
  const _registryId_0 = _identity_0["snd"];
  return {$: "../../../../src/ecs/event-runtime.Registered", "runtime": {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": ((_nextReader_0 + 1) >>> 0), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": {$: "../../../../src/ecs/event-runtime.Reader", "namespace": _namespace_0, "id": _nextReader_0, "registryId": _registryId_0}, "registry": _registry_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1262$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1262$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058viewed$1261$(_reader_0, _cursor_0, _viewed_0) {
  const _world_0 = _viewed_0["fst"];
  const _values_0 = _viewed_0["snd"];
  const _result_0 = ($consume_removals$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1261$(_values_0, _cursor_0))));
  return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058consumed$1261$(_reader_0, ($$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1261$(_values_0)), _world_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047reader$045domains$058event_batch$1261$(_tick_0, _filtered_0, _rest_0) {
  const _t_0 = _filtered_0["fst"];
  if (_t_0.$ === "Nil") {
    return _rest_0;
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/event-runtime.Batch", "tick": _tick_0, "values": _t_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_world$1261$(_id_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, ($mixed$045components$045v13$058take$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1262$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1262$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058get_projected$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($mixed$045components$045v13$058put$1261$(_rest_0, _column_0)), "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $runtime$045v14$058failed_clocked$1261$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _error_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "runtime-v14.Ran", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": ($$$$047readings$058activate$1261$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), "tick": _clock_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v14.Failed", "error": _error_0}};
}

function $runtime$045v14$058succeeded_clocked$1261$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $runtime$045v14$058succeeded_collected$1261$(($$$$047routing$058collect$1261$(_world_0, _clock_0, ($$$$047readings$058activate$1261$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), _id_0, _clock_0, false)), _clock_0, _frameStart_0, _boundary_0, _capacity_0, _output_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1261$(_result_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1263$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1263$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)), _args_0);
}

function $$$$047readings$058select$1261$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047readings$058queue_reading$1261$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047domains$058key_equal$1261$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $barrier$058command_collected$1261$(_command_0, _state_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return $barrier$058collected$1261$(($$$$047routing$058collect$1261$(_command_0(_world_0), _tick_0, _domains_0)), _tick_0);
}

function $$$$047routing$058collected$1261$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047routing$058publish_batches$1261$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047routing$058partition_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047routing$058partition_selected$1261$(($classify$1261$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058queued$1261$(_handle_0, _valid_0) {
  const _world_0 = _valid_0["fst"];
  const _t_0 = _valid_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058remove$1261$(_x_0, _handle_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1262$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1262$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1263$(_world_0, {$: "../../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_allowed$1261$(_checked_0, _handle_0, _incoming_0) {
  const _world_0 = _checked_0["fst"];
  const _t_0 = _checked_0["snd"];
  if (!_t_0) {
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.MissingEntity"}};
  } else {
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $runtime$045v14$058registered_result$1261$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "runtime-v14.RegistrationFailed", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "runtime-v14.Registered", "runtime": {$: "runtime-v14.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register$1263$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)), _name_0, _access_0);
}

function $runtime$045v14$058started_clocked$1261$(_clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "runtime-v14.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": _clock_0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../../src/ecs/world.Rejected", "error": {$: "../../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../../src/ecs/world.Accepted"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identity$1260$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  const _readerNamespace_0 = _reader_0["namespace"];
  const _readerId_0 = _reader_0["id"];
  const _expected_0 = _reader_0["registryId"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_checked$1260$(($Bool$and$((_namespace_0 === _readerNamespace_0), (_expected_0 === _actual_0))), _world_0, {$: "../../../../src/ecs/event-runtime.Reader", "namespace": _readerNamespace_0, "id": _readerId_0, "registryId": _expected_0}, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $consume_removals$1260$(_records_0) {
  return {$: "Done", "value": _records_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1260$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _cursor_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const __0 = _xs_0["head"];
        const _rest_0 = _xs_0["tail"];
        if (_cursor_0 === 0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058include$1260$(($mixed$045components$045v13$058select_removal$1260$(__0)), ($$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1260$(_rest_0, 0)));
        } else {
          const _p_0 = (_cursor_0 - 1);
          $0 = _rest_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058consumed$1260$(_reader_0, _next_0, _world_0, _result_0) {
  if (_result_0.$ === "Done") {
    const _out_0 = _result_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058finished$1260$(_reader_0, _next_0, {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _out_0});
  } else {
    const _error_0 = _result_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058finished$1260$(_reader_0, _next_0, {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1260$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _xs_0["tail"];
    return nat_chk(($$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1260$(_rest_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1260$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $mixed$045components$045v13$058put$1260$(_rest_0, _column_0) {
  const _graph_0 = _rest_0["graph"];
  const _retired_0 = _rest_0["retired"];
  return {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_0, "retired": _retired_0}, "graph": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058access$1260$(_value_0) {
  if (_value_0.$ === "None") {
    return {$: "../../../../src/ecs/component.ComponentAbsent"};
  } else {
    const _value_1 = _value_0["value"];
    return {$: "../../../../src/ecs/component.Found", "value": _value_1};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1260$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047readings$058activate$1260$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047domains$058activate_one$1260$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $runtime$045v14$058succeeded_collected$1260$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "runtime-v14.Ran", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v14.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../readings.KeyReading", "key": _key_0, "values": ($$$$047queue$058read$1260$({$: "../queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $barrier$058collected$1260$(_joined_0, _tick_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "barrier.BarrierState", "world": _world_0, "domains": _domains_0, "tick": _tick_0};
}

function $$$$047routing$058publish_batches$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047routing$058publish_one$1260$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047routing$058partition_selected$1260$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047routing$058group$1260$(_batches_0, _wanted_0, _item_0))};
  }
}

function $classify$1260$(_notice_0) {
  if (_notice_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    return {$: "Some", "value": {$: "../domains.DeclaredKey", "id": _key_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058remove$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058checked$1260$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1260$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_identity$1261$(_runtime_0, _reader_0, _registry_0, _actual_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _namespace_0 = _runtime_0["namespace"];
  const _batches_0 = _runtime_0["batches"];
  const _positions_0 = _runtime_0["positions"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _dropped_0 = _runtime_0["droppedThrough"];
  const _readerNamespace_0 = _reader_0["namespace"];
  const _readerId_0 = _reader_0["id"];
  const _expected_0 = _reader_0["registryId"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_checked$1261$(($Bool$and$((_namespace_0 === _readerNamespace_0), (_expected_0 === _actual_0))), _world_0, {$: "../../../../src/ecs/event-runtime.Reader", "namespace": _readerNamespace_0, "id": _readerId_0, "registryId": _expected_0}, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1262$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $consume_removals$1261$(_records_0) {
  return {$: "Done", "value": _records_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1261$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _cursor_0 = $1;
      if (_xs_0.$ === "Nil") {
        return {$: "Nil"};
      } else {
        const __0 = _xs_0["head"];
        const _rest_0 = _xs_0["tail"];
        if (_cursor_0 === 0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058include$1261$(($mixed$045components$045v13$058select_removal$1261$(__0)), ($$$$047$$$047$$$047$$$047src$047ecs$047removals$058since$1261$(_rest_0, 0)));
        } else {
          const _p_0 = (_cursor_0 - 1);
          $0 = _rest_0;
          $1 = _p_0;
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058consumed$1261$(_reader_0, _next_0, _world_0, _result_0) {
  if (_result_0.$ === "Done") {
    const _out_0 = _result_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058finished$1261$(_reader_0, _next_0, {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _out_0});
  } else {
    const _error_0 = _result_0["error"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047removals$058finished$1261$(_reader_0, _next_0, {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1261$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _rest_0 = _xs_0["tail"];
    return nat_chk(($$$$047$$$047$$$047$$$047src$047ecs$047removals$058count$1261$(_rest_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1265$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_store$1261$(_id_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1262$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1262$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $mixed$045components$045v13$058put$1261$(_rest_0, _column_0) {
  const _graph_0 = _rest_0["graph"];
  const _retired_0 = _rest_0["retired"];
  return {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_0, "retired": _retired_0}, "graph": _graph_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_sized$1261$(_id_0, _stamps_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.Owned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedOrdinaryOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$($0) {
  for (;;) {
    {
      const _carrier_0 = $0;
      if (_carrier_0.$ === "../../../../src/ecs/column.IndexedPreparedOwned") {
        const _state_0 = _carrier_0["state"];
        return _state_0;
      } else {
        const _inner_0 = _carrier_0["inner"];
        $0 = _inner_0;
        continue;
      }
    }
  }
}

function $$$$047readings$058activate$1261$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047domains$058activate_one$1261$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $runtime$045v14$058succeeded_collected$1261$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "runtime-v14.Ran", "runtime": {$: "runtime-v14.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime-v14.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime-v14.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1261$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_1)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1263$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047readings$058queue_reading$1261$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../readings.KeyReading", "key": _key_0, "values": ($$$$047queue$058read$1261$({$: "../queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $barrier$058collected$1261$(_joined_0, _tick_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "barrier.BarrierState", "world": _world_0, "domains": _domains_0, "tick": _tick_0};
}

function $$$$047routing$058publish_batches$1261$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047routing$058publish_one$1261$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047routing$058partition_selected$1261$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047routing$058group$1261$(_batches_0, _wanted_0, _item_0))};
  }
}

function $classify$1261$(_notice_0) {
  if (_notice_0.$ === "../../../../src/ecs/relation-commands.RelationFailed") {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    return {$: "Some", "value": {$: "../domains.DeclaredKey", "id": _key_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058remove$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058checked$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1262$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1262$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1262$(_world_0, _events_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1263$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid$1263$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1263$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1263$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock$1261$(_id_0, _incoming_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$((_tick_0 < 4294967295), _world_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1263$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1263$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_checked$1260$(_allowed_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/event-runtime.Ran", "runtime": {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../src/ecs/event-runtime.Rejected", "args": _args_0}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_position$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _readerId_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058include$1260$(_item_0, _rest_0) {
  if (_item_0.$ === "None") {
    return _rest_0;
  } else {
    const _value_0 = _item_0["value"];
    return {$: "Con", "head": _value_0, "tail": _rest_0};
  }
}

function $mixed$045components$045v13$058select_removal$1260$(_event_0) {
  if (_event_0.$ === "../../../../src/ecs/relation-commands.Original") {
    const _t_0 = _event_0["event"];
    if (_t_0.$ === "mixed-components-v13.Removal") {
      const _t_1 = _t_0["notice"];
      const _record_0 = _t_1["record"];
      return {$: "Some", "value": _record_0};
    } else {
      return {$: "None"};
    }
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058finished$1260$(_reader_0, _next_0, _outcome_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _name_0 = _reader_0["name"];
  const __0 = _reader_0["cursor"];
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/removals.Completed", "reader": {$: "../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": __0}, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _out_0 = _outcome_0["output"];
    return {$: "../../../../src/ecs/removals.Completed", "reader": {$: "../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _next_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _out_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1260$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($mixed$045components$045v13$058put$1260$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1260$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047domains$058activate_one$1260$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _wanted_0, "queue": ($$$$047queue$058empty$1260$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047domains$058activate_walk$1260$(($$$$047domains$058key_equal$1260$(_key_0, _wanted_0)), {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047domains$058activate_one$1260$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047queue$058read$1260$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0);
}

function $$$$047routing$058publish_one$1260$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _wanted_0, "queue": ($$$$047queue$058publish$1260$(($$$$047queue$058empty$1260$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047routing$058publish_found$1260$(($$$$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047routing$058publish_one$1260$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047routing$058group$1260$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047routing$058group_found$1260$(($$$$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047routing$058group$1260$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058checked$1260$(_handle_0, _valid_0) {
  const _world_0 = _valid_0["fst"];
  const _t_0 = _valid_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058at_clock$1260$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1260$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_owner_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "None"}, "snd": false};
  } else {
    const _owner_1 = _owner_0["value"];
    return {$: "Tuple", "fst": {$: "Some", "value": _owner_1}, "snd": true};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_checked$1261$(_allowed_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/event-runtime.Ran", "runtime": {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../src/ecs/event-runtime.Rejected", "args": _args_0}};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_position$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _readerId_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1262$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058include$1261$(_item_0, _rest_0) {
  if (_item_0.$ === "None") {
    return _rest_0;
  } else {
    const _value_0 = _item_0["value"];
    return {$: "Con", "head": _value_0, "tail": _rest_0};
  }
}

function $mixed$045components$045v13$058select_removal$1261$(_event_0) {
  if (_event_0.$ === "../../../../src/ecs/relation-commands.Original") {
    const _t_0 = _event_0["event"];
    if (_t_0.$ === "mixed-components-v13.Removal") {
      const _t_1 = _t_0["notice"];
      const _record_0 = _t_1["record"];
      return {$: "Some", "value": _record_0};
    } else {
      return {$: "None"};
    }
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047removals$058finished$1261$(_reader_0, _next_0, _outcome_0) {
  const _namespace_0 = _reader_0["namespace"];
  const _id_0 = _reader_0["id"];
  const _name_0 = _reader_0["name"];
  const __0 = _reader_0["cursor"];
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/removals.Completed", "reader": {$: "../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": __0}, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _out_0 = _outcome_0["output"];
    return {$: "../../../../src/ecs/removals.Completed", "reader": {$: "../../../../src/ecs/removals.Reader", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "cursor": _next_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _out_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058lifecycle_join$1261$(_rest_0, _observed_0) {
  const _column_0 = _observed_0["fst"];
  const _stamp_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($mixed$045components$045v13$058put$1261$(_rest_0, _column_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1262$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_checked$1261$(_values_0, _stamps_0, _id_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_checked$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_sized$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_checked$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _valid_0, _same_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    if (_same_0) {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0);
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, (_id_0 < _current_0));
    }
  }
}

function $$$$047domains$058activate_one$1261$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _wanted_0, "queue": ($$$$047queue$058empty$1261$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047domains$058activate_walk$1261$(($$$$047domains$058key_equal$1261$(_key_0, _wanted_0)), {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047domains$058activate_one$1261$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1261$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$({$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1263$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1263$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047queue$058read$1261$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047queue$058read_back$1261$(_front_0, _back_0, _cursor_0);
}

function $$$$047routing$058publish_one$1261$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _wanted_0, "queue": ($$$$047queue$058publish$1261$(($$$$047queue$058empty$1261$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047routing$058publish_found$1261$(($$$$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047routing$058publish_one$1261$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047routing$058group$1261$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047routing$058group_found$1261$(($$$$047domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047routing$058group$1261$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058checked$1261$(_handle_0, _valid_0) {
  const _world_0 = _valid_0["fst"];
  const _t_0 = _valid_0["snd"];
  if (!_t_0) {
    return _world_0;
  } else {
    return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058at_clock$1261$(_handle_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_join$1263$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1263$(_allowed_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1263$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_checked$1261$(_allowed_0, _world_0, _id_0, _observed_0) {
  if (!_allowed_0) {
    const _incoming_0 = _observed_0["fst"];
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  } else {
    const _incoming_1 = _observed_0["fst"];
    const _present_0 = _observed_0["snd"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _present_0, _incoming_1, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1261$(_world_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_join$1263$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_position$1260$(_position_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$({$: "../../../../src/ecs/event-runtime.Position", "id": _readerId_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_1, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1260$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, ($mixed$045components$045v13$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($mixed$045components$045v13$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1260$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1260$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($mixed$045components$045v13$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1260$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047queue$058empty$1260$() {
  return {$: "../queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047domains$058activate_walk$1260$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047domains$058activate_domain$1260$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../src/ecs/system.Completed", "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047queue$058read_loop$1260$(($List$reverse$(_back_0)), _cursor_0, ($$$$047queue$058read_loop$1260$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047queue$058publish$1260$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047queue$058count_loop$1260$(_items_0, 0));
  return $$$$047queue$058publish_checked$1260$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047queue$058count_loop$1260$(_items_0, 0)));
}

function $$$$047routing$058publish_found$1260$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": ($$$$047queue$058publish$1260$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047routing$058group_found$1260$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058at_clock$1260$(_handle_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058published$1260$(_tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $mixed$045components$045v13$058clear$1260$(_x_0, _handle_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1260$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_position$1261$(_position_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_position_0.$ === "None") {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1261$({$: "../../../../src/ecs/event-runtime.Position", "id": _readerId_0, "cursor": 0, "registeredAt": _tick_0}, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  } else {
    const _position_1 = _position_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1261$(_position_1, _batches_0, _dropped_0)), _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0))};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_taken$1261$(_stamps_0, _id_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, ($mixed$045components$045v13$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_current$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, ($mixed$045components$045v13$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_different$1261$(_id_0, _values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_checked$1261$(_id_0, _values_0, _metadata_0, _valid_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "None"};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, array_rmw(_values_0, _x_0, () => _x_1));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_current$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0) {
  if (_owner_0.$ === "None") {
    return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "None"}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "None"}};
  } else {
    const _owned_0 = _owner_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, ($mixed$045components$045v13$058project$(_owned_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_different$1261$(_id_0, _values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _backwards_0) {
  if (_backwards_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, {$: "None"}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0))))));
  } else {
    const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
    const _x_1 = ((_x_0 + 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
  }
}

function $$$$047queue$058empty$1261$() {
  return {$: "../queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047domains$058activate_walk$1261$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047domains$058activate_domain$1261$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1261$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../../src/ecs/system.Completed", "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1263$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047queue$058read_back$1261$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047queue$058read_loop$1261$(($List$reverse$(_back_0)), _cursor_0, ($$$$047queue$058read_loop$1261$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047queue$058publish$1261$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047queue$058count_loop$1261$(_items_0, 0));
  return $$$$047queue$058publish_checked$1261$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047queue$058count_loop$1261$(_items_0, 0)));
}

function $$$$047routing$058publish_found$1261$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": ($$$$047queue$058publish$1261$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047routing$058group_found$1261$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058at_clock$1261$(_handle_0, _clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _tick_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058published$1261$(_tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(run_clo((_x_0) => {
  return $mixed$045components$045v13$058clear$1261$(_x_0, _handle_0);
}), _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1263$(_world_0, {$: "Con", "head": {$: "../../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1263$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1263$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1263$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replace_clock_advanced$1261$(_id_0, _incomingPresent_0, _incoming_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  const _tick_0 = _advanced_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058register_meta$1263$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1260$(_reading_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _items_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_registered_result$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, {$: "../../../../src/ecs/event-runtime.Input", "values": _items_0, "lagged": _lagged_0, "args": _args_0})), _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1260$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1260$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1260$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1260$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(($mixed$045components$045v13$058project$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1260$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($mixed$045components$045v13$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0) {
  return {$: "../../../../src/ecs/column.Indexed", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1260$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, ($mixed$045components$045v13$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1260$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1260$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($mixed$045components$045v13$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047domains$058activate_domain$1260$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047queue$058read_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047queue$058visible_items$1260$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047queue$058publish_checked$1260$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047queue$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058published$1260$(_tick_0, _cleaned_0) {
  const _world_0 = _cleaned_0["fst"];
  const _records_0 = _cleaned_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, ($$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058encode_all$1260$(($$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058stamp$1260$(_tick_0, _records_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $mixed$045components$045v13$058clear$1260$(_store_0, _handle_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _retired_0 = _t_0["retired"];
  const _graph_0 = _store_0["graph"];
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $mixed$045components$045v13$058cleared$1260$({$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058clear$1260$(_column_0, _id_0)), _graph_0, _retired_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1263$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($mixed$045components$045v13$058take$1260$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_reading$1261$(_reading_0, _world_0, _reader_0, _registry_0, _args_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  const _items_0 = _reading_0["values"];
  const _lagged_0 = _reading_0["lagged"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_registered_result$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, {$: "../../../../src/ecs/event-runtime.Input", "values": _items_0, "lagged": _lagged_0, "args": _args_0})), _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reading$1261$(_position_0, _batches_0, _dropped_0) {
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../../src/ecs/event-runtime.Reading", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_lifecycle_got$1261$(_values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_lifecycle_got$1261$(_values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "snd": _stamp_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058plain_view_projected$1261$(_values_0, _stamps_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _projection_0, _stamps_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058view_taken$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Rejected") {
    const _column_0 = _outcome_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "None"}};
  } else {
    const _column_1 = _outcome_0["column"];
    const _t_0 = _outcome_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
    } else {
      const _owner_0 = _t_0["value"];
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(($mixed$045components$045v13$058project$(_owner_0)), _column_1, _id_0);
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_0, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), "stamps": _stamps_0};
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return {$: "../../../../src/ecs/column.Column", "values": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), "stamps": _stamps_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_view_projected$1261$(_values_0, _stamps_0, _capacity_0, _target_0, _rest_1, _past_0, ($mixed$045components$045v13$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, _active_0) {
  if (!_active_0) {
    return _past_0;
  } else {
    return {$: "../../../../src/ecs/column.HistoryCon", "id": _current_0, "value": _owner_0, "rest": _past_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0) {
  return {$: "../../../../src/ecs/column.Indexed", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryOwned", "state": {$: "../../../../src/ecs/column.IndexedOrdinaryState", "values": _values_0, "metadata": _metadata_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_taken$1261$(_id_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "None") {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "None"}};
  } else {
    const _owner_0 = _t_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, ($mixed$045components$045v13$058project$(_owner_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _remaining_0, _past_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": {$: "Some", "value": _owner_0}, "remaining": _remaining_0, "past": _past_0}}}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, _active_0) {
  if (!_active_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, _values_0)))), _metadata_0);
  } else {
    const _x_0 = ((_current_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$(_remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$(_past_0, (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0))))), _metadata_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek_view$1261$($0, $1, $2, $3, $4, $5, $6, $7) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _remaining_0 = $5;
      const _past_0 = $6;
      const _phase_0 = $7;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "snd": {$: "None"}};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "snd": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $6 = _past_0;
            $7 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_view_projected$1261$(_values_0, _metadata_0, _capacity_0, _target_0, _rest_1, _past_0, ($mixed$045components$045v13$058project$(_owner_1)));
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "snd": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _rest_1;
                $6 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $7 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047domains$058activate_domain$1261$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1263$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047queue$058read_loop$1261$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047queue$058visible_items$1261$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047queue$058publish_checked$1261$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047queue$058publish_nonempty$1261$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047queue$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058published$1261$(_tick_0, _cleaned_0) {
  const _world_0 = _cleaned_0["fst"];
  const _records_0 = _cleaned_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1262$(_world_0, ($$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058encode_all$1261$(($$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058stamp$1261$(_tick_0, _records_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store$1262$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $mixed$045components$045v13$058clear$1261$(_store_0, _handle_0) {
  const _t_0 = _store_0["components"];
  const _column_0 = _t_0["column"];
  const _retired_0 = _t_0["retired"];
  const _graph_0 = _store_0["graph"];
  const _namespace_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return $mixed$045components$045v13$058cleared$1261$({$: "../../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _id_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0)), _graph_0, _retired_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish$1263$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1263$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1268$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058live_join$1263$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058replaced$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../../src/ecs/component.Swapped") {
    const _previous_0 = _t_0["previous"];
    return {$: "../../../../src/ecs/component.Replaced", "world": _world_0, "previous": _previous_0};
  } else {
    const _incoming_0 = _t_0["incoming"];
    return {$: "../../../../src/ecs/component.ReplaceRejected", "world": _world_0, "incoming": _incoming_0, "error": {$: "../../../../src/ecs/world.CapacityExceeded"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_world$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(($$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, ($mixed$045components$045v13$058take$1261$(_store_0)))), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_registered_result$1260$(_result_0, _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reject_input$1260$(_args_0, {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, _reader_0, _registry_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_outcome$1260$(_outcome_0, _reader_0, _registry_1, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1260$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1260$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1260$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$({$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1260$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($body$1260$(_world_0, _args_0)));
  }
}

function $$$$047queue$058visible_items$1260$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047queue$058prepend_items$1260$(_items_0, _acc_0);
  }
}

function $$$$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058encode_all$1260$(_notices_0) {
  if (_notices_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _notice_0 = _notices_0["head"];
    const _rest_0 = _notices_0["tail"];
    return {$: "Con", "head": ($mixed$045components$045v13$058encode$1260$(_notice_0)), "tail": ($$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058encode_all$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058stamp$1260$(_tick_0, _records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": {$: "../../../public-inspect/bend-candidate/removal-publication.Notice", "tick": _tick_0, "record": _record_0}, "tail": ($$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058stamp$1260$(_tick_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1262$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $mixed$045components$045v13$058cleared$1260$(_handle_0, _result_0, _graph_0, _retired_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_0, "retired": _retired_0}, "graph": _graph_0}, "snd": {$: "Nil"}};
    } else {
      const _owner_0 = _t_0["value"];
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_0, "retired": {$: "Con", "head": _owner_0, "tail": _retired_0}}, "graph": _graph_0}, "snd": {$: "Con", "head": {$: "../../../../src/ecs/removals.Removed", "entity": _handle_0, "family": {$: "mixed-components-v13.Stock"}}, "tail": {$: "Nil"}}};
    }
  } else {
    const _column_1 = _result_0["column"];
    const _t_1 = _result_0["incoming"];
    if (_t_1.$ === "None") {
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_1, "retired": _retired_0}, "graph": _graph_0}, "snd": {$: "Nil"}};
    } else {
      const _owner_1 = _t_1["value"];
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_1, "retired": {$: "Con", "head": _owner_1, "tail": _retired_0}}, "graph": _graph_0}, "snd": {$: "Nil"}};
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear$1260$(_column_0, _id_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058cleared$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, {$: "None"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1264$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1260$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_registered_result$1261$(_result_0, _reader_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_result_0.$ === "../../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reject_input$1261$(_args_0, {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": _positions_0, "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, _reader_0, _registry_0);
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_outcome$1261$(_outcome_0, _reader_0, _registry_1, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run$1262$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1261$(_batches_0, _cursor_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _batches_0["head"];
    const _tick_0 = _t_0["tick"];
    const _items_0 = _t_0["values"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1261$((_cursor_0 < _tick_0), _items_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since$1261$(_rest_0, _cursor_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(_result_0, _projection_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed$1261$(_projected_0, _column_0, _id_0) {
  const _owner_0 = _projected_0["fst"];
  const _result_0 = _projected_0["snd"];
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    const _x_0 = ((_id_0 - 1) >>> 0);
    const _x_1 = {$: "Some", "value": _owner_0};
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058restored$1261$(array_rmw(_values_0, _x_0, () => _x_1), _result_0, _stamps_0);
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../../src/ecs/column.Prepared", "state": _carrier_0}, _id_0, {$: "Some", "value": _owner_0})));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, {$: "Tuple", "fst": _owner_0, "snd": _result_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_result_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$({$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2}, _id_0, {$: "Some", "value": _owner_0})));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_past$1261$($0, $1) {
  for (;;) {
    {
      const _past_0 = $0;
      const _values_0 = $1;
      if (_past_0.$ === "../../../../src/ecs/column.HistoryNil") {
        return _values_0;
      } else {
        const _id_0 = _past_0["id"];
        const _owner_0 = _past_0["value"];
        const _rest_0 = _past_0["rest"];
        const _x_0 = ((_id_0 - 1) >>> 0);
        $0 = _rest_0;
        $1 = (_values_0[_x_0 % _values_0.length] = _owner_0, _values_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _projection_0 = _result_0["snd"];
  const _x_0 = ((_id_0 - 1) >>> 0);
  const _x_1 = {$: "Some", "value": _owner_0};
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, array_rmw(_values_0, _x_0, () => _x_1));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1263$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1263$(_registry_0, ($body$1261$(_world_0, _args_0)));
  }
}

function $$$$047queue$058visible_items$1261$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047queue$058prepend_items$1261$(_items_0, _acc_0);
  }
}

function $$$$047queue$058publish_nonempty$1261$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058encode_all$1261$(_notices_0) {
  if (_notices_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _notice_0 = _notices_0["head"];
    const _rest_0 = _notices_0["tail"];
    return {$: "Con", "head": ($mixed$045components$045v13$058encode$1261$(_notice_0)), "tail": ($$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058encode_all$1261$(_rest_0))};
  }
}

function $$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058stamp$1261$(_tick_0, _records_0) {
  if (_records_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _record_0 = _records_0["head"];
    const _rest_0 = _records_0["tail"];
    return {$: "Con", "head": {$: "../../../public-inspect/bend-candidate/removal-publication.Notice", "tick": _tick_0, "record": _record_0}, "tail": ($$$$047$$$047$$$047public$045inspect$047bend$045candidate$047removal$045publication$058stamp$1261$(_tick_0, _rest_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1267$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $mixed$045components$045v13$058cleared$1261$(_handle_0, _result_0, _graph_0, _retired_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _t_0 = _result_0["previous"];
    if (_t_0.$ === "None") {
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_0, "retired": _retired_0}, "graph": _graph_0}, "snd": {$: "Nil"}};
    } else {
      const _owner_0 = _t_0["value"];
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_0, "retired": {$: "Con", "head": _owner_0, "tail": _retired_0}}, "graph": _graph_0}, "snd": {$: "Con", "head": {$: "../../../../src/ecs/removals.Removed", "entity": _handle_0, "family": {$: "mixed-components-v13.Stock"}}, "tail": {$: "Nil"}}};
    }
  } else {
    const _column_1 = _result_0["column"];
    const _t_1 = _result_0["incoming"];
    if (_t_1.$ === "None") {
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_1, "retired": _retired_0}, "graph": _graph_0}, "snd": {$: "Nil"}};
    } else {
      const _owner_1 = _t_1["value"];
      return {$: "Tuple", "fst": {$: "../../../../src/ecs/relation-commands.Store", "components": {$: "mixed-components-v13.Cells", "column": _column_1, "retired": {$: "Con", "head": _owner_1, "tail": _retired_0}}, "graph": _graph_0}, "snd": {$: "Nil"}};
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear$1261$(_column_0, _id_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058cleared$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, {$: "None"})));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1263$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1263$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(($List$length$(_edges_0)), {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1269$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_store$1261$(_id_0, _incoming_0, _incomingPresent_0, _tick_0, _split_0) {
  const _rest_0 = _split_0["fst"];
  const _column_0 = _split_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incomingPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _id_0)), _id_0, _incoming_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reject_input$1260$(_input_0, _runtime_0, _reader_0, _registry_0) {
  const _args_0 = _input_0["args"];
  return {$: "../../../../src/ecs/event-runtime.Ran", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../src/ecs/event-runtime.Rejected", "args": _args_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_outcome$1260$(_outcome_0, _reader_0, _registry_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/event-runtime.Ran", "runtime": {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../src/ecs/event-runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../../../../src/ecs/event-runtime.Ran", "runtime": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_1)), _namespace_0, _batches_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _readerId_0, _tick_0, false)), _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../src/ecs/event-runtime.Succeeded", "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1260$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1261$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1260$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1260$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1260$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1260$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1260$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1260$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1260$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1260$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $body$1260$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _t_0 = _input_0["args"];
  const _private_0 = _t_0["private"];
  const _cursor_0 = _t_0["cursor"];
  return $captured$1260$(($marked_named$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), "registered", 0)), _cursor_0, _private_0, _readings_0);
}

function $$$$047queue$058prepend_items$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $mixed$045components$045v13$058encode$1260$(_notice_0) {
  return {$: "../../../../src/ecs/relation-commands.Original", "event": {$: "mixed-components-v13.Removal", "notice": _notice_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058cleared$1260$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1260$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($mixed$045components$045v13$058put$1260$(_rest_0, _column_1)), "snd": {$: "../../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1260$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058reject_input$1261$(_input_0, _runtime_0, _reader_0, _registry_0) {
  const _args_0 = _input_0["args"];
  return {$: "../../../../src/ecs/event-runtime.Ran", "runtime": _runtime_0, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../src/ecs/event-runtime.Rejected", "args": _args_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058run_outcome$1261$(_outcome_0, _reader_0, _registry_0, _readerId_0, _namespace_0, _batches_0, _positions_0, _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0) {
  if (_outcome_0.$ === "../../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../../src/ecs/event-runtime.Ran", "runtime": {$: "../../../../src/ecs/event-runtime.Runtime", "world": _world_0, "namespace": _namespace_0, "batches": _batches_0, "positions": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), "nextReader": _nextReader_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "droppedThrough": _dropped_0}, "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../src/ecs/event-runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../../../../src/ecs/event-runtime.Ran", "runtime": ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058sync_values$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_1)), _namespace_0, _batches_0, ($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _readerId_0, (_tick_0 < 1 ? 0 : _tick_0 - 1))), _readerId_0, _tick_0, false)), _nextReader_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _dropped_0)), "reader": _reader_0, "registry": _registry_0, "completion": {$: "../../../../src/ecs/event-runtime.Succeeded", "output": _output_0}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1262$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058since_checked$1261$(_visible_0, _items_0, _rest_0) {
  if (!_visible_0) {
    return _rest_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058append$1263$(_items_0, _rest_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058viewed_return$1261$(_view_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    return {$: "Tuple", "fst": _column_0, "snd": {$: "Some", "value": _view_0}};
  } else {
    const _column_1 = _result_0["column"];
    return {$: "Tuple", "fst": _column_1, "snd": {$: "None"}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap$1261$(_column_0, _id_0, _incoming_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_sized$1261$(_id_0, _incoming_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_projected_state$1261$(_id_0, _result_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_projected$1261$(_id_0, _values_0, _metadata_0, _result_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_checked$1261$(_values_0, _stamps_0, _id_0, _incoming_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(array_rmw(_values_0, _x_0, () => _incoming_0), _stamps_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_sized$1261$(_id_0, _incoming_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, ($Bool$and$(($Bool$and$((_id_0 > 0), (_id_0 <= _size_0))), (_id_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_view_restored$1261$(_metadata_0, _projection_0, _result_0) {
  const _values_0 = _result_0["fst"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "snd": {$: "Some", "value": _projection_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1263$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $body$1261$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _t_0 = _input_0["args"];
  const _private_0 = _t_0["private"];
  const _cursor_0 = _t_0["cursor"];
  return $captured$1261$(($marked_named$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047world$058namespace$1262$(_world_0)), "registered", 0)), _cursor_0, _private_0, _readings_0);
}

function $$$$047queue$058prepend_items$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $mixed$045components$045v13$058encode$1261$(_notice_0) {
  return {$: "../../../../src/ecs/relation-commands.Original", "event": {$: "mixed-components-v13.Removal", "notice": _notice_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058cleared$1261$(_id_0, _outcome_0) {
  if (_outcome_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _outcome_0["column"];
    const _previous_0 = _outcome_0["previous"];
    return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0)), "previous": _previous_0};
  } else {
    const _column_1 = _outcome_0["column"];
    const _incoming_0 = _outcome_0["incoming"];
    return {$: "../../../../src/ecs/column.Rejected", "column": _column_1, "incoming": _incoming_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append$1263$(_left_0, _right_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1263$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058swap_join$1261$(_rest_0, _id_0, _incoming_0, _tick_0, _result_0) {
  if (_result_0.$ === "../../../../src/ecs/column.Accepted") {
    const _column_0 = _result_0["column"];
    const _previous_0 = _result_0["previous"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047component$058owner_present$1260$(_previous_0)));
  } else {
    const _column_1 = _result_0["column"];
    const _incoming_1 = _result_0["incoming"];
    return {$: "Tuple", "fst": ($mixed$045components$045v13$058put$1261$(_rest_0, _column_1)), "snd": {$: "../../../../src/ecs/component.SwapRejected", "incoming": _incoming_1}};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure$1261$(_column_0, _target_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, ($Bool$and$((_target_0 > 0), (_target_0 <= 131072))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1260$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1260$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1260$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $captured$1260$(_marked_0, _cursor_0, _private_0, _readings_0) {
  const _world_0 = _marked_0["fst"];
  const _t_0 = _marked_0["snd"];
  const _stage_0 = _t_0["stage"];
  const _clock_0 = _t_0["worldClock"];
  const _stamp_0 = _t_0["stamp"];
  const _component_0 = _t_0["component"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Tuple", "fst": _private_0, "snd": {$: "Tuple", "fst": _readings_0, "snd": {$: "ClockMark", "stage": _stage_0, "relationTick": _clock_0, "worldClock": _clock_0, "stamp": _stamp_0, "component": _component_0, "cursor": {$: "Some", "value": _cursor_0}, "added": {$: "Some", "value": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058added$(_stamp_0, _cursor_0))}, "changed": {$: "Some", "value": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058changed$(_stamp_0, _cursor_0))}}}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1260$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1260$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($mixed$045components$045v13$058put$1260$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1260$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1262$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$((_namespace_0 === _actual_0), {$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap_state$1261$(_id_0, _incoming_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, ($Bool$and$((_id_0 > 0), (_id_0 <= _capacity_0))), (_id_0 === _current_0), (_id_0 < _current_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058swapped$1261$(_result_0, _stamps_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0}, "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swap_checked$1261$(_id_0, _incoming_0, _metadata_0, _values_0, _valid_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "incoming": _incoming_0};
  } else {
    const _x_0 = ((_id_0 - 1) >>> 0);
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, array_rmw(_values_0, _x_0, () => _incoming_0));
  }
}

function $captured$1261$(_marked_0, _cursor_0, _private_0, _readings_0) {
  const _world_0 = _marked_0["fst"];
  const _t_0 = _marked_0["snd"];
  const _stage_0 = _t_0["stage"];
  const _clock_0 = _t_0["worldClock"];
  const _stamp_0 = _t_0["stamp"];
  const _component_0 = _t_0["component"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Tuple", "fst": _private_0, "snd": {$: "Tuple", "fst": _readings_0, "snd": {$: "ClockMark", "stage": _stage_0, "relationTick": _clock_0, "worldClock": _clock_0, "stamp": _stamp_0, "component": _component_0, "cursor": {$: "Some", "value": _cursor_0}, "added": {$: "Some", "value": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058added$(_stamp_0, _cursor_0))}, "changed": {$: "Some", "value": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058changed$(_stamp_0, _cursor_0))}}}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_stamp$1261$(_column_0, _id_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1263$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047component$058mark_swapped$1261$(_rest_0, _column_0, _id_0, _incoming_0, _tick_0, _observed_0) {
  const _previous_0 = _observed_0["fst"];
  const _wasPresent_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": ($mixed$045components$045v13$058put$1261$(_rest_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0)))), "snd": {$: "../../../../src/ecs/component.Swapped", "previous": _previous_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_checked$1261$(_column_0, _target_0, _valid_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
    }
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Prepared", "state": _carrier_0};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
    }
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
    }
  } else {
    const _carrier_2 = _column_0["state"];
    if (!_valid_0) {
      return {$: "../../../../src/ecs/column.PreparedIndexed", "state": _carrier_2};
    } else {
      return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1260$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1260$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1260$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$({$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1260$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1260$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1260$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1260$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1260$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1260$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1262$({$: "../../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058prepared_swap$1261$(_values_0, _stamps_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$(_x_1, _values_0, _stamps_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_swap$1261$(_values_0, _metadata_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _id_0, _incoming_0, _valid_0, _same_0, _backwards_0) {
  if (!_valid_0) {
    return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, "incoming": _incoming_0};
  } else {
    if (_same_0) {
      return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _incoming_0, "remaining": _remaining_0, "past": _past_0}}}, "previous": _owner_0};
    } else {
      if (_backwards_0) {
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058swap_recovered$1261$(_id_0, _incoming_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$({$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}})));
      } else {
        const _x_0 = ((_capacity_0 + _capacity_0) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$(_x_1, _values_0, _metadata_0, _capacity_0, _id_0, _incoming_0, _remaining_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058past_current$1261$(_current_0, _owner_0, _past_0, (_current_0 > 0))), {$: "../../../../src/ecs/column.Inspect"});
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_swapped$1261$(_metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _previous_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.Accepted", "column": ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0)), "previous": _previous_0};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$(_stamps_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_clear_state$1261$(_id_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$(_metadata_0, _id_0)), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark$1261$(_column_0, _id_0, _incoming_0, _wasPresent_0, _tick_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0))))};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_1)));
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, _sized_0) {
  const _values_0 = _sized_0["fst"];
  const _size_0 = _sized_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1261$(17, _values_0, _stamps_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_ensure_state$1261$(_target_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}}, (_target_0 <= _capacity_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1260$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1260$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1260$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $U32$log2$(_n_0) {
  return $U32$log2$go$(5, _n_0, 0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1260$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1260$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1260$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1262$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
  } else if (_column_0.$ === "../../../../src/ecs/column.Prepared") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058unseal$1261$(_carrier_0)));
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_1 = _column_0["state"];
    return {$: "../../../../src/ecs/column.Indexed", "state": _carrier_1};
  } else {
    const _carrier_2 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_unseal$1261$(_carrier_2)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _stamps_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": _stamps_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _stamps_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_seek$1261$($0, $1, $2, $3, $4, $5, $6, $7, $8) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _capacity_0 = $3;
      const _target_0 = $4;
      const _incoming_0 = $5;
      const _remaining_0 = $6;
      const _past_0 = $7;
      const _phase_0 = $8;
      if (_fuel_0 === 0) {
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_0 = _remaining_0["id"];
          const _owner_0 = _remaining_0["owner"];
          const _rest_0 = _remaining_0["rest"];
          return {$: "../../../../src/ecs/column.Rejected", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": 0, "owner": {$: "None"}, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_0, "owner": _owner_0, "rest": _rest_0}, "past": _past_0}}}, "incoming": _incoming_0};
        }
      } else {
        const _more_0 = (_fuel_0 - 1);
        if (_remaining_0.$ === "../../../../src/ecs/owner-handoff.HandoffNil") {
          return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffNil"}, "past": _past_0}}}, "previous": {$: "None"}};
        } else {
          const _id_1 = _remaining_0["id"];
          const _owner_1 = _remaining_0["owner"];
          const _rest_1 = _remaining_0["rest"];
          if (_phase_0.$ === "../../../../src/ecs/column.Inspect") {
            $0 = _more_0;
            $1 = _values_0;
            $2 = _metadata_0;
            $3 = _capacity_0;
            $4 = _target_0;
            $5 = _incoming_0;
            $6 = {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1};
            $7 = _past_0;
            $8 = {$: "../../../../src/ecs/column.Choice", "equal": (_target_0 === _id_1), "before": (_target_0 < _id_1)};
            continue;
          } else {
            const _t_0 = _phase_0["equal"];
            if (_t_0) {
              return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": _rest_1, "past": _past_0}}}, "previous": {$: "Some", "value": _owner_1}};
            } else {
              const _t_1 = _phase_0["before"];
              if (_t_1) {
                return {$: "../../../../src/ecs/column.Accepted", "column": {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": _metadata_0, "capacity": _capacity_0, "current": _target_0, "owner": _incoming_0, "remaining": {$: "../../../../src/ecs/owner-handoff.HandoffCon", "id": _id_1, "owner": _owner_1, "rest": _rest_1}, "past": _past_0}}}, "previous": {$: "None"}};
              } else {
                $0 = _more_0;
                $1 = _values_0;
                $2 = _metadata_0;
                $3 = _capacity_0;
                $4 = _target_0;
                $5 = _incoming_0;
                $6 = _rest_1;
                $7 = {$: "../../../../src/ecs/column.HistoryCon", "id": _id_1, "value": {$: "Some", "value": _owner_1}, "rest": _past_0};
                $8 = {$: "../../../../src/ecs/column.Inspect"};
                continue;
              }
            }
          }
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
  return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return {$: "../../../../src/ecs/column.Prepared", "state": {$: "../../../../src/ecs/column.Owned", "state": {$: "../../../../src/ecs/column.State", "values": _values_0, "stamps": ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$(_stamps_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$(_stamps_0, _id_0)), _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_state$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _capacity_0 = _state_0["capacity"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$(_metadata_0, _id_0)));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _stamps_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return {$: "../../../../src/ecs/column.Column", "values": _values_0, "stamps": _stamps_0};
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _stamps_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_prepared$1261$(_target_0, _column_0, _fits_0) {
  if (_fits_0) {
    return _column_0;
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover$1261$(_column_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_sized$1261$(_target_0, _metadata_0, _result_0) {
  const _values_0 = _result_0["fst"];
  const _size_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$(17, _values_0, _metadata_0, _size_0, ($U32$log2$(_size_0)), _target_0, (_target_0 <= _size_0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($event_body$1260$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1260$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1260$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1260$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1260$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0) {
  if (_depth_0 === 0) {
    return [{$: "None"}];
  } else {
    const _rest_0 = (_depth_0 - 1);
    return array_node(($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)), ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_rest_0)));
  }
}

function $U32$log2$go$($0, $1, $2) {
  for (;;) {
    {
      const _k_0 = $0;
      const _n_0 = $1;
      const _b_0 = $2;
      if (_k_0 === 0) {
        return _b_0;
      } else {
        const _p_0 = (_k_0 - 1);
        const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
        const _s_0 = _x_0;
        const _x_1 = (_s_0 >= 32 ? 0 : (_n_0 >>> _s_0) >>> 0);
        const _x_2 = ($Bool$to_u32$((_x_1 !== 0)));
        const _t_0 = nat_chk(_s_0 * _x_2);
        $0 = _p_0;
        $1 = (_t_0 >= 32 ? 0 : (_n_0 >>> _t_0) >>> 0);
        $2 = nat_chk(_b_0 + _t_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1260$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1260$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1260$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1260$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1260$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058run_checked$1262$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, ($event_body$1261$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _stamps_0 = _state_0["stamps"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_current$1261$(_values_0, _stamps_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_state$1261$(_state_0) {
  const _values_0 = _state_0["values"];
  const _metadata_0 = _state_0["metadata"];
  const _current_0 = _state_0["current"];
  const _owner_0 = _state_0["owner"];
  const _remaining_0 = _state_0["remaining"];
  const _past_0 = _state_0["past"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_recover_current$1261$(_values_0, _metadata_0, _current_0, _owner_0, _remaining_0, _past_0, (_current_0 > 0));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))));
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_prepared_mark_got$1261$(_id_0, _incoming_0, _wasPresent_0, _tick_0, _values_0, _capacity_0, _current_0, _owner_0, _remaining_0, _past_0, _result_0) {
  const _metadata_0 = _result_0["fst"];
  const _stamp_0 = _result_0["snd"];
  return {$: "../../../../src/ecs/column.PreparedIndexed", "state": {$: "../../../../src/ecs/column.IndexedPreparedOwned", "state": {$: "../../../../src/ecs/column.IndexedPreparedState", "values": _values_0, "metadata": ($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$(_metadata_0, _id_0, ($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$(_incoming_0, _wasPresent_0, _stamp_0, _tick_0)))), "capacity": _capacity_0, "current": _current_0, "owner": _owner_0, "remaining": _remaining_0, "past": _past_0}}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_recovered$1261$(_target_0, _column_0) {
  if (_column_0.$ === "../../../../src/ecs/column.Column") {
    const _values_0 = _column_0["values"];
    const _stamps_0 = _column_0["stamps"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058ensure_sized$1261$(_target_0, _stamps_0, {$: "Tuple", fst: _values_0, snd: _values_0.length});
  } else if (_column_0.$ === "../../../../src/ecs/column.Indexed") {
    const _carrier_0 = _column_0["state"];
    return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_ensure_state$1261$(_target_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_unseal$1261$(_carrier_0)));
  } else {
    return _column_0;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_grow$1261$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _values_0 = $1;
      const _metadata_0 = $2;
      const _size_0 = $3;
      const _depth_0 = $4;
      const _target_0 = $5;
      const _enough_0 = $6;
      if (_fuel_0 === 0) {
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        }
      } else {
        const _rest_0 = (_fuel_0 - 1);
        if (_enough_0) {
          return $$$$047$$$047$$$047$$$047src$047ecs$047column$058indexed_wrap$1261$(_values_0, _metadata_0);
        } else {
          const _next_0 = ((_size_0 << 1) >>> 0);
          $0 = _rest_0;
          $1 = array_node(_values_0, ($$$$047$$$047$$$047$$$047src$047ecs$047column$058absent$1260$(_depth_0)));
          $2 = _metadata_0;
          $3 = _next_0;
          $4 = nat_chk(_depth_0 + 1);
          $5 = _target_0;
          $6 = (_target_0 <= _next_0);
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $event_body$1260$(_world_0, _input_0) {
  const _values_0 = _input_0["values"];
  const _lagged_0 = _input_0["lagged"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "../../../../src/ecs/event-runtime.Reading", "values": _values_0, "lagged": _lagged_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $Bool$to_u32$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $$$$047$$$047$$$047$$$047src$047ecs$047system$058complete$1262$(_registry_0, _outcome_0) {
  return {$: "../../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $event_body$1261$(_world_0, _input_0) {
  const _values_0 = _input_0["values"];
  const _lagged_0 = _input_0["lagged"];
  return {$: "../../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "../../../../src/ecs/event-runtime.Reading", "values": _values_0, "lagged": _lagged_0}};
}

function $$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $0m1(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/owner-handoff.Rows": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/owner-handoff.Rows has no tag " + v?.$ + " (its tags: ../../../../src/ecs/owner-handoff.Rows); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m0(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m1(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m2(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/indexed-lifecycle.Metadata": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/indexed-lifecycle.Metadata has no tag " + v?.$ + " (its tags: ../../../../src/ecs/indexed-lifecycle.Metadata); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m3(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m4(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/indexed-lifecycle.Metadata": at = at[key] = {...v, "depth": nat_host(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/indexed-lifecycle.Metadata has no tag " + v?.$ + " (its tags: ../../../../src/ecs/indexed-lifecycle.Metadata); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m5(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/world.Growth": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/world.Growth has no tag " + v?.$ + " (its tags: ../../../../src/ecs/world.Growth); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m7(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": nat_host(v["cursor"]), "registeredAt": nat_host(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m6(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m7(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m9(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": BigInt(v["cursor"]), "registeredAt": BigInt(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m8(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m9(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m10(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m7(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m11(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m9(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m16(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "ClockMark": at = at[key] = {...v, "relationTick": BigInt(v["relationTick"])}; return top[0];
      default: throw "bend: ClockMark has no tag " + v?.$ + " (its tags: ClockMark); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m15(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m16(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m21(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../queue.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"]), "count": BigInt(v["count"])}; return top[0];
      default: throw "bend: ../queue.Batch has no tag " + v?.$ + " (its tags: ../queue.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m20(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m21(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m19(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../queue.Queue": at = at[key] = {...v, "front": $0m20(v["front"]), "back": $0m20(v["back"]), "size": BigInt(v["size"]), "dropped": BigInt(v["dropped"])}; return top[0];
      default: throw "bend: ../queue.Queue has no tag " + v?.$ + " (its tags: ../queue.Queue); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m18(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../domains.Domain": at = at[key] = {...v, "queue": $0m19(v["queue"])}; return top[0];
      default: throw "bend: ../domains.Domain has no tag " + v?.$ + " (its tags: ../domains.Domain); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m17(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m18(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m22(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "RemovalSnapshot": at = at[key] = {...v, "cursor": BigInt(v["cursor"])}; return top[0];
      default: throw "bend: RemovalSnapshot has no tag " + v?.$ + " (its tags: RemovalSnapshot); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m24(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Batch has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m23(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m24(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m14(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Final": at = at[key] = {...v, "marks": $0m15(v["marks"]), "relationDomains": $0m17(v["relationDomains"]), "relationPositions": $0m8(v["relationPositions"]), "relationTick": BigInt(v["relationTick"]), "relationStart": BigInt(v["relationStart"]), "relationBoundary": BigInt(v["relationBoundary"]), "relationCapacity": BigInt(v["relationCapacity"]), "removalReader": $0m22(v["removalReader"]), "eventBatches": $0m23(v["eventBatches"]), "eventPositions": $0m8(v["eventPositions"]), "eventTick": BigInt(v["eventTick"]), "eventStart": BigInt(v["eventStart"]), "eventBoundary": BigInt(v["eventBoundary"]), "eventCapacity": BigInt(v["eventCapacity"]), "eventDropped": BigInt(v["eventDropped"]), "depth": BigInt(v["depth"]), "pendingCount": BigInt(v["pendingCount"])}; return top[0];
      default: throw "bend: Final has no tag " + v?.$ + " (its tags: Final); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m13(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m14(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m31(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../queue.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"]), "count": BigInt(v["count"])}; return top[0];
      default: throw "bend: ../queue.Batch has no tag " + v?.$ + " (its tags: ../queue.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m30(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m31(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m29(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../queue.Queue": at = at[key] = {...v, "front": $0m30(v["front"]), "back": $0m30(v["back"]), "size": BigInt(v["size"]), "dropped": BigInt(v["dropped"])}; return top[0];
      default: throw "bend: ../queue.Queue has no tag " + v?.$ + " (its tags: ../queue.Queue); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m28(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../domains.Domain": at = at[key] = {...v, "queue": $0m29(v["queue"])}; return top[0];
      default: throw "bend: ../domains.Domain has no tag " + v?.$ + " (its tags: ../domains.Domain); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m27(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m28(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m33(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../../src/ecs/event-runtime.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"])}; return top[0];
      default: throw "bend: ../../../../src/ecs/event-runtime.Batch has no tag " + v?.$ + " (its tags: ../../../../src/ecs/event-runtime.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m32(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m33(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m26(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Final": at = at[key] = {...v, "marks": $0m15(v["marks"]), "relationDomains": $0m27(v["relationDomains"]), "relationPositions": $0m8(v["relationPositions"]), "relationTick": BigInt(v["relationTick"]), "relationStart": BigInt(v["relationStart"]), "relationBoundary": BigInt(v["relationBoundary"]), "relationCapacity": BigInt(v["relationCapacity"]), "removalReader": $0m22(v["removalReader"]), "eventBatches": $0m32(v["eventBatches"]), "eventPositions": $0m8(v["eventPositions"]), "eventTick": BigInt(v["eventTick"]), "eventStart": BigInt(v["eventStart"]), "eventBoundary": BigInt(v["eventBoundary"]), "eventCapacity": BigInt(v["eventCapacity"]), "eventDropped": BigInt(v["eventDropped"]), "depth": BigInt(v["depth"]), "pendingCount": BigInt(v["pendingCount"])}; return top[0];
      default: throw "bend: Final has no tag " + v?.$ + " (its tags: Final); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m25(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m26(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m12(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m13(v["fst"]), "snd": $0m25(v["snd"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}
export default {
  "../../../../src/ecs/lifecycle.choose": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058choose$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/lifecycle.get": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058get$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/lifecycle.keep": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058keep$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/lifecycle.clear": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058clear$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/lifecycle.set": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058set$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/lifecycle.written": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058written$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/lifecycle.after_write": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058after_write$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/lifecycle.added": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058added$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/lifecycle.changed": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047lifecycle$058changed$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/owner-handoff.selected": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058selected$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/owner-handoff.prototype_handoff_restore_state": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_restore_state$((a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); return r; }, 9),
  "../../../../src/ecs/owner-handoff.prototype_handoff_inspect_state": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_inspect_state$((a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); return r; }, 9),
  "../../../../src/ecs/owner-handoff.prototype_handoff_finish_forward": run_lib((a0, a1, a2, a3) => { const r = $0m0(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_finish_forward$((a0), nat_host(a1), (a2), (a3)))); (a0); BigInt(a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/owner-handoff.prototype_handoff_recover_go": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover_go$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/owner-handoff.prototype_handoff_recover": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047owner$045handoff$058prototype_handoff_recover$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/indexed-lifecycle.empty": run_lib(() => { const r = $0m2(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058empty$()));  return r; }, 0),
  "../../../../src/ecs/indexed-lifecycle.normal": run_lib((a0) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058normal$((a0)))); (a0); return r; }, 1),
  "../../../../src/ecs/indexed-lifecycle.got_changed": run_lib((a0, a1, a2, a3, a4, a5) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_changed$((a0), (a1), nat_host(a2), (a3), (a4), (a5)))); (a0); (a1); BigInt(a2); (a3); (a4); (a5); return r; }, 6),
  "../../../../src/ecs/indexed-lifecycle.got_added": run_lib((a0, a1, a2, a3, a4, a5) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058got_added$((a0), (a1), (a2), nat_host(a3), (a4), (a5)))); (a0); (a1); (a2); BigInt(a3); (a4); (a5); return r; }, 6),
  "../../../../src/ecs/indexed-lifecycle.get_checked": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get_checked$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); (a7); return r; }, 8),
  "../../../../src/ecs/indexed-lifecycle.get": run_lib((a0, a1) => { const r = $0m3(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058get$($0m4(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../../../../src/ecs/indexed-lifecycle.write_ready": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m2(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_ready$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); return r; }, 7),
  "../../../../src/ecs/indexed-lifecycle.write_grow": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8) => { const r = $0m2(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058write_grow$(nat_host(a0), (a1), (a2), (a3), (a4), (a5), nat_host(a6), (a7), (a8)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); BigInt(a6); (a7); (a8); return r; }, 9),
  "../../../../src/ecs/indexed-lifecycle.set_checked": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m2(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set_checked$((a0), (a1), (a2), (a3), (a4), nat_host(a5), (a6), (a7)))); (a0); (a1); (a2); (a3); (a4); BigInt(a5); (a6); (a7); return r; }, 8),
  "../../../../src/ecs/indexed-lifecycle.set": run_lib((a0, a1, a2) => { const r = $0m2(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058set$($0m4(a0), (a1), (a2)))); $0m2(a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/indexed-lifecycle.clear_checked": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = $0m2(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear_checked$((a0), (a1), (a2), (a3), nat_host(a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); BigInt(a4); (a5); (a6); (a7); return r; }, 8),
  "../../../../src/ecs/indexed-lifecycle.clear": run_lib((a0, a1) => { const r = $0m2(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047indexed$045lifecycle$058clear$($0m4(a0), (a1)))); $0m2(a0); (a1); return r; }, 2),
  "../../../../src/ecs/column.recover_selected_rows": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047column$058recover_selected_rows$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/string-equality.equal_walk": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/string-equality.equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/string-equality.access_equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/string-equality.registration_equal": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047string$045equality$058registration_equal$((a0), (a1), (a2), (a3), (a4), (a5)))); (a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "../../../../src/ecs/world.factory": run_lib(() => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058factory$()));  return r; }, 0),
  "../../../../src/ecs/world.grow_live": run_lib((a0, a1, a2, a3) => { const r = $0m5(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058grow_live$(nat_host(a0), (a1), nat_host(a2), (a3)))); BigInt(a0); (a1); BigInt(a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.access_equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058access_equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/world.matching_access": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_access$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/world.matching_id": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058matching_id$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../../../../src/ecs/world.registration_meta_matches": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.registration_list_walk": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../../../../src/ecs/world.registration_list_matches": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/world.next_clock": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047world$058next_clock$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/registration.retained": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047registration$058retained$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/registration.without": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047registration$058without$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.hold_boundary": run_lib((a0, a1) => { const r = BigInt(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0m6(a0), nat_host(a1)))); $0m8(a0); BigInt(a1); return r; }, 2),
  "../../../../src/ecs/event-runtime.update_checked": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m8(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((a0), (a1), (a2), nat_host(a3), nat_host(a4), $0m6(a5), nat_host(a6)))); (a0); (a1); (a2); BigInt(a3); BigInt(a4); $0m8(a5); BigInt(a6); return r; }, 7),
  "../../../../src/ecs/event-runtime.update": run_lib((a0, a1, a2, a3) => { const r = $0m8(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$($0m6(a0), (a1), nat_host(a2), (a3)))); $0m8(a0); (a1); BigInt(a2); (a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.choose_position": run_lib((a0, a1, a2) => { const r = $0m11(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((a0), $0m7(a1), $0m10(a2)))); (a0); $0m9(a1); $0m11(a2); return r; }, 3),
  "../../../../src/ecs/event-runtime.lookup_checked": run_lib((a0, a1, a2) => { const r = $0m11(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$($0m7(a0), (a1), $0m10(a2)))); $0m9(a0); (a1); $0m11(a2); return r; }, 3),
  "../../../../src/ecs/event-runtime.lookup": run_lib((a0, a1) => { const r = $0m11(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$($0m6(a0), (a1)))); $0m8(a0); (a1); return r; }, 2),
  "../../../../src/ecs/event-runtime.activation": run_lib((a0, a1, a2, a3) => { const r = $0m8(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$($0m10(a0), $0m6(a1), (a2), nat_host(a3)))); $0m11(a0); $0m8(a1); (a2); BigInt(a3); return r; }, 4),
  "../../../../src/ecs/event-runtime.activate": run_lib((a0, a1, a2) => { const r = $0m8(run_loop($$$$047$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$($0m6(a0), (a1), nat_host(a2)))); $0m8(a0); (a1); BigInt(a2); return r; }, 3),
  "../domains.member": run_lib((a0, a1) => { const r = (run_loop($$$$047domains$058member$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../domains.add_checked": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047domains$058add_checked$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../domains.add": run_lib((a0, a1) => { const r = (run_loop($$$$047domains$058add$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../domains.select_boundary": run_lib((a0, a1, a2) => { const r = BigInt(run_loop($$$$047domains$058select_boundary$((a0), nat_host(a1), nat_host(a2)))); (a0); BigInt(a1); BigInt(a2); return r; }, 3),
  "../domains.boundary": run_lib((a0, a1, a2) => { const r = BigInt(run_loop($$$$047domains$058boundary$($0m6(a0), (a1), nat_host(a2)))); $0m8(a0); (a1); BigInt(a2); return r; }, 3),
  "../runtime.position_or": run_lib((a0, a1, a2) => { const r = $0m9(run_loop($$$$047runtime$058position_or$($0m10(a0), (a1), nat_host(a2)))); $0m11(a0); (a1); BigInt(a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.contains": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/relation-graph.removed_id": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.remove_id": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/relation-graph.chosen_target": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.chosen_inverse": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.appended_source": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/relation-graph.validation": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$((a0), (a1), (a2), (a3), (a4), (a5), (a6)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "../../../../src/ecs/relation-graph.already": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "runtime-v14.position_or": run_lib((a0, a1, a2) => { const r = $0m9(run_loop($runtime$045v14$058position_or$($0m10(a0), (a1), nat_host(a2)))); $0m11(a0); (a1); BigInt(a2); return r; }, 3),
  "../../../../src/ecs/component.get_live_read": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047component$058get_live_read$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../../src/ecs/component.stamped_tick": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047component$058stamped_tick$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../../src/ecs/removals.removal_access": run_lib((a0) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047removals$058removal_access$((a0)))); (a0); return r; }, 1),
  "../../../../src/ecs/removals.readers_remain": run_lib((a0) => { const r = (run_loop($$$$047$$$047$$$047$$$047src$047ecs$047removals$058readers_remain$((a0)))); (a0); return r; }, 1),
  "mixed-components-v13.array_join": run_lib((a0, a1) => { const r = (run_loop($mixed$045components$045v13$058array_join$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "mixed-components-v13.array_project": run_lib((a0) => { const r = (run_loop($mixed$045components$045v13$058array_project$((a0)))); (a0); return r; }, 1),
  "mixed-components-v13.project_join": run_lib((a0) => { const r = (run_loop($mixed$045components$045v13$058project_join$((a0)))); (a0); return r; }, 1),
  "mixed-components-v13.project": run_lib((a0) => { const r = (run_loop($mixed$045components$045v13$058project$((a0)))); (a0); return r; }, 1),
  "cells": run_lib((a0) => { const r = (run_loop($cells$((a0)))); (a0); return r; }, 1),
  "bool_cells": run_lib((a0) => { const r = (run_loop($bool_cells$((a0)))); (a0); return r; }, 1),
  "payload": run_lib((a0) => { const r = (run_loop($payload$((a0)))); (a0); return r; }, 1),
  "optional": run_lib((a0) => { const r = (run_loop($optional$((a0)))); (a0); return r; }, 1),
  "column_values": run_lib((a0) => { const r = (run_loop($column_values$((a0)))); (a0); return r; }, 1),
  "retired": run_lib((a0) => { const r = (run_loop($retired$((a0)))); (a0); return r; }, 1),
  "main": run_lib(() => { const r = $0m12(run_loop($main$()));  return r; }, 0),
};
