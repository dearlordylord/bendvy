import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const ts=JSON.parse(readFileSync(process.argv[2],'utf8')),bend=JSON.parse(readFileSync(process.argv[3],'utf8'));
assert.equal(ts.observations.length,8);assert.equal(bend.observed.length,2);
for(let index=0;index<2;index++){
 const root=bend.observed[index];const seen=ts.observations.filter(x=>x.root===['ReadersAlpha','ReadersBeta'][index]);
 const captures=root.marks.filter(x=>x.stage==='registered');assert.equal(captures.length,4);
 for(let i=0;i<4;i++){
  const b=captures[i],t=seen[i].snapshots;assert.equal(t.length,1);
  const rows=b.component.$==='Found'?[{id:1,cells:b.component.value}]:[];
  assert.deepEqual(t[0].rows,rows);assert.deepEqual(t[0].added,b.added?[1]:[]);assert.deepEqual(t[0].changed,b.changed?[1]:[]);
  const relations=root.deliveries[i][0];assert.equal(relations.lagged,t[0].relationLag);
  assert.deepEqual(relations.values.map(x=>({operation:'relate',source:x.failure.source,target:x.failure.target,error:x.failure.error.$})),t[0].failures.map(x=>({operation:x.operation,source:x.source,target:x.target,error:x.error._tag})));
 }
 assert.deepEqual(root.eventReading.values.map(x=>x.event.value),seen[3].snapshots[0].events);assert.equal(root.eventReading.lagged,seen[3].snapshots[0].eventLag);assert.deepEqual(root.removed.map(x=>x.entity.id),seen[3].snapshots[0].removed);
}
console.log(JSON.stringify({developmentOnly:true,acceptance:false,completeIssue43:false,matchedRoots:2,matchedRegisteredReads:8,matchedFeatures:['plain affine component payload','added','changed','repeated cursor read','relation failure operation/source/target/error/lag','ordinary event full values/lag','actual removal entity'],excludedFromParityComparison:['backend-specific physical owners','schema-qualified descriptor names','World/stream/removal clock domains'],clockNormalization:false}));
