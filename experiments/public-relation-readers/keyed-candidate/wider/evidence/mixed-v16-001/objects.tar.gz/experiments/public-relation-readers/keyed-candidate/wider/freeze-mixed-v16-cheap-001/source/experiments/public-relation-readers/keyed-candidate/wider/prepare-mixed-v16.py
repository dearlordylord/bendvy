"""Small development-only exact-source JS preflight; no issue acceptance."""
import hashlib,importlib.util,json,os,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4];sys.path.insert(0,str(ROOT))
from scripts.task_runner import Inputs,Runner
W=Path(__file__).resolve().parent;F=W/'freeze-mixed-v16-cheap-001';OUT=W/'mixed-v16-cheap-001'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepare():
 assert not F.exists();sources=set()
 def visit(p):
  p=p.resolve()
  if p in sources:return
  sources.add(p)
  if p.suffix=='.bend':
   for name in re.findall(r'^import\s+(\S+)',p.read_text(),re.M):
    if name!='Base':visit(p.parent/name)
 visit(W/'mixed-clock-v16.bend')
 for n in ['mixed-consumer-v16.mjs','mixed-oracle-v16.mjs','codec-memo.mjs']:sources.add(W/n)
 for n in ['scripts/task_runner.py','scripts/receipt-logs.py','docs/SPEC.md','.references/sources.json']:sources.add(ROOT/n)
 sources.add(Path(__file__).resolve());F.mkdir();stage=F/'source'
 for p in sources:
  q=stage/p.relative_to(ROOT);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
 bend=Path('/home/node/.bend/bin/bend').resolve();node=Path('/home/node/.local/share/mise/installs/node/24.20.0/bin/node').resolve()
 base=[p for p in Path('/home/node/.bend/bend2').rglob('*') if p.is_file()]
 pins=Inputs(files=[*sources,*base,bend,node],directories=[stage]).expected
 entry=stage/(W/'mixed-clock-v16.bend').relative_to(ROOT);consumer=stage/(W/'mixed-consumer-v16.mjs').relative_to(ROOT)
 cmds=[{'label':'check','argv':[str(bend),str(entry),'--check-only'],'limit':5},{'label':'emit','argv':[str(bend),str(entry),'-o',str(OUT/'mixed.mjs')],'limit':30},{'label':'consume','argv':[str(node),str(consumer),str(OUT/'mixed.mjs')],'limit':5}]
 env=dict(os.environ,BEND_NO_TELEMETRY='1');ep=F/'environment.json';ep.write_text(json.dumps(env,sort_keys=True));ep.chmod(0o600)
 plan={'developmentOnly':True,'acceptance':False,'completeIssue43':False,'commands':cmds,'inputs':pins,'environmentSHA256':sha(ep),'scope':'Three real registered bodies, component C.get/lifecycle, actual retained Registry cursor, affine payloads, deferred clear/removal/ordinary event/relation failure; independent whole two-schema literal. No TS counterpart, no Native or acceptance.'}
 (F/'execution-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(sha(F/'execution-plan.json'))
if __name__=='__main__':prepare()
