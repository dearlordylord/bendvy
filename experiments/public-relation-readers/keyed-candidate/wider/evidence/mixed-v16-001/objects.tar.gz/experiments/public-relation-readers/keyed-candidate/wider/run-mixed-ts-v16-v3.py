"""Frozen one-command actual pinned TS development preflight."""
import hashlib,importlib.util,json,os,sys
from pathlib import Path
R=Path(__file__).resolve().parents[4];sys.path.insert(0,str(R))
from scripts.task_runner import Inputs,Runner
W=Path(__file__).resolve().parent;O=W/'mixed-ts-v16-cheap-003';P=O/'execution-plan.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prepare():
 O.mkdir();src=W/'mixed-reference-v16.mjs';node=Path('/home/node/.local/share/mise/installs/node/24.20.0/bin/node').resolve();files=[src,Path(__file__).resolve(),node,*[p for p in (R/'.references/bevy-ts/packages/core/src').rglob('*') if p.is_file()],R/'.references/sources.json',R/'scripts/task_runner.py',R/'scripts/receipt-logs.py'];ep=O/'environment.json';ep.write_text(json.dumps(dict(os.environ),sort_keys=True));ep.chmod(0o600)
 P.write_text(json.dumps({'developmentOnly':True,'acceptance':False,'command':[str(node),str(src)],'limit':5,'pins':{str(p):sha(p) for p in files},'environmentSHA256':sha(ep)},indent=2)+'\n');print(sha(P))
def execute():
 plan=json.loads(P.read_text());ep=O/'environment.json';assert sha(ep)==plan['environmentSHA256'];i=Inputs(files=[*plan['pins'],P,ep]);assert all(i.expected[k]==v for k,v in plan['pins'].items());sp=importlib.util.spec_from_file_location('logs',R/'scripts/receipt-logs.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);logs=m.CommandLogs(O,['reference']);runner=Runner(logs,inputs=i,env=json.loads(ep.read_text()),cwd=R,capture='split')
 try:result=runner.run('reference',plan['command'],5)
 except Exception as e:result=e.result
 result.pop('stdout',None);result.pop('stderr',None);receipt=dict(result,developmentOnly=True,acceptance=False,completeIssue43=False,planSHA256=sha(P),rawPins=logs.hashes);(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
if sys.argv[1:] == ['--prepare-only']:prepare()
elif sys.argv[1:] == ['--execute']:execute()
else:raise SystemExit('use --prepare-only or --execute')
