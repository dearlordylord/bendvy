"""No-child portable snapshot of named mixed-reader development evidence."""
import hashlib,io,json,tarfile
from pathlib import Path
W=Path(__file__).resolve().parent;R=W.parents[3];DEST=W/'evidence/mixed-v16-001'
def sha(data):return hashlib.sha256(data).hexdigest()
def main():
 assert not DEST.exists()
 terminal=W/'mixed-v16-controls-001/receipt.json';receipt=json.loads(terminal.read_text());assert receipt['status']=='MIXED_DEVELOPMENT_PASS';plan=W/'freeze-mixed-v16-controls-001/execution-plan.json';assert sha(plan.read_bytes())==receipt['planSHA256']
 for field in ['generatedPins','receiptPins','toolProbeReceiptPins']:
  for name,h in receipt[field].items():assert sha(Path(name).read_bytes())==h,name
 for folder,field in [(W/'mixed-v16-controls-001','rawPins'),(W/'mixed-v16-controls-001/tool-probes','toolProbeRawPins')]:
  for name,h in receipt[field].items():assert sha((folder/name).read_bytes())==h,name
 files={}
 def add(p):
  p=p.resolve();assert p.is_file()
  if p.read_bytes().startswith(b'\x7fELF'):return
  if p.name=='environment.json' or '__pycache__' in p.parts:return
  files[str(p.relative_to(R))]=p.read_bytes()
 for directory in [W/'freeze-mixed-v16-controls-001',W/'mixed-v16-controls-001',W/'freeze-mixed-v16-cheap-001',W/'mixed-v16-cheap-001',W/'mixed-ts-v16-cheap-003']:
  for p in directory.rglob('*'):
   if p.is_file():add(p)
 # Include actual TS adapter and its consumed reference files as verified in its own receipt.
 tsp=json.loads((W/'mixed-ts-v16-cheap-003/execution-plan.json').read_text())
 for name,h in tsp['pins'].items():
  p=Path(name);assert sha(p.read_bytes())==h,name
  if p.is_relative_to(R):add(p)
 for p in [W/'MIXED-V16-DEVELOPMENT.md',Path(__file__)]:add(p)
 DEST.mkdir(parents=True)
 with tarfile.open(DEST/'objects.tar.gz','w:gz') as t:
  for name,data in sorted(files.items()):
   item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(data))
 index={'developmentOnly':True,'acceptance':False,'completeIssue43':False,'terminalSHA256':sha(terminal.read_bytes()),'archiveSHA256':sha((DEST/'objects.tar.gz').read_bytes()),'files':{n:{'sha256':sha(d),'bytes':len(d)} for n,d in sorted(files.items())},'excluded':['ELF executable contents (hashes retained)','private environment values','Python caches'],'scope':'Named complete v16 mixed reader development JS/TS/Native and compiling mutants only; no production integration or performance qualification.'}
 (DEST/'index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'files':len(files),'archiveBytes':(DEST/'objects.tar.gz').stat().st_size,'terminalSHA256':index['terminalSHA256']}))
if __name__=='__main__':main()
