# Actual registered mixed readers: development checkpoint

This is incomplete issue #43 work. It does not adopt a production runtime, approve a new clock policy, pass performance qualification, or close full parity.

`mixed-clock-v16.bend` retains one real system Registry per nominal schema. Before each run it obtains the owning Registry's previous cursor through `Sy.cursor` and passes that cursor together with the affine private Array through `Args`. The registered body itself consumes and returns World through public component `get` and `lifecycle`; it evaluates public `Lifecycle.added/changed` against that actual previous cursor. Read-only captures are returned by the body, rather than inferred from an external observer.

Each schema executes initial read, actual component insertion, inserted read, repeat read, a real queued relation failure plus ordinary-event publication and component clear, and final read. Every component/private/resource Array cell and complete World/domain/queue/Registry/removal/event observation is retained in the authored literal oracle. The inserted component owns `[11,12,13,14]`; first read reports added/changed true, repeat reports false with the same payload and stamp. World and relation clocks are actual returned World clocks; event ticks and removal offsets remain separate existing domains.

## Observed positive development evidence

- `freeze-mixed-v15-cheap-001`: retained checker failure because a Data capture contained default affine `Maybe<U32>`. Fixed by explicit `Maybe<&2,U32>`; no cap or oracle change.
- `mixed-v15-cheap-002/receipt.json`: frozen check, JS emit, complete two-schema literal consumer all exit 0, caps 5/30/5 seconds. This earlier fixture lacks the repeated public added/changed control; it is retained unchanged.
- `mixed-v16-cheap-001/receipt.json`: frozen check, JS emit, complete stronger two-schema literal all exit 0 at the same caps. Full raw output SHA256 `0a289c85ec1938b97c95bf2a865ae6a67faa9257c0cc618746ca8727463b69eb`.
- `mixed-ts-v16-cheap-001` and `002`: retained failed actual TS adapter attempts. First returned command status from a callback; second used incorrect insert argument shape. Pinned `Command.ts` specifies `[descriptor,value]` entries.
- `mixed-ts-v16-cheap-003/receipt.json`: corrected actual pinned TS adapter exits 0 under 5 seconds. Eight complete observations across two nominal roots, with exact callback assertions for component payload, added/changed first and repeat, relation failure, ordinary events and actual removal. Full raw SHA256 `280640d6d796af6dc90e769b0951233ad750b2d8eab2eb05d69581ef78f00039`.

Cheap receipts pin transitive sources and installed bytes for failure localization. They are not a complete installed resolver/negative/backend delivery cohort. Exact current-source mutation and Native admission remain separate.

## Prospective controls

`freeze-mixed-v16-controls-001/execution-plan.json` SHA256 `be7c76c0d0a1edc84f4cda278357deb7d9a6a0a29fdc688e88792d71c5ef8f55` was independently admitted and executed unchanged. It has 14 semantic commands: retained actual TS/Bend public comparison; three compilable current-source clock/cursor/queue mutations with full independent variant literals; Native emit/compile/run and complete structural-value parsing. The ordinary tool resolver closure and exact configuration/environment are guarded. Checker/runtime caps remain 5 seconds; emission 30 seconds; compilation 120 seconds.

The cross-backend comparison covers eight actual registered public observations, complete component values, added/changed filters, relation operation/source/target/error/lag, ordinary event values/lag and removal entities. It explicitly excludes backend-specific physical ownership representations, schema-qualified descriptor strings and distinct clock domains; it does not normalize clocks or establish equivalence outside those named features.

Full issue acceptance additionally requires the governing confinement/negative contracts, remaining lifecycle/failure/disposal requirements, production adoption and equivalent performance qualification. No laws or proofs are introduced here.

## Observed admitted controls and Native

The exact `be7c76…` plan completed with `MIXED_DEVELOPMENT_PASS`; terminal receipt SHA256 `c0194589af5be61ea54c3d993874fcea358daadb9af7fc1f8a2c6bfc2f5a29dc`. All 14 semantic commands exited 0. Actual retained TS/Bend public comparison passed. Each of the three current-source mutants passed compilation, then failed the correct full oracle and matched its independently authored full two-schema variant. The cursor mutant incorrectly replays added/changed on the repeat read; the queue mutant executes the actual deferred command list in LIFO order; the clock mutant records an incorrect relation tick after a public component insertion. Real Native compilation and execution exited 0 and the complete structural output matched the same full literal used for JS.

The frozen plan inherited stale scope wording listing the actual TS comparator as outstanding. This report corrects that wording: the named actual public comparator was executed and passed. It does not establish equality of excluded clock domains, backend physical layouts or descriptor naming, nor complete issue #43. All frozen plan/source/receipts remain unchanged.
