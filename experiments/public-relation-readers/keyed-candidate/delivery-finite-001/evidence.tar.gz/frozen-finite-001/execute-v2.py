"""Prepare then execute the reviewed bounded #43 finite feature gate.

The original semantic freeze is immutable. This execution extension seals helper,
config/tool/asset inputs, all prospective outputs and raw labels. No full #43,
performance, trusted-raw-provider confinement or universal proof is claimed.
"""
from pathlib import Path
import argparse
import functools
import hashlib
import json
import os
import re
import runpy
import shutil
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
CANDIDATE = HERE.parent
STAGE = HERE / 'execution-v2-001'
CLANG_ROOT = Path('/tmp/bendvy-clang19-diagnostic/root')
CLANG = Path('/tmp/bendvy-clang19-diagnostic/clang19')
CAPS = {'check': 5, 'emit': 30, 'compiler': 120, 'runtime': 5}
CPU = 5
CONFIG_NAMES = ['bend.json', 'bend.config.json', 'bunfig.toml', 'package.json',
                '.clang', 'clang.cfg', 'tsconfig.json', '.node-version', 'check.json', 'bender.json']
ENV = dict(os.environ, BEND_NO_TELEMETRY='1',
           BENDVY_CLANG19_ROOT=str(CLANG_ROOT),
           LD_LIBRARY_PATH=':'.join(map(str, [CLANG_ROOT / 'usr/lib/aarch64-linux-gnu',
               CLANG_ROOT / 'usr/lib/llvm-19/lib',
               Path('/home/node/.local/opt/dnd-clang14/usr/lib/aarch64-linux-gnu')])))
SYS_TOOLS = {name: Path(shutil.which(name)).resolve(strict=True)
             for name in ('bend', 'node', 'python3', 'git', 'taskset', 'ldd', 'ld', 'sh', 'env', 'bash')}
SYS_TOOLS.update({'clang-wrapper': CLANG,
                 'clang-native': CLANG_ROOT / 'usr/lib/llvm-19/bin/clang'})


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory(path):
    path = Path(path)
    if not path.exists():
        return {'absent': True}
    if path.is_file():
        return {'sha256': sha(path), 'resolved': str(path.resolve())}
    return {str(p.relative_to(path)): {'sha256': sha(p),
             'resolved': str(p.resolve())} for p in sorted(path.rglob('*')) if p.is_file()}


def encoded(value):
    if isinstance(value, bytes):
        return {'rawHex': value.hex()}
    raise TypeError(type(value).__name__)


def decoded(value):
    if set(value) == {'rawHex'}:
        return bytes.fromhex(value['rawHex'])
    return value


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, default=encoded)
        stream.write('\n')


def config_inventory():
    roots = {ROOT, CANDIDATE, HERE, STAGE, Path.cwd(), CLANG.parent,
             CLANG_ROOT / 'usr/lib/llvm-19/bin', ROOT / '.references/bevy-ts',
             ROOT / '.references/bevy-ts/packages/core'}
    entries = [CANDIDATE / 'observe.bend', CANDIDATE / 'foreign.bend', CANDIDATE / 'consumer.mjs', CANDIDATE / 'native-consumer.mjs', CANDIDATE / 'driven-reference.mjs', HERE / 'mutant-witness.mjs', Path('/home/node/.bend/bend2/base.bend')]
    entries += list((ROOT / 'src/ecs').glob('*.bend'))
    entries += list((ROOT / '.references/bevy-ts/packages/core/src').rglob('*.ts'))
    entries += list((CANDIDATE / 'development-attempts/controls-002').rglob('*.bend'))
    for entry in entries:
        roots.update(entry.parents)
    roots.add(Path('/home/node/.bend'))
    paths = {root / name for root in roots for name in CONFIG_NAMES}
    paths.update(Path(folder) / 'env' for folder in ENV.get('PATH','').split(':') if folder)
    paths.update([Path('/bin/sh'), Path('/bin/bash'), Path('/home/node/.bend/check.json'), Path('/home/node/.bend/bend.json'), Path('/etc/ld.so.cache'),
                  Path('/etc/ld.so.preload'), Path('/etc/ld.so.conf'),
                  Path('/etc/ld.so.conf.d'), Path('/home/node/.config/bend'),
                  ROOT / 'node_modules', CANDIDATE / 'node_modules',
                  ROOT / '.references/bevy-ts/node_modules'])
    return {str(path): inventory(path) for path in sorted(paths)}


def source_inventory():
    frozen = json.loads((HERE / 'manifest.json').read_text())
    pins = {str(ROOT / name): digest for name, digest in frozen['sources'].items()}
    pins.update({str(ROOT / name): digest for name, digest in frozen['references'].items()})
    pins[frozen['installedBase']['path']] = frozen['installedBase']['sha256']
    for name in ('manifest.json', 'input.json', 'execute.py', 'execute-v2.py', 'mutant-witness.mjs'):
        pins[str(HERE / name)] = sha(HERE / name)
    for name in ('scripts/owned-tool-pins.py', 'scripts/receipt-logs.py',
                 'src/ecs/world-namespace.c', 'src/ecs/world-namespace.js'):
        pins[str(ROOT / name)] = sha(ROOT / name)
    for path in (HERE / 'preflight').glob('negative-*-current.*'):
        pins[str(path)] = sha(path)
    for path in (HERE / 'preflight/controls-002').rglob('*.bend'):
        original = CANDIDATE / 'development-attempts/controls-002' / path.relative_to(HERE / 'preflight/controls-002')
        assert sha(path) == sha(original), 'exact frozen mutation source drift'
        pins[str(path)] = sha(path)
        pins[str(original)] = sha(original)
    for folder in ('source', 'reference', 'authority'):
        for path in (HERE / folder).rglob('*'):
            if path.is_file():
                pins[str(path)] = sha(path)
    assert all(sha(path) == digest for path, digest in pins.items()), 'freeze/live drift'
    return pins


def namespaces():
    return {'core': inventory(ROOT / 'src/ecs'),
            'candidateFiles': {p.name: sha(p) for p in sorted(CANDIDATE.iterdir())
                if p.is_file() and p.suffix in ('.bend', '.mjs', '.py', '.md')},
            'TS': inventory(ROOT / '.references/bevy-ts/packages/core/src'),
            'Base/compiler': inventory('/home/node/.bend/bend2'),
            'controls': inventory(HERE / 'preflight/controls-002'),
            'originalControls': inventory(CANDIDATE / 'development-attempts/controls-002'),
            'referenceGitPointers': {str(ROOT / '.references' / name / '.git' / pointer): inventory(ROOT / '.references' / name / '.git' / pointer) for name in ('bevy-ts','bevy','bend2') for pointer in ('HEAD','packed-refs','refs/heads/main')},
            'frozenSource': inventory(HERE / 'source'),
            'frozenReference': inventory(HERE / 'reference'),
            'frozenAuthority': inventory(HERE / 'authority')}


def plan():
    rows = []
    def add(label, argv, cap, emits=None, exit=0, diagnostic=None):
        rows.append(dict(label=label, argv=list(map(str, argv)), cap=cap,
                         emits=emits, exit=exit, diagnostic=diagnostic))
    for fixture in ('observe', 'foreign'):
        add(f'{fixture}-check', [SYS_TOOLS['bend'], CANDIDATE / f'{fixture}.bend', '--check-only'], 5)
        add(f'{fixture}-emit-js', [SYS_TOOLS['bend'], CANDIDATE / f'{fixture}.bend', '-o', STAGE / f'{fixture}.mjs'], 30, f'{fixture}.mjs')
        add(f'{fixture}-consume-js', [SYS_TOOLS['node'], CANDIDATE / 'consumer.mjs', STAGE / f'{fixture}.mjs'] + (['--foreign'] if fixture == 'foreign' else []), 5)
    add('TS-reference', [SYS_TOOLS['node'], CANDIDATE / 'driven-reference.mjs'], 5)
    add('shared-oracle', [SYS_TOOLS['node'], CANDIDATE / 'compare-shared.mjs', STAGE / 'observe-consume-js.stdout', STAGE / 'TS-reference.stdout'], 5)
    for fixture in ('observe', 'foreign'):
        add(f'{fixture}-emit-c', [SYS_TOOLS['bend'], CANDIDATE / f'{fixture}.bend', '-o', STAGE / f'{fixture}.c'], 30, f'{fixture}.c')
        add(f'{fixture}-headers', [CLANG, '-M', '-MF', STAGE / f'{fixture}.d', STAGE / f'{fixture}.c', '-pthread'], 5, f'{fixture}.d')
    for fixture in ('observe', 'foreign'):
        add(f'{fixture}-compile', [CLANG, '-O3', STAGE / f'{fixture}.c', '-pthread', '-lm', '-o', STAGE / f'{fixture}-native'], 120, f'{fixture}-native')
        add(f'{fixture}-native', [STAGE / f'{fixture}-native', '--threads', '1', '--gpu', 'off'], 5)
        add(f'{fixture}-consume-native', [SYS_TOOLS['node'], CANDIDATE / 'native-consumer.mjs', STAGE / f'{fixture}-native.stdout'] + (['--foreign'] if fixture == 'foreign' else []), 5)
    negatives = {'negative-closed-undeclared': 'Access.OtherParent',
                 'negative-closed-schema': 'A.ReadersBeta',
                 'negative-closed-write-read': 'Access.WriteGrant',
                 'negative-owner-duplicate': 'consumed more than once',
                 'negative-owner-specialize': 'K.Input'}
    for fixture, needle in negatives.items():
        add(fixture, [SYS_TOOLS['bend'], CANDIDATE / f'{fixture}.bend', '--check-only'], 5, exit=1, diagnostic={'exactFrozenPrefix': str(HERE / 'preflight' / (fixture + '-current'))})
    for name in ('advance-on-failure', 'advance-wrong-reader', 'publish-before-barrier'):
        source = CANDIDATE / 'development-attempts/controls-002' / name / 'observe.bend'
        # Canonical controls retain their actual relative import resolution. Their
        # bytes are compared with the frozen copy before every operation.
        add(name + '-check', [SYS_TOOLS['bend'], source, '--check-only'], 5)
        add(name + '-emit-js', [SYS_TOOLS['bend'], source, '-o', STAGE / (name + '.mjs')], 30, name + '.mjs')
        add(name + '-consume-js', [SYS_TOOLS['node'], CANDIDATE / 'consumer.mjs', STAGE / (name + '.mjs')], 5, exit=1, diagnostic={'fullOracleRejection': 'AssertionError [ERR_ASSERTION]: Expected values to be strictly deep-equal:'})
        add(name + '-witness', [SYS_TOOLS['node'], HERE / 'mutant-witness.mjs', name, STAGE / (name + '.mjs')], 5)
    return rows


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    assert args.prepare_only != args.execute
    assert CPU in os.sched_getaffinity(0)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT / 'scripts'))
    import task_runner
    helper = runpy.run_path(str(ROOT / 'scripts/owned-tool-pins.py'))
    LogClass = runpy.run_path(str(ROOT / 'scripts/receipt-logs.py'))['CommandLogs']
    rows = plan()
    if args.prepare_only:
        STAGE.mkdir()
        sealed = dict(scope='bounded finite #43 feature only; all wider gates pending',
            sourcePins=source_inventory(), namespaces=namespaces(), configs=config_inventory(),
            tools={name: {'path': str(path), 'sha256': sha(path)} for name, path in SYS_TOOLS.items()},
            environmentSHA256=hashlib.sha256(json.dumps(ENV, sort_keys=True).encode()).hexdigest(),
            environmentKeys=sorted(ENV), cpu=CPU, limits=CAPS, commands=rows,
            prospectiveGenerated=[row['emits'] for row in rows if row['emits']],
            prospectiveRaw=[row['label'] + ext for row in rows for ext in ('.stdout', '.stderr')],
            inputSHA256=sha(HERE / 'input.json'), runnerSHA256=task_runner.IMPLEMENTATION_SHA256,
            generated={}, raw={}, commandReceipts=[], assets={})
        write(STAGE / 'plan.json', sealed)
        sealed['metadataPins'] = {'plan.json': sha(STAGE / 'plan.json')}
    else:
        sealed = json.loads((STAGE / 'prepared.json').read_text(), object_hook=decoded)
        assert sealed['commands'] == rows, 'prospective command plan drift'
        sealed['metadataPins']['prepared.json'] = sha(STAGE / 'prepared.json')
    logs = LogClass(STAGE, [row['label'] for row in rows]) if args.prepare_only else LogClass.__new__(LogClass)
    if args.execute:
        logs.directory, logs.labels, logs.hashes = STAGE, frozenset(row['label'] for row in rows), dict(sealed['raw'])
    executor = functools.partial(task_runner.execute_result, capture='split')
    tool_config = dict(execute=executor, tools=SYS_TOOLS,
        resource_roots=[Path('/home/node/.bend/bend2'), CLANG_ROOT / 'usr/lib/llvm-19/lib/clang/19'],
        ldd=SYS_TOOLS['ldd'], taskset=SYS_TOOLS['taskset'], cpu=CPU, env=ENV,
        skip_ldd=('clang-wrapper', 'ldd'), capture_mode='split')
    def guard():
        assert source_inventory() == sealed['sourcePins'], 'source closure drift'
        assert namespaces() == sealed['namespaces'], 'source/asset membership drift'
        assert config_inventory() == sealed['configs'], 'configuration/absence drift'
        assert hashlib.sha256(json.dumps(ENV, sort_keys=True).encode()).hexdigest() == sealed['environmentSHA256'], 'environment drift'
        assert all(sha(info['path']) == info['sha256'] for info in sealed['tools'].values()), 'tool bytes drift'
        assert all(sha(path) == digest for path, digest in sealed['assets'].items()), 'header/linker asset drift'
        assert all(sha(STAGE / name) == digest for name, digest in sealed['generated'].items()), 'generated bytes drift'
        assert all(sha(STAGE / name) == digest for name, digest in sealed['metadataPins'].items()), 'metadata drift'
        expected = set(sealed['generated']) | set(sealed['raw']) | set(sealed['metadataPins'])
        assert {p.name for p in STAGE.iterdir()} == expected, 'prospective output membership drift'
        logs.guard()
        if 'toolSnapshot' in sealed:
            helper['verify'](sealed['toolSnapshot'], **tool_config)
    def command(row):
        guard()
        label, emitted = row['label'], row['emits']
        if emitted:
            assert not (STAGE / emitted).exists(), 'prospective generated output already exists'
        argv = [str(SYS_TOOLS['taskset']), '-c', str(CPU)] + row['argv']
        result = executor(argv, row['cap'], env=ENV, cwd=ROOT)
        sealed['raw'] = logs.record(label, result['stdout'], result['stderr'])
        sealed['commandReceipts'].append(dict(label=label, argv=argv, cap=row['cap'],
            exit=result['exit'], failure=result['failure'], runnerSHA256=result['runnerSHA256'],
            stdoutSHA256=sha(STAGE / (label + '.stdout')), stderrSHA256=sha(STAGE / (label + '.stderr'))))
        if emitted and (STAGE / emitted).is_file():
            sealed['generated'][emitted] = sha(STAGE / emitted)
        assert result['failure'] is None and result['exit'] == row['exit'], (label, result['exit'], result['failure'])
        if row['diagnostic']:
            diagnostic = row['diagnostic']
            if 'exactFrozenPrefix' in diagnostic:
                prefix = diagnostic['exactFrozenPrefix']
                # Only the terminal update advisory is excluded; the complete
                # intended type binding, definition, source line/span and verdict
                # bytes remain exact. No arbitrary substring grants a pass.
                clean = lambda raw: re.sub(rb'\nbend [^\n]+ is available: run bend update\n?$', b'\n', raw)
                assert clean(result['stdout']) == clean(Path(prefix + '.stdout').read_bytes()), 'negative stdout drift'
                assert clean(result['stderr']) == clean(Path(prefix + '.stderr').read_bytes()), 'negative diagnostic/span drift'
            else:
                assert diagnostic['fullOracleRejection'].encode() in result['stderr'], 'not complete-oracle rejection'
        guard()
    try:
        if args.prepare_only:
            # Complete actual Node/Bend/reference consumer checks precede ELF discovery.
            for row in rows[:12]:
                command(row)
            for filename in ('observe.d', 'foreign.d'):
                tokens = (STAGE / filename).read_text().replace('\\\n', '').split(':', 1)[1].split()
                for token in tokens:
                    path = Path(token).resolve()
                    if path.suffix != '.c':
                        sealed['assets'][str(path)] = sha(path)
            # Pin exact native linker/startup assets; no root-wide library copy.
            for folder in ('/usr/lib/gcc/aarch64-linux-gnu/12', '/usr/lib/aarch64-linux-gnu'):
                for pattern in ('crt*.o', 'libgcc*.a', 'libc.so', 'libm.so'):
                    for path in Path(folder).glob(pattern):
                        sealed['assets'][str(path.resolve())] = sha(path)
            sealed['toolSnapshot'] = helper['snapshot'](**tool_config)
            guard()
            sealed['status'] = 'PREPARED_NOT_EXECUTED'
            write(STAGE / 'prepared.json', sealed)
            print(STAGE / 'prepared.json')
        else:
            guard()
            for row in rows[12:]:
                command(row)
            guard()
            sealed['status'] = 'FINITE_FEATURE_PASS'
            sealed['completeIssue43'] = False
            write(STAGE / 'receipt.json', sealed)
            print(STAGE / 'receipt.json')
    except BaseException as error:
        sealed['status'] = 'INCOMPLETE'
        sealed['failureType'] = type(error).__name__
        write(STAGE / 'incomplete.json', sealed)
        raise

if __name__ == '__main__':
    run()
