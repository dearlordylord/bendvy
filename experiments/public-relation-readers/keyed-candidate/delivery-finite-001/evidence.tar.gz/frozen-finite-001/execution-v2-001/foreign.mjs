function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058registration_equal$(_id_0, _name_0, _access_0, _otherId_0, _otherName_0, _otherAccess_0) {
  return $Bool$and$((_id_0 === _otherId_0), ($Bool$and$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_name_0, _otherName_0)), ($$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$(_access_0, _otherAccess_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $$$$047$$$047$$$047src$047ecs$047world$058grow_live$($0, $1, $2, $3) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _capacity_0 = $1;
      const _depth_0 = $2;
      const _live_0 = $3;
      if (_remaining_0 === 0) {
        return {$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0};
      } else {
        const _rest_0 = (_remaining_0 - 1);
        $0 = _rest_0;
        $1 = (Math.imul(_capacity_0, 2) >>> 0);
        $2 = nat_chk(_depth_0 + 1);
        $3 = array_node(_live_0, array_new(_depth_0, false));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047registration$058retained$(_keep_0, _meta_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _meta_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047registration$058retained$(($Bool$not$(($$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0)))), _meta_0, ($$$$047$$$047$$$047src$047ecs$047registration$058without$(_rest_0, _id_0, _name_0, _access_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0, $1) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _boundary_0 = $1;
      if (_positions_0.$ === "Nil") {
        return _boundary_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = (_boundary_0 < _cursor_0 ? _boundary_0 : _cursor_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $domains$058member$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_id_0 === _wanted_0);
    const _x_1 = ($domains$058member$(_rest_0, _wanted_0));
    return (_x_0 || _x_1);
  }
}

function $domains$058add_checked$(_found_0, _ids_0, _id_0) {
  if (_found_0) {
    return _ids_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _ids_0};
  }
}

function $domains$058add$(_ids_0, _id_0) {
  return $domains$058add_checked$(($domains$058member$(_ids_0, _id_0)), _ids_0, _id_0);
}

function $domains$058select_boundary$(_registered_0, _cursor_0, _boundary_0) {
  if (!_registered_0) {
    return _boundary_0;
  } else {
    return (_cursor_0 < _boundary_0 ? _cursor_0 : _boundary_0);
  }
}

function $domains$058boundary$($0, $1, $2) {
  for (;;) {
    {
      const _positions_0 = $0;
      const _ids_0 = $1;
      const _acc_0 = $2;
      if (_positions_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _positions_0["head"];
        const _id_0 = _t_0["id"];
        const _cursor_0 = _t_0["cursor"];
        const _rest_0 = _positions_0["tail"];
        $0 = _rest_0;
        $1 = _ids_0;
        $2 = ($domains$058select_boundary$(($domains$058member$(_ids_0, _id_0)), _cursor_0, _acc_0));
        continue;
      }
    }
  }
}

function $runtime$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    const _x_1 = (_x_0 === _id_0);
    const _x_2 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_rest_0, _id_0));
    return (_x_1 || _x_2);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$(_remove_0, _id_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_xs_0, _id_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _x_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((_x_0 === _id_0), _x_0, ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(_found_0, _target_0, _next_0) {
  if (_found_0) {
    return {$: "Some", "value": _target_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$(_found_0, _sources_0, _next_0) {
  if (_found_0) {
    return _sources_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(_present_0, _sources_0, _source_0) {
  if (_present_0) {
    return _sources_0;
  } else {
    return $List$append$(_sources_0, {$: "Con", "head": _source_0, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, _self_0, _cyclic_0, _source_0, _target_0, _name_0) {
  if (!_sourceLive_0) {
    return {$: "Some", "value": {$: "../../../src/ecs/relation-types.MissingEntity", "source": _source_0}};
  } else {
    if (!_targetLive_0) {
      return {$: "Some", "value": {$: "../../../src/ecs/relation-types.MissingTargetEntity", "source": _source_0, "target": _target_0, "relation": _name_0}};
    } else {
      if (_self_0) {
        return {$: "Some", "value": {$: "../../../src/ecs/relation-types.SelfRelationNotAllowed", "source": _source_0, "relation": _name_0}};
      } else {
        if (_cyclic_0) {
          return {$: "Some", "value": {$: "../../../src/ecs/relation-types.HierarchyCycle", "source": _source_0, "target": _target_0, "relation": _name_0}};
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(_previous_0, _target_0) {
  if (_previous_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _previous_0["value"];
    return (_id_0 === _target_0);
  }
}

function $driven$058cells$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $List$append$(($driven$058cells$(_left_0)), ($driven$058cells$(_right_0)));
  }
}

function $driven$058private_observed$(_cloned_0) {
  const _owner_0 = _cloned_0["fst"];
  const _copy_0 = _cloned_0["snd"];
  return {$: "Tuple", "fst": _owner_0, "snd": ($driven$058cells$(_copy_0))};
}

function $observe$058bool_cells$(_array_0) {
  if (_array_0.length === 1) {
    const _value_0 = _array_0[0];
    return {$: "Con", "head": _value_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _array_0.slice(0, _array_0.length >> 1);
    const _right_0 = _array_0.slice(_array_0.length >> 1);
    return $List$append$(($observe$058bool_cells$(_left_0)), ($observe$058bool_cells$(_right_0)));
  }
}

function $observe$058main$() {
  return {$: "Tuple", "fst": ($observe$058observed$1260$(($driven$058application$1260$()))), "snd": ($observe$058observed$1261$(($driven$058application$1261$())))};
}

function $main$() {
  return {$: "Tuple", "fst": ($application$1260$()), "snd": ($application$1261$())};
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $observe$058observed$1260$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _t_1 = _t_0["pair"];
    const _t_2 = _t_1["runtime"];
    const _t_3 = _t_2["world"];
    const _namespace_0 = _t_3["namespace"];
    const _nextId_0 = _t_3["nextId"];
    const _highWater_0 = _t_3["highWater"];
    const _live_0 = _t_3["live"];
    const _capacity_0 = _t_3["capacity"];
    const _depth_0 = _t_3["depth"];
    const _t_4 = _t_3["store"];
    const _t_5 = _t_4["components"];
    const _left_0 = _t_5["left"];
    const _right_0 = _t_5["right"];
    const _graph_0 = _t_4["graph"];
    const _t_6 = _t_3["resource"];
    const _baseline_0 = _t_6["baseline"];
    const _returned_0 = _t_6["returned"];
    const _events_0 = _t_3["events"];
    const _pending_0 = _t_3["pending"];
    const _registrations_0 = _t_3["registrations"];
    const _nextSystemId_0 = _t_3["nextSystemId"];
    const _clock_0 = _t_3["clock"];
    const _domains_0 = _t_2["domains"];
    const _positions_0 = _t_2["positions"];
    const _tick_0 = _t_2["tick"];
    const _frameStart_0 = _t_2["frameStart"];
    const _boundary_0 = _t_2["boundary"];
    const _retentionCapacity_0 = _t_2["capacity"];
    const _fastPrivate_0 = _t_1["fastPrivate"];
    const _slowPrivate_0 = _t_1["slowPrivate"];
    const _deliveries_0 = _t_0["deliveries"];
    return {$: "Some", "value": {$: "observe.Final", "deliveries": ($List$reverse$(_deliveries_0)), "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "retentionCapacity": _retentionCapacity_0, "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": ($observe$058bool_cells$(_live_0)), "capacity": _capacity_0, "depth": _depth_0, "left": ($driven$058cells$(_left_0)), "right": ($driven$058cells$(_right_0)), "graph": _graph_0, "baseline": ($driven$058cells$(_baseline_0)), "returned": ($observe$058mailbox$1260$(_returned_0)), "events": _events_0, "pendingCount": ($observe$058pending_count$1260$(_pending_0, 0)), "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0, "fastPrivate": ($driven$058cells$(_fastPrivate_0)), "slowPrivate": ($driven$058cells$(_slowPrivate_0))}};
  }
}

function $driven$058application$1260$() {
  return $driven$058started$1260$(($application$058seeded$1260$(($$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})))));
}

function $observe$058observed$1261$(_state_0) {
  if (_state_0.$ === "None") {
    return {$: "None"};
  } else {
    const _t_0 = _state_0["value"];
    const _t_1 = _t_0["pair"];
    const _t_2 = _t_1["runtime"];
    const _t_3 = _t_2["world"];
    const _namespace_0 = _t_3["namespace"];
    const _nextId_0 = _t_3["nextId"];
    const _highWater_0 = _t_3["highWater"];
    const _live_0 = _t_3["live"];
    const _capacity_0 = _t_3["capacity"];
    const _depth_0 = _t_3["depth"];
    const _t_4 = _t_3["store"];
    const _t_5 = _t_4["components"];
    const _left_0 = _t_5["left"];
    const _right_0 = _t_5["right"];
    const _graph_0 = _t_4["graph"];
    const _t_6 = _t_3["resource"];
    const _baseline_0 = _t_6["baseline"];
    const _returned_0 = _t_6["returned"];
    const _events_0 = _t_3["events"];
    const _pending_0 = _t_3["pending"];
    const _registrations_0 = _t_3["registrations"];
    const _nextSystemId_0 = _t_3["nextSystemId"];
    const _clock_0 = _t_3["clock"];
    const _domains_0 = _t_2["domains"];
    const _positions_0 = _t_2["positions"];
    const _tick_0 = _t_2["tick"];
    const _frameStart_0 = _t_2["frameStart"];
    const _boundary_0 = _t_2["boundary"];
    const _retentionCapacity_0 = _t_2["capacity"];
    const _fastPrivate_0 = _t_1["fastPrivate"];
    const _slowPrivate_0 = _t_1["slowPrivate"];
    const _deliveries_0 = _t_0["deliveries"];
    return {$: "Some", "value": {$: "observe.Final", "deliveries": ($List$reverse$(_deliveries_0)), "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "retentionCapacity": _retentionCapacity_0, "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": ($observe$058bool_cells$(_live_0)), "capacity": _capacity_0, "depth": _depth_0, "left": ($driven$058cells$(_left_0)), "right": ($driven$058cells$(_right_0)), "graph": _graph_0, "baseline": ($driven$058cells$(_baseline_0)), "returned": ($observe$058mailbox$1261$(_returned_0)), "events": _events_0, "pendingCount": ($observe$058pending_count$1261$(_pending_0, 0)), "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0, "fastPrivate": ($driven$058cells$(_fastPrivate_0)), "slowPrivate": ($driven$058cells$(_slowPrivate_0))}};
  }
}

function $driven$058application$1261$() {
  return $driven$058started$1261$(($application$058seeded$1261$(($$$$047$$$047$$$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})))));
}

function $application$1260$() {
  return $first$1260$(($$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})));
}

function $application$1261$() {
  return $first$1261$(($$$$047$$$047$$$047src$047ecs$047world$058create$1261$(($$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})));
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $observe$058mailbox$1260$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["private"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": ($driven$058cells$(_owner_0)), "tail": ($observe$058mailbox$1260$(_rest_0))};
  }
}

function $observe$058pending_count$1260$($0, $1) {
  for (;;) {
    {
      const _pending_0 = $0;
      const _acc_0 = $1;
      if (_pending_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _pending_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $driven$058started$1260$(_result_0) {
  if (_result_0.$ === "application.Started") {
    const _runtime_0 = _result_0["runtime"];
    return $driven$058registered$1260$(($pair$058register$1260$(_runtime_0)));
  } else {
    return {$: "None"};
  }
}

function $application$058seeded$1260$(_created_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "application.Started", "runtime": ($runtime$058start$1260$(($application$058reserved$1260$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0))))))};
  } else {
    const _factory_0 = _created_0["factory"];
    const _resource_0 = _created_0["resource"];
    return {$: "application.StartRejected", "factory": _factory_0, "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $observe$058mailbox$1261$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _owner_0 = _t_0["private"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": ($driven$058cells$(_owner_0)), "tail": ($observe$058mailbox$1261$(_rest_0))};
  }
}

function $observe$058pending_count$1261$($0, $1) {
  for (;;) {
    {
      const _pending_0 = $0;
      const _acc_0 = $1;
      if (_pending_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _pending_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(_acc_0 + 1);
        continue;
      }
    }
  }
}

function $driven$058started$1261$(_result_0) {
  if (_result_0.$ === "application.Started") {
    const _runtime_0 = _result_0["runtime"];
    return $driven$058registered$1261$(($pair$058register$1261$(_runtime_0)));
  } else {
    return {$: "None"};
  }
}

function $application$058seeded$1261$(_created_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "application.Started", "runtime": ($runtime$058start$1261$(($application$058reserved$1261$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0))))))};
  } else {
    const _factory_0 = _created_0["factory"];
    const _resource_0 = _created_0["resource"];
    return {$: "application.StartRejected", "factory": _factory_0, "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $first$1260$(_created_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _factory_0 = _created_0["factory"];
    const _source_0 = _created_0["world"];
    return $second$1260$(($$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, {$: "application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})), _source_0);
  } else {
    return {$: "None"};
  }
}

function $first$1261$(_created_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _factory_0 = _created_0["factory"];
    const _source_0 = _created_0["world"];
    return $second$1261$(($$$$047$$$047$$$047src$047ecs$047world$058create$1261$(_factory_0, {$: "application.Resources", "baseline": array_node([301], [302]), "returned": {$: "Nil"}})), _source_0);
  } else {
    return {$: "None"};
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $driven$058registered$1260$(_result_0) {
  if (_result_0.$ === "pair.PairReady") {
    const _pair_0 = _result_0["pair"];
    return $driven$058steps$1260$({$: "Con", "head": 0, "tail": {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Con", "head": 4, "tail": {$: "Con", "head": 5, "tail": {$: "Con", "head": 6, "tail": {$: "Con", "head": 7, "tail": {$: "Con", "head": 8, "tail": {$: "Con", "head": 9, "tail": {$: "Con", "head": 10, "tail": {$: "Con", "head": 11, "tail": {$: "Con", "head": 12, "tail": {$: "Con", "head": 12, "tail": {$: "Nil"}}}}}}}}}}}}}}}, {$: "Some", "value": {$: "driven.Driven", "pair": _pair_0, "deliveries": {$: "Nil"}}});
  } else {
    return {$: "None"};
  }
}

function $pair$058register$1260$(_runtime_0) {
  return $pair$058fast_registered$1260$(($runtime$058register$1260$(_runtime_0, {$: "Con", "head": {$: "domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "fast", {$: "Con", "head": "Parent:read", "tail": {$: "Nil"}})));
}

function $runtime$058start$1260$(_world_0) {
  return {$: "runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $application$058reserved$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $application$058activated$1260$(($$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0)));
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/world.CreateRejected", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../src/ecs/world.Created", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($application$058empty$1260$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $driven$058registered$1261$(_result_0) {
  if (_result_0.$ === "pair.PairReady") {
    const _pair_0 = _result_0["pair"];
    return $driven$058steps$1261$({$: "Con", "head": 0, "tail": {$: "Con", "head": 1, "tail": {$: "Con", "head": 2, "tail": {$: "Con", "head": 3, "tail": {$: "Con", "head": 4, "tail": {$: "Con", "head": 5, "tail": {$: "Con", "head": 6, "tail": {$: "Con", "head": 7, "tail": {$: "Con", "head": 8, "tail": {$: "Con", "head": 9, "tail": {$: "Con", "head": 10, "tail": {$: "Con", "head": 11, "tail": {$: "Con", "head": 12, "tail": {$: "Con", "head": 12, "tail": {$: "Nil"}}}}}}}}}}}}}}}, {$: "Some", "value": {$: "driven.Driven", "pair": _pair_0, "deliveries": {$: "Nil"}}});
  } else {
    return {$: "None"};
  }
}

function $pair$058register$1261$(_runtime_0) {
  return $pair$058fast_registered$1261$(($runtime$058register$1261$(_runtime_0, {$: "Con", "head": {$: "domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "fast", {$: "Con", "head": "Parent:read", "tail": {$: "Nil"}})));
}

function $runtime$058start$1261$(_world_0) {
  return {$: "runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": 0, "frameStart": 0, "boundary": 0, "capacity": 65536};
}

function $application$058reserved$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Reserved") {
    const _handle_0 = _t_0["handle"];
    return $application$058activated$1261$(($$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0)));
  } else {
    return _world_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$((_nextId_0 < 131073), ($Bool$not$((_nextId_0 < _capacity_0))), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0});
}

function $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1261$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/world.CreateRejected", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../src/ecs/world.Created", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($application$058empty$1261$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $second$1260$(_created_0, _source_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _receiver_0 = _created_0["world"];
    return $pairs$1260$(($pair$058register$1260$(($runtime$058start$1260$(($application$058reserved$1260$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_source_0)))))))), ($pair$058register$1260$(($runtime$058start$1260$(($application$058reserved$1260$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1260$(_receiver_0)))))))));
  } else {
    return {$: "None"};
  }
}

function $second$1261$(_created_0, _source_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _receiver_0 = _created_0["world"];
    return $pairs$1261$(($pair$058register$1261$(($runtime$058start$1261$(($application$058reserved$1261$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_source_0)))))))), ($pair$058register$1261$(($runtime$058start$1261$(($application$058reserved$1261$(($$$$047$$$047$$$047src$047ecs$047world$058reserve_id$1261$(_receiver_0)))))))));
  } else {
    return {$: "None"};
  }
}

function $driven$058steps$1260$($0, $1) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _state_0 = $1;
      if (_remaining_0.$ === "Nil") {
        if (_state_0.$ === "None") {
          return {$: "None"};
        } else {
          return _state_0;
        }
      } else {
        const _step_0 = _remaining_0["head"];
        const _rest_0 = _remaining_0["tail"];
        if (_state_0.$ === "Some") {
          const _state_1 = _state_0["value"];
          $0 = _rest_0;
          $1 = ($driven$058execute_step$1260$(_step_0, _state_1));
          continue;
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $pair$058fast_registered$1260$(_result_0) {
  if (_result_0.$ === "runtime.RegistrationFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "pair.PairRejected", "runtime": _runtime_0};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _fast_0 = _result_0["reader"];
    return $pair$058slow_registered$1260$(($runtime$058register$1260$(_runtime_1, {$: "Con", "head": {$: "domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "slow", {$: "Con", "head": "Parent:read", "tail": {$: "Nil"}})), _fast_0);
  }
}

function $runtime$058register$1260$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$058registered_result$1260$(($$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $application$058activated$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047world$058activate$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(true, _handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1260$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": {$: "../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$({$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(($$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $application$058empty$1260$(__0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1260$({$: "application.CellOwners", "left": array_node([11], [12]), "right": array_node([21], [22])});
}

function $driven$058steps$1261$($0, $1) {
  for (;;) {
    {
      const _remaining_0 = $0;
      const _state_0 = $1;
      if (_remaining_0.$ === "Nil") {
        if (_state_0.$ === "None") {
          return {$: "None"};
        } else {
          return _state_0;
        }
      } else {
        const _step_0 = _remaining_0["head"];
        const _rest_0 = _remaining_0["tail"];
        if (_state_0.$ === "Some") {
          const _state_1 = _state_0["value"];
          $0 = _rest_0;
          $1 = ($driven$058execute_step$1261$(_step_0, _state_1));
          continue;
        } else {
          return {$: "None"};
        }
      }
    }
  }
}

function $pair$058fast_registered$1261$(_result_0) {
  if (_result_0.$ === "runtime.RegistrationFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "pair.PairRejected", "runtime": _runtime_0};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _fast_0 = _result_0["reader"];
    return $pair$058slow_registered$1261$(($runtime$058register$1261$(_runtime_1, {$: "Con", "head": {$: "domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "slow", {$: "Con", "head": "Parent:read", "tail": {$: "Nil"}})), _fast_0);
  }
}

function $runtime$058register$1261$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$058registered_result$1261$(($$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $application$058activated$1261$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047world$058activate$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(true, _handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_available$1261$(_available_0, _grow_0, _world_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.ReservationRejected", "error": {$: "../../../src/ecs/world.CapacityExceeded"}}};
  } else {
    if (!_grow_0) {
      const _namespace_0 = _world_0["namespace"];
      const _nextId_0 = _world_0["nextId"];
      const _highWater_0 = _world_0["highWater"];
      const _live_0 = _world_0["live"];
      const _capacity_0 = _world_0["capacity"];
      const _depth_0 = _world_0["depth"];
      const _store_0 = _world_0["store"];
      const _resource_0 = _world_0["resource"];
      const _events_0 = _world_0["events"];
      const _pending_0 = _world_0["pending"];
      const _registrations_0 = _world_0["registrations"];
      const _nextSystemId_0 = _world_0["nextSystemId"];
      const _clock_0 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$({$: "../../../src/ecs/world.Growth", "live": _live_0, "capacity": _capacity_0, "depth": _depth_0}, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
    } else {
      const _namespace_1 = _world_0["namespace"];
      const _nextId_1 = _world_0["nextId"];
      const _highWater_1 = _world_0["highWater"];
      const _live_1 = _world_0["live"];
      const _capacity_1 = _world_0["capacity"];
      const _depth_1 = _world_0["depth"];
      const _store_1 = _world_0["store"];
      const _resource_1 = _world_0["resource"];
      const _events_1 = _world_0["events"];
      const _pending_1 = _world_0["pending"];
      const _registrations_1 = _world_0["registrations"];
      const _nextSystemId_1 = _world_0["nextSystemId"];
      const _clock_1 = _world_0["clock"];
      return $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(($$$$047$$$047$$$047src$047ecs$047world$058grow_live$(1, _capacity_1, _depth_1, _live_1)), _namespace_1, _nextId_1, _highWater_1, _store_1, _resource_1, _events_1, _pending_1, _registrations_1, _nextSystemId_1, _clock_1);
    }
  }
}

function $application$058empty$1261$(__0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1261$({$: "application.CellOwners", "left": array_node([11], [12]), "right": array_node([21], [22])});
}

function $pairs$1260$(_source_0, _receiver_0) {
  if (_source_0.$ === "pair.PairReady") {
    const _t_0 = _source_0["pair"];
    const _t_1 = _t_0["runtime"];
    const _t_2 = _t_1["world"];
    const _namespace_0 = _t_2["namespace"];
    const _nextId_0 = _t_2["nextId"];
    const _highWater_0 = _t_2["highWater"];
    const _live_0 = _t_2["live"];
    const _capacity_0 = _t_2["capacity"];
    const _depth_0 = _t_2["depth"];
    const _store_0 = _t_2["store"];
    const _resources_0 = _t_2["resource"];
    const _events_0 = _t_2["events"];
    const _pending_0 = _t_2["pending"];
    const _registrations_0 = _t_2["registrations"];
    const _nextSystemId_0 = _t_2["nextSystemId"];
    const _clock_0 = _t_2["clock"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _frameStart_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _retentionCapacity_0 = _t_1["capacity"];
    const _fast_0 = _t_0["fast"];
    const _slow_0 = _t_0["slow"];
    const _fp_0 = _t_0["fastPrivate"];
    const _sp_0 = _t_0["slowPrivate"];
    if (_receiver_0.$ === "pair.PairReady") {
      const _receiver_1 = _receiver_0["pair"];
      return $foreign$1260$({$: "pair.OwnedReaders", "runtime": {$: "runtime.Runtime", "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _retentionCapacity_0}, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fp_0, "slowPrivate": _sp_0}, ($driven$058queue$1260$({$: "driven.Driven", "pair": _receiver_1, "deliveries": {$: "Nil"}}, 1, 1)), {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
    } else {
      return {$: "None"};
    }
  } else {
    return {$: "None"};
  }
}

function $pairs$1261$(_source_0, _receiver_0) {
  if (_source_0.$ === "pair.PairReady") {
    const _t_0 = _source_0["pair"];
    const _t_1 = _t_0["runtime"];
    const _t_2 = _t_1["world"];
    const _namespace_0 = _t_2["namespace"];
    const _nextId_0 = _t_2["nextId"];
    const _highWater_0 = _t_2["highWater"];
    const _live_0 = _t_2["live"];
    const _capacity_0 = _t_2["capacity"];
    const _depth_0 = _t_2["depth"];
    const _store_0 = _t_2["store"];
    const _resources_0 = _t_2["resource"];
    const _events_0 = _t_2["events"];
    const _pending_0 = _t_2["pending"];
    const _registrations_0 = _t_2["registrations"];
    const _nextSystemId_0 = _t_2["nextSystemId"];
    const _clock_0 = _t_2["clock"];
    const _domains_0 = _t_1["domains"];
    const _positions_0 = _t_1["positions"];
    const _tick_0 = _t_1["tick"];
    const _frameStart_0 = _t_1["frameStart"];
    const _boundary_0 = _t_1["boundary"];
    const _retentionCapacity_0 = _t_1["capacity"];
    const _fast_0 = _t_0["fast"];
    const _slow_0 = _t_0["slow"];
    const _fp_0 = _t_0["fastPrivate"];
    const _sp_0 = _t_0["slowPrivate"];
    if (_receiver_0.$ === "pair.PairReady") {
      const _receiver_1 = _receiver_0["pair"];
      return $foreign$1261$({$: "pair.OwnedReaders", "runtime": {$: "runtime.Runtime", "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resources_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _retentionCapacity_0}, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fp_0, "slowPrivate": _sp_0}, ($driven$058queue$1261$({$: "driven.Driven", "pair": _receiver_1, "deliveries": {$: "Nil"}}, 1, 1)), {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1});
    } else {
      return {$: "None"};
    }
  } else {
    return {$: "None"};
  }
}

function $driven$058execute_step$1260$(_step_0, _state_0) {
  if (_step_0 == 0) {
    return $driven$058fast$1260$(_state_0, false);
  } else if ((_step_0 & 15) == 0) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 8) {
    return $driven$058fast$1260$(_state_0, false);
  } else if ((_step_0 & 15) == 8) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 4) {
    return {$: "Some", "value": ($driven$058queue$1260$(_state_0, 2, 1))};
  } else if ((_step_0 & 7) == 4) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 2) {
    return {$: "Some", "value": ($driven$058queue$1260$(_state_0, 1, 1))};
  } else if ((_step_0 & 15) == 2) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 10) {
    return $driven$058slow$1260$(_state_0, false);
  } else if ((_step_0 & 15) == 10) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 6) {
    return $driven$058slow$1260$(_state_0, false);
  } else if ((_step_0 & 7) == 6) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 1) {
    return $driven$058slow$1260$(_state_0, false);
  } else if ((_step_0 & 15) == 1) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 9) {
    return $driven$058slow$1260$(_state_0, true);
  } else if ((_step_0 & 15) == 9) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 5) {
    return $driven$058fast$1260$(_state_0, false);
  } else if ((_step_0 & 7) == 5) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 3) {
    return {$: "Some", "value": ($driven$058queue$1260$(_state_0, 1, 99))};
  } else if ((_step_0 & 15) == 3) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 11) {
    return $driven$058fast$1260$(_state_0, false);
  } else if ((_step_0 & 15) == 11) {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  } else if (_step_0 == 7) {
    return {$: "Some", "value": ($driven$058barrier$1260$(_state_0))};
  } else {
    return {$: "Some", "value": ($driven$058frame$1260$(_state_0))};
  }
}

function $pair$058slow_registered$1260$(_result_0, _fast_0) {
  if (_result_0.$ === "runtime.RegistrationFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "pair.PairRejected", "runtime": _runtime_0};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _slow_0 = _result_0["reader"];
    return {$: "pair.PairReady", "pair": {$: "pair.OwnedReaders", "runtime": _runtime_1, "fast": _fast_0, "slow": _slow_0, "fastPrivate": array_node([101], [102]), "slowPrivate": array_node([201], [202])}};
  }
}

function $runtime$058registered_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "runtime.RegistrationFailed", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "runtime.Registered", "runtime": {$: "runtime.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1260$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1260$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1260$(_components_0) {
  return {$: "../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $driven$058execute_step$1261$(_step_0, _state_0) {
  if (_step_0 == 0) {
    return $driven$058fast$1261$(_state_0, false);
  } else if ((_step_0 & 15) == 0) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 8) {
    return $driven$058fast$1261$(_state_0, false);
  } else if ((_step_0 & 15) == 8) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 4) {
    return {$: "Some", "value": ($driven$058queue$1261$(_state_0, 2, 1))};
  } else if ((_step_0 & 7) == 4) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 2) {
    return {$: "Some", "value": ($driven$058queue$1261$(_state_0, 1, 1))};
  } else if ((_step_0 & 15) == 2) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 10) {
    return $driven$058slow$1261$(_state_0, false);
  } else if ((_step_0 & 15) == 10) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 6) {
    return $driven$058slow$1261$(_state_0, false);
  } else if ((_step_0 & 7) == 6) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 1) {
    return $driven$058slow$1261$(_state_0, false);
  } else if ((_step_0 & 15) == 1) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 9) {
    return $driven$058slow$1261$(_state_0, true);
  } else if ((_step_0 & 15) == 9) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 5) {
    return $driven$058fast$1261$(_state_0, false);
  } else if ((_step_0 & 7) == 5) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 3) {
    return {$: "Some", "value": ($driven$058queue$1261$(_state_0, 1, 99))};
  } else if ((_step_0 & 15) == 3) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 11) {
    return $driven$058fast$1261$(_state_0, false);
  } else if ((_step_0 & 15) == 11) {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  } else if (_step_0 == 7) {
    return {$: "Some", "value": ($driven$058barrier$1261$(_state_0))};
  } else {
    return {$: "Some", "value": ($driven$058frame$1261$(_state_0))};
  }
}

function $pair$058slow_registered$1261$(_result_0, _fast_0) {
  if (_result_0.$ === "runtime.RegistrationFailed") {
    const _runtime_0 = _result_0["runtime"];
    return {$: "pair.PairRejected", "runtime": _runtime_0};
  } else {
    const _runtime_1 = _result_0["runtime"];
    const _slow_0 = _result_0["reader"];
    return {$: "pair.PairReady", "pair": {$: "pair.OwnedReaders", "runtime": _runtime_1, "fast": _fast_0, "slow": _slow_0, "fastPrivate": array_node([101], [102]), "slowPrivate": array_node([201], [202])}};
  }
}

function $runtime$058registered_result$1261$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "runtime.RegistrationFailed", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "runtime.Registered", "runtime": {$: "runtime.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime.Reader", "registry": _registry_0, "keys": _keys_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_join$1261$(_value_0, _handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _ns_0 = _handle_0["namespace"];
  const _id_0 = _handle_0["id"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($Bool$and$((_namespace_0 === _ns_0), ($Bool$and$((0 < _id_0), (_id_0 < _nextId_0)))))};
}

function $$$$047$$$047$$$047src$047ecs$047world$058reserve_finish$1261$(_grown_0, _namespace_0, _nextId_0, _highWater_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _grown_0["live"];
  const _capacity_0 = _grown_0["capacity"];
  const _depth_0 = _grown_0["depth"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": ((_nextId_0 + 1) >>> 0), "highWater": _nextId_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Reserved", "handle": {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _nextId_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058empty$1261$(_components_0) {
  return {$: "../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": {$: "../../../src/ecs/relation-types.Graph", "edges": {$: "Nil"}, "inverses": {$: "Nil"}}};
}

function $foreign$1260$(_source_0, _receiver_0, _handle_0) {
  const _t_0 = _receiver_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fp_0 = _t_0["fastPrivate"];
  const _sp_0 = _t_0["slowPrivate"];
  return $queued$1260$(($runtime$058with_world$1262$(run_clo((_x_0) => {
  return $queue_foreign$1260$(_x_0, _handle_0);
}), _runtime_0)), _source_0, _fast_0, _slow_0, _fp_0, _sp_0);
}

function $driven$058queue$1260$(_state_0, _key_0, _target_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return $driven$058queue_completed$1260$(($runtime$058with_world$1260$(run_clo((_x_0) => {
  return $driven$058queue_named$1260$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_x_0)), _key_0, _target_0);
}), _runtime_0)), _fast_0, _slow_0, _fastPrivate_0, _slowPrivate_0, _previous_0);
}

function $foreign$1261$(_source_0, _receiver_0, _handle_0) {
  const _t_0 = _receiver_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fp_0 = _t_0["fastPrivate"];
  const _sp_0 = _t_0["slowPrivate"];
  return $queued$1261$(($runtime$058with_world$1263$(run_clo((_x_0) => {
  return $queue_foreign$1261$(_x_0, _handle_0);
}), _runtime_0)), _source_0, _fast_0, _slow_0, _fp_0, _sp_0);
}

function $driven$058queue$1261$(_state_0, _key_0, _target_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return $driven$058queue_completed$1261$(($runtime$058with_world$1261$(run_clo((_x_0) => {
  return $driven$058queue_named$1261$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_x_0)), _key_0, _target_0);
}), _runtime_0)), _fast_0, _slow_0, _fastPrivate_0, _slowPrivate_0, _previous_0);
}

function $driven$058fast$1260$(_state_0, _fail_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return $driven$058fast_completed$1260$(($runtime$058run$1260$(_runtime_0, _fast_0, {$: "application.ReaderArgs", "private": _fastPrivate_0, "fail": _fail_0})), _slow_0, _slowPrivate_0, _previous_0);
}

function $driven$058frame$1260$(_state_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": ($runtime$058frame$1260$(_runtime_0)), "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fastPrivate_0, "slowPrivate": _slowPrivate_0}, "deliveries": _previous_0};
}

function $driven$058slow$1260$(_state_0, _fail_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return $driven$058slow_completed$1260$(($runtime$058run$1260$(_runtime_0, _slow_0, {$: "application.ReaderArgs", "private": _slowPrivate_0, "fail": _fail_0})), _fast_0, _fastPrivate_0, _previous_0);
}

function $driven$058barrier$1260$(_state_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": ($runtime$058barrier$1260$(_runtime_0)), "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fastPrivate_0, "slowPrivate": _slowPrivate_0}, "deliveries": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1260$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.Rejected", "error": {$: "../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Accepted"}};
  }
}

function $driven$058fast$1261$(_state_0, _fail_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return $driven$058fast_completed$1261$(($runtime$058run$1261$(_runtime_0, _fast_0, {$: "application.ReaderArgs", "private": _fastPrivate_0, "fail": _fail_0})), _slow_0, _slowPrivate_0, _previous_0);
}

function $driven$058frame$1261$(_state_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": ($runtime$058frame$1261$(_runtime_0)), "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fastPrivate_0, "slowPrivate": _slowPrivate_0}, "deliveries": _previous_0};
}

function $driven$058slow$1261$(_state_0, _fail_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return $driven$058slow_completed$1261$(($runtime$058run$1261$(_runtime_0, _slow_0, {$: "application.ReaderArgs", "private": _slowPrivate_0, "fail": _fail_0})), _fast_0, _fastPrivate_0, _previous_0);
}

function $driven$058barrier$1261$(_state_0) {
  const _t_0 = _state_0["pair"];
  const _runtime_0 = _t_0["runtime"];
  const _fast_0 = _t_0["fast"];
  const _slow_0 = _t_0["slow"];
  const _fastPrivate_0 = _t_0["fastPrivate"];
  const _slowPrivate_0 = _t_0["slowPrivate"];
  const _previous_0 = _state_0["deliveries"];
  return {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": ($runtime$058barrier$1261$(_runtime_0)), "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fastPrivate_0, "slowPrivate": _slowPrivate_0}, "deliveries": _previous_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058set_live_checked$1261$(_allowed_0, _value_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.Rejected", "error": {$: "../../../src/ecs/world.MissingEntity"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": (_live_0[_id_0 % _live_0.length] = _value_0, _live_0), "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Accepted"}};
  }
}

function $queued$1260$(_queued_0, _source_0, _fast_0, _slow_0, _fp_0, _sp_0) {
  const _runtime_0 = _queued_0["fst"];
  const _t_0 = _queued_0["snd"];
  const _status_0 = _t_0["status"];
  const _before_0 = _t_0["before"];
  const _after_0 = _t_0["after"];
  return $result$1260$(_source_0, {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": _runtime_0, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fp_0, "slowPrivate": _sp_0}, "deliveries": {$: "Nil"}}, _status_0, _before_0, _after_0);
}

function $runtime$058with_world$1262$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$058with_world_result$1262$(_effect_0(_world_0), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $queue_foreign$1260$(_world_0, _handle_0) {
  return $counted_before$1260$(($$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0)), _handle_0);
}

function $driven$058queue_completed$1260$(_result_0, _fast_0, _slow_0, _fastPrivate_0, _slowPrivate_0, _previous_0) {
  const _runtime_0 = _result_0["fst"];
  return {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": _runtime_0, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fastPrivate_0, "slowPrivate": _slowPrivate_0}, "deliveries": _previous_0};
}

function $runtime$058with_world$1260$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$058with_world_result$1260$(_effect_0(_world_0), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $driven$058queue_named$1260$(_named_0, _key_0, _target_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $application$058queue$1260$(($application$058descriptor$1260$(_key_0)), {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _target_0}, _world_0);
}

function $queued$1261$(_queued_0, _source_0, _fast_0, _slow_0, _fp_0, _sp_0) {
  const _runtime_0 = _queued_0["fst"];
  const _t_0 = _queued_0["snd"];
  const _status_0 = _t_0["status"];
  const _before_0 = _t_0["before"];
  const _after_0 = _t_0["after"];
  return $result$1261$(_source_0, {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": _runtime_0, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fp_0, "slowPrivate": _sp_0}, "deliveries": {$: "Nil"}}, _status_0, _before_0, _after_0);
}

function $runtime$058with_world$1263$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$058with_world_result$1263$(_effect_0(_world_0), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $queue_foreign$1261$(_world_0, _handle_0) {
  return $counted_before$1261$(($$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0)), _handle_0);
}

function $driven$058queue_completed$1261$(_result_0, _fast_0, _slow_0, _fastPrivate_0, _slowPrivate_0, _previous_0) {
  const _runtime_0 = _result_0["fst"];
  return {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": _runtime_0, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _fastPrivate_0, "slowPrivate": _slowPrivate_0}, "deliveries": _previous_0};
}

function $runtime$058with_world$1261$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$058with_world_result$1261$(_effect_0(_world_0), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $driven$058queue_named$1261$(_named_0, _key_0, _target_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $application$058queue$1261$(($application$058descriptor$1261$(_key_0)), {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": 1}, {$: "../../../src/ecs/world.Handle", "namespace": _namespace_0, "id": _target_0}, _world_0);
}

function $driven$058fast_completed$1260$(_result_0, _slow_0, _otherPrivate_0, _previous_0) {
  const _runtime_0 = _result_0["runtime"];
  const _fast_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "runtime.Succeeded") {
    const _t_1 = _t_0["output"];
    const _owner_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": ($driven$058delivered$1260$("fast", 0, _readings_0, ($driven$058private_observed$({$: "Tuple", fst: _owner_0, snd: _owner_0.slice()})), _runtime_0, _fast_0, _slow_0, _otherPrivate_0, _previous_0, true))};
  } else if (_t_0.$ === "runtime.Failed") {
    const _error_0 = _t_0["error"];
    return $driven$058recovered_failure$1260$(($driven$058recover$1260$(_runtime_0)), _fast_0, _slow_0, _otherPrivate_0, _previous_0, "fast", _error_0, true);
  } else {
    return {$: "None"};
  }
}

function $runtime$058run$1260$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $runtime$058run_identified$1260$(_runtime_0, ($$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0)), _keys_0, _args_0);
}

function $runtime$058frame$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "runtime.Runtime", "world": _world_0, "domains": ($domains$058trim$1260$(_domains_0, _positions_0, _frameStart_0, _capacity_0)), "positions": _positions_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0};
}

function $driven$058slow_completed$1260$(_result_0, _fast_0, _otherPrivate_0, _previous_0) {
  const _runtime_0 = _result_0["runtime"];
  const _slow_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "runtime.Succeeded") {
    const _t_1 = _t_0["output"];
    const _owner_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": ($driven$058delivered$1260$("slow", 0, _readings_0, ($driven$058private_observed$({$: "Tuple", fst: _owner_0, snd: _owner_0.slice()})), _runtime_0, _fast_0, _slow_0, _otherPrivate_0, _previous_0, false))};
  } else if (_t_0.$ === "runtime.Failed") {
    const _error_0 = _t_0["error"];
    return $driven$058recovered_failure$1260$(($driven$058recover$1260$(_runtime_0)), _fast_0, _slow_0, _otherPrivate_0, _previous_0, "slow", _error_0, false);
  } else {
    return {$: "None"};
  }
}

function $runtime$058barrier$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$058barrier_join$1260$(($barrier$058barrier$1260$(_world_0, _domains_0, _tick_0)), _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $driven$058fast_completed$1261$(_result_0, _slow_0, _otherPrivate_0, _previous_0) {
  const _runtime_0 = _result_0["runtime"];
  const _fast_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "runtime.Succeeded") {
    const _t_1 = _t_0["output"];
    const _owner_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": ($driven$058delivered$1261$("fast", 0, _readings_0, ($driven$058private_observed$({$: "Tuple", fst: _owner_0, snd: _owner_0.slice()})), _runtime_0, _fast_0, _slow_0, _otherPrivate_0, _previous_0, true))};
  } else if (_t_0.$ === "runtime.Failed") {
    const _error_0 = _t_0["error"];
    return $driven$058recovered_failure$1261$(($driven$058recover$1261$(_runtime_0)), _fast_0, _slow_0, _otherPrivate_0, _previous_0, "fast", _error_0, true);
  } else {
    return {$: "None"};
  }
}

function $runtime$058run$1261$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  return $runtime$058run_identified$1261$(_runtime_0, ($$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0)), _keys_0, _args_0);
}

function $runtime$058frame$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _capacity_0 = _runtime_0["capacity"];
  return {$: "runtime.Runtime", "world": _world_0, "domains": ($domains$058trim$1261$(_domains_0, _positions_0, _frameStart_0, _capacity_0)), "positions": _positions_0, "tick": _tick_0, "frameStart": _tick_0, "boundary": _frameStart_0, "capacity": _capacity_0};
}

function $driven$058slow_completed$1261$(_result_0, _fast_0, _otherPrivate_0, _previous_0) {
  const _runtime_0 = _result_0["runtime"];
  const _slow_0 = _result_0["reader"];
  const _t_0 = _result_0["completion"];
  if (_t_0.$ === "runtime.Succeeded") {
    const _t_1 = _t_0["output"];
    const _owner_0 = _t_1["fst"];
    const _readings_0 = _t_1["snd"];
    return {$: "Some", "value": ($driven$058delivered$1261$("slow", 0, _readings_0, ($driven$058private_observed$({$: "Tuple", fst: _owner_0, snd: _owner_0.slice()})), _runtime_0, _fast_0, _slow_0, _otherPrivate_0, _previous_0, false))};
  } else if (_t_0.$ === "runtime.Failed") {
    const _error_0 = _t_0["error"];
    return $driven$058recovered_failure$1261$(($driven$058recover$1261$(_runtime_0)), _fast_0, _slow_0, _otherPrivate_0, _previous_0, "slow", _error_0, false);
  } else {
    return {$: "None"};
  }
}

function $runtime$058barrier$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $runtime$058barrier_join$1261$(($barrier$058barrier$1261$(_world_0, _domains_0, _tick_0)), _positions_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058register$1261$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$((_nextSystemId_0 < 4294967295), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $result$1260$(_source_0, _receiver_0, _status_0, _before_0, _after_0) {
  return {$: "Some", "value": {$: "ForeignResult", "status": _status_0, "before": _before_0, "after": _after_0, "source": ($observe$058observed$1260$({$: "Some", "value": {$: "driven.Driven", "pair": _source_0, "deliveries": {$: "Nil"}}})), "receiver": ($observe$058observed$1260$({$: "Some", "value": ($driven$058barrier$1260$(_receiver_0))}))}};
}

function $runtime$058with_world_result$1262$(_result_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$058with_world_collected$1262$(($routing$058collect$1260$(_world_0, nat_chk(_tick_0 + 1), _domains_0)), _output_0, _positions_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0);
}

function $counted_before$1260$(_counted_0, _handle_0) {
  const _world_0 = _counted_0["fst"];
  const _before_0 = _counted_0["snd"];
  return $foreign_queued$1260$(($application$058queue$1260$(($application$058descriptor$1260$(1)), _handle_0, _handle_0, _world_0)), _before_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_pending_0)));
}

function $runtime$058with_world_result$1260$(_result_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$058with_world_collected$1260$(($routing$058collect$1260$(_world_0, nat_chk(_tick_0 + 1), _domains_0)), _output_0, _positions_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0);
}

function $application$058queue$1260$(_descriptor_0, _source_0, _target_0, _world_0) {
  return $application$058queued$1260$(($$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), _descriptor_0, _source_0, _target_0)));
}

function $application$058descriptor$1260$(_key_0) {
  if (_key_0 == 1) {
    return {$: "../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../src/ecs/relation-types.Hierarchy"}};
  } else {
    return {$: "../../../src/ecs/relation-types.Descriptor", "key": 2, "name": "ParentB", "inverseName": "ChildrenB", "kind": {$: "../../../src/ecs/relation-types.Hierarchy"}};
  }
}

function $result$1261$(_source_0, _receiver_0, _status_0, _before_0, _after_0) {
  return {$: "Some", "value": {$: "ForeignResult", "status": _status_0, "before": _before_0, "after": _after_0, "source": ($observe$058observed$1261$({$: "Some", "value": {$: "driven.Driven", "pair": _source_0, "deliveries": {$: "Nil"}}})), "receiver": ($observe$058observed$1261$({$: "Some", "value": ($driven$058barrier$1261$(_receiver_0))}))}};
}

function $runtime$058with_world_result$1263$(_result_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$058with_world_collected$1263$(($routing$058collect$1261$(_world_0, nat_chk(_tick_0 + 1), _domains_0)), _output_0, _positions_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0);
}

function $counted_before$1261$(_counted_0, _handle_0) {
  const _world_0 = _counted_0["fst"];
  const _before_0 = _counted_0["snd"];
  return $foreign_queued$1261$(($application$058queue$1261$(($application$058descriptor$1261$(1)), _handle_0, _handle_0, _world_0)), _before_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_pending_0)));
}

function $runtime$058with_world_result$1261$(_result_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $runtime$058with_world_collected$1261$(($routing$058collect$1261$(_world_0, nat_chk(_tick_0 + 1), _domains_0)), _output_0, _positions_0, nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0);
}

function $application$058queue$1261$(_descriptor_0, _source_0, _target_0, _world_0) {
  return $application$058queued$1261$(($$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), _descriptor_0, _source_0, _target_0)));
}

function $application$058descriptor$1261$(_key_0) {
  if (_key_0 == 1) {
    return {$: "../../../src/ecs/relation-types.Descriptor", "key": 1, "name": "Parent", "inverseName": "Children", "kind": {$: "../../../src/ecs/relation-types.Hierarchy"}};
  } else {
    return {$: "../../../src/ecs/relation-types.Descriptor", "key": 2, "name": "ParentB", "inverseName": "ChildrenB", "kind": {$: "../../../src/ecs/relation-types.Hierarchy"}};
  }
}

function $driven$058delivered$1260$(_who_0, _result_0, _readings_0, _observed_0, _runtime_0, _fast_0, _slow_0, _other_0, _previous_0, _isFast_0) {
  const _owner_0 = _observed_0["fst"];
  const _observedCells_0 = _observed_0["snd"];
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $driven$058delivered_side$1260$(_isFast_0, {$: "pair.OwnedReaders", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _owner_0, "slowPrivate": _other_0}, {$: "Con", "head": {$: "driven.Delivery", "who": _who_0, "result": _result_0, "readings": _readings_0, "privateCells": _observedCells_0, "domains": _domains_0, "positions": _positions_0}, "tail": _previous_0});
}

function $driven$058recovered_failure$1260$(_recovered_0, _fast_0, _slow_0, _other_0, _previous_0, _who_0, _error_0, _isFast_0) {
  const _runtime_0 = _recovered_0["fst"];
  const _t_0 = _recovered_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _owner_0 = _t_1["private"];
    const _readings_0 = _t_1["readings"];
    return {$: "Some", "value": ($driven$058delivered$1260$(_who_0, _error_0, _readings_0, ($driven$058private_observed$({$: "Tuple", fst: _owner_0, snd: _owner_0.slice()})), _runtime_0, _fast_0, _slow_0, _other_0, _previous_0, _isFast_0))};
  } else {
    return {$: "None"};
  }
}

function $driven$058recover$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $driven$058recovered$1260$(($driven$058recover_world$1260$(_world_0)), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$058run_identified$1260$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $runtime$058run_result$1260$(($$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, {$: "runtime.Input", "readings": ($readings$058all$1260$(_keys_0, _domains_0, ($runtime$058position_or$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058identity$1260$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $domains$058trim$1260$(_domains_0, _positions_0, _fallback_0, _capacity_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _domain_0 = _domains_0["head"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": ($domains$058trim_domain$1260$(_domain_0, _positions_0, _fallback_0, _capacity_0)), "tail": ($domains$058trim$1260$(_rest_0, _positions_0, _fallback_0, _capacity_0))};
  }
}

function $runtime$058barrier_join$1260$(_state_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $barrier$058barrier$1260$(_world_0, _domains_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $barrier$058drain$1260$(($List$reverse$(_pending_0)), {$: "barrier.BarrierState", "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "tick": _tick_0});
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $driven$058delivered$1261$(_who_0, _result_0, _readings_0, _observed_0, _runtime_0, _fast_0, _slow_0, _other_0, _previous_0, _isFast_0) {
  const _owner_0 = _observed_0["fst"];
  const _observedCells_0 = _observed_0["snd"];
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $driven$058delivered_side$1261$(_isFast_0, {$: "pair.OwnedReaders", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _owner_0, "slowPrivate": _other_0}, {$: "Con", "head": {$: "driven.Delivery", "who": _who_0, "result": _result_0, "readings": _readings_0, "privateCells": _observedCells_0, "domains": _domains_0, "positions": _positions_0}, "tail": _previous_0});
}

function $driven$058recovered_failure$1261$(_recovered_0, _fast_0, _slow_0, _other_0, _previous_0, _who_0, _error_0, _isFast_0) {
  const _runtime_0 = _recovered_0["fst"];
  const _t_0 = _recovered_0["snd"];
  if (_t_0.$ === "Some") {
    const _t_1 = _t_0["value"];
    const _owner_0 = _t_1["private"];
    const _readings_0 = _t_1["readings"];
    return {$: "Some", "value": ($driven$058delivered$1261$(_who_0, _error_0, _readings_0, ($driven$058private_observed$({$: "Tuple", fst: _owner_0, snd: _owner_0.slice()})), _runtime_0, _fast_0, _slow_0, _other_0, _previous_0, _isFast_0))};
  } else {
    return {$: "None"};
  }
}

function $driven$058recover$1261$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $driven$058recovered$1261$(($driven$058recover_world$1261$(_world_0)), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $runtime$058run_identified$1261$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $runtime$058run_result$1261$(($$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, {$: "runtime.Input", "readings": ($readings$058all$1261$(_keys_0, _domains_0, ($runtime$058position_or$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058identity$1261$(_registry_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "snd": _id_0};
}

function $domains$058trim$1261$(_domains_0, _positions_0, _fallback_0, _capacity_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _domain_0 = _domains_0["head"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": ($domains$058trim_domain$1261$(_domain_0, _positions_0, _fallback_0, _capacity_0)), "tail": ($domains$058trim$1261$(_rest_0, _positions_0, _fallback_0, _capacity_0))};
  }
}

function $runtime$058barrier_join$1261$(_state_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0};
}

function $barrier$058barrier$1261$(_world_0, _domains_0, _tick_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $barrier$058drain$1261$(($List$reverse$(_pending_0)), {$: "barrier.BarrierState", "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "domains": _domains_0, "tick": _tick_0});
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1261$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $runtime$058with_world_collected$1262$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $routing$058collect$1260$(_world_0, _tick_0, _domains_0) {
  return $routing$058collect_view$1260$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _tick_0, _domains_0);
}

function $foreign_queued$1260$(_result_0, _before_0) {
  const _world_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $counted_after$1260$(($$$$047$$$047$$$047src$047ecs$047world$058pending_count$1260$(_world_0)), _status_0, _before_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1260$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_length$1260$(_rest_0)));
  }
}

function $runtime$058with_world_collected$1260$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $application$058queued$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $application$058queue_finish$1260$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, {$: "../../../src/ecs/transaction.Success"})), _status_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1260$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $runtime$058with_world_collected$1263$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $routing$058collect$1261$(_world_0, _tick_0, _domains_0) {
  return $routing$058collect_view$1261$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0)), _tick_0, _domains_0);
}

function $foreign_queued$1261$(_result_0, _before_0) {
  const _world_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $counted_after$1261$(($$$$047$$$047$$$047src$047ecs$047world$058pending_count$1261$(_world_0)), _status_0, _before_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_count_join$1261$(_namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _registrations_0, _nextSystemId_0, _clock_0, _counted_0) {
  const _pending_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _count_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_commands_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": 0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, ($$$$047$$$047$$$047src$047ecs$047world$058pending_length$1261$(_rest_0)));
  }
}

function $runtime$058with_world_collected$1261$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _output_0};
}

function $application$058queued$1261$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _status_0 = _result_0["snd"];
  return $application$058queue_finish$1261$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, {$: "../../../src/ecs/transaction.Success"})), _status_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_relate$1261$(_tx_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}};
}

function $driven$058delivered_side$1260$(_isFast_0, _pair_0, _deliveries_0) {
  if (_isFast_0) {
    return {$: "driven.Driven", "pair": _pair_0, "deliveries": _deliveries_0};
  } else {
    const _runtime_0 = _pair_0["runtime"];
    const _fast_0 = _pair_0["fast"];
    const _slow_0 = _pair_0["slow"];
    const _owner_0 = _pair_0["fastPrivate"];
    const _other_0 = _pair_0["slowPrivate"];
    return {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": _runtime_0, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _other_0, "slowPrivate": _owner_0}, "deliveries": _deliveries_0};
  }
}

function $driven$058recovered$1260$(_result_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _owner_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _owner_0};
}

function $driven$058recover_world$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _baseline_0 = _t_0["baseline"];
  const _t_1 = _t_0["returned"];
  if (_t_1.$ === "Con") {
    const _owner_0 = _t_1["head"];
    const _rest_0 = _t_1["tail"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "application.Resources", "baseline": _baseline_0, "returned": _rest_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "Some", "value": _owner_0}};
  } else {
    const _events_1 = _world_0["events"];
    const _pending_1 = _world_0["pending"];
    const _registrations_1 = _world_0["registrations"];
    const _nextSystemId_1 = _world_0["nextSystemId"];
    const _clock_1 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "application.Resources", "baseline": _baseline_0, "returned": _t_1}, "events": _events_1, "pending": _pending_1, "registrations": _registrations_1, "nextSystemId": _nextSystemId_1, "clock": _clock_1}, "snd": {$: "None"}};
  }
}

function $runtime$058run_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "runtime.Ran", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $runtime$058outcome$1260$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $readings$058all$1260$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($readings$058one$1260$(_domains_0, _key_0, _position_0)), "tail": ($readings$058all$1260$(_rest_0, _domains_0, _position_0))};
  }
}

function $domains$058trim_domain$1260$(_domain_0, _positions_0, _fallback_0, _capacity_0) {
  const _key_0 = _domain_0["key"];
  const _queue_0 = _domain_0["queue"];
  const _ids_0 = _domain_0["readers"];
  return {$: "domains.Domain", "key": _key_0, "queue": run_loop($queue$058trim$1260$(_queue_0, ($domains$058boundary$(_positions_0, _ids_0, _fallback_0)), _capacity_0)), "readers": _ids_0};
}

function $barrier$058drain$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _state_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($barrier$058command_collected$1260$(_command_0, _state_0));
        continue;
      }
    }
  }
}

function $driven$058delivered_side$1261$(_isFast_0, _pair_0, _deliveries_0) {
  if (_isFast_0) {
    return {$: "driven.Driven", "pair": _pair_0, "deliveries": _deliveries_0};
  } else {
    const _runtime_0 = _pair_0["runtime"];
    const _fast_0 = _pair_0["fast"];
    const _slow_0 = _pair_0["slow"];
    const _owner_0 = _pair_0["fastPrivate"];
    const _other_0 = _pair_0["slowPrivate"];
    return {$: "driven.Driven", "pair": {$: "pair.OwnedReaders", "runtime": _runtime_0, "fast": _fast_0, "slow": _slow_0, "fastPrivate": _other_0, "slowPrivate": _owner_0}, "deliveries": _deliveries_0};
  }
}

function $driven$058recovered$1261$(_result_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  const _world_0 = _result_0["fst"];
  const _owner_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "snd": _owner_0};
}

function $driven$058recover_world$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _baseline_0 = _t_0["baseline"];
  const _t_1 = _t_0["returned"];
  if (_t_1.$ === "Con") {
    const _owner_0 = _t_1["head"];
    const _rest_0 = _t_1["tail"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "application.Resources", "baseline": _baseline_0, "returned": _rest_0}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": {$: "Some", "value": _owner_0}};
  } else {
    const _events_1 = _world_0["events"];
    const _pending_1 = _world_0["pending"];
    const _registrations_1 = _world_0["registrations"];
    const _nextSystemId_1 = _world_0["nextSystemId"];
    const _clock_1 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "application.Resources", "baseline": _baseline_0, "returned": _t_1}, "events": _events_1, "pending": _pending_1, "registrations": _registrations_1, "nextSystemId": _nextSystemId_1, "clock": _clock_1}, "snd": {$: "None"}};
  }
}

function $runtime$058run_result$1261$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "runtime.Ran", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $runtime$058outcome$1261$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1261$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1261$(_world_0)), _args_0);
}

function $readings$058all$1261$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($readings$058one$1261$(_domains_0, _key_0, _position_0)), "tail": ($readings$058all$1261$(_rest_0, _domains_0, _position_0))};
  }
}

function $domains$058trim_domain$1261$(_domain_0, _positions_0, _fallback_0, _capacity_0) {
  const _key_0 = _domain_0["key"];
  const _queue_0 = _domain_0["queue"];
  const _ids_0 = _domain_0["readers"];
  return {$: "domains.Domain", "key": _key_0, "queue": run_loop($queue$058trim$1261$(_queue_0, ($domains$058boundary$(_positions_0, _ids_0, _fallback_0)), _capacity_0)), "readers": _ids_0};
}

function $barrier$058drain$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _state_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _state_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($barrier$058command_collected$1261$(_command_0, _state_0));
        continue;
      }
    }
  }
}

function $routing$058collect_view$1260$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $routing$058collected$1260$(_world_0, ($routing$058partition_loop$1260$(_items_0, {$: "routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $counted_after$1260$(_counted_0, _status_0, _before_0) {
  const _world_0 = _counted_0["fst"];
  const _after_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "ForeignQueue", "status": _status_0, "before": _before_0, "after": _after_0}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1260$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $application$058queue_finish$1260$(_result_0, _status_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _status_0};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1260$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $routing$058collect_view$1261$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $routing$058collected$1261$(_world_0, ($routing$058partition_loop$1261$(_items_0, {$: "routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_view$1261$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $counted_after$1261$(_counted_0, _status_0, _before_0) {
  const _world_0 = _counted_0["fst"];
  const _after_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "ForeignQueue", "status": _status_0, "before": _before_0, "after": _after_0}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058pending_prepend$1261$(_command_0, _counted_0) {
  const _commands_0 = _counted_0["fst"];
  const _count_0 = _counted_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _command_0, "tail": _commands_0}, "snd": ((_count_0 + 1) >>> 0)};
}

function $application$058queue_finish$1261$(_result_0, _status_0) {
  const _world_0 = _result_0["world"];
  return {$: "Tuple", "fst": _world_0, "snd": _status_0};
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_namespaced$1261$(_checked_0, _undo_0, _commands_0, _events_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _checked_0["fst"];
  const _namespace_0 = _checked_0["snd"];
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(($Bool$and$((_namespace_0 === _sn_0), (_namespace_0 === _tn_0))), {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0}, _descriptor_0, {$: "../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0}, {$: "../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $runtime$058outcome$1260$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "runtime.Ran", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": ($readings$058activate$1260$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "tick": nat_chk(_tick_0 + 1), "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $runtime$058succeeded_collected$1260$(($routing$058collect$1260$(_world_1, nat_chk(_tick_0 + 1), ($readings$058activate$1260$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), _id_0, nat_chk(_tick_0 + 1), false)), nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $readings$058one$1260$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $readings$058select$1260$(($domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $readings$058one$1260$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $queue$058trim$1260$(_queue_0, _boundary_0, _capacity_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return $queue$058trim_loop$1260$(nat_chk(_size_0 + 1), {$: "queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _boundary_0, _capacity_0);
}

function $barrier$058command_collected$1260$(_command_0, _state_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return $barrier$058collected$1260$(($routing$058collect$1260$(_command_0(_world_0), nat_chk(_tick_0 + 1), _domains_0)), nat_chk(_tick_0 + 1));
}

function $runtime$058outcome$1261$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "runtime.Ran", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": ($readings$058activate$1261$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), "tick": nat_chk(_tick_0 + 1), "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime.Failed", "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $runtime$058succeeded_collected$1261$(($routing$058collect$1261$(_world_1, nat_chk(_tick_0 + 1), ($readings$058activate$1261$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _tick_0)), _id_0, nat_chk(_tick_0 + 1), false)), nat_chk(_tick_0 + 1), _frameStart_0, _boundary_0, _capacity_0, _output_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1261$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0);
}

function $readings$058one$1261$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $readings$058select$1261$(($domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $readings$058one$1261$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $queue$058trim$1261$(_queue_0, _boundary_0, _capacity_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return $queue$058trim_loop$1261$(nat_chk(_size_0 + 1), {$: "queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _boundary_0, _capacity_0);
}

function $barrier$058command_collected$1261$(_command_0, _state_0) {
  const _world_0 = _state_0["world"];
  const _domains_0 = _state_0["domains"];
  const _tick_0 = _state_0["tick"];
  return $barrier$058collected$1261$(($routing$058collect$1261$(_command_0(_world_0), nat_chk(_tick_0 + 1), _domains_0)), nat_chk(_tick_0 + 1));
}

function $routing$058collected$1260$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($routing$058publish_batches$1260$(_batches_0, _tick_0, _domains_0))};
}

function $routing$058partition_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($routing$058partition_selected$1260$(($application$058classify$1260$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1260$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../src/ecs/relation-commands.Queued"}};
  }
}

function $routing$058collected$1261$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($routing$058publish_batches$1261$(_batches_0, _tick_0, _domains_0))};
}

function $routing$058partition_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($routing$058partition_selected$1261$(($application$058classify$1261$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1261$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058queue_checked$1261$(_same_0, _tx_0, _descriptor_0, _source_0, _target_0) {
  if (!_same_0) {
    return {$: "Tuple", "fst": _tx_0, "snd": {$: "../../../src/ecs/relation-commands.MissingEntity"}};
  } else {
    return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0);
}))), "snd": {$: "../../../src/ecs/relation-commands.Queued"}};
  }
}

function $readings$058activate$1260$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($domains$058activate_one$1260$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $runtime$058succeeded_collected$1260$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "runtime.Ran", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $readings$058select$1260$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $readings$058queue_reading$1260$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $domains$058key_equal$1260$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $queue$058trim_loop$1260$(_fuel_0, _queue_0, _boundary_0, _capacity_0) {
  if (_fuel_0 === 0) {
    return _queue_0;
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $queue$058trim_normalized$1260$(($queue$058normalize$1260$(_queue_0)), _boundary_0, _capacity_0, run_clo((_x_0) => {
  return $queue$058trim_loop$1260$(_rest_0, _x_0, _boundary_0, _capacity_0);
}));
  }
}

function $barrier$058collected$1260$(_joined_0, _tick_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "barrier.BarrierState", "world": _world_0, "domains": _domains_0, "tick": _tick_0};
}

function $readings$058activate$1261$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($domains$058activate_one$1261$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $runtime$058succeeded_collected$1261$(_joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "runtime.Ran", "runtime": {$: "runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0}, "reader": {$: "runtime.Reader", "registry": _registry_0, "keys": _keys_0}, "completion": {$: "runtime.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1261$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $readings$058select$1261$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $readings$058queue_reading$1261$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $domains$058key_equal$1261$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $queue$058trim_loop$1261$(_fuel_0, _queue_0, _boundary_0, _capacity_0) {
  if (_fuel_0 === 0) {
    return _queue_0;
  } else {
    const _rest_0 = (_fuel_0 - 1);
    return $queue$058trim_normalized$1261$(($queue$058normalize$1261$(_queue_0)), _boundary_0, _capacity_0, run_clo((_x_0) => {
  return $queue$058trim_loop$1261$(_rest_0, _x_0, _boundary_0, _capacity_0);
}));
  }
}

function $barrier$058collected$1261$(_joined_0, _tick_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "barrier.BarrierState", "world": _world_0, "domains": _domains_0, "tick": _tick_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $routing$058publish_batches$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($routing$058publish_one$1260$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $routing$058partition_selected$1260$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "routing.Partition", "ordinary": _ordinary_0, "batches": ($routing$058group$1260$(_batches_0, _wanted_0, _item_0))};
  }
}

function $application$058classify$1260$(_notice_0) {
  if (_notice_0.$ === "../../../src/ecs/relation-commands.RelationFailed") {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    return {$: "Some", "value": {$: "domains.DeclaredKey", "id": _key_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058stage$1260$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1260$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_replace$1261$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $routing$058publish_batches$1261$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($routing$058publish_one$1261$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $routing$058partition_selected$1261$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "routing.Partition", "ordinary": _ordinary_0, "batches": ($routing$058group$1261$(_batches_0, _wanted_0, _item_0))};
  }
}

function $application$058classify$1261$(_notice_0) {
  if (_notice_0.$ === "../../../src/ecs/relation-commands.RelationFailed") {
    const _t_0 = _notice_0["failure"];
    const _t_1 = _t_0["relation"];
    const _key_0 = _t_1["key"];
    return {$: "Some", "value": {$: "domains.DeclaredKey", "id": _key_0}};
  } else {
    return {$: "None"};
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1261$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058stage$1261$(_tx_0, _command_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": {$: "Con", "head": _command_0, "tail": _commands_0}, "events": _events_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_relate$1261$(_world_0, _descriptor_0, _source_0, _target_0) {
  const _sn_0 = _source_0["namespace"];
  const _sid_0 = _source_0["id"];
  const _tn_0 = _target_0["namespace"];
  const _tid_0 = _target_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, {$: "../../../src/ecs/world.Handle", "namespace": _sn_0, "id": _sid_0})), _descriptor_0, _sid_0, _tid_0, {$: "../../../src/ecs/world.Handle", "namespace": _tn_0, "id": _tid_0});
}

function $domains$058activate_one$1260$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "domains.Domain", "key": _wanted_0, "queue": ($queue$058empty$1260$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $domains$058activate_walk$1260$(($domains$058key_equal$1260$(_key_0, _wanted_0)), {$: "domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $domains$058activate_one$1260$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $readings$058queue_reading$1260$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "readings.KeyReading", "key": _key_0, "values": ($queue$058read$1260$({$: "queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $queue$058trim_normalized$1260$(_queue_0, _boundary_0, _capacity_0, _ih_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "queue.Queue", "front": {$: "Nil"}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _t_1 = _t_0["head"];
    const _tick_0 = _t_1["tick"];
    const _count_0 = _t_1["count"];
    const _items_0 = _t_1["values"];
    const _rest_0 = _t_0["tail"];
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    const _x_0 = ($Nat$is_le$(_tick_0, _boundary_0));
    const _x_1 = (_capacity_0 < _size_1);
    return $queue$058trim_step$1260$((_x_0 || _x_1), _tick_0, _count_0, _items_0, _rest_0, _back_1, _size_1, _dropped_1, _ih_0);
  }
}

function $queue$058normalize$1260$(_queue_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "queue.Queue", "front": ($List$reverse$(_back_0)), "back": {$: "Nil"}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    return {$: "queue.Queue", "front": _t_0, "back": _back_1, "size": _size_1, "dropped": _dropped_1};
  }
}

function $domains$058activate_one$1261$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "domains.Domain", "key": _wanted_0, "queue": ($queue$058empty$1261$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $domains$058activate_walk$1261$(($domains$058key_equal$1261$(_key_0, _wanted_0)), {$: "domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $domains$058activate_one$1261$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $readings$058queue_reading$1261$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "readings.KeyReading", "key": _key_0, "values": ($queue$058read$1261$({$: "queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $queue$058trim_normalized$1261$(_queue_0, _boundary_0, _capacity_0, _ih_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "queue.Queue", "front": {$: "Nil"}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _t_1 = _t_0["head"];
    const _tick_0 = _t_1["tick"];
    const _count_0 = _t_1["count"];
    const _items_0 = _t_1["values"];
    const _rest_0 = _t_0["tail"];
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    const _x_0 = ($Nat$is_le$(_tick_0, _boundary_0));
    const _x_1 = (_capacity_0 < _size_1);
    return $queue$058trim_step$1261$((_x_0 || _x_1), _tick_0, _count_0, _items_0, _rest_0, _back_1, _size_1, _dropped_1, _ih_0);
  }
}

function $queue$058normalize$1261$(_queue_0) {
  const _t_0 = _queue_0["front"];
  if (_t_0.$ === "Nil") {
    const _back_0 = _queue_0["back"];
    const _size_0 = _queue_0["size"];
    const _dropped_0 = _queue_0["dropped"];
    return {$: "queue.Queue", "front": ($List$reverse$(_back_0)), "back": {$: "Nil"}, "size": _size_0, "dropped": _dropped_0};
  } else {
    const _back_1 = _queue_0["back"];
    const _size_1 = _queue_0["size"];
    const _dropped_1 = _queue_0["dropped"];
    return {$: "queue.Queue", "front": _t_0, "back": _back_1, "size": _size_1, "dropped": _dropped_1};
  }
}

function $routing$058publish_one$1260$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "domains.Domain", "key": _wanted_0, "queue": ($queue$058publish$1260$(($queue$058empty$1260$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $routing$058publish_found$1260$(($domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $routing$058publish_one$1260$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $routing$058group$1260$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $routing$058group_found$1260$(($domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $routing$058group$1260$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid$1260$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1260$(_world_0, _handle_0)));
}

function $routing$058publish_one$1261$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "domains.Domain", "key": _wanted_0, "queue": ($queue$058publish$1261$(($queue$058empty$1261$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $routing$058publish_found$1261$(($domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $routing$058publish_one$1261$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $routing$058group$1261$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $routing$058group_found$1261$(($domains$058key_equal$1261$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $routing$058group$1261$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1261$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058publish$1261$(_world_0, _events_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1261$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_source$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _targetHandle_0) {
  const _world_0 = _checked_0["fst"];
  const _sourceLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(($$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _targetHandle_0)), _descriptor_0, _source_0, _target_0, _sourceLive_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid$1261$(_world_0, _handle_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, ($$$$047$$$047$$$047src$047ecs$047world$058metadata_valid$1261$(_world_0, _handle_0)));
}

function $queue$058empty$1260$() {
  return {$: "queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $domains$058activate_walk$1260$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($domains$058activate_domain$1260$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $queue$058read$1260$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $queue$058read_back$1260$(_front_0, _back_0, _cursor_0);
}

function $queue$058trim_step$1260$(_remove_0, _tick_0, _count_0, _items_0, _rest_0, _back_0, _size_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "queue.Queue", "front": {$: "Con", "head": {$: "queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _rest_0}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, {$: "queue.Queue", "front": _rest_0, "back": _back_0, "size": (_size_0 < _count_0 ? 0 : _size_0 - _count_0), "dropped": (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0)});
  }
}

function $Nat$is_le$(_a_0, _b_0) {
  return $Cmp$is_le$(cmp_new(_a_0, _b_0));
}

function $queue$058empty$1261$() {
  return {$: "queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $domains$058activate_walk$1261$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($domains$058activate_domain$1261$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1261$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1261$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $queue$058read$1261$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $queue$058read_back$1261$(_front_0, _back_0, _cursor_0);
}

function $queue$058trim_step$1261$(_remove_0, _tick_0, _count_0, _items_0, _rest_0, _back_0, _size_0, _dropped_0, _ih_0) {
  if (!_remove_0) {
    return {$: "queue.Queue", "front": {$: "Con", "head": {$: "queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _rest_0}, "back": _back_0, "size": _size_0, "dropped": _dropped_0};
  } else {
    return run_tail(_ih_0, {$: "queue.Queue", "front": _rest_0, "back": _back_0, "size": (_size_0 < _count_0 ? 0 : _size_0 - _count_0), "dropped": (_dropped_0 > _tick_0 ? _dropped_0 : _tick_0)});
  }
}

function $queue$058publish$1260$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($queue$058count_loop$1260$(_items_0, 0));
  return $queue$058publish_checked$1260$((0 < _x_0), _queue_0, _tick_0, _items_0, ($queue$058count_loop$1260$(_items_0, 0)));
}

function $routing$058publish_found$1260$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "domains.Domain", "key": _key_0, "queue": ($queue$058publish$1260$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $routing$058group_found$1260$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1260$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(($$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1260$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0);
}

function $queue$058publish$1261$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($queue$058count_loop$1261$(_items_0, 0));
  return $queue$058publish_checked$1261$((0 < _x_0), _queue_0, _tick_0, _items_0, ($queue$058count_loop$1261$(_items_0, 0)));
}

function $routing$058publish_found$1261$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "domains.Domain", "key": _key_0, "queue": ($queue$058publish$1261$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $routing$058group_found$1261$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1261$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058apply_live$1261$(_checked_0, _descriptor_0, _source_0, _target_0, _sourceLive_0) {
  const _world_0 = _checked_0["fst"];
  const _targetLive_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(($$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_x_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0);
}), _world_0)), _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_join$1261$(_handle_0, _checked_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0);
}

function $domains$058activate_domain$1260$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($application$058reader$1260$(_world_0, _args_0)));
  }
}

function $queue$058read_back$1260$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($queue$058read_loop$1260$(($List$reverse$(_back_0)), _cursor_0, ($queue$058read_loop$1260$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $Cmp$is_le$(_c_0) {
  if (_c_0.$ === "GT") {
    return false;
  } else {
    return true;
  }
}

function $domains$058activate_domain$1261$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1261$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, ($application$058reader$1261$(_world_0, _args_0)));
  }
}

function $queue$058read_back$1261$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($queue$058read_loop$1261$(($List$reverse$(_back_0)), _cursor_0, ($queue$058read_loop$1261$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $queue$058publish_checked$1260$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $queue$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058enqueue$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1260$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": {$: "../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store$1260$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1260$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1260$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $queue$058publish_checked$1261$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $queue$058publish_nonempty$1261$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $queue$058count_loop$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058enqueue$1261$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1261$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058publish_relate$1261$(_observed_0, _descriptor_0, _source_0, _target_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0.$ === "None") {
    return _world_0;
  } else {
    const _error_0 = _t_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1261$(_world_0, {$: "Con", "head": {$: "../../../src/ecs/relation-commands.RelationFailed", "failure": {$: "../../../src/ecs/relation-types.Failure", "relation": _descriptor_0, "operation": {$: "../../../src/ecs/relation-types.Relate"}, "source": _source_0, "target": _target_0, "error": _error_0}}, "tail": {$: "Nil"}});
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store$1261$(_effect_0, _world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_effect_0(_store_0), _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058store_relate$1261$(_store_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  const _components_0 = _store_0["components"];
  const _graph_0 = _store_0["graph"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0)), _components_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058valid_checked$1261$(_allowed_0, _world_0, _handle_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    const _id_0 = _handle_0["id"];
    return $$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$({$: "Tuple", fst: _live_0, snd: _live_0[_id_0 % _live_0.length]}, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $application$058reader$1260$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _t_0 = _input_0["args"];
  const _private_0 = _t_0["private"];
  const _fail_0 = _t_0["fail"];
  return $application$058reader_dispatch$1260$(_fail_0, _world_0, _readings_0, _private_0);
}

function $queue$058read_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($queue$058visible_items$1260$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1261$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $application$058reader$1261$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _t_0 = _input_0["args"];
  const _private_0 = _t_0["private"];
  const _fail_0 = _t_0["fail"];
  return $application$058reader_dispatch$1261$(_fail_0, _world_0, _readings_0, _private_0);
}

function $queue$058read_loop$1261$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($queue$058visible_items$1261$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1260$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1260$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1260$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058live_join$1260$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $queue$058publish_nonempty$1261$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append$1261$(_left_0, _right_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058with_store_finish$1261$(_observed_0, _namespace_0, _nextId_0, _highWater_0, _live_0, _capacity_0, _depth_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _store_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045commands$058relate_result$1261$(_result_0, _components_0) {
  const _graph_0 = _result_0["graph"];
  const _error_0 = _result_0["error"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/relation-commands.Store", "components": _components_0, "graph": _graph_0}, "snd": _error_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058relate$1261$(_graph_0, _descriptor_0, _source_0, _target_0, _sourceLive_0, _targetLive_0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$(_sourceLive_0, _targetLive_0, (_source_0 === _target_0), ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0)), _source_0, _target_0, ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0)))), _graph_0, _descriptor_0, _source_0, _target_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058live_join$1261$(_checked_0, _namespace_0, _nextId_0, _highWater_0, _capacity_0, _depth_0, _store_0, _resource_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _live_0 = _checked_0["fst"];
  const _found_0 = _checked_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _found_0};
}

function $application$058reader_dispatch$1260$(_fail_0, _world_0, _readings_0, _private_0) {
  if (!_fail_0) {
    return $application$058reader_success$1260$(_world_0, {$: "runtime.Input", "readings": _readings_0, "args": {$: "application.ReaderArgs", "private": _private_0, "fail": false}});
  } else {
    return $application$058reader_failure$1260$(_world_0, {$: "runtime.Input", "readings": _readings_0, "args": {$: "application.ReaderArgs", "private": _private_0, "fail": true}});
  }
}

function $queue$058visible_items$1260$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $queue$058prepend_items$1260$(_items_0, _acc_0);
  }
}

function $application$058reader_dispatch$1261$(_fail_0, _world_0, _readings_0, _private_0) {
  if (!_fail_0) {
    return $application$058reader_success$1261$(_world_0, {$: "runtime.Input", "readings": _readings_0, "args": {$: "application.ReaderArgs", "private": _private_0, "fail": false}});
  } else {
    return $application$058reader_failure$1261$(_world_0, {$: "runtime.Input", "readings": _readings_0, "args": {$: "application.ReaderArgs", "private": _private_0, "fail": true}});
  }
}

function $queue$058visible_items$1261$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $queue$058prepend_items$1261$(_items_0, _acc_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1260$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1260$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(($List$length$(_edges_0)), {$: "../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1260$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1261$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058checked$1261$(_error_0, _graph_0, _descriptor_0, _source_0, _target_0) {
  if (_error_0.$ === "Some") {
    const _error_1 = _error_0["value"];
    return {$: "../../../src/ecs/relation-types.CoreResult", "graph": _graph_0, "error": {$: "Some", "value": _error_1}};
  } else {
    const _edges_0 = _graph_0["edges"];
    const _inverses_0 = _graph_0["inverses"];
    return {$: "../../../src/ecs/relation-types.CoreResult", "graph": ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$(run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _target_0)), _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0)), "error": {$: "None"}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle$1261$(_graph_0, _descriptor_0, _source_0, _target_0) {
  const _edges_0 = _graph_0["edges"];
  const _inverses_0 = _graph_0["inverses"];
  const _k_0 = _descriptor_0["key"];
  const _n_0 = _descriptor_0["name"];
  const _inv_0 = _descriptor_0["inverseName"];
  const _t_0 = _descriptor_0["kind"];
  if (_t_0.$ === "../../../src/ecs/relation-types.Ordinary") {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(($List$length$(_edges_0)), {$: "../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0}, {$: "../../../src/ecs/relation-types.Descriptor", "key": _k_0, "name": _n_0, "inverseName": _inv_0, "kind": {$: "../../../src/ecs/relation-types.Hierarchy"}}, _source_0, _target_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058name$1261$(_descriptor_0) {
  const _name_0 = _descriptor_0["name"];
  return _name_0;
}

function $application$058reader_success$1260$(_world_0, _input_0) {
  return $application$058reader_success_returned$1260$(_world_0, ($closed$045access$058gameplay$1260$({$: "closed-access.ReadGrant"}, _input_0)));
}

function $application$058reader_failure$1260$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _t_0 = _input_0["args"];
  const _args_0 = _t_0["private"];
  return $application$058reader_failed_finish$1260$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)), {$: "../../../src/ecs/relation-commands.Original", "event": 999})), {$: "../../../src/ecs/transaction.Failure", "error": 77})), _args_0, _readings_0);
}

function $queue$058prepend_items$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $application$058reader_success$1261$(_world_0, _input_0) {
  return $application$058reader_success_returned$1261$(_world_0, ($closed$045access$058gameplay$1261$({$: "closed-access.ReadGrant"}, _input_0)));
}

function $application$058reader_failure$1261$(_world_0, _input_0) {
  const _readings_0 = _input_0["readings"];
  const _t_0 = _input_0["args"];
  const _args_0 = _t_0["private"];
  return $application$058reader_failed_finish$1261$(($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1261$(_world_0)), {$: "../../../src/ecs/relation-commands.Original", "event": 999})), {$: "../../../src/ecs/transaction.Failure", "error": 77})), _args_0, _readings_0);
}

function $queue$058prepend_items$1261$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1260$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1260$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $List$length$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = _xs_0["tail"];
    return nat_chk(($List$length$(_t_0)) + 1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058updated$1261$(_same_0, _edges_0, _inverses_0, _descriptor_0, _source_0, _target_0) {
  if (_same_0) {
    return {$: "../../../src/ecs/relation-types.Graph", "edges": _edges_0, "inverses": _inverses_0};
  } else {
    return {$: "../../../src/ecs/relation-types.Graph", "edges": ($List$append$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0)), {$: "Con", "head": {$: "../../../src/ecs/relation-types.Edge", "relation": _descriptor_0, "source": _source_0, "target": _target_0}, "tail": {$: "Nil"}})), "inverses": ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0)), _inverses_0, _descriptor_0, _source_0)), _descriptor_0, _target_0, _source_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0) {
  if (_edges_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _edges_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["source"];
    const _target_0 = _t_0["target"];
    const _rest_0 = _edges_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), _target_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_rest_0, _descriptor_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_fuel_0, _graph_0, _descriptor_0, _source_0, _current_0) {
  if (_fuel_0 === 0) {
    return (_source_0 === _current_0);
  } else {
    const _rest_0 = (_fuel_0 - 1);
    const _x_1 = (_source_0 === _current_0);
    const _x_2 = run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _current_0)), run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058cycle_loop$1261$(_rest_0, _graph_0, _descriptor_0, _source_0, _x_0);
})));
    return (_x_1 || _x_2);
  }
}

function $application$058reader_success_returned$1260$(_world_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["args"];
  const _args_0 = _t_1["private"];
  const _readings_0 = _result_0["snd"];
  return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Tuple", "fst": _args_0, "snd": _readings_0}};
}

function $closed$045access$058gameplay$1260$(_grant_0, _owner_0) {
  return $closed$045access$058all$1260$(_grant_0, _owner_0);
}

function $application$058reader_failed_finish$1260$(_returned_0, _args_0, _readings_0) {
  const _world_0 = _returned_0["world"];
  return {$: "../../../src/ecs/system.Failed", "world": ($application$058returned_args$1260$(_world_0, _args_0, _readings_0)), "error": 77};
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058emit$1260$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $application$058reader_success_returned$1261$(_world_0, _result_0) {
  const _t_0 = _result_0["fst"];
  const _t_1 = _t_0["args"];
  const _args_0 = _t_1["private"];
  const _readings_0 = _result_0["snd"];
  return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Tuple", "fst": _args_0, "snd": _readings_0}};
}

function $closed$045access$058gameplay$1261$(_grant_0, _owner_0) {
  return $closed$045access$058all$1261$(_grant_0, _owner_0);
}

function $application$058reader_failed_finish$1261$(_returned_0, _args_0, _readings_0) {
  const _world_0 = _returned_0["world"];
  return {$: "../../../src/ecs/system.Failed", "world": ($application$058returned_args$1261$(_world_0, _args_0, _readings_0)), "error": 77};
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058emit$1261$(_tx_0, _event_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1260$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1260$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1260$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1260$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1260$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1260$(_edges_0, _descriptor_0, _source_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge$1261$(_edges_0, _descriptor_0, _source_0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$(_edges_0, _descriptor_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  if (_entries_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _source_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _entries_0["head"];
    const _other_0 = _t_0["relation"];
    const _id_0 = _t_0["target"];
    const _sources_0 = _t_0["sources"];
    const _rest_0 = _entries_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add$1261$(_rest_0, _descriptor_0, _target_0, _source_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_previous$1261$(_previous_0, _entries_0, _descriptor_0, _source_0) {
  if (_previous_0.$ === "None") {
    return _entries_0;
  } else {
    const _target_0 = _previous_0["value"];
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0) {
  const _key_0 = _descriptor_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058next_cycle$1261$(_current_0, _next_0) {
  if (_current_0.$ === "None") {
    return false;
  } else {
    const _id_0 = _current_0["value"];
    return run_tail(_next_0, _id_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058target$1261$(_graph_0, _descriptor_0, _source_0) {
  const _edges_0 = _graph_0["edges"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058target_edges$1261$(_edges_0, _descriptor_0, _source_0);
}

function $closed$045access$058all$1260$(__0, _owner_0) {
  return $application$058read_input$1260$(_owner_0);
}

function $application$058returned_args$1260$(_world_0, _args_0, _readings_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _baseline_0 = _t_0["baseline"];
  const _returned_0 = _t_0["returned"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "application.Resources", "baseline": _baseline_0, "returned": {$: "Con", "head": {$: "application.ReturnedPrivate", "private": _args_0, "readings": _readings_0}, "tail": _returned_0}}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $closed$045access$058all$1261$(__0, _owner_0) {
  return $application$058read_input$1261$(_owner_0);
}

function $application$058returned_args$1261$(_world_0, _args_0, _readings_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _t_0 = _world_0["resource"];
  const _baseline_0 = _t_0["baseline"];
  const _returned_0 = _t_0["returned"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": {$: "application.Resources", "baseline": _baseline_0, "returned": {$: "Con", "head": {$: "application.ReturnedPrivate", "private": _args_0, "readings": _readings_0}, "tail": _returned_0}}, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1260$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1260$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1260$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_acc$1261$($0, $1, $2, $3) {
  for (;;) {
    {
      const _edges_0 = $0;
      const _descriptor_0 = $1;
      const _source_0 = $2;
      const _acc_0 = $3;
      if (_edges_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _edge_0 = _edges_0["head"];
        const _rest_0 = _edges_0["tail"];
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _source_0;
        $3 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_add_found$1261$(_found_0, _other_0, _id_0, _sources_0, _descriptor_0, _target_0, _source_0, _rest_0, _next_0) {
  if (_found_0) {
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$(($$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$(_sources_0, _source_0)), _sources_0, _source_0))}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _other_0, "target": _id_0, "sources": _sources_0}, "tail": _next_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove$1261$(_entries_0, _descriptor_0, _target_0, _source_0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$(_entries_0, _descriptor_0, _target_0, _source_0, {$: "Nil"});
}

function $application$058read_input$1260$(_input_0) {
  const _readings_0 = _input_0["readings"];
  const _args_0 = _input_0["args"];
  return {$: "Tuple", "fst": {$: "runtime.Input", "readings": _readings_0, "args": _args_0}, "snd": _readings_0};
}

function $application$058read_input$1261$(_input_0) {
  const _readings_0 = _input_0["readings"];
  const _args_0 = _input_0["args"];
  return {$: "Tuple", "fst": {$: "runtime.Input", "readings": _readings_0, "args": _args_0}, "snd": _readings_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1260$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1260$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1260$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_edge_keep$1261$(_edge_0, _descriptor_0, _source_0, _acc_0) {
  const _other_0 = _edge_0["relation"];
  const _id_0 = _edge_0["source"];
  const _target_0 = _edge_0["target"];
  const _x_0 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
  const _x_1 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
  return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _source_0))), {$: "../../../src/ecs/relation-types.Edge", "relation": _other_0, "source": _id_0, "target": _target_0}, _acc_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_acc$1261$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _entries_0 = $0;
      const _descriptor_0 = $1;
      const _target_0 = $2;
      const _source_0 = $3;
      const _acc_0 = $4;
      if (_entries_0.$ === "Nil") {
        return $List$reverse$(_acc_0);
      } else {
        const _t_0 = _entries_0["head"];
        const _other_0 = _t_0["relation"];
        const _id_0 = _t_0["target"];
        const _sources_0 = _t_0["sources"];
        const _rest_0 = _entries_0["tail"];
        const _x_0 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_other_0));
        const _x_1 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058key$1261$(_descriptor_0));
        $0 = _rest_0;
        $1 = _descriptor_0;
        $2 = _target_0;
        $3 = _source_0;
        $4 = ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(($Bool$and$((_x_0 === _x_1), (_id_0 === _target_0))), _other_0, _id_0, _sources_0, _source_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1260$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1260$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058edge_removed$1261$(_remove_0, _edge_0, _rest_0) {
  if (_remove_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _edge_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058inverse_remove_one$1261$(_matched_0, _descriptor_0, _target_0, _sources_0, _source_0, _rest_0) {
  if (_matched_0) {
    return $$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, ($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$(_sources_0, _source_0)), _rest_0);
  } else {
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": _sources_0}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1260$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045graph$058nonempty_inverse$1261$(_descriptor_0, _target_0, _sources_0, _rest_0) {
  if (_sources_0.$ === "Nil") {
    return _rest_0;
  } else {
    const _head_0 = _sources_0["head"];
    const _tail_0 = _sources_0["tail"];
    return {$: "Con", "head": {$: "../../../src/ecs/relation-types.Inverse", "relation": _descriptor_0, "target": _target_0, "sources": {$: "Con", "head": _head_0, "tail": _tail_0}}, "tail": _rest_0};
  }
}

function $0m0(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../src/ecs/world.Growth": at = at[key] = {...v, "depth": BigInt(v["depth"])}; return top[0];
      default: throw "bend: ../../../src/ecs/world.Growth has no tag " + v?.$ + " (its tags: ../../../src/ecs/world.Growth); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m2(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": nat_host(v["cursor"]), "registeredAt": nat_host(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m1(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m2(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m4(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "../../../src/ecs/event-runtime.Position": at = at[key] = {...v, "cursor": BigInt(v["cursor"]), "registeredAt": BigInt(v["registeredAt"])}; return top[0];
      default: throw "bend: ../../../src/ecs/event-runtime.Position has no tag " + v?.$ + " (its tags: ../../../src/ecs/event-runtime.Position); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m3(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m4(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m5(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m2(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m6(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m4(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m16(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "queue.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"]), "count": BigInt(v["count"])}; return top[0];
      default: throw "bend: queue.Batch has no tag " + v?.$ + " (its tags: queue.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m15(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m16(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m14(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "queue.Queue": at = at[key] = {...v, "front": $0m15(v["front"]), "back": $0m15(v["back"]), "size": BigInt(v["size"]), "dropped": BigInt(v["dropped"])}; return top[0];
      default: throw "bend: queue.Queue has no tag " + v?.$ + " (its tags: queue.Queue); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m13(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "domains.Domain": at = at[key] = {...v, "queue": $0m14(v["queue"])}; return top[0];
      default: throw "bend: domains.Domain has no tag " + v?.$ + " (its tags: domains.Domain); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m12(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m13(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m11(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "driven.Delivery": at = at[key] = {...v, "domains": $0m12(v["domains"]), "positions": $0m3(v["positions"])}; return top[0];
      default: throw "bend: driven.Delivery has no tag " + v?.$ + " (its tags: driven.Delivery); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m10(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m11(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m9(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "observe.Final": at = at[key] = {...v, "deliveries": $0m10(v["deliveries"]), "domains": $0m12(v["domains"]), "positions": $0m3(v["positions"]), "tick": BigInt(v["tick"]), "frameStart": BigInt(v["frameStart"]), "boundary": BigInt(v["boundary"]), "retentionCapacity": BigInt(v["retentionCapacity"]), "depth": BigInt(v["depth"]), "pendingCount": BigInt(v["pendingCount"])}; return top[0];
      default: throw "bend: observe.Final has no tag " + v?.$ + " (its tags: observe.Final); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m8(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m9(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m25(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "queue.Batch": at = at[key] = {...v, "tick": BigInt(v["tick"]), "count": BigInt(v["count"])}; return top[0];
      default: throw "bend: queue.Batch has no tag " + v?.$ + " (its tags: queue.Batch); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m24(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m25(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m23(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "queue.Queue": at = at[key] = {...v, "front": $0m24(v["front"]), "back": $0m24(v["back"]), "size": BigInt(v["size"]), "dropped": BigInt(v["dropped"])}; return top[0];
      default: throw "bend: queue.Queue has no tag " + v?.$ + " (its tags: queue.Queue); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m22(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "domains.Domain": at = at[key] = {...v, "queue": $0m23(v["queue"])}; return top[0];
      default: throw "bend: domains.Domain has no tag " + v?.$ + " (its tags: domains.Domain); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m21(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m22(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m20(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "driven.Delivery": at = at[key] = {...v, "domains": $0m21(v["domains"]), "positions": $0m3(v["positions"])}; return top[0];
      default: throw "bend: driven.Delivery has no tag " + v?.$ + " (its tags: driven.Delivery); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m19(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Nil": at[key] = v; return top[0];
      case "Con": at = at[key] = {...v, "head": $0m20(v["head"])}; key = "tail"; v = v[key]; continue;
      default: throw "bend: List has no tag " + v?.$ + " (its tags: Nil, Con); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m18(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "observe.Final": at = at[key] = {...v, "deliveries": $0m19(v["deliveries"]), "domains": $0m21(v["domains"]), "positions": $0m3(v["positions"]), "tick": BigInt(v["tick"]), "frameStart": BigInt(v["frameStart"]), "boundary": BigInt(v["boundary"]), "retentionCapacity": BigInt(v["retentionCapacity"]), "depth": BigInt(v["depth"]), "pendingCount": BigInt(v["pendingCount"])}; return top[0];
      default: throw "bend: observe.Final has no tag " + v?.$ + " (its tags: observe.Final); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m17(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m18(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m7(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m8(v["fst"]), "snd": $0m17(v["snd"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m28(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "ForeignResult": at = at[key] = {...v, "source": $0m8(v["source"]), "receiver": $0m8(v["receiver"])}; return top[0];
      default: throw "bend: ForeignResult has no tag " + v?.$ + " (its tags: ForeignResult); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m27(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m28(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m30(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "ForeignResult": at = at[key] = {...v, "source": $0m17(v["source"]), "receiver": $0m17(v["receiver"])}; return top[0];
      default: throw "bend: ForeignResult has no tag " + v?.$ + " (its tags: ForeignResult); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m29(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "None": at[key] = v; return top[0];
      case "Some": at = at[key] = {...v, "value": $0m30(v["value"])}; return top[0];
      default: throw "bend: Maybe has no tag " + v?.$ + " (its tags: None, Some); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m26(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m27(v["fst"]), "snd": $0m29(v["snd"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}
export default {
  "../../../src/ecs/string-equality.equal_walk": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../src/ecs/string-equality.equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../src/ecs/string-equality.access_equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047string$045equality$058access_equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../src/ecs/string-equality.registration_equal": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047string$045equality$058registration_equal$((a0), (a1), (a2), (a3), (a4), (a5)))); (a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "../../../src/ecs/world.factory": run_lib(() => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047world$058factory$()));  return r; }, 0),
  "../../../src/ecs/world.grow_live": run_lib((a0, a1, a2, a3) => { const r = $0m0(run_loop($$$$047$$$047$$$047src$047ecs$047world$058grow_live$(nat_host(a0), (a1), nat_host(a2), (a3)))); BigInt(a0); (a1); BigInt(a2); (a3); return r; }, 4),
  "../../../src/ecs/world.access_equal": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047world$058access_equal$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../src/ecs/world.matching_access": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047world$058matching_access$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../src/ecs/world.matching_id": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047world$058matching_id$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../../../src/ecs/world.registration_meta_matches": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../src/ecs/world.registration_list_walk": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "../../../src/ecs/world.registration_list_matches": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../src/ecs/world.next_clock": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../src/ecs/registration.retained": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047registration$058retained$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../src/ecs/registration.without": run_lib((a0, a1, a2, a3) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047registration$058without$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "../../../src/ecs/event-runtime.hold_boundary": run_lib((a0, a1) => { const r = BigInt(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058hold_boundary$($0m1(a0), nat_host(a1)))); $0m3(a0); BigInt(a1); return r; }, 2),
  "../../../src/ecs/event-runtime.update_checked": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = $0m3(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((a0), (a1), (a2), nat_host(a3), nat_host(a4), $0m1(a5), nat_host(a6)))); (a0); (a1); (a2); BigInt(a3); BigInt(a4); $0m3(a5); BigInt(a6); return r; }, 7),
  "../../../src/ecs/event-runtime.update": run_lib((a0, a1, a2, a3) => { const r = $0m3(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$($0m1(a0), (a1), nat_host(a2), (a3)))); $0m3(a0); (a1); BigInt(a2); (a3); return r; }, 4),
  "../../../src/ecs/event-runtime.choose_position": run_lib((a0, a1, a2) => { const r = $0m6(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((a0), $0m2(a1), $0m5(a2)))); (a0); $0m4(a1); $0m6(a2); return r; }, 3),
  "../../../src/ecs/event-runtime.lookup_checked": run_lib((a0, a1, a2) => { const r = $0m6(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$($0m2(a0), (a1), $0m5(a2)))); $0m4(a0); (a1); $0m6(a2); return r; }, 3),
  "../../../src/ecs/event-runtime.lookup": run_lib((a0, a1) => { const r = $0m6(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$($0m1(a0), (a1)))); $0m3(a0); (a1); return r; }, 2),
  "../../../src/ecs/event-runtime.activation": run_lib((a0, a1, a2, a3) => { const r = $0m3(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$($0m5(a0), $0m1(a1), (a2), nat_host(a3)))); $0m6(a0); $0m3(a1); (a2); BigInt(a3); return r; }, 4),
  "../../../src/ecs/event-runtime.activate": run_lib((a0, a1, a2) => { const r = $0m3(run_loop($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$($0m1(a0), (a1), nat_host(a2)))); $0m3(a0); (a1); BigInt(a2); return r; }, 3),
  "domains.member": run_lib((a0, a1) => { const r = (run_loop($domains$058member$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "domains.add_checked": run_lib((a0, a1, a2) => { const r = (run_loop($domains$058add_checked$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "domains.add": run_lib((a0, a1) => { const r = (run_loop($domains$058add$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "domains.select_boundary": run_lib((a0, a1, a2) => { const r = BigInt(run_loop($domains$058select_boundary$((a0), nat_host(a1), nat_host(a2)))); (a0); BigInt(a1); BigInt(a2); return r; }, 3),
  "domains.boundary": run_lib((a0, a1, a2) => { const r = BigInt(run_loop($domains$058boundary$($0m1(a0), (a1), nat_host(a2)))); $0m3(a0); (a1); BigInt(a2); return r; }, 3),
  "runtime.position_or": run_lib((a0, a1, a2) => { const r = $0m4(run_loop($runtime$058position_or$($0m5(a0), (a1), nat_host(a2)))); $0m6(a0); (a1); BigInt(a2); return r; }, 3),
  "../../../src/ecs/relation-graph.contains": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058contains$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../src/ecs/relation-graph.removed_id": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058removed_id$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../src/ecs/relation-graph.remove_id": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058remove_id$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "../../../src/ecs/relation-graph.chosen_target": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_target$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../src/ecs/relation-graph.chosen_inverse": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058chosen_inverse$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../src/ecs/relation-graph.appended_source": run_lib((a0, a1, a2) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058appended_source$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "../../../src/ecs/relation-graph.validation": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058validation$((a0), (a1), (a2), (a3), (a4), (a5), (a6)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "../../../src/ecs/relation-graph.already": run_lib((a0, a1) => { const r = (run_loop($$$$047$$$047$$$047src$047ecs$047relation$045graph$058already$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "driven.cells": run_lib((a0) => { const r = (run_loop($driven$058cells$((a0)))); (a0); return r; }, 1),
  "driven.private_observed": run_lib((a0) => { const r = (run_loop($driven$058private_observed$((a0)))); (a0); return r; }, 1),
  "observe.bool_cells": run_lib((a0) => { const r = (run_loop($observe$058bool_cells$((a0)))); (a0); return r; }, 1),
  "observe.main": run_lib(() => { const r = $0m7(run_loop($observe$058main$()));  return r; }, 0),
  "main": run_lib(() => { const r = $0m26(run_loop($main$()));  return r; }, 0),
};
