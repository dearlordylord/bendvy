import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {normalize} from '../codec.mjs';
import {expected} from '../oracle.mjs';
const [name,filename]=process.argv.slice(2);
const {default:api}=await import(pathToFileURL(resolve(filename)));
const observed=normalize(api.main()),baseline=expected();
assert.equal(observed.length,2);assert.notDeepEqual(observed,baseline);
const witnesses=[];
for(const [index,root] of ['ReadersAlpha','ReadersBeta'].entries()){
 const actual=observed[index],normal=baseline[index];
 assert.equal(actual.$,'Final');assert.equal(actual.deliveries.length,8);
 assert.deepEqual(actual.fastPrivate,[101,102]);assert.deepEqual(actual.slowPrivate,[201,202]);
 if(name==='advance-on-failure'){
  const failure=actual.deliveries[5],before=actual.deliveries[4],retry=actual.deliveries[6];
  assert.equal(failure.who,'slow');assert.equal(failure.result,77);
  assert.deepEqual(failure.readings,normal.deliveries[5].readings);
  assert.equal(before.positions.find(p=>p.id===2).cursor,7);
  assert.equal(failure.positions.find(p=>p.id===2).cursor,12);
  assert.deepEqual(retry.readings,[{$:'KeyReading',key:{$:'DeclaredKey',id:1},values:[],lagged:false}]);
  assert.equal(normal.deliveries[5].positions.find(p=>p.id===2).cursor,7);
  witnesses.push({root,semanticDefect:name,reader:'slow',before:7,failedCursor:12,expectedFailedCursor:7,retry:retry.readings,expectedRetry:normal.deliveries[6].readings});
 }else if(name==='advance-wrong-reader'){
  const first=actual.deliveries[0],last=actual.deliveries[7];
  assert.equal(first.who,'fast');assert.equal(first.positions.find(p=>p.id===1).cursor,0);
  assert.equal(normal.deliveries[0].positions.find(p=>p.id===1).cursor,1);
  assert.equal(last.positions.find(p=>p.id===2).cursor,14);
  assert.equal(normal.deliveries[7].positions.find(p=>p.id===2).cursor,13);
  assert.deepEqual(last.readings,normal.deliveries[4].readings);
  witnesses.push({root,semanticDefect:name,reader:'fast',actualInitialCursor:0,expectedInitialCursor:1,wrongSlowCursor:14,expectedSlowCursor:13,last: last.readings,expectedLast:normal.deliveries[7].readings});
 }else if(name==='publish-before-barrier'){
  const before=actual.deliveries[2];assert.equal(before.who,'fast');
  assert.deepEqual(before.readings,normal.deliveries[4].readings);
  assert.deepEqual(normal.deliveries[2].readings,[{$:'KeyReading',key:{$:'DeclaredKey',id:1},values:[],lagged:false}]);
  witnesses.push({root,semanticDefect:name,checkpoint:'fast-before-explicit-barrier',actual:before.readings,expected:normal.deliveries[2].readings});
 }else throw Error('unplanned semantic mutant');
}
console.log(JSON.stringify({boundedFiniteControl:true,reached:true,witnesses}));
