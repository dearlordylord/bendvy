
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID__________SRC_ECS_WORLD_CREATED 13
#define CID__________SRC_ECS_WORLD_CREATEREJECTED 14
#define CID_SCHEMA 15
#define CID__________SRC_ECS_WORLD_FACTORY 16
#define CID_CHR 17
#define CID__________SRC_ECS_WORLD_WORLD 18
#define CID__________SRC_ECS_SYSTEM_REGISTERED 19
#define CID__________SRC_ECS_SYSTEM_REGISTRATIONFAILED 20
#define CID_NIL 21
#define CID_CON 22
#define CID__________SRC_ECS_WORLD_REGISTRATIONMETA 23
#define CID__________SRC_ECS_SYSTEM_SUCCEEDED 24
#define CID__________SRC_ECS_SYSTEM_FAILED 25
#define CID__________SRC_ECS_SYSTEM_REGISTRY 26
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUNTIME 27
#define CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DOMAIN 28
#define CID__________SRC_ECS_EVENT_RUNTIME_POSITION 29
#define CID__________SRC_ECS_WORLD_REGISTERED 30
#define CID__________SRC_ECS_WORLD_REGISTRATIONREJECTED 31
#define CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DECLAREDKEY 32
#define CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_QUEUE_QUEUE 33
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_REGISTERED 34
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_REGISTRATIONFAILED 35
#define CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_KEYREADING 36
#define CID__________SRC_ECS_WORLD_MISSINGENTITY 37
#define CID__________SRC_ECS_WORLD_CAPACITYEXCEEDED 38
#define CID__________SRC_ECS_WORLD_NAMESPACEEXHAUSTED 39
#define CID__________SRC_ECS_WORLD_SYSTEMIDEXHAUSTED 40
#define CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_QUEUE_BATCH 41
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_INPUT 42
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_READER 43
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RAN 44
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_SUCCEEDED 45
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_FAILED 46
#define CID__________SRC_ECS_RELATION_FAILURE_RUNTIME_REJECTED 47
#define CID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_READERDISPOSED 48
#define CID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_READERDISPOSALREJECTED 49
#define CID__________SRC_ECS_SYSTEM_COMPLETED 50
#define CID__________SRC_ECS_SYSTEM_REGISTRATIONREJECTED 51
#define CID__________SRC_ECS_SYSTEM_DISPOSED 52
#define CID__________SRC_ECS_SYSTEM_DISPOSALREJECTED 53
#define CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION 54
#define CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PENDINGBATCH 55
#define CID_IO_PRINT 56
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER 0
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER_K4 1
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD 2
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD_K10 3
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0 4
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0_K17 5
#define FID__________SRC_ECS_WORLD_ACCESS_EQUAL 6
#define FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K20 7
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0 8
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_C39 9
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_K40 10
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0 11
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_C42 12
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_K43 13
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0 14
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_C50 15
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K51 16
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K52 17
#define FID__________SRC_ECS_REGISTRATION_WITHOUT 18
#define FID__________SRC_ECS_REGISTRATION_WITHOUT_K54 19
#define FID__________SRC_ECS_REGISTRATION_WITHOUT_K55 20
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0 21
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0_K67 22
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0 23
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0_K69 24
#define FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE 25
#define FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE_K77 26
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0 27
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0_K79 28
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE 29
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE_K86 30
#define FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES 31
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0 32
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0_K97 33
#define FID__________SRC_ECS_SYSTEM_RUN_0 34
#define FID__________SRC_ECS_SYSTEM_RUN_0_K105 35
#define FID_NAT_SHOW_FIN 36
#define FID__________SRC_ECS_REGISTRATION_REMOVE_0 37
#define FID__________SRC_ECS_REGISTRATION_REMOVE_0_K119 38
#define FID__________SRC_ECS_REGISTRATION_REMOVE_0_K120 39
#define FID__________SRC_ECS_EVENT_RUNTIME_UPDATE 40
#define FID__________SRC_ECS_EVENT_RUNTIME_UPDATE_K123 41
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0 42
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K125 43
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K126 44
#define FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK 45
#define FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K128 46
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0 47
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_C145 48
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K146 49
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K147 50
#define FID_NAT_SHOW 51
#define FID_U32_SHOW_GO 52
#define FID__________SRC_ECS_SYSTEM_DISPOSE_0 53
#define FID__________SRC_ECS_SYSTEM_DISPOSE_0_K161 54
#define FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES 55
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0 56
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K183 57
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K184 58
#define FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP 59
#define FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP_K187 60
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0 61
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K190 62
#define FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K191 63
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0 64
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0_K193 65
#define FID_POSITIONS_TAIL 66
#define FID_POSITIONS_TAIL_K202 67
#define FID_POSITIONS_TAIL_K203 68
#define FID_POSITIONS_TAIL_K204 69
#define FID_POSITION 70
#define FID_POSITION_K206 71
#define FID_POSITION_K207 72
#define FID_POSITION_K208 73
#define FID_POSITION_K209 74
#define FID_POSITION_K210 75
#define FID_POSITION_K211 76
#define FID_POSITION_K212 77
#define FID_POSITION_K213 78
#define FID_READINGS_TAIL 79
#define FID_READINGS_TAIL_K215 80
#define FID_READINGS_TAIL_K216 81
#define FID_READINGS_TAIL_K217 82
#define FID_READING 83
#define FID_READING_K219 84
#define FID_READING_K220 85
#define FID_READING_K221 86
#define FID_READING_K222 87
#define FID_READING_K223 88
#define FID_READING_K224 89
#define FID_READING_K225 90
#define FID_TAIL 91
#define FID_TAIL_K228 92
#define FID_TAIL_K229 93
#define FID_TAIL_K230 94
#define FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0 95
#define FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K236 96
#define FID_POSITIONS 97
#define FID_POSITIONS_K268 98
#define FID_POSITIONS_K269 99
#define FID_POSITIONS_K270 100
#define FID_POSITIONS_K271 101
#define FID_READINGS 102
#define FID_READINGS_K273 103
#define FID_READINGS_K274 104
#define FID_READINGS_K275 105
#define FID_READINGS_K276 106
#define FID_U32_SHOW 107
#define FID_NUMBERS 108
#define FID_NUMBERS_K279 109
#define FID_NUMBERS_K280 110
#define FID_NUMBERS_K281 111
#define FID_NUMBERS_K282 112
#define FID_STRING_APPEND 113
#define FID_STRING_APPEND_K284 114
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0 115
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K286 116
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K287 117
#define FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K288 118
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0 119
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0_K313 120
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0 121
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K317 122
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K318 123
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K319 124
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K320 125
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K321 126
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K322 127
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K323 128
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K324 129
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K325 130
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0 131
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K363 132
#define FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K364 133
#define FID_CREATED 134
#define FID_CREATED_C604 135
#define FID_CREATED_K605 136
#define FID_CREATED_K606 137
#define FID_CREATED_K607 138
#define FID_CREATED_K608 139
#define FID_CREATED_K609 140
#define FID_CREATED_K610 141
#define FID_CREATED_K611 142
#define FID_CREATED_K612 143
#define FID_CREATED_K613 144
#define FID_CREATED_K614 145
#define FID_CREATED_K615 146
#define FID_CREATED_K616 147
#define FID_CREATED_K617 148
#define FID_CREATED_K618 149
#define FID_CREATED_K619 150
#define FID_CREATED_K620 151
#define FID_CREATED_K621 152
#define FID_CREATED_K622 153
#define FID_CREATED_K623 154
#define FID_CREATED_K624 155
#define FID_CREATED_K625 156
#define FID_CREATED_K626 157
#define FID_CREATED_K627 158
#define FID_CREATED_K628 159
#define FID_CREATED_K629 160
#define FID_CREATED_K630 161
#define FID_CREATED_K631 162
#define FID_CREATED_K632 163
#define FID_CREATED_K633 164
#define FID_CREATED_K634 165
#define FID_CREATED_K635 166
#define FID_CREATED_K636 167
#define FID_CREATED_K637 168
#define FID_CREATED_K638 169
#define FID_CREATED_K639 170
#define FID_MAIN 171
#define FID_MAIN_K641 172
#define FID_IO_PRINT 173
#define FID_IO_EMIT 174
#define FID_CLO_APPLY 175
#define FID_EXIT 176
#define FID_ENTER 177
CONSTV u8 FID_T[][3] = { { 2, 0, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 8, 0, 2 }, { 6, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 3, 0, 2 }, { 4, 0, 2 }, { 3, 1, 2 }, { 4, 0, 2 }, { 5, 0, 2 }, { 7, 1, 2 }, { 3, 0, 2 }, { 4, 0, 2 }, { 7, 6, 2 }, { 7, 1, 2 }, { 4, 0, 2 }, { 8, 1, 2 }, { 5, 1, 2 }, { 5, 0, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 3, 0, 2 }, { 7, 4, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 6, 0, 2 }, { 3, 0, 2 }, { 3, 2, 2 }, { 17, 0, 2 }, { 18, 12, 2 }, { 4, 0, 2 }, { 15, 0, 2 }, { 16, 1, 2 }, { 11, 1, 2 }, { 4, 0, 2 }, { 7, 1, 2 }, { 2, 0, 2 }, { 8, 1, 2 }, { 7, 1, 2 }, { 5, 0, 2 }, { 5, 1, 2 }, { 5, 0, 2 }, { 6, 0, 2 }, { 3, 3, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 3, 0, 2 }, { 16, 0, 2 }, { 17, 12, 2 }, { 4, 0, 2 }, { 13, 0, 2 }, { 15, 2, 2 }, { 13, 1, 2 }, { 2, 0, 2 }, { 8, 4, 2 }, { 5, 0, 2 }, { 8, 3, 2 }, { 4, 1, 2 }, { 18, 0, 2 }, { 19, 19, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 14, 0, 2 }, { 14, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 25, 0, 2 }, { 26, 17, 2 }, { 19, 1, 2 }, { 18, 1, 2 }, { 13, 0, 2 }, { 1, 1, 2 }, { 25, 0, 2 }, { 29, 4, 2 }, { 26, 1, 2 }, { 28, 19, 2 }, { 26, 1, 2 }, { 25, 1, 2 }, { 27, 1, 2 }, { 27, 12, 2 }, { 26, 1, 2 }, { 26, 1, 2 }, { 19, 0, 2 }, { 18, 11, 2 }, { 18, 12, 2 }, { 13, 0, 2 }, { 1, 0, 2 }, { 28, 18, 2 }, { 30, 27, 2 }, { 31, 26, 2 }, { 31, 1, 2 }, { 31, 1, 2 }, { 31, 1, 2 }, { 31, 1, 2 }, { 32, 1, 2 }, { 31, 1, 2 }, { 30, 1, 2 }, { 30, 1, 2 }, { 29, 1, 2 }, { 29, 1, 2 }, { 28, 1, 2 }, { 28, 1, 2 }, { 27, 1, 2 }, { 27, 1, 2 }, { 20, 12, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 20, 1, 2 }, { 21, 12, 2 }, { 22, 1, 2 }, { 22, 1, 2 }, { 21, 1, 2 }, { 21, 1, 2 }, { 20, 1, 2 }, { 20, 1, 2 }, { 19, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 14, 0 }, { 2, 0 }, { 0, 1 }, { 1, 1 }, { 1, 1 }, { 13, 1 }, { 18, 0 }, { 13, 0 }, { 0, 1 }, { 2, 1 }, { 3, 1 }, { 2, 1 }, { 2, 1 }, { 5, 1 }, { 20, 1 }, { 6, 1 }, { 3, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 4, 1 }, { 27, 0 }, { 20, 0 }, { 3, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 3, 1 }, { 2, 1 }, { 7, 1 }, { 29, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 20, 1 }, { 27, 1 }, { 20, 1 }, { 19, 1 }, { 13, 1 }, { 18, 1 }, { 2, 1 }, { 2, 1 }, { 2, 0 } };
#define STAT_LEN 768

#define WL_RESW 27
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
    if ((N) <= 19) break; r19 = e.mem[(A) + 19]; \
    if ((N) <= 20) break; r20 = e.mem[(A) + 20]; \
    if ((N) <= 21) break; r21 = e.mem[(A) + 21]; \
    if ((N) <= 22) break; r22 = e.mem[(A) + 22]; \
    if ((N) <= 23) break; r23 = e.mem[(A) + 23]; \
    if ((N) <= 24) break; r24 = e.mem[(A) + 24]; \
    if ((N) <= 25) break; r25 = e.mem[(A) + 25]; \
    if ((N) <= 26) break; r26 = e.mem[(A) + 26]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
    case 19: r19 = (X); \
      break; \
    case 20: r20 = (X); \
      break; \
    case 21: r21 = (X); \
      break; \
    case 22: r22 = (X); \
      break; \
    case 23: r23 = (X); \
      break; \
    case 24: r24 = (X); \
      break; \
    case 25: r25 = (X); \
      break; \
    case 26: r26 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18; (V)[19] = r19; (V)[20] = r20; (V)[21] = r21; (V)[22] = r22; (V)[23] = r23; (V)[24] = r24; (V)[25] = r25; (V)[26] = r26;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18]; r19 = (V)[19]; r20 = (V)[20]; r21 = (V)[21]; r22 = (V)[22]; r23 = (V)[23]; r24 = (V)[24]; r25 = (V)[25]; r26 = (V)[26];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18, Term r19, Term r20, Term r21, Term r22, Term r23, Term r24, Term r25, Term r26

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26

#define WL_TABLE WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER_K4) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD_K10) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0_K17) WL_X(FID__________SRC_ECS_WORLD_ACCESS_EQUAL) WL_X(FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K20) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_C39) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_K40) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_C42) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_K43) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_C50) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K51) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K52) WL_X(FID__________SRC_ECS_REGISTRATION_WITHOUT) WL_X(FID__________SRC_ECS_REGISTRATION_WITHOUT_K54) WL_X(FID__________SRC_ECS_REGISTRATION_WITHOUT_K55) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0_K67) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0_K69) WL_X(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE) WL_X(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE_K77) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0_K79) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE_K86) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0_K97) WL_X(FID__________SRC_ECS_SYSTEM_RUN_0) WL_X(FID__________SRC_ECS_SYSTEM_RUN_0_K105) WL_X(FID_NAT_SHOW_FIN) WL_X(FID__________SRC_ECS_REGISTRATION_REMOVE_0) WL_X(FID__________SRC_ECS_REGISTRATION_REMOVE_0_K119) WL_X(FID__________SRC_ECS_REGISTRATION_REMOVE_0_K120) WL_X(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE) WL_X(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE_K123) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K125) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K126) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K128) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_C145) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K146) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K147) WL_X(FID_NAT_SHOW) WL_X(FID_U32_SHOW_GO) WL_X(FID__________SRC_ECS_SYSTEM_DISPOSE_0) WL_X(FID__________SRC_ECS_SYSTEM_DISPOSE_0_K161) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K183) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K184) WL_X(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP) WL_X(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP_K187) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K190) WL_X(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K191) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0_K193) WL_X(FID_POSITIONS_TAIL) WL_X(FID_POSITIONS_TAIL_K202) WL_X(FID_POSITIONS_TAIL_K203) WL_X(FID_POSITIONS_TAIL_K204) WL_X(FID_POSITION) WL_X(FID_POSITION_K206) WL_X(FID_POSITION_K207) WL_X(FID_POSITION_K208) WL_X(FID_POSITION_K209) WL_X(FID_POSITION_K210) WL_X(FID_POSITION_K211) WL_X(FID_POSITION_K212) WL_X(FID_POSITION_K213) WL_X(FID_READINGS_TAIL) WL_X(FID_READINGS_TAIL_K215) WL_X(FID_READINGS_TAIL_K216) WL_X(FID_READINGS_TAIL_K217) WL_X(FID_READING) WL_X(FID_READING_K219) WL_X(FID_READING_K220) WL_X(FID_READING_K221) WL_X(FID_READING_K222) WL_X(FID_READING_K223) WL_X(FID_READING_K224) WL_X(FID_READING_K225) WL_X(FID_TAIL) WL_X(FID_TAIL_K228) WL_X(FID_TAIL_K229) WL_X(FID_TAIL_K230) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K236) WL_X(FID_POSITIONS) WL_X(FID_POSITIONS_K268) WL_X(FID_POSITIONS_K269) WL_X(FID_POSITIONS_K270) WL_X(FID_POSITIONS_K271) WL_X(FID_READINGS) WL_X(FID_READINGS_K273) WL_X(FID_READINGS_K274) WL_X(FID_READINGS_K275) WL_X(FID_READINGS_K276) WL_X(FID_U32_SHOW) WL_X(FID_NUMBERS) WL_X(FID_NUMBERS_K279) WL_X(FID_NUMBERS_K280) WL_X(FID_NUMBERS_K281) WL_X(FID_NUMBERS_K282) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K284) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K286) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K287) WL_X(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K288) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0_K313) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K317) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K318) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K319) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K320) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K321) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K322) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K323) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K324) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K325) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K363) WL_X(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K364) WL_X(FID_CREATED) WL_X(FID_CREATED_C604) WL_X(FID_CREATED_K605) WL_X(FID_CREATED_K606) WL_X(FID_CREATED_K607) WL_X(FID_CREATED_K608) WL_X(FID_CREATED_K609) WL_X(FID_CREATED_K610) WL_X(FID_CREATED_K611) WL_X(FID_CREATED_K612) WL_X(FID_CREATED_K613) WL_X(FID_CREATED_K614) WL_X(FID_CREATED_K615) WL_X(FID_CREATED_K616) WL_X(FID_CREATED_K617) WL_X(FID_CREATED_K618) WL_X(FID_CREATED_K619) WL_X(FID_CREATED_K620) WL_X(FID_CREATED_K621) WL_X(FID_CREATED_K622) WL_X(FID_CREATED_K623) WL_X(FID_CREATED_K624) WL_X(FID_CREATED_K625) WL_X(FID_CREATED_K626) WL_X(FID_CREATED_K627) WL_X(FID_CREATED_K628) WL_X(FID_CREATED_K629) WL_X(FID_CREATED_K630) WL_X(FID_CREATED_K631) WL_X(FID_CREATED_K632) WL_X(FID_CREATED_K633) WL_X(FID_CREATED_K634) WL_X(FID_CREATED_K635) WL_X(FID_CREATED_K636) WL_X(FID_CREATED_K637) WL_X(FID_CREATED_K638) WL_X(FID_CREATED_K639) WL_X(FID_MAIN) WL_X(FID_MAIN_K641) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 125ull, term_pak(CID_SNIL, 0), 58ull, term_pak(CID_SNIL, 0), 34ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 4), 120ull, term_ctr(CID_SCON, STAT_OFF + 6), 101ull, term_ctr(CID_SCON, STAT_OFF + 8), 110ull, term_ctr(CID_SCON, STAT_OFF + 10), 34ull, term_ctr(CID_SCON, STAT_OFF + 12), 44ull, term_ctr(CID_SCON, STAT_OFF + 14), 101ull, term_ctr(CID_SCON, STAT_OFF + 16), 117ull, term_ctr(CID_SCON, STAT_OFF + 18), 114ull, term_ctr(CID_SCON, STAT_OFF + 20), 116ull, term_ctr(CID_SCON, STAT_OFF + 22), 58ull, term_ctr(CID_SCON, STAT_OFF + 24), 34ull, term_ctr(CID_SCON, STAT_OFF + 26), 100ull, term_ctr(CID_SCON, STAT_OFF + 28), 101ull, term_ctr(CID_SCON, STAT_OFF + 30), 116ull, term_ctr(CID_SCON, STAT_OFF + 32), 115ull, term_ctr(CID_SCON, STAT_OFF + 34), 117ull, term_ctr(CID_SCON, STAT_OFF + 36), 97ull, term_ctr(CID_SCON, STAT_OFF + 38), 104ull, term_ctr(CID_SCON, STAT_OFF + 40), 120ull, term_ctr(CID_SCON, STAT_OFF + 42), 101ull, term_ctr(CID_SCON, STAT_OFF + 44), 34ull, term_ctr(CID_SCON, STAT_OFF + 46), 44ull, term_ctr(CID_SCON, STAT_OFF + 48), 115ull, term_ctr(CID_SCON, STAT_OFF + 6), 97ull, term_ctr(CID_SCON, STAT_OFF + 52), 108ull, term_ctr(CID_SCON, STAT_OFF + 54), 34ull, term_ctr(CID_SCON, STAT_OFF + 56), 44ull, term_ctr(CID_SCON, STAT_OFF + 58), 112ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 62), 114ull, term_ctr(CID_SCON, STAT_OFF + 64), 119ull, term_ctr(CID_SCON, STAT_OFF + 66), 45ull, term_ctr(CID_SCON, STAT_OFF + 68), 100ull, term_ctr(CID_SCON, STAT_OFF + 70), 101ull, term_ctr(CID_SCON, STAT_OFF + 72), 116ull, term_ctr(CID_SCON, STAT_OFF + 74), 99ull, term_ctr(CID_SCON, STAT_OFF + 76), 101ull, term_ctr(CID_SCON, STAT_OFF + 78), 112ull, term_ctr(CID_SCON, STAT_OFF + 80), 120ull, term_ctr(CID_SCON, STAT_OFF + 82), 101ull, term_ctr(CID_SCON, STAT_OFF + 84), 110ull, term_ctr(CID_SCON, STAT_OFF + 86), 117ull, term_ctr(CID_SCON, STAT_OFF + 88), 110ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 92), 105ull, term_ctr(CID_SCON, STAT_OFF + 94), 116ull, term_ctr(CID_SCON, STAT_OFF + 96), 115ull, term_ctr(CID_SCON, STAT_OFF + 98), 117ull, term_ctr(CID_SCON, STAT_OFF + 100), 97ull, term_ctr(CID_SCON, STAT_OFF + 102), 104ull, term_ctr(CID_SCON, STAT_OFF + 104), 120ull, term_ctr(CID_SCON, STAT_OFF + 106), 101ull, term_ctr(CID_SCON, STAT_OFF + 108), 45ull, term_ctr(CID_SCON, STAT_OFF + 110), 121ull, term_ctr(CID_SCON, STAT_OFF + 112), 108ull, term_ctr(CID_SCON, STAT_OFF + 114), 114ull, term_ctr(CID_SCON, STAT_OFF + 116), 97ull, term_ctr(CID_SCON, STAT_OFF + 118), 101ull, term_ctr(CID_SCON, STAT_OFF + 120), 45ull, term_ctr(CID_SCON, STAT_OFF + 122), 100ull, term_ctr(CID_SCON, STAT_OFF + 124), 101ull, term_ctr(CID_SCON, STAT_OFF + 126), 116ull, term_ctr(CID_SCON, STAT_OFF + 128), 99ull, term_ctr(CID_SCON, STAT_OFF + 130), 101ull, term_ctr(CID_SCON, STAT_OFF + 132), 112ull, term_ctr(CID_SCON, STAT_OFF + 134), 120ull, term_ctr(CID_SCON, STAT_OFF + 136), 101ull, term_ctr(CID_SCON, STAT_OFF + 138), 110ull, term_ctr(CID_SCON, STAT_OFF + 140), 117ull, term_ctr(CID_SCON, STAT_OFF + 142), 101ull, term_pak(CID_SNIL, 0), 117ull, term_ctr(CID_SCON, STAT_OFF + 146), 114ull, term_ctr(CID_SCON, STAT_OFF + 148), 116ull, term_ctr(CID_SCON, STAT_OFF + 150), 115ull, term_ctr(CID_SCON, STAT_OFF + 146), 108ull, term_ctr(CID_SCON, STAT_OFF + 154), 97ull, term_ctr(CID_SCON, STAT_OFF + 156), 102ull, term_ctr(CID_SCON, STAT_OFF + 158), 110ull, term_ctr(CID_SCON, STAT_OFF + 4), 111ull, term_ctr(CID_SCON, STAT_OFF + 162), 105ull, term_ctr(CID_SCON, STAT_OFF + 164), 116ull, term_ctr(CID_SCON, STAT_OFF + 166), 115ull, term_ctr(CID_SCON, STAT_OFF + 168), 117ull, term_ctr(CID_SCON, STAT_OFF + 170), 97ull, term_ctr(CID_SCON, STAT_OFF + 172), 104ull, term_ctr(CID_SCON, STAT_OFF + 174), 120ull, term_ctr(CID_SCON, STAT_OFF + 176), 69ull, term_ctr(CID_SCON, STAT_OFF + 178), 101ull, term_ctr(CID_SCON, STAT_OFF + 180), 114ull, term_ctr(CID_SCON, STAT_OFF + 182), 111ull, term_ctr(CID_SCON, STAT_OFF + 184), 102ull, term_ctr(CID_SCON, STAT_OFF + 186), 101ull, term_ctr(CID_SCON, STAT_OFF + 188), 66ull, term_ctr(CID_SCON, STAT_OFF + 190), 114ull, term_ctr(CID_SCON, STAT_OFF + 192), 101ull, term_ctr(CID_SCON, STAT_OFF + 194), 100ull, term_ctr(CID_SCON, STAT_OFF + 196), 97ull, term_ctr(CID_SCON, STAT_OFF + 198), 101ull, term_ctr(CID_SCON, STAT_OFF + 200), 82ull, term_ctr(CID_SCON, STAT_OFF + 202), 116ull, term_ctr(CID_SCON, STAT_OFF + 204), 120ull, term_ctr(CID_SCON, STAT_OFF + 206), 101ull, term_ctr(CID_SCON, STAT_OFF + 208), 110ull, term_ctr(CID_SCON, STAT_OFF + 210), 34ull, term_ctr(CID_SCON, STAT_OFF + 212), 44ull, term_ctr(CID_SCON, STAT_OFF + 214), 109ull, term_ctr(CID_SCON, STAT_OFF + 4), 101ull, term_ctr(CID_SCON, STAT_OFF + 218), 116ull, term_ctr(CID_SCON, STAT_OFF + 220), 115ull, term_ctr(CID_SCON, STAT_OFF + 222), 121ull, term_ctr(CID_SCON, STAT_OFF + 224), 83ull, term_ctr(CID_SCON, STAT_OFF + 226), 100ull, term_ctr(CID_SCON, STAT_OFF + 228), 101ull, term_ctr(CID_SCON, STAT_OFF + 230), 115ull, term_ctr(CID_SCON, STAT_OFF + 232), 111ull, term_ctr(CID_SCON, STAT_OFF + 234), 112ull, term_ctr(CID_SCON, STAT_OFF + 236), 115ull, term_ctr(CID_SCON, STAT_OFF + 238), 105ull, term_ctr(CID_SCON, STAT_OFF + 240), 100ull, term_ctr(CID_SCON, STAT_OFF + 242), 34ull, term_ctr(CID_SCON, STAT_OFF + 244), 44ull, term_ctr(CID_SCON, STAT_OFF + 246), 103ull, term_ctr(CID_SCON, STAT_OFF + 228), 110ull, term_ctr(CID_SCON, STAT_OFF + 250), 105ull, term_ctr(CID_SCON, STAT_OFF + 252), 110ull, term_ctr(CID_SCON, STAT_OFF + 254), 105ull, term_ctr(CID_SCON, STAT_OFF + 256), 97ull, term_ctr(CID_SCON, STAT_OFF + 258), 109ull, term_ctr(CID_SCON, STAT_OFF + 260), 101ull, term_ctr(CID_SCON, STAT_OFF + 262), 114ull, term_ctr(CID_SCON, STAT_OFF + 264), 34ull, term_ctr(CID_SCON, STAT_OFF + 266), 44ull, term_ctr(CID_SCON, STAT_OFF + 268), 44ull, term_pak(CID_SNIL, 0), 65ull, term_ctr(CID_SCON, STAT_OFF + 6), 100ull, term_ctr(CID_SCON, STAT_OFF + 274), 101ull, term_ctr(CID_SCON, STAT_OFF + 276), 114ull, term_ctr(CID_SCON, STAT_OFF + 278), 101ull, term_ctr(CID_SCON, STAT_OFF + 280), 116ull, term_ctr(CID_SCON, STAT_OFF + 282), 115ull, term_ctr(CID_SCON, STAT_OFF + 284), 105ull, term_ctr(CID_SCON, STAT_OFF + 286), 103ull, term_ctr(CID_SCON, STAT_OFF + 288), 101ull, term_ctr(CID_SCON, STAT_OFF + 290), 114ull, term_ctr(CID_SCON, STAT_OFF + 292), 34ull, term_ctr(CID_SCON, STAT_OFF + 294), 44ull, term_ctr(CID_SCON, STAT_OFF + 296), 114ull, term_ctr(CID_SCON, STAT_OFF + 4), 111ull, term_ctr(CID_SCON, STAT_OFF + 300), 115ull, term_ctr(CID_SCON, STAT_OFF + 302), 114ull, term_ctr(CID_SCON, STAT_OFF + 304), 117ull, term_ctr(CID_SCON, STAT_OFF + 306), 99ull, term_ctr(CID_SCON, STAT_OFF + 308), 34ull, term_ctr(CID_SCON, STAT_OFF + 310), 44ull, term_ctr(CID_SCON, STAT_OFF + 312), 100ull, term_ctr(CID_SCON, STAT_OFF + 4), 105ull, term_ctr(CID_SCON, STAT_OFF + 316), 34ull, term_ctr(CID_SCON, STAT_OFF + 318), 123ull, term_ctr(CID_SCON, STAT_OFF + 320), 101ull, term_ctr(CID_SCON, STAT_OFF + 316), 103ull, term_ctr(CID_SCON, STAT_OFF + 324), 103ull, term_ctr(CID_SCON, STAT_OFF + 326), 97ull, term_ctr(CID_SCON, STAT_OFF + 328), 108ull, term_ctr(CID_SCON, STAT_OFF + 330), 34ull, term_ctr(CID_SCON, STAT_OFF + 332), 44ull, term_ctr(CID_SCON, STAT_OFF + 334), 115ull, term_ctr(CID_SCON, STAT_OFF + 4), 101ull, term_ctr(CID_SCON, STAT_OFF + 338), 117ull, term_ctr(CID_SCON, STAT_OFF + 340), 108ull, term_ctr(CID_SCON, STAT_OFF + 342), 97ull, term_ctr(CID_SCON, STAT_OFF + 344), 118ull, term_ctr(CID_SCON, STAT_OFF + 346), 34ull, term_ctr(CID_SCON, STAT_OFF + 348), 44ull, term_ctr(CID_SCON, STAT_OFF + 350), 121ull, term_ctr(CID_SCON, STAT_OFF + 4), 101ull, term_ctr(CID_SCON, STAT_OFF + 354), 107ull, term_ctr(CID_SCON, STAT_OFF + 356), 34ull, term_ctr(CID_SCON, STAT_OFF + 358), 123ull, term_ctr(CID_SCON, STAT_OFF + 360), 48ull, term_pak(CID_SNIL, 0), 108ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 366), 101ull, term_ctr(CID_SCON, STAT_OFF + 368), 114ull, term_ctr(CID_SCON, STAT_OFF + 370), 116ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 374), 101ull, term_ctr(CID_SCON, STAT_OFF + 376), 114ull, term_ctr(CID_SCON, STAT_OFF + 378), 97ull, term_ctr(CID_SCON, STAT_OFF + 380), 80ull, term_ctr(CID_SCON, STAT_OFF + 382), term_ctr(CID_SCON, STAT_OFF + 384), term_pak(CID_NIL, 0), 93ull, term_pak(CID_SNIL, 0), 91ull, term_ctr(CID_SCON, STAT_OFF + 388), 91ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 368), 117ull, term_ctr(CID_SCON, STAT_OFF + 394), 102ull, term_ctr(CID_SCON, STAT_OFF + 396), 101ull, term_ctr(CID_SCON, STAT_OFF + 398), 114ull, term_ctr(CID_SCON, STAT_OFF + 400), 45ull, term_ctr(CID_SCON, STAT_OFF + 402), 108ull, term_ctr(CID_SCON, STAT_OFF + 404), 97ull, term_ctr(CID_SCON, STAT_OFF + 406), 115ull, term_ctr(CID_SCON, STAT_OFF + 408), 111ull, term_ctr(CID_SCON, STAT_OFF + 410), 112ull, term_ctr(CID_SCON, STAT_OFF + 412), 115ull, term_ctr(CID_SCON, STAT_OFF + 414), 105ull, term_ctr(CID_SCON, STAT_OFF + 416), 100ull, term_ctr(CID_SCON, STAT_OFF + 418), 45ull, term_ctr(CID_SCON, STAT_OFF + 420), 100ull, term_ctr(CID_SCON, STAT_OFF + 422), 101ull, term_ctr(CID_SCON, STAT_OFF + 424), 116ull, term_ctr(CID_SCON, STAT_OFF + 426), 99ull, term_ctr(CID_SCON, STAT_OFF + 428), 101ull, term_ctr(CID_SCON, STAT_OFF + 430), 112ull, term_ctr(CID_SCON, STAT_OFF + 432), 120ull, term_ctr(CID_SCON, STAT_OFF + 434), 101ull, term_ctr(CID_SCON, STAT_OFF + 436), 110ull, term_ctr(CID_SCON, STAT_OFF + 438), 117ull, term_ctr(CID_SCON, STAT_OFF + 440), 100ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 444), 116ull, term_ctr(CID_SCON, STAT_OFF + 446), 97ull, term_ctr(CID_SCON, STAT_OFF + 448), 108ull, term_ctr(CID_SCON, STAT_OFF + 450), 101ull, term_ctr(CID_SCON, STAT_OFF + 452), 114ull, term_ctr(CID_SCON, STAT_OFF + 454), 110ull, term_ctr(CID_SCON, STAT_OFF + 456), 117ull, term_ctr(CID_SCON, STAT_OFF + 458), 101ull, term_ctr(CID_SCON, STAT_OFF + 300), 116ull, term_ctr(CID_SCON, STAT_OFF + 462), 102ull, term_ctr(CID_SCON, STAT_OFF + 464), 65ull, term_ctr(CID_SCON, STAT_OFF + 466), 115ull, term_ctr(CID_SCON, STAT_OFF + 468), 110ull, term_ctr(CID_SCON, STAT_OFF + 470), 111ull, term_ctr(CID_SCON, STAT_OFF + 472), 105ull, term_ctr(CID_SCON, STAT_OFF + 474), 116ull, term_ctr(CID_SCON, STAT_OFF + 476), 105ull, term_ctr(CID_SCON, STAT_OFF + 478), 115ull, term_ctr(CID_SCON, STAT_OFF + 480), 111ull, term_ctr(CID_SCON, STAT_OFF + 482), 112ull, term_ctr(CID_SCON, STAT_OFF + 484), 34ull, term_ctr(CID_SCON, STAT_OFF + 486), 44ull, term_ctr(CID_SCON, STAT_OFF + 488), 101ull, term_ctr(CID_SCON, STAT_OFF + 4), 114ull, term_ctr(CID_SCON, STAT_OFF + 492), 111ull, term_ctr(CID_SCON, STAT_OFF + 494), 102ull, term_ctr(CID_SCON, STAT_OFF + 496), 101ull, term_ctr(CID_SCON, STAT_OFF + 498), 66ull, term_ctr(CID_SCON, STAT_OFF + 500), 115ull, term_ctr(CID_SCON, STAT_OFF + 502), 110ull, term_ctr(CID_SCON, STAT_OFF + 504), 111ull, term_ctr(CID_SCON, STAT_OFF + 506), 105ull, term_ctr(CID_SCON, STAT_OFF + 508), 116ull, term_ctr(CID_SCON, STAT_OFF + 510), 105ull, term_ctr(CID_SCON, STAT_OFF + 512), 115ull, term_ctr(CID_SCON, STAT_OFF + 514), 111ull, term_ctr(CID_SCON, STAT_OFF + 516), 112ull, term_ctr(CID_SCON, STAT_OFF + 518), 34ull, term_ctr(CID_SCON, STAT_OFF + 520), 44ull, term_ctr(CID_SCON, STAT_OFF + 522), 103ull, term_ctr(CID_SCON, STAT_OFF + 338), 110ull, term_ctr(CID_SCON, STAT_OFF + 526), 105ull, term_ctr(CID_SCON, STAT_OFF + 528), 100ull, term_ctr(CID_SCON, STAT_OFF + 530), 97ull, term_ctr(CID_SCON, STAT_OFF + 532), 101ull, term_ctr(CID_SCON, STAT_OFF + 534), 114ull, term_ctr(CID_SCON, STAT_OFF + 536), 34ull, term_ctr(CID_SCON, STAT_OFF + 538), 44ull, term_ctr(CID_SCON, STAT_OFF + 540), 115ull, term_ctr(CID_SCON, STAT_OFF + 226), 34ull, term_ctr(CID_SCON, STAT_OFF + 544), 44ull, term_ctr(CID_SCON, STAT_OFF + 546), 100ull, term_ctr(CID_SCON, STAT_OFF + 462), 97ull, term_ctr(CID_SCON, STAT_OFF + 550), 101ull, term_ctr(CID_SCON, STAT_OFF + 552), 114ull, term_ctr(CID_SCON, STAT_OFF + 554), 34ull, term_ctr(CID_SCON, STAT_OFF + 556), 44ull, term_ctr(CID_SCON, STAT_OFF + 558), 118ull, term_ctr(CID_SCON, STAT_OFF + 324), 114ull, term_ctr(CID_SCON, STAT_OFF + 562), 101ull, term_ctr(CID_SCON, STAT_OFF + 564), 115ull, term_ctr(CID_SCON, STAT_OFF + 566), 101ull, term_ctr(CID_SCON, STAT_OFF + 568), 114ull, term_ctr(CID_SCON, STAT_OFF + 570), 34ull, term_ctr(CID_SCON, STAT_OFF + 572), 123ull, term_ctr(CID_SCON, STAT_OFF + 574), 114ull, term_ctr(CID_SCON, STAT_OFF + 146), 117ull, term_ctr(CID_SCON, STAT_OFF + 578), 108ull, term_ctr(CID_SCON, STAT_OFF + 580), 105ull, term_ctr(CID_SCON, STAT_OFF + 582), 97ull, term_ctr(CID_SCON, STAT_OFF + 584), 102ull, term_ctr(CID_SCON, STAT_OFF + 586), 45ull, term_ctr(CID_SCON, STAT_OFF + 588), 110ull, term_ctr(CID_SCON, STAT_OFF + 590), 117ull, term_ctr(CID_SCON, STAT_OFF + 592), 114ull, term_ctr(CID_SCON, STAT_OFF + 594), 45ull, term_ctr(CID_SCON, STAT_OFF + 596), 100ull, term_ctr(CID_SCON, STAT_OFF + 598), 101ull, term_ctr(CID_SCON, STAT_OFF + 600), 116ull, term_ctr(CID_SCON, STAT_OFF + 602), 99ull, term_ctr(CID_SCON, STAT_OFF + 604), 101ull, term_ctr(CID_SCON, STAT_OFF + 606), 112ull, term_ctr(CID_SCON, STAT_OFF + 608), 120ull, term_ctr(CID_SCON, STAT_OFF + 610), 101ull, term_ctr(CID_SCON, STAT_OFF + 612), 110ull, term_ctr(CID_SCON, STAT_OFF + 614), 117ull, term_ctr(CID_SCON, STAT_OFF + 616), 42ull, term_pak(CID_NIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 592), 105ull, term_ctr(CID_SCON, STAT_OFF + 622), 116ull, term_ctr(CID_SCON, STAT_OFF + 624), 97ull, term_ctr(CID_SCON, STAT_OFF + 626), 118ull, term_ctr(CID_SCON, STAT_OFF + 628), 114ull, term_ctr(CID_SCON, STAT_OFF + 630), 101ull, term_ctr(CID_SCON, STAT_OFF + 632), 115ull, term_ctr(CID_SCON, STAT_OFF + 634), 101ull, term_ctr(CID_SCON, STAT_OFF + 636), 114ull, term_ctr(CID_SCON, STAT_OFF + 638), 45ull, term_ctr(CID_SCON, STAT_OFF + 640), 100ull, term_ctr(CID_SCON, STAT_OFF + 642), 101ull, term_ctr(CID_SCON, STAT_OFF + 644), 116ull, term_ctr(CID_SCON, STAT_OFF + 646), 99ull, term_ctr(CID_SCON, STAT_OFF + 648), 101ull, term_ctr(CID_SCON, STAT_OFF + 650), 112ull, term_ctr(CID_SCON, STAT_OFF + 652), 120ull, term_ctr(CID_SCON, STAT_OFF + 654), 101ull, term_ctr(CID_SCON, STAT_OFF + 656), 110ull, term_ctr(CID_SCON, STAT_OFF + 658), 117ull, term_ctr(CID_SCON, STAT_OFF + 660), 114ull, term_ctr(CID_SCON, STAT_OFF + 628), 116ull, term_ctr(CID_SCON, STAT_OFF + 664), 115ull, term_ctr(CID_SCON, STAT_OFF + 666), 105ull, term_ctr(CID_SCON, STAT_OFF + 668), 103ull, term_ctr(CID_SCON, STAT_OFF + 670), 101ull, term_ctr(CID_SCON, STAT_OFF + 672), 114ull, term_ctr(CID_SCON, STAT_OFF + 674), 45ull, term_ctr(CID_SCON, STAT_OFF + 676), 100ull, term_ctr(CID_SCON, STAT_OFF + 678), 101ull, term_ctr(CID_SCON, STAT_OFF + 680), 116ull, term_ctr(CID_SCON, STAT_OFF + 682), 99ull, term_ctr(CID_SCON, STAT_OFF + 684), 101ull, term_ctr(CID_SCON, STAT_OFF + 686), 112ull, term_ctr(CID_SCON, STAT_OFF + 688), 120ull, term_ctr(CID_SCON, STAT_OFF + 690), 101ull, term_ctr(CID_SCON, STAT_OFF + 692), 110ull, term_ctr(CID_SCON, STAT_OFF + 694), 117ull, term_ctr(CID_SCON, STAT_OFF + 696), term_pak(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DECLAREDKEY, 1ull), term_pak(CID_NIL, 0), 109ull, term_ctr(CID_SCON, STAT_OFF + 590), 101ull, term_ctr(CID_SCON, STAT_OFF + 702), 116ull, term_ctr(CID_SCON, STAT_OFF + 704), 115ull, term_ctr(CID_SCON, STAT_OFF + 706), 121ull, term_ctr(CID_SCON, STAT_OFF + 708), 115ull, term_ctr(CID_SCON, STAT_OFF + 710), 45ull, term_ctr(CID_SCON, STAT_OFF + 712), 100ull, term_ctr(CID_SCON, STAT_OFF + 714), 101ull, term_ctr(CID_SCON, STAT_OFF + 716), 116ull, term_ctr(CID_SCON, STAT_OFF + 718), 99ull, term_ctr(CID_SCON, STAT_OFF + 720), 101ull, term_ctr(CID_SCON, STAT_OFF + 722), 112ull, term_ctr(CID_SCON, STAT_OFF + 724), 120ull, term_ctr(CID_SCON, STAT_OFF + 726), 101ull, term_ctr(CID_SCON, STAT_OFF + 728), 110ull, term_ctr(CID_SCON, STAT_OFF + 730), 117ull, term_ctr(CID_SCON, STAT_OFF + 732), 100ull, term_ctr(CID_SCON, STAT_OFF + 590), 108ull, term_ctr(CID_SCON, STAT_OFF + 736), 114ull, term_ctr(CID_SCON, STAT_OFF + 738), 111ull, term_ctr(CID_SCON, STAT_OFF + 740), 119ull, term_ctr(CID_SCON, STAT_OFF + 742), 45ull, term_ctr(CID_SCON, STAT_OFF + 744), 100ull, term_ctr(CID_SCON, STAT_OFF + 746), 101ull, term_ctr(CID_SCON, STAT_OFF + 748), 116ull, term_ctr(CID_SCON, STAT_OFF + 750), 99ull, term_ctr(CID_SCON, STAT_OFF + 752), 101ull, term_ctr(CID_SCON, STAT_OFF + 754), 112ull, term_ctr(CID_SCON, STAT_OFF + 756), 120ull, term_ctr(CID_SCON, STAT_OFF + 758), 101ull, term_ctr(CID_SCON, STAT_OFF + 760), 110ull, term_ctr(CID_SCON, STAT_OFF + 762), 117ull, term_ctr(CID_SCON, STAT_OFF + 764) };

INLINE Term spin_0(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _items_1 = r0;
  Term _acc_1 = r1;
  WL_SPIN
    if (term_aux(_items_1) == CID_NIL) {
      _v_1 = _acc_1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_1);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _items_1 = r0;
      _acc_1 = r1;
      WL_AGAIN(spin_0);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _world_11 = r0;
  u32 _world_12 = r1;
  u32 _world_13 = r2;
  Term _world_14 = r3;
  u32 _world_15 = r4;
  Term _world_16 = r5;
  Term _world_17 = r6;
  Term _world_18 = r7;
  Term _world_19 = r8;
  u32 _world_20 = r9;
  u32 _world_21 = r10;
  Term _input_0 = r11;
  WL_SPIN
    _v_26 = 0;
    _v_27 = _world_11;
    _v_28 = _world_12;
    _v_29 = _world_13;
    _v_30 = _world_14;
    _v_31 = _world_15;
    _v_32 = _world_16;
    _v_33 = _world_17;
    _v_34 = _world_18;
    _v_35 = _world_19;
    _v_36 = _world_20;
    _v_37 = _world_21;
    _v_38 = _input_0;
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h17 = r17;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  Term _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  u32 _v_74 = 0;
  Term _v_75 = 0;
  Term _v_76 = 0;
  u32 _registry_5 = r0;
  u32 _registry_6 = r1;
  Term _registry_7 = r2;
  Term _registry_8 = r3;
  u32 _registry_9 = r4;
  u32 _outcome_0 = r5;
  u32 _outcome_1 = r6;
  u32 _outcome_2 = r7;
  u32 _outcome_3 = r8;
  Term _outcome_4 = r9;
  u32 _outcome_5 = r10;
  Term _outcome_6 = r11;
  Term _outcome_7 = r12;
  Term _outcome_8 = r13;
  Term _outcome_9 = r14;
  u32 _outcome_10 = r15;
  u32 _outcome_11 = r16;
  Term _outcome_12 = r17;
  WL_SPIN
    _v_58 = 0;
    _v_59 = _registry_5;
    _v_60 = _registry_6;
    _v_61 = _registry_7;
    _v_62 = _registry_8;
    _v_63 = _registry_9;
    _v_64 = _outcome_0;
    _v_65 = _outcome_1;
    _v_66 = _outcome_2;
    _v_67 = _outcome_3;
    _v_68 = _outcome_4;
    _v_69 = _outcome_5;
    _v_70 = _outcome_6;
    _v_71 = _outcome_7;
    _v_72 = _outcome_8;
    _v_73 = _outcome_9;
    _v_74 = _outcome_10;
    _v_75 = _outcome_11;
    _v_76 = _outcome_12;
  break;
  }
  o[0] = _v_58;
  o[1] = _v_59;
  o[2] = _v_60;
  o[3] = _v_61;
  o[4] = _v_62;
  o[5] = _v_63;
  o[6] = _v_64;
  o[7] = _v_65;
  o[8] = _v_66;
  o[9] = _v_67;
  o[10] = _v_68;
  o[11] = _v_69;
  o[12] = _v_70;
  o[13] = _v_71;
  o[14] = _v_72;
  o[15] = _v_73;
  o[16] = _v_74;
  o[17] = _v_75;
  o[18] = _v_76;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_1 = 0;
  u32 _found_0 = r0;
  Term _ids_2 = r1;
  u32 _id_2 = r2;
  WL_SPIN
    if (_found_0 == 1) {
      _v_1 = _ids_2;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _id_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, _ids_2);
      _v_1 = term_ctr(CID_CON, _nd_0);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, Term r3, Term r4, Term r5, u64 q5, Term r6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h5 = r5;
  Term _v_4 = 0;
  Term _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _queue_4 = r0;
  Term _queue_5 = r1;
  Term _queue_6 = r2;
  Term _queue_7 = r3;
  Term _tick_1 = r4;
  Term _items_1 = r5;
  Term _count_1 = r6;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, _tick_1);
    e.mem[_nd_0 + 1] = rfc_seal(e, _count_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _items_1);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_QUEUE_BATCH, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _queue_5);
    _v_4 = _queue_4;
    _v_5 = term_ctr(CID_CON, _nd_1);
    _v_6 = nat_chk(e, _queue_6 + _count_1);
    _v_7 = _queue_7;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_2 = 0;
  u32 _visible_0 = r0;
  Term _items_0 = r1;
  Term _acc_1 = r2;
  WL_SPIN
    if (_visible_0 == 0) {
      term_sink(e, _items_0);
      _v_2 = _acc_1;
    } else {
      Term _v_3 = 0;
      Term _o_0[1];
      if (spin_0(e, _o_0, _items_0, _items_0 == h1 ? q1 : blk_loc(e.mem, _items_0), _acc_1, _acc_1 == h2 ? q2 : blk_loc(e.mem, _acc_1)) == 0) {
        return 0;
      }
      _v_3 = _o_0[0];
      _v_2 = _v_3;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h17 = r17;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _allowed_0 = r0;
  u32 _registry_5 = r1;
  u32 _registry_6 = r2;
  Term _registry_7 = r3;
  Term _registry_8 = r4;
  u32 _registry_9 = r5;
  u32 _world_0 = r6;
  u32 _world_1 = r7;
  u32 _world_2 = r8;
  Term _world_3 = r9;
  u32 _world_4 = r10;
  Term _world_5 = r11;
  Term _world_6 = r12;
  Term _world_7 = r13;
  Term _world_8 = r14;
  u32 _world_9 = r15;
  u32 _world_10 = r16;
  Term _args_1 = r17;
  WL_SPIN
    if (_allowed_0 == 0) {
      _v_19 = 1;
      _v_20 = _registry_5;
      _v_21 = _registry_6;
      _v_22 = _registry_7;
      _v_23 = _registry_8;
      _v_24 = _registry_9;
      _v_25 = _world_0;
      _v_26 = _world_1;
      _v_27 = _world_2;
      _v_28 = _world_3;
      _v_29 = _world_4;
      _v_30 = _world_5;
      _v_31 = _world_6;
      _v_32 = _world_7;
      _v_33 = _world_8;
      _v_34 = _world_9;
      _v_35 = _world_10;
      _v_36 = _args_1;
      _v_37 = 0;
    } else {
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      u32 _v_40 = 0;
      u32 _v_41 = 0;
      Term _v_42 = 0;
      u32 _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      Term _v_47 = 0;
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      Term _v_50 = 0;
      u32 _v_51 = 0;
      u32 _v_52 = 0;
      u32 _v_53 = 0;
      u32 _v_54 = 0;
      Term _v_55 = 0;
      u32 _v_56 = 0;
      Term _v_57 = 0;
      Term _v_58 = 0;
      Term _v_59 = 0;
      Term _v_60 = 0;
      u32 _v_61 = 0;
      u32 _v_62 = 0;
      Term _v_63 = 0;
      Term _o_0[13];
      if (spin_1(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h9 ? q9 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h12 ? q12 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h13 ? q13 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h14 ? q14 : blk_loc(e.mem, _world_8), _world_9, _world_10, _args_1, _args_1 == h17 ? q17 : blk_loc(e.mem, _args_1)) == 0) {
        return 0;
      }
      _v_51 = _o_0[0];
      _v_52 = _o_0[1];
      _v_53 = _o_0[2];
      _v_54 = _o_0[3];
      _v_55 = _o_0[4];
      _v_56 = _o_0[5];
      _v_57 = _o_0[6];
      _v_58 = _o_0[7];
      _v_59 = _o_0[8];
      _v_60 = _o_0[9];
      _v_61 = _o_0[10];
      _v_62 = _o_0[11];
      _v_63 = _o_0[12];
      _v_38 = _v_51;
      _v_39 = _v_52;
      _v_40 = _v_53;
      _v_41 = _v_54;
      _v_42 = _v_55;
      _v_43 = _v_56;
      _v_44 = _v_57;
      _v_45 = _v_58;
      _v_46 = _v_59;
      _v_47 = _v_60;
      _v_48 = _v_61;
      _v_49 = _v_62;
      _v_50 = _v_63;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      u32 _v_66 = 0;
      Term _v_67 = 0;
      Term _v_68 = 0;
      u32 _v_69 = 0;
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      Term _v_77 = 0;
      Term _v_78 = 0;
      Term _v_79 = 0;
      u32 _v_80 = 0;
      Term _v_81 = 0;
      Term _v_82 = 0;
      Term _o_1[19];
      if (spin_2(e, _o_1, _registry_5, _registry_6, _registry_7, _registry_7 == h3 ? q3 : blk_loc(e.mem, _registry_7), _registry_8, _registry_8 == h4 ? q4 : blk_loc(e.mem, _registry_8), _registry_9, _v_38, _v_39, _v_40, _v_41, _v_42, _v_42 == h17 ? q17 : _v_42 == h14 ? q14 : _v_42 == h13 ? q13 : _v_42 == h12 ? q12 : _v_42 == h9 ? q9 : _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : blk_loc(e.mem, _v_42), _v_43, _v_44, _v_45, _v_45 == h17 ? q17 : _v_45 == h14 ? q14 : _v_45 == h13 ? q13 : _v_45 == h12 ? q12 : _v_45 == h9 ? q9 : _v_45 == h4 ? q4 : _v_45 == h3 ? q3 : blk_loc(e.mem, _v_45), _v_46, _v_46 == h17 ? q17 : _v_46 == h14 ? q14 : _v_46 == h13 ? q13 : _v_46 == h12 ? q12 : _v_46 == h9 ? q9 : _v_46 == h4 ? q4 : _v_46 == h3 ? q3 : blk_loc(e.mem, _v_46), _v_47, _v_47 == h17 ? q17 : _v_47 == h14 ? q14 : _v_47 == h13 ? q13 : _v_47 == h12 ? q12 : _v_47 == h9 ? q9 : _v_47 == h4 ? q4 : _v_47 == h3 ? q3 : blk_loc(e.mem, _v_47), _v_48, _v_49, _v_50, _v_50 == h17 ? q17 : _v_50 == h14 ? q14 : _v_50 == h13 ? q13 : _v_50 == h12 ? q12 : _v_50 == h9 ? q9 : _v_50 == h4 ? q4 : _v_50 == h3 ? q3 : blk_loc(e.mem, _v_50)) == 0) {
        return 0;
      }
      _v_64 = _o_1[0];
      _v_65 = _o_1[1];
      _v_66 = _o_1[2];
      _v_67 = _o_1[3];
      _v_68 = _o_1[4];
      _v_69 = _o_1[5];
      _v_70 = _o_1[6];
      _v_71 = _o_1[7];
      _v_72 = _o_1[8];
      _v_73 = _o_1[9];
      _v_74 = _o_1[10];
      _v_75 = _o_1[11];
      _v_76 = _o_1[12];
      _v_77 = _o_1[13];
      _v_78 = _o_1[14];
      _v_79 = _o_1[15];
      _v_80 = _o_1[16];
      _v_81 = _o_1[17];
      _v_82 = _o_1[18];
      _v_19 = _v_64;
      _v_20 = _v_65;
      _v_21 = _v_66;
      _v_22 = _v_67;
      _v_23 = _v_68;
      _v_24 = _v_69;
      _v_25 = _v_70;
      _v_26 = _v_71;
      _v_27 = _v_72;
      _v_28 = _v_73;
      _v_29 = _v_74;
      _v_30 = _v_75;
      _v_31 = _v_76;
      _v_32 = _v_77;
      _v_33 = _v_78;
      _v_34 = _v_79;
      _v_35 = _v_80;
      _v_36 = _v_81;
      _v_37 = _v_82;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_3 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    _v_3 = U32_BIN(_a_1, ==, _b_1);
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_5 = 0;
  u32 _a_2 = r0;
  u32 _b_2 = r1;
  WL_SPIN
    if (_a_2 == 0) {
      _v_5 = 0;
    } else {
      _v_5 = _b_2;
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_4 = 0;
  Term _a_1 = r0;
  Term _b_1 = r1;
  u32 _same_0 = r2;
  WL_SPIN
    if (term_aux(_a_1) == CID_SNIL) {
      if (term_aux(_b_1) == CID_SNIL) {
        _v_4 = _same_0;
      } else {
        u64 _sp_3 = term_peek(e.mem, _b_1);
        u32 _f_8 = e.mem[_sp_3 + 0];
        Term _f_9 = e.mem[_sp_3 + 1];
        _v_4 = 0;
      }
    } else {
      u64 _sp_4 = term_peek(e.mem, _a_1);
      u32 _f_10 = e.mem[_sp_4 + 0];
      Term _f_11 = e.mem[_sp_4 + 1];
      if (term_aux(_b_1) == CID_SNIL) {
        _v_4 = 0;
      } else {
        u64 _sp_5 = term_peek(e.mem, _b_1);
        u32 _f_12 = e.mem[_sp_5 + 0];
        Term _f_13 = e.mem[_sp_5 + 1];
        u32 _v_5 = 0;
        u32 _v_6 = 0;
        u32 _v_7 = 0;
        Term _o_0[1];
        if (spin_7(e, _o_0, _f_10, _f_12) == 0) {
          return 0;
        }
        _v_7 = _o_0[0];
        _v_6 = _v_7;
        u32 _v_8 = 0;
        Term _o_1[1];
        if (spin_8(e, _o_1, _same_0, _v_6) == 0) {
          return 0;
        }
        _v_8 = _o_1[0];
        _v_5 = _v_8;
        r0 = _f_11;
        r1 = _f_13;
        r2 = _v_5;
        _a_1 = r0;
        _b_1 = r1;
        _same_0 = r2;
        WL_AGAIN(spin_10);
      }
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_2 = 0;
  Term _a_0 = r0;
  Term _b_0 = r1;
  WL_SPIN
    u32 _v_3 = 0;
    Term _o_2[1];
    if (spin_10(e, _o_2, _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), _b_0, _b_0 == h1 ? q1 : blk_loc(e.mem, _b_0), 1) == 0) {
      return 0;
    }
    _v_3 = _o_2[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u64 q0, Term r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_14 = 0;
  Term _items_2 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_items_2) == CID_NIL) {
      _v_14 = _acc_0;
    } else {
      u64 _sp_0 = term_peek(e.mem, _items_2);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      r0 = _f_1;
      r1 = nat_chk(e, 1ull + _acc_0);
      _items_2 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_12);
    }
  break;
  }
  o[0] = _v_14;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, Term r4, Term r5, Term r6, u64 q6, Term r7) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h6 = r6;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _nonempty_0 = r0;
  Term _queue_8 = r1;
  Term _queue_9 = r2;
  Term _queue_10 = r3;
  Term _queue_11 = r4;
  Term _tick_2 = r5;
  Term _items_3 = r6;
  Term _count_0 = r7;
  WL_SPIN
    if (_nonempty_0 == 0) {
      term_sink(e, _items_3);
      _v_21 = _queue_8;
      _v_22 = _queue_9;
      _v_23 = _queue_10;
      _v_24 = _queue_11;
    } else {
      Term _v_25 = 0;
      Term _v_26 = 0;
      Term _v_27 = 0;
      Term _v_28 = 0;
      Term _o_2[4];
      if (spin_4(e, _o_2, _queue_8, _queue_8 == h1 ? q1 : blk_loc(e.mem, _queue_8), _queue_9, _queue_9 == h2 ? q2 : blk_loc(e.mem, _queue_9), _queue_10, _queue_11, _tick_2, _items_3, _items_3 == h6 ? q6 : blk_loc(e.mem, _items_3), _count_0) == 0) {
        return 0;
      }
      _v_25 = _o_2[0];
      _v_26 = _o_2[1];
      _v_27 = _o_2[2];
      _v_28 = _o_2[3];
      _v_21 = _v_25;
      _v_22 = _v_26;
      _v_23 = _v_27;
      _v_24 = _v_28;
    }
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  o[2] = _v_23;
  o[3] = _v_24;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, Term r3, Term r4, Term r5, u64 q5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h5 = r5;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _queue_4 = r0;
  Term _queue_5 = r1;
  Term _queue_6 = r2;
  Term _queue_7 = r3;
  Term _tick_1 = r4;
  Term _items_1 = r5;
  WL_SPIN
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _o_0[1];
    if (spin_12(e, _o_0, _items_1, _items_1 == h5 ? q5 : blk_loc(e.mem, _items_1), 0) == 0) {
      return 0;
    }
    _v_13 = _o_0[0];
    _v_12 = _v_13;
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _o_1[1];
    if (spin_12(e, _o_1, _items_1, _items_1 == h5 ? q5 : blk_loc(e.mem, _items_1), 0) == 0) {
      return 0;
    }
    _v_16 = _o_1[0];
    _v_15 = _v_16;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _o_3[4];
    if (spin_13(e, _o_3, (0 < _v_12), _queue_4, _queue_4 == h0 ? q0 : blk_loc(e.mem, _queue_4), _queue_5, _queue_5 == h1 ? q1 : blk_loc(e.mem, _queue_5), _queue_6, _queue_7, _tick_1, _items_1, _items_1 == h5 ? q5 : blk_loc(e.mem, _items_1), _v_15) == 0) {
      return 0;
    }
    _v_17 = _o_3[0];
    _v_18 = _o_3[1];
    _v_19 = _o_3[2];
    _v_20 = _o_3[3];
    _v_8 = _v_17;
    _v_9 = _v_18;
    _v_10 = _v_19;
    _v_11 = _v_20;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_5 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_5 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_15);
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_3 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_4 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_15(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_3 = _v_4;
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, u64 q0, Term r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term _v_8 = 0;
  Term _batches_0 = r0;
  Term _cursor_1 = r1;
  Term _acc_1 = r2;
  WL_SPIN
    if (term_aux(_batches_0) == CID_NIL) {
      _v_8 = _acc_1;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _batches_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _fb_2[3];
      u64 _sp_2 = ctr_take(e, _f_2, 3, _fb_2);
      Term _f_4 = _fb_2[0];
      Term _f_5 = _fb_2[1];
      Term _f_6 = _fb_2[2];
      spare_free(e, cls_fit(3), _sp_2);
      Term _v_9 = 0;
      Term _v_10 = 0;
      Term _o_2[1];
      if (spin_5(e, _o_2, (_cursor_1 < _f_4), _f_6, _f_6 == h2 ? q2 : _f_6 == h0 ? q0 : blk_loc(e.mem, _f_6), _acc_1, _acc_1 == h2 ? q2 : blk_loc(e.mem, _acc_1)) == 0) {
        return 0;
      }
      _v_10 = _o_2[0];
      _v_9 = _v_10;
      spare_free(e, cls_fit(2), _sp_1);
      r0 = _f_3;
      r1 = _cursor_1;
      r2 = _v_9;
      _batches_0 = r0;
      _cursor_1 = r1;
      _acc_1 = r2;
      WL_AGAIN(spin_16);
    }
  break;
  }
  o[0] = _v_8;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_15 = 0;
  Term _xs_3 = r0;
  Term _acc_2 = r1;
  WL_SPIN
    if (term_aux(_xs_3) == CID_NIL) {
      _v_15 = _acc_2;
    } else {
      Term _fb_3[2];
      u64 _sp_3 = ctr_take(e, _xs_3, 2, _fb_3);
      Term _f_7 = _fb_3[0];
      Term _f_8 = _fb_3[1];
      u64 _nd_1 = _sp_3 >= HEAP_OFF ? _sp_3 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _f_7);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_2);
      r0 = _f_8;
      r1 = term_ctr(CID_CON, _nd_1);
      _xs_3 = r0;
      _acc_2 = r1;
      WL_AGAIN(spin_18);
    }
  break;
  }
  o[0] = _v_15;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_13 = 0;
  Term _xs_2 = r0;
  WL_SPIN
    Term _v_14 = 0;
    Term _o_5[1];
    Term _a_2 = term_pak(CID_NIL, 0);
    if (spin_18(e, _o_5, _xs_2, _xs_2 == h0 ? q0 : blk_loc(e.mem, _xs_2), _a_2, _a_2 == h0 ? q0 : blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_14 = _o_5[0];
    _v_13 = _v_14;
  break;
  }
  o[0] = _v_13;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h17 = r17;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _registry_10 = r0;
  u32 _registry_11 = r1;
  Term _registry_12 = r2;
  Term _registry_13 = r3;
  u32 _registry_14 = r4;
  u32 _checked_0 = r5;
  u32 _checked_1 = r6;
  u32 _checked_2 = r7;
  Term _checked_3 = r8;
  u32 _checked_4 = r9;
  Term _checked_5 = r10;
  Term _checked_6 = r11;
  Term _checked_7 = r12;
  Term _checked_8 = r13;
  u32 _checked_9 = r14;
  u32 _checked_10 = r15;
  u32 _checked_11 = r16;
  Term _args_2 = r17;
  WL_SPIN
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    u32 _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _o_0[19];
    if (spin_6(e, _o_0, _checked_11, _registry_10, _registry_11, _registry_12, _registry_12 == h2 ? q2 : blk_loc(e.mem, _registry_12), _registry_13, _registry_13 == h3 ? q3 : blk_loc(e.mem, _registry_13), _registry_14, _checked_0, _checked_1, _checked_2, _checked_3, _checked_3 == h8 ? q8 : blk_loc(e.mem, _checked_3), _checked_4, _checked_5, _checked_6, _checked_6 == h11 ? q11 : blk_loc(e.mem, _checked_6), _checked_7, _checked_7 == h12 ? q12 : blk_loc(e.mem, _checked_7), _checked_8, _checked_8 == h13 ? q13 : blk_loc(e.mem, _checked_8), _checked_9, _checked_10, _args_2, _args_2 == h17 ? q17 : blk_loc(e.mem, _args_2)) == 0) {
      return 0;
    }
    _v_38 = _o_0[0];
    _v_39 = _o_0[1];
    _v_40 = _o_0[2];
    _v_41 = _o_0[3];
    _v_42 = _o_0[4];
    _v_43 = _o_0[5];
    _v_44 = _o_0[6];
    _v_45 = _o_0[7];
    _v_46 = _o_0[8];
    _v_47 = _o_0[9];
    _v_48 = _o_0[10];
    _v_49 = _o_0[11];
    _v_50 = _o_0[12];
    _v_51 = _o_0[13];
    _v_52 = _o_0[14];
    _v_53 = _o_0[15];
    _v_54 = _o_0[16];
    _v_55 = _o_0[17];
    _v_56 = _o_0[18];
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _v_55;
    _v_37 = _v_56;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _left_0 = r0;
  u32 _right_0 = r1;
  WL_SPIN
    _v_2 = U32_BIN(_left_0, ==, _right_0);
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _front_0 = r0;
  Term _back_0 = r1;
  Term _cursor_1 = r2;
  WL_SPIN
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_0[1];
    if (spin_14(e, _o_0, _back_0, _back_0 == h1 ? q1 : blk_loc(e.mem, _back_0)) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_3 = _v_4;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _o_1[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_16(e, _o_1, _front_0, _front_0 == h0 ? q0 : blk_loc(e.mem, _front_0), _cursor_1, _a_0, _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_6 = _o_1[0];
    _v_5 = _v_6;
    Term _v_7 = 0;
    Term _o_2[1];
    if (spin_16(e, _o_2, _v_3, _v_3 == h1 ? q1 : _v_3 == h0 ? q0 : blk_loc(e.mem, _v_3), _cursor_1, _v_5, _v_5 == h1 ? q1 : _v_5 == h0 ? q0 : blk_loc(e.mem, _v_5)) == 0) {
      return 0;
    }
    _v_7 = _o_2[0];
    _v_2 = _v_7;
    Term _v_8 = 0;
    Term _o_3[1];
    if (spin_17(e, _o_3, _v_2, _v_2 == h1 ? q1 : _v_2 == h0 ? q0 : blk_loc(e.mem, _v_2)) == 0) {
      return 0;
    }
    _v_8 = _o_3[0];
    _v_1 = _v_8;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, u32 r18) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h15 = r15;
  Term h16 = r16;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _outcome_0 = r0;
  u32 _outcome_1 = r1;
  u32 _outcome_2 = r2;
  u32 _outcome_3 = r3;
  Term _outcome_4 = r4;
  u32 _outcome_5 = r5;
  Term _outcome_6 = r6;
  Term _outcome_7 = r7;
  Term _outcome_8 = r8;
  Term _outcome_9 = r9;
  u32 _outcome_10 = r10;
  u32 _outcome_11 = r11;
  Term _outcome_12 = r12;
  u32 _registry_5 = r13;
  u32 _registry_6 = r14;
  Term _registry_7 = r15;
  Term _registry_8 = r16;
  u32 _registry_9 = r17;
  u32 _nextCursor_0 = r18;
  WL_SPIN
    if (_outcome_0 == 1) {
      _v_19 = 0;
      _v_20 = _registry_5;
      _v_21 = _registry_6;
      _v_22 = _registry_7;
      _v_23 = _registry_8;
      _v_24 = _registry_9;
      _v_25 = 1;
      _v_26 = _outcome_1;
      _v_27 = _outcome_2;
      _v_28 = _outcome_3;
      _v_29 = _outcome_4;
      _v_30 = _outcome_5;
      _v_31 = _outcome_6;
      _v_32 = _outcome_7;
      _v_33 = _outcome_8;
      _v_34 = _outcome_9;
      _v_35 = _outcome_10;
      _v_36 = _outcome_11;
      _v_37 = 0;
    } else {
      _v_19 = 0;
      _v_20 = _registry_5;
      _v_21 = _registry_6;
      _v_22 = _registry_7;
      _v_23 = _registry_8;
      _v_24 = _nextCursor_0;
      _v_25 = 0;
      _v_26 = _outcome_1;
      _v_27 = _outcome_2;
      _v_28 = _outcome_3;
      _v_29 = _outcome_4;
      _v_30 = _outcome_5;
      _v_31 = _outcome_6;
      _v_32 = _outcome_7;
      _v_33 = _outcome_8;
      _v_34 = _outcome_9;
      _v_35 = _outcome_10;
      _v_36 = _outcome_11;
      _v_37 = _outcome_12;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_2 = 1;
    } else {
      _v_2 = 0;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term _v_4 = 0;
  u32 _keep_0 = r0;
  u32 _meta_0 = r1;
  Term _meta_1 = r2;
  Term _meta_2 = r3;
  Term _rest_0 = r4;
  WL_SPIN
    if (_keep_0 == 1) {
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _meta_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _meta_1);
      e.mem[_nd_0 + 2] = rfc_seal(e, _meta_2);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_WORLD_REGISTRATIONMETA, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _rest_0);
      _v_4 = term_ctr(CID_CON, _nd_1);
    } else {
      term_sink(e, _meta_1);
      term_sink(e, _meta_2);
      _v_4 = _rest_0;
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, Term r3, Term r4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_2 = 0;
  Term _queue_4 = r0;
  Term _queue_5 = r1;
  Term _queue_6 = r2;
  Term _queue_7 = r3;
  Term _cursor_0 = r4;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_0[1];
    if (spin_21(e, _o_0, _queue_4, _queue_4 == h0 ? q0 : blk_loc(e.mem, _queue_4), _queue_5, _queue_5 == h1 ? q1 : blk_loc(e.mem, _queue_5), _cursor_0) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  WL_SPIN
    _v_24 = _world_0;
    _v_25 = _world_1;
    _v_26 = _world_2;
    _v_27 = _world_3;
    _v_28 = _world_4;
    _v_29 = _world_5;
    _v_30 = _world_6;
    _v_31 = _world_7;
    _v_32 = _world_8;
    _v_33 = _world_9;
    _v_34 = _world_10;
    _v_35 = _world_10;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  Term _v_65 = 0;
  Term _v_66 = 0;
  Term _v_67 = 0;
  Term _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  u32 _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  u32 _registry_5 = r0;
  u32 _registry_6 = r1;
  Term _registry_7 = r2;
  Term _registry_8 = r3;
  u32 _registry_9 = r4;
  Term _output_0 = r5;
  u32 _observed_0 = r6;
  u32 _observed_1 = r7;
  u32 _observed_2 = r8;
  Term _observed_3 = r9;
  u32 _observed_4 = r10;
  Term _observed_5 = r11;
  Term _observed_6 = r12;
  Term _observed_7 = r13;
  Term _observed_8 = r14;
  u32 _observed_9 = r15;
  u32 _observed_10 = r16;
  u32 _observed_11 = r17;
  WL_SPIN
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    Term _v_85 = 0;
    Term _v_86 = 0;
    Term _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    u32 _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _o_1[19];
    if (spin_22(e, _o_1, 0, _observed_0, _observed_1, _observed_2, _observed_3, _observed_3 == h9 ? q9 : blk_loc(e.mem, _observed_3), _observed_4, _observed_5, _observed_6, _observed_6 == h12 ? q12 : blk_loc(e.mem, _observed_6), _observed_7, _observed_7 == h13 ? q13 : blk_loc(e.mem, _observed_7), _observed_8, _observed_8 == h14 ? q14 : blk_loc(e.mem, _observed_8), _observed_9, _observed_10, _output_0, _output_0 == h5 ? q5 : blk_loc(e.mem, _output_0), _registry_5, _registry_6, _registry_7, _registry_7 == h2 ? q2 : blk_loc(e.mem, _registry_7), _registry_8, _registry_8 == h3 ? q3 : blk_loc(e.mem, _registry_8), _registry_9, _observed_11) == 0) {
      return 0;
    }
    _v_74 = _o_1[0];
    _v_75 = _o_1[1];
    _v_76 = _o_1[2];
    _v_77 = _o_1[3];
    _v_78 = _o_1[4];
    _v_79 = _o_1[5];
    _v_80 = _o_1[6];
    _v_81 = _o_1[7];
    _v_82 = _o_1[8];
    _v_83 = _o_1[9];
    _v_84 = _o_1[10];
    _v_85 = _o_1[11];
    _v_86 = _o_1[12];
    _v_87 = _o_1[13];
    _v_88 = _o_1[14];
    _v_89 = _o_1[15];
    _v_90 = _o_1[16];
    _v_91 = _o_1[17];
    _v_92 = _o_1[18];
    _v_55 = _v_74;
    _v_56 = _v_75;
    _v_57 = _v_76;
    _v_58 = _v_77;
    _v_59 = _v_78;
    _v_60 = _v_79;
    _v_61 = _v_80;
    _v_62 = _v_81;
    _v_63 = _v_82;
    _v_64 = _v_83;
    _v_65 = _v_84;
    _v_66 = _v_85;
    _v_67 = _v_86;
    _v_68 = _v_87;
    _v_69 = _v_88;
    _v_70 = _v_89;
    _v_71 = _v_90;
    _v_72 = _v_91;
    _v_73 = _v_92;
  break;
  }
  o[0] = _v_55;
  o[1] = _v_56;
  o[2] = _v_57;
  o[3] = _v_58;
  o[4] = _v_59;
  o[5] = _v_60;
  o[6] = _v_61;
  o[7] = _v_62;
  o[8] = _v_63;
  o[9] = _v_64;
  o[10] = _v_65;
  o[11] = _v_66;
  o[12] = _v_67;
  o[13] = _v_68;
  o[14] = _v_69;
  o[15] = _v_70;
  o[16] = _v_71;
  o[17] = _v_72;
  o[18] = _v_73;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, u32 r0, u32 r1, Term r2, Term r3, Term r4, u64 q4, u32 r5, Term r6) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term _v_1 = 0;
  u32 _position_0 = r0;
  u32 _position_1 = r1;
  Term _position_2 = r2;
  Term _position_3 = r3;
  Term _positions_2 = r4;
  u32 _id_2 = r5;
  Term _registered_2 = r6;
  WL_SPIN
    if (_position_0 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _id_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, 0);
      e.mem[_nd_0 + 2] = rfc_seal(e, _registered_2);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EVENT_RUNTIME_POSITION, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _positions_2);
      _v_1 = term_ctr(CID_CON, _nd_1);
    } else {
      _v_1 = _positions_2;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _qr_0 = r0;
  Term _qr_1 = r1;
  WL_SPIN
    _v_4 = ((u64)(u32)(nat_chk(e, 48ull + _qr_1)));
    _v_5 = _qr_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term _v_1 = 0;
  u32 _found_0 = r0;
  u32 _id_0 = r1;
  Term _rest_0 = r2;
  WL_SPIN
    if (_found_0 == 1) {
      _v_1 = _rest_0;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _id_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _rest_0);
      _v_1 = term_ctr(CID_CON, _nd_0);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, Term r15, Term r16, Term r17, u32 r18) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_80 = 0;
  u32 _v_81 = 0;
  u32 _v_82 = 0;
  Term _v_83 = 0;
  u32 _v_84 = 0;
  Term _v_85 = 0;
  Term _v_86 = 0;
  Term _v_87 = 0;
  Term _v_88 = 0;
  u32 _v_89 = 0;
  u32 _v_90 = 0;
  Term _v_91 = 0;
  Term _v_92 = 0;
  Term _v_93 = 0;
  Term _v_94 = 0;
  Term _v_95 = 0;
  Term _v_96 = 0;
  u32 _v_97 = 0;
  u32 _v_98 = 0;
  u32 _v_99 = 0;
  u32 _available_0 = r0;
  u32 _runtime_18 = r1;
  u32 _runtime_19 = r2;
  u32 _runtime_20 = r3;
  Term _runtime_21 = r4;
  u32 _runtime_22 = r5;
  Term _runtime_23 = r6;
  Term _runtime_24 = r7;
  Term _runtime_25 = r8;
  Term _runtime_26 = r9;
  u32 _runtime_27 = r10;
  u32 _runtime_28 = r11;
  Term _runtime_29 = r12;
  Term _runtime_30 = r13;
  Term _runtime_31 = r14;
  Term _runtime_32 = r15;
  Term _runtime_33 = r16;
  Term _runtime_34 = r17;
  u32 _runtime_35 = r18;
  WL_SPIN
    if (_available_0 == 0) {
      _v_80 = _runtime_18;
      _v_81 = _runtime_19;
      _v_82 = _runtime_20;
      _v_83 = _runtime_21;
      _v_84 = _runtime_22;
      _v_85 = _runtime_23;
      _v_86 = _runtime_24;
      _v_87 = _runtime_25;
      _v_88 = _runtime_26;
      _v_89 = _runtime_27;
      _v_90 = _runtime_28;
      _v_91 = _runtime_29;
      _v_92 = _runtime_30;
      _v_93 = _runtime_31;
      _v_94 = _runtime_32;
      _v_95 = _runtime_33;
      _v_96 = _runtime_34;
      _v_97 = _runtime_35;
      _v_98 = 0;
      _v_99 = 0;
    } else {
      _v_80 = _runtime_18;
      _v_81 = _runtime_19;
      _v_82 = _runtime_20;
      _v_83 = _runtime_21;
      _v_84 = _runtime_22;
      _v_85 = _runtime_23;
      _v_86 = _runtime_24;
      _v_87 = _runtime_25;
      _v_88 = _runtime_26;
      _v_89 = _runtime_27;
      _v_90 = _runtime_28;
      _v_91 = _runtime_29;
      _v_92 = _runtime_30;
      _v_93 = _runtime_31;
      _v_94 = _runtime_32;
      _v_95 = _runtime_33;
      _v_96 = _runtime_34;
      _v_97 = U32_BIN(_runtime_35, +, 1ull);
      _v_98 = 1;
      _v_99 = _runtime_35;
    }
  break;
  }
  o[0] = _v_80;
  o[1] = _v_81;
  o[2] = _v_82;
  o[3] = _v_83;
  o[4] = _v_84;
  o[5] = _v_85;
  o[6] = _v_86;
  o[7] = _v_87;
  o[8] = _v_88;
  o[9] = _v_89;
  o[10] = _v_90;
  o[11] = _v_91;
  o[12] = _v_92;
  o[13] = _v_93;
  o[14] = _v_94;
  o[15] = _v_95;
  o[16] = _v_96;
  o[17] = _v_97;
  o[18] = _v_98;
  o[19] = _v_99;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, Term r14, Term r15, Term r16, u32 r17) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  u32 _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  u32 _runtime_0 = r0;
  u32 _runtime_1 = r1;
  u32 _runtime_2 = r2;
  Term _runtime_3 = r3;
  u32 _runtime_4 = r4;
  Term _runtime_5 = r5;
  Term _runtime_6 = r6;
  Term _runtime_7 = r7;
  Term _runtime_8 = r8;
  u32 _runtime_9 = r9;
  u32 _runtime_10 = r10;
  Term _runtime_11 = r11;
  Term _runtime_12 = r12;
  Term _runtime_13 = r13;
  Term _runtime_14 = r14;
  Term _runtime_15 = r15;
  Term _runtime_16 = r16;
  u32 _runtime_17 = r17;
  WL_SPIN
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    Term _v_63 = 0;
    u32 _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    Term _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _o_0[20];
    if (spin_32(e, _o_0, U32_BIN(_runtime_17, <, 4294967295ull), _runtime_0, _runtime_1, _runtime_2, _runtime_3, _runtime_3 == h3 ? q3 : blk_loc(e.mem, _runtime_3), _runtime_4, _runtime_5, _runtime_6, _runtime_6 == h6 ? q6 : blk_loc(e.mem, _runtime_6), _runtime_7, _runtime_7 == h7 ? q7 : blk_loc(e.mem, _runtime_7), _runtime_8, _runtime_8 == h8 ? q8 : blk_loc(e.mem, _runtime_8), _runtime_9, _runtime_10, _runtime_11, _runtime_11 == h11 ? q11 : blk_loc(e.mem, _runtime_11), _runtime_12, _runtime_12 == h12 ? q12 : blk_loc(e.mem, _runtime_12), _runtime_13, _runtime_14, _runtime_15, _runtime_16, _runtime_17) == 0) {
      return 0;
    }
    _v_60 = _o_0[0];
    _v_61 = _o_0[1];
    _v_62 = _o_0[2];
    _v_63 = _o_0[3];
    _v_64 = _o_0[4];
    _v_65 = _o_0[5];
    _v_66 = _o_0[6];
    _v_67 = _o_0[7];
    _v_68 = _o_0[8];
    _v_69 = _o_0[9];
    _v_70 = _o_0[10];
    _v_71 = _o_0[11];
    _v_72 = _o_0[12];
    _v_73 = _o_0[13];
    _v_74 = _o_0[14];
    _v_75 = _o_0[15];
    _v_76 = _o_0[16];
    _v_77 = _o_0[17];
    _v_78 = _o_0[18];
    _v_79 = _o_0[19];
    _v_40 = _v_60;
    _v_41 = _v_61;
    _v_42 = _v_62;
    _v_43 = _v_63;
    _v_44 = _v_64;
    _v_45 = _v_65;
    _v_46 = _v_66;
    _v_47 = _v_67;
    _v_48 = _v_68;
    _v_49 = _v_69;
    _v_50 = _v_70;
    _v_51 = _v_71;
    _v_52 = _v_72;
    _v_53 = _v_73;
    _v_54 = _v_74;
    _v_55 = _v_75;
    _v_56 = _v_76;
    _v_57 = _v_77;
    _v_58 = _v_78;
    _v_59 = _v_79;
  break;
  }
  o[0] = _v_40;
  o[1] = _v_41;
  o[2] = _v_42;
  o[3] = _v_43;
  o[4] = _v_44;
  o[5] = _v_45;
  o[6] = _v_46;
  o[7] = _v_47;
  o[8] = _v_48;
  o[9] = _v_49;
  o[10] = _v_50;
  o[11] = _v_51;
  o[12] = _v_52;
  o[13] = _v_53;
  o[14] = _v_54;
  o[15] = _v_55;
  o[16] = _v_56;
  o[17] = _v_57;
  o[18] = _v_58;
  o[19] = _v_59;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  u32 __0 = r0;
  WL_SPIN
    _v_4 = 1;
    _v_5 = 1ull;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _world_22 = r0;
  u32 _world_23 = r1;
  u32 _world_24 = r2;
  Term _world_25 = r3;
  u32 _world_26 = r4;
  Term _world_27 = r5;
  Term _world_28 = r6;
  Term _world_29 = r7;
  Term _world_30 = r8;
  u32 _world_31 = r9;
  u32 _world_32 = r10;
  Term _retained_0 = r11;
  WL_SPIN
    term_sink(e, _world_28);
    _v_24 = _world_22;
    _v_25 = _world_23;
    _v_26 = _world_24;
    _v_27 = _world_25;
    _v_28 = _world_26;
    _v_29 = _world_27;
    _v_30 = _retained_0;
    _v_31 = _world_29;
    _v_32 = _world_30;
    _v_33 = _world_31;
    _v_34 = _world_32;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, Term r4, u32 r5, Term r6, Term r7) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  u32 _v_3 = 0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  u32 _key_1 = r0;
  Term _queue_4 = r1;
  Term _queue_5 = r2;
  Term _queue_6 = r3;
  Term _queue_7 = r4;
  u32 _position_3 = r5;
  Term _position_4 = r6;
  Term _position_5 = r7;
  WL_SPIN
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _o_0[1];
    if (spin_25(e, _o_0, _queue_4, _queue_4 == h1 ? q1 : blk_loc(e.mem, _queue_4), _queue_5, _queue_5 == h2 ? q2 : blk_loc(e.mem, _queue_5), _queue_6, _queue_7, _position_4) == 0) {
      return 0;
    }
    _v_7 = _o_0[0];
    _v_6 = _v_7;
    _v_3 = _key_1;
    _v_4 = _v_6;
    _v_5 = ((_position_4 > _position_5 ? _position_4 : _position_5) < _queue_7);
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _world_11 = r0;
  u32 _world_12 = r1;
  u32 _world_13 = r2;
  Term _world_14 = r3;
  u32 _world_15 = r4;
  Term _world_16 = r5;
  Term _world_17 = r6;
  Term _world_18 = r7;
  Term _world_19 = r8;
  u32 _world_20 = r9;
  u32 _world_21 = r10;
  WL_SPIN
    _v_24 = _world_11;
    _v_25 = _world_12;
    _v_26 = _world_13;
    _v_27 = _world_14;
    _v_28 = _world_15;
    _v_29 = _world_16;
    _v_30 = _world_17;
    _v_31 = _world_18;
    _v_32 = _world_19;
    _v_33 = _world_20;
    _v_34 = _world_21;
    _v_35 = _world_11;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, u32 r16, Term r17, u64 q17) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h17 = r17;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _registry_0 = r0;
  u32 _registry_1 = r1;
  Term _registry_2 = r2;
  Term _registry_3 = r3;
  u32 _registry_4 = r4;
  u32 _outcome_0 = r5;
  u32 _outcome_1 = r6;
  u32 _outcome_2 = r7;
  u32 _outcome_3 = r8;
  Term _outcome_4 = r9;
  u32 _outcome_5 = r10;
  Term _outcome_6 = r11;
  Term _outcome_7 = r12;
  Term _outcome_8 = r13;
  Term _outcome_9 = r14;
  u32 _outcome_10 = r15;
  u32 _outcome_11 = r16;
  Term _outcome_12 = r17;
  WL_SPIN
    if (_outcome_0 == 1) {
      _v_19 = 0;
      _v_20 = _registry_0;
      _v_21 = _registry_1;
      _v_22 = _registry_2;
      _v_23 = _registry_3;
      _v_24 = _registry_4;
      _v_25 = 1;
      _v_26 = _outcome_1;
      _v_27 = _outcome_2;
      _v_28 = _outcome_3;
      _v_29 = _outcome_4;
      _v_30 = _outcome_5;
      _v_31 = _outcome_6;
      _v_32 = _outcome_7;
      _v_33 = _outcome_8;
      _v_34 = _outcome_9;
      _v_35 = _outcome_10;
      _v_36 = _outcome_11;
      _v_37 = 0;
    } else {
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      u32 _v_40 = 0;
      Term _v_41 = 0;
      u32 _v_42 = 0;
      Term _v_43 = 0;
      Term _v_44 = 0;
      Term _v_45 = 0;
      Term _v_46 = 0;
      u32 _v_47 = 0;
      u32 _v_48 = 0;
      u32 _v_49 = 0;
      u32 _v_50 = 0;
      u32 _v_51 = 0;
      u32 _v_52 = 0;
      Term _v_53 = 0;
      u32 _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      Term _v_57 = 0;
      Term _v_58 = 0;
      u32 _v_59 = 0;
      u32 _v_60 = 0;
      u32 _v_61 = 0;
      Term _o_0[12];
      if (spin_26(e, _o_0, _outcome_1, _outcome_2, _outcome_3, _outcome_4, _outcome_4 == h9 ? q9 : blk_loc(e.mem, _outcome_4), _outcome_5, _outcome_6, _outcome_7, _outcome_7 == h12 ? q12 : blk_loc(e.mem, _outcome_7), _outcome_8, _outcome_8 == h13 ? q13 : blk_loc(e.mem, _outcome_8), _outcome_9, _outcome_9 == h14 ? q14 : blk_loc(e.mem, _outcome_9), _outcome_10, _outcome_11) == 0) {
        return 0;
      }
      _v_50 = _o_0[0];
      _v_51 = _o_0[1];
      _v_52 = _o_0[2];
      _v_53 = _o_0[3];
      _v_54 = _o_0[4];
      _v_55 = _o_0[5];
      _v_56 = _o_0[6];
      _v_57 = _o_0[7];
      _v_58 = _o_0[8];
      _v_59 = _o_0[9];
      _v_60 = _o_0[10];
      _v_61 = _o_0[11];
      _v_38 = _v_50;
      _v_39 = _v_51;
      _v_40 = _v_52;
      _v_41 = _v_53;
      _v_42 = _v_54;
      _v_43 = _v_55;
      _v_44 = _v_56;
      _v_45 = _v_57;
      _v_46 = _v_58;
      _v_47 = _v_59;
      _v_48 = _v_60;
      _v_49 = _v_61;
      u32 _v_62 = 0;
      u32 _v_63 = 0;
      u32 _v_64 = 0;
      Term _v_65 = 0;
      Term _v_66 = 0;
      u32 _v_67 = 0;
      u32 _v_68 = 0;
      u32 _v_69 = 0;
      u32 _v_70 = 0;
      Term _v_71 = 0;
      Term _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      Term _v_75 = 0;
      Term _v_76 = 0;
      Term _v_77 = 0;
      u32 _v_78 = 0;
      Term _v_79 = 0;
      Term _v_80 = 0;
      Term _o_1[19];
      if (spin_27(e, _o_1, _registry_0, _registry_1, _registry_2, _registry_2 == h2 ? q2 : blk_loc(e.mem, _registry_2), _registry_3, _registry_3 == h3 ? q3 : blk_loc(e.mem, _registry_3), _registry_4, _outcome_12, _outcome_12 == h17 ? q17 : blk_loc(e.mem, _outcome_12), _v_38, _v_39, _v_40, _v_41, _v_41 == h17 ? q17 : _v_41 == h14 ? q14 : _v_41 == h13 ? q13 : _v_41 == h12 ? q12 : _v_41 == h9 ? q9 : _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : blk_loc(e.mem, _v_41), _v_42, _v_43, _v_44, _v_44 == h17 ? q17 : _v_44 == h14 ? q14 : _v_44 == h13 ? q13 : _v_44 == h12 ? q12 : _v_44 == h9 ? q9 : _v_44 == h3 ? q3 : _v_44 == h2 ? q2 : blk_loc(e.mem, _v_44), _v_45, _v_45 == h17 ? q17 : _v_45 == h14 ? q14 : _v_45 == h13 ? q13 : _v_45 == h12 ? q12 : _v_45 == h9 ? q9 : _v_45 == h3 ? q3 : _v_45 == h2 ? q2 : blk_loc(e.mem, _v_45), _v_46, _v_46 == h17 ? q17 : _v_46 == h14 ? q14 : _v_46 == h13 ? q13 : _v_46 == h12 ? q12 : _v_46 == h9 ? q9 : _v_46 == h3 ? q3 : _v_46 == h2 ? q2 : blk_loc(e.mem, _v_46), _v_47, _v_48, _v_49) == 0) {
        return 0;
      }
      _v_62 = _o_1[0];
      _v_63 = _o_1[1];
      _v_64 = _o_1[2];
      _v_65 = _o_1[3];
      _v_66 = _o_1[4];
      _v_67 = _o_1[5];
      _v_68 = _o_1[6];
      _v_69 = _o_1[7];
      _v_70 = _o_1[8];
      _v_71 = _o_1[9];
      _v_72 = _o_1[10];
      _v_73 = _o_1[11];
      _v_74 = _o_1[12];
      _v_75 = _o_1[13];
      _v_76 = _o_1[14];
      _v_77 = _o_1[15];
      _v_78 = _o_1[16];
      _v_79 = _o_1[17];
      _v_80 = _o_1[18];
      _v_19 = _v_62;
      _v_20 = _v_63;
      _v_21 = _v_64;
      _v_22 = _v_65;
      _v_23 = _v_66;
      _v_24 = _v_67;
      _v_25 = _v_68;
      _v_26 = _v_69;
      _v_27 = _v_70;
      _v_28 = _v_71;
      _v_29 = _v_72;
      _v_30 = _v_73;
      _v_31 = _v_74;
      _v_32 = _v_75;
      _v_33 = _v_76;
      _v_34 = _v_77;
      _v_35 = _v_78;
      _v_36 = _v_79;
      _v_37 = _v_80;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, u32 r13, u32 r14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, Term r18, u64 q18, Term r19, u64 q19, Term r20, Term r21, Term r22, Term r23, u32 r24, Term r25, u64 q25) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h15 = r15;
  Term h16 = r16;
  Term h18 = r18;
  Term h19 = r19;
  Term h25 = r25;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  u32 _id_5 = r0;
  u32 _joined_0 = r1;
  u32 _joined_1 = r2;
  u32 _joined_2 = r3;
  Term _joined_3 = r4;
  u32 _joined_4 = r5;
  Term _joined_5 = r6;
  Term _joined_6 = r7;
  Term _joined_7 = r8;
  Term _joined_8 = r9;
  u32 _joined_9 = r10;
  u32 _joined_10 = r11;
  Term _joined_11 = r12;
  u32 _registry_25 = r13;
  u32 _registry_26 = r14;
  Term _registry_27 = r15;
  Term _registry_28 = r16;
  u32 _registry_29 = r17;
  Term _keys_5 = r18;
  Term _positions_3 = r19;
  Term _tick_0 = r20;
  Term _frameStart_5 = r21;
  Term _boundary_5 = r22;
  Term _capacity_5 = r23;
  u32 _nextReader_5 = r24;
  Term _output_5 = r25;
  WL_SPIN
    _v_27 = _joined_0;
    _v_28 = _joined_1;
    _v_29 = _joined_2;
    _v_30 = _joined_3;
    _v_31 = _joined_4;
    _v_32 = _joined_5;
    _v_33 = _joined_6;
    _v_34 = _joined_7;
    _v_35 = _joined_8;
    _v_36 = _joined_9;
    _v_37 = _joined_10;
    _v_38 = _joined_11;
    _v_39 = _positions_3;
    _v_40 = _tick_0;
    _v_41 = _frameStart_5;
    _v_42 = _boundary_5;
    _v_43 = _capacity_5;
    _v_44 = _nextReader_5;
    _v_45 = _registry_25;
    _v_46 = _registry_26;
    _v_47 = _registry_27;
    _v_48 = _registry_28;
    _v_49 = _registry_29;
    _v_50 = _keys_5;
    _v_51 = _id_5;
    _v_52 = 0;
    _v_53 = _output_5;
  break;
  }
  o[0] = _v_27;
  o[1] = _v_28;
  o[2] = _v_29;
  o[3] = _v_30;
  o[4] = _v_31;
  o[5] = _v_32;
  o[6] = _v_33;
  o[7] = _v_34;
  o[8] = _v_35;
  o[9] = _v_36;
  o[10] = _v_37;
  o[11] = _v_38;
  o[12] = _v_39;
  o[13] = _v_40;
  o[14] = _v_41;
  o[15] = _v_42;
  o[16] = _v_43;
  o[17] = _v_44;
  o[18] = _v_45;
  o[19] = _v_46;
  o[20] = _v_47;
  o[21] = _v_48;
  o[22] = _v_49;
  o[23] = _v_50;
  o[24] = _v_51;
  o[25] = _v_52;
  o[26] = _v_53;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, Term r4, Term r5, u64 q5, Term r6) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term _v_1 = 0;
  u32 _found_0 = r0;
  u32 _dispose_2 = r1;
  u32 _id_2 = r2;
  Term _old_0 = r3;
  Term _registered_0 = r4;
  Term _rest_0 = r5;
  Term _cursor_2 = r6;
  WL_SPIN
    if (_found_0 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _id_2);
      e.mem[_nd_0 + 1] = rfc_seal(e, _old_0);
      e.mem[_nd_0 + 2] = rfc_seal(e, _registered_0);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EVENT_RUNTIME_POSITION, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _rest_0);
      _v_1 = term_ctr(CID_CON, _nd_1);
    } else {
      if (_dispose_2 == 0) {
        u64 _nd_2 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_2 + 0] = rfc_seal(e, _id_2);
        e.mem[_nd_2 + 1] = rfc_seal(e, _cursor_2);
        e.mem[_nd_2 + 2] = rfc_seal(e, _registered_0);
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EVENT_RUNTIME_POSITION, _nd_2));
        e.mem[_nd_3 + 1] = rfc_seal(e, _rest_0);
        _v_1 = term_ctr(CID_CON, _nd_3);
      } else {
        _v_1 = _rest_0;
      }
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, u32 r0, u32 r1, Term r2, Term r3, u32 r4, u32 r5, Term r6, Term r7) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  u32 _found_0 = r0;
  u32 _position_3 = r1;
  Term _position_4 = r2;
  Term _position_5 = r3;
  u32 _fallback_4 = r4;
  u32 _fallback_5 = r5;
  Term _fallback_6 = r6;
  Term _fallback_7 = r7;
  WL_SPIN
    if (_found_0 == 0) {
      _v_4 = _fallback_4;
      _v_5 = _fallback_5;
      _v_6 = _fallback_6;
      _v_7 = _fallback_7;
    } else {
      _v_4 = 1;
      _v_5 = _position_3;
      _v_6 = _position_4;
      _v_7 = _position_5;
    }
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term h9 = r9;
  Term h10 = r10;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h15 = r15;
  Term h17 = r17;
  Term h18 = r18;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  u32 _result_7 = r7;
  u32 _result_8 = r8;
  Term _result_9 = r9;
  Term _result_10 = r10;
  Term _result_11 = r11;
  Term _result_12 = r12;
  Term _result_13 = r13;
  Term _result_14 = r14;
  Term _result_15 = r15;
  u32 _result_16 = r16;
  Term _result_17 = r17;
  Term _result_18 = r18;
  WL_SPIN
    if (_result_0 == 1) {
      _v_19 = 1;
      _v_20 = _result_1;
      _v_21 = _result_2;
      _v_22 = _result_3;
      _v_23 = _result_4;
      _v_24 = _result_5;
      _v_25 = _result_6;
      _v_26 = _result_7;
      _v_27 = _result_8;
      _v_28 = _result_9;
      _v_29 = _result_10;
      _v_30 = _result_11;
      _v_31 = _result_12;
      _v_32 = _result_13;
      _v_33 = _result_14;
      _v_34 = _result_15;
      _v_35 = _result_16;
      _v_36 = _result_17;
      _v_37 = 0;
    } else {
      u32 _v_38 = 0;
      u32 _v_39 = 0;
      u32 _v_40 = 0;
      Term _v_41 = 0;
      Term _v_42 = 0;
      u32 _v_43 = 0;
      u32 _v_44 = 0;
      u32 _v_45 = 0;
      u32 _v_46 = 0;
      Term _v_47 = 0;
      Term _v_48 = 0;
      Term _v_49 = 0;
      Term _v_50 = 0;
      Term _v_51 = 0;
      Term _v_52 = 0;
      Term _v_53 = 0;
      u32 _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      Term _o_0[19];
      if (spin_37(e, _o_0, _result_1, _result_2, _result_3, _result_3 == h3 ? q3 : blk_loc(e.mem, _result_3), _result_4, _result_4 == h4 ? q4 : blk_loc(e.mem, _result_4), _result_5, _result_6, _result_7, _result_8, _result_9, _result_10, _result_10 == h10 ? q10 : blk_loc(e.mem, _result_10), _result_11, _result_12, _result_13, _result_13 == h13 ? q13 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h14 ? q14 : blk_loc(e.mem, _result_14), _result_15, _result_15 == h15 ? q15 : blk_loc(e.mem, _result_15), _result_16, _result_17, _result_18, _result_18 == h18 ? q18 : blk_loc(e.mem, _result_18)) == 0) {
        return 0;
      }
      _v_38 = _o_0[0];
      _v_39 = _o_0[1];
      _v_40 = _o_0[2];
      _v_41 = _o_0[3];
      _v_42 = _o_0[4];
      _v_43 = _o_0[5];
      _v_44 = _o_0[6];
      _v_45 = _o_0[7];
      _v_46 = _o_0[8];
      _v_47 = _o_0[9];
      _v_48 = _o_0[10];
      _v_49 = _o_0[11];
      _v_50 = _o_0[12];
      _v_51 = _o_0[13];
      _v_52 = _o_0[14];
      _v_53 = _o_0[15];
      _v_54 = _o_0[16];
      _v_55 = _o_0[17];
      _v_56 = _o_0[18];
      _v_19 = _v_38;
      _v_20 = _v_39;
      _v_21 = _v_40;
      _v_22 = _v_41;
      _v_23 = _v_42;
      _v_24 = _v_43;
      _v_25 = _v_44;
      _v_26 = _v_45;
      _v_27 = _v_46;
      _v_28 = _v_47;
      _v_29 = _v_48;
      _v_30 = _v_49;
      _v_31 = _v_50;
      _v_32 = _v_51;
      _v_33 = _v_52;
      _v_34 = _v_53;
      _v_35 = _v_54;
      _v_36 = _v_55;
      _v_37 = _v_56;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, u32 r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, u32 r14, u32 r15, u32 r16) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _registry_10 = r0;
  u32 _registry_11 = r1;
  Term _registry_12 = r2;
  Term _registry_13 = r3;
  u32 _registry_14 = r4;
  u32 _observed_0 = r5;
  u32 _observed_1 = r6;
  u32 _observed_2 = r7;
  Term _observed_3 = r8;
  u32 _observed_4 = r9;
  Term _observed_5 = r10;
  Term _observed_6 = r11;
  Term _observed_7 = r12;
  Term _observed_8 = r13;
  u32 _observed_9 = r14;
  u32 _observed_10 = r15;
  u32 _observed_11 = r16;
  WL_SPIN
    if (_observed_11 == 1) {
      term_sink(e, _registry_12);
      term_sink(e, _registry_13);
      _v_17 = 0;
      _v_18 = _observed_0;
      _v_19 = _observed_1;
      _v_20 = _observed_2;
      _v_21 = _observed_3;
      _v_22 = _observed_4;
      _v_23 = _observed_5;
      _v_24 = _observed_6;
      _v_25 = _observed_7;
      _v_26 = _observed_8;
      _v_27 = _observed_9;
      _v_28 = _observed_10;
      _v_29 = 0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
    } else {
      _v_17 = 1;
      _v_18 = _observed_0;
      _v_19 = _observed_1;
      _v_20 = _observed_2;
      _v_21 = _observed_3;
      _v_22 = _observed_4;
      _v_23 = _observed_5;
      _v_24 = _observed_6;
      _v_25 = _observed_7;
      _v_26 = _observed_8;
      _v_27 = _observed_9;
      _v_28 = _observed_10;
      _v_29 = _registry_10;
      _v_30 = _registry_11;
      _v_31 = _registry_12;
      _v_32 = _registry_13;
      _v_33 = _registry_14;
    }
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _value_0 = r0;
  WL_SPIN
    if (_value_0 == 1) {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 152);
    } else {
      _v_2 = term_ctr(CID_SCON, STAT_OFF + 160);
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  u32 _result_0 = r11;
  u32 _result_1 = r12;
  u32 _namespace_1 = r13;
  Term _name_1 = r14;
  Term _access_1 = r15;
  WL_SPIN
    if (_result_0 == 1) {
      term_sink(e, _name_1);
      term_sink(e, _access_1);
      _v_17 = 1;
      _v_18 = _world_0;
      _v_19 = _world_1;
      _v_20 = _world_2;
      _v_21 = _world_3;
      _v_22 = _world_4;
      _v_23 = _world_5;
      _v_24 = _world_6;
      _v_25 = _world_7;
      _v_26 = _world_8;
      _v_27 = _world_9;
      _v_28 = _world_10;
      _v_29 = 0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
    } else {
      _v_17 = 0;
      _v_18 = _world_0;
      _v_19 = _world_1;
      _v_20 = _world_2;
      _v_21 = _world_3;
      _v_22 = _world_4;
      _v_23 = _world_5;
      _v_24 = _world_6;
      _v_25 = _world_7;
      _v_26 = _world_8;
      _v_27 = _world_9;
      _v_28 = _world_10;
      _v_29 = _namespace_1;
      _v_30 = _result_1;
      _v_31 = _name_1;
      _v_32 = _access_1;
      _v_33 = 0ull;
    }
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_3 = 0;
  Term _reversed_0 = r0;
  Term _output_0 = r1;
  WL_SPIN
    if (term_aux(_reversed_0) == CID_NIL) {
      _v_3 = _output_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _reversed_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _output_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _reversed_0 = r0;
      _output_0 = r1;
      WL_AGAIN(spin_46);
    }
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _world_11 = r0;
  u32 _world_12 = r1;
  u32 _world_13 = r2;
  Term _world_14 = r3;
  u32 _world_15 = r4;
  Term _world_16 = r5;
  Term _world_17 = r6;
  Term _world_18 = r7;
  Term _world_19 = r8;
  u32 _world_20 = r9;
  u32 _world_21 = r10;
  WL_SPIN
    _world_17 = term_keep(e, _world_17, 1);
    _v_24 = _world_11;
    _v_25 = _world_12;
    _v_26 = _world_13;
    _v_27 = _world_14;
    _v_28 = _world_15;
    _v_29 = _world_16;
    _v_30 = _world_17;
    _v_31 = _world_18;
    _v_32 = _world_19;
    _v_33 = _world_20;
    _v_34 = _world_21;
    _v_35 = _world_17;
  break;
  }
  o[0] = _v_24;
  o[1] = _v_25;
  o[2] = _v_26;
  o[3] = _v_27;
  o[4] = _v_28;
  o[5] = _v_29;
  o[6] = _v_30;
  o[7] = _v_31;
  o[8] = _v_32;
  o[9] = _v_33;
  o[10] = _v_34;
  o[11] = _v_35;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, u32 r0, Term r1, Term r2, u32 r3, u32 r4, u32 r5, Term r6, Term r7) {
  u32 wpoll = 0;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  u32 _position_0 = r0;
  Term _position_1 = r1;
  Term _position_2 = r2;
  u32 _id_2 = r3;
  u32 _fallback_0 = r4;
  u32 _fallback_1 = r5;
  Term _fallback_2 = r6;
  Term _fallback_3 = r7;
  WL_SPIN
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _o_0[4];
    if (spin_41(e, _o_0, U32_BIN(_position_0, ==, _id_2), _position_0, _position_1, _position_2, _fallback_0, _fallback_1, _fallback_2, _fallback_3) == 0) {
      return 0;
    }
    _v_8 = _o_0[0];
    _v_9 = _o_0[1];
    _v_10 = _o_0[2];
    _v_11 = _o_0[3];
    _v_4 = _v_8;
    _v_5 = _v_9;
    _v_6 = _v_10;
    _v_7 = _v_11;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  u32 _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  u32 _v_64 = 0;
  u32 _available_0 = r0;
  u32 _world_11 = r1;
  u32 _world_12 = r2;
  u32 _world_13 = r3;
  Term _world_14 = r4;
  u32 _world_15 = r5;
  Term _world_16 = r6;
  Term _world_17 = r7;
  Term _world_18 = r8;
  Term _world_19 = r9;
  u32 _world_20 = r10;
  u32 _world_21 = r11;
  Term _name_2 = r12;
  Term _access_2 = r13;
  WL_SPIN
    if (_available_0 == 0) {
      term_sink(e, _name_2);
      term_sink(e, _access_2);
      _v_52 = _world_11;
      _v_53 = _world_12;
      _v_54 = _world_13;
      _v_55 = _world_14;
      _v_56 = _world_15;
      _v_57 = _world_16;
      _v_58 = _world_17;
      _v_59 = _world_18;
      _v_60 = _world_19;
      _v_61 = _world_20;
      _v_62 = _world_21;
      _v_63 = 1;
      _v_64 = 3;
    } else {
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = rfc_seal(e, _world_20);
      e.mem[_nd_0 + 1] = rfc_seal(e, _name_2);
      e.mem[_nd_0 + 2] = rfc_seal(e, _access_2);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_WORLD_REGISTRATIONMETA, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _world_19);
      _v_52 = _world_11;
      _v_53 = _world_12;
      _v_54 = _world_13;
      _v_55 = _world_14;
      _v_56 = _world_15;
      _v_57 = _world_16;
      _v_58 = _world_17;
      _v_59 = _world_18;
      _v_60 = term_ctr(CID_CON, _nd_1);
      _v_61 = U32_BIN(_world_20, +, 1ull);
      _v_62 = _world_21;
      _v_63 = 0;
      _v_64 = _world_20;
    }
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  Term _name_1 = r11;
  Term _access_1 = r12;
  WL_SPIN
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    Term _o_0[13];
    if (spin_50(e, _o_0, U32_BIN(_world_9, <, 4294967295ull), _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_10, _name_1, _name_1 == h11 ? q11 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h12 ? q12 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_39 = _o_0[0];
    _v_40 = _o_0[1];
    _v_41 = _o_0[2];
    _v_42 = _o_0[3];
    _v_43 = _o_0[4];
    _v_44 = _o_0[5];
    _v_45 = _o_0[6];
    _v_46 = _o_0[7];
    _v_47 = _o_0[8];
    _v_48 = _o_0[9];
    _v_49 = _o_0[10];
    _v_50 = _o_0[11];
    _v_51 = _o_0[12];
    _v_26 = _v_39;
    _v_27 = _v_40;
    _v_28 = _v_41;
    _v_29 = _v_42;
    _v_30 = _v_43;
    _v_31 = _v_44;
    _v_32 = _v_45;
    _v_33 = _v_46;
    _v_34 = _v_47;
    _v_35 = _v_48;
    _v_36 = _v_49;
    _v_37 = _v_50;
    _v_38 = _v_51;
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  u32 _v_85 = 0;
  Term _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  Term _v_89 = 0;
  Term _v_90 = 0;
  Term _v_91 = 0;
  u32 _v_92 = 0;
  u32 _v_93 = 0;
  u32 _v_94 = 0;
  u32 _v_95 = 0;
  Term _v_96 = 0;
  Term _v_97 = 0;
  u32 _v_98 = 0;
  u32 _registered_0 = r0;
  u32 _registered_1 = r1;
  u32 _registered_2 = r2;
  Term _registered_3 = r3;
  u32 _registered_4 = r4;
  Term _registered_5 = r5;
  Term _registered_6 = r6;
  Term _registered_7 = r7;
  Term _registered_8 = r8;
  u32 _registered_9 = r9;
  u32 _registered_10 = r10;
  u32 _registered_11 = r11;
  u32 _registered_12 = r12;
  u32 _namespace_0 = r13;
  Term _name_3 = r14;
  Term _access_3 = r15;
  WL_SPIN
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    u32 _v_101 = 0;
    u32 _v_102 = 0;
    Term _v_103 = 0;
    u32 _v_104 = 0;
    Term _v_105 = 0;
    Term _v_106 = 0;
    Term _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    u32 _v_110 = 0;
    u32 _v_111 = 0;
    u32 _v_112 = 0;
    Term _v_113 = 0;
    Term _v_114 = 0;
    u32 _v_115 = 0;
    Term _o_2[17];
    if (spin_45(e, _o_2, _registered_0, _registered_1, _registered_2, _registered_3, _registered_3 == h3 ? q3 : blk_loc(e.mem, _registered_3), _registered_4, _registered_5, _registered_6, _registered_6 == h6 ? q6 : blk_loc(e.mem, _registered_6), _registered_7, _registered_7 == h7 ? q7 : blk_loc(e.mem, _registered_7), _registered_8, _registered_8 == h8 ? q8 : blk_loc(e.mem, _registered_8), _registered_9, _registered_10, _registered_11, _registered_12, _namespace_0, _name_3, _name_3 == h14 ? q14 : blk_loc(e.mem, _name_3), _access_3, _access_3 == h15 ? q15 : blk_loc(e.mem, _access_3)) == 0) {
      return 0;
    }
    _v_99 = _o_2[0];
    _v_100 = _o_2[1];
    _v_101 = _o_2[2];
    _v_102 = _o_2[3];
    _v_103 = _o_2[4];
    _v_104 = _o_2[5];
    _v_105 = _o_2[6];
    _v_106 = _o_2[7];
    _v_107 = _o_2[8];
    _v_108 = _o_2[9];
    _v_109 = _o_2[10];
    _v_110 = _o_2[11];
    _v_111 = _o_2[12];
    _v_112 = _o_2[13];
    _v_113 = _o_2[14];
    _v_114 = _o_2[15];
    _v_115 = _o_2[16];
    _v_82 = _v_99;
    _v_83 = _v_100;
    _v_84 = _v_101;
    _v_85 = _v_102;
    _v_86 = _v_103;
    _v_87 = _v_104;
    _v_88 = _v_105;
    _v_89 = _v_106;
    _v_90 = _v_107;
    _v_91 = _v_108;
    _v_92 = _v_109;
    _v_93 = _v_110;
    _v_94 = _v_111;
    _v_95 = _v_112;
    _v_96 = _v_113;
    _v_97 = _v_114;
    _v_98 = _v_115;
  break;
  }
  o[0] = _v_82;
  o[1] = _v_83;
  o[2] = _v_84;
  o[3] = _v_85;
  o[4] = _v_86;
  o[5] = _v_87;
  o[6] = _v_88;
  o[7] = _v_89;
  o[8] = _v_90;
  o[9] = _v_91;
  o[10] = _v_92;
  o[11] = _v_93;
  o[12] = _v_94;
  o[13] = _v_95;
  o[14] = _v_96;
  o[15] = _v_97;
  o[16] = _v_98;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_2 = 0;
  Term _left_0 = r0;
  Term _right_0 = r1;
  WL_SPIN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_0[1];
    if (spin_17(e, _o_0, _left_0, _left_0 == h0 ? q0 : blk_loc(e.mem, _left_0)) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_3 = _v_4;
    Term _v_5 = 0;
    Term _o_1[1];
    if (spin_46(e, _o_1, _v_3, _v_3 == h1 ? q1 : _v_3 == h0 ? q0 : blk_loc(e.mem, _v_3), _right_0, _right_0 == h1 ? q1 : blk_loc(e.mem, _right_0)) == 0) {
      return 0;
    }
    _v_5 = _o_1[0];
    _v_2 = _v_5;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, Term r14, Term r15, Term r16, u32 r17) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  u32 _collected_0 = r0;
  u32 _collected_1 = r1;
  u32 _collected_2 = r2;
  Term _collected_3 = r3;
  u32 _collected_4 = r4;
  Term _collected_5 = r5;
  Term _collected_6 = r6;
  Term _collected_7 = r7;
  Term _collected_8 = r8;
  u32 _collected_9 = r9;
  u32 _collected_10 = r10;
  Term _collected_11 = r11;
  Term _positions_2 = r12;
  Term _tick_0 = r13;
  Term _frameStart_2 = r14;
  Term _boundary_2 = r15;
  Term _capacity_2 = r16;
  u32 _nextReader_2 = r17;
  WL_SPIN
    _v_18 = _collected_0;
    _v_19 = _collected_1;
    _v_20 = _collected_2;
    _v_21 = _collected_3;
    _v_22 = _collected_4;
    _v_23 = _collected_5;
    _v_24 = _collected_6;
    _v_25 = _collected_7;
    _v_26 = _collected_8;
    _v_27 = _collected_9;
    _v_28 = _collected_10;
    _v_29 = _collected_11;
    _v_30 = _positions_2;
    _v_31 = _tick_0;
    _v_32 = _frameStart_2;
    _v_33 = _boundary_2;
    _v_34 = _capacity_2;
    _v_35 = _nextReader_2;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  o[8] = _v_26;
  o[9] = _v_27;
  o[10] = _v_28;
  o[11] = _v_29;
  o[12] = _v_30;
  o[13] = _v_31;
  o[14] = _v_32;
  o[15] = _v_33;
  o[16] = _v_34;
  o[17] = _v_35;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, u32 r0, u32 r1, Term r2, Term r3, u32 r4, Term r5) {
  u32 wpoll = 0;
  u32 _v_6 = 0;
  Term _v_7 = 0;
  Term _v_8 = 0;
  u32 _position_0 = r0;
  u32 _position_1 = r1;
  Term _position_2 = r2;
  Term _position_3 = r3;
  u32 _id_0 = r4;
  Term _tick_0 = r5;
  WL_SPIN
    if (_position_0 == 0) {
      _v_6 = _id_0;
      _v_7 = 0;
      _v_8 = _tick_0;
    } else {
      _v_6 = _position_1;
      _v_7 = _position_2;
      _v_8 = _position_3;
    }
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_47 = 0;
  u32 _available_0 = r0;
  u32 _clock_0 = r1;
  WL_SPIN
    if (_available_0 == 0) {
      _v_47 = _clock_0;
    } else {
      _v_47 = U32_BIN(_clock_0, +, 1ull);
    }
  break;
  }
  o[0] = _v_47;
  return 1;
}

INLINE Term spin_55(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  WL_SPIN
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    Term _o_1[1];
    if (spin_56(e, _o_1, U32_BIN(_world_10, <, 4294967295ull), _world_10) == 0) {
      return 0;
    }
    _v_46 = _o_1[0];
    _v_45 = _v_46;
    u32 _v_48 = 0;
    u32 _v_49 = 0;
    Term _o_2[1];
    if (spin_56(e, _o_2, U32_BIN(_world_10, <, 4294967295ull), _world_10) == 0) {
      return 0;
    }
    _v_49 = _o_2[0];
    _v_48 = _v_49;
    _v_33 = _world_0;
    _v_34 = _world_1;
    _v_35 = _world_2;
    _v_36 = _world_3;
    _v_37 = _world_4;
    _v_38 = _world_5;
    _v_39 = _world_6;
    _v_40 = _world_7;
    _v_41 = _world_8;
    _v_42 = _world_9;
    _v_43 = _v_45;
    _v_44 = _v_48;
  break;
  }
  o[0] = _v_33;
  o[1] = _v_34;
  o[2] = _v_35;
  o[3] = _v_36;
  o[4] = _v_37;
  o[5] = _v_38;
  o[6] = _v_39;
  o[7] = _v_40;
  o[8] = _v_41;
  o[9] = _v_42;
  o[10] = _v_43;
  o[11] = _v_44;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  u32 _named_0 = r0;
  u32 _named_1 = r1;
  u32 _named_2 = r2;
  Term _named_3 = r3;
  u32 _named_4 = r4;
  Term _named_5 = r5;
  Term _named_6 = r6;
  Term _named_7 = r7;
  Term _named_8 = r8;
  u32 _named_9 = r9;
  u32 _named_10 = r10;
  u32 _named_11 = r11;
  Term _name_1 = r12;
  Term _access_1 = r13;
  WL_SPIN
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    _name_1 = term_keep(e, _name_1, 1);
    _access_1 = term_keep(e, _access_1, 1);
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    Term _o_1[13];
    if (spin_49(e, _o_1, _named_0, _named_1, _named_2, _named_3, _named_3 == h3 ? q3 : blk_loc(e.mem, _named_3), _named_4, _named_5, _named_6, _named_6 == h6 ? q6 : blk_loc(e.mem, _named_6), _named_7, _named_7 == h7 ? q7 : blk_loc(e.mem, _named_7), _named_8, _named_8 == h8 ? q8 : blk_loc(e.mem, _named_8), _named_9, _named_10, _name_1, _name_1 == h12 ? q12 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h13 ? q13 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_71 = _o_1[0];
    _v_72 = _o_1[1];
    _v_73 = _o_1[2];
    _v_74 = _o_1[3];
    _v_75 = _o_1[4];
    _v_76 = _o_1[5];
    _v_77 = _o_1[6];
    _v_78 = _o_1[7];
    _v_79 = _o_1[8];
    _v_80 = _o_1[9];
    _v_81 = _o_1[10];
    _v_82 = _o_1[11];
    _v_83 = _o_1[12];
    _v_58 = _v_71;
    _v_59 = _v_72;
    _v_60 = _v_73;
    _v_61 = _v_74;
    _v_62 = _v_75;
    _v_63 = _v_76;
    _v_64 = _v_77;
    _v_65 = _v_78;
    _v_66 = _v_79;
    _v_67 = _v_80;
    _v_68 = _v_81;
    _v_69 = _v_82;
    _v_70 = _v_83;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    Term _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    Term _o_2[17];
    if (spin_51(e, _o_2, _v_58, _v_59, _v_60, _v_61, _v_61 == h13 ? q13 : _v_61 == h12 ? q12 : _v_61 == h8 ? q8 : _v_61 == h7 ? q7 : _v_61 == h6 ? q6 : _v_61 == h3 ? q3 : blk_loc(e.mem, _v_61), _v_62, _v_63, _v_64, _v_64 == h13 ? q13 : _v_64 == h12 ? q12 : _v_64 == h8 ? q8 : _v_64 == h7 ? q7 : _v_64 == h6 ? q6 : _v_64 == h3 ? q3 : blk_loc(e.mem, _v_64), _v_65, _v_65 == h13 ? q13 : _v_65 == h12 ? q12 : _v_65 == h8 ? q8 : _v_65 == h7 ? q7 : _v_65 == h6 ? q6 : _v_65 == h3 ? q3 : blk_loc(e.mem, _v_65), _v_66, _v_66 == h13 ? q13 : _v_66 == h12 ? q12 : _v_66 == h8 ? q8 : _v_66 == h7 ? q7 : _v_66 == h6 ? q6 : _v_66 == h3 ? q3 : blk_loc(e.mem, _v_66), _v_67, _v_68, _v_69, _v_70, _named_11, _name_1, _name_1 == h12 ? q12 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h13 ? q13 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_84 = _o_2[0];
    _v_85 = _o_2[1];
    _v_86 = _o_2[2];
    _v_87 = _o_2[3];
    _v_88 = _o_2[4];
    _v_89 = _o_2[5];
    _v_90 = _o_2[6];
    _v_91 = _o_2[7];
    _v_92 = _o_2[8];
    _v_93 = _o_2[9];
    _v_94 = _o_2[10];
    _v_95 = _o_2[11];
    _v_96 = _o_2[12];
    _v_97 = _o_2[13];
    _v_98 = _o_2[14];
    _v_99 = _o_2[15];
    _v_100 = _o_2[16];
    _v_41 = _v_84;
    _v_42 = _v_85;
    _v_43 = _v_86;
    _v_44 = _v_87;
    _v_45 = _v_88;
    _v_46 = _v_89;
    _v_47 = _v_90;
    _v_48 = _v_91;
    _v_49 = _v_92;
    _v_50 = _v_93;
    _v_51 = _v_94;
    _v_52 = _v_95;
    _v_53 = _v_96;
    _v_54 = _v_97;
    _v_55 = _v_98;
    _v_56 = _v_99;
    _v_57 = _v_100;
  break;
  }
  o[0] = _v_41;
  o[1] = _v_42;
  o[2] = _v_43;
  o[3] = _v_44;
  o[4] = _v_45;
  o[5] = _v_46;
  o[6] = _v_47;
  o[7] = _v_48;
  o[8] = _v_49;
  o[9] = _v_50;
  o[10] = _v_51;
  o[11] = _v_52;
  o[12] = _v_53;
  o[13] = _v_54;
  o[14] = _v_55;
  o[15] = _v_56;
  o[16] = _v_57;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _world_11 = r0;
  u32 _world_12 = r1;
  u32 _world_13 = r2;
  Term _world_14 = r3;
  u32 _world_15 = r4;
  Term _world_16 = r5;
  Term _world_17 = r6;
  Term _world_18 = r7;
  Term _world_19 = r8;
  u32 _world_20 = r9;
  u32 _world_21 = r10;
  Term _published_1 = r11;
  WL_SPIN
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _o_0[1];
    if (spin_52(e, _o_0, _world_17, _world_17 == h6 ? q6 : blk_loc(e.mem, _world_17), _published_1, _published_1 == h11 ? q11 : blk_loc(e.mem, _published_1)) == 0) {
      return 0;
    }
    _v_23 = _o_0[0];
    _v_22 = _v_23;
    _v_11 = _world_11;
    _v_12 = _world_12;
    _v_13 = _world_13;
    _v_14 = _world_14;
    _v_15 = _world_15;
    _v_16 = _world_16;
    _v_17 = _v_22;
    _v_18 = _world_18;
    _v_19 = _world_19;
    _v_20 = _world_20;
    _v_21 = _world_21;
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  Term _name_1 = r11;
  Term _access_1 = r12;
  WL_SPIN
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    Term _o_0[12];
    if (spin_36(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_10) == 0) {
      return 0;
    }
    _v_63 = _o_0[0];
    _v_64 = _o_0[1];
    _v_65 = _o_0[2];
    _v_66 = _o_0[3];
    _v_67 = _o_0[4];
    _v_68 = _o_0[5];
    _v_69 = _o_0[6];
    _v_70 = _o_0[7];
    _v_71 = _o_0[8];
    _v_72 = _o_0[9];
    _v_73 = _o_0[10];
    _v_74 = _o_0[11];
    _v_51 = _v_63;
    _v_52 = _v_64;
    _v_53 = _v_65;
    _v_54 = _v_66;
    _v_55 = _v_67;
    _v_56 = _v_68;
    _v_57 = _v_69;
    _v_58 = _v_70;
    _v_59 = _v_71;
    _v_60 = _v_72;
    _v_61 = _v_73;
    _v_62 = _v_74;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    u32 _v_91 = 0;
    Term _o_1[17];
    if (spin_57(e, _o_1, _v_51, _v_52, _v_53, _v_54, _v_54 == h12 ? q12 : _v_54 == h11 ? q11 : _v_54 == h8 ? q8 : _v_54 == h7 ? q7 : _v_54 == h6 ? q6 : _v_54 == h3 ? q3 : blk_loc(e.mem, _v_54), _v_55, _v_56, _v_57, _v_57 == h12 ? q12 : _v_57 == h11 ? q11 : _v_57 == h8 ? q8 : _v_57 == h7 ? q7 : _v_57 == h6 ? q6 : _v_57 == h3 ? q3 : blk_loc(e.mem, _v_57), _v_58, _v_58 == h12 ? q12 : _v_58 == h11 ? q11 : _v_58 == h8 ? q8 : _v_58 == h7 ? q7 : _v_58 == h6 ? q6 : _v_58 == h3 ? q3 : blk_loc(e.mem, _v_58), _v_59, _v_59 == h12 ? q12 : _v_59 == h11 ? q11 : _v_59 == h8 ? q8 : _v_59 == h7 ? q7 : _v_59 == h6 ? q6 : _v_59 == h3 ? q3 : blk_loc(e.mem, _v_59), _v_60, _v_61, _v_62, _name_1, _name_1 == h11 ? q11 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h12 ? q12 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_75 = _o_1[0];
    _v_76 = _o_1[1];
    _v_77 = _o_1[2];
    _v_78 = _o_1[3];
    _v_79 = _o_1[4];
    _v_80 = _o_1[5];
    _v_81 = _o_1[6];
    _v_82 = _o_1[7];
    _v_83 = _o_1[8];
    _v_84 = _o_1[9];
    _v_85 = _o_1[10];
    _v_86 = _o_1[11];
    _v_87 = _o_1[12];
    _v_88 = _o_1[13];
    _v_89 = _o_1[14];
    _v_90 = _o_1[15];
    _v_91 = _o_1[16];
    _v_34 = _v_75;
    _v_35 = _v_76;
    _v_36 = _v_77;
    _v_37 = _v_78;
    _v_38 = _v_79;
    _v_39 = _v_80;
    _v_40 = _v_81;
    _v_41 = _v_82;
    _v_42 = _v_83;
    _v_43 = _v_84;
    _v_44 = _v_85;
    _v_45 = _v_86;
    _v_46 = _v_87;
    _v_47 = _v_88;
    _v_48 = _v_89;
    _v_49 = _v_90;
    _v_50 = _v_91;
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  o[7] = _v_41;
  o[8] = _v_42;
  o[9] = _v_43;
  o[10] = _v_44;
  o[11] = _v_45;
  o[12] = _v_46;
  o[13] = _v_47;
  o[14] = _v_48;
  o[15] = _v_49;
  o[16] = _v_50;
  return 1;
}

INLINE Term spin_60(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, u32 r16, Term r17, u64 q17, Term r18, u64 q18, Term r19, u64 q19, Term r20, Term r21, Term r22, Term r23, u32 r24) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h14 = r14;
  Term h15 = r15;
  Term h17 = r17;
  Term h18 = r18;
  Term h19 = r19;
  u32 _v_118 = 0;
  u32 _v_119 = 0;
  u32 _v_120 = 0;
  u32 _v_121 = 0;
  Term _v_122 = 0;
  u32 _v_123 = 0;
  Term _v_124 = 0;
  Term _v_125 = 0;
  Term _v_126 = 0;
  Term _v_127 = 0;
  u32 _v_128 = 0;
  u32 _v_129 = 0;
  Term _v_130 = 0;
  Term _v_131 = 0;
  Term _v_132 = 0;
  Term _v_133 = 0;
  Term _v_134 = 0;
  Term _v_135 = 0;
  u32 _v_136 = 0;
  u32 _v_137 = 0;
  u32 _v_138 = 0;
  Term _v_139 = 0;
  Term _v_140 = 0;
  u32 _v_141 = 0;
  Term _v_142 = 0;
  u32 _v_143 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  u32 _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  Term _result_9 = r9;
  u32 _result_10 = r10;
  u32 _result_11 = r11;
  u32 _result_12 = r12;
  u32 _result_13 = r13;
  Term _result_14 = r14;
  Term _result_15 = r15;
  u32 _result_16 = r16;
  Term _keys_1 = r17;
  Term _domains_0 = r18;
  Term _positions_0 = r19;
  Term _tick_0 = r20;
  Term _frameStart_0 = r21;
  Term _boundary_0 = r22;
  Term _capacity_0 = r23;
  u32 _nextReader_0 = r24;
  WL_SPIN
    if (_result_0 == 1) {
      term_sink(e, _keys_1);
      _v_118 = 1;
      _v_119 = _result_1;
      _v_120 = _result_2;
      _v_121 = _result_3;
      _v_122 = _result_4;
      _v_123 = _result_5;
      _v_124 = _result_6;
      _v_125 = _result_7;
      _v_126 = _result_8;
      _v_127 = _result_9;
      _v_128 = _result_10;
      _v_129 = _result_11;
      _v_130 = _domains_0;
      _v_131 = _positions_0;
      _v_132 = _tick_0;
      _v_133 = _frameStart_0;
      _v_134 = _boundary_0;
      _v_135 = _capacity_0;
      _v_136 = _nextReader_0;
      _v_137 = 0;
      _v_138 = 0;
      _v_139 = 0;
      _v_140 = 0;
      _v_141 = 0;
      _v_142 = 0;
      _v_143 = 0;
    } else {
      _v_118 = 0;
      _v_119 = _result_1;
      _v_120 = _result_2;
      _v_121 = _result_3;
      _v_122 = _result_4;
      _v_123 = _result_5;
      _v_124 = _result_6;
      _v_125 = _result_7;
      _v_126 = _result_8;
      _v_127 = _result_9;
      _v_128 = _result_10;
      _v_129 = _result_11;
      _v_130 = _domains_0;
      _v_131 = _positions_0;
      _v_132 = _tick_0;
      _v_133 = _frameStart_0;
      _v_134 = _boundary_0;
      _v_135 = _capacity_0;
      _v_136 = U32_BIN(_nextReader_0, +, 1ull);
      _v_137 = _result_12;
      _v_138 = _result_13;
      _v_139 = _result_14;
      _v_140 = _result_15;
      _v_141 = _result_16;
      _v_142 = _keys_1;
      _v_143 = _nextReader_0;
    }
  break;
  }
  o[0] = _v_118;
  o[1] = _v_119;
  o[2] = _v_120;
  o[3] = _v_121;
  o[4] = _v_122;
  o[5] = _v_123;
  o[6] = _v_124;
  o[7] = _v_125;
  o[8] = _v_126;
  o[9] = _v_127;
  o[10] = _v_128;
  o[11] = _v_129;
  o[12] = _v_130;
  o[13] = _v_131;
  o[14] = _v_132;
  o[15] = _v_133;
  o[16] = _v_134;
  o[17] = _v_135;
  o[18] = _v_136;
  o[19] = _v_137;
  o[20] = _v_138;
  o[21] = _v_139;
  o[22] = _v_140;
  o[23] = _v_141;
  o[24] = _v_142;
  o[25] = _v_143;
  return 1;
}

INLINE Term spin_61(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, Term r14, Term r15, Term r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  Term h18 = r18;
  Term h19 = r19;
  Term h20 = r20;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _runtime_18 = r0;
  u32 _runtime_19 = r1;
  u32 _runtime_20 = r2;
  Term _runtime_21 = r3;
  u32 _runtime_22 = r4;
  Term _runtime_23 = r5;
  Term _runtime_24 = r6;
  Term _runtime_25 = r7;
  Term _runtime_26 = r8;
  u32 _runtime_27 = r9;
  u32 _runtime_28 = r10;
  Term _runtime_29 = r11;
  Term _runtime_30 = r12;
  Term _runtime_31 = r13;
  Term _runtime_32 = r14;
  Term _runtime_33 = r15;
  Term _runtime_34 = r16;
  u32 _runtime_35 = r17;
  Term _keys_1 = r18;
  Term _name_1 = r19;
  Term _access_1 = r20;
  WL_SPIN
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    u32 _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    Term _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    u32 _v_85 = 0;
    Term _o_0[17];
    if (spin_59(e, _o_0, _runtime_18, _runtime_19, _runtime_20, _runtime_21, _runtime_21 == h3 ? q3 : blk_loc(e.mem, _runtime_21), _runtime_22, _runtime_23, _runtime_24, _runtime_24 == h6 ? q6 : blk_loc(e.mem, _runtime_24), _runtime_25, _runtime_25 == h7 ? q7 : blk_loc(e.mem, _runtime_25), _runtime_26, _runtime_26 == h8 ? q8 : blk_loc(e.mem, _runtime_26), _runtime_27, _runtime_28, _name_1, _name_1 == h19 ? q19 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h20 ? q20 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_69 = _o_0[0];
    _v_70 = _o_0[1];
    _v_71 = _o_0[2];
    _v_72 = _o_0[3];
    _v_73 = _o_0[4];
    _v_74 = _o_0[5];
    _v_75 = _o_0[6];
    _v_76 = _o_0[7];
    _v_77 = _o_0[8];
    _v_78 = _o_0[9];
    _v_79 = _o_0[10];
    _v_80 = _o_0[11];
    _v_81 = _o_0[12];
    _v_82 = _o_0[13];
    _v_83 = _o_0[14];
    _v_84 = _o_0[15];
    _v_85 = _o_0[16];
    _v_52 = _v_69;
    _v_53 = _v_70;
    _v_54 = _v_71;
    _v_55 = _v_72;
    _v_56 = _v_73;
    _v_57 = _v_74;
    _v_58 = _v_75;
    _v_59 = _v_76;
    _v_60 = _v_77;
    _v_61 = _v_78;
    _v_62 = _v_79;
    _v_63 = _v_80;
    _v_64 = _v_81;
    _v_65 = _v_82;
    _v_66 = _v_83;
    _v_67 = _v_84;
    _v_68 = _v_85;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    u32 _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    Term _v_98 = 0;
    Term _v_99 = 0;
    Term _v_100 = 0;
    Term _v_101 = 0;
    Term _v_102 = 0;
    Term _v_103 = 0;
    u32 _v_104 = 0;
    u32 _v_105 = 0;
    u32 _v_106 = 0;
    Term _v_107 = 0;
    Term _v_108 = 0;
    u32 _v_109 = 0;
    Term _v_110 = 0;
    u32 _v_111 = 0;
    Term _o_1[26];
    if (spin_60(e, _o_1, _v_52, _v_53, _v_54, _v_55, _v_56, _v_56 == h20 ? q20 : _v_56 == h19 ? q19 : _v_56 == h18 ? q18 : _v_56 == h12 ? q12 : _v_56 == h11 ? q11 : _v_56 == h8 ? q8 : _v_56 == h7 ? q7 : _v_56 == h6 ? q6 : _v_56 == h3 ? q3 : blk_loc(e.mem, _v_56), _v_57, _v_58, _v_59, _v_59 == h20 ? q20 : _v_59 == h19 ? q19 : _v_59 == h18 ? q18 : _v_59 == h12 ? q12 : _v_59 == h11 ? q11 : _v_59 == h8 ? q8 : _v_59 == h7 ? q7 : _v_59 == h6 ? q6 : _v_59 == h3 ? q3 : blk_loc(e.mem, _v_59), _v_60, _v_60 == h20 ? q20 : _v_60 == h19 ? q19 : _v_60 == h18 ? q18 : _v_60 == h12 ? q12 : _v_60 == h11 ? q11 : _v_60 == h8 ? q8 : _v_60 == h7 ? q7 : _v_60 == h6 ? q6 : _v_60 == h3 ? q3 : blk_loc(e.mem, _v_60), _v_61, _v_61 == h20 ? q20 : _v_61 == h19 ? q19 : _v_61 == h18 ? q18 : _v_61 == h12 ? q12 : _v_61 == h11 ? q11 : _v_61 == h8 ? q8 : _v_61 == h7 ? q7 : _v_61 == h6 ? q6 : _v_61 == h3 ? q3 : blk_loc(e.mem, _v_61), _v_62, _v_63, _v_64, _v_65, _v_66, _v_66 == h20 ? q20 : _v_66 == h19 ? q19 : _v_66 == h18 ? q18 : _v_66 == h12 ? q12 : _v_66 == h11 ? q11 : _v_66 == h8 ? q8 : _v_66 == h7 ? q7 : _v_66 == h6 ? q6 : _v_66 == h3 ? q3 : blk_loc(e.mem, _v_66), _v_67, _v_67 == h20 ? q20 : _v_67 == h19 ? q19 : _v_67 == h18 ? q18 : _v_67 == h12 ? q12 : _v_67 == h11 ? q11 : _v_67 == h8 ? q8 : _v_67 == h7 ? q7 : _v_67 == h6 ? q6 : _v_67 == h3 ? q3 : blk_loc(e.mem, _v_67), _v_68, _keys_1, _keys_1 == h18 ? q18 : blk_loc(e.mem, _keys_1), _runtime_29, _runtime_29 == h11 ? q11 : blk_loc(e.mem, _runtime_29), _runtime_30, _runtime_30 == h12 ? q12 : blk_loc(e.mem, _runtime_30), _runtime_31, _runtime_32, _runtime_33, _runtime_34, _runtime_35) == 0) {
      return 0;
    }
    _v_86 = _o_1[0];
    _v_87 = _o_1[1];
    _v_88 = _o_1[2];
    _v_89 = _o_1[3];
    _v_90 = _o_1[4];
    _v_91 = _o_1[5];
    _v_92 = _o_1[6];
    _v_93 = _o_1[7];
    _v_94 = _o_1[8];
    _v_95 = _o_1[9];
    _v_96 = _o_1[10];
    _v_97 = _o_1[11];
    _v_98 = _o_1[12];
    _v_99 = _o_1[13];
    _v_100 = _o_1[14];
    _v_101 = _o_1[15];
    _v_102 = _o_1[16];
    _v_103 = _o_1[17];
    _v_104 = _o_1[18];
    _v_105 = _o_1[19];
    _v_106 = _o_1[20];
    _v_107 = _o_1[21];
    _v_108 = _o_1[22];
    _v_109 = _o_1[23];
    _v_110 = _o_1[24];
    _v_111 = _o_1[25];
    _v_26 = _v_86;
    _v_27 = _v_87;
    _v_28 = _v_88;
    _v_29 = _v_89;
    _v_30 = _v_90;
    _v_31 = _v_91;
    _v_32 = _v_92;
    _v_33 = _v_93;
    _v_34 = _v_94;
    _v_35 = _v_95;
    _v_36 = _v_96;
    _v_37 = _v_97;
    _v_38 = _v_98;
    _v_39 = _v_99;
    _v_40 = _v_100;
    _v_41 = _v_101;
    _v_42 = _v_102;
    _v_43 = _v_103;
    _v_44 = _v_104;
    _v_45 = _v_105;
    _v_46 = _v_106;
    _v_47 = _v_107;
    _v_48 = _v_108;
    _v_49 = _v_109;
    _v_50 = _v_110;
    _v_51 = _v_111;
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  o[13] = _v_39;
  o[14] = _v_40;
  o[15] = _v_41;
  o[16] = _v_42;
  o[17] = _v_43;
  o[18] = _v_44;
  o[19] = _v_45;
  o[20] = _v_46;
  o[21] = _v_47;
  o[22] = _v_48;
  o[23] = _v_49;
  o[24] = _v_50;
  o[25] = _v_51;
  return 1;
}

INLINE Term spin_62(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  u32 _v_21 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  WL_SPIN
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    u32 _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    Term _o_0[11];
    Term _a_0 = term_ctr(CID_CON, STAT_OFF + 620);
    if (spin_58(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_10, _a_0, _a_0 == h8 ? q8 : _a_0 == h7 ? q7 : _a_0 == h6 ? q6 : _a_0 == h3 ? q3 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_33 = _o_0[0];
    _v_34 = _o_0[1];
    _v_35 = _o_0[2];
    _v_36 = _o_0[3];
    _v_37 = _o_0[4];
    _v_38 = _o_0[5];
    _v_39 = _o_0[6];
    _v_40 = _o_0[7];
    _v_41 = _o_0[8];
    _v_42 = _o_0[9];
    _v_43 = _o_0[10];
    _v_22 = _v_33;
    _v_23 = _v_34;
    _v_24 = _v_35;
    _v_25 = _v_36;
    _v_26 = _v_37;
    _v_27 = _v_38;
    _v_28 = _v_39;
    _v_29 = _v_40;
    _v_30 = _v_41;
    _v_31 = _v_42;
    _v_32 = _v_43;
    _v_11 = _v_22;
    _v_12 = _v_23;
    _v_13 = _v_24;
    _v_14 = _v_25;
    _v_15 = _v_26;
    _v_16 = _v_27;
    _v_17 = _v_28;
    _v_18 = _v_29;
    _v_19 = _v_30;
    _v_20 = _v_31;
    _v_21 = _v_32;
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  o[7] = _v_18;
  o[8] = _v_19;
  o[9] = _v_20;
  o[10] = _v_21;
  return 1;
}

INLINE Term spin_63(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, u32 r5, Term r6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13, Term r14, Term r15, Term r16, Term r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21) {
  u32 wpoll = 0;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h12 = r12;
  Term h13 = r13;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  u32 _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _available_0 = r0;
  u32 _runtime_18 = r1;
  u32 _runtime_19 = r2;
  u32 _runtime_20 = r3;
  Term _runtime_21 = r4;
  u32 _runtime_22 = r5;
  Term _runtime_23 = r6;
  Term _runtime_24 = r7;
  Term _runtime_25 = r8;
  Term _runtime_26 = r9;
  u32 _runtime_27 = r10;
  u32 _runtime_28 = r11;
  Term _runtime_29 = r12;
  Term _runtime_30 = r13;
  Term _runtime_31 = r14;
  Term _runtime_32 = r15;
  Term _runtime_33 = r16;
  Term _runtime_34 = r17;
  u32 _runtime_35 = r18;
  Term _keys_1 = r19;
  Term _name_1 = r20;
  Term _access_1 = r21;
  WL_SPIN
    if (_available_0 == 0) {
      term_sink(e, _keys_1);
      term_sink(e, _name_1);
      term_sink(e, _access_1);
      _v_26 = 1;
      _v_27 = _runtime_18;
      _v_28 = _runtime_19;
      _v_29 = _runtime_20;
      _v_30 = _runtime_21;
      _v_31 = _runtime_22;
      _v_32 = _runtime_23;
      _v_33 = _runtime_24;
      _v_34 = _runtime_25;
      _v_35 = _runtime_26;
      _v_36 = _runtime_27;
      _v_37 = _runtime_28;
      _v_38 = _runtime_29;
      _v_39 = _runtime_30;
      _v_40 = _runtime_31;
      _v_41 = _runtime_32;
      _v_42 = _runtime_33;
      _v_43 = _runtime_34;
      _v_44 = _runtime_35;
      _v_45 = 0;
      _v_46 = 0;
      _v_47 = 0;
      _v_48 = 0;
      _v_49 = 0;
      _v_50 = 0;
      _v_51 = 0;
    } else {
      u32 _v_52 = 0;
      u32 _v_53 = 0;
      u32 _v_54 = 0;
      u32 _v_55 = 0;
      Term _v_56 = 0;
      u32 _v_57 = 0;
      Term _v_58 = 0;
      Term _v_59 = 0;
      Term _v_60 = 0;
      Term _v_61 = 0;
      u32 _v_62 = 0;
      u32 _v_63 = 0;
      Term _v_64 = 0;
      Term _v_65 = 0;
      Term _v_66 = 0;
      Term _v_67 = 0;
      Term _v_68 = 0;
      Term _v_69 = 0;
      u32 _v_70 = 0;
      u32 _v_71 = 0;
      u32 _v_72 = 0;
      Term _v_73 = 0;
      Term _v_74 = 0;
      u32 _v_75 = 0;
      Term _v_76 = 0;
      u32 _v_77 = 0;
      Term _o_0[26];
      if (spin_61(e, _o_0, _runtime_18, _runtime_19, _runtime_20, _runtime_21, _runtime_21 == h4 ? q4 : blk_loc(e.mem, _runtime_21), _runtime_22, _runtime_23, _runtime_24, _runtime_24 == h7 ? q7 : blk_loc(e.mem, _runtime_24), _runtime_25, _runtime_25 == h8 ? q8 : blk_loc(e.mem, _runtime_25), _runtime_26, _runtime_26 == h9 ? q9 : blk_loc(e.mem, _runtime_26), _runtime_27, _runtime_28, _runtime_29, _runtime_29 == h12 ? q12 : blk_loc(e.mem, _runtime_29), _runtime_30, _runtime_30 == h13 ? q13 : blk_loc(e.mem, _runtime_30), _runtime_31, _runtime_32, _runtime_33, _runtime_34, _runtime_35, _keys_1, _keys_1 == h19 ? q19 : blk_loc(e.mem, _keys_1), _name_1, _name_1 == h20 ? q20 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h21 ? q21 : blk_loc(e.mem, _access_1)) == 0) {
        return 0;
      }
      _v_52 = _o_0[0];
      _v_53 = _o_0[1];
      _v_54 = _o_0[2];
      _v_55 = _o_0[3];
      _v_56 = _o_0[4];
      _v_57 = _o_0[5];
      _v_58 = _o_0[6];
      _v_59 = _o_0[7];
      _v_60 = _o_0[8];
      _v_61 = _o_0[9];
      _v_62 = _o_0[10];
      _v_63 = _o_0[11];
      _v_64 = _o_0[12];
      _v_65 = _o_0[13];
      _v_66 = _o_0[14];
      _v_67 = _o_0[15];
      _v_68 = _o_0[16];
      _v_69 = _o_0[17];
      _v_70 = _o_0[18];
      _v_71 = _o_0[19];
      _v_72 = _o_0[20];
      _v_73 = _o_0[21];
      _v_74 = _o_0[22];
      _v_75 = _o_0[23];
      _v_76 = _o_0[24];
      _v_77 = _o_0[25];
      _v_26 = _v_52;
      _v_27 = _v_53;
      _v_28 = _v_54;
      _v_29 = _v_55;
      _v_30 = _v_56;
      _v_31 = _v_57;
      _v_32 = _v_58;
      _v_33 = _v_59;
      _v_34 = _v_60;
      _v_35 = _v_61;
      _v_36 = _v_62;
      _v_37 = _v_63;
      _v_38 = _v_64;
      _v_39 = _v_65;
      _v_40 = _v_66;
      _v_41 = _v_67;
      _v_42 = _v_68;
      _v_43 = _v_69;
      _v_44 = _v_70;
      _v_45 = _v_71;
      _v_46 = _v_72;
      _v_47 = _v_73;
      _v_48 = _v_74;
      _v_49 = _v_75;
      _v_50 = _v_76;
      _v_51 = _v_77;
    }
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  o[13] = _v_39;
  o[14] = _v_40;
  o[15] = _v_41;
  o[16] = _v_42;
  o[17] = _v_43;
  o[18] = _v_44;
  o[19] = _v_45;
  o[20] = _v_46;
  o[21] = _v_47;
  o[22] = _v_48;
  o[23] = _v_49;
  o[24] = _v_50;
  o[25] = _v_51;
  return 1;
}

INLINE Term spin_64(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_17 = 0;
  u32 _v_18 = 0;
  u32 _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  u32 _result_0 = r11;
  u32 _result_1 = r12;
  u32 _namespace_1 = r13;
  Term _name_1 = r14;
  Term _access_1 = r15;
  WL_SPIN
    if (_result_0 == 1) {
      term_sink(e, _name_1);
      term_sink(e, _access_1);
      _v_17 = 1;
      _v_18 = _world_0;
      _v_19 = _world_1;
      _v_20 = _world_2;
      _v_21 = _world_3;
      _v_22 = _world_4;
      _v_23 = _world_5;
      _v_24 = _world_6;
      _v_25 = _world_7;
      _v_26 = _world_8;
      _v_27 = _world_9;
      _v_28 = _world_10;
      _v_29 = 0;
      _v_30 = 0;
      _v_31 = 0;
      _v_32 = 0;
      _v_33 = 0;
    } else {
      _v_17 = 0;
      _v_18 = _world_0;
      _v_19 = _world_1;
      _v_20 = _world_2;
      _v_21 = _world_3;
      _v_22 = _world_4;
      _v_23 = _world_5;
      _v_24 = _world_6;
      _v_25 = _world_7;
      _v_26 = _world_8;
      _v_27 = _world_9;
      _v_28 = _world_10;
      _v_29 = _namespace_1;
      _v_30 = _result_1;
      _v_31 = _name_1;
      _v_32 = _access_1;
      _v_33 = 0ull;
    }
  break;
  }
  o[0] = _v_17;
  o[1] = _v_18;
  o[2] = _v_19;
  o[3] = _v_20;
  o[4] = _v_21;
  o[5] = _v_22;
  o[6] = _v_23;
  o[7] = _v_24;
  o[8] = _v_25;
  o[9] = _v_26;
  o[10] = _v_27;
  o[11] = _v_28;
  o[12] = _v_29;
  o[13] = _v_30;
  o[14] = _v_31;
  o[15] = _v_32;
  o[16] = _v_33;
  return 1;
}

INLINE Term spin_65(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, Term r14, Term r15, Term r16, u32 r17, Term r18, u64 q18, Term r19, u64 q19, Term r20, u64 q20) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  Term h18 = r18;
  Term h19 = r19;
  Term h20 = r20;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  u32 _v_63 = 0;
  Term _v_64 = 0;
  Term _v_65 = 0;
  Term _v_66 = 0;
  Term _v_67 = 0;
  Term _v_68 = 0;
  Term _v_69 = 0;
  u32 _v_70 = 0;
  u32 _v_71 = 0;
  u32 _v_72 = 0;
  Term _v_73 = 0;
  Term _v_74 = 0;
  u32 _v_75 = 0;
  Term _v_76 = 0;
  u32 _v_77 = 0;
  u32 _runtime_0 = r0;
  u32 _runtime_1 = r1;
  u32 _runtime_2 = r2;
  Term _runtime_3 = r3;
  u32 _runtime_4 = r4;
  Term _runtime_5 = r5;
  Term _runtime_6 = r6;
  Term _runtime_7 = r7;
  Term _runtime_8 = r8;
  u32 _runtime_9 = r9;
  u32 _runtime_10 = r10;
  Term _runtime_11 = r11;
  Term _runtime_12 = r12;
  Term _runtime_13 = r13;
  Term _runtime_14 = r14;
  Term _runtime_15 = r15;
  Term _runtime_16 = r16;
  u32 _runtime_17 = r17;
  Term _keys_0 = r18;
  Term _name_0 = r19;
  Term _access_0 = r20;
  WL_SPIN
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _v_82 = 0;
    u32 _v_83 = 0;
    Term _v_84 = 0;
    Term _v_85 = 0;
    Term _v_86 = 0;
    Term _v_87 = 0;
    u32 _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    Term _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    u32 _v_98 = 0;
    Term _v_99 = 0;
    Term _v_100 = 0;
    u32 _v_101 = 0;
    Term _v_102 = 0;
    u32 _v_103 = 0;
    Term _o_0[26];
    if (spin_63(e, _o_0, U32_BIN(_runtime_17, <, 4294967295ull), _runtime_0, _runtime_1, _runtime_2, _runtime_3, _runtime_3 == h3 ? q3 : blk_loc(e.mem, _runtime_3), _runtime_4, _runtime_5, _runtime_6, _runtime_6 == h6 ? q6 : blk_loc(e.mem, _runtime_6), _runtime_7, _runtime_7 == h7 ? q7 : blk_loc(e.mem, _runtime_7), _runtime_8, _runtime_8 == h8 ? q8 : blk_loc(e.mem, _runtime_8), _runtime_9, _runtime_10, _runtime_11, _runtime_11 == h11 ? q11 : blk_loc(e.mem, _runtime_11), _runtime_12, _runtime_12 == h12 ? q12 : blk_loc(e.mem, _runtime_12), _runtime_13, _runtime_14, _runtime_15, _runtime_16, _runtime_17, _keys_0, _keys_0 == h18 ? q18 : blk_loc(e.mem, _keys_0), _name_0, _name_0 == h19 ? q19 : blk_loc(e.mem, _name_0), _access_0, _access_0 == h20 ? q20 : blk_loc(e.mem, _access_0)) == 0) {
      return 0;
    }
    _v_78 = _o_0[0];
    _v_79 = _o_0[1];
    _v_80 = _o_0[2];
    _v_81 = _o_0[3];
    _v_82 = _o_0[4];
    _v_83 = _o_0[5];
    _v_84 = _o_0[6];
    _v_85 = _o_0[7];
    _v_86 = _o_0[8];
    _v_87 = _o_0[9];
    _v_88 = _o_0[10];
    _v_89 = _o_0[11];
    _v_90 = _o_0[12];
    _v_91 = _o_0[13];
    _v_92 = _o_0[14];
    _v_93 = _o_0[15];
    _v_94 = _o_0[16];
    _v_95 = _o_0[17];
    _v_96 = _o_0[18];
    _v_97 = _o_0[19];
    _v_98 = _o_0[20];
    _v_99 = _o_0[21];
    _v_100 = _o_0[22];
    _v_101 = _o_0[23];
    _v_102 = _o_0[24];
    _v_103 = _o_0[25];
    _v_52 = _v_78;
    _v_53 = _v_79;
    _v_54 = _v_80;
    _v_55 = _v_81;
    _v_56 = _v_82;
    _v_57 = _v_83;
    _v_58 = _v_84;
    _v_59 = _v_85;
    _v_60 = _v_86;
    _v_61 = _v_87;
    _v_62 = _v_88;
    _v_63 = _v_89;
    _v_64 = _v_90;
    _v_65 = _v_91;
    _v_66 = _v_92;
    _v_67 = _v_93;
    _v_68 = _v_94;
    _v_69 = _v_95;
    _v_70 = _v_96;
    _v_71 = _v_97;
    _v_72 = _v_98;
    _v_73 = _v_99;
    _v_74 = _v_100;
    _v_75 = _v_101;
    _v_76 = _v_102;
    _v_77 = _v_103;
  break;
  }
  o[0] = _v_52;
  o[1] = _v_53;
  o[2] = _v_54;
  o[3] = _v_55;
  o[4] = _v_56;
  o[5] = _v_57;
  o[6] = _v_58;
  o[7] = _v_59;
  o[8] = _v_60;
  o[9] = _v_61;
  o[10] = _v_62;
  o[11] = _v_63;
  o[12] = _v_64;
  o[13] = _v_65;
  o[14] = _v_66;
  o[15] = _v_67;
  o[16] = _v_68;
  o[17] = _v_69;
  o[18] = _v_70;
  o[19] = _v_71;
  o[20] = _v_72;
  o[21] = _v_73;
  o[22] = _v_74;
  o[23] = _v_75;
  o[24] = _v_76;
  o[25] = _v_77;
  return 1;
}

INLINE Term spin_66(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, u32 r12, u32 r13, Term r14, u64 q14, Term r15, u64 q15) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h14 = r14;
  Term h15 = r15;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  Term _v_51 = 0;
  Term _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  u32 _v_55 = 0;
  u32 _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  u32 _v_59 = 0;
  u32 _registered_0 = r0;
  u32 _registered_1 = r1;
  u32 _registered_2 = r2;
  Term _registered_3 = r3;
  u32 _registered_4 = r4;
  Term _registered_5 = r5;
  Term _registered_6 = r6;
  Term _registered_7 = r7;
  Term _registered_8 = r8;
  u32 _registered_9 = r9;
  u32 _registered_10 = r10;
  u32 _registered_11 = r11;
  u32 _registered_12 = r12;
  u32 _namespace_0 = r13;
  Term _name_1 = r14;
  Term _access_1 = r15;
  WL_SPIN
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _o_1[17];
    if (spin_64(e, _o_1, _registered_0, _registered_1, _registered_2, _registered_3, _registered_3 == h3 ? q3 : blk_loc(e.mem, _registered_3), _registered_4, _registered_5, _registered_6, _registered_6 == h6 ? q6 : blk_loc(e.mem, _registered_6), _registered_7, _registered_7 == h7 ? q7 : blk_loc(e.mem, _registered_7), _registered_8, _registered_8 == h8 ? q8 : blk_loc(e.mem, _registered_8), _registered_9, _registered_10, _registered_11, _registered_12, _namespace_0, _name_1, _name_1 == h14 ? q14 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h15 ? q15 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_60 = _o_1[0];
    _v_61 = _o_1[1];
    _v_62 = _o_1[2];
    _v_63 = _o_1[3];
    _v_64 = _o_1[4];
    _v_65 = _o_1[5];
    _v_66 = _o_1[6];
    _v_67 = _o_1[7];
    _v_68 = _o_1[8];
    _v_69 = _o_1[9];
    _v_70 = _o_1[10];
    _v_71 = _o_1[11];
    _v_72 = _o_1[12];
    _v_73 = _o_1[13];
    _v_74 = _o_1[14];
    _v_75 = _o_1[15];
    _v_76 = _o_1[16];
    _v_43 = _v_60;
    _v_44 = _v_61;
    _v_45 = _v_62;
    _v_46 = _v_63;
    _v_47 = _v_64;
    _v_48 = _v_65;
    _v_49 = _v_66;
    _v_50 = _v_67;
    _v_51 = _v_68;
    _v_52 = _v_69;
    _v_53 = _v_70;
    _v_54 = _v_71;
    _v_55 = _v_72;
    _v_56 = _v_73;
    _v_57 = _v_74;
    _v_58 = _v_75;
    _v_59 = _v_76;
  break;
  }
  o[0] = _v_43;
  o[1] = _v_44;
  o[2] = _v_45;
  o[3] = _v_46;
  o[4] = _v_47;
  o[5] = _v_48;
  o[6] = _v_49;
  o[7] = _v_50;
  o[8] = _v_51;
  o[9] = _v_52;
  o[10] = _v_53;
  o[11] = _v_54;
  o[12] = _v_55;
  o[13] = _v_56;
  o[14] = _v_57;
  o[15] = _v_58;
  o[16] = _v_59;
  return 1;
}

INLINE Term spin_67(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  Term _v_57 = 0;
  Term _v_58 = 0;
  u32 _v_59 = 0;
  u32 _clocked_0 = r0;
  u32 _clocked_1 = r1;
  u32 _clocked_2 = r2;
  Term _clocked_3 = r3;
  u32 _clocked_4 = r4;
  Term _clocked_5 = r5;
  Term _clocked_6 = r6;
  Term _clocked_7 = r7;
  Term _clocked_8 = r8;
  u32 _clocked_9 = r9;
  u32 _clocked_10 = r10;
  u32 _clocked_11 = r11;
  WL_SPIN
    _v_42 = _clocked_0;
    _v_43 = _clocked_1;
    _v_44 = _clocked_2;
    _v_45 = _clocked_3;
    _v_46 = _clocked_4;
    _v_47 = _clocked_5;
    _v_48 = _clocked_6;
    _v_49 = _clocked_7;
    _v_50 = _clocked_8;
    _v_51 = _clocked_9;
    _v_52 = _clocked_10;
    _v_53 = term_pak(CID_NIL, 0);
    _v_54 = term_pak(CID_NIL, 0);
    _v_55 = ((u64)_clocked_11);
    _v_56 = 0;
    _v_57 = 0;
    _v_58 = ((u64)65536ull);
    _v_59 = 1ull;
  break;
  }
  o[0] = _v_42;
  o[1] = _v_43;
  o[2] = _v_44;
  o[3] = _v_45;
  o[4] = _v_46;
  o[5] = _v_47;
  o[6] = _v_48;
  o[7] = _v_49;
  o[8] = _v_50;
  o[9] = _v_51;
  o[10] = _v_52;
  o[11] = _v_53;
  o[12] = _v_54;
  o[13] = _v_55;
  o[14] = _v_56;
  o[15] = _v_57;
  o[16] = _v_58;
  o[17] = _v_59;
  return 1;
}

INLINE Term spin_68(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, u32 r11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  Term _v_50 = 0;
  u32 _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  u32 _named_0 = r0;
  u32 _named_1 = r1;
  u32 _named_2 = r2;
  Term _named_3 = r3;
  u32 _named_4 = r4;
  Term _named_5 = r5;
  Term _named_6 = r6;
  Term _named_7 = r7;
  Term _named_8 = r8;
  u32 _named_9 = r9;
  u32 _named_10 = r10;
  u32 _named_11 = r11;
  Term _name_1 = r12;
  Term _access_1 = r13;
  WL_SPIN
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    _name_1 = term_keep(e, _name_1, 1);
    _access_1 = term_keep(e, _access_1, 1);
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    u32 _v_82 = 0;
    u32 _v_83 = 0;
    Term _o_1[13];
    if (spin_49(e, _o_1, _named_0, _named_1, _named_2, _named_3, _named_3 == h3 ? q3 : blk_loc(e.mem, _named_3), _named_4, _named_5, _named_6, _named_6 == h6 ? q6 : blk_loc(e.mem, _named_6), _named_7, _named_7 == h7 ? q7 : blk_loc(e.mem, _named_7), _named_8, _named_8 == h8 ? q8 : blk_loc(e.mem, _named_8), _named_9, _named_10, _name_1, _name_1 == h12 ? q12 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h13 ? q13 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_71 = _o_1[0];
    _v_72 = _o_1[1];
    _v_73 = _o_1[2];
    _v_74 = _o_1[3];
    _v_75 = _o_1[4];
    _v_76 = _o_1[5];
    _v_77 = _o_1[6];
    _v_78 = _o_1[7];
    _v_79 = _o_1[8];
    _v_80 = _o_1[9];
    _v_81 = _o_1[10];
    _v_82 = _o_1[11];
    _v_83 = _o_1[12];
    _v_58 = _v_71;
    _v_59 = _v_72;
    _v_60 = _v_73;
    _v_61 = _v_74;
    _v_62 = _v_75;
    _v_63 = _v_76;
    _v_64 = _v_77;
    _v_65 = _v_78;
    _v_66 = _v_79;
    _v_67 = _v_80;
    _v_68 = _v_81;
    _v_69 = _v_82;
    _v_70 = _v_83;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    u32 _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    Term _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    Term _o_2[17];
    if (spin_66(e, _o_2, _v_58, _v_59, _v_60, _v_61, _v_61 == h13 ? q13 : _v_61 == h12 ? q12 : _v_61 == h8 ? q8 : _v_61 == h7 ? q7 : _v_61 == h6 ? q6 : _v_61 == h3 ? q3 : blk_loc(e.mem, _v_61), _v_62, _v_63, _v_64, _v_64 == h13 ? q13 : _v_64 == h12 ? q12 : _v_64 == h8 ? q8 : _v_64 == h7 ? q7 : _v_64 == h6 ? q6 : _v_64 == h3 ? q3 : blk_loc(e.mem, _v_64), _v_65, _v_65 == h13 ? q13 : _v_65 == h12 ? q12 : _v_65 == h8 ? q8 : _v_65 == h7 ? q7 : _v_65 == h6 ? q6 : _v_65 == h3 ? q3 : blk_loc(e.mem, _v_65), _v_66, _v_66 == h13 ? q13 : _v_66 == h12 ? q12 : _v_66 == h8 ? q8 : _v_66 == h7 ? q7 : _v_66 == h6 ? q6 : _v_66 == h3 ? q3 : blk_loc(e.mem, _v_66), _v_67, _v_68, _v_69, _v_70, _named_11, _name_1, _name_1 == h12 ? q12 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h13 ? q13 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_84 = _o_2[0];
    _v_85 = _o_2[1];
    _v_86 = _o_2[2];
    _v_87 = _o_2[3];
    _v_88 = _o_2[4];
    _v_89 = _o_2[5];
    _v_90 = _o_2[6];
    _v_91 = _o_2[7];
    _v_92 = _o_2[8];
    _v_93 = _o_2[9];
    _v_94 = _o_2[10];
    _v_95 = _o_2[11];
    _v_96 = _o_2[12];
    _v_97 = _o_2[13];
    _v_98 = _o_2[14];
    _v_99 = _o_2[15];
    _v_100 = _o_2[16];
    _v_41 = _v_84;
    _v_42 = _v_85;
    _v_43 = _v_86;
    _v_44 = _v_87;
    _v_45 = _v_88;
    _v_46 = _v_89;
    _v_47 = _v_90;
    _v_48 = _v_91;
    _v_49 = _v_92;
    _v_50 = _v_93;
    _v_51 = _v_94;
    _v_52 = _v_95;
    _v_53 = _v_96;
    _v_54 = _v_97;
    _v_55 = _v_98;
    _v_56 = _v_99;
    _v_57 = _v_100;
  break;
  }
  o[0] = _v_41;
  o[1] = _v_42;
  o[2] = _v_43;
  o[3] = _v_44;
  o[4] = _v_45;
  o[5] = _v_46;
  o[6] = _v_47;
  o[7] = _v_48;
  o[8] = _v_49;
  o[9] = _v_50;
  o[10] = _v_51;
  o[11] = _v_52;
  o[12] = _v_53;
  o[13] = _v_54;
  o[14] = _v_55;
  o[15] = _v_56;
  o[16] = _v_57;
  return 1;
}

INLINE Term spin_69(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_56 = 0;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  Term _v_64 = 0;
  u32 _v_65 = 0;
  u32 _v_66 = 0;
  Term _v_67 = 0;
  Term _v_68 = 0;
  Term _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  Term _v_72 = 0;
  u32 _v_73 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  WL_SPIN
    u32 _v_74 = 0;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    u32 _v_83 = 0;
    u32 _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    Term _v_89 = 0;
    u32 _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    Term _v_93 = 0;
    Term _v_94 = 0;
    u32 _v_95 = 0;
    u32 _v_96 = 0;
    u32 _v_97 = 0;
    Term _o_0[12];
    if (spin_26(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_10) == 0) {
      return 0;
    }
    _v_86 = _o_0[0];
    _v_87 = _o_0[1];
    _v_88 = _o_0[2];
    _v_89 = _o_0[3];
    _v_90 = _o_0[4];
    _v_91 = _o_0[5];
    _v_92 = _o_0[6];
    _v_93 = _o_0[7];
    _v_94 = _o_0[8];
    _v_95 = _o_0[9];
    _v_96 = _o_0[10];
    _v_97 = _o_0[11];
    _v_74 = _v_86;
    _v_75 = _v_87;
    _v_76 = _v_88;
    _v_77 = _v_89;
    _v_78 = _v_90;
    _v_79 = _v_91;
    _v_80 = _v_92;
    _v_81 = _v_93;
    _v_82 = _v_94;
    _v_83 = _v_95;
    _v_84 = _v_96;
    _v_85 = _v_97;
    u32 _v_98 = 0;
    u32 _v_99 = 0;
    u32 _v_100 = 0;
    Term _v_101 = 0;
    u32 _v_102 = 0;
    Term _v_103 = 0;
    Term _v_104 = 0;
    Term _v_105 = 0;
    Term _v_106 = 0;
    u32 _v_107 = 0;
    u32 _v_108 = 0;
    Term _v_109 = 0;
    Term _v_110 = 0;
    Term _v_111 = 0;
    Term _v_112 = 0;
    Term _v_113 = 0;
    Term _v_114 = 0;
    u32 _v_115 = 0;
    Term _o_1[18];
    if (spin_67(e, _o_1, _v_74, _v_75, _v_76, _v_77, _v_77 == h8 ? q8 : _v_77 == h7 ? q7 : _v_77 == h6 ? q6 : _v_77 == h3 ? q3 : blk_loc(e.mem, _v_77), _v_78, _v_79, _v_80, _v_80 == h8 ? q8 : _v_80 == h7 ? q7 : _v_80 == h6 ? q6 : _v_80 == h3 ? q3 : blk_loc(e.mem, _v_80), _v_81, _v_81 == h8 ? q8 : _v_81 == h7 ? q7 : _v_81 == h6 ? q6 : _v_81 == h3 ? q3 : blk_loc(e.mem, _v_81), _v_82, _v_82 == h8 ? q8 : _v_82 == h7 ? q7 : _v_82 == h6 ? q6 : _v_82 == h3 ? q3 : blk_loc(e.mem, _v_82), _v_83, _v_84, _v_85) == 0) {
      return 0;
    }
    _v_98 = _o_1[0];
    _v_99 = _o_1[1];
    _v_100 = _o_1[2];
    _v_101 = _o_1[3];
    _v_102 = _o_1[4];
    _v_103 = _o_1[5];
    _v_104 = _o_1[6];
    _v_105 = _o_1[7];
    _v_106 = _o_1[8];
    _v_107 = _o_1[9];
    _v_108 = _o_1[10];
    _v_109 = _o_1[11];
    _v_110 = _o_1[12];
    _v_111 = _o_1[13];
    _v_112 = _o_1[14];
    _v_113 = _o_1[15];
    _v_114 = _o_1[16];
    _v_115 = _o_1[17];
    _v_56 = _v_98;
    _v_57 = _v_99;
    _v_58 = _v_100;
    _v_59 = _v_101;
    _v_60 = _v_102;
    _v_61 = _v_103;
    _v_62 = _v_104;
    _v_63 = _v_105;
    _v_64 = _v_106;
    _v_65 = _v_107;
    _v_66 = _v_108;
    _v_67 = _v_109;
    _v_68 = _v_110;
    _v_69 = _v_111;
    _v_70 = _v_112;
    _v_71 = _v_113;
    _v_72 = _v_114;
    _v_73 = _v_115;
  break;
  }
  o[0] = _v_56;
  o[1] = _v_57;
  o[2] = _v_58;
  o[3] = _v_59;
  o[4] = _v_60;
  o[5] = _v_61;
  o[6] = _v_62;
  o[7] = _v_63;
  o[8] = _v_64;
  o[9] = _v_65;
  o[10] = _v_66;
  o[11] = _v_67;
  o[12] = _v_68;
  o[13] = _v_69;
  o[14] = _v_70;
  o[15] = _v_71;
  o[16] = _v_72;
  o[17] = _v_73;
  return 1;
}

INLINE Term spin_70(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  u32 _v_25 = 0;
  u32 _available_0 = r0;
  u32 _namespace_0 = r1;
  WL_SPIN
    if (_available_0 == 0) {
      _v_13 = 1;
      _v_14 = _namespace_0;
      _v_15 = 0;
      _v_16 = 0;
      _v_17 = 0;
      _v_18 = 0;
      _v_19 = 0;
      _v_20 = 0;
      _v_21 = 0;
      _v_22 = 0;
      _v_23 = 0;
      _v_24 = 0;
      _v_25 = 0;
    } else {
      Term _fv_0[1];
      _fv_0[0] = 0;
      _v_13 = 0;
      _v_14 = U32_BIN(_namespace_0, +, 1ull);
      _v_15 = _namespace_0;
      _v_16 = 1ull;
      _v_17 = 0ull;
      _v_18 = blk_new(e, 0, 0, 0, 1, _fv_0);
      _v_19 = 1ull;
      _v_20 = 0;
      _v_21 = term_pak(CID_NIL, 0);
      _v_22 = term_pak(CID_NIL, 0);
      _v_23 = term_pak(CID_NIL, 0);
      _v_24 = 1ull;
      _v_25 = 0ull;
    }
  break;
  }
  o[0] = _v_13;
  o[1] = _v_14;
  o[2] = _v_15;
  o[3] = _v_16;
  o[4] = _v_17;
  o[5] = _v_18;
  o[6] = _v_19;
  o[7] = _v_20;
  o[8] = _v_21;
  o[9] = _v_22;
  o[10] = _v_23;
  o[11] = _v_24;
  o[12] = _v_25;
  return 1;
}

INLINE Term spin_71(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, u32 r10, Term r11, u64 q11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h11 = r11;
  Term h12 = r12;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  u32 _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  u32 _world_0 = r0;
  u32 _world_1 = r1;
  u32 _world_2 = r2;
  Term _world_3 = r3;
  u32 _world_4 = r4;
  Term _world_5 = r5;
  Term _world_6 = r6;
  Term _world_7 = r7;
  Term _world_8 = r8;
  u32 _world_9 = r9;
  u32 _world_10 = r10;
  Term _name_0 = r11;
  Term _access_0 = r12;
  WL_SPIN
    u32 _v_51 = 0;
    u32 _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    u32 _v_60 = 0;
    u32 _v_61 = 0;
    u32 _v_62 = 0;
    u32 _v_63 = 0;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    Term _o_0[12];
    if (spin_36(e, _o_0, _world_0, _world_1, _world_2, _world_3, _world_3 == h3 ? q3 : blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, _world_6 == h6 ? q6 : blk_loc(e.mem, _world_6), _world_7, _world_7 == h7 ? q7 : blk_loc(e.mem, _world_7), _world_8, _world_8 == h8 ? q8 : blk_loc(e.mem, _world_8), _world_9, _world_10) == 0) {
      return 0;
    }
    _v_63 = _o_0[0];
    _v_64 = _o_0[1];
    _v_65 = _o_0[2];
    _v_66 = _o_0[3];
    _v_67 = _o_0[4];
    _v_68 = _o_0[5];
    _v_69 = _o_0[6];
    _v_70 = _o_0[7];
    _v_71 = _o_0[8];
    _v_72 = _o_0[9];
    _v_73 = _o_0[10];
    _v_74 = _o_0[11];
    _v_51 = _v_63;
    _v_52 = _v_64;
    _v_53 = _v_65;
    _v_54 = _v_66;
    _v_55 = _v_67;
    _v_56 = _v_68;
    _v_57 = _v_69;
    _v_58 = _v_70;
    _v_59 = _v_71;
    _v_60 = _v_72;
    _v_61 = _v_73;
    _v_62 = _v_74;
    u32 _v_75 = 0;
    u32 _v_76 = 0;
    u32 _v_77 = 0;
    u32 _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    u32 _v_85 = 0;
    u32 _v_86 = 0;
    u32 _v_87 = 0;
    u32 _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    u32 _v_91 = 0;
    Term _o_1[17];
    if (spin_68(e, _o_1, _v_51, _v_52, _v_53, _v_54, _v_54 == h12 ? q12 : _v_54 == h11 ? q11 : _v_54 == h8 ? q8 : _v_54 == h7 ? q7 : _v_54 == h6 ? q6 : _v_54 == h3 ? q3 : blk_loc(e.mem, _v_54), _v_55, _v_56, _v_57, _v_57 == h12 ? q12 : _v_57 == h11 ? q11 : _v_57 == h8 ? q8 : _v_57 == h7 ? q7 : _v_57 == h6 ? q6 : _v_57 == h3 ? q3 : blk_loc(e.mem, _v_57), _v_58, _v_58 == h12 ? q12 : _v_58 == h11 ? q11 : _v_58 == h8 ? q8 : _v_58 == h7 ? q7 : _v_58 == h6 ? q6 : _v_58 == h3 ? q3 : blk_loc(e.mem, _v_58), _v_59, _v_59 == h12 ? q12 : _v_59 == h11 ? q11 : _v_59 == h8 ? q8 : _v_59 == h7 ? q7 : _v_59 == h6 ? q6 : _v_59 == h3 ? q3 : blk_loc(e.mem, _v_59), _v_60, _v_61, _v_62, _name_0, _name_0 == h11 ? q11 : blk_loc(e.mem, _name_0), _access_0, _access_0 == h12 ? q12 : blk_loc(e.mem, _access_0)) == 0) {
      return 0;
    }
    _v_75 = _o_1[0];
    _v_76 = _o_1[1];
    _v_77 = _o_1[2];
    _v_78 = _o_1[3];
    _v_79 = _o_1[4];
    _v_80 = _o_1[5];
    _v_81 = _o_1[6];
    _v_82 = _o_1[7];
    _v_83 = _o_1[8];
    _v_84 = _o_1[9];
    _v_85 = _o_1[10];
    _v_86 = _o_1[11];
    _v_87 = _o_1[12];
    _v_88 = _o_1[13];
    _v_89 = _o_1[14];
    _v_90 = _o_1[15];
    _v_91 = _o_1[16];
    _v_34 = _v_75;
    _v_35 = _v_76;
    _v_36 = _v_77;
    _v_37 = _v_78;
    _v_38 = _v_79;
    _v_39 = _v_80;
    _v_40 = _v_81;
    _v_41 = _v_82;
    _v_42 = _v_83;
    _v_43 = _v_84;
    _v_44 = _v_85;
    _v_45 = _v_86;
    _v_46 = _v_87;
    _v_47 = _v_88;
    _v_48 = _v_89;
    _v_49 = _v_90;
    _v_50 = _v_91;
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  o[7] = _v_41;
  o[8] = _v_42;
  o[9] = _v_43;
  o[10] = _v_44;
  o[11] = _v_45;
  o[12] = _v_46;
  o[13] = _v_47;
  o[14] = _v_48;
  o[15] = _v_49;
  o[16] = _v_50;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER)
  {
    Term _ids_0 = r0;
    u32 _wanted_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_ids_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _ids_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_0;
        STK(1) = _wanted_0;
        STK(2) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER_K4;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER_K4, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _wanted_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER_K4, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _wanted_0;
      _ids_0 = r0;
      _wanted_0 = r1;
      WL_AGAIN(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER_K4)
  {
    WL_POPN(2);
    u32 _f_2 = STK(0);
    u32 _wanted_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = ((U32_BIN(_f_2, ==, _wanted_1)) | (_h_0));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD)
  {
    Term _ids_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    _ids_0 = term_keep(e, _ids_0, 1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _ids_0;
      STK(1) = _id_0;
      STK(2) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD_K10;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD_K10, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _ids_0;
      e.mem[_t_0 + 1] = _id_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD_K10, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _ids_0;
      e.mem[_t_1 + 1] = _id_0;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER, _t_1);
    }
    r0 = _ids_0;
    r1 = _id_0;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_MEMBER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD_K10)
  {
    WL_POPN(2);
    Term _ids_1 = STK(0);
    u32 _id_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_3(e, _o_0, _h_0, _ids_1, blk_loc(e.mem, _ids_1), _id_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0)
  {
    u32 _same_0 = r0;
    u32 _domain_0 = r1;
    Term _domain_1 = r2;
    Term _domain_2 = r3;
    Term _domain_3 = r4;
    Term _domain_4 = r5;
    Term _domain_5 = r6;
    u32 _id_0 = r7;
    WL_OPEN
    if (_same_0 == 0) {
      r0 = _domain_0;
      r1 = _domain_1;
      r2 = _domain_2;
      r3 = _domain_3;
      r4 = _domain_4;
      r5 = _domain_5;
      WL_RETN(6);
    } else {
      if (seq) {
        WL_ROOM(6);
        STK(0) = _domain_0;
        STK(1) = _domain_1;
        STK(2) = _domain_2;
        STK(3) = _domain_3;
        STK(4) = _domain_4;
        STK(5) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0_K17;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0_K17, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _domain_0;
        e.mem[_t_0 + 1] = _domain_1;
        e.mem[_t_0 + 2] = _domain_2;
        e.mem[_t_0 + 3] = _domain_3;
        e.mem[_t_0 + 4] = _domain_4;
        WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0_K17, _t_0);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _domain_5;
        e.mem[_t_1 + 1] = _id_0;
        return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD, _t_1);
      }
      r0 = _domain_5;
      r1 = _id_0;
      WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ADD);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0_K17)
  {
    WL_POPN(5);
    u32 _domain_6 = STK(0);
    Term _domain_7 = STK(1);
    Term _domain_8 = STK(2);
    Term _domain_9 = STK(3);
    Term _domain_10 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    r0 = _domain_6;
    r1 = _domain_7;
    r2 = _domain_8;
    r3 = _domain_9;
    r4 = _domain_10;
    r5 = _h_0;
    WL_RETN(6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_ACCESS_EQUAL)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      if (term_aux(_ys_0) == CID_NIL) {
        r0 = 1;
        WL_RETN(1);
      } else {
        u64 _sp_0 = term_peek(e.mem, _ys_0);
        Term _f_0 = e.mem[_sp_0 + 0];
        Term _f_1 = e.mem[_sp_0 + 1];
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      u64 _sp_1 = term_peek(e.mem, _xs_0);
      Term _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      if (term_aux(_ys_0) == CID_NIL) {
        r0 = 0;
        WL_RETN(1);
      } else {
        u64 _sp_2 = term_peek(e.mem, _ys_0);
        Term _f_4 = e.mem[_sp_2 + 0];
        Term _f_5 = e.mem[_sp_2 + 1];
        if (seq) {
          WL_ROOM(3);
          STK(0) = _f_2;
          STK(1) = _f_4;
          STK(2) = FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K20;
          WL_PUSHN(3);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K20, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_2;
          e.mem[_t_0 + 1] = _f_4;
          WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K20, _t_0);
          WL_IDX = 2;
        }
        r0 = _f_3;
        r1 = _f_5;
        _xs_0 = r0;
        _ys_0 = r1;
        WL_AGAIN(FID__________SRC_ECS_WORLD_ACCESS_EQUAL);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K20)
  {
    WL_POPN(2);
    Term _f_6 = STK(0);
    Term _f_7 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_3[1];
    if (spin_9(e, _o_3, _f_6, blk_loc(e.mem, _f_6), _f_7, blk_loc(e.mem, _f_7)) == 0) {
      return 0;
    }
    _v_1 = _o_3[0];
    _v_0 = _v_1;
    u32 _v_9 = 0;
    Term _o_4[1];
    if (spin_8(e, _o_4, _v_0, _h_0) == 0) {
      return 0;
    }
    _v_9 = _o_4[0];
    r0 = _v_9;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0)
  {
    Term _batches_0 = r0;
    u32 _wanted_0 = r1;
    u32 _item_0 = r2;
    WL_OPEN
    if (term_aux(_batches_0) == CID_NIL) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _item_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _wanted_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PENDINGBATCH, _nd_1));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      r0 = term_ctr(CID_CON, _nd_2);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _batches_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_20(e, _o_0, _f_2, _wanted_0) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      _f_1 = term_keep(e, _f_1, 1);
      u64 _nd_3 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_3 + 0] = _f_1;
      e.mem[_nd_3 + 1] = _wanted_0;
      e.mem[_nd_3 + 2] = _item_0;
      if (_v_0 == 1) {
        Term _ih_0 = term_clo(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_C39, _nd_3);
        term_sink(e, _ih_0);
        u64 _nd_4 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_4 + 0] = rfc_seal(e, _item_0);
        e.mem[_nd_4 + 1] = rfc_seal(e, _f_3);
        u64 _nd_5 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_5 + 0] = rfc_seal(e, _f_2);
        e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_4));
        u64 _nd_6 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PENDINGBATCH, _nd_5));
        e.mem[_nd_6 + 1] = rfc_seal(e, _f_1);
        r0 = term_ctr(CID_CON, _nd_6);
        WL_RETN(1);
      } else {
        term_sink(e, _f_1);
        Term _ih_1 = term_clo(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_C39, _nd_3);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(3);
          STK(0) = _f_2;
          STK(1) = _f_3;
          STK(2) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_K40;
          WL_PUSHN(3);
        } else {
          u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_K40, WL_CONT, WL_IDX, 1);
          e.mem[_t_1 + 0] = _f_2;
          e.mem[_t_1 + 1] = _f_3;
          WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_K40, _t_1);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_2 + 0] = _ih_1;
          e.mem[_t_2 + 1] = term_pak(CID_UNIT, 0);
          return term_tsk(FID_CLO_APPLY, _t_2);
        }
        r0 = _ih_1;
        r1 = term_pak(CID_UNIT, 0);
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_C39)
  {
    Term _f_4 = r0;
    u32 _wanted_1 = r1;
    u32 _item_1 = r2;
    Term _x_0 = r3;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0)) {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _f_4;
      e.mem[_t_0 + 1] = _wanted_1;
      e.mem[_t_0 + 2] = _item_1;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0, _t_0);
    }
    r0 = _f_4;
    r1 = _wanted_1;
    r2 = _item_1;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0_K40)
  {
    WL_POPN(2);
    u32 _f_5 = STK(0);
    Term _f_6 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, _f_5);
    e.mem[_nd_7 + 1] = rfc_seal(e, _f_6);
    u64 _nd_8 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_8 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PENDINGBATCH, _nd_7));
    e.mem[_nd_8 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0)
  {
    Term _domains_0 = r0;
    u32 _wanted_0 = r1;
    Term _tick_0 = r2;
    Term _items_0 = r3;
    WL_OPEN
    if (term_aux(_domains_0) == CID_NIL) {
      Term _v_0 = 0;
      Term _v_1 = 0;
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _v_7 = 0;
      Term _o_0[4];
      Term _a_0 = term_pak(CID_NIL, 0);
      Term _a_1 = term_pak(CID_NIL, 0);
      if (spin_11(e, _o_0, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1), 0, 0, _tick_0, _items_0, blk_loc(e.mem, _items_0)) == 0) {
        return 0;
      }
      _v_4 = _o_0[0];
      _v_5 = _o_0[1];
      _v_6 = _o_0[2];
      _v_7 = _o_0[3];
      _v_0 = _v_4;
      _v_1 = _v_5;
      _v_2 = _v_6;
      _v_3 = _v_7;
      u64 _nd_0 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_0 + 0] = rfc_seal(e, _wanted_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _v_0);
      e.mem[_nd_0 + 2] = rfc_seal(e, _v_1);
      e.mem[_nd_0 + 3] = rfc_seal(e, _v_2);
      e.mem[_nd_0 + 4] = rfc_seal(e, _v_3);
      e.mem[_nd_0 + 5] = rfc_seal(e, term_pak(CID_NIL, 0));
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DOMAIN, _nd_0));
      e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      r0 = term_ctr(CID_CON, _nd_1);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _domains_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      Term _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      u32 _v_8 = 0;
      u32 _v_9 = 0;
      Term _o_1[1];
      if (spin_20(e, _o_1, _f_2, _wanted_0) == 0) {
        return 0;
      }
      _v_9 = _o_1[0];
      _v_8 = _v_9;
      _f_1 = term_keep(e, _f_1, 1);
      _items_0 = term_keep(e, _items_0, 1);
      u64 _nd_2 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_2 + 0] = _f_1;
      e.mem[_nd_2 + 1] = _wanted_0;
      e.mem[_nd_2 + 2] = _tick_0;
      e.mem[_nd_2 + 3] = _items_0;
      if (_v_8 == 1) {
        Term _ih_0 = term_clo(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_C42, _nd_2);
        term_sink(e, _ih_0);
        Term _v_10 = 0;
        Term _v_11 = 0;
        Term _v_12 = 0;
        Term _v_13 = 0;
        Term _v_14 = 0;
        Term _v_15 = 0;
        Term _v_16 = 0;
        Term _v_17 = 0;
        Term _o_2[4];
        if (spin_11(e, _o_2, _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_5, _f_6, _tick_0, _items_0, blk_loc(e.mem, _items_0)) == 0) {
          return 0;
        }
        _v_14 = _o_2[0];
        _v_15 = _o_2[1];
        _v_16 = _o_2[2];
        _v_17 = _o_2[3];
        _v_10 = _v_14;
        _v_11 = _v_15;
        _v_12 = _v_16;
        _v_13 = _v_17;
        u64 _nd_3 = heap_alloc(e, cls_fit(6));
        e.mem[_nd_3 + 0] = rfc_seal(e, _f_2);
        e.mem[_nd_3 + 1] = rfc_seal(e, _v_10);
        e.mem[_nd_3 + 2] = rfc_seal(e, _v_11);
        e.mem[_nd_3 + 3] = rfc_seal(e, _v_12);
        e.mem[_nd_3 + 4] = rfc_seal(e, _v_13);
        e.mem[_nd_3 + 5] = rfc_seal(e, _f_7);
        u64 _nd_4 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DOMAIN, _nd_3));
        e.mem[_nd_4 + 1] = rfc_seal(e, _f_1);
        r0 = term_ctr(CID_CON, _nd_4);
        WL_RETN(1);
      } else {
        term_sink(e, _f_1);
        term_sink(e, _items_0);
        Term _ih_1 = term_clo(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_C42, _nd_2);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(7);
          STK(0) = _f_2;
          STK(1) = _f_3;
          STK(2) = _f_4;
          STK(3) = _f_5;
          STK(4) = _f_6;
          STK(5) = _f_7;
          STK(6) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_K43;
          WL_PUSHN(7);
        } else {
          u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_K43, WL_CONT, WL_IDX, 1);
          e.mem[_t_1 + 0] = _f_2;
          e.mem[_t_1 + 1] = _f_3;
          e.mem[_t_1 + 2] = _f_4;
          e.mem[_t_1 + 3] = _f_5;
          e.mem[_t_1 + 4] = _f_6;
          e.mem[_t_1 + 5] = _f_7;
          WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_K43, _t_1);
          WL_IDX = 6;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_2 + 0] = _ih_1;
          e.mem[_t_2 + 1] = term_pak(CID_UNIT, 0);
          return term_tsk(FID_CLO_APPLY, _t_2);
        }
        r0 = _ih_1;
        r1 = term_pak(CID_UNIT, 0);
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_C42)
  {
    Term _f_8 = r0;
    u32 _wanted_1 = r1;
    Term _tick_1 = r2;
    Term _items_1 = r3;
    Term _x_0 = r4;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0)) {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _f_8;
      e.mem[_t_0 + 1] = _wanted_1;
      e.mem[_t_0 + 2] = _tick_1;
      e.mem[_t_0 + 3] = _items_1;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0, _t_0);
    }
    r0 = _f_8;
    r1 = _wanted_1;
    r2 = _tick_1;
    r3 = _items_1;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0_K43)
  {
    WL_POPN(6);
    u32 _f_9 = STK(0);
    Term _f_10 = STK(1);
    Term _f_11 = STK(2);
    Term _f_12 = STK(3);
    Term _f_13 = STK(4);
    Term _f_14 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_5 + 0] = rfc_seal(e, _f_9);
    e.mem[_nd_5 + 1] = rfc_seal(e, _f_10);
    e.mem[_nd_5 + 2] = rfc_seal(e, _f_11);
    e.mem[_nd_5 + 3] = rfc_seal(e, _f_12);
    e.mem[_nd_5 + 4] = rfc_seal(e, _f_13);
    e.mem[_nd_5 + 5] = rfc_seal(e, _f_14);
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DOMAIN, _nd_5));
    e.mem[_nd_6 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0)
  {
    Term _domains_0 = r0;
    u32 _wanted_0 = r1;
    u32 _id_0 = r2;
    WL_OPEN
    if (term_aux(_domains_0) == CID_NIL) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _id_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      u64 _nd_1 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_1 + 0] = rfc_seal(e, _wanted_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      e.mem[_nd_1 + 2] = rfc_seal(e, term_pak(CID_NIL, 0));
      e.mem[_nd_1 + 3] = rfc_seal(e, 0);
      e.mem[_nd_1 + 4] = rfc_seal(e, 0);
      e.mem[_nd_1 + 5] = rfc_seal(e, term_ctr(CID_CON, _nd_0));
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DOMAIN, _nd_1));
      e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      r0 = term_ctr(CID_CON, _nd_2);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _domains_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      Term _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_20(e, _o_0, _f_2, _wanted_0) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      _f_1 = term_keep(e, _f_1, 1);
      u64 _nd_3 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_3 + 0] = _f_1;
      e.mem[_nd_3 + 1] = _wanted_0;
      e.mem[_nd_3 + 2] = _id_0;
      if (_v_0 == 1) {
        Term _ih_0 = term_clo(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_C50, _nd_3);
        term_sink(e, _ih_0);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K51;
          WL_PUSHN(2);
        } else {
          u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K51, WL_CONT, WL_IDX, 1);
          e.mem[_t_1 + 0] = _f_1;
          WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K51, _t_1);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0)) {
          u64 _t_2 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_2 + 0] = 1;
          e.mem[_t_2 + 1] = _f_2;
          e.mem[_t_2 + 2] = _f_3;
          e.mem[_t_2 + 3] = _f_4;
          e.mem[_t_2 + 4] = _f_5;
          e.mem[_t_2 + 5] = _f_6;
          e.mem[_t_2 + 6] = _f_7;
          e.mem[_t_2 + 7] = _id_0;
          return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0, _t_2);
        }
        r0 = 1;
        r1 = _f_2;
        r2 = _f_3;
        r3 = _f_4;
        r4 = _f_5;
        r5 = _f_6;
        r6 = _f_7;
        r7 = _id_0;
        WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_DOMAIN_0);
      } else {
        term_sink(e, _f_1);
        Term _ih_1 = term_clo(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_C50, _nd_3);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(7);
          STK(0) = _f_2;
          STK(1) = _f_3;
          STK(2) = _f_4;
          STK(3) = _f_5;
          STK(4) = _f_6;
          STK(5) = _f_7;
          STK(6) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K52;
          WL_PUSHN(7);
        } else {
          u64 _t_3 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K52, WL_CONT, WL_IDX, 1);
          e.mem[_t_3 + 0] = _f_2;
          e.mem[_t_3 + 1] = _f_3;
          e.mem[_t_3 + 2] = _f_4;
          e.mem[_t_3 + 3] = _f_5;
          e.mem[_t_3 + 4] = _f_6;
          e.mem[_t_3 + 5] = _f_7;
          WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K52, _t_3);
          WL_IDX = 6;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_4 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_4 + 0] = _ih_1;
          e.mem[_t_4 + 1] = term_pak(CID_UNIT, 0);
          return term_tsk(FID_CLO_APPLY, _t_4);
        }
        r0 = _ih_1;
        r1 = term_pak(CID_UNIT, 0);
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_C50)
  {
    Term _f_8 = r0;
    u32 _wanted_1 = r1;
    u32 _id_1 = r2;
    Term _x_0 = r3;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0)) {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _f_8;
      e.mem[_t_0 + 1] = _wanted_1;
      e.mem[_t_0 + 2] = _id_1;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0, _t_0);
    }
    r0 = _f_8;
    r1 = _wanted_1;
    r2 = _id_1;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K51)
  {
    WL_POPN(1);
    Term _f_9 = STK(0);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_4 + 0] = rfc_seal(e, _h_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _h_1);
    e.mem[_nd_4 + 2] = rfc_seal(e, _h_2);
    e.mem[_nd_4 + 3] = rfc_seal(e, _h_3);
    e.mem[_nd_4 + 4] = rfc_seal(e, _h_4);
    e.mem[_nd_4 + 5] = rfc_seal(e, _h_5);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DOMAIN, _nd_4));
    e.mem[_nd_5 + 1] = rfc_seal(e, _f_9);
    r0 = term_ctr(CID_CON, _nd_5);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0_K52)
  {
    WL_POPN(6);
    u32 _f_10 = STK(0);
    Term _f_11 = STK(1);
    Term _f_12 = STK(2);
    Term _f_13 = STK(3);
    Term _f_14 = STK(4);
    Term _f_15 = STK(5);
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_6 + 0] = rfc_seal(e, _f_10);
    e.mem[_nd_6 + 1] = rfc_seal(e, _f_11);
    e.mem[_nd_6 + 2] = rfc_seal(e, _f_12);
    e.mem[_nd_6 + 3] = rfc_seal(e, _f_13);
    e.mem[_nd_6 + 4] = rfc_seal(e, _f_14);
    e.mem[_nd_6 + 5] = rfc_seal(e, _f_15);
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DOMAIN, _nd_6));
    e.mem[_nd_7 + 1] = rfc_seal(e, _h_6);
    r0 = term_ctr(CID_CON, _nd_7);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_REGISTRATION_WITHOUT)
  {
    Term _registrations_0 = r0;
    u32 _id_0 = r1;
    Term _name_0 = r2;
    Term _access_0 = r3;
    WL_OPEN
    if (term_aux(_registrations_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _registrations_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(8);
        STK(0) = _f_2;
        STK(1) = _f_3;
        STK(2) = _f_4;
        STK(3) = _f_1;
        STK(4) = _id_0;
        STK(5) = _name_0;
        STK(6) = _access_0;
        STK(7) = FID__________SRC_ECS_REGISTRATION_WITHOUT_K54;
        WL_PUSHN(8);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_REGISTRATION_WITHOUT_K54, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_2;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _f_4;
        e.mem[_t_0 + 3] = _f_1;
        e.mem[_t_0 + 4] = _id_0;
        e.mem[_t_0 + 5] = _name_0;
        e.mem[_t_0 + 6] = _access_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_REGISTRATION_WITHOUT_K54, _t_0);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _id_0;
        e.mem[_t_1 + 4] = _name_0;
        e.mem[_t_1 + 5] = _access_0;
        return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _id_0;
      r4 = _name_0;
      r5 = _access_0;
      WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_REGISTRATION_WITHOUT_K54)
  {
    WL_POPN(7);
    u32 _f_5 = STK(0);
    Term _f_6 = STK(1);
    Term _f_7 = STK(2);
    Term _f_8 = STK(3);
    u32 _id_1 = STK(4);
    Term _name_1 = STK(5);
    Term _access_1 = STK(6);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(5);
      STK(0) = _f_5;
      STK(1) = _f_6;
      STK(2) = _f_7;
      STK(3) = _h_0;
      STK(4) = FID__________SRC_ECS_REGISTRATION_WITHOUT_K55;
      WL_PUSHN(5);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_REGISTRATION_WITHOUT_K55, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _f_6;
      e.mem[_t_2 + 2] = _f_7;
      e.mem[_t_2 + 3] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_REGISTRATION_WITHOUT_K55, _t_2);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_REGISTRATION_WITHOUT)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_REGISTRATION_WITHOUT, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_8;
      e.mem[_t_3 + 1] = _id_1;
      e.mem[_t_3 + 2] = _name_1;
      e.mem[_t_3 + 3] = _access_1;
      return term_tsk(FID__________SRC_ECS_REGISTRATION_WITHOUT, _t_3);
    }
    r0 = _f_8;
    r1 = _id_1;
    r2 = _name_1;
    r3 = _access_1;
    WL_JMP(FID__________SRC_ECS_REGISTRATION_WITHOUT);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_REGISTRATION_WITHOUT_K55)
  {
    WL_POPN(4);
    u32 _f_9 = STK(0);
    Term _f_10 = STK(1);
    Term _f_11 = STK(2);
    u32 _h_2 = STK(3);
    Term _h_1 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_23(e, _o_0, _h_2) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    Term _v_3 = 0;
    Term _o_1[1];
    if (spin_24(e, _o_1, _v_0, _f_9, _f_10, blk_loc(e.mem, _f_10), _f_11, blk_loc(e.mem, _f_11), _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_3 = _o_1[0];
    r0 = _v_3;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0)
  {
    u32 _key_0 = r0;
    u32 _key_1 = r1;
    u32 _item_0 = r2;
    Term _ordinary_0 = r3;
    Term _batches_0 = r4;
    WL_OPEN
    if (_key_0 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _item_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _ordinary_0);
      r0 = term_ctr(CID_CON, _nd_0);
      r1 = _batches_0;
      WL_RETN(2);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _ordinary_0;
        STK(1) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0_K67;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0_K67, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _ordinary_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0_K67, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _batches_0;
        e.mem[_t_1 + 1] = _key_1;
        e.mem[_t_1 + 2] = _item_0;
        return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0, _t_1);
      }
      r0 = _batches_0;
      r1 = _key_1;
      r2 = _item_0;
      WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_GROUP_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0_K67)
  {
    WL_POPN(1);
    Term _ordinary_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    r0 = _ordinary_1;
    r1 = _h_0;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0)
  {
    Term _batches_0 = r0;
    Term _tick_0 = r1;
    Term _domains_0 = r2;
    WL_OPEN
    if (term_aux(_batches_0) == CID_NIL) {
      r0 = _domains_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _batches_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      Term _v_0 = 0;
      Term _v_1 = 0;
      Term _o_0[1];
      if (spin_17(e, _o_0, _f_3, blk_loc(e.mem, _f_3)) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_1;
        STK(1) = _tick_0;
        STK(2) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0_K69;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0_K69, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _tick_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0_K69, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _domains_0;
        e.mem[_t_1 + 1] = _f_2;
        e.mem[_t_1 + 2] = _tick_0;
        e.mem[_t_1 + 3] = _v_0;
        return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0, _t_1);
      }
      r0 = _domains_0;
      r1 = _f_2;
      r2 = _tick_0;
      r3 = _v_0;
      WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_ONE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0_K69)
  {
    WL_POPN(2);
    Term _f_4 = STK(0);
    Term _tick_1 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_4;
      e.mem[_t_2 + 1] = _tick_1;
      e.mem[_t_2 + 2] = _h_0;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0, _t_2);
    }
    r0 = _f_4;
    r1 = _tick_1;
    r2 = _h_0;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE)
  {
    Term _positions_0 = r0;
    u32 _id_0 = r1;
    Term _registered_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _positions_0;
      STK(1) = _id_0;
      STK(2) = _registered_0;
      STK(3) = FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE_K77;
      WL_PUSHN(4);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE_K77, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _positions_0;
      e.mem[_t_0 + 1] = _id_0;
      e.mem[_t_0 + 2] = _registered_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE_K77, _t_0);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _positions_0;
      e.mem[_t_1 + 1] = _id_0;
      return term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP, _t_1);
    }
    r0 = _positions_0;
    r1 = _id_0;
    WL_JMP(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE_K77)
  {
    WL_POPN(3);
    Term _positions_1 = STK(0);
    u32 _id_1 = STK(1);
    Term _registered_1 = STK(2);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_28(e, _o_0, _h_0, _h_1, _h_2, _h_3, _positions_1, blk_loc(e.mem, _positions_1), _id_1, _registered_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0)
  {
    Term _keys_0 = r0;
    Term _domains_0 = r1;
    u32 _id_0 = r2;
    WL_OPEN
    if (term_aux(_keys_0) == CID_NIL) {
      r0 = _domains_0;
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _keys_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u32 _key_0 = term_loc(_f_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_1;
        STK(1) = _id_0;
        STK(2) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0_K79;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0_K79, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _id_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0_K79, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _domains_0;
        e.mem[_t_1 + 1] = _key_0;
        e.mem[_t_1 + 2] = _id_0;
        return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0, _t_1);
      }
      r0 = _domains_0;
      r1 = _key_0;
      r2 = _id_0;
      WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_ACTIVATE_ONE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0_K79)
  {
    WL_POPN(2);
    Term _f_2 = STK(0);
    u32 _id_1 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _id_1;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0, _t_2);
    }
    r0 = _f_2;
    r1 = _h_0;
    r2 = _id_1;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE)
  {
    Term _ids_0 = r0;
    u32 _wanted_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_ids_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _ids_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_0;
        STK(1) = _wanted_0;
        STK(2) = FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE_K86;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE_K86, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _wanted_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE_K86, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _wanted_0;
      _ids_0 = r0;
      _wanted_0 = r1;
      WL_AGAIN(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE_K86)
  {
    WL_POPN(2);
    u32 _f_2 = STK(0);
    u32 _wanted_1 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_30(e, _o_0, U32_BIN(_f_2, ==, _wanted_1), _f_2, _h_0, blk_loc(e.mem, _h_0)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES)
  {
    u32 _meta_0 = r0;
    Term _meta_1 = r1;
    Term _meta_2 = r2;
    u32 _id_0 = r3;
    Term _name_0 = r4;
    Term _access_0 = r5;
    WL_OPEN
    u32 _s_0 = U32_BIN(_meta_0, ==, _id_0);
    if (_s_0 == 0) {
      r0 = 0;
      WL_RETN(1);
    } else {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_9(e, _o_0, _meta_1, blk_loc(e.mem, _meta_1), _name_0, blk_loc(e.mem, _name_0)) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      if (_v_0 == 0) {
        r0 = 0;
        WL_RETN(1);
      } else {
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_ACCESS_EQUAL)) {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_ACCESS_EQUAL, WL_CONT, WL_IDX, 0);
          e.mem[_t_0 + 0] = _meta_2;
          e.mem[_t_0 + 1] = _access_0;
          return term_tsk(FID__________SRC_ECS_WORLD_ACCESS_EQUAL, _t_0);
        }
        r0 = _meta_2;
        r1 = _access_0;
        WL_JMP(FID__________SRC_ECS_WORLD_ACCESS_EQUAL);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0)
  {
    Term _items_0 = r0;
    Term _acc_0 = r1;
    Term _acc_1 = r2;
    WL_OPEN
    if (term_aux(_items_0) == CID_NIL) {
      r0 = _acc_0;
      r1 = _acc_1;
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      u32 _v_3 = 0;
      Term _o_0[2];
      if (spin_33(e, _o_0, _f_0) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      _v_3 = _o_0[1];
      _v_0 = _v_2;
      _v_1 = _v_3;
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0_K97;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0_K97, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0_K97, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = _v_1;
        e.mem[_t_1 + 2] = _f_0;
        e.mem[_t_1 + 3] = _acc_0;
        e.mem[_t_1 + 4] = _acc_1;
        return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0, _t_1);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _f_0;
      r3 = _acc_0;
      r4 = _acc_1;
      WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_SELECTED_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0_K97)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _h_0;
      e.mem[_t_2 + 2] = _h_1;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0, _t_2);
    }
    r0 = _f_2;
    r1 = _h_0;
    r2 = _h_1;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SYSTEM_RUN_0)
  {
    u32 _registry_0 = r0;
    u32 _registry_1 = r1;
    Term _registry_2 = r2;
    Term _registry_3 = r3;
    u32 _registry_4 = r4;
    u32 _world_0 = r5;
    u32 _world_1 = r6;
    u32 _world_2 = r7;
    Term _world_3 = r8;
    u32 _world_4 = r9;
    Term _world_5 = r10;
    Term _world_6 = r11;
    Term _world_7 = r12;
    Term _world_8 = r13;
    u32 _world_9 = r14;
    u32 _world_10 = r15;
    Term _args_0 = r16;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _o_0[12];
    if (spin_36(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, _world_10) == 0) {
      return 0;
    }
    _v_12 = _o_0[0];
    _v_13 = _o_0[1];
    _v_14 = _o_0[2];
    _v_15 = _o_0[3];
    _v_16 = _o_0[4];
    _v_17 = _o_0[5];
    _v_18 = _o_0[6];
    _v_19 = _o_0[7];
    _v_20 = _o_0[8];
    _v_21 = _o_0[9];
    _v_22 = _o_0[10];
    _v_23 = _o_0[11];
    _v_0 = _v_12;
    _v_1 = _v_13;
    _v_2 = _v_14;
    _v_3 = _v_15;
    _v_4 = _v_16;
    _v_5 = _v_17;
    _v_6 = _v_18;
    _v_7 = _v_19;
    _v_8 = _v_20;
    _v_9 = _v_21;
    _v_10 = _v_22;
    _v_11 = _v_23;
    u32 _s_0 = U32_BIN(_registry_0, ==, _v_11);
    if (_s_0 == 0) {
      r0 = 1;
      r1 = _registry_0;
      r2 = _registry_1;
      r3 = _registry_2;
      r4 = _registry_3;
      r5 = _registry_4;
      r6 = _v_0;
      r7 = _v_1;
      r8 = _v_2;
      r9 = _v_3;
      r10 = _v_4;
      r11 = _v_5;
      r12 = _v_6;
      r13 = _v_7;
      r14 = _v_8;
      r15 = _v_9;
      r16 = _v_10;
      r17 = _args_0;
      r18 = 0;
      WL_RETN(19);
    } else {
      _registry_2 = term_keep(e, _registry_2, 1);
      _registry_3 = term_keep(e, _registry_3, 1);
      if (seq) {
        WL_ROOM(7);
        STK(0) = _registry_0;
        STK(1) = _registry_1;
        STK(2) = _registry_2;
        STK(3) = _registry_3;
        STK(4) = _registry_4;
        STK(5) = _args_0;
        STK(6) = FID__________SRC_ECS_SYSTEM_RUN_0_K105;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_SYSTEM_RUN_0_K105, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _registry_0;
        e.mem[_t_0 + 1] = _registry_1;
        e.mem[_t_0 + 2] = _registry_2;
        e.mem[_t_0 + 3] = _registry_3;
        e.mem[_t_0 + 4] = _registry_4;
        e.mem[_t_0 + 5] = _args_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_SYSTEM_RUN_0_K105, _t_0);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = _v_1;
        e.mem[_t_1 + 2] = _v_2;
        e.mem[_t_1 + 3] = _v_3;
        e.mem[_t_1 + 4] = _v_4;
        e.mem[_t_1 + 5] = _v_5;
        e.mem[_t_1 + 6] = _v_6;
        e.mem[_t_1 + 7] = _v_7;
        e.mem[_t_1 + 8] = _v_8;
        e.mem[_t_1 + 9] = _v_9;
        e.mem[_t_1 + 10] = _v_10;
        e.mem[_t_1 + 11] = _registry_1;
        e.mem[_t_1 + 12] = _registry_2;
        e.mem[_t_1 + 13] = _registry_3;
        return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0, _t_1);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _v_5;
      r6 = _v_6;
      r7 = _v_7;
      r8 = _v_8;
      r9 = _v_9;
      r10 = _v_10;
      r11 = _registry_1;
      r12 = _registry_2;
      r13 = _registry_3;
      WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SYSTEM_RUN_0_K105)
  {
    WL_POPN(6);
    u32 _registry_5 = STK(0);
    u32 _registry_6 = STK(1);
    Term _registry_7 = STK(2);
    Term _registry_8 = STK(3);
    u32 _registry_9 = STK(4);
    Term _args_1 = STK(5);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    WL_OPEN
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    u32 _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    u32 _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    Term _o_1[19];
    if (spin_19(e, _o_1, _registry_5, _registry_6, _registry_7, blk_loc(e.mem, _registry_7), _registry_8, blk_loc(e.mem, _registry_8), _registry_9, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, _h_5, _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, _h_10, _h_11, _args_1, blk_loc(e.mem, _args_1)) == 0) {
      return 0;
    }
    _v_36 = _o_1[0];
    _v_37 = _o_1[1];
    _v_38 = _o_1[2];
    _v_39 = _o_1[3];
    _v_40 = _o_1[4];
    _v_41 = _o_1[5];
    _v_42 = _o_1[6];
    _v_43 = _o_1[7];
    _v_44 = _o_1[8];
    _v_45 = _o_1[9];
    _v_46 = _o_1[10];
    _v_47 = _o_1[11];
    _v_48 = _o_1[12];
    _v_49 = _o_1[13];
    _v_50 = _o_1[14];
    _v_51 = _o_1[15];
    _v_52 = _o_1[16];
    _v_53 = _o_1[17];
    _v_54 = _o_1[18];
    r0 = _v_36;
    r1 = _v_37;
    r2 = _v_38;
    r3 = _v_39;
    r4 = _v_40;
    r5 = _v_41;
    r6 = _v_42;
    r7 = _v_43;
    r8 = _v_44;
    r9 = _v_45;
    r10 = _v_46;
    r11 = _v_47;
    r12 = _v_48;
    r13 = _v_49;
    r14 = _v_50;
    r15 = _v_51;
    r16 = _v_52;
    r17 = _v_53;
    r18 = _v_54;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW_FIN)
  {
    Term _g_0 = r0;
    Term _acc_0 = r1;
    u32 _dq_0 = r2;
    Term _dq_1 = r3;
    WL_OPEN
    WL_SPIN
    if (_dq_1 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = term_ctr(CID_SCON, _nd_0);
      WL_RETN(1);
    } else {
      Term _p_0 = (_dq_1 - 1);
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _dq_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _acc_0);
      if (_g_0 == 0) {
        Term _n_0 = nat_chk(e, _p_0 + 1);
        Term _acc_1 = term_ctr(CID_SCON, _nd_1);
        r0 = _acc_1;
        WL_RETN(1);
      } else {
        Term _g_1 = (_g_0 - 1);
        Term _n_1 = nat_chk(e, _p_0 + 1);
        Term _acc_2 = term_ctr(CID_SCON, _nd_1);
        u32 _v_0 = 0;
        Term _v_1 = 0;
        Term _a_0 = 10ull;
        Term _a_1 = (_a_0 == 0 ? 0 : _n_1 / _a_0);
        Term _a_2 = (_a_0 == 0 ? _n_1 : _n_1 % _a_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        Term _o_0[2];
        if (spin_29(e, _o_0, _a_1, _a_2) == 0) {
          return 0;
        }
        _v_2 = _o_0[0];
        _v_3 = _o_0[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        r0 = _g_1;
        r1 = _acc_2;
        r2 = _v_0;
        r3 = _v_1;
        _g_0 = r0;
        _acc_0 = r1;
        _dq_0 = r2;
        _dq_1 = r3;
        WL_AGAIN(FID_NAT_SHOW_FIN);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_REGISTRATION_REMOVE_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    u32 _world_9 = r9;
    u32 _world_10 = r10;
    u32 _namespace_0 = r11;
    u32 _id_0 = r12;
    Term _name_0 = r13;
    Term _access_0 = r14;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_10;
      STK(11) = _namespace_0;
      STK(12) = _id_0;
      STK(13) = _name_0;
      STK(14) = _access_0;
      STK(15) = FID__________SRC_ECS_REGISTRATION_REMOVE_0_K119;
      WL_PUSHN(16);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_REGISTRATION_REMOVE_0_K119, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _namespace_0;
      e.mem[_t_0 + 12] = _id_0;
      e.mem[_t_0 + 13] = _name_0;
      e.mem[_t_0 + 14] = _access_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_REGISTRATION_REMOVE_0_K119, _t_0);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_8;
      e.mem[_t_1 + 1] = _id_0;
      e.mem[_t_1 + 2] = _name_0;
      e.mem[_t_1 + 3] = _access_0;
      return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, _t_1);
    }
    r0 = _world_8;
    r1 = _id_0;
    r2 = _name_0;
    r3 = _access_0;
    WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_REGISTRATION_REMOVE_0_K119)
  {
    WL_POPN(15);
    u32 _world_11 = STK(0);
    u32 _world_12 = STK(1);
    u32 _world_13 = STK(2);
    Term _world_14 = STK(3);
    u32 _world_15 = STK(4);
    Term _world_16 = STK(5);
    Term _world_17 = STK(6);
    Term _world_18 = STK(7);
    Term _world_19 = STK(8);
    u32 _world_20 = STK(9);
    u32 _world_21 = STK(10);
    u32 _namespace_1 = STK(11);
    u32 _id_1 = STK(12);
    Term _name_1 = STK(13);
    Term _access_1 = STK(14);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_8(e, _o_0, U32_BIN(_namespace_1, ==, _world_11), _h_0) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (_v_0 == 0) {
      r0 = _world_11;
      r1 = _world_12;
      r2 = _world_13;
      r3 = _world_14;
      r4 = _world_15;
      r5 = _world_16;
      r6 = _world_17;
      r7 = _world_18;
      r8 = _world_19;
      r9 = _world_20;
      r10 = _world_21;
      r11 = 0;
      WL_RETN(12);
    } else {
      if (seq) {
        WL_ROOM(11);
        STK(0) = _world_11;
        STK(1) = _world_12;
        STK(2) = _world_13;
        STK(3) = _world_14;
        STK(4) = _world_15;
        STK(5) = _world_16;
        STK(6) = _world_17;
        STK(7) = _world_18;
        STK(8) = _world_20;
        STK(9) = _world_21;
        STK(10) = FID__________SRC_ECS_REGISTRATION_REMOVE_0_K120;
        WL_PUSHN(11);
      } else {
        u64 _t_2 = task_node(e, FID__________SRC_ECS_REGISTRATION_REMOVE_0_K120, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _world_11;
        e.mem[_t_2 + 1] = _world_12;
        e.mem[_t_2 + 2] = _world_13;
        e.mem[_t_2 + 3] = _world_14;
        e.mem[_t_2 + 4] = _world_15;
        e.mem[_t_2 + 5] = _world_16;
        e.mem[_t_2 + 6] = _world_17;
        e.mem[_t_2 + 7] = _world_18;
        e.mem[_t_2 + 8] = _world_20;
        e.mem[_t_2 + 9] = _world_21;
        WL_CONT = term_tsk(FID__________SRC_ECS_REGISTRATION_REMOVE_0_K120, _t_2);
        WL_IDX = 10;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_REGISTRATION_WITHOUT)) {
        u64 _t_3 = task_node(e, FID__________SRC_ECS_REGISTRATION_WITHOUT, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _world_19;
        e.mem[_t_3 + 1] = _id_1;
        e.mem[_t_3 + 2] = _name_1;
        e.mem[_t_3 + 3] = _access_1;
        return term_tsk(FID__________SRC_ECS_REGISTRATION_WITHOUT, _t_3);
      }
      r0 = _world_19;
      r1 = _id_1;
      r2 = _name_1;
      r3 = _access_1;
      WL_JMP(FID__________SRC_ECS_REGISTRATION_WITHOUT);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_REGISTRATION_REMOVE_0_K120)
  {
    WL_POPN(10);
    u32 _world_22 = STK(0);
    u32 _world_23 = STK(1);
    u32 _world_24 = STK(2);
    Term _world_25 = STK(3);
    u32 _world_26 = STK(4);
    Term _world_27 = STK(5);
    Term _world_28 = STK(6);
    Term _world_29 = STK(7);
    u32 _world_30 = STK(8);
    u32 _world_31 = STK(9);
    Term _h_1 = r0;
    WL_OPEN
    r0 = _world_22;
    r1 = _world_23;
    r2 = _world_24;
    r3 = _world_25;
    r4 = _world_26;
    r5 = _world_27;
    r6 = _world_28;
    r7 = _world_29;
    r8 = _h_1;
    r9 = _world_30;
    r10 = _world_31;
    r11 = 1;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE)
  {
    Term _positions_0 = r0;
    u32 _id_0 = r1;
    Term _cursor_0 = r2;
    u32 _dispose_0 = r3;
    WL_OPEN
    WL_SPIN
    if (term_aux(_positions_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _positions_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(7);
        STK(0) = _f_2;
        STK(1) = _f_3;
        STK(2) = _f_4;
        STK(3) = _id_0;
        STK(4) = _cursor_0;
        STK(5) = _dispose_0;
        STK(6) = FID__________SRC_ECS_EVENT_RUNTIME_UPDATE_K123;
        WL_PUSHN(7);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_UPDATE_K123, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_2;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _f_4;
        e.mem[_t_0 + 3] = _id_0;
        e.mem[_t_0 + 4] = _cursor_0;
        e.mem[_t_0 + 5] = _dispose_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE_K123, _t_0);
        WL_IDX = 6;
      }
      r0 = _f_1;
      r1 = _id_0;
      r2 = _cursor_0;
      r3 = _dispose_0;
      _positions_0 = r0;
      _id_0 = r1;
      _cursor_0 = r2;
      _dispose_0 = r3;
      WL_AGAIN(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE_K123)
  {
    WL_POPN(6);
    u32 _f_5 = STK(0);
    Term _f_6 = STK(1);
    Term _f_7 = STK(2);
    u32 _id_1 = STK(3);
    Term _cursor_1 = STK(4);
    u32 _dispose_1 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_39(e, _o_0, U32_BIN(_f_5, ==, _id_1), _dispose_1, _f_5, _f_6, _f_7, _h_0, blk_loc(e.mem, _h_0), _cursor_1) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0)
  {
    Term _domains_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    if (term_aux(_domains_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _domains_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      Term _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(8);
        STK(0) = _f_2;
        STK(1) = _f_3;
        STK(2) = _f_4;
        STK(3) = _f_5;
        STK(4) = _f_6;
        STK(5) = _f_1;
        STK(6) = _id_0;
        STK(7) = FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K125;
        WL_PUSHN(8);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K125, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_2;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _f_4;
        e.mem[_t_0 + 3] = _f_5;
        e.mem[_t_0 + 4] = _f_6;
        e.mem[_t_0 + 5] = _f_1;
        e.mem[_t_0 + 6] = _id_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K125, _t_0);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_7;
        e.mem[_t_1 + 1] = _id_0;
        return term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE, _t_1);
      }
      r0 = _f_7;
      r1 = _id_0;
      WL_JMP(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_REMOVE);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K125)
  {
    WL_POPN(7);
    u32 _f_8 = STK(0);
    Term _f_9 = STK(1);
    Term _f_10 = STK(2);
    Term _f_11 = STK(3);
    Term _f_12 = STK(4);
    Term _f_13 = STK(5);
    u32 _id_1 = STK(6);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _f_8;
      STK(1) = _f_9;
      STK(2) = _f_10;
      STK(3) = _f_11;
      STK(4) = _f_12;
      STK(5) = _h_0;
      STK(6) = FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K126;
      WL_PUSHN(7);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K126, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_8;
      e.mem[_t_2 + 1] = _f_9;
      e.mem[_t_2 + 2] = _f_10;
      e.mem[_t_2 + 3] = _f_11;
      e.mem[_t_2 + 4] = _f_12;
      e.mem[_t_2 + 5] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K126, _t_2);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_13;
      e.mem[_t_3 + 1] = _id_1;
      return term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0, _t_3);
    }
    r0 = _f_13;
    r1 = _id_1;
    WL_JMP(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0_K126)
  {
    WL_POPN(6);
    u32 _f_14 = STK(0);
    Term _f_15 = STK(1);
    Term _f_16 = STK(2);
    Term _f_17 = STK(3);
    Term _f_18 = STK(4);
    Term _h_2 = STK(5);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_14);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_15);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_16);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_17);
    e.mem[_nd_0 + 4] = rfc_seal(e, _f_18);
    e.mem[_nd_0 + 5] = rfc_seal(e, _h_2);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_DOMAINS_DOMAIN, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_1);
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK)
  {
    Term _registrations_0 = r0;
    u32 _id_0 = r1;
    Term _name_0 = r2;
    Term _access_0 = r3;
    u32 _found_0 = r4;
    WL_OPEN
    if (term_aux(_registrations_0) == CID_NIL) {
      if (_found_0 == 1) {
        r0 = 1;
        WL_RETN(1);
      } else {
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      u64 _sp_0 = term_peek(e.mem, _registrations_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _sp_1 = term_peek(e.mem, _f_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      Term _f_4 = e.mem[_sp_1 + 2];
      if (_found_0 == 1) {
        r0 = 1;
        WL_RETN(1);
      } else {
        if (seq) {
          WL_ROOM(5);
          STK(0) = _f_1;
          STK(1) = _id_0;
          STK(2) = _name_0;
          STK(3) = _access_0;
          STK(4) = FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K128;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K128, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          e.mem[_t_0 + 1] = _id_0;
          e.mem[_t_0 + 2] = _name_0;
          e.mem[_t_0 + 3] = _access_0;
          WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K128, _t_0);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES)) {
          u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _f_2;
          e.mem[_t_1 + 1] = _f_3;
          e.mem[_t_1 + 2] = _f_4;
          e.mem[_t_1 + 3] = _id_0;
          e.mem[_t_1 + 4] = _name_0;
          e.mem[_t_1 + 5] = _access_0;
          return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES, _t_1);
        }
        r0 = _f_2;
        r1 = _f_3;
        r2 = _f_4;
        r3 = _id_0;
        r4 = _name_0;
        r5 = _access_0;
        WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K128)
  {
    WL_POPN(4);
    Term _f_5 = STK(0);
    u32 _id_1 = STK(1);
    Term _name_1 = STK(2);
    Term _access_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _id_1;
      e.mem[_t_2 + 2] = _name_1;
      e.mem[_t_2 + 3] = _access_1;
      e.mem[_t_2 + 4] = _h_0;
      return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK, _t_2);
    }
    r0 = _f_5;
    r1 = _id_1;
    r2 = _name_1;
    r3 = _access_1;
    r4 = _h_0;
    WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0)
  {
    Term _domains_0 = r0;
    u32 _wanted_0 = r1;
    u32 _position_0 = r2;
    Term _position_1 = r3;
    Term _position_2 = r4;
    WL_OPEN
    if (term_aux(_domains_0) == CID_NIL) {
      r0 = _wanted_0;
      r1 = term_pak(CID_NIL, 0);
      r2 = 0;
      WL_RETN(3);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _domains_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[6];
      u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      Term _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      spare_free(e, cls_fit(6), _sp_1);
      term_sink(e, _f_7);
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_20(e, _o_0, _f_2, _wanted_0) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      u64 _nd_0 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_0 + 0] = _f_1;
      e.mem[_nd_0 + 1] = _wanted_0;
      e.mem[_nd_0 + 2] = _position_0;
      e.mem[_nd_0 + 3] = _position_1;
      e.mem[_nd_0 + 4] = _position_2;
      if (_v_0 == 1) {
        Term _ih_0 = term_clo(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_C145, _nd_0);
        term_sink(e, _ih_0);
        u32 _v_2 = 0;
        Term _v_3 = 0;
        u32 _v_4 = 0;
        Term _o_1[3];
        if (spin_35(e, _o_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, blk_loc(e.mem, _f_4), _f_5, _f_6, _position_0, _position_1, _position_2) == 0) {
          return 0;
        }
        _v_2 = _o_1[0];
        _v_3 = _o_1[1];
        _v_4 = _o_1[2];
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _v_2;
        r1 = _v_3;
        r2 = _v_4;
        WL_RETN(3);
      } else {
        term_sink(e, _f_3);
        term_sink(e, _f_4);
        Term _ih_1 = term_clo(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_C145, _nd_0);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K147;
          WL_PUSHN(1);
        } else {
          u64 _t_2 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K147, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K147, _t_2);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _ih_1;
          e.mem[_t_3 + 1] = term_pak(CID_UNIT, 0);
          return term_tsk(FID_CLO_APPLY, _t_3);
        }
        r0 = _ih_1;
        r1 = term_pak(CID_UNIT, 0);
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_C145)
  {
    Term _f_8 = r0;
    u32 _wanted_1 = r1;
    u32 _position_3 = r2;
    Term _position_4 = r3;
    Term _position_5 = r4;
    Term _x_0 = r5;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K146;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K146, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K146, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_8;
      e.mem[_t_1 + 1] = _wanted_1;
      e.mem[_t_1 + 2] = _position_3;
      e.mem[_t_1 + 3] = _position_4;
      e.mem[_t_1 + 4] = _position_5;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0, _t_1);
    }
    r0 = _f_8;
    r1 = _wanted_1;
    r2 = _position_3;
    r3 = _position_4;
    r4 = _position_5;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K146)
  {
    u32 _r_0 = r0;
    Term _r_1 = r1;
    u32 _r_2 = r2;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = rfc_seal(e, _r_0);
    e.mem[_nd_1 + 1] = rfc_seal(e, _r_1);
    e.mem[_nd_1 + 2] = rfc_seal(e, _r_2);
    r0 = term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_KEYREADING, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0_K147)
  {
    Term _r_3 = r0;
    WL_OPEN
    Term _fb_2[3];
    u64 _sp_2 = ctr_take(e, _r_3, 3, _fb_2);
    u32 _f_9 = _fb_2[0];
    Term _f_10 = _fb_2[1];
    u32 _f_11 = _fb_2[2];
    spare_free(e, cls_fit(3), _sp_2);
    r0 = _f_9;
    r1 = _f_10;
    r2 = _f_11;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NAT_SHOW)
  {
    Term _n_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _a_0 = 10ull;
    Term _a_1 = (_a_0 == 0 ? 0 : _n_0 / _a_0);
    Term _a_2 = (_a_0 == 0 ? _n_0 : _n_0 % _a_0);
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_29(e, _o_0, _a_1, _a_2) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW_FIN)) {
      u64 _t_0 = task_node(e, FID_NAT_SHOW_FIN, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _n_0;
      e.mem[_t_0 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_0 + 2] = _v_0;
      e.mem[_t_0 + 3] = _v_1;
      return term_tsk(FID_NAT_SHOW_FIN, _t_0);
    }
    r0 = _n_0;
    r1 = term_pak(CID_SNIL, 0);
    r2 = _v_0;
    r3 = _v_1;
    WL_JMP(FID_NAT_SHOW_FIN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SYSTEM_DISPOSE_0)
  {
    u32 _registry_0 = r0;
    u32 _registry_1 = r1;
    Term _registry_2 = r2;
    Term _registry_3 = r3;
    u32 _registry_4 = r4;
    u32 _world_0 = r5;
    u32 _world_1 = r6;
    u32 _world_2 = r7;
    Term _world_3 = r8;
    u32 _world_4 = r9;
    Term _world_5 = r10;
    Term _world_6 = r11;
    Term _world_7 = r12;
    Term _world_8 = r13;
    u32 _world_9 = r14;
    u32 _world_10 = r15;
    WL_OPEN
    if (seq) {
      WL_ROOM(6);
      STK(0) = _registry_0;
      STK(1) = _registry_1;
      STK(2) = _registry_2;
      STK(3) = _registry_3;
      STK(4) = _registry_4;
      STK(5) = FID__________SRC_ECS_SYSTEM_DISPOSE_0_K161;
      WL_PUSHN(6);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_SYSTEM_DISPOSE_0_K161, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _registry_0;
      e.mem[_t_0 + 1] = _registry_1;
      e.mem[_t_0 + 2] = _registry_2;
      e.mem[_t_0 + 3] = _registry_3;
      e.mem[_t_0 + 4] = _registry_4;
      WL_CONT = term_tsk(FID__________SRC_ECS_SYSTEM_DISPOSE_0_K161, _t_0);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_REGISTRATION_REMOVE_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_REGISTRATION_REMOVE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = _world_1;
      e.mem[_t_1 + 2] = _world_2;
      e.mem[_t_1 + 3] = _world_3;
      e.mem[_t_1 + 4] = _world_4;
      e.mem[_t_1 + 5] = _world_5;
      e.mem[_t_1 + 6] = _world_6;
      e.mem[_t_1 + 7] = _world_7;
      e.mem[_t_1 + 8] = _world_8;
      e.mem[_t_1 + 9] = _world_9;
      e.mem[_t_1 + 10] = _world_10;
      e.mem[_t_1 + 11] = _registry_0;
      e.mem[_t_1 + 12] = _registry_1;
      e.mem[_t_1 + 13] = _registry_2;
      e.mem[_t_1 + 14] = _registry_3;
      return term_tsk(FID__________SRC_ECS_REGISTRATION_REMOVE_0, _t_1);
    }
    r0 = _world_0;
    r1 = _world_1;
    r2 = _world_2;
    r3 = _world_3;
    r4 = _world_4;
    r5 = _world_5;
    r6 = _world_6;
    r7 = _world_7;
    r8 = _world_8;
    r9 = _world_9;
    r10 = _world_10;
    r11 = _registry_0;
    r12 = _registry_1;
    r13 = _registry_2;
    r14 = _registry_3;
    WL_JMP(FID__________SRC_ECS_REGISTRATION_REMOVE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SYSTEM_DISPOSE_0_K161)
  {
    WL_POPN(5);
    u32 _registry_5 = STK(0);
    u32 _registry_6 = STK(1);
    Term _registry_7 = STK(2);
    Term _registry_8 = STK(3);
    u32 _registry_9 = STK(4);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _o_0[17];
    if (spin_43(e, _o_0, _registry_5, _registry_6, _registry_7, blk_loc(e.mem, _registry_7), _registry_8, blk_loc(e.mem, _registry_8), _registry_9, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, _h_5, _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, _h_10, _h_11) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    WL_RETN(17);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)
  {
    Term _registrations_0 = r0;
    u32 _id_0 = r1;
    Term _name_0 = r2;
    Term _access_0 = r3;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK)) {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _registrations_0;
      e.mem[_t_0 + 1] = _id_0;
      e.mem[_t_0 + 2] = _name_0;
      e.mem[_t_0 + 3] = _access_0;
      e.mem[_t_0 + 4] = 0;
      return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK, _t_0);
    }
    r0 = _registrations_0;
    r1 = _id_0;
    r2 = _name_0;
    r3 = _access_0;
    r4 = 0;
    WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    u32 _world_9 = r9;
    u32 _world_10 = r10;
    Term _tick_0 = r11;
    Term _domains_0 = r12;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _o_0[12];
    if (spin_47(e, _o_0, _world_0, _world_1, _world_2, _world_3, blk_loc(e.mem, _world_3), _world_4, _world_5, _world_6, blk_loc(e.mem, _world_6), _world_7, blk_loc(e.mem, _world_7), _world_8, blk_loc(e.mem, _world_8), _world_9, _world_10) == 0) {
      return 0;
    }
    _v_12 = _o_0[0];
    _v_13 = _o_0[1];
    _v_14 = _o_0[2];
    _v_15 = _o_0[3];
    _v_16 = _o_0[4];
    _v_17 = _o_0[5];
    _v_18 = _o_0[6];
    _v_19 = _o_0[7];
    _v_20 = _o_0[8];
    _v_21 = _o_0[9];
    _v_22 = _o_0[10];
    _v_23 = _o_0[11];
    _v_0 = _v_12;
    _v_1 = _v_13;
    _v_2 = _v_14;
    _v_3 = _v_15;
    _v_4 = _v_16;
    _v_5 = _v_17;
    _v_6 = _v_18;
    _v_7 = _v_19;
    _v_8 = _v_20;
    _v_9 = _v_21;
    _v_10 = _v_22;
    _v_11 = _v_23;
    if (seq) {
      WL_ROOM(14);
      STK(0) = _v_0;
      STK(1) = _v_1;
      STK(2) = _v_2;
      STK(3) = _v_3;
      STK(4) = _v_4;
      STK(5) = _v_5;
      STK(6) = _v_6;
      STK(7) = _v_7;
      STK(8) = _v_8;
      STK(9) = _v_9;
      STK(10) = _v_10;
      STK(11) = _tick_0;
      STK(12) = _domains_0;
      STK(13) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K183;
      WL_PUSHN(14);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K183, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _v_0;
      e.mem[_t_0 + 1] = _v_1;
      e.mem[_t_0 + 2] = _v_2;
      e.mem[_t_0 + 3] = _v_3;
      e.mem[_t_0 + 4] = _v_4;
      e.mem[_t_0 + 5] = _v_5;
      e.mem[_t_0 + 6] = _v_6;
      e.mem[_t_0 + 7] = _v_7;
      e.mem[_t_0 + 8] = _v_8;
      e.mem[_t_0 + 9] = _v_9;
      e.mem[_t_0 + 10] = _v_10;
      e.mem[_t_0 + 11] = _tick_0;
      e.mem[_t_0 + 12] = _domains_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K183, _t_0);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_11;
      e.mem[_t_1 + 1] = term_pak(CID_NIL, 0);
      e.mem[_t_1 + 2] = term_pak(CID_NIL, 0);
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0, _t_1);
    }
    r0 = _v_11;
    r1 = term_pak(CID_NIL, 0);
    r2 = term_pak(CID_NIL, 0);
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PARTITION_LOOP_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K183)
  {
    WL_POPN(13);
    u32 _v_36 = STK(0);
    u32 _v_37 = STK(1);
    u32 _v_38 = STK(2);
    Term _v_39 = STK(3);
    u32 _v_40 = STK(4);
    Term _v_41 = STK(5);
    Term _v_42 = STK(6);
    Term _v_43 = STK(7);
    Term _v_44 = STK(8);
    u32 _v_45 = STK(9);
    u32 _v_46 = STK(10);
    Term _tick_1 = STK(11);
    Term _domains_1 = STK(12);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _v_36;
      STK(1) = _v_37;
      STK(2) = _v_38;
      STK(3) = _v_39;
      STK(4) = _v_40;
      STK(5) = _v_41;
      STK(6) = _v_42;
      STK(7) = _v_43;
      STK(8) = _v_44;
      STK(9) = _v_45;
      STK(10) = _v_46;
      STK(11) = _h_0;
      STK(12) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K184;
      WL_PUSHN(13);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K184, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _v_36;
      e.mem[_t_2 + 1] = _v_37;
      e.mem[_t_2 + 2] = _v_38;
      e.mem[_t_2 + 3] = _v_39;
      e.mem[_t_2 + 4] = _v_40;
      e.mem[_t_2 + 5] = _v_41;
      e.mem[_t_2 + 6] = _v_42;
      e.mem[_t_2 + 7] = _v_43;
      e.mem[_t_2 + 8] = _v_44;
      e.mem[_t_2 + 9] = _v_45;
      e.mem[_t_2 + 10] = _v_46;
      e.mem[_t_2 + 11] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K184, _t_2);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_1;
      e.mem[_t_3 + 1] = _tick_1;
      e.mem[_t_3 + 2] = _domains_1;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0, _t_3);
    }
    r0 = _h_1;
    r1 = _tick_1;
    r2 = _domains_1;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_PUBLISH_BATCHES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0_K184)
  {
    WL_POPN(12);
    u32 _v_47 = STK(0);
    u32 _v_48 = STK(1);
    u32 _v_49 = STK(2);
    Term _v_50 = STK(3);
    u32 _v_51 = STK(4);
    Term _v_52 = STK(5);
    Term _v_53 = STK(6);
    Term _v_54 = STK(7);
    Term _v_55 = STK(8);
    u32 _v_56 = STK(9);
    u32 _v_57 = STK(10);
    Term _h_3 = STK(11);
    Term _h_2 = r0;
    WL_OPEN
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    Term _v_66 = 0;
    u32 _v_67 = 0;
    u32 _v_68 = 0;
    Term _v_69 = 0;
    Term _v_70 = 0;
    Term _o_1[1];
    if (spin_17(e, _o_1, _h_3, blk_loc(e.mem, _h_3)) == 0) {
      return 0;
    }
    _v_70 = _o_1[0];
    _v_69 = _v_70;
    u32 _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    u32 _v_75 = 0;
    Term _v_76 = 0;
    Term _v_77 = 0;
    Term _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _o_2[11];
    if (spin_34(e, _o_2, _v_47, _v_48, _v_49, _v_50, blk_loc(e.mem, _v_50), _v_51, _v_52, _v_53, blk_loc(e.mem, _v_53), _v_54, blk_loc(e.mem, _v_54), _v_55, blk_loc(e.mem, _v_55), _v_56, _v_57, _v_69, blk_loc(e.mem, _v_69)) == 0) {
      return 0;
    }
    _v_71 = _o_2[0];
    _v_72 = _o_2[1];
    _v_73 = _o_2[2];
    _v_74 = _o_2[3];
    _v_75 = _o_2[4];
    _v_76 = _o_2[5];
    _v_77 = _o_2[6];
    _v_78 = _o_2[7];
    _v_79 = _o_2[8];
    _v_80 = _o_2[9];
    _v_81 = _o_2[10];
    _v_58 = _v_71;
    _v_59 = _v_72;
    _v_60 = _v_73;
    _v_61 = _v_74;
    _v_62 = _v_75;
    _v_63 = _v_76;
    _v_64 = _v_77;
    _v_65 = _v_78;
    _v_66 = _v_79;
    _v_67 = _v_80;
    _v_68 = _v_81;
    r0 = _v_58;
    r1 = _v_59;
    r2 = _v_60;
    r3 = _v_61;
    r4 = _v_62;
    r5 = _v_63;
    r6 = _v_64;
    r7 = _v_65;
    r8 = _v_66;
    r9 = _v_67;
    r10 = _v_68;
    r11 = _h_2;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP)
  {
    Term _positions_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_positions_0) == CID_NIL) {
      r0 = 0;
      r1 = 0;
      r2 = 0;
      r3 = 0;
      WL_RETN(4);
    } else {
      u64 _sp_0 = term_peek(e.mem, _positions_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _sp_1 = term_peek(e.mem, _f_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      Term _f_4 = e.mem[_sp_1 + 2];
      if (seq) {
        WL_ROOM(5);
        STK(0) = _f_2;
        STK(1) = _f_3;
        STK(2) = _f_4;
        STK(3) = _id_0;
        STK(4) = FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP_K187;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP_K187, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_2;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _f_4;
        e.mem[_t_0 + 3] = _id_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP_K187, _t_0);
        WL_IDX = 4;
      }
      r0 = _f_1;
      r1 = _id_0;
      _positions_0 = r0;
      _id_0 = r1;
      WL_AGAIN(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP_K187)
  {
    WL_POPN(4);
    u32 _f_5 = STK(0);
    Term _f_6 = STK(1);
    Term _f_7 = STK(2);
    u32 _id_1 = STK(3);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _o_1[4];
    if (spin_48(e, _o_1, _f_5, _f_6, _f_7, _id_1, _h_0, _h_1, _h_2, _h_3) == 0) {
      return 0;
    }
    _v_0 = _o_1[0];
    _v_1 = _o_1[1];
    _v_2 = _o_1[2];
    _v_3 = _o_1[3];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0)
  {
    Term _keys_0 = r0;
    Term _domains_0 = r1;
    u32 _position_0 = r2;
    Term _position_1 = r3;
    Term _position_2 = r4;
    WL_OPEN
    if (term_aux(_keys_0) == CID_NIL) {
      term_sink(e, _domains_0);
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _keys_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u32 _key_0 = term_loc(_f_0);
      _domains_0 = term_keep(e, _domains_0, 1);
      if (seq) {
        WL_ROOM(6);
        STK(0) = _f_1;
        STK(1) = _domains_0;
        STK(2) = _position_0;
        STK(3) = _position_1;
        STK(4) = _position_2;
        STK(5) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K190;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K190, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        e.mem[_t_0 + 1] = _domains_0;
        e.mem[_t_0 + 2] = _position_0;
        e.mem[_t_0 + 3] = _position_1;
        e.mem[_t_0 + 4] = _position_2;
        WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K190, _t_0);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _domains_0;
        e.mem[_t_1 + 1] = _key_0;
        e.mem[_t_1 + 2] = _position_0;
        e.mem[_t_1 + 3] = _position_1;
        e.mem[_t_1 + 4] = _position_2;
        return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0, _t_1);
      }
      r0 = _domains_0;
      r1 = _key_0;
      r2 = _position_0;
      r3 = _position_1;
      r4 = _position_2;
      WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ONE_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K190)
  {
    WL_POPN(5);
    Term _f_2 = STK(0);
    Term _domains_1 = STK(1);
    u32 _position_3 = STK(2);
    Term _position_4 = STK(3);
    Term _position_5 = STK(4);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _h_0;
      STK(1) = _h_1;
      STK(2) = _h_2;
      STK(3) = FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K191;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K191, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _h_1;
      e.mem[_t_2 + 2] = _h_2;
      WL_CONT = term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K191, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      e.mem[_t_3 + 1] = _domains_1;
      e.mem[_t_3 + 2] = _position_3;
      e.mem[_t_3 + 3] = _position_4;
      e.mem[_t_3 + 4] = _position_5;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0, _t_3);
    }
    r0 = _f_2;
    r1 = _domains_1;
    r2 = _position_3;
    r3 = _position_4;
    r4 = _position_5;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0_K191)
  {
    WL_POPN(3);
    u32 _h_4 = STK(0);
    Term _h_5 = STK(1);
    u32 _h_6 = STK(2);
    Term _h_3 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, _h_4);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_5);
    e.mem[_nd_0 + 2] = rfc_seal(e, _h_6);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_KEYREADING, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_3);
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0)
  {
    u32 _registry_0 = r0;
    u32 _registry_1 = r1;
    Term _registry_2 = r2;
    Term _registry_3 = r3;
    u32 _registry_4 = r4;
    u32 _advanced_0 = r5;
    u32 _advanced_1 = r6;
    u32 _advanced_2 = r7;
    Term _advanced_3 = r8;
    u32 _advanced_4 = r9;
    Term _advanced_5 = r10;
    Term _advanced_6 = r11;
    Term _advanced_7 = r12;
    Term _advanced_8 = r13;
    u32 _advanced_9 = r14;
    u32 _advanced_10 = r15;
    u32 _advanced_11 = r16;
    Term _input_0 = r17;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0_K193;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0_K193, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0_K193, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SYSTEM_RUN_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_SYSTEM_RUN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _registry_0;
      e.mem[_t_1 + 1] = _registry_1;
      e.mem[_t_1 + 2] = _registry_2;
      e.mem[_t_1 + 3] = _registry_3;
      e.mem[_t_1 + 4] = _registry_4;
      e.mem[_t_1 + 5] = _advanced_0;
      e.mem[_t_1 + 6] = _advanced_1;
      e.mem[_t_1 + 7] = _advanced_2;
      e.mem[_t_1 + 8] = _advanced_3;
      e.mem[_t_1 + 9] = _advanced_4;
      e.mem[_t_1 + 10] = _advanced_5;
      e.mem[_t_1 + 11] = _advanced_6;
      e.mem[_t_1 + 12] = _advanced_7;
      e.mem[_t_1 + 13] = _advanced_8;
      e.mem[_t_1 + 14] = _advanced_9;
      e.mem[_t_1 + 15] = _advanced_10;
      e.mem[_t_1 + 16] = _input_0;
      return term_tsk(FID__________SRC_ECS_SYSTEM_RUN_0, _t_1);
    }
    r0 = _registry_0;
    r1 = _registry_1;
    r2 = _registry_2;
    r3 = _registry_3;
    r4 = _registry_4;
    r5 = _advanced_0;
    r6 = _advanced_1;
    r7 = _advanced_2;
    r8 = _advanced_3;
    r9 = _advanced_4;
    r10 = _advanced_5;
    r11 = _advanced_6;
    r12 = _advanced_7;
    r13 = _advanced_8;
    r14 = _advanced_9;
    r15 = _advanced_10;
    r16 = _input_0;
    WL_JMP(FID__________SRC_ECS_SYSTEM_RUN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0_K193)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    u32 _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    Term _h_15 = r15;
    u32 _h_16 = r16;
    Term _h_17 = r17;
    Term _h_18 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _o_0[19];
    if (spin_42(e, _o_0, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, _h_6, _h_7, _h_8, _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, blk_loc(e.mem, _h_15), _h_16, _h_17, blk_loc(e.mem, _h_17), _h_18, blk_loc(e.mem, _h_18)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    _v_17 = _o_0[17];
    _v_18 = _o_0[18];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS_TAIL)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_SNIL, 0);
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _values_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _sp_1 = term_peek(e.mem, _f_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      Term _f_4 = e.mem[_sp_1 + 2];
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_POSITIONS_TAIL_K202;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_POSITIONS_TAIL_K202, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_POSITIONS_TAIL_K202, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_POSITION)) {
        u64 _t_1 = task_node(e, FID_POSITION, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        return term_tsk(FID_POSITION, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      WL_JMP(FID_POSITION);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS_TAIL_K202)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_POSITIONS_TAIL_K203;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_POSITIONS_TAIL_K203, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_POSITIONS_TAIL_K203, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_POSITIONS_TAIL)) {
      u64 _t_3 = task_node(e, FID_POSITIONS_TAIL, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      return term_tsk(FID_POSITIONS_TAIL, _t_3);
    }
    r0 = _f_5;
    WL_JMP(FID_POSITIONS_TAIL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS_TAIL_K203)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_POSITIONS_TAIL_K204;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_POSITIONS_TAIL_K204, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_POSITIONS_TAIL_K204, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS_TAIL_K204)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 272);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 272);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION)
  {
    u32 _value_0 = r0;
    Term _value_1 = r1;
    Term _value_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_1;
      STK(1) = _value_2;
      STK(2) = FID_POSITION_K206;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_POSITION_K206, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      e.mem[_t_0 + 1] = _value_2;
      WL_CONT = term_tsk(FID_POSITION_K206, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K206)
  {
    WL_POPN(2);
    Term _value_3 = STK(0);
    Term _value_4 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_4;
      STK(1) = _h_0;
      STK(2) = FID_POSITION_K207;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_POSITION_K207, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_4;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_POSITION_K207, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_3 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_3;
      return term_tsk(FID_NAT_SHOW, _t_3);
    }
    r0 = _value_3;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K207)
  {
    WL_POPN(2);
    Term _value_5 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_POSITION_K208;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_POSITION_K208, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_POSITION_K208, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NAT_SHOW)) {
      u64 _t_5 = task_node(e, FID_NAT_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_5;
      return term_tsk(FID_NAT_SHOW, _t_5);
    }
    r0 = _value_5;
    WL_JMP(FID_NAT_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K208)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_POSITION_K209;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_POSITION_K209, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      WL_CONT = term_tsk(FID_POSITION_K209, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_3;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_3;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K209)
  {
    WL_POPN(2);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_7;
      STK(1) = _h_8;
      STK(2) = FID_POSITION_K210;
      WL_PUSHN(3);
    } else {
      u64 _t_8 = task_node(e, FID_POSITION_K210, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      e.mem[_t_8 + 1] = _h_8;
      WL_CONT = term_tsk(FID_POSITION_K210, _t_8);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_ctr(CID_SCON, STAT_OFF + 298);
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 298);
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K210)
  {
    WL_POPN(2);
    Term _h_10 = STK(0);
    Term _h_11 = STK(1);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_10;
      STK(1) = FID_POSITION_K211;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_POSITION_K211, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_10;
      WL_CONT = term_tsk(FID_POSITION_K211, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_11;
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = _h_11;
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K211)
  {
    WL_POPN(1);
    Term _h_13 = STK(0);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_13;
      STK(1) = FID_POSITION_K212;
      WL_PUSHN(2);
    } else {
      u64 _t_12 = task_node(e, FID_POSITION_K212, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_13;
      WL_CONT = term_tsk(FID_POSITION_K212, _t_12);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = term_ctr(CID_SCON, STAT_OFF + 314);
      e.mem[_t_13 + 1] = _h_12;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 314);
    r1 = _h_12;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K212)
  {
    WL_POPN(1);
    Term _h_15 = STK(0);
    Term _h_14 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_POSITION_K213;
      WL_PUSHN(1);
    } else {
      u64 _t_14 = task_node(e, FID_POSITION_K213, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_POSITION_K213, _t_14);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_15 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_15;
      e.mem[_t_15 + 1] = _h_14;
      return term_tsk(FID_STRING_APPEND, _t_15);
    }
    r0 = _h_15;
    r1 = _h_14;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITION_K213)
  {
    Term _h_16 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_16 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_ctr(CID_SCON, STAT_OFF + 322);
      e.mem[_t_16 + 1] = _h_16;
      return term_tsk(FID_STRING_APPEND, _t_16);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 322);
    r1 = _h_16;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS_TAIL)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_SNIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u32 _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_READINGS_TAIL_K215;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_READINGS_TAIL_K215, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_READINGS_TAIL_K215, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_READING)) {
        u64 _t_1 = task_node(e, FID_READING, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        return term_tsk(FID_READING, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      WL_JMP(FID_READING);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS_TAIL_K215)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_READINGS_TAIL_K216;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_READINGS_TAIL_K216, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_READINGS_TAIL_K216, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_READINGS_TAIL)) {
      u64 _t_3 = task_node(e, FID_READINGS_TAIL, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      return term_tsk(FID_READINGS_TAIL, _t_3);
    }
    r0 = _f_5;
    WL_JMP(FID_READINGS_TAIL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS_TAIL_K216)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_READINGS_TAIL_K217;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_READINGS_TAIL_K217, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_READINGS_TAIL_K217, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS_TAIL_K217)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 272);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 272);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READING)
  {
    u32 _value_0 = r0;
    Term _value_1 = r1;
    u32 _value_2 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_1;
      STK(1) = _value_2;
      STK(2) = FID_READING_K219;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_READING_K219, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_1;
      e.mem[_t_0 + 1] = _value_2;
      WL_CONT = term_tsk(FID_READING_K219, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _value_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _value_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READING_K219)
  {
    WL_POPN(2);
    Term _value_3 = STK(0);
    u32 _value_4 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _value_4;
      STK(1) = _h_0;
      STK(2) = FID_READING_K220;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_READING_K220, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _value_4;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_READING_K220, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NUMBERS)) {
      u64 _t_3 = task_node(e, FID_NUMBERS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _value_3;
      return term_tsk(FID_NUMBERS, _t_3);
    }
    r0 = _value_3;
    WL_JMP(FID_NUMBERS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READING_K220)
  {
    WL_POPN(2);
    u32 _value_5 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_44(e, _o_0, _value_5) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID_READING_K221;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_READING_K221, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID_READING_K221, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _v_0;
      e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _v_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READING_K221)
  {
    WL_POPN(2);
    Term _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_4;
      STK(1) = _h_5;
      STK(2) = FID_READING_K222;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_READING_K222, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_4;
      e.mem[_t_6 + 1] = _h_5;
      WL_CONT = term_tsk(FID_READING_K222, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 336);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 336);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READING_K222)
  {
    WL_POPN(2);
    Term _h_7 = STK(0);
    Term _h_8 = STK(1);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_7;
      STK(1) = FID_READING_K223;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_READING_K223, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_7;
      WL_CONT = term_tsk(FID_READING_K223, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_8;
      e.mem[_t_9 + 1] = _h_6;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_8;
    r1 = _h_6;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READING_K223)
  {
    WL_POPN(1);
    Term _h_10 = STK(0);
    Term _h_9 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_10;
      STK(1) = FID_READING_K224;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_READING_K224, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_10;
      WL_CONT = term_tsk(FID_READING_K224, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 352);
      e.mem[_t_11 + 1] = _h_9;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 352);
    r1 = _h_9;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READING_K224)
  {
    WL_POPN(1);
    Term _h_12 = STK(0);
    Term _h_11 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_READING_K225;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_READING_K225, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_READING_K225, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_13 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_12;
      e.mem[_t_13 + 1] = _h_11;
      return term_tsk(FID_STRING_APPEND, _t_13);
    }
    r0 = _h_12;
    r1 = _h_11;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READING_K225)
  {
    Term _h_13 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_14 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = term_ctr(CID_SCON, STAT_OFF + 362);
      e.mem[_t_14 + 1] = _h_13;
      return term_tsk(FID_STRING_APPEND, _t_14);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 362);
    r1 = _h_13;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_pak(CID_SNIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_TAIL_K228;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_TAIL_K228, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_TAIL_K228, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_K228)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_TAIL_K229;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_TAIL_K229, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_TAIL_K229, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TAIL)) {
      u64 _t_3 = task_node(e, FID_TAIL, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      return term_tsk(FID_TAIL, _t_3);
    }
    r0 = _f_2;
    WL_JMP(FID_TAIL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_K229)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_TAIL_K230;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_TAIL_K230, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_TAIL_K230, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_2;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_TAIL_K230)
  {
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 272);
      e.mem[_t_6 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 272);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0)
  {
    u32 _world_0 = r0;
    u32 _world_1 = r1;
    u32 _world_2 = r2;
    Term _world_3 = r3;
    u32 _world_4 = r4;
    Term _world_5 = r5;
    Term _world_6 = r6;
    Term _world_7 = r7;
    Term _world_8 = r8;
    u32 _world_9 = r9;
    u32 _world_10 = r10;
    u32 _id_0 = r11;
    Term _name_0 = r12;
    Term _access_0 = r13;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _world_0;
      STK(1) = _world_1;
      STK(2) = _world_2;
      STK(3) = _world_3;
      STK(4) = _world_4;
      STK(5) = _world_5;
      STK(6) = _world_6;
      STK(7) = _world_7;
      STK(8) = _world_8;
      STK(9) = _world_9;
      STK(10) = _world_10;
      STK(11) = _name_0;
      STK(12) = _access_0;
      STK(13) = FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K236;
      WL_PUSHN(14);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K236, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _world_1;
      e.mem[_t_0 + 2] = _world_2;
      e.mem[_t_0 + 3] = _world_3;
      e.mem[_t_0 + 4] = _world_4;
      e.mem[_t_0 + 5] = _world_5;
      e.mem[_t_0 + 6] = _world_6;
      e.mem[_t_0 + 7] = _world_7;
      e.mem[_t_0 + 8] = _world_8;
      e.mem[_t_0 + 9] = _world_9;
      e.mem[_t_0 + 10] = _world_10;
      e.mem[_t_0 + 11] = _name_0;
      e.mem[_t_0 + 12] = _access_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K236, _t_0);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_8;
      e.mem[_t_1 + 1] = _id_0;
      e.mem[_t_1 + 2] = _name_0;
      e.mem[_t_1 + 3] = _access_0;
      return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, _t_1);
    }
    r0 = _world_8;
    r1 = _id_0;
    r2 = _name_0;
    r3 = _access_0;
    WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0_K236)
  {
    WL_POPN(13);
    u32 _world_11 = STK(0);
    u32 _world_12 = STK(1);
    u32 _world_13 = STK(2);
    Term _world_14 = STK(3);
    u32 _world_15 = STK(4);
    Term _world_16 = STK(5);
    Term _world_17 = STK(6);
    Term _world_18 = STK(7);
    Term _world_19 = STK(8);
    u32 _world_20 = STK(9);
    u32 _world_21 = STK(10);
    Term _name_1 = STK(11);
    Term _access_1 = STK(12);
    u32 _h_0 = r0;
    WL_OPEN
    term_sink(e, _name_1);
    term_sink(e, _access_1);
    r0 = _world_11;
    r1 = _world_12;
    r2 = _world_13;
    r3 = _world_14;
    r4 = _world_15;
    r5 = _world_16;
    r6 = _world_17;
    r7 = _world_18;
    r8 = _world_19;
    r9 = _world_20;
    r10 = _world_21;
    r11 = _h_0;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 390);
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _values_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _sp_1 = term_peek(e.mem, _f_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      Term _f_4 = e.mem[_sp_1 + 2];
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_POSITIONS_K268;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_POSITIONS_K268, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_POSITIONS_K268, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_POSITION)) {
        u64 _t_1 = task_node(e, FID_POSITION, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        return term_tsk(FID_POSITION, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      WL_JMP(FID_POSITION);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS_K268)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_POSITIONS_K269;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_POSITIONS_K269, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_POSITIONS_K269, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_POSITIONS_TAIL)) {
      u64 _t_3 = task_node(e, FID_POSITIONS_TAIL, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      return term_tsk(FID_POSITIONS_TAIL, _t_3);
    }
    r0 = _f_5;
    WL_JMP(FID_POSITIONS_TAIL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS_K269)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_POSITIONS_K270;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_POSITIONS_K270, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_POSITIONS_K270, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_1;
      e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 388);
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_SCON, STAT_OFF + 388);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS_K270)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_POSITIONS_K271;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_POSITIONS_K271, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_POSITIONS_K271, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_4;
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_POSITIONS_K271)
  {
    Term _h_5 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = term_ctr(CID_SCON, STAT_OFF + 392);
      e.mem[_t_8 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 392);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 390);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[3];
      u64 _sp_1 = ctr_take(e, _f_0, 3, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u32 _f_4 = _fb_1[2];
      spare_free(e, cls_fit(3), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_READINGS_K273;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_READINGS_K273, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_READINGS_K273, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_READING)) {
        u64 _t_1 = task_node(e, FID_READING, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_2;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        return term_tsk(FID_READING, _t_1);
      }
      r0 = _f_2;
      r1 = _f_3;
      r2 = _f_4;
      WL_JMP(FID_READING);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS_K273)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_READINGS_K274;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_READINGS_K274, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_READINGS_K274, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_READINGS_TAIL)) {
      u64 _t_3 = task_node(e, FID_READINGS_TAIL, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_5;
      return term_tsk(FID_READINGS_TAIL, _t_3);
    }
    r0 = _f_5;
    WL_JMP(FID_READINGS_TAIL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS_K274)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_READINGS_K275;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_READINGS_K275, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_READINGS_K275, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_1;
      e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 388);
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_SCON, STAT_OFF + 388);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS_K275)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_READINGS_K276;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_READINGS_K276, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_READINGS_K276, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_4;
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_READINGS_K276)
  {
    Term _h_5 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = term_ctr(CID_SCON, STAT_OFF + 392);
      e.mem[_t_8 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 392);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 364);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS)
  {
    Term _values_0 = r0;
    WL_OPEN
    if (term_aux(_values_0) == CID_NIL) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 390);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _values_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID_NUMBERS_K279;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_NUMBERS_K279, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID_NUMBERS_K279, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
        u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        return term_tsk(FID_U32_SHOW, _t_1);
      }
      r0 = _f_0;
      WL_JMP(FID_U32_SHOW);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS_K279)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID_NUMBERS_K280;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_NUMBERS_K280, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_0;
      WL_CONT = term_tsk(FID_NUMBERS_K280, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_TAIL)) {
      u64 _t_3 = task_node(e, FID_TAIL, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      return term_tsk(FID_TAIL, _t_3);
    }
    r0 = _f_2;
    WL_JMP(FID_TAIL);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS_K280)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_2;
      STK(1) = FID_NUMBERS_K281;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_NUMBERS_K281, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      WL_CONT = term_tsk(FID_NUMBERS_K281, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_1;
      e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 388);
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_1;
    r1 = term_ctr(CID_SCON, STAT_OFF + 388);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS_K281)
  {
    WL_POPN(1);
    Term _h_4 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_NUMBERS_K282;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_NUMBERS_K282, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_NUMBERS_K282, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_4;
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NUMBERS_K282)
  {
    Term _h_5 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_8 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = term_ctr(CID_SCON, STAT_OFF + 392);
      e.mem[_t_8 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_8);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 392);
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K284;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K284, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K284, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K284)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0)
  {
    u32 _runtime_0 = r0;
    u32 _runtime_1 = r1;
    u32 _runtime_2 = r2;
    Term _runtime_3 = r3;
    u32 _runtime_4 = r4;
    Term _runtime_5 = r5;
    Term _runtime_6 = r6;
    Term _runtime_7 = r7;
    Term _runtime_8 = r8;
    u32 _runtime_9 = r9;
    u32 _runtime_10 = r10;
    Term _runtime_11 = r11;
    Term _runtime_12 = r12;
    Term _runtime_13 = r13;
    Term _runtime_14 = r14;
    Term _runtime_15 = r15;
    Term _runtime_16 = r16;
    u32 _runtime_17 = r17;
    u32 _reader_0 = r18;
    u32 _reader_1 = r19;
    Term _reader_2 = r20;
    Term _reader_3 = r21;
    u32 _reader_4 = r22;
    Term _reader_5 = r23;
    u32 _reader_6 = r24;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _runtime_11;
      STK(1) = _runtime_12;
      STK(2) = _runtime_13;
      STK(3) = _runtime_14;
      STK(4) = _runtime_15;
      STK(5) = _runtime_16;
      STK(6) = _runtime_17;
      STK(7) = _reader_6;
      STK(8) = _reader_5;
      STK(9) = FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K286;
      WL_PUSHN(10);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K286, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _runtime_11;
      e.mem[_t_0 + 1] = _runtime_12;
      e.mem[_t_0 + 2] = _runtime_13;
      e.mem[_t_0 + 3] = _runtime_14;
      e.mem[_t_0 + 4] = _runtime_15;
      e.mem[_t_0 + 5] = _runtime_16;
      e.mem[_t_0 + 6] = _runtime_17;
      e.mem[_t_0 + 7] = _reader_6;
      e.mem[_t_0 + 8] = _reader_5;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K286, _t_0);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SYSTEM_DISPOSE_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_SYSTEM_DISPOSE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _reader_0;
      e.mem[_t_1 + 1] = _reader_1;
      e.mem[_t_1 + 2] = _reader_2;
      e.mem[_t_1 + 3] = _reader_3;
      e.mem[_t_1 + 4] = _reader_4;
      e.mem[_t_1 + 5] = _runtime_0;
      e.mem[_t_1 + 6] = _runtime_1;
      e.mem[_t_1 + 7] = _runtime_2;
      e.mem[_t_1 + 8] = _runtime_3;
      e.mem[_t_1 + 9] = _runtime_4;
      e.mem[_t_1 + 10] = _runtime_5;
      e.mem[_t_1 + 11] = _runtime_6;
      e.mem[_t_1 + 12] = _runtime_7;
      e.mem[_t_1 + 13] = _runtime_8;
      e.mem[_t_1 + 14] = _runtime_9;
      e.mem[_t_1 + 15] = _runtime_10;
      return term_tsk(FID__________SRC_ECS_SYSTEM_DISPOSE_0, _t_1);
    }
    r0 = _reader_0;
    r1 = _reader_1;
    r2 = _reader_2;
    r3 = _reader_3;
    r4 = _reader_4;
    r5 = _runtime_0;
    r6 = _runtime_1;
    r7 = _runtime_2;
    r8 = _runtime_3;
    r9 = _runtime_4;
    r10 = _runtime_5;
    r11 = _runtime_6;
    r12 = _runtime_7;
    r13 = _runtime_8;
    r14 = _runtime_9;
    r15 = _runtime_10;
    WL_JMP(FID__________SRC_ECS_SYSTEM_DISPOSE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K286)
  {
    WL_POPN(9);
    Term _runtime_18 = STK(0);
    Term _runtime_19 = STK(1);
    Term _runtime_20 = STK(2);
    Term _runtime_21 = STK(3);
    Term _runtime_22 = STK(4);
    Term _runtime_23 = STK(5);
    u32 _runtime_24 = STK(6);
    u32 _reader_7 = STK(7);
    Term _reader_8 = STK(8);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    u32 _h_11 = r11;
    u32 _h_12 = r12;
    u32 _h_13 = r13;
    Term _h_14 = r14;
    Term _h_15 = r15;
    u32 _h_16 = r16;
    WL_OPEN
    if (_h_0 == 0) {
      term_sink(e, _reader_8);
      if (seq) {
        WL_ROOM(19);
        STK(0) = _h_1;
        STK(1) = _h_2;
        STK(2) = _h_3;
        STK(3) = _h_4;
        STK(4) = _h_5;
        STK(5) = _h_6;
        STK(6) = _h_7;
        STK(7) = _h_8;
        STK(8) = _h_9;
        STK(9) = _h_10;
        STK(10) = _h_11;
        STK(11) = _runtime_19;
        STK(12) = _reader_7;
        STK(13) = _runtime_20;
        STK(14) = _runtime_21;
        STK(15) = _runtime_22;
        STK(16) = _runtime_23;
        STK(17) = _runtime_24;
        STK(18) = FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K287;
        WL_PUSHN(19);
      } else {
        u64 _t_2 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K287, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _h_1;
        e.mem[_t_2 + 1] = _h_2;
        e.mem[_t_2 + 2] = _h_3;
        e.mem[_t_2 + 3] = _h_4;
        e.mem[_t_2 + 4] = _h_5;
        e.mem[_t_2 + 5] = _h_6;
        e.mem[_t_2 + 6] = _h_7;
        e.mem[_t_2 + 7] = _h_8;
        e.mem[_t_2 + 8] = _h_9;
        e.mem[_t_2 + 9] = _h_10;
        e.mem[_t_2 + 10] = _h_11;
        e.mem[_t_2 + 11] = _runtime_19;
        e.mem[_t_2 + 12] = _reader_7;
        e.mem[_t_2 + 13] = _runtime_20;
        e.mem[_t_2 + 14] = _runtime_21;
        e.mem[_t_2 + 15] = _runtime_22;
        e.mem[_t_2 + 16] = _runtime_23;
        e.mem[_t_2 + 17] = _runtime_24;
        WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K287, _t_2);
        WL_IDX = 18;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0)) {
        u64 _t_3 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _runtime_18;
        e.mem[_t_3 + 1] = _reader_7;
        return term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0, _t_3);
      }
      r0 = _runtime_18;
      r1 = _reader_7;
      WL_JMP(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_RELEASE_0);
    } else {
      r0 = 1;
      r1 = _h_1;
      r2 = _h_2;
      r3 = _h_3;
      r4 = _h_4;
      r5 = _h_5;
      r6 = _h_6;
      r7 = _h_7;
      r8 = _h_8;
      r9 = _h_9;
      r10 = _h_10;
      r11 = _h_11;
      r12 = _runtime_18;
      r13 = _runtime_19;
      r14 = _runtime_20;
      r15 = _runtime_21;
      r16 = _runtime_22;
      r17 = _runtime_23;
      r18 = _runtime_24;
      r19 = _h_12;
      r20 = _h_13;
      r21 = _h_14;
      r22 = _h_15;
      r23 = _h_16;
      r24 = _reader_8;
      r25 = _reader_7;
      WL_RETN(26);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K287)
  {
    WL_POPN(18);
    u32 _h_18 = STK(0);
    u32 _h_19 = STK(1);
    u32 _h_20 = STK(2);
    Term _h_21 = STK(3);
    u32 _h_22 = STK(4);
    Term _h_23 = STK(5);
    Term _h_24 = STK(6);
    Term _h_25 = STK(7);
    Term _h_26 = STK(8);
    u32 _h_27 = STK(9);
    u32 _h_28 = STK(10);
    Term _runtime_25 = STK(11);
    u32 _reader_9 = STK(12);
    Term _runtime_26 = STK(13);
    Term _runtime_27 = STK(14);
    Term _runtime_28 = STK(15);
    Term _runtime_29 = STK(16);
    u32 _runtime_30 = STK(17);
    Term _h_17 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(18);
      STK(0) = _h_18;
      STK(1) = _h_19;
      STK(2) = _h_20;
      STK(3) = _h_21;
      STK(4) = _h_22;
      STK(5) = _h_23;
      STK(6) = _h_24;
      STK(7) = _h_25;
      STK(8) = _h_26;
      STK(9) = _h_27;
      STK(10) = _h_28;
      STK(11) = _runtime_26;
      STK(12) = _runtime_27;
      STK(13) = _runtime_28;
      STK(14) = _runtime_29;
      STK(15) = _runtime_30;
      STK(16) = _h_17;
      STK(17) = FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K288;
      WL_PUSHN(18);
    } else {
      u64 _t_4 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K288, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_18;
      e.mem[_t_4 + 1] = _h_19;
      e.mem[_t_4 + 2] = _h_20;
      e.mem[_t_4 + 3] = _h_21;
      e.mem[_t_4 + 4] = _h_22;
      e.mem[_t_4 + 5] = _h_23;
      e.mem[_t_4 + 6] = _h_24;
      e.mem[_t_4 + 7] = _h_25;
      e.mem[_t_4 + 8] = _h_26;
      e.mem[_t_4 + 9] = _h_27;
      e.mem[_t_4 + 10] = _h_28;
      e.mem[_t_4 + 11] = _runtime_26;
      e.mem[_t_4 + 12] = _runtime_27;
      e.mem[_t_4 + 13] = _runtime_28;
      e.mem[_t_4 + 14] = _runtime_29;
      e.mem[_t_4 + 15] = _runtime_30;
      e.mem[_t_4 + 16] = _h_17;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K288, _t_4);
      WL_IDX = 17;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE)) {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_UPDATE, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _runtime_25;
      e.mem[_t_5 + 1] = _reader_9;
      e.mem[_t_5 + 2] = _runtime_26;
      e.mem[_t_5 + 3] = 1;
      return term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE, _t_5);
    }
    r0 = _runtime_25;
    r1 = _reader_9;
    r2 = _runtime_26;
    r3 = 1;
    WL_JMP(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0_K288)
  {
    WL_POPN(17);
    u32 _h_30 = STK(0);
    u32 _h_31 = STK(1);
    u32 _h_32 = STK(2);
    Term _h_33 = STK(3);
    u32 _h_34 = STK(4);
    Term _h_35 = STK(5);
    Term _h_36 = STK(6);
    Term _h_37 = STK(7);
    Term _h_38 = STK(8);
    u32 _h_39 = STK(9);
    u32 _h_40 = STK(10);
    Term _runtime_31 = STK(11);
    Term _runtime_32 = STK(12);
    Term _runtime_33 = STK(13);
    Term _runtime_34 = STK(14);
    u32 _runtime_35 = STK(15);
    Term _h_41 = STK(16);
    Term _h_29 = r0;
    WL_OPEN
    r0 = 0;
    r1 = _h_30;
    r2 = _h_31;
    r3 = _h_32;
    r4 = _h_33;
    r5 = _h_34;
    r6 = _h_35;
    r7 = _h_36;
    r8 = _h_37;
    r9 = _h_38;
    r10 = _h_39;
    r11 = _h_40;
    r12 = _h_41;
    r13 = _h_29;
    r14 = _runtime_31;
    r15 = _runtime_32;
    r16 = _runtime_33;
    r17 = _runtime_34;
    r18 = _runtime_35;
    r19 = 0;
    r20 = 0;
    r21 = 0;
    r22 = 0;
    r23 = 0;
    r24 = 0;
    r25 = 0;
    WL_RETN(26);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0)
  {
    Term _effect_0 = r0;
    u32 _advanced_0 = r1;
    u32 _advanced_1 = r2;
    u32 _advanced_2 = r3;
    Term _advanced_3 = r4;
    u32 _advanced_4 = r5;
    Term _advanced_5 = r6;
    Term _advanced_6 = r7;
    Term _advanced_7 = r8;
    Term _advanced_8 = r9;
    u32 _advanced_9 = r10;
    u32 _advanced_10 = r11;
    u32 _advanced_11 = r12;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_0 + 0] = rfc_seal(e, _advanced_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _advanced_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _advanced_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _advanced_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _advanced_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _advanced_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 7] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 8] = rfc_seal(e, _advanced_6);
    e.mem[_nd_0 + 9] = rfc_seal(e, _advanced_7);
    e.mem[_nd_0 + 10] = rfc_seal(e, _advanced_8);
    e.mem[_nd_0 + 11] = rfc_seal(e, _advanced_9);
    e.mem[_nd_0 + 12] = rfc_seal(e, _advanced_10);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0_K313;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0_K313, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0_K313, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _effect_0;
      e.mem[_t_1 + 1] = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _effect_0;
    r1 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0_K313)
  {
    Term _r_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _r_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[13];
    u64 _sp_1 = ctr_take(e, _f_0, 13, _fb_1);
    u32 _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    u32 _f_4 = _fb_1[2];
    Term _f_5 = _fb_1[3];
    u32 _f_6 = _fb_1[4];
    Term _f_7 = _fb_1[5];
    Term _f_8 = _fb_1[6];
    Term _f_9 = _fb_1[7];
    Term _f_10 = _fb_1[8];
    Term _f_11 = _fb_1[9];
    Term _f_12 = _fb_1[10];
    u32 _f_13 = _fb_1[11];
    u32 _f_14 = _fb_1[12];
    spare_free(e, cls_fit(13), _sp_1);
    r0 = _f_2;
    r1 = _f_3;
    r2 = _f_4;
    r3 = _f_5;
    r4 = _f_6;
    r5 = _f_7;
    r6 = _f_10;
    r7 = _f_11;
    r8 = _f_12;
    r9 = _f_13;
    r10 = _f_14;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0)
  {
    u32 _runtime_0 = r0;
    u32 _runtime_1 = r1;
    u32 _runtime_2 = r2;
    Term _runtime_3 = r3;
    u32 _runtime_4 = r4;
    Term _runtime_5 = r5;
    Term _runtime_6 = r6;
    Term _runtime_7 = r7;
    Term _runtime_8 = r8;
    u32 _runtime_9 = r9;
    u32 _runtime_10 = r10;
    Term _runtime_11 = r11;
    Term _runtime_12 = r12;
    Term _runtime_13 = r13;
    Term _runtime_14 = r14;
    Term _runtime_15 = r15;
    Term _runtime_16 = r16;
    u32 _runtime_17 = r17;
    u32 _reader_0 = r18;
    u32 _reader_1 = r19;
    Term _reader_2 = r20;
    Term _reader_3 = r21;
    u32 _reader_4 = r22;
    Term _reader_5 = r23;
    u32 _reader_6 = r24;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _runtime_0;
      STK(1) = _runtime_1;
      STK(2) = _runtime_2;
      STK(3) = _runtime_3;
      STK(4) = _runtime_4;
      STK(5) = _runtime_5;
      STK(6) = _runtime_6;
      STK(7) = _runtime_7;
      STK(8) = _runtime_8;
      STK(9) = _runtime_9;
      STK(10) = _runtime_10;
      STK(11) = _runtime_11;
      STK(12) = _runtime_12;
      STK(13) = _runtime_13;
      STK(14) = _runtime_14;
      STK(15) = _runtime_15;
      STK(16) = _runtime_16;
      STK(17) = _runtime_17;
      STK(18) = _reader_0;
      STK(19) = _reader_1;
      STK(20) = _reader_2;
      STK(21) = _reader_3;
      STK(22) = _reader_4;
      STK(23) = _reader_6;
      STK(24) = _reader_5;
      STK(25) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K317;
      WL_PUSHN(26);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K317, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _runtime_0;
      e.mem[_t_0 + 1] = _runtime_1;
      e.mem[_t_0 + 2] = _runtime_2;
      e.mem[_t_0 + 3] = _runtime_3;
      e.mem[_t_0 + 4] = _runtime_4;
      e.mem[_t_0 + 5] = _runtime_5;
      e.mem[_t_0 + 6] = _runtime_6;
      e.mem[_t_0 + 7] = _runtime_7;
      e.mem[_t_0 + 8] = _runtime_8;
      e.mem[_t_0 + 9] = _runtime_9;
      e.mem[_t_0 + 10] = _runtime_10;
      e.mem[_t_0 + 11] = _runtime_11;
      e.mem[_t_0 + 12] = _runtime_12;
      e.mem[_t_0 + 13] = _runtime_13;
      e.mem[_t_0 + 14] = _runtime_14;
      e.mem[_t_0 + 15] = _runtime_15;
      e.mem[_t_0 + 16] = _runtime_16;
      e.mem[_t_0 + 17] = _runtime_17;
      e.mem[_t_0 + 18] = _reader_0;
      e.mem[_t_0 + 19] = _reader_1;
      e.mem[_t_0 + 20] = _reader_2;
      e.mem[_t_0 + 21] = _reader_3;
      e.mem[_t_0 + 22] = _reader_4;
      e.mem[_t_0 + 23] = _reader_6;
      e.mem[_t_0 + 24] = _reader_5;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K317, _t_0);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _runtime_12;
      e.mem[_t_1 + 1] = _reader_6;
      return term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP, _t_1);
    }
    r0 = _runtime_12;
    r1 = _reader_6;
    WL_JMP(FID__________SRC_ECS_EVENT_RUNTIME_LOOKUP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K317)
  {
    WL_POPN(25);
    u32 _runtime_18 = STK(0);
    u32 _runtime_19 = STK(1);
    u32 _runtime_20 = STK(2);
    Term _runtime_21 = STK(3);
    u32 _runtime_22 = STK(4);
    Term _runtime_23 = STK(5);
    Term _runtime_24 = STK(6);
    Term _runtime_25 = STK(7);
    Term _runtime_26 = STK(8);
    u32 _runtime_27 = STK(9);
    u32 _runtime_28 = STK(10);
    Term _runtime_29 = STK(11);
    Term _runtime_30 = STK(12);
    Term _runtime_31 = STK(13);
    Term _runtime_32 = STK(14);
    Term _runtime_33 = STK(15);
    Term _runtime_34 = STK(16);
    u32 _runtime_35 = STK(17);
    u32 _reader_7 = STK(18);
    u32 _reader_8 = STK(19);
    Term _reader_9 = STK(20);
    Term _reader_10 = STK(21);
    u32 _reader_11 = STK(22);
    u32 _reader_12 = STK(23);
    Term _reader_13 = STK(24);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_0[3];
    if (spin_54(e, _o_0, _h_0, _h_1, _h_2, _h_3, _reader_12, _runtime_31) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_4 = _o_0[1];
    _v_5 = _o_0[2];
    _v_0 = _v_3;
    _v_1 = _v_4;
    _v_2 = _v_5;
    _runtime_29 = term_keep(e, _runtime_29, 1);
    if (seq) {
      WL_ROOM(26);
      STK(0) = _runtime_18;
      STK(1) = _runtime_19;
      STK(2) = _runtime_20;
      STK(3) = _runtime_21;
      STK(4) = _runtime_22;
      STK(5) = _runtime_23;
      STK(6) = _runtime_24;
      STK(7) = _runtime_25;
      STK(8) = _runtime_26;
      STK(9) = _runtime_27;
      STK(10) = _runtime_28;
      STK(11) = _runtime_29;
      STK(12) = _runtime_30;
      STK(13) = _runtime_31;
      STK(14) = _runtime_32;
      STK(15) = _runtime_33;
      STK(16) = _runtime_34;
      STK(17) = _runtime_35;
      STK(18) = _reader_7;
      STK(19) = _reader_8;
      STK(20) = _reader_9;
      STK(21) = _reader_10;
      STK(22) = _reader_11;
      STK(23) = _reader_12;
      STK(24) = _reader_13;
      STK(25) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K318;
      WL_PUSHN(26);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K318, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _runtime_18;
      e.mem[_t_2 + 1] = _runtime_19;
      e.mem[_t_2 + 2] = _runtime_20;
      e.mem[_t_2 + 3] = _runtime_21;
      e.mem[_t_2 + 4] = _runtime_22;
      e.mem[_t_2 + 5] = _runtime_23;
      e.mem[_t_2 + 6] = _runtime_24;
      e.mem[_t_2 + 7] = _runtime_25;
      e.mem[_t_2 + 8] = _runtime_26;
      e.mem[_t_2 + 9] = _runtime_27;
      e.mem[_t_2 + 10] = _runtime_28;
      e.mem[_t_2 + 11] = _runtime_29;
      e.mem[_t_2 + 12] = _runtime_30;
      e.mem[_t_2 + 13] = _runtime_31;
      e.mem[_t_2 + 14] = _runtime_32;
      e.mem[_t_2 + 15] = _runtime_33;
      e.mem[_t_2 + 16] = _runtime_34;
      e.mem[_t_2 + 17] = _runtime_35;
      e.mem[_t_2 + 18] = _reader_7;
      e.mem[_t_2 + 19] = _reader_8;
      e.mem[_t_2 + 20] = _reader_9;
      e.mem[_t_2 + 21] = _reader_10;
      e.mem[_t_2 + 22] = _reader_11;
      e.mem[_t_2 + 23] = _reader_12;
      e.mem[_t_2 + 24] = _reader_13;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K318, _t_2);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _reader_13;
      e.mem[_t_3 + 1] = _runtime_29;
      e.mem[_t_3 + 2] = _v_0;
      e.mem[_t_3 + 3] = _v_1;
      e.mem[_t_3 + 4] = _v_2;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0, _t_3);
    }
    r0 = _reader_13;
    r1 = _runtime_29;
    r2 = _v_0;
    r3 = _v_1;
    r4 = _v_2;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ALL_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K318)
  {
    WL_POPN(25);
    u32 _runtime_36 = STK(0);
    u32 _runtime_37 = STK(1);
    u32 _runtime_38 = STK(2);
    Term _runtime_39 = STK(3);
    u32 _runtime_40 = STK(4);
    Term _runtime_41 = STK(5);
    Term _runtime_42 = STK(6);
    Term _runtime_43 = STK(7);
    Term _runtime_44 = STK(8);
    u32 _runtime_45 = STK(9);
    u32 _runtime_46 = STK(10);
    Term _runtime_47 = STK(11);
    Term _runtime_48 = STK(12);
    Term _runtime_49 = STK(13);
    Term _runtime_50 = STK(14);
    Term _runtime_51 = STK(15);
    Term _runtime_52 = STK(16);
    u32 _runtime_53 = STK(17);
    u32 _reader_14 = STK(18);
    u32 _reader_15 = STK(19);
    Term _reader_16 = STK(20);
    Term _reader_17 = STK(21);
    u32 _reader_18 = STK(22);
    u32 _reader_19 = STK(23);
    Term _reader_20 = STK(24);
    Term _h_4 = r0;
    WL_OPEN
    u32 _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _o_1[12];
    if (spin_55(e, _o_1, _runtime_36, _runtime_37, _runtime_38, _runtime_39, blk_loc(e.mem, _runtime_39), _runtime_40, _runtime_41, _runtime_42, blk_loc(e.mem, _runtime_42), _runtime_43, blk_loc(e.mem, _runtime_43), _runtime_44, blk_loc(e.mem, _runtime_44), _runtime_45, _runtime_46) == 0) {
      return 0;
    }
    _v_18 = _o_1[0];
    _v_19 = _o_1[1];
    _v_20 = _o_1[2];
    _v_21 = _o_1[3];
    _v_22 = _o_1[4];
    _v_23 = _o_1[5];
    _v_24 = _o_1[6];
    _v_25 = _o_1[7];
    _v_26 = _o_1[8];
    _v_27 = _o_1[9];
    _v_28 = _o_1[10];
    _v_29 = _o_1[11];
    _v_6 = _v_18;
    _v_7 = _v_19;
    _v_8 = _v_20;
    _v_9 = _v_21;
    _v_10 = _v_22;
    _v_11 = _v_23;
    _v_12 = _v_24;
    _v_13 = _v_25;
    _v_14 = _v_26;
    _v_15 = _v_27;
    _v_16 = _v_28;
    _v_17 = _v_29;
    if (seq) {
      WL_ROOM(10);
      STK(0) = _runtime_47;
      STK(1) = _runtime_48;
      STK(2) = _runtime_49;
      STK(3) = _runtime_50;
      STK(4) = _runtime_51;
      STK(5) = _runtime_52;
      STK(6) = _runtime_53;
      STK(7) = _reader_19;
      STK(8) = _reader_20;
      STK(9) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K319;
      WL_PUSHN(10);
    } else {
      u64 _t_4 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K319, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _runtime_47;
      e.mem[_t_4 + 1] = _runtime_48;
      e.mem[_t_4 + 2] = _runtime_49;
      e.mem[_t_4 + 3] = _runtime_50;
      e.mem[_t_4 + 4] = _runtime_51;
      e.mem[_t_4 + 5] = _runtime_52;
      e.mem[_t_4 + 6] = _runtime_53;
      e.mem[_t_4 + 7] = _reader_19;
      e.mem[_t_4 + 8] = _reader_20;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K319, _t_4);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0)) {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _reader_14;
      e.mem[_t_5 + 1] = _reader_15;
      e.mem[_t_5 + 2] = _reader_16;
      e.mem[_t_5 + 3] = _reader_17;
      e.mem[_t_5 + 4] = _reader_18;
      e.mem[_t_5 + 5] = _v_6;
      e.mem[_t_5 + 6] = _v_7;
      e.mem[_t_5 + 7] = _v_8;
      e.mem[_t_5 + 8] = _v_9;
      e.mem[_t_5 + 9] = _v_10;
      e.mem[_t_5 + 10] = _v_11;
      e.mem[_t_5 + 11] = _v_12;
      e.mem[_t_5 + 12] = _v_13;
      e.mem[_t_5 + 13] = _v_14;
      e.mem[_t_5 + 14] = _v_15;
      e.mem[_t_5 + 15] = _v_16;
      e.mem[_t_5 + 16] = _v_17;
      e.mem[_t_5 + 17] = _h_4;
      return term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0, _t_5);
    }
    r0 = _reader_14;
    r1 = _reader_15;
    r2 = _reader_16;
    r3 = _reader_17;
    r4 = _reader_18;
    r5 = _v_6;
    r6 = _v_7;
    r7 = _v_8;
    r8 = _v_9;
    r9 = _v_10;
    r10 = _v_11;
    r11 = _v_12;
    r12 = _v_13;
    r13 = _v_14;
    r14 = _v_15;
    r15 = _v_16;
    r16 = _v_17;
    r17 = _h_4;
    WL_JMP(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_CLOCKED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K319)
  {
    WL_POPN(9);
    Term _runtime_54 = STK(0);
    Term _runtime_55 = STK(1);
    Term _runtime_56 = STK(2);
    Term _runtime_57 = STK(3);
    Term _runtime_58 = STK(4);
    Term _runtime_59 = STK(5);
    u32 _runtime_60 = STK(6);
    u32 _reader_21 = STK(7);
    Term _reader_22 = STK(8);
    u32 _h_5 = r0;
    u32 _h_6 = r1;
    u32 _h_7 = r2;
    Term _h_8 = r3;
    Term _h_9 = r4;
    u32 _h_10 = r5;
    u32 _h_11 = r6;
    u32 _h_12 = r7;
    u32 _h_13 = r8;
    Term _h_14 = r9;
    Term _h_15 = r10;
    Term _h_16 = r11;
    Term _h_17 = r12;
    Term _h_18 = r13;
    Term _h_19 = r14;
    Term _h_20 = r15;
    u32 _h_21 = r16;
    Term _h_22 = r17;
    Term _h_23 = r18;
    WL_OPEN
    if (_h_5 == 1) {
      term_sink(e, _h_22);
      r0 = _h_11;
      r1 = _h_12;
      r2 = _h_13;
      r3 = _h_14;
      r4 = _h_15;
      r5 = _h_16;
      r6 = _h_17;
      r7 = _h_18;
      r8 = _h_19;
      r9 = _h_20;
      r10 = _h_21;
      r11 = _runtime_54;
      r12 = _runtime_55;
      r13 = _runtime_56;
      r14 = _runtime_57;
      r15 = _runtime_58;
      r16 = _runtime_59;
      r17 = _runtime_60;
      r18 = _h_6;
      r19 = _h_7;
      r20 = _h_8;
      r21 = _h_9;
      r22 = _h_10;
      r23 = _reader_22;
      r24 = _reader_21;
      r25 = 2;
      r26 = 0;
      WL_RETN(27);
    } else {
      if (_h_11 == 1) {
        u32 _v_30 = 0;
        u32 _v_31 = 0;
        u32 _v_32 = 0;
        Term _v_33 = 0;
        u32 _v_34 = 0;
        Term _v_35 = 0;
        Term _v_36 = 0;
        Term _v_37 = 0;
        Term _v_38 = 0;
        u32 _v_39 = 0;
        u32 _v_40 = 0;
        u32 _v_41 = 0;
        u32 _v_42 = 0;
        u32 _v_43 = 0;
        u32 _v_44 = 0;
        Term _v_45 = 0;
        u32 _v_46 = 0;
        Term _v_47 = 0;
        Term _v_48 = 0;
        Term _v_49 = 0;
        Term _v_50 = 0;
        u32 _v_51 = 0;
        u32 _v_52 = 0;
        u32 _v_53 = 0;
        Term _o_2[12];
        if (spin_26(e, _o_2, _h_12, _h_13, _h_14, _h_15, blk_loc(e.mem, _h_15), _h_16, _h_17, _h_18, blk_loc(e.mem, _h_18), _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20), _h_21, _h_22) == 0) {
          return 0;
        }
        _v_42 = _o_2[0];
        _v_43 = _o_2[1];
        _v_44 = _o_2[2];
        _v_45 = _o_2[3];
        _v_46 = _o_2[4];
        _v_47 = _o_2[5];
        _v_48 = _o_2[6];
        _v_49 = _o_2[7];
        _v_50 = _o_2[8];
        _v_51 = _o_2[9];
        _v_52 = _o_2[10];
        _v_53 = _o_2[11];
        _v_30 = _v_42;
        _v_31 = _v_43;
        _v_32 = _v_44;
        _v_33 = _v_45;
        _v_34 = _v_46;
        _v_35 = _v_47;
        _v_36 = _v_48;
        _v_37 = _v_49;
        _v_38 = _v_50;
        _v_39 = _v_51;
        _v_40 = _v_52;
        _v_41 = _v_53;
        if (seq) {
          WL_ROOM(26);
          STK(0) = _v_30;
          STK(1) = _v_31;
          STK(2) = _v_32;
          STK(3) = _v_33;
          STK(4) = _v_34;
          STK(5) = _v_35;
          STK(6) = _v_36;
          STK(7) = _v_37;
          STK(8) = _v_38;
          STK(9) = _v_39;
          STK(10) = _v_40;
          STK(11) = _v_41;
          STK(12) = _h_6;
          STK(13) = _h_7;
          STK(14) = _h_8;
          STK(15) = _h_9;
          STK(16) = _h_10;
          STK(17) = _reader_22;
          STK(18) = _runtime_55;
          STK(19) = _reader_21;
          STK(20) = _runtime_56;
          STK(21) = _runtime_57;
          STK(22) = _runtime_58;
          STK(23) = _runtime_59;
          STK(24) = _runtime_60;
          STK(25) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K320;
          WL_PUSHN(26);
        } else {
          u64 _t_6 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K320, WL_CONT, WL_IDX, 1);
          e.mem[_t_6 + 0] = _v_30;
          e.mem[_t_6 + 1] = _v_31;
          e.mem[_t_6 + 2] = _v_32;
          e.mem[_t_6 + 3] = _v_33;
          e.mem[_t_6 + 4] = _v_34;
          e.mem[_t_6 + 5] = _v_35;
          e.mem[_t_6 + 6] = _v_36;
          e.mem[_t_6 + 7] = _v_37;
          e.mem[_t_6 + 8] = _v_38;
          e.mem[_t_6 + 9] = _v_39;
          e.mem[_t_6 + 10] = _v_40;
          e.mem[_t_6 + 11] = _v_41;
          e.mem[_t_6 + 12] = _h_6;
          e.mem[_t_6 + 13] = _h_7;
          e.mem[_t_6 + 14] = _h_8;
          e.mem[_t_6 + 15] = _h_9;
          e.mem[_t_6 + 16] = _h_10;
          e.mem[_t_6 + 17] = _reader_22;
          e.mem[_t_6 + 18] = _runtime_55;
          e.mem[_t_6 + 19] = _reader_21;
          e.mem[_t_6 + 20] = _runtime_56;
          e.mem[_t_6 + 21] = _runtime_57;
          e.mem[_t_6 + 22] = _runtime_58;
          e.mem[_t_6 + 23] = _runtime_59;
          e.mem[_t_6 + 24] = _runtime_60;
          WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K320, _t_6);
          WL_IDX = 25;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0)) {
          u64 _t_7 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_7 + 0] = _reader_22;
          e.mem[_t_7 + 1] = _runtime_54;
          e.mem[_t_7 + 2] = _reader_21;
          return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0, _t_7);
        }
        r0 = _reader_22;
        r1 = _runtime_54;
        r2 = _reader_21;
        WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0);
      } else {
        u32 _v_78 = 0;
        u32 _v_79 = 0;
        u32 _v_80 = 0;
        Term _v_81 = 0;
        u32 _v_82 = 0;
        Term _v_83 = 0;
        Term _v_84 = 0;
        Term _v_85 = 0;
        Term _v_86 = 0;
        u32 _v_87 = 0;
        u32 _v_88 = 0;
        u32 _v_89 = 0;
        u32 _v_90 = 0;
        u32 _v_91 = 0;
        u32 _v_92 = 0;
        Term _v_93 = 0;
        u32 _v_94 = 0;
        Term _v_95 = 0;
        Term _v_96 = 0;
        Term _v_97 = 0;
        Term _v_98 = 0;
        u32 _v_99 = 0;
        u32 _v_100 = 0;
        u32 _v_101 = 0;
        Term _o_3[12];
        if (spin_26(e, _o_3, _h_12, _h_13, _h_14, _h_15, blk_loc(e.mem, _h_15), _h_16, _h_17, _h_18, blk_loc(e.mem, _h_18), _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20), _h_21, _h_22) == 0) {
          return 0;
        }
        _v_90 = _o_3[0];
        _v_91 = _o_3[1];
        _v_92 = _o_3[2];
        _v_93 = _o_3[3];
        _v_94 = _o_3[4];
        _v_95 = _o_3[5];
        _v_96 = _o_3[6];
        _v_97 = _o_3[7];
        _v_98 = _o_3[8];
        _v_99 = _o_3[9];
        _v_100 = _o_3[10];
        _v_101 = _o_3[11];
        _v_78 = _v_90;
        _v_79 = _v_91;
        _v_80 = _v_92;
        _v_81 = _v_93;
        _v_82 = _v_94;
        _v_83 = _v_95;
        _v_84 = _v_96;
        _v_85 = _v_97;
        _v_86 = _v_98;
        _v_87 = _v_99;
        _v_88 = _v_100;
        _v_89 = _v_101;
        if (seq) {
          WL_ROOM(27);
          STK(0) = _v_78;
          STK(1) = _v_79;
          STK(2) = _v_80;
          STK(3) = _v_81;
          STK(4) = _v_82;
          STK(5) = _v_83;
          STK(6) = _v_84;
          STK(7) = _v_85;
          STK(8) = _v_86;
          STK(9) = _v_87;
          STK(10) = _v_88;
          STK(11) = _v_89;
          STK(12) = _h_6;
          STK(13) = _h_7;
          STK(14) = _h_8;
          STK(15) = _h_9;
          STK(16) = _h_10;
          STK(17) = _reader_22;
          STK(18) = _runtime_55;
          STK(19) = _reader_21;
          STK(20) = _runtime_56;
          STK(21) = _runtime_57;
          STK(22) = _runtime_58;
          STK(23) = _runtime_59;
          STK(24) = _runtime_60;
          STK(25) = _h_23;
          STK(26) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K322;
          WL_PUSHN(27);
        } else {
          u64 _t_10 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K322, WL_CONT, WL_IDX, 1);
          e.mem[_t_10 + 0] = _v_78;
          e.mem[_t_10 + 1] = _v_79;
          e.mem[_t_10 + 2] = _v_80;
          e.mem[_t_10 + 3] = _v_81;
          e.mem[_t_10 + 4] = _v_82;
          e.mem[_t_10 + 5] = _v_83;
          e.mem[_t_10 + 6] = _v_84;
          e.mem[_t_10 + 7] = _v_85;
          e.mem[_t_10 + 8] = _v_86;
          e.mem[_t_10 + 9] = _v_87;
          e.mem[_t_10 + 10] = _v_88;
          e.mem[_t_10 + 11] = _v_89;
          e.mem[_t_10 + 12] = _h_6;
          e.mem[_t_10 + 13] = _h_7;
          e.mem[_t_10 + 14] = _h_8;
          e.mem[_t_10 + 15] = _h_9;
          e.mem[_t_10 + 16] = _h_10;
          e.mem[_t_10 + 17] = _reader_22;
          e.mem[_t_10 + 18] = _runtime_55;
          e.mem[_t_10 + 19] = _reader_21;
          e.mem[_t_10 + 20] = _runtime_56;
          e.mem[_t_10 + 21] = _runtime_57;
          e.mem[_t_10 + 22] = _runtime_58;
          e.mem[_t_10 + 23] = _runtime_59;
          e.mem[_t_10 + 24] = _runtime_60;
          e.mem[_t_10 + 25] = _h_23;
          WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K322, _t_10);
          WL_IDX = 26;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0)) {
          u64 _t_11 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_11 + 0] = _reader_22;
          e.mem[_t_11 + 1] = _runtime_54;
          e.mem[_t_11 + 2] = _reader_21;
          return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0, _t_11);
        }
        r0 = _reader_22;
        r1 = _runtime_54;
        r2 = _reader_21;
        WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_READINGS_ACTIVATE_0);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K320)
  {
    WL_POPN(25);
    u32 _v_54 = STK(0);
    u32 _v_55 = STK(1);
    u32 _v_56 = STK(2);
    Term _v_57 = STK(3);
    u32 _v_58 = STK(4);
    Term _v_59 = STK(5);
    Term _v_60 = STK(6);
    Term _v_61 = STK(7);
    Term _v_62 = STK(8);
    u32 _v_63 = STK(9);
    u32 _v_64 = STK(10);
    u32 _v_65 = STK(11);
    u32 _h_25 = STK(12);
    u32 _h_26 = STK(13);
    Term _h_27 = STK(14);
    Term _h_28 = STK(15);
    u32 _h_29 = STK(16);
    Term _reader_23 = STK(17);
    Term _runtime_61 = STK(18);
    u32 _reader_24 = STK(19);
    Term _runtime_62 = STK(20);
    Term _runtime_63 = STK(21);
    Term _runtime_64 = STK(22);
    Term _runtime_65 = STK(23);
    u32 _runtime_66 = STK(24);
    Term _h_24 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _v_54;
      STK(1) = _v_55;
      STK(2) = _v_56;
      STK(3) = _v_57;
      STK(4) = _v_58;
      STK(5) = _v_59;
      STK(6) = _v_60;
      STK(7) = _v_61;
      STK(8) = _v_62;
      STK(9) = _v_63;
      STK(10) = _v_64;
      STK(11) = _v_65;
      STK(12) = _h_25;
      STK(13) = _h_26;
      STK(14) = _h_27;
      STK(15) = _h_28;
      STK(16) = _h_29;
      STK(17) = _reader_23;
      STK(18) = _reader_24;
      STK(19) = _runtime_63;
      STK(20) = _runtime_64;
      STK(21) = _runtime_65;
      STK(22) = _runtime_66;
      STK(23) = _h_24;
      STK(24) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K321;
      WL_PUSHN(25);
    } else {
      u64 _t_8 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K321, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _v_54;
      e.mem[_t_8 + 1] = _v_55;
      e.mem[_t_8 + 2] = _v_56;
      e.mem[_t_8 + 3] = _v_57;
      e.mem[_t_8 + 4] = _v_58;
      e.mem[_t_8 + 5] = _v_59;
      e.mem[_t_8 + 6] = _v_60;
      e.mem[_t_8 + 7] = _v_61;
      e.mem[_t_8 + 8] = _v_62;
      e.mem[_t_8 + 9] = _v_63;
      e.mem[_t_8 + 10] = _v_64;
      e.mem[_t_8 + 11] = _v_65;
      e.mem[_t_8 + 12] = _h_25;
      e.mem[_t_8 + 13] = _h_26;
      e.mem[_t_8 + 14] = _h_27;
      e.mem[_t_8 + 15] = _h_28;
      e.mem[_t_8 + 16] = _h_29;
      e.mem[_t_8 + 17] = _reader_23;
      e.mem[_t_8 + 18] = _reader_24;
      e.mem[_t_8 + 19] = _runtime_63;
      e.mem[_t_8 + 20] = _runtime_64;
      e.mem[_t_8 + 21] = _runtime_65;
      e.mem[_t_8 + 22] = _runtime_66;
      e.mem[_t_8 + 23] = _h_24;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K321, _t_8);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE)) {
      u64 _t_9 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _runtime_61;
      e.mem[_t_9 + 1] = _reader_24;
      e.mem[_t_9 + 2] = _runtime_62;
      return term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE, _t_9);
    }
    r0 = _runtime_61;
    r1 = _reader_24;
    r2 = _runtime_62;
    WL_JMP(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K321)
  {
    WL_POPN(24);
    u32 _v_66 = STK(0);
    u32 _v_67 = STK(1);
    u32 _v_68 = STK(2);
    Term _v_69 = STK(3);
    u32 _v_70 = STK(4);
    Term _v_71 = STK(5);
    Term _v_72 = STK(6);
    Term _v_73 = STK(7);
    Term _v_74 = STK(8);
    u32 _v_75 = STK(9);
    u32 _v_76 = STK(10);
    u32 _v_77 = STK(11);
    u32 _h_31 = STK(12);
    u32 _h_32 = STK(13);
    Term _h_33 = STK(14);
    Term _h_34 = STK(15);
    u32 _h_35 = STK(16);
    Term _reader_25 = STK(17);
    u32 _reader_26 = STK(18);
    Term _runtime_67 = STK(19);
    Term _runtime_68 = STK(20);
    Term _runtime_69 = STK(21);
    u32 _runtime_70 = STK(22);
    Term _h_36 = STK(23);
    Term _h_30 = r0;
    WL_OPEN
    r0 = _v_66;
    r1 = _v_67;
    r2 = _v_68;
    r3 = _v_69;
    r4 = _v_70;
    r5 = _v_71;
    r6 = _v_72;
    r7 = _v_73;
    r8 = _v_74;
    r9 = _v_75;
    r10 = _v_76;
    r11 = _h_36;
    r12 = _h_30;
    r13 = ((u64)_v_77);
    r14 = _runtime_67;
    r15 = _runtime_68;
    r16 = _runtime_69;
    r17 = _runtime_70;
    r18 = _h_31;
    r19 = _h_32;
    r20 = _h_33;
    r21 = _h_34;
    r22 = _h_35;
    r23 = _reader_25;
    r24 = _reader_26;
    r25 = 1;
    r26 = 0;
    WL_RETN(27);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K322)
  {
    WL_POPN(26);
    u32 _v_102 = STK(0);
    u32 _v_103 = STK(1);
    u32 _v_104 = STK(2);
    Term _v_105 = STK(3);
    u32 _v_106 = STK(4);
    Term _v_107 = STK(5);
    Term _v_108 = STK(6);
    Term _v_109 = STK(7);
    Term _v_110 = STK(8);
    u32 _v_111 = STK(9);
    u32 _v_112 = STK(10);
    u32 _v_113 = STK(11);
    u32 _h_38 = STK(12);
    u32 _h_39 = STK(13);
    Term _h_40 = STK(14);
    Term _h_41 = STK(15);
    u32 _h_42 = STK(16);
    Term _reader_27 = STK(17);
    Term _runtime_71 = STK(18);
    u32 _reader_28 = STK(19);
    Term _runtime_72 = STK(20);
    Term _runtime_73 = STK(21);
    Term _runtime_74 = STK(22);
    Term _runtime_75 = STK(23);
    u32 _runtime_76 = STK(24);
    Term _h_43 = STK(25);
    Term _h_37 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(16);
      STK(0) = _v_113;
      STK(1) = _h_38;
      STK(2) = _h_39;
      STK(3) = _h_40;
      STK(4) = _h_41;
      STK(5) = _h_42;
      STK(6) = _reader_27;
      STK(7) = _runtime_71;
      STK(8) = _reader_28;
      STK(9) = _runtime_72;
      STK(10) = _runtime_73;
      STK(11) = _runtime_74;
      STK(12) = _runtime_75;
      STK(13) = _runtime_76;
      STK(14) = _h_43;
      STK(15) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K323;
      WL_PUSHN(16);
    } else {
      u64 _t_12 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K323, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _v_113;
      e.mem[_t_12 + 1] = _h_38;
      e.mem[_t_12 + 2] = _h_39;
      e.mem[_t_12 + 3] = _h_40;
      e.mem[_t_12 + 4] = _h_41;
      e.mem[_t_12 + 5] = _h_42;
      e.mem[_t_12 + 6] = _reader_27;
      e.mem[_t_12 + 7] = _runtime_71;
      e.mem[_t_12 + 8] = _reader_28;
      e.mem[_t_12 + 9] = _runtime_72;
      e.mem[_t_12 + 10] = _runtime_73;
      e.mem[_t_12 + 11] = _runtime_74;
      e.mem[_t_12 + 12] = _runtime_75;
      e.mem[_t_12 + 13] = _runtime_76;
      e.mem[_t_12 + 14] = _h_43;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K323, _t_12);
      WL_IDX = 15;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0)) {
      u64 _t_13 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _v_102;
      e.mem[_t_13 + 1] = _v_103;
      e.mem[_t_13 + 2] = _v_104;
      e.mem[_t_13 + 3] = _v_105;
      e.mem[_t_13 + 4] = _v_106;
      e.mem[_t_13 + 5] = _v_107;
      e.mem[_t_13 + 6] = _v_108;
      e.mem[_t_13 + 7] = _v_109;
      e.mem[_t_13 + 8] = _v_110;
      e.mem[_t_13 + 9] = _v_111;
      e.mem[_t_13 + 10] = _v_112;
      e.mem[_t_13 + 11] = ((u64)_v_113);
      e.mem[_t_13 + 12] = _h_37;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0, _t_13);
    }
    r0 = _v_102;
    r1 = _v_103;
    r2 = _v_104;
    r3 = _v_105;
    r4 = _v_106;
    r5 = _v_107;
    r6 = _v_108;
    r7 = _v_109;
    r8 = _v_110;
    r9 = _v_111;
    r10 = _v_112;
    r11 = ((u64)_v_113);
    r12 = _h_37;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K323)
  {
    WL_POPN(15);
    u32 _v_114 = STK(0);
    u32 _h_56 = STK(1);
    u32 _h_57 = STK(2);
    Term _h_58 = STK(3);
    Term _h_59 = STK(4);
    u32 _h_60 = STK(5);
    Term _reader_29 = STK(6);
    Term _runtime_77 = STK(7);
    u32 _reader_30 = STK(8);
    Term _runtime_78 = STK(9);
    Term _runtime_79 = STK(10);
    Term _runtime_80 = STK(11);
    Term _runtime_81 = STK(12);
    u32 _runtime_82 = STK(13);
    Term _h_61 = STK(14);
    u32 _h_44 = r0;
    u32 _h_45 = r1;
    u32 _h_46 = r2;
    Term _h_47 = r3;
    u32 _h_48 = r4;
    Term _h_49 = r5;
    Term _h_50 = r6;
    Term _h_51 = r7;
    Term _h_52 = r8;
    u32 _h_53 = r9;
    u32 _h_54 = r10;
    Term _h_55 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _v_114;
      STK(1) = _h_56;
      STK(2) = _h_57;
      STK(3) = _h_58;
      STK(4) = _h_59;
      STK(5) = _h_60;
      STK(6) = _reader_29;
      STK(7) = _reader_30;
      STK(8) = _runtime_79;
      STK(9) = _runtime_80;
      STK(10) = _runtime_81;
      STK(11) = _runtime_82;
      STK(12) = _h_61;
      STK(13) = _h_44;
      STK(14) = _h_45;
      STK(15) = _h_46;
      STK(16) = _h_47;
      STK(17) = _h_48;
      STK(18) = _h_49;
      STK(19) = _h_50;
      STK(20) = _h_51;
      STK(21) = _h_52;
      STK(22) = _h_53;
      STK(23) = _h_54;
      STK(24) = _h_55;
      STK(25) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K324;
      WL_PUSHN(26);
    } else {
      u64 _t_14 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K324, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _v_114;
      e.mem[_t_14 + 1] = _h_56;
      e.mem[_t_14 + 2] = _h_57;
      e.mem[_t_14 + 3] = _h_58;
      e.mem[_t_14 + 4] = _h_59;
      e.mem[_t_14 + 5] = _h_60;
      e.mem[_t_14 + 6] = _reader_29;
      e.mem[_t_14 + 7] = _reader_30;
      e.mem[_t_14 + 8] = _runtime_79;
      e.mem[_t_14 + 9] = _runtime_80;
      e.mem[_t_14 + 10] = _runtime_81;
      e.mem[_t_14 + 11] = _runtime_82;
      e.mem[_t_14 + 12] = _h_61;
      e.mem[_t_14 + 13] = _h_44;
      e.mem[_t_14 + 14] = _h_45;
      e.mem[_t_14 + 15] = _h_46;
      e.mem[_t_14 + 16] = _h_47;
      e.mem[_t_14 + 17] = _h_48;
      e.mem[_t_14 + 18] = _h_49;
      e.mem[_t_14 + 19] = _h_50;
      e.mem[_t_14 + 20] = _h_51;
      e.mem[_t_14 + 21] = _h_52;
      e.mem[_t_14 + 22] = _h_53;
      e.mem[_t_14 + 23] = _h_54;
      e.mem[_t_14 + 24] = _h_55;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K324, _t_14);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE)) {
      u64 _t_15 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _runtime_77;
      e.mem[_t_15 + 1] = _reader_30;
      e.mem[_t_15 + 2] = _runtime_78;
      return term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE, _t_15);
    }
    r0 = _runtime_77;
    r1 = _reader_30;
    r2 = _runtime_78;
    WL_JMP(FID__________SRC_ECS_EVENT_RUNTIME_ACTIVATE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K324)
  {
    WL_POPN(25);
    u32 _v_115 = STK(0);
    u32 _h_63 = STK(1);
    u32 _h_64 = STK(2);
    Term _h_65 = STK(3);
    Term _h_66 = STK(4);
    u32 _h_67 = STK(5);
    Term _reader_31 = STK(6);
    u32 _reader_32 = STK(7);
    Term _runtime_83 = STK(8);
    Term _runtime_84 = STK(9);
    Term _runtime_85 = STK(10);
    u32 _runtime_86 = STK(11);
    Term _h_68 = STK(12);
    u32 _h_69 = STK(13);
    u32 _h_70 = STK(14);
    u32 _h_71 = STK(15);
    Term _h_72 = STK(16);
    u32 _h_73 = STK(17);
    Term _h_74 = STK(18);
    Term _h_75 = STK(19);
    Term _h_76 = STK(20);
    Term _h_77 = STK(21);
    u32 _h_78 = STK(22);
    u32 _h_79 = STK(23);
    Term _h_80 = STK(24);
    Term _h_62 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(26);
      STK(0) = _v_115;
      STK(1) = _h_63;
      STK(2) = _h_64;
      STK(3) = _h_65;
      STK(4) = _h_66;
      STK(5) = _h_67;
      STK(6) = _reader_31;
      STK(7) = _reader_32;
      STK(8) = _runtime_83;
      STK(9) = _runtime_84;
      STK(10) = _runtime_85;
      STK(11) = _runtime_86;
      STK(12) = _h_68;
      STK(13) = _h_69;
      STK(14) = _h_70;
      STK(15) = _h_71;
      STK(16) = _h_72;
      STK(17) = _h_73;
      STK(18) = _h_74;
      STK(19) = _h_75;
      STK(20) = _h_76;
      STK(21) = _h_77;
      STK(22) = _h_78;
      STK(23) = _h_79;
      STK(24) = _h_80;
      STK(25) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K325;
      WL_PUSHN(26);
    } else {
      u64 _t_16 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K325, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _v_115;
      e.mem[_t_16 + 1] = _h_63;
      e.mem[_t_16 + 2] = _h_64;
      e.mem[_t_16 + 3] = _h_65;
      e.mem[_t_16 + 4] = _h_66;
      e.mem[_t_16 + 5] = _h_67;
      e.mem[_t_16 + 6] = _reader_31;
      e.mem[_t_16 + 7] = _reader_32;
      e.mem[_t_16 + 8] = _runtime_83;
      e.mem[_t_16 + 9] = _runtime_84;
      e.mem[_t_16 + 10] = _runtime_85;
      e.mem[_t_16 + 11] = _runtime_86;
      e.mem[_t_16 + 12] = _h_68;
      e.mem[_t_16 + 13] = _h_69;
      e.mem[_t_16 + 14] = _h_70;
      e.mem[_t_16 + 15] = _h_71;
      e.mem[_t_16 + 16] = _h_72;
      e.mem[_t_16 + 17] = _h_73;
      e.mem[_t_16 + 18] = _h_74;
      e.mem[_t_16 + 19] = _h_75;
      e.mem[_t_16 + 20] = _h_76;
      e.mem[_t_16 + 21] = _h_77;
      e.mem[_t_16 + 22] = _h_78;
      e.mem[_t_16 + 23] = _h_79;
      e.mem[_t_16 + 24] = _h_80;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K325, _t_16);
      WL_IDX = 25;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE)) {
      u64 _t_17 = task_node(e, FID__________SRC_ECS_EVENT_RUNTIME_UPDATE, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_62;
      e.mem[_t_17 + 1] = _reader_32;
      e.mem[_t_17 + 2] = ((u64)_v_115);
      e.mem[_t_17 + 3] = 0;
      return term_tsk(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE, _t_17);
    }
    r0 = _h_62;
    r1 = _reader_32;
    r2 = ((u64)_v_115);
    r3 = 0;
    WL_JMP(FID__________SRC_ECS_EVENT_RUNTIME_UPDATE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0_K325)
  {
    WL_POPN(25);
    u32 _v_116 = STK(0);
    u32 _h_82 = STK(1);
    u32 _h_83 = STK(2);
    Term _h_84 = STK(3);
    Term _h_85 = STK(4);
    u32 _h_86 = STK(5);
    Term _reader_33 = STK(6);
    u32 _reader_34 = STK(7);
    Term _runtime_87 = STK(8);
    Term _runtime_88 = STK(9);
    Term _runtime_89 = STK(10);
    u32 _runtime_90 = STK(11);
    Term _h_87 = STK(12);
    u32 _h_88 = STK(13);
    u32 _h_89 = STK(14);
    u32 _h_90 = STK(15);
    Term _h_91 = STK(16);
    u32 _h_92 = STK(17);
    Term _h_93 = STK(18);
    Term _h_94 = STK(19);
    Term _h_95 = STK(20);
    Term _h_96 = STK(21);
    u32 _h_97 = STK(22);
    u32 _h_98 = STK(23);
    Term _h_99 = STK(24);
    Term _h_81 = r0;
    WL_OPEN
    u32 _v_117 = 0;
    u32 _v_118 = 0;
    u32 _v_119 = 0;
    Term _v_120 = 0;
    u32 _v_121 = 0;
    Term _v_122 = 0;
    Term _v_123 = 0;
    Term _v_124 = 0;
    Term _v_125 = 0;
    u32 _v_126 = 0;
    u32 _v_127 = 0;
    Term _v_128 = 0;
    Term _v_129 = 0;
    Term _v_130 = 0;
    Term _v_131 = 0;
    Term _v_132 = 0;
    Term _v_133 = 0;
    u32 _v_134 = 0;
    u32 _v_135 = 0;
    u32 _v_136 = 0;
    Term _v_137 = 0;
    Term _v_138 = 0;
    u32 _v_139 = 0;
    Term _v_140 = 0;
    u32 _v_141 = 0;
    u32 _v_142 = 0;
    Term _v_143 = 0;
    Term _o_4[27];
    if (spin_38(e, _o_4, _reader_34, _h_88, _h_89, _h_90, _h_91, blk_loc(e.mem, _h_91), _h_92, _h_93, _h_94, blk_loc(e.mem, _h_94), _h_95, blk_loc(e.mem, _h_95), _h_96, blk_loc(e.mem, _h_96), _h_97, _h_98, _h_99, blk_loc(e.mem, _h_99), _h_82, _h_83, _h_84, blk_loc(e.mem, _h_84), _h_85, blk_loc(e.mem, _h_85), _h_86, _reader_33, blk_loc(e.mem, _reader_33), _h_81, blk_loc(e.mem, _h_81), ((u64)_v_116), _runtime_87, _runtime_88, _runtime_89, _runtime_90, _h_87, blk_loc(e.mem, _h_87)) == 0) {
      return 0;
    }
    _v_117 = _o_4[0];
    _v_118 = _o_4[1];
    _v_119 = _o_4[2];
    _v_120 = _o_4[3];
    _v_121 = _o_4[4];
    _v_122 = _o_4[5];
    _v_123 = _o_4[6];
    _v_124 = _o_4[7];
    _v_125 = _o_4[8];
    _v_126 = _o_4[9];
    _v_127 = _o_4[10];
    _v_128 = _o_4[11];
    _v_129 = _o_4[12];
    _v_130 = _o_4[13];
    _v_131 = _o_4[14];
    _v_132 = _o_4[15];
    _v_133 = _o_4[16];
    _v_134 = _o_4[17];
    _v_135 = _o_4[18];
    _v_136 = _o_4[19];
    _v_137 = _o_4[20];
    _v_138 = _o_4[21];
    _v_139 = _o_4[22];
    _v_140 = _o_4[23];
    _v_141 = _o_4[24];
    _v_142 = _o_4[25];
    _v_143 = _o_4[26];
    r0 = _v_117;
    r1 = _v_118;
    r2 = _v_119;
    r3 = _v_120;
    r4 = _v_121;
    r5 = _v_122;
    r6 = _v_123;
    r7 = _v_124;
    r8 = _v_125;
    r9 = _v_126;
    r10 = _v_127;
    r11 = _v_128;
    r12 = _v_129;
    r13 = _v_130;
    r14 = _v_131;
    r15 = _v_132;
    r16 = _v_133;
    r17 = _v_134;
    r18 = _v_135;
    r19 = _v_136;
    r20 = _v_137;
    r21 = _v_138;
    r22 = _v_139;
    r23 = _v_140;
    r24 = _v_141;
    r25 = _v_142;
    r26 = _v_143;
    WL_RETN(27);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0)
  {
    Term _effect_0 = r0;
    u32 _runtime_0 = r1;
    u32 _runtime_1 = r2;
    u32 _runtime_2 = r3;
    Term _runtime_3 = r4;
    u32 _runtime_4 = r5;
    Term _runtime_5 = r6;
    Term _runtime_6 = r7;
    Term _runtime_7 = r8;
    Term _runtime_8 = r9;
    u32 _runtime_9 = r10;
    u32 _runtime_10 = r11;
    Term _runtime_11 = r12;
    Term _runtime_12 = r13;
    Term _runtime_13 = r14;
    Term _runtime_14 = r15;
    Term _runtime_15 = r16;
    Term _runtime_16 = r17;
    u32 _runtime_17 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _o_0[12];
    if (spin_55(e, _o_0, _runtime_0, _runtime_1, _runtime_2, _runtime_3, blk_loc(e.mem, _runtime_3), _runtime_4, _runtime_5, _runtime_6, blk_loc(e.mem, _runtime_6), _runtime_7, blk_loc(e.mem, _runtime_7), _runtime_8, blk_loc(e.mem, _runtime_8), _runtime_9, _runtime_10) == 0) {
      return 0;
    }
    _v_12 = _o_0[0];
    _v_13 = _o_0[1];
    _v_14 = _o_0[2];
    _v_15 = _o_0[3];
    _v_16 = _o_0[4];
    _v_17 = _o_0[5];
    _v_18 = _o_0[6];
    _v_19 = _o_0[7];
    _v_20 = _o_0[8];
    _v_21 = _o_0[9];
    _v_22 = _o_0[10];
    _v_23 = _o_0[11];
    _v_0 = _v_12;
    _v_1 = _v_13;
    _v_2 = _v_14;
    _v_3 = _v_15;
    _v_4 = _v_16;
    _v_5 = _v_17;
    _v_6 = _v_18;
    _v_7 = _v_19;
    _v_8 = _v_20;
    _v_9 = _v_21;
    _v_10 = _v_22;
    _v_11 = _v_23;
    if (seq) {
      WL_ROOM(8);
      STK(0) = _runtime_11;
      STK(1) = _runtime_12;
      STK(2) = _runtime_13;
      STK(3) = _runtime_14;
      STK(4) = _runtime_15;
      STK(5) = _runtime_16;
      STK(6) = _runtime_17;
      STK(7) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K363;
      WL_PUSHN(8);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K363, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _runtime_11;
      e.mem[_t_0 + 1] = _runtime_12;
      e.mem[_t_0 + 2] = _runtime_13;
      e.mem[_t_0 + 3] = _runtime_14;
      e.mem[_t_0 + 4] = _runtime_15;
      e.mem[_t_0 + 5] = _runtime_16;
      e.mem[_t_0 + 6] = _runtime_17;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K363, _t_0);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _effect_0;
      e.mem[_t_1 + 1] = _v_0;
      e.mem[_t_1 + 2] = _v_1;
      e.mem[_t_1 + 3] = _v_2;
      e.mem[_t_1 + 4] = _v_3;
      e.mem[_t_1 + 5] = _v_4;
      e.mem[_t_1 + 6] = _v_5;
      e.mem[_t_1 + 7] = _v_6;
      e.mem[_t_1 + 8] = _v_7;
      e.mem[_t_1 + 9] = _v_8;
      e.mem[_t_1 + 10] = _v_9;
      e.mem[_t_1 + 11] = _v_10;
      e.mem[_t_1 + 12] = _v_11;
      return term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0, _t_1);
    }
    r0 = _effect_0;
    r1 = _v_0;
    r2 = _v_1;
    r3 = _v_2;
    r4 = _v_3;
    r5 = _v_4;
    r6 = _v_5;
    r7 = _v_6;
    r8 = _v_7;
    r9 = _v_8;
    r10 = _v_9;
    r11 = _v_10;
    r12 = _v_11;
    WL_JMP(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_EFFECT_CLOCKED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K363)
  {
    WL_POPN(7);
    Term _runtime_18 = STK(0);
    Term _runtime_19 = STK(1);
    Term _runtime_20 = STK(2);
    Term _runtime_21 = STK(3);
    Term _runtime_22 = STK(4);
    Term _runtime_23 = STK(5);
    u32 _runtime_24 = STK(6);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    WL_OPEN
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    u32 _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _o_1[12];
    if (spin_26(e, _o_1, _h_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, _h_5, _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, _h_10) == 0) {
      return 0;
    }
    _v_36 = _o_1[0];
    _v_37 = _o_1[1];
    _v_38 = _o_1[2];
    _v_39 = _o_1[3];
    _v_40 = _o_1[4];
    _v_41 = _o_1[5];
    _v_42 = _o_1[6];
    _v_43 = _o_1[7];
    _v_44 = _o_1[8];
    _v_45 = _o_1[9];
    _v_46 = _o_1[10];
    _v_47 = _o_1[11];
    _v_24 = _v_36;
    _v_25 = _v_37;
    _v_26 = _v_38;
    _v_27 = _v_39;
    _v_28 = _v_40;
    _v_29 = _v_41;
    _v_30 = _v_42;
    _v_31 = _v_43;
    _v_32 = _v_44;
    _v_33 = _v_45;
    _v_34 = _v_46;
    _v_35 = _v_47;
    if (seq) {
      WL_ROOM(7);
      STK(0) = _v_35;
      STK(1) = _runtime_19;
      STK(2) = _runtime_21;
      STK(3) = _runtime_22;
      STK(4) = _runtime_23;
      STK(5) = _runtime_24;
      STK(6) = FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K364;
      WL_PUSHN(7);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K364, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _v_35;
      e.mem[_t_2 + 1] = _runtime_19;
      e.mem[_t_2 + 2] = _runtime_21;
      e.mem[_t_2 + 3] = _runtime_22;
      e.mem[_t_2 + 4] = _runtime_23;
      e.mem[_t_2 + 5] = _runtime_24;
      WL_CONT = term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K364, _t_2);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _v_24;
      e.mem[_t_3 + 1] = _v_25;
      e.mem[_t_3 + 2] = _v_26;
      e.mem[_t_3 + 3] = _v_27;
      e.mem[_t_3 + 4] = _v_28;
      e.mem[_t_3 + 5] = _v_29;
      e.mem[_t_3 + 6] = _v_30;
      e.mem[_t_3 + 7] = _v_31;
      e.mem[_t_3 + 8] = _v_32;
      e.mem[_t_3 + 9] = _v_33;
      e.mem[_t_3 + 10] = _v_34;
      e.mem[_t_3 + 11] = ((u64)_v_35);
      e.mem[_t_3 + 12] = _runtime_18;
      return term_tsk(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0, _t_3);
    }
    r0 = _v_24;
    r1 = _v_25;
    r2 = _v_26;
    r3 = _v_27;
    r4 = _v_28;
    r5 = _v_29;
    r6 = _v_30;
    r7 = _v_31;
    r8 = _v_32;
    r9 = _v_33;
    r10 = _v_34;
    r11 = ((u64)_v_35);
    r12 = _runtime_18;
    WL_JMP(FID__________SRC_ECS_INTERNAL_RELATION_FAILURES_ROUTING_COLLECT_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0_K364)
  {
    WL_POPN(6);
    u32 _v_48 = STK(0);
    Term _runtime_25 = STK(1);
    Term _runtime_26 = STK(2);
    Term _runtime_27 = STK(3);
    Term _runtime_28 = STK(4);
    u32 _runtime_29 = STK(5);
    u32 _h_11 = r0;
    u32 _h_12 = r1;
    u32 _h_13 = r2;
    Term _h_14 = r3;
    u32 _h_15 = r4;
    Term _h_16 = r5;
    Term _h_17 = r6;
    Term _h_18 = r7;
    Term _h_19 = r8;
    u32 _h_20 = r9;
    u32 _h_21 = r10;
    Term _h_22 = r11;
    WL_OPEN
    u32 _v_49 = 0;
    u32 _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _v_63 = 0;
    Term _v_64 = 0;
    Term _v_65 = 0;
    u32 _v_66 = 0;
    Term _o_2[18];
    if (spin_53(e, _o_2, _h_11, _h_12, _h_13, _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, _h_17, blk_loc(e.mem, _h_17), _h_18, blk_loc(e.mem, _h_18), _h_19, blk_loc(e.mem, _h_19), _h_20, _h_21, _h_22, blk_loc(e.mem, _h_22), _runtime_25, blk_loc(e.mem, _runtime_25), ((u64)_v_48), _runtime_26, _runtime_27, _runtime_28, _runtime_29) == 0) {
      return 0;
    }
    _v_49 = _o_2[0];
    _v_50 = _o_2[1];
    _v_51 = _o_2[2];
    _v_52 = _o_2[3];
    _v_53 = _o_2[4];
    _v_54 = _o_2[5];
    _v_55 = _o_2[6];
    _v_56 = _o_2[7];
    _v_57 = _o_2[8];
    _v_58 = _o_2[9];
    _v_59 = _o_2[10];
    _v_60 = _o_2[11];
    _v_61 = _o_2[12];
    _v_62 = _o_2[13];
    _v_63 = _o_2[14];
    _v_64 = _o_2[15];
    _v_65 = _o_2[16];
    _v_66 = _o_2[17];
    r0 = _v_49;
    r1 = _v_50;
    r2 = _v_51;
    r3 = _v_52;
    r4 = _v_53;
    r5 = _v_54;
    r6 = _v_55;
    r7 = _v_56;
    r8 = _v_57;
    r9 = _v_58;
    r10 = _v_59;
    r11 = _v_60;
    r12 = _v_61;
    r13 = _v_62;
    r14 = _v_63;
    r15 = _v_64;
    r16 = _v_65;
    r17 = _v_66;
    WL_RETN(18);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED)
  {
    u32 _result_0 = r0;
    u32 _result_1 = r1;
    u32 _result_2 = r2;
    u32 _result_3 = r3;
    u32 _result_4 = r4;
    Term _result_5 = r5;
    u32 _result_6 = r6;
    Term _result_7 = r7;
    Term _result_8 = r8;
    Term _result_9 = r9;
    Term _result_10 = r10;
    u32 _result_11 = r11;
    u32 _result_12 = r12;
    WL_OPEN
    if (_result_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 766);
      WL_RETN(1);
    } else {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      u32 _v_2 = 0;
      u32 _v_3 = 0;
      Term _v_4 = 0;
      u32 _v_5 = 0;
      Term _v_6 = 0;
      Term _v_7 = 0;
      Term _v_8 = 0;
      Term _v_9 = 0;
      u32 _v_10 = 0;
      u32 _v_11 = 0;
      u32 _v_12 = 0;
      u32 _v_13 = 0;
      Term _v_14 = 0;
      Term _v_15 = 0;
      u32 _v_16 = 0;
      u32 _v_17 = 0;
      u32 _v_18 = 0;
      u32 _v_19 = 0;
      u32 _v_20 = 0;
      Term _v_21 = 0;
      u32 _v_22 = 0;
      Term _v_23 = 0;
      Term _v_24 = 0;
      Term _v_25 = 0;
      Term _v_26 = 0;
      u32 _v_27 = 0;
      u32 _v_28 = 0;
      u32 _v_29 = 0;
      u32 _v_30 = 0;
      Term _v_31 = 0;
      Term _v_32 = 0;
      u32 _v_33 = 0;
      Term _o_2[17];
      Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 460);
      Term _a_1 = term_pak(CID_NIL, 0);
      if (spin_71(e, _o_2, _result_2, _result_3, _result_4, _result_5, blk_loc(e.mem, _result_5), _result_6, _result_7, _result_8, blk_loc(e.mem, _result_8), _result_9, blk_loc(e.mem, _result_9), _result_10, blk_loc(e.mem, _result_10), _result_11, _result_12, _a_0, blk_loc(e.mem, _a_0), _a_1, blk_loc(e.mem, _a_1)) == 0) {
        return 0;
      }
      _v_17 = _o_2[0];
      _v_18 = _o_2[1];
      _v_19 = _o_2[2];
      _v_20 = _o_2[3];
      _v_21 = _o_2[4];
      _v_22 = _o_2[5];
      _v_23 = _o_2[6];
      _v_24 = _o_2[7];
      _v_25 = _o_2[8];
      _v_26 = _o_2[9];
      _v_27 = _o_2[10];
      _v_28 = _o_2[11];
      _v_29 = _o_2[12];
      _v_30 = _o_2[13];
      _v_31 = _o_2[14];
      _v_32 = _o_2[15];
      _v_33 = _o_2[16];
      _v_0 = _v_17;
      _v_1 = _v_18;
      _v_2 = _v_19;
      _v_3 = _v_20;
      _v_4 = _v_21;
      _v_5 = _v_22;
      _v_6 = _v_23;
      _v_7 = _v_24;
      _v_8 = _v_25;
      _v_9 = _v_26;
      _v_10 = _v_27;
      _v_11 = _v_28;
      _v_12 = _v_29;
      _v_13 = _v_30;
      _v_14 = _v_31;
      _v_15 = _v_32;
      _v_16 = _v_33;
      if (_v_0 == 1) {
        term_sink(e, _v_4);
        term_sink(e, _v_7);
        term_sink(e, _v_8);
        term_sink(e, _v_9);
        r0 = term_ctr(CID_SCON, STAT_OFF + 734);
        WL_RETN(1);
      } else {
        term_sink(e, _v_14);
        term_sink(e, _v_15);
        u32 _v_92 = 0;
        u32 _v_93 = 0;
        u32 _v_94 = 0;
        Term _v_95 = 0;
        u32 _v_96 = 0;
        Term _v_97 = 0;
        Term _v_98 = 0;
        Term _v_99 = 0;
        Term _v_100 = 0;
        u32 _v_101 = 0;
        u32 _v_102 = 0;
        Term _v_103 = 0;
        Term _v_104 = 0;
        Term _v_105 = 0;
        Term _v_106 = 0;
        Term _v_107 = 0;
        Term _v_108 = 0;
        u32 _v_109 = 0;
        u32 _v_110 = 0;
        u32 _v_111 = 0;
        u32 _v_112 = 0;
        u32 _v_113 = 0;
        u32 _v_114 = 0;
        Term _v_115 = 0;
        u32 _v_116 = 0;
        Term _v_117 = 0;
        Term _v_118 = 0;
        Term _v_119 = 0;
        Term _v_120 = 0;
        u32 _v_121 = 0;
        u32 _v_122 = 0;
        Term _v_123 = 0;
        Term _v_124 = 0;
        Term _v_125 = 0;
        Term _v_126 = 0;
        Term _v_127 = 0;
        Term _v_128 = 0;
        u32 _v_129 = 0;
        u32 _v_130 = 0;
        u32 _v_131 = 0;
        u32 _v_132 = 0;
        Term _v_133 = 0;
        u32 _v_134 = 0;
        Term _v_135 = 0;
        Term _v_136 = 0;
        Term _v_137 = 0;
        Term _v_138 = 0;
        u32 _v_139 = 0;
        u32 _v_140 = 0;
        Term _v_141 = 0;
        Term _v_142 = 0;
        Term _v_143 = 0;
        Term _v_144 = 0;
        Term _v_145 = 0;
        Term _v_146 = 0;
        u32 _v_147 = 0;
        Term _o_3[18];
        if (spin_69(e, _o_3, _v_1, _v_2, _v_3, _v_4, blk_loc(e.mem, _v_4), _v_5, _v_6, _v_7, blk_loc(e.mem, _v_7), _v_8, blk_loc(e.mem, _v_8), _v_9, blk_loc(e.mem, _v_9), _v_10, _v_11) == 0) {
          return 0;
        }
        _v_130 = _o_3[0];
        _v_131 = _o_3[1];
        _v_132 = _o_3[2];
        _v_133 = _o_3[3];
        _v_134 = _o_3[4];
        _v_135 = _o_3[5];
        _v_136 = _o_3[6];
        _v_137 = _o_3[7];
        _v_138 = _o_3[8];
        _v_139 = _o_3[9];
        _v_140 = _o_3[10];
        _v_141 = _o_3[11];
        _v_142 = _o_3[12];
        _v_143 = _o_3[13];
        _v_144 = _o_3[14];
        _v_145 = _o_3[15];
        _v_146 = _o_3[16];
        _v_147 = _o_3[17];
        _v_112 = _v_130;
        _v_113 = _v_131;
        _v_114 = _v_132;
        _v_115 = _v_133;
        _v_116 = _v_134;
        _v_117 = _v_135;
        _v_118 = _v_136;
        _v_119 = _v_137;
        _v_120 = _v_138;
        _v_121 = _v_139;
        _v_122 = _v_140;
        _v_123 = _v_141;
        _v_124 = _v_142;
        _v_125 = _v_143;
        _v_126 = _v_144;
        _v_127 = _v_145;
        _v_128 = _v_146;
        _v_129 = _v_147;
        u32 _v_148 = 0;
        u32 _v_149 = 0;
        u32 _v_150 = 0;
        Term _v_151 = 0;
        u32 _v_152 = 0;
        Term _v_153 = 0;
        Term _v_154 = 0;
        Term _v_155 = 0;
        Term _v_156 = 0;
        u32 _v_157 = 0;
        u32 _v_158 = 0;
        Term _v_159 = 0;
        Term _v_160 = 0;
        Term _v_161 = 0;
        Term _v_162 = 0;
        Term _v_163 = 0;
        Term _v_164 = 0;
        u32 _v_165 = 0;
        u32 _v_166 = 0;
        u32 _v_167 = 0;
        Term _o_4[20];
        if (spin_31(e, _o_4, _v_112, _v_113, _v_114, _v_115, blk_loc(e.mem, _v_115), _v_116, _v_117, _v_118, blk_loc(e.mem, _v_118), _v_119, blk_loc(e.mem, _v_119), _v_120, blk_loc(e.mem, _v_120), _v_121, _v_122, _v_123, blk_loc(e.mem, _v_123), _v_124, blk_loc(e.mem, _v_124), _v_125, _v_126, _v_127, _v_128, _v_129) == 0) {
          return 0;
        }
        _v_148 = _o_4[0];
        _v_149 = _o_4[1];
        _v_150 = _o_4[2];
        _v_151 = _o_4[3];
        _v_152 = _o_4[4];
        _v_153 = _o_4[5];
        _v_154 = _o_4[6];
        _v_155 = _o_4[7];
        _v_156 = _o_4[8];
        _v_157 = _o_4[9];
        _v_158 = _o_4[10];
        _v_159 = _o_4[11];
        _v_160 = _o_4[12];
        _v_161 = _o_4[13];
        _v_162 = _o_4[14];
        _v_163 = _o_4[15];
        _v_164 = _o_4[16];
        _v_165 = _o_4[17];
        _v_166 = _o_4[18];
        _v_167 = _o_4[19];
        _v_92 = _v_148;
        _v_93 = _v_149;
        _v_94 = _v_150;
        _v_95 = _v_151;
        _v_96 = _v_152;
        _v_97 = _v_153;
        _v_98 = _v_154;
        _v_99 = _v_155;
        _v_100 = _v_156;
        _v_101 = _v_157;
        _v_102 = _v_158;
        _v_103 = _v_159;
        _v_104 = _v_160;
        _v_105 = _v_161;
        _v_106 = _v_162;
        _v_107 = _v_163;
        _v_108 = _v_164;
        _v_109 = _v_165;
        _v_110 = _v_166;
        _v_111 = _v_167;
        if (_v_110 == 1) {
          u32 _v_168 = 0;
          u32 _v_169 = 0;
          u32 _v_170 = 0;
          Term _v_171 = 0;
          u32 _v_172 = 0;
          Term _v_173 = 0;
          Term _v_174 = 0;
          Term _v_175 = 0;
          Term _v_176 = 0;
          u32 _v_177 = 0;
          u32 _v_178 = 0;
          Term _v_179 = 0;
          Term _v_180 = 0;
          Term _v_181 = 0;
          Term _v_182 = 0;
          Term _v_183 = 0;
          Term _v_184 = 0;
          u32 _v_185 = 0;
          u32 _v_186 = 0;
          u32 _v_187 = 0;
          u32 _v_188 = 0;
          u32 _v_189 = 0;
          u32 _v_190 = 0;
          Term _v_191 = 0;
          u32 _v_192 = 0;
          Term _v_193 = 0;
          Term _v_194 = 0;
          Term _v_195 = 0;
          Term _v_196 = 0;
          u32 _v_197 = 0;
          u32 _v_198 = 0;
          Term _v_199 = 0;
          Term _v_200 = 0;
          Term _v_201 = 0;
          Term _v_202 = 0;
          Term _v_203 = 0;
          Term _v_204 = 0;
          u32 _v_205 = 0;
          u32 _v_206 = 0;
          u32 _v_207 = 0;
          Term _o_5[20];
          if (spin_31(e, _o_5, _v_92, _v_93, _v_94, _v_95, blk_loc(e.mem, _v_95), _v_96, _v_97, _v_98, blk_loc(e.mem, _v_98), _v_99, blk_loc(e.mem, _v_99), _v_100, blk_loc(e.mem, _v_100), _v_101, _v_102, _v_103, blk_loc(e.mem, _v_103), _v_104, blk_loc(e.mem, _v_104), _v_105, _v_106, _v_107, _v_108, _v_109) == 0) {
            return 0;
          }
          _v_188 = _o_5[0];
          _v_189 = _o_5[1];
          _v_190 = _o_5[2];
          _v_191 = _o_5[3];
          _v_192 = _o_5[4];
          _v_193 = _o_5[5];
          _v_194 = _o_5[6];
          _v_195 = _o_5[7];
          _v_196 = _o_5[8];
          _v_197 = _o_5[9];
          _v_198 = _o_5[10];
          _v_199 = _o_5[11];
          _v_200 = _o_5[12];
          _v_201 = _o_5[13];
          _v_202 = _o_5[14];
          _v_203 = _o_5[15];
          _v_204 = _o_5[16];
          _v_205 = _o_5[17];
          _v_206 = _o_5[18];
          _v_207 = _o_5[19];
          _v_168 = _v_188;
          _v_169 = _v_189;
          _v_170 = _v_190;
          _v_171 = _v_191;
          _v_172 = _v_192;
          _v_173 = _v_193;
          _v_174 = _v_194;
          _v_175 = _v_195;
          _v_176 = _v_196;
          _v_177 = _v_197;
          _v_178 = _v_198;
          _v_179 = _v_199;
          _v_180 = _v_200;
          _v_181 = _v_201;
          _v_182 = _v_202;
          _v_183 = _v_203;
          _v_184 = _v_204;
          _v_185 = _v_205;
          _v_186 = _v_206;
          _v_187 = _v_207;
          if (_v_186 == 1) {
            u32 _v_208 = 0;
            u32 _v_209 = 0;
            u32 _v_210 = 0;
            u32 _v_211 = 0;
            Term _v_212 = 0;
            u32 _v_213 = 0;
            Term _v_214 = 0;
            Term _v_215 = 0;
            Term _v_216 = 0;
            Term _v_217 = 0;
            u32 _v_218 = 0;
            u32 _v_219 = 0;
            Term _v_220 = 0;
            Term _v_221 = 0;
            Term _v_222 = 0;
            Term _v_223 = 0;
            Term _v_224 = 0;
            Term _v_225 = 0;
            u32 _v_226 = 0;
            u32 _v_227 = 0;
            u32 _v_228 = 0;
            Term _v_229 = 0;
            Term _v_230 = 0;
            u32 _v_231 = 0;
            Term _v_232 = 0;
            u32 _v_233 = 0;
            u32 _v_234 = 0;
            u32 _v_235 = 0;
            u32 _v_236 = 0;
            u32 _v_237 = 0;
            Term _v_238 = 0;
            u32 _v_239 = 0;
            Term _v_240 = 0;
            Term _v_241 = 0;
            Term _v_242 = 0;
            Term _v_243 = 0;
            u32 _v_244 = 0;
            u32 _v_245 = 0;
            Term _v_246 = 0;
            Term _v_247 = 0;
            Term _v_248 = 0;
            Term _v_249 = 0;
            Term _v_250 = 0;
            Term _v_251 = 0;
            u32 _v_252 = 0;
            u32 _v_253 = 0;
            u32 _v_254 = 0;
            Term _v_255 = 0;
            Term _v_256 = 0;
            u32 _v_257 = 0;
            Term _v_258 = 0;
            u32 _v_259 = 0;
            Term _o_6[26];
            Term _a_2 = term_ctr(CID_CON, STAT_OFF + 700);
            Term _a_3 = term_ctr(CID_SCON, STAT_OFF + 372);
            Term _a_4 = term_ctr(CID_CON, STAT_OFF + 386);
            if (spin_65(e, _o_6, _v_168, _v_169, _v_170, _v_171, blk_loc(e.mem, _v_171), _v_172, _v_173, _v_174, blk_loc(e.mem, _v_174), _v_175, blk_loc(e.mem, _v_175), _v_176, blk_loc(e.mem, _v_176), _v_177, _v_178, _v_179, blk_loc(e.mem, _v_179), _v_180, blk_loc(e.mem, _v_180), _v_181, _v_182, _v_183, _v_184, _v_185, _a_2, blk_loc(e.mem, _a_2), _a_3, blk_loc(e.mem, _a_3), _a_4, blk_loc(e.mem, _a_4)) == 0) {
              return 0;
            }
            _v_234 = _o_6[0];
            _v_235 = _o_6[1];
            _v_236 = _o_6[2];
            _v_237 = _o_6[3];
            _v_238 = _o_6[4];
            _v_239 = _o_6[5];
            _v_240 = _o_6[6];
            _v_241 = _o_6[7];
            _v_242 = _o_6[8];
            _v_243 = _o_6[9];
            _v_244 = _o_6[10];
            _v_245 = _o_6[11];
            _v_246 = _o_6[12];
            _v_247 = _o_6[13];
            _v_248 = _o_6[14];
            _v_249 = _o_6[15];
            _v_250 = _o_6[16];
            _v_251 = _o_6[17];
            _v_252 = _o_6[18];
            _v_253 = _o_6[19];
            _v_254 = _o_6[20];
            _v_255 = _o_6[21];
            _v_256 = _o_6[22];
            _v_257 = _o_6[23];
            _v_258 = _o_6[24];
            _v_259 = _o_6[25];
            _v_208 = _v_234;
            _v_209 = _v_235;
            _v_210 = _v_236;
            _v_211 = _v_237;
            _v_212 = _v_238;
            _v_213 = _v_239;
            _v_214 = _v_240;
            _v_215 = _v_241;
            _v_216 = _v_242;
            _v_217 = _v_243;
            _v_218 = _v_244;
            _v_219 = _v_245;
            _v_220 = _v_246;
            _v_221 = _v_247;
            _v_222 = _v_248;
            _v_223 = _v_249;
            _v_224 = _v_250;
            _v_225 = _v_251;
            _v_226 = _v_252;
            _v_227 = _v_253;
            _v_228 = _v_254;
            _v_229 = _v_255;
            _v_230 = _v_256;
            _v_231 = _v_257;
            _v_232 = _v_258;
            _v_233 = _v_259;
            if (_v_208 == 1) {
              term_sink(e, _v_212);
              term_sink(e, _v_215);
              term_sink(e, _v_216);
              term_sink(e, _v_217);
              term_sink(e, _v_220);
              term_sink(e, _v_221);
              r0 = term_ctr(CID_SCON, STAT_OFF + 698);
              WL_RETN(1);
            } else {
              u32 _v_260 = 0;
              u32 _v_261 = 0;
              u32 _v_262 = 0;
              Term _v_263 = 0;
              u32 _v_264 = 0;
              Term _v_265 = 0;
              Term _v_266 = 0;
              Term _v_267 = 0;
              Term _v_268 = 0;
              u32 _v_269 = 0;
              u32 _v_270 = 0;
              Term _v_271 = 0;
              Term _v_272 = 0;
              Term _v_273 = 0;
              Term _v_274 = 0;
              Term _v_275 = 0;
              Term _v_276 = 0;
              u32 _v_277 = 0;
              u32 _v_278 = 0;
              u32 _v_279 = 0;
              u32 _v_280 = 0;
              u32 _v_281 = 0;
              u32 _v_282 = 0;
              Term _v_283 = 0;
              u32 _v_284 = 0;
              Term _v_285 = 0;
              Term _v_286 = 0;
              Term _v_287 = 0;
              Term _v_288 = 0;
              u32 _v_289 = 0;
              u32 _v_290 = 0;
              Term _v_291 = 0;
              Term _v_292 = 0;
              Term _v_293 = 0;
              Term _v_294 = 0;
              Term _v_295 = 0;
              Term _v_296 = 0;
              u32 _v_297 = 0;
              u32 _v_298 = 0;
              u32 _v_299 = 0;
              Term _o_7[20];
              if (spin_31(e, _o_7, _v_209, _v_210, _v_211, _v_212, blk_loc(e.mem, _v_212), _v_213, _v_214, _v_215, blk_loc(e.mem, _v_215), _v_216, blk_loc(e.mem, _v_216), _v_217, blk_loc(e.mem, _v_217), _v_218, _v_219, _v_220, blk_loc(e.mem, _v_220), _v_221, blk_loc(e.mem, _v_221), _v_222, _v_223, _v_224, _v_225, _v_226) == 0) {
                return 0;
              }
              _v_280 = _o_7[0];
              _v_281 = _o_7[1];
              _v_282 = _o_7[2];
              _v_283 = _o_7[3];
              _v_284 = _o_7[4];
              _v_285 = _o_7[5];
              _v_286 = _o_7[6];
              _v_287 = _o_7[7];
              _v_288 = _o_7[8];
              _v_289 = _o_7[9];
              _v_290 = _o_7[10];
              _v_291 = _o_7[11];
              _v_292 = _o_7[12];
              _v_293 = _o_7[13];
              _v_294 = _o_7[14];
              _v_295 = _o_7[15];
              _v_296 = _o_7[16];
              _v_297 = _o_7[17];
              _v_298 = _o_7[18];
              _v_299 = _o_7[19];
              _v_260 = _v_280;
              _v_261 = _v_281;
              _v_262 = _v_282;
              _v_263 = _v_283;
              _v_264 = _v_284;
              _v_265 = _v_285;
              _v_266 = _v_286;
              _v_267 = _v_287;
              _v_268 = _v_288;
              _v_269 = _v_289;
              _v_270 = _v_290;
              _v_271 = _v_291;
              _v_272 = _v_292;
              _v_273 = _v_293;
              _v_274 = _v_294;
              _v_275 = _v_295;
              _v_276 = _v_296;
              _v_277 = _v_297;
              _v_278 = _v_298;
              _v_279 = _v_299;
              if (_v_278 == 1) {
                if (seq) {
                  WL_ROOM(11);
                  STK(0) = _v_279;
                  STK(1) = _v_227;
                  STK(2) = _v_228;
                  STK(3) = _v_229;
                  STK(4) = _v_230;
                  STK(5) = _v_231;
                  STK(6) = _v_232;
                  STK(7) = _v_233;
                  STK(8) = _v_111;
                  STK(9) = _v_187;
                  STK(10) = FID_CREATED_K605;
                  WL_PUSHN(11);
                } else {
                  u64 _t_0 = task_node(e, FID_CREATED_K605, WL_CONT, WL_IDX, 1);
                  e.mem[_t_0 + 0] = _v_279;
                  e.mem[_t_0 + 1] = _v_227;
                  e.mem[_t_0 + 2] = _v_228;
                  e.mem[_t_0 + 3] = _v_229;
                  e.mem[_t_0 + 4] = _v_230;
                  e.mem[_t_0 + 5] = _v_231;
                  e.mem[_t_0 + 6] = _v_232;
                  e.mem[_t_0 + 7] = _v_233;
                  e.mem[_t_0 + 8] = _v_111;
                  e.mem[_t_0 + 9] = _v_187;
                  WL_CONT = term_tsk(FID_CREATED_K605, _t_0);
                  WL_IDX = 10;
                }
                if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0)) {
                  u64 _t_1 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0, WL_CONT, WL_IDX, 0);
                  e.mem[_t_1 + 0] = term_clo(FID_CREATED_C604, 0);
                  e.mem[_t_1 + 1] = _v_260;
                  e.mem[_t_1 + 2] = _v_261;
                  e.mem[_t_1 + 3] = _v_262;
                  e.mem[_t_1 + 4] = _v_263;
                  e.mem[_t_1 + 5] = _v_264;
                  e.mem[_t_1 + 6] = _v_265;
                  e.mem[_t_1 + 7] = _v_266;
                  e.mem[_t_1 + 8] = _v_267;
                  e.mem[_t_1 + 9] = _v_268;
                  e.mem[_t_1 + 10] = _v_269;
                  e.mem[_t_1 + 11] = _v_270;
                  e.mem[_t_1 + 12] = _v_271;
                  e.mem[_t_1 + 13] = _v_272;
                  e.mem[_t_1 + 14] = _v_273;
                  e.mem[_t_1 + 15] = _v_274;
                  e.mem[_t_1 + 16] = _v_275;
                  e.mem[_t_1 + 17] = _v_276;
                  e.mem[_t_1 + 18] = _v_277;
                  return term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0, _t_1);
                }
                r0 = term_clo(FID_CREATED_C604, 0);
                r1 = _v_260;
                r2 = _v_261;
                r3 = _v_262;
                r4 = _v_263;
                r5 = _v_264;
                r6 = _v_265;
                r7 = _v_266;
                r8 = _v_267;
                r9 = _v_268;
                r10 = _v_269;
                r11 = _v_270;
                r12 = _v_271;
                r13 = _v_272;
                r14 = _v_273;
                r15 = _v_274;
                r16 = _v_275;
                r17 = _v_276;
                r18 = _v_277;
                WL_JMP(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_WITH_WORLD_0);
              } else {
                term_sink(e, _v_263);
                term_sink(e, _v_266);
                term_sink(e, _v_267);
                term_sink(e, _v_268);
                term_sink(e, _v_271);
                term_sink(e, _v_272);
                term_sink(e, _v_229);
                term_sink(e, _v_230);
                term_sink(e, _v_232);
                r0 = term_ctr(CID_SCON, STAT_OFF + 662);
                WL_RETN(1);
              }
            }
          } else {
            term_sink(e, _v_171);
            term_sink(e, _v_174);
            term_sink(e, _v_175);
            term_sink(e, _v_176);
            term_sink(e, _v_179);
            term_sink(e, _v_180);
            r0 = term_ctr(CID_SCON, STAT_OFF + 662);
            WL_RETN(1);
          }
        } else {
          term_sink(e, _v_95);
          term_sink(e, _v_98);
          term_sink(e, _v_99);
          term_sink(e, _v_100);
          term_sink(e, _v_103);
          term_sink(e, _v_104);
          r0 = term_ctr(CID_SCON, STAT_OFF + 662);
          WL_RETN(1);
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_C604)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[13];
    u64 _sp_0 = ctr_take(e, _x_0, 13, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    u32 _f_11 = _fb_0[11];
    u32 _f_12 = _fb_0[12];
    spare_free(e, cls_fit(13), _sp_0);
    u32 _v_300 = 0;
    u32 _v_301 = 0;
    u32 _v_302 = 0;
    Term _v_303 = 0;
    u32 _v_304 = 0;
    Term _v_305 = 0;
    Term _v_306 = 0;
    Term _v_307 = 0;
    Term _v_308 = 0;
    u32 _v_309 = 0;
    u32 _v_310 = 0;
    Term _o_8[11];
    if (spin_62(e, _o_8, _f_0, _f_1, _f_2, _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, _f_8, blk_loc(e.mem, _f_8), _f_9, blk_loc(e.mem, _f_9), _f_10, blk_loc(e.mem, _f_10), _f_11, _f_12) == 0) {
      return 0;
    }
    _v_300 = _o_8[0];
    _v_301 = _o_8[1];
    _v_302 = _o_8[2];
    _v_303 = _o_8[3];
    _v_304 = _o_8[4];
    _v_305 = _o_8[5];
    _v_306 = _o_8[6];
    _v_307 = _o_8[7];
    _v_308 = _o_8[8];
    _v_309 = _o_8[9];
    _v_310 = _o_8[10];
    u64 _nd_0 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_300);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_301);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_302);
    e.mem[_nd_0 + 3] = rfc_seal(e, _v_303);
    e.mem[_nd_0 + 4] = rfc_seal(e, _v_304);
    e.mem[_nd_0 + 5] = rfc_seal(e, _v_305);
    e.mem[_nd_0 + 6] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 7] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 8] = rfc_seal(e, _v_306);
    e.mem[_nd_0 + 9] = rfc_seal(e, _v_307);
    e.mem[_nd_0 + 10] = rfc_seal(e, _v_308);
    e.mem[_nd_0 + 11] = rfc_seal(e, _v_309);
    e.mem[_nd_0 + 12] = rfc_seal(e, _v_310);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_UNIT, 0));
    r0 = term_ctr(CID_TUPLE, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K605)
  {
    WL_POPN(10);
    u32 _v_311 = STK(0);
    u32 _v_312 = STK(1);
    u32 _v_313 = STK(2);
    Term _v_314 = STK(3);
    Term _v_315 = STK(4);
    u32 _v_316 = STK(5);
    Term _v_317 = STK(6);
    u32 _v_318 = STK(7);
    u32 _v_319 = STK(8);
    u32 _v_320 = STK(9);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    Term _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _v_311);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _v_320);
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _v_319);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_ctr(CID_CON, _nd_3));
    Term _ids_0 = term_ctr(CID_CON, _nd_4);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _v_313;
      STK(1) = _v_318;
      STK(2) = _ids_0;
      STK(3) = FID_CREATED_K606;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_CREATED_K606, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _v_313;
      e.mem[_t_2 + 1] = _v_318;
      e.mem[_t_2 + 2] = _ids_0;
      WL_CONT = term_tsk(FID_CREATED_K606, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_6;
      e.mem[_t_3 + 7] = _h_7;
      e.mem[_t_3 + 8] = _h_8;
      e.mem[_t_3 + 9] = _h_9;
      e.mem[_t_3 + 10] = _h_10;
      e.mem[_t_3 + 11] = _h_11;
      e.mem[_t_3 + 12] = _h_12;
      e.mem[_t_3 + 13] = _h_13;
      e.mem[_t_3 + 14] = _h_14;
      e.mem[_t_3 + 15] = _h_15;
      e.mem[_t_3 + 16] = _h_16;
      e.mem[_t_3 + 17] = _h_17;
      e.mem[_t_3 + 18] = _v_312;
      e.mem[_t_3 + 19] = _v_313;
      e.mem[_t_3 + 20] = _v_314;
      e.mem[_t_3 + 21] = _v_315;
      e.mem[_t_3 + 22] = _v_316;
      e.mem[_t_3 + 23] = _v_317;
      e.mem[_t_3 + 24] = _v_318;
      return term_tsk(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_6;
    r7 = _h_7;
    r8 = _h_8;
    r9 = _h_9;
    r10 = _h_10;
    r11 = _h_11;
    r12 = _h_12;
    r13 = _h_13;
    r14 = _h_14;
    r15 = _h_15;
    r16 = _h_16;
    r17 = _h_17;
    r18 = _v_312;
    r19 = _v_313;
    r20 = _v_314;
    r21 = _v_315;
    r22 = _v_316;
    r23 = _v_317;
    r24 = _v_318;
    WL_JMP(FID__________SRC_ECS_RELATION_FAILURE_RUNTIME_RUN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K606)
  {
    WL_POPN(3);
    u32 _v_321 = STK(0);
    u32 _v_322 = STK(1);
    Term _ids_1 = STK(2);
    u32 _h_18 = r0;
    u32 _h_19 = r1;
    u32 _h_20 = r2;
    Term _h_21 = r3;
    u32 _h_22 = r4;
    Term _h_23 = r5;
    Term _h_24 = r6;
    Term _h_25 = r7;
    Term _h_26 = r8;
    u32 _h_27 = r9;
    u32 _h_28 = r10;
    Term _h_29 = r11;
    Term _h_30 = r12;
    Term _h_31 = r13;
    Term _h_32 = r14;
    Term _h_33 = r15;
    Term _h_34 = r16;
    u32 _h_35 = r17;
    u32 _h_36 = r18;
    u32 _h_37 = r19;
    Term _h_38 = r20;
    Term _h_39 = r21;
    u32 _h_40 = r22;
    Term _h_41 = r23;
    u32 _h_42 = r24;
    u32 _h_43 = r25;
    Term _h_44 = r26;
    WL_OPEN
    if (_h_43 == 0) {
      _h_30 = term_keep(e, _h_30, 1);
      if (seq) {
        WL_ROOM(6);
        STK(0) = _h_30;
        STK(1) = _h_44;
        STK(2) = _ids_1;
        STK(3) = _v_322;
        STK(4) = _v_321;
        STK(5) = FID_CREATED_K607;
        WL_PUSHN(6);
      } else {
        u64 _t_4 = task_node(e, FID_CREATED_K607, WL_CONT, WL_IDX, 1);
        e.mem[_t_4 + 0] = _h_30;
        e.mem[_t_4 + 1] = _h_44;
        e.mem[_t_4 + 2] = _ids_1;
        e.mem[_t_4 + 3] = _v_322;
        e.mem[_t_4 + 4] = _v_321;
        WL_CONT = term_tsk(FID_CREATED_K607, _t_4);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0)) {
        u64 _t_5 = task_node(e, FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _h_18;
        e.mem[_t_5 + 1] = _h_19;
        e.mem[_t_5 + 2] = _h_20;
        e.mem[_t_5 + 3] = _h_21;
        e.mem[_t_5 + 4] = _h_22;
        e.mem[_t_5 + 5] = _h_23;
        e.mem[_t_5 + 6] = _h_24;
        e.mem[_t_5 + 7] = _h_25;
        e.mem[_t_5 + 8] = _h_26;
        e.mem[_t_5 + 9] = _h_27;
        e.mem[_t_5 + 10] = _h_28;
        e.mem[_t_5 + 11] = _h_29;
        e.mem[_t_5 + 12] = _h_30;
        e.mem[_t_5 + 13] = _h_31;
        e.mem[_t_5 + 14] = _h_32;
        e.mem[_t_5 + 15] = _h_33;
        e.mem[_t_5 + 16] = _h_34;
        e.mem[_t_5 + 17] = _h_35;
        e.mem[_t_5 + 18] = _h_36;
        e.mem[_t_5 + 19] = _h_37;
        e.mem[_t_5 + 20] = _h_38;
        e.mem[_t_5 + 21] = _h_39;
        e.mem[_t_5 + 22] = _h_40;
        e.mem[_t_5 + 23] = _h_41;
        e.mem[_t_5 + 24] = _h_42;
        return term_tsk(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0, _t_5);
      }
      r0 = _h_18;
      r1 = _h_19;
      r2 = _h_20;
      r3 = _h_21;
      r4 = _h_22;
      r5 = _h_23;
      r6 = _h_24;
      r7 = _h_25;
      r8 = _h_26;
      r9 = _h_27;
      r10 = _h_28;
      r11 = _h_29;
      r12 = _h_30;
      r13 = _h_31;
      r14 = _h_32;
      r15 = _h_33;
      r16 = _h_34;
      r17 = _h_35;
      r18 = _h_36;
      r19 = _h_37;
      r20 = _h_38;
      r21 = _h_39;
      r22 = _h_40;
      r23 = _h_41;
      r24 = _h_42;
      WL_JMP(FID__________SRC_ECS_RELATION_FAILURE_DISPOSAL_DISPOSE_0);
    } else {
      term_sink(e, _h_21);
      term_sink(e, _h_24);
      term_sink(e, _h_25);
      term_sink(e, _h_26);
      term_sink(e, _h_29);
      term_sink(e, _h_30);
      term_sink(e, _h_38);
      term_sink(e, _h_39);
      term_sink(e, _h_41);
      term_sink(e, _h_44);
      term_sink(e, _ids_1);
      r0 = term_ctr(CID_SCON, STAT_OFF + 618);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K607)
  {
    WL_POPN(5);
    Term _h_71 = STK(0);
    Term _h_72 = STK(1);
    Term _ids_2 = STK(2);
    u32 _v_323 = STK(3);
    u32 _v_324 = STK(4);
    u32 _h_45 = r0;
    u32 _h_46 = r1;
    u32 _h_47 = r2;
    u32 _h_48 = r3;
    Term _h_49 = r4;
    u32 _h_50 = r5;
    Term _h_51 = r6;
    Term _h_52 = r7;
    Term _h_53 = r8;
    Term _h_54 = r9;
    u32 _h_55 = r10;
    u32 _h_56 = r11;
    Term _h_57 = r12;
    Term _h_58 = r13;
    Term _h_59 = r14;
    Term _h_60 = r15;
    Term _h_61 = r16;
    Term _h_62 = r17;
    u32 _h_63 = r18;
    u32 _h_64 = r19;
    u32 _h_65 = r20;
    Term _h_66 = r21;
    Term _h_67 = r22;
    u32 _h_68 = r23;
    Term _h_69 = r24;
    u32 _h_70 = r25;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_71;
      STK(1) = _h_72;
      STK(2) = _v_323;
      STK(3) = _v_324;
      STK(4) = _h_45;
      STK(5) = _h_46;
      STK(6) = _h_47;
      STK(7) = _h_48;
      STK(8) = _h_49;
      STK(9) = _h_50;
      STK(10) = _h_51;
      STK(11) = _h_52;
      STK(12) = _h_53;
      STK(13) = _h_54;
      STK(14) = _h_55;
      STK(15) = _h_56;
      STK(16) = _h_57;
      STK(17) = _h_58;
      STK(18) = _h_59;
      STK(19) = _h_60;
      STK(20) = _h_61;
      STK(21) = _h_62;
      STK(22) = _h_63;
      STK(23) = _h_64;
      STK(24) = _h_65;
      STK(25) = _h_66;
      STK(26) = _h_67;
      STK(27) = _h_68;
      STK(28) = _h_69;
      STK(29) = _h_70;
      STK(30) = FID_CREATED_K608;
      WL_PUSHN(31);
    } else {
      u64 _t_6 = task_node(e, FID_CREATED_K608, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_71;
      e.mem[_t_6 + 1] = _h_72;
      e.mem[_t_6 + 2] = _v_323;
      e.mem[_t_6 + 3] = _v_324;
      e.mem[_t_6 + 4] = _h_45;
      e.mem[_t_6 + 5] = _h_46;
      e.mem[_t_6 + 6] = _h_47;
      e.mem[_t_6 + 7] = _h_48;
      e.mem[_t_6 + 8] = _h_49;
      e.mem[_t_6 + 9] = _h_50;
      e.mem[_t_6 + 10] = _h_51;
      e.mem[_t_6 + 11] = _h_52;
      e.mem[_t_6 + 12] = _h_53;
      e.mem[_t_6 + 13] = _h_54;
      e.mem[_t_6 + 14] = _h_55;
      e.mem[_t_6 + 15] = _h_56;
      e.mem[_t_6 + 16] = _h_57;
      e.mem[_t_6 + 17] = _h_58;
      e.mem[_t_6 + 18] = _h_59;
      e.mem[_t_6 + 19] = _h_60;
      e.mem[_t_6 + 20] = _h_61;
      e.mem[_t_6 + 21] = _h_62;
      e.mem[_t_6 + 22] = _h_63;
      e.mem[_t_6 + 23] = _h_64;
      e.mem[_t_6 + 24] = _h_65;
      e.mem[_t_6 + 25] = _h_66;
      e.mem[_t_6 + 26] = _h_67;
      e.mem[_t_6 + 27] = _h_68;
      e.mem[_t_6 + 28] = _h_69;
      e.mem[_t_6 + 29] = _h_70;
      WL_CONT = term_tsk(FID_CREATED_K608, _t_6);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_NUMBERS)) {
      u64 _t_7 = task_node(e, FID_NUMBERS, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _ids_2;
      return term_tsk(FID_NUMBERS, _t_7);
    }
    r0 = _ids_2;
    WL_JMP(FID_NUMBERS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K608)
  {
    WL_POPN(30);
    Term _h_74 = STK(0);
    Term _h_75 = STK(1);
    u32 _v_325 = STK(2);
    u32 _v_326 = STK(3);
    u32 _h_76 = STK(4);
    u32 _h_77 = STK(5);
    u32 _h_78 = STK(6);
    u32 _h_79 = STK(7);
    Term _h_80 = STK(8);
    u32 _h_81 = STK(9);
    Term _h_82 = STK(10);
    Term _h_83 = STK(11);
    Term _h_84 = STK(12);
    Term _h_85 = STK(13);
    u32 _h_86 = STK(14);
    u32 _h_87 = STK(15);
    Term _h_88 = STK(16);
    Term _h_89 = STK(17);
    Term _h_90 = STK(18);
    Term _h_91 = STK(19);
    Term _h_92 = STK(20);
    Term _h_93 = STK(21);
    u32 _h_94 = STK(22);
    u32 _h_95 = STK(23);
    u32 _h_96 = STK(24);
    Term _h_97 = STK(25);
    Term _h_98 = STK(26);
    u32 _h_99 = STK(27);
    Term _h_100 = STK(28);
    u32 _h_101 = STK(29);
    Term _h_73 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_74;
      STK(1) = _h_75;
      STK(2) = _v_326;
      STK(3) = _h_76;
      STK(4) = _h_77;
      STK(5) = _h_78;
      STK(6) = _h_79;
      STK(7) = _h_80;
      STK(8) = _h_81;
      STK(9) = _h_82;
      STK(10) = _h_83;
      STK(11) = _h_84;
      STK(12) = _h_85;
      STK(13) = _h_86;
      STK(14) = _h_87;
      STK(15) = _h_88;
      STK(16) = _h_89;
      STK(17) = _h_90;
      STK(18) = _h_91;
      STK(19) = _h_92;
      STK(20) = _h_93;
      STK(21) = _h_94;
      STK(22) = _h_95;
      STK(23) = _h_96;
      STK(24) = _h_97;
      STK(25) = _h_98;
      STK(26) = _h_99;
      STK(27) = _h_100;
      STK(28) = _h_101;
      STK(29) = _h_73;
      STK(30) = FID_CREATED_K609;
      WL_PUSHN(31);
    } else {
      u64 _t_8 = task_node(e, FID_CREATED_K609, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _h_74;
      e.mem[_t_8 + 1] = _h_75;
      e.mem[_t_8 + 2] = _v_326;
      e.mem[_t_8 + 3] = _h_76;
      e.mem[_t_8 + 4] = _h_77;
      e.mem[_t_8 + 5] = _h_78;
      e.mem[_t_8 + 6] = _h_79;
      e.mem[_t_8 + 7] = _h_80;
      e.mem[_t_8 + 8] = _h_81;
      e.mem[_t_8 + 9] = _h_82;
      e.mem[_t_8 + 10] = _h_83;
      e.mem[_t_8 + 11] = _h_84;
      e.mem[_t_8 + 12] = _h_85;
      e.mem[_t_8 + 13] = _h_86;
      e.mem[_t_8 + 14] = _h_87;
      e.mem[_t_8 + 15] = _h_88;
      e.mem[_t_8 + 16] = _h_89;
      e.mem[_t_8 + 17] = _h_90;
      e.mem[_t_8 + 18] = _h_91;
      e.mem[_t_8 + 19] = _h_92;
      e.mem[_t_8 + 20] = _h_93;
      e.mem[_t_8 + 21] = _h_94;
      e.mem[_t_8 + 22] = _h_95;
      e.mem[_t_8 + 23] = _h_96;
      e.mem[_t_8 + 24] = _h_97;
      e.mem[_t_8 + 25] = _h_98;
      e.mem[_t_8 + 26] = _h_99;
      e.mem[_t_8 + 27] = _h_100;
      e.mem[_t_8 + 28] = _h_101;
      e.mem[_t_8 + 29] = _h_73;
      WL_CONT = term_tsk(FID_CREATED_K609, _t_8);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_9 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _v_325;
      return term_tsk(FID_U32_SHOW, _t_9);
    }
    r0 = _v_325;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K609)
  {
    WL_POPN(30);
    Term _h_103 = STK(0);
    Term _h_104 = STK(1);
    u32 _v_327 = STK(2);
    u32 _h_105 = STK(3);
    u32 _h_106 = STK(4);
    u32 _h_107 = STK(5);
    u32 _h_108 = STK(6);
    Term _h_109 = STK(7);
    u32 _h_110 = STK(8);
    Term _h_111 = STK(9);
    Term _h_112 = STK(10);
    Term _h_113 = STK(11);
    Term _h_114 = STK(12);
    u32 _h_115 = STK(13);
    u32 _h_116 = STK(14);
    Term _h_117 = STK(15);
    Term _h_118 = STK(16);
    Term _h_119 = STK(17);
    Term _h_120 = STK(18);
    Term _h_121 = STK(19);
    Term _h_122 = STK(20);
    u32 _h_123 = STK(21);
    u32 _h_124 = STK(22);
    u32 _h_125 = STK(23);
    Term _h_126 = STK(24);
    Term _h_127 = STK(25);
    u32 _h_128 = STK(26);
    Term _h_129 = STK(27);
    u32 _h_130 = STK(28);
    Term _h_131 = STK(29);
    Term _h_102 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_103;
      STK(1) = _h_104;
      STK(2) = _h_105;
      STK(3) = _h_106;
      STK(4) = _h_107;
      STK(5) = _h_108;
      STK(6) = _h_109;
      STK(7) = _h_110;
      STK(8) = _h_111;
      STK(9) = _h_112;
      STK(10) = _h_113;
      STK(11) = _h_114;
      STK(12) = _h_115;
      STK(13) = _h_116;
      STK(14) = _h_117;
      STK(15) = _h_118;
      STK(16) = _h_119;
      STK(17) = _h_120;
      STK(18) = _h_121;
      STK(19) = _h_122;
      STK(20) = _h_123;
      STK(21) = _h_124;
      STK(22) = _h_125;
      STK(23) = _h_126;
      STK(24) = _h_127;
      STK(25) = _h_128;
      STK(26) = _h_129;
      STK(27) = _h_130;
      STK(28) = _h_131;
      STK(29) = _h_102;
      STK(30) = FID_CREATED_K610;
      WL_PUSHN(31);
    } else {
      u64 _t_10 = task_node(e, FID_CREATED_K610, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_103;
      e.mem[_t_10 + 1] = _h_104;
      e.mem[_t_10 + 2] = _h_105;
      e.mem[_t_10 + 3] = _h_106;
      e.mem[_t_10 + 4] = _h_107;
      e.mem[_t_10 + 5] = _h_108;
      e.mem[_t_10 + 6] = _h_109;
      e.mem[_t_10 + 7] = _h_110;
      e.mem[_t_10 + 8] = _h_111;
      e.mem[_t_10 + 9] = _h_112;
      e.mem[_t_10 + 10] = _h_113;
      e.mem[_t_10 + 11] = _h_114;
      e.mem[_t_10 + 12] = _h_115;
      e.mem[_t_10 + 13] = _h_116;
      e.mem[_t_10 + 14] = _h_117;
      e.mem[_t_10 + 15] = _h_118;
      e.mem[_t_10 + 16] = _h_119;
      e.mem[_t_10 + 17] = _h_120;
      e.mem[_t_10 + 18] = _h_121;
      e.mem[_t_10 + 19] = _h_122;
      e.mem[_t_10 + 20] = _h_123;
      e.mem[_t_10 + 21] = _h_124;
      e.mem[_t_10 + 22] = _h_125;
      e.mem[_t_10 + 23] = _h_126;
      e.mem[_t_10 + 24] = _h_127;
      e.mem[_t_10 + 25] = _h_128;
      e.mem[_t_10 + 26] = _h_129;
      e.mem[_t_10 + 27] = _h_130;
      e.mem[_t_10 + 28] = _h_131;
      e.mem[_t_10 + 29] = _h_102;
      WL_CONT = term_tsk(FID_CREATED_K610, _t_10);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_11 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _v_327;
      return term_tsk(FID_U32_SHOW, _t_11);
    }
    r0 = _v_327;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K610)
  {
    WL_POPN(30);
    Term _h_133 = STK(0);
    Term _h_134 = STK(1);
    u32 _h_135 = STK(2);
    u32 _h_136 = STK(3);
    u32 _h_137 = STK(4);
    u32 _h_138 = STK(5);
    Term _h_139 = STK(6);
    u32 _h_140 = STK(7);
    Term _h_141 = STK(8);
    Term _h_142 = STK(9);
    Term _h_143 = STK(10);
    Term _h_144 = STK(11);
    u32 _h_145 = STK(12);
    u32 _h_146 = STK(13);
    Term _h_147 = STK(14);
    Term _h_148 = STK(15);
    Term _h_149 = STK(16);
    Term _h_150 = STK(17);
    Term _h_151 = STK(18);
    Term _h_152 = STK(19);
    u32 _h_153 = STK(20);
    u32 _h_154 = STK(21);
    u32 _h_155 = STK(22);
    Term _h_156 = STK(23);
    Term _h_157 = STK(24);
    u32 _h_158 = STK(25);
    Term _h_159 = STK(26);
    u32 _h_160 = STK(27);
    Term _h_161 = STK(28);
    Term _h_162 = STK(29);
    Term _h_132 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_133;
      STK(1) = _h_135;
      STK(2) = _h_136;
      STK(3) = _h_137;
      STK(4) = _h_138;
      STK(5) = _h_139;
      STK(6) = _h_140;
      STK(7) = _h_141;
      STK(8) = _h_142;
      STK(9) = _h_143;
      STK(10) = _h_144;
      STK(11) = _h_145;
      STK(12) = _h_146;
      STK(13) = _h_147;
      STK(14) = _h_148;
      STK(15) = _h_149;
      STK(16) = _h_150;
      STK(17) = _h_151;
      STK(18) = _h_152;
      STK(19) = _h_153;
      STK(20) = _h_154;
      STK(21) = _h_155;
      STK(22) = _h_156;
      STK(23) = _h_157;
      STK(24) = _h_158;
      STK(25) = _h_159;
      STK(26) = _h_160;
      STK(27) = _h_161;
      STK(28) = _h_162;
      STK(29) = _h_132;
      STK(30) = FID_CREATED_K611;
      WL_PUSHN(31);
    } else {
      u64 _t_12 = task_node(e, FID_CREATED_K611, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_133;
      e.mem[_t_12 + 1] = _h_135;
      e.mem[_t_12 + 2] = _h_136;
      e.mem[_t_12 + 3] = _h_137;
      e.mem[_t_12 + 4] = _h_138;
      e.mem[_t_12 + 5] = _h_139;
      e.mem[_t_12 + 6] = _h_140;
      e.mem[_t_12 + 7] = _h_141;
      e.mem[_t_12 + 8] = _h_142;
      e.mem[_t_12 + 9] = _h_143;
      e.mem[_t_12 + 10] = _h_144;
      e.mem[_t_12 + 11] = _h_145;
      e.mem[_t_12 + 12] = _h_146;
      e.mem[_t_12 + 13] = _h_147;
      e.mem[_t_12 + 14] = _h_148;
      e.mem[_t_12 + 15] = _h_149;
      e.mem[_t_12 + 16] = _h_150;
      e.mem[_t_12 + 17] = _h_151;
      e.mem[_t_12 + 18] = _h_152;
      e.mem[_t_12 + 19] = _h_153;
      e.mem[_t_12 + 20] = _h_154;
      e.mem[_t_12 + 21] = _h_155;
      e.mem[_t_12 + 22] = _h_156;
      e.mem[_t_12 + 23] = _h_157;
      e.mem[_t_12 + 24] = _h_158;
      e.mem[_t_12 + 25] = _h_159;
      e.mem[_t_12 + 26] = _h_160;
      e.mem[_t_12 + 27] = _h_161;
      e.mem[_t_12 + 28] = _h_162;
      e.mem[_t_12 + 29] = _h_132;
      WL_CONT = term_tsk(FID_CREATED_K611, _t_12);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_READINGS)) {
      u64 _t_13 = task_node(e, FID_READINGS, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _h_134;
      return term_tsk(FID_READINGS, _t_13);
    }
    r0 = _h_134;
    WL_JMP(FID_READINGS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K611)
  {
    WL_POPN(30);
    Term _h_164 = STK(0);
    u32 _h_165 = STK(1);
    u32 _h_166 = STK(2);
    u32 _h_167 = STK(3);
    u32 _h_168 = STK(4);
    Term _h_169 = STK(5);
    u32 _h_170 = STK(6);
    Term _h_171 = STK(7);
    Term _h_172 = STK(8);
    Term _h_173 = STK(9);
    Term _h_174 = STK(10);
    u32 _h_175 = STK(11);
    u32 _h_176 = STK(12);
    Term _h_177 = STK(13);
    Term _h_178 = STK(14);
    Term _h_179 = STK(15);
    Term _h_180 = STK(16);
    Term _h_181 = STK(17);
    Term _h_182 = STK(18);
    u32 _h_183 = STK(19);
    u32 _h_184 = STK(20);
    u32 _h_185 = STK(21);
    Term _h_186 = STK(22);
    Term _h_187 = STK(23);
    u32 _h_188 = STK(24);
    Term _h_189 = STK(25);
    u32 _h_190 = STK(26);
    Term _h_191 = STK(27);
    Term _h_192 = STK(28);
    Term _h_193 = STK(29);
    Term _h_163 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(32);
      STK(0) = _h_164;
      STK(1) = _h_165;
      STK(2) = _h_166;
      STK(3) = _h_167;
      STK(4) = _h_168;
      STK(5) = _h_169;
      STK(6) = _h_170;
      STK(7) = _h_171;
      STK(8) = _h_172;
      STK(9) = _h_173;
      STK(10) = _h_174;
      STK(11) = _h_175;
      STK(12) = _h_176;
      STK(13) = _h_177;
      STK(14) = _h_178;
      STK(15) = _h_179;
      STK(16) = _h_180;
      STK(17) = _h_181;
      STK(18) = _h_182;
      STK(19) = _h_183;
      STK(20) = _h_184;
      STK(21) = _h_185;
      STK(22) = _h_186;
      STK(23) = _h_187;
      STK(24) = _h_188;
      STK(25) = _h_189;
      STK(26) = _h_190;
      STK(27) = _h_191;
      STK(28) = _h_192;
      STK(29) = _h_193;
      STK(30) = _h_163;
      STK(31) = FID_CREATED_K612;
      WL_PUSHN(32);
    } else {
      u64 _t_14 = task_node(e, FID_CREATED_K612, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _h_164;
      e.mem[_t_14 + 1] = _h_165;
      e.mem[_t_14 + 2] = _h_166;
      e.mem[_t_14 + 3] = _h_167;
      e.mem[_t_14 + 4] = _h_168;
      e.mem[_t_14 + 5] = _h_169;
      e.mem[_t_14 + 6] = _h_170;
      e.mem[_t_14 + 7] = _h_171;
      e.mem[_t_14 + 8] = _h_172;
      e.mem[_t_14 + 9] = _h_173;
      e.mem[_t_14 + 10] = _h_174;
      e.mem[_t_14 + 11] = _h_175;
      e.mem[_t_14 + 12] = _h_176;
      e.mem[_t_14 + 13] = _h_177;
      e.mem[_t_14 + 14] = _h_178;
      e.mem[_t_14 + 15] = _h_179;
      e.mem[_t_14 + 16] = _h_180;
      e.mem[_t_14 + 17] = _h_181;
      e.mem[_t_14 + 18] = _h_182;
      e.mem[_t_14 + 19] = _h_183;
      e.mem[_t_14 + 20] = _h_184;
      e.mem[_t_14 + 21] = _h_185;
      e.mem[_t_14 + 22] = _h_186;
      e.mem[_t_14 + 23] = _h_187;
      e.mem[_t_14 + 24] = _h_188;
      e.mem[_t_14 + 25] = _h_189;
      e.mem[_t_14 + 26] = _h_190;
      e.mem[_t_14 + 27] = _h_191;
      e.mem[_t_14 + 28] = _h_192;
      e.mem[_t_14 + 29] = _h_193;
      e.mem[_t_14 + 30] = _h_163;
      WL_CONT = term_tsk(FID_CREATED_K612, _t_14);
      WL_IDX = 31;
    }
    if (!DEVICE && !seq && fid_nofk(FID_POSITIONS)) {
      u64 _t_15 = task_node(e, FID_POSITIONS, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _h_164;
      return term_tsk(FID_POSITIONS, _t_15);
    }
    r0 = _h_164;
    WL_JMP(FID_POSITIONS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K612)
  {
    WL_POPN(31);
    Term _h_195 = STK(0);
    u32 _h_196 = STK(1);
    u32 _h_197 = STK(2);
    u32 _h_198 = STK(3);
    u32 _h_199 = STK(4);
    Term _h_200 = STK(5);
    u32 _h_201 = STK(6);
    Term _h_202 = STK(7);
    Term _h_203 = STK(8);
    Term _h_204 = STK(9);
    Term _h_205 = STK(10);
    u32 _h_206 = STK(11);
    u32 _h_207 = STK(12);
    Term _h_208 = STK(13);
    Term _h_209 = STK(14);
    Term _h_210 = STK(15);
    Term _h_211 = STK(16);
    Term _h_212 = STK(17);
    Term _h_213 = STK(18);
    u32 _h_214 = STK(19);
    u32 _h_215 = STK(20);
    u32 _h_216 = STK(21);
    Term _h_217 = STK(22);
    Term _h_218 = STK(23);
    u32 _h_219 = STK(24);
    Term _h_220 = STK(25);
    u32 _h_221 = STK(26);
    Term _h_222 = STK(27);
    Term _h_223 = STK(28);
    Term _h_224 = STK(29);
    Term _h_225 = STK(30);
    Term _h_194 = r0;
    WL_OPEN
    term_sink(e, _h_195);
    if (seq) {
      WL_ROOM(31);
      STK(0) = _h_196;
      STK(1) = _h_197;
      STK(2) = _h_198;
      STK(3) = _h_199;
      STK(4) = _h_200;
      STK(5) = _h_201;
      STK(6) = _h_202;
      STK(7) = _h_203;
      STK(8) = _h_204;
      STK(9) = _h_205;
      STK(10) = _h_206;
      STK(11) = _h_207;
      STK(12) = _h_208;
      STK(13) = _h_209;
      STK(14) = _h_210;
      STK(15) = _h_211;
      STK(16) = _h_212;
      STK(17) = _h_213;
      STK(18) = _h_214;
      STK(19) = _h_215;
      STK(20) = _h_216;
      STK(21) = _h_217;
      STK(22) = _h_218;
      STK(23) = _h_219;
      STK(24) = _h_220;
      STK(25) = _h_221;
      STK(26) = _h_222;
      STK(27) = _h_223;
      STK(28) = _h_224;
      STK(29) = _h_225;
      STK(30) = FID_CREATED_K613;
      WL_PUSHN(31);
    } else {
      u64 _t_16 = task_node(e, FID_CREATED_K613, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _h_196;
      e.mem[_t_16 + 1] = _h_197;
      e.mem[_t_16 + 2] = _h_198;
      e.mem[_t_16 + 3] = _h_199;
      e.mem[_t_16 + 4] = _h_200;
      e.mem[_t_16 + 5] = _h_201;
      e.mem[_t_16 + 6] = _h_202;
      e.mem[_t_16 + 7] = _h_203;
      e.mem[_t_16 + 8] = _h_204;
      e.mem[_t_16 + 9] = _h_205;
      e.mem[_t_16 + 10] = _h_206;
      e.mem[_t_16 + 11] = _h_207;
      e.mem[_t_16 + 12] = _h_208;
      e.mem[_t_16 + 13] = _h_209;
      e.mem[_t_16 + 14] = _h_210;
      e.mem[_t_16 + 15] = _h_211;
      e.mem[_t_16 + 16] = _h_212;
      e.mem[_t_16 + 17] = _h_213;
      e.mem[_t_16 + 18] = _h_214;
      e.mem[_t_16 + 19] = _h_215;
      e.mem[_t_16 + 20] = _h_216;
      e.mem[_t_16 + 21] = _h_217;
      e.mem[_t_16 + 22] = _h_218;
      e.mem[_t_16 + 23] = _h_219;
      e.mem[_t_16 + 24] = _h_220;
      e.mem[_t_16 + 25] = _h_221;
      e.mem[_t_16 + 26] = _h_222;
      e.mem[_t_16 + 27] = _h_223;
      e.mem[_t_16 + 28] = _h_224;
      e.mem[_t_16 + 29] = _h_225;
      WL_CONT = term_tsk(FID_CREATED_K613, _t_16);
      WL_IDX = 30;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_17 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = term_ctr(CID_SCON, STAT_OFF + 524);
      e.mem[_t_17 + 1] = _h_194;
      return term_tsk(FID_STRING_APPEND, _t_17);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 524);
    r1 = _h_194;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K613)
  {
    WL_POPN(30);
    u32 _h_227 = STK(0);
    u32 _h_228 = STK(1);
    u32 _h_229 = STK(2);
    u32 _h_230 = STK(3);
    Term _h_231 = STK(4);
    u32 _h_232 = STK(5);
    Term _h_233 = STK(6);
    Term _h_234 = STK(7);
    Term _h_235 = STK(8);
    Term _h_236 = STK(9);
    u32 _h_237 = STK(10);
    u32 _h_238 = STK(11);
    Term _h_239 = STK(12);
    Term _h_240 = STK(13);
    Term _h_241 = STK(14);
    Term _h_242 = STK(15);
    Term _h_243 = STK(16);
    Term _h_244 = STK(17);
    u32 _h_245 = STK(18);
    u32 _h_246 = STK(19);
    u32 _h_247 = STK(20);
    Term _h_248 = STK(21);
    Term _h_249 = STK(22);
    u32 _h_250 = STK(23);
    Term _h_251 = STK(24);
    u32 _h_252 = STK(25);
    Term _h_253 = STK(26);
    Term _h_254 = STK(27);
    Term _h_255 = STK(28);
    Term _h_256 = STK(29);
    Term _h_226 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _h_227;
      STK(1) = _h_228;
      STK(2) = _h_229;
      STK(3) = _h_230;
      STK(4) = _h_231;
      STK(5) = _h_232;
      STK(6) = _h_233;
      STK(7) = _h_234;
      STK(8) = _h_235;
      STK(9) = _h_236;
      STK(10) = _h_237;
      STK(11) = _h_238;
      STK(12) = _h_239;
      STK(13) = _h_240;
      STK(14) = _h_241;
      STK(15) = _h_242;
      STK(16) = _h_243;
      STK(17) = _h_244;
      STK(18) = _h_245;
      STK(19) = _h_246;
      STK(20) = _h_247;
      STK(21) = _h_248;
      STK(22) = _h_249;
      STK(23) = _h_250;
      STK(24) = _h_251;
      STK(25) = _h_252;
      STK(26) = _h_253;
      STK(27) = _h_254;
      STK(28) = _h_255;
      STK(29) = FID_CREATED_K614;
      WL_PUSHN(30);
    } else {
      u64 _t_18 = task_node(e, FID_CREATED_K614, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _h_227;
      e.mem[_t_18 + 1] = _h_228;
      e.mem[_t_18 + 2] = _h_229;
      e.mem[_t_18 + 3] = _h_230;
      e.mem[_t_18 + 4] = _h_231;
      e.mem[_t_18 + 5] = _h_232;
      e.mem[_t_18 + 6] = _h_233;
      e.mem[_t_18 + 7] = _h_234;
      e.mem[_t_18 + 8] = _h_235;
      e.mem[_t_18 + 9] = _h_236;
      e.mem[_t_18 + 10] = _h_237;
      e.mem[_t_18 + 11] = _h_238;
      e.mem[_t_18 + 12] = _h_239;
      e.mem[_t_18 + 13] = _h_240;
      e.mem[_t_18 + 14] = _h_241;
      e.mem[_t_18 + 15] = _h_242;
      e.mem[_t_18 + 16] = _h_243;
      e.mem[_t_18 + 17] = _h_244;
      e.mem[_t_18 + 18] = _h_245;
      e.mem[_t_18 + 19] = _h_246;
      e.mem[_t_18 + 20] = _h_247;
      e.mem[_t_18 + 21] = _h_248;
      e.mem[_t_18 + 22] = _h_249;
      e.mem[_t_18 + 23] = _h_250;
      e.mem[_t_18 + 24] = _h_251;
      e.mem[_t_18 + 25] = _h_252;
      e.mem[_t_18 + 26] = _h_253;
      e.mem[_t_18 + 27] = _h_254;
      e.mem[_t_18 + 28] = _h_255;
      WL_CONT = term_tsk(FID_CREATED_K614, _t_18);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_19 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _h_256;
      e.mem[_t_19 + 1] = _h_226;
      return term_tsk(FID_STRING_APPEND, _t_19);
    }
    r0 = _h_256;
    r1 = _h_226;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K614)
  {
    WL_POPN(29);
    u32 _h_258 = STK(0);
    u32 _h_259 = STK(1);
    u32 _h_260 = STK(2);
    u32 _h_261 = STK(3);
    Term _h_262 = STK(4);
    u32 _h_263 = STK(5);
    Term _h_264 = STK(6);
    Term _h_265 = STK(7);
    Term _h_266 = STK(8);
    Term _h_267 = STK(9);
    u32 _h_268 = STK(10);
    u32 _h_269 = STK(11);
    Term _h_270 = STK(12);
    Term _h_271 = STK(13);
    Term _h_272 = STK(14);
    Term _h_273 = STK(15);
    Term _h_274 = STK(16);
    Term _h_275 = STK(17);
    u32 _h_276 = STK(18);
    u32 _h_277 = STK(19);
    u32 _h_278 = STK(20);
    Term _h_279 = STK(21);
    Term _h_280 = STK(22);
    u32 _h_281 = STK(23);
    Term _h_282 = STK(24);
    u32 _h_283 = STK(25);
    Term _h_284 = STK(26);
    Term _h_285 = STK(27);
    Term _h_286 = STK(28);
    Term _h_257 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(30);
      STK(0) = _h_258;
      STK(1) = _h_259;
      STK(2) = _h_260;
      STK(3) = _h_261;
      STK(4) = _h_262;
      STK(5) = _h_263;
      STK(6) = _h_264;
      STK(7) = _h_265;
      STK(8) = _h_266;
      STK(9) = _h_267;
      STK(10) = _h_268;
      STK(11) = _h_269;
      STK(12) = _h_270;
      STK(13) = _h_271;
      STK(14) = _h_272;
      STK(15) = _h_273;
      STK(16) = _h_274;
      STK(17) = _h_275;
      STK(18) = _h_276;
      STK(19) = _h_277;
      STK(20) = _h_278;
      STK(21) = _h_279;
      STK(22) = _h_280;
      STK(23) = _h_281;
      STK(24) = _h_282;
      STK(25) = _h_283;
      STK(26) = _h_284;
      STK(27) = _h_285;
      STK(28) = _h_286;
      STK(29) = FID_CREATED_K615;
      WL_PUSHN(30);
    } else {
      u64 _t_20 = task_node(e, FID_CREATED_K615, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _h_258;
      e.mem[_t_20 + 1] = _h_259;
      e.mem[_t_20 + 2] = _h_260;
      e.mem[_t_20 + 3] = _h_261;
      e.mem[_t_20 + 4] = _h_262;
      e.mem[_t_20 + 5] = _h_263;
      e.mem[_t_20 + 6] = _h_264;
      e.mem[_t_20 + 7] = _h_265;
      e.mem[_t_20 + 8] = _h_266;
      e.mem[_t_20 + 9] = _h_267;
      e.mem[_t_20 + 10] = _h_268;
      e.mem[_t_20 + 11] = _h_269;
      e.mem[_t_20 + 12] = _h_270;
      e.mem[_t_20 + 13] = _h_271;
      e.mem[_t_20 + 14] = _h_272;
      e.mem[_t_20 + 15] = _h_273;
      e.mem[_t_20 + 16] = _h_274;
      e.mem[_t_20 + 17] = _h_275;
      e.mem[_t_20 + 18] = _h_276;
      e.mem[_t_20 + 19] = _h_277;
      e.mem[_t_20 + 20] = _h_278;
      e.mem[_t_20 + 21] = _h_279;
      e.mem[_t_20 + 22] = _h_280;
      e.mem[_t_20 + 23] = _h_281;
      e.mem[_t_20 + 24] = _h_282;
      e.mem[_t_20 + 25] = _h_283;
      e.mem[_t_20 + 26] = _h_284;
      e.mem[_t_20 + 27] = _h_285;
      e.mem[_t_20 + 28] = _h_286;
      WL_CONT = term_tsk(FID_CREATED_K615, _t_20);
      WL_IDX = 29;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_21 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = term_ctr(CID_SCON, STAT_OFF + 542);
      e.mem[_t_21 + 1] = _h_257;
      return term_tsk(FID_STRING_APPEND, _t_21);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 542);
    r1 = _h_257;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K615)
  {
    WL_POPN(29);
    u32 _h_288 = STK(0);
    u32 _h_289 = STK(1);
    u32 _h_290 = STK(2);
    u32 _h_291 = STK(3);
    Term _h_292 = STK(4);
    u32 _h_293 = STK(5);
    Term _h_294 = STK(6);
    Term _h_295 = STK(7);
    Term _h_296 = STK(8);
    Term _h_297 = STK(9);
    u32 _h_298 = STK(10);
    u32 _h_299 = STK(11);
    Term _h_300 = STK(12);
    Term _h_301 = STK(13);
    Term _h_302 = STK(14);
    Term _h_303 = STK(15);
    Term _h_304 = STK(16);
    Term _h_305 = STK(17);
    u32 _h_306 = STK(18);
    u32 _h_307 = STK(19);
    u32 _h_308 = STK(20);
    Term _h_309 = STK(21);
    Term _h_310 = STK(22);
    u32 _h_311 = STK(23);
    Term _h_312 = STK(24);
    u32 _h_313 = STK(25);
    Term _h_314 = STK(26);
    Term _h_315 = STK(27);
    Term _h_316 = STK(28);
    Term _h_287 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_288;
      STK(1) = _h_289;
      STK(2) = _h_290;
      STK(3) = _h_291;
      STK(4) = _h_292;
      STK(5) = _h_293;
      STK(6) = _h_294;
      STK(7) = _h_295;
      STK(8) = _h_296;
      STK(9) = _h_297;
      STK(10) = _h_298;
      STK(11) = _h_299;
      STK(12) = _h_300;
      STK(13) = _h_301;
      STK(14) = _h_302;
      STK(15) = _h_303;
      STK(16) = _h_304;
      STK(17) = _h_305;
      STK(18) = _h_306;
      STK(19) = _h_307;
      STK(20) = _h_308;
      STK(21) = _h_309;
      STK(22) = _h_310;
      STK(23) = _h_311;
      STK(24) = _h_312;
      STK(25) = _h_313;
      STK(26) = _h_314;
      STK(27) = _h_315;
      STK(28) = FID_CREATED_K616;
      WL_PUSHN(29);
    } else {
      u64 _t_22 = task_node(e, FID_CREATED_K616, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _h_288;
      e.mem[_t_22 + 1] = _h_289;
      e.mem[_t_22 + 2] = _h_290;
      e.mem[_t_22 + 3] = _h_291;
      e.mem[_t_22 + 4] = _h_292;
      e.mem[_t_22 + 5] = _h_293;
      e.mem[_t_22 + 6] = _h_294;
      e.mem[_t_22 + 7] = _h_295;
      e.mem[_t_22 + 8] = _h_296;
      e.mem[_t_22 + 9] = _h_297;
      e.mem[_t_22 + 10] = _h_298;
      e.mem[_t_22 + 11] = _h_299;
      e.mem[_t_22 + 12] = _h_300;
      e.mem[_t_22 + 13] = _h_301;
      e.mem[_t_22 + 14] = _h_302;
      e.mem[_t_22 + 15] = _h_303;
      e.mem[_t_22 + 16] = _h_304;
      e.mem[_t_22 + 17] = _h_305;
      e.mem[_t_22 + 18] = _h_306;
      e.mem[_t_22 + 19] = _h_307;
      e.mem[_t_22 + 20] = _h_308;
      e.mem[_t_22 + 21] = _h_309;
      e.mem[_t_22 + 22] = _h_310;
      e.mem[_t_22 + 23] = _h_311;
      e.mem[_t_22 + 24] = _h_312;
      e.mem[_t_22 + 25] = _h_313;
      e.mem[_t_22 + 26] = _h_314;
      e.mem[_t_22 + 27] = _h_315;
      WL_CONT = term_tsk(FID_CREATED_K616, _t_22);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_23 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _h_316;
      e.mem[_t_23 + 1] = _h_287;
      return term_tsk(FID_STRING_APPEND, _t_23);
    }
    r0 = _h_316;
    r1 = _h_287;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K616)
  {
    WL_POPN(28);
    u32 _h_318 = STK(0);
    u32 _h_319 = STK(1);
    u32 _h_320 = STK(2);
    u32 _h_321 = STK(3);
    Term _h_322 = STK(4);
    u32 _h_323 = STK(5);
    Term _h_324 = STK(6);
    Term _h_325 = STK(7);
    Term _h_326 = STK(8);
    Term _h_327 = STK(9);
    u32 _h_328 = STK(10);
    u32 _h_329 = STK(11);
    Term _h_330 = STK(12);
    Term _h_331 = STK(13);
    Term _h_332 = STK(14);
    Term _h_333 = STK(15);
    Term _h_334 = STK(16);
    Term _h_335 = STK(17);
    u32 _h_336 = STK(18);
    u32 _h_337 = STK(19);
    u32 _h_338 = STK(20);
    Term _h_339 = STK(21);
    Term _h_340 = STK(22);
    u32 _h_341 = STK(23);
    Term _h_342 = STK(24);
    u32 _h_343 = STK(25);
    Term _h_344 = STK(26);
    Term _h_345 = STK(27);
    Term _h_317 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(29);
      STK(0) = _h_318;
      STK(1) = _h_319;
      STK(2) = _h_320;
      STK(3) = _h_321;
      STK(4) = _h_322;
      STK(5) = _h_323;
      STK(6) = _h_324;
      STK(7) = _h_325;
      STK(8) = _h_326;
      STK(9) = _h_327;
      STK(10) = _h_328;
      STK(11) = _h_329;
      STK(12) = _h_330;
      STK(13) = _h_331;
      STK(14) = _h_332;
      STK(15) = _h_333;
      STK(16) = _h_334;
      STK(17) = _h_335;
      STK(18) = _h_336;
      STK(19) = _h_337;
      STK(20) = _h_338;
      STK(21) = _h_339;
      STK(22) = _h_340;
      STK(23) = _h_341;
      STK(24) = _h_342;
      STK(25) = _h_343;
      STK(26) = _h_344;
      STK(27) = _h_345;
      STK(28) = FID_CREATED_K617;
      WL_PUSHN(29);
    } else {
      u64 _t_24 = task_node(e, FID_CREATED_K617, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _h_318;
      e.mem[_t_24 + 1] = _h_319;
      e.mem[_t_24 + 2] = _h_320;
      e.mem[_t_24 + 3] = _h_321;
      e.mem[_t_24 + 4] = _h_322;
      e.mem[_t_24 + 5] = _h_323;
      e.mem[_t_24 + 6] = _h_324;
      e.mem[_t_24 + 7] = _h_325;
      e.mem[_t_24 + 8] = _h_326;
      e.mem[_t_24 + 9] = _h_327;
      e.mem[_t_24 + 10] = _h_328;
      e.mem[_t_24 + 11] = _h_329;
      e.mem[_t_24 + 12] = _h_330;
      e.mem[_t_24 + 13] = _h_331;
      e.mem[_t_24 + 14] = _h_332;
      e.mem[_t_24 + 15] = _h_333;
      e.mem[_t_24 + 16] = _h_334;
      e.mem[_t_24 + 17] = _h_335;
      e.mem[_t_24 + 18] = _h_336;
      e.mem[_t_24 + 19] = _h_337;
      e.mem[_t_24 + 20] = _h_338;
      e.mem[_t_24 + 21] = _h_339;
      e.mem[_t_24 + 22] = _h_340;
      e.mem[_t_24 + 23] = _h_341;
      e.mem[_t_24 + 24] = _h_342;
      e.mem[_t_24 + 25] = _h_343;
      e.mem[_t_24 + 26] = _h_344;
      e.mem[_t_24 + 27] = _h_345;
      WL_CONT = term_tsk(FID_CREATED_K617, _t_24);
      WL_IDX = 28;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_25 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = term_ctr(CID_SCON, STAT_OFF + 548);
      e.mem[_t_25 + 1] = _h_317;
      return term_tsk(FID_STRING_APPEND, _t_25);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 548);
    r1 = _h_317;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K617)
  {
    WL_POPN(28);
    u32 _h_347 = STK(0);
    u32 _h_348 = STK(1);
    u32 _h_349 = STK(2);
    u32 _h_350 = STK(3);
    Term _h_351 = STK(4);
    u32 _h_352 = STK(5);
    Term _h_353 = STK(6);
    Term _h_354 = STK(7);
    Term _h_355 = STK(8);
    Term _h_356 = STK(9);
    u32 _h_357 = STK(10);
    u32 _h_358 = STK(11);
    Term _h_359 = STK(12);
    Term _h_360 = STK(13);
    Term _h_361 = STK(14);
    Term _h_362 = STK(15);
    Term _h_363 = STK(16);
    Term _h_364 = STK(17);
    u32 _h_365 = STK(18);
    u32 _h_366 = STK(19);
    u32 _h_367 = STK(20);
    Term _h_368 = STK(21);
    Term _h_369 = STK(22);
    u32 _h_370 = STK(23);
    Term _h_371 = STK(24);
    u32 _h_372 = STK(25);
    Term _h_373 = STK(26);
    Term _h_374 = STK(27);
    Term _h_346 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_347;
      STK(1) = _h_348;
      STK(2) = _h_349;
      STK(3) = _h_350;
      STK(4) = _h_351;
      STK(5) = _h_352;
      STK(6) = _h_353;
      STK(7) = _h_354;
      STK(8) = _h_355;
      STK(9) = _h_356;
      STK(10) = _h_357;
      STK(11) = _h_358;
      STK(12) = _h_359;
      STK(13) = _h_360;
      STK(14) = _h_361;
      STK(15) = _h_362;
      STK(16) = _h_363;
      STK(17) = _h_364;
      STK(18) = _h_365;
      STK(19) = _h_366;
      STK(20) = _h_367;
      STK(21) = _h_368;
      STK(22) = _h_369;
      STK(23) = _h_370;
      STK(24) = _h_371;
      STK(25) = _h_372;
      STK(26) = _h_373;
      STK(27) = FID_CREATED_K618;
      WL_PUSHN(28);
    } else {
      u64 _t_26 = task_node(e, FID_CREATED_K618, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _h_347;
      e.mem[_t_26 + 1] = _h_348;
      e.mem[_t_26 + 2] = _h_349;
      e.mem[_t_26 + 3] = _h_350;
      e.mem[_t_26 + 4] = _h_351;
      e.mem[_t_26 + 5] = _h_352;
      e.mem[_t_26 + 6] = _h_353;
      e.mem[_t_26 + 7] = _h_354;
      e.mem[_t_26 + 8] = _h_355;
      e.mem[_t_26 + 9] = _h_356;
      e.mem[_t_26 + 10] = _h_357;
      e.mem[_t_26 + 11] = _h_358;
      e.mem[_t_26 + 12] = _h_359;
      e.mem[_t_26 + 13] = _h_360;
      e.mem[_t_26 + 14] = _h_361;
      e.mem[_t_26 + 15] = _h_362;
      e.mem[_t_26 + 16] = _h_363;
      e.mem[_t_26 + 17] = _h_364;
      e.mem[_t_26 + 18] = _h_365;
      e.mem[_t_26 + 19] = _h_366;
      e.mem[_t_26 + 20] = _h_367;
      e.mem[_t_26 + 21] = _h_368;
      e.mem[_t_26 + 22] = _h_369;
      e.mem[_t_26 + 23] = _h_370;
      e.mem[_t_26 + 24] = _h_371;
      e.mem[_t_26 + 25] = _h_372;
      e.mem[_t_26 + 26] = _h_373;
      WL_CONT = term_tsk(FID_CREATED_K618, _t_26);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_27 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _h_374;
      e.mem[_t_27 + 1] = _h_346;
      return term_tsk(FID_STRING_APPEND, _t_27);
    }
    r0 = _h_374;
    r1 = _h_346;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K618)
  {
    WL_POPN(27);
    u32 _h_376 = STK(0);
    u32 _h_377 = STK(1);
    u32 _h_378 = STK(2);
    u32 _h_379 = STK(3);
    Term _h_380 = STK(4);
    u32 _h_381 = STK(5);
    Term _h_382 = STK(6);
    Term _h_383 = STK(7);
    Term _h_384 = STK(8);
    Term _h_385 = STK(9);
    u32 _h_386 = STK(10);
    u32 _h_387 = STK(11);
    Term _h_388 = STK(12);
    Term _h_389 = STK(13);
    Term _h_390 = STK(14);
    Term _h_391 = STK(15);
    Term _h_392 = STK(16);
    Term _h_393 = STK(17);
    u32 _h_394 = STK(18);
    u32 _h_395 = STK(19);
    u32 _h_396 = STK(20);
    Term _h_397 = STK(21);
    Term _h_398 = STK(22);
    u32 _h_399 = STK(23);
    Term _h_400 = STK(24);
    u32 _h_401 = STK(25);
    Term _h_402 = STK(26);
    Term _h_375 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(28);
      STK(0) = _h_376;
      STK(1) = _h_377;
      STK(2) = _h_378;
      STK(3) = _h_379;
      STK(4) = _h_380;
      STK(5) = _h_381;
      STK(6) = _h_382;
      STK(7) = _h_383;
      STK(8) = _h_384;
      STK(9) = _h_385;
      STK(10) = _h_386;
      STK(11) = _h_387;
      STK(12) = _h_388;
      STK(13) = _h_389;
      STK(14) = _h_390;
      STK(15) = _h_391;
      STK(16) = _h_392;
      STK(17) = _h_393;
      STK(18) = _h_394;
      STK(19) = _h_395;
      STK(20) = _h_396;
      STK(21) = _h_397;
      STK(22) = _h_398;
      STK(23) = _h_399;
      STK(24) = _h_400;
      STK(25) = _h_401;
      STK(26) = _h_402;
      STK(27) = FID_CREATED_K619;
      WL_PUSHN(28);
    } else {
      u64 _t_28 = task_node(e, FID_CREATED_K619, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _h_376;
      e.mem[_t_28 + 1] = _h_377;
      e.mem[_t_28 + 2] = _h_378;
      e.mem[_t_28 + 3] = _h_379;
      e.mem[_t_28 + 4] = _h_380;
      e.mem[_t_28 + 5] = _h_381;
      e.mem[_t_28 + 6] = _h_382;
      e.mem[_t_28 + 7] = _h_383;
      e.mem[_t_28 + 8] = _h_384;
      e.mem[_t_28 + 9] = _h_385;
      e.mem[_t_28 + 10] = _h_386;
      e.mem[_t_28 + 11] = _h_387;
      e.mem[_t_28 + 12] = _h_388;
      e.mem[_t_28 + 13] = _h_389;
      e.mem[_t_28 + 14] = _h_390;
      e.mem[_t_28 + 15] = _h_391;
      e.mem[_t_28 + 16] = _h_392;
      e.mem[_t_28 + 17] = _h_393;
      e.mem[_t_28 + 18] = _h_394;
      e.mem[_t_28 + 19] = _h_395;
      e.mem[_t_28 + 20] = _h_396;
      e.mem[_t_28 + 21] = _h_397;
      e.mem[_t_28 + 22] = _h_398;
      e.mem[_t_28 + 23] = _h_399;
      e.mem[_t_28 + 24] = _h_400;
      e.mem[_t_28 + 25] = _h_401;
      e.mem[_t_28 + 26] = _h_402;
      WL_CONT = term_tsk(FID_CREATED_K619, _t_28);
      WL_IDX = 27;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_29 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = term_ctr(CID_SCON, STAT_OFF + 560);
      e.mem[_t_29 + 1] = _h_375;
      return term_tsk(FID_STRING_APPEND, _t_29);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 560);
    r1 = _h_375;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K619)
  {
    WL_POPN(27);
    u32 _h_404 = STK(0);
    u32 _h_405 = STK(1);
    u32 _h_406 = STK(2);
    u32 _h_407 = STK(3);
    Term _h_408 = STK(4);
    u32 _h_409 = STK(5);
    Term _h_410 = STK(6);
    Term _h_411 = STK(7);
    Term _h_412 = STK(8);
    Term _h_413 = STK(9);
    u32 _h_414 = STK(10);
    u32 _h_415 = STK(11);
    Term _h_416 = STK(12);
    Term _h_417 = STK(13);
    Term _h_418 = STK(14);
    Term _h_419 = STK(15);
    Term _h_420 = STK(16);
    Term _h_421 = STK(17);
    u32 _h_422 = STK(18);
    u32 _h_423 = STK(19);
    u32 _h_424 = STK(20);
    Term _h_425 = STK(21);
    Term _h_426 = STK(22);
    u32 _h_427 = STK(23);
    Term _h_428 = STK(24);
    u32 _h_429 = STK(25);
    Term _h_430 = STK(26);
    Term _h_403 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _h_404;
      STK(1) = _h_405;
      STK(2) = _h_406;
      STK(3) = _h_407;
      STK(4) = _h_408;
      STK(5) = _h_409;
      STK(6) = _h_410;
      STK(7) = _h_411;
      STK(8) = _h_412;
      STK(9) = _h_413;
      STK(10) = _h_414;
      STK(11) = _h_415;
      STK(12) = _h_416;
      STK(13) = _h_417;
      STK(14) = _h_418;
      STK(15) = _h_419;
      STK(16) = _h_420;
      STK(17) = _h_421;
      STK(18) = _h_422;
      STK(19) = _h_423;
      STK(20) = _h_424;
      STK(21) = _h_425;
      STK(22) = _h_426;
      STK(23) = _h_427;
      STK(24) = _h_428;
      STK(25) = _h_429;
      STK(26) = FID_CREATED_K620;
      WL_PUSHN(27);
    } else {
      u64 _t_30 = task_node(e, FID_CREATED_K620, WL_CONT, WL_IDX, 1);
      e.mem[_t_30 + 0] = _h_404;
      e.mem[_t_30 + 1] = _h_405;
      e.mem[_t_30 + 2] = _h_406;
      e.mem[_t_30 + 3] = _h_407;
      e.mem[_t_30 + 4] = _h_408;
      e.mem[_t_30 + 5] = _h_409;
      e.mem[_t_30 + 6] = _h_410;
      e.mem[_t_30 + 7] = _h_411;
      e.mem[_t_30 + 8] = _h_412;
      e.mem[_t_30 + 9] = _h_413;
      e.mem[_t_30 + 10] = _h_414;
      e.mem[_t_30 + 11] = _h_415;
      e.mem[_t_30 + 12] = _h_416;
      e.mem[_t_30 + 13] = _h_417;
      e.mem[_t_30 + 14] = _h_418;
      e.mem[_t_30 + 15] = _h_419;
      e.mem[_t_30 + 16] = _h_420;
      e.mem[_t_30 + 17] = _h_421;
      e.mem[_t_30 + 18] = _h_422;
      e.mem[_t_30 + 19] = _h_423;
      e.mem[_t_30 + 20] = _h_424;
      e.mem[_t_30 + 21] = _h_425;
      e.mem[_t_30 + 22] = _h_426;
      e.mem[_t_30 + 23] = _h_427;
      e.mem[_t_30 + 24] = _h_428;
      e.mem[_t_30 + 25] = _h_429;
      WL_CONT = term_tsk(FID_CREATED_K620, _t_30);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_31 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _h_430;
      e.mem[_t_31 + 1] = _h_403;
      return term_tsk(FID_STRING_APPEND, _t_31);
    }
    r0 = _h_430;
    r1 = _h_403;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K620)
  {
    WL_POPN(26);
    u32 _h_432 = STK(0);
    u32 _h_433 = STK(1);
    u32 _h_434 = STK(2);
    u32 _h_435 = STK(3);
    Term _h_436 = STK(4);
    u32 _h_437 = STK(5);
    Term _h_438 = STK(6);
    Term _h_439 = STK(7);
    Term _h_440 = STK(8);
    Term _h_441 = STK(9);
    u32 _h_442 = STK(10);
    u32 _h_443 = STK(11);
    Term _h_444 = STK(12);
    Term _h_445 = STK(13);
    Term _h_446 = STK(14);
    Term _h_447 = STK(15);
    Term _h_448 = STK(16);
    Term _h_449 = STK(17);
    u32 _h_450 = STK(18);
    u32 _h_451 = STK(19);
    u32 _h_452 = STK(20);
    Term _h_453 = STK(21);
    Term _h_454 = STK(22);
    u32 _h_455 = STK(23);
    Term _h_456 = STK(24);
    u32 _h_457 = STK(25);
    Term _h_431 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(27);
      STK(0) = _h_432;
      STK(1) = _h_433;
      STK(2) = _h_434;
      STK(3) = _h_435;
      STK(4) = _h_436;
      STK(5) = _h_437;
      STK(6) = _h_438;
      STK(7) = _h_439;
      STK(8) = _h_440;
      STK(9) = _h_441;
      STK(10) = _h_442;
      STK(11) = _h_443;
      STK(12) = _h_444;
      STK(13) = _h_445;
      STK(14) = _h_446;
      STK(15) = _h_447;
      STK(16) = _h_448;
      STK(17) = _h_449;
      STK(18) = _h_450;
      STK(19) = _h_451;
      STK(20) = _h_452;
      STK(21) = _h_453;
      STK(22) = _h_454;
      STK(23) = _h_455;
      STK(24) = _h_456;
      STK(25) = _h_457;
      STK(26) = FID_CREATED_K621;
      WL_PUSHN(27);
    } else {
      u64 _t_32 = task_node(e, FID_CREATED_K621, WL_CONT, WL_IDX, 1);
      e.mem[_t_32 + 0] = _h_432;
      e.mem[_t_32 + 1] = _h_433;
      e.mem[_t_32 + 2] = _h_434;
      e.mem[_t_32 + 3] = _h_435;
      e.mem[_t_32 + 4] = _h_436;
      e.mem[_t_32 + 5] = _h_437;
      e.mem[_t_32 + 6] = _h_438;
      e.mem[_t_32 + 7] = _h_439;
      e.mem[_t_32 + 8] = _h_440;
      e.mem[_t_32 + 9] = _h_441;
      e.mem[_t_32 + 10] = _h_442;
      e.mem[_t_32 + 11] = _h_443;
      e.mem[_t_32 + 12] = _h_444;
      e.mem[_t_32 + 13] = _h_445;
      e.mem[_t_32 + 14] = _h_446;
      e.mem[_t_32 + 15] = _h_447;
      e.mem[_t_32 + 16] = _h_448;
      e.mem[_t_32 + 17] = _h_449;
      e.mem[_t_32 + 18] = _h_450;
      e.mem[_t_32 + 19] = _h_451;
      e.mem[_t_32 + 20] = _h_452;
      e.mem[_t_32 + 21] = _h_453;
      e.mem[_t_32 + 22] = _h_454;
      e.mem[_t_32 + 23] = _h_455;
      e.mem[_t_32 + 24] = _h_456;
      e.mem[_t_32 + 25] = _h_457;
      WL_CONT = term_tsk(FID_CREATED_K621, _t_32);
      WL_IDX = 26;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_33 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = term_ctr(CID_SCON, STAT_OFF + 576);
      e.mem[_t_33 + 1] = _h_431;
      return term_tsk(FID_STRING_APPEND, _t_33);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 576);
    r1 = _h_431;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K621)
  {
    WL_POPN(26);
    u32 _h_459 = STK(0);
    u32 _h_460 = STK(1);
    u32 _h_461 = STK(2);
    u32 _h_462 = STK(3);
    Term _h_463 = STK(4);
    u32 _h_464 = STK(5);
    Term _h_465 = STK(6);
    Term _h_466 = STK(7);
    Term _h_467 = STK(8);
    Term _h_468 = STK(9);
    u32 _h_469 = STK(10);
    u32 _h_470 = STK(11);
    Term _h_471 = STK(12);
    Term _h_472 = STK(13);
    Term _h_473 = STK(14);
    Term _h_474 = STK(15);
    Term _h_475 = STK(16);
    Term _h_476 = STK(17);
    u32 _h_477 = STK(18);
    u32 _h_478 = STK(19);
    u32 _h_479 = STK(20);
    Term _h_480 = STK(21);
    Term _h_481 = STK(22);
    u32 _h_482 = STK(23);
    Term _h_483 = STK(24);
    u32 _h_484 = STK(25);
    Term _h_458 = r0;
    WL_OPEN
    if (_h_459 == 1) {
      term_sink(e, _h_463);
      term_sink(e, _h_466);
      term_sink(e, _h_467);
      term_sink(e, _h_468);
      term_sink(e, _h_471);
      term_sink(e, _h_472);
      term_sink(e, _h_480);
      term_sink(e, _h_481);
      term_sink(e, _h_483);
      term_sink(e, _h_458);
      r0 = term_ctr(CID_SCON, STAT_OFF + 442);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(9);
        STK(0) = _h_471;
        STK(1) = _h_472;
        STK(2) = _h_473;
        STK(3) = _h_474;
        STK(4) = _h_475;
        STK(5) = _h_476;
        STK(6) = _h_477;
        STK(7) = _h_458;
        STK(8) = FID_CREATED_K622;
        WL_PUSHN(9);
      } else {
        u64 _t_34 = task_node(e, FID_CREATED_K622, WL_CONT, WL_IDX, 1);
        e.mem[_t_34 + 0] = _h_471;
        e.mem[_t_34 + 1] = _h_472;
        e.mem[_t_34 + 2] = _h_473;
        e.mem[_t_34 + 3] = _h_474;
        e.mem[_t_34 + 4] = _h_475;
        e.mem[_t_34 + 5] = _h_476;
        e.mem[_t_34 + 6] = _h_477;
        e.mem[_t_34 + 7] = _h_458;
        WL_CONT = term_tsk(FID_CREATED_K622, _t_34);
        WL_IDX = 8;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0)) {
        u64 _t_35 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_35 + 0] = _h_460;
        e.mem[_t_35 + 1] = _h_461;
        e.mem[_t_35 + 2] = _h_462;
        e.mem[_t_35 + 3] = _h_463;
        e.mem[_t_35 + 4] = _h_464;
        e.mem[_t_35 + 5] = _h_465;
        e.mem[_t_35 + 6] = _h_466;
        e.mem[_t_35 + 7] = _h_467;
        e.mem[_t_35 + 8] = _h_468;
        e.mem[_t_35 + 9] = _h_469;
        e.mem[_t_35 + 10] = _h_470;
        e.mem[_t_35 + 11] = 1ull;
        e.mem[_t_35 + 12] = term_ctr(CID_SCON, STAT_OFF + 460);
        e.mem[_t_35 + 13] = term_pak(CID_NIL, 0);
        return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0, _t_35);
      }
      r0 = _h_460;
      r1 = _h_461;
      r2 = _h_462;
      r3 = _h_463;
      r4 = _h_464;
      r5 = _h_465;
      r6 = _h_466;
      r7 = _h_467;
      r8 = _h_468;
      r9 = _h_469;
      r10 = _h_470;
      r11 = 1ull;
      r12 = term_ctr(CID_SCON, STAT_OFF + 460);
      r13 = term_pak(CID_NIL, 0);
      WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K622)
  {
    WL_POPN(8);
    Term _h_497 = STK(0);
    Term _h_498 = STK(1);
    Term _h_499 = STK(2);
    Term _h_500 = STK(3);
    Term _h_501 = STK(4);
    Term _h_502 = STK(5);
    u32 _h_503 = STK(6);
    Term _h_504 = STK(7);
    u32 _h_485 = r0;
    u32 _h_486 = r1;
    u32 _h_487 = r2;
    Term _h_488 = r3;
    u32 _h_489 = r4;
    Term _h_490 = r5;
    Term _h_491 = r6;
    Term _h_492 = r7;
    Term _h_493 = r8;
    u32 _h_494 = r9;
    u32 _h_495 = r10;
    u32 _h_496 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_497;
      STK(1) = _h_498;
      STK(2) = _h_499;
      STK(3) = _h_500;
      STK(4) = _h_501;
      STK(5) = _h_502;
      STK(6) = _h_503;
      STK(7) = _h_504;
      STK(8) = _h_485;
      STK(9) = _h_486;
      STK(10) = _h_487;
      STK(11) = _h_488;
      STK(12) = _h_489;
      STK(13) = _h_490;
      STK(14) = _h_491;
      STK(15) = _h_492;
      STK(16) = _h_493;
      STK(17) = _h_494;
      STK(18) = _h_495;
      STK(19) = _h_496;
      STK(20) = FID_CREATED_K623;
      WL_PUSHN(21);
    } else {
      u64 _t_36 = task_node(e, FID_CREATED_K623, WL_CONT, WL_IDX, 1);
      e.mem[_t_36 + 0] = _h_497;
      e.mem[_t_36 + 1] = _h_498;
      e.mem[_t_36 + 2] = _h_499;
      e.mem[_t_36 + 3] = _h_500;
      e.mem[_t_36 + 4] = _h_501;
      e.mem[_t_36 + 5] = _h_502;
      e.mem[_t_36 + 6] = _h_503;
      e.mem[_t_36 + 7] = _h_504;
      e.mem[_t_36 + 8] = _h_485;
      e.mem[_t_36 + 9] = _h_486;
      e.mem[_t_36 + 10] = _h_487;
      e.mem[_t_36 + 11] = _h_488;
      e.mem[_t_36 + 12] = _h_489;
      e.mem[_t_36 + 13] = _h_490;
      e.mem[_t_36 + 14] = _h_491;
      e.mem[_t_36 + 15] = _h_492;
      e.mem[_t_36 + 16] = _h_493;
      e.mem[_t_36 + 17] = _h_494;
      e.mem[_t_36 + 18] = _h_495;
      e.mem[_t_36 + 19] = _h_496;
      WL_CONT = term_tsk(FID_CREATED_K623, _t_36);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_POSITIONS)) {
      u64 _t_37 = task_node(e, FID_POSITIONS, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = _h_498;
      return term_tsk(FID_POSITIONS, _t_37);
    }
    r0 = _h_498;
    WL_JMP(FID_POSITIONS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K623)
  {
    WL_POPN(20);
    Term _h_506 = STK(0);
    Term _h_507 = STK(1);
    Term _h_508 = STK(2);
    Term _h_509 = STK(3);
    Term _h_510 = STK(4);
    Term _h_511 = STK(5);
    u32 _h_512 = STK(6);
    Term _h_513 = STK(7);
    u32 _h_514 = STK(8);
    u32 _h_515 = STK(9);
    u32 _h_516 = STK(10);
    Term _h_517 = STK(11);
    u32 _h_518 = STK(12);
    Term _h_519 = STK(13);
    Term _h_520 = STK(14);
    Term _h_521 = STK(15);
    Term _h_522 = STK(16);
    u32 _h_523 = STK(17);
    u32 _h_524 = STK(18);
    u32 _h_525 = STK(19);
    Term _h_505 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_506;
      STK(1) = _h_507;
      STK(2) = _h_508;
      STK(3) = _h_509;
      STK(4) = _h_510;
      STK(5) = _h_511;
      STK(6) = _h_512;
      STK(7) = _h_513;
      STK(8) = _h_514;
      STK(9) = _h_515;
      STK(10) = _h_516;
      STK(11) = _h_517;
      STK(12) = _h_518;
      STK(13) = _h_519;
      STK(14) = _h_520;
      STK(15) = _h_521;
      STK(16) = _h_522;
      STK(17) = _h_523;
      STK(18) = _h_524;
      STK(19) = _h_525;
      STK(20) = FID_CREATED_K624;
      WL_PUSHN(21);
    } else {
      u64 _t_38 = task_node(e, FID_CREATED_K624, WL_CONT, WL_IDX, 1);
      e.mem[_t_38 + 0] = _h_506;
      e.mem[_t_38 + 1] = _h_507;
      e.mem[_t_38 + 2] = _h_508;
      e.mem[_t_38 + 3] = _h_509;
      e.mem[_t_38 + 4] = _h_510;
      e.mem[_t_38 + 5] = _h_511;
      e.mem[_t_38 + 6] = _h_512;
      e.mem[_t_38 + 7] = _h_513;
      e.mem[_t_38 + 8] = _h_514;
      e.mem[_t_38 + 9] = _h_515;
      e.mem[_t_38 + 10] = _h_516;
      e.mem[_t_38 + 11] = _h_517;
      e.mem[_t_38 + 12] = _h_518;
      e.mem[_t_38 + 13] = _h_519;
      e.mem[_t_38 + 14] = _h_520;
      e.mem[_t_38 + 15] = _h_521;
      e.mem[_t_38 + 16] = _h_522;
      e.mem[_t_38 + 17] = _h_523;
      e.mem[_t_38 + 18] = _h_524;
      e.mem[_t_38 + 19] = _h_525;
      WL_CONT = term_tsk(FID_CREATED_K624, _t_38);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_39 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = term_ctr(CID_SCON, STAT_OFF + 490);
      e.mem[_t_39 + 1] = _h_505;
      return term_tsk(FID_STRING_APPEND, _t_39);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 490);
    r1 = _h_505;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K624)
  {
    WL_POPN(20);
    Term _h_527 = STK(0);
    Term _h_528 = STK(1);
    Term _h_529 = STK(2);
    Term _h_530 = STK(3);
    Term _h_531 = STK(4);
    Term _h_532 = STK(5);
    u32 _h_533 = STK(6);
    Term _h_534 = STK(7);
    u32 _h_535 = STK(8);
    u32 _h_536 = STK(9);
    u32 _h_537 = STK(10);
    Term _h_538 = STK(11);
    u32 _h_539 = STK(12);
    Term _h_540 = STK(13);
    Term _h_541 = STK(14);
    Term _h_542 = STK(15);
    Term _h_543 = STK(16);
    u32 _h_544 = STK(17);
    u32 _h_545 = STK(18);
    u32 _h_546 = STK(19);
    Term _h_526 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_527;
      STK(1) = _h_528;
      STK(2) = _h_529;
      STK(3) = _h_530;
      STK(4) = _h_531;
      STK(5) = _h_532;
      STK(6) = _h_533;
      STK(7) = _h_535;
      STK(8) = _h_536;
      STK(9) = _h_537;
      STK(10) = _h_538;
      STK(11) = _h_539;
      STK(12) = _h_540;
      STK(13) = _h_541;
      STK(14) = _h_542;
      STK(15) = _h_543;
      STK(16) = _h_544;
      STK(17) = _h_545;
      STK(18) = _h_546;
      STK(19) = FID_CREATED_K625;
      WL_PUSHN(20);
    } else {
      u64 _t_40 = task_node(e, FID_CREATED_K625, WL_CONT, WL_IDX, 1);
      e.mem[_t_40 + 0] = _h_527;
      e.mem[_t_40 + 1] = _h_528;
      e.mem[_t_40 + 2] = _h_529;
      e.mem[_t_40 + 3] = _h_530;
      e.mem[_t_40 + 4] = _h_531;
      e.mem[_t_40 + 5] = _h_532;
      e.mem[_t_40 + 6] = _h_533;
      e.mem[_t_40 + 7] = _h_535;
      e.mem[_t_40 + 8] = _h_536;
      e.mem[_t_40 + 9] = _h_537;
      e.mem[_t_40 + 10] = _h_538;
      e.mem[_t_40 + 11] = _h_539;
      e.mem[_t_40 + 12] = _h_540;
      e.mem[_t_40 + 13] = _h_541;
      e.mem[_t_40 + 14] = _h_542;
      e.mem[_t_40 + 15] = _h_543;
      e.mem[_t_40 + 16] = _h_544;
      e.mem[_t_40 + 17] = _h_545;
      e.mem[_t_40 + 18] = _h_546;
      WL_CONT = term_tsk(FID_CREATED_K625, _t_40);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_41 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = _h_534;
      e.mem[_t_41 + 1] = _h_526;
      return term_tsk(FID_STRING_APPEND, _t_41);
    }
    r0 = _h_534;
    r1 = _h_526;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K625)
  {
    WL_POPN(19);
    Term _h_548 = STK(0);
    Term _h_549 = STK(1);
    Term _h_550 = STK(2);
    Term _h_551 = STK(3);
    Term _h_552 = STK(4);
    Term _h_553 = STK(5);
    u32 _h_554 = STK(6);
    u32 _h_555 = STK(7);
    u32 _h_556 = STK(8);
    u32 _h_557 = STK(9);
    Term _h_558 = STK(10);
    u32 _h_559 = STK(11);
    Term _h_560 = STK(12);
    Term _h_561 = STK(13);
    Term _h_562 = STK(14);
    Term _h_563 = STK(15);
    u32 _h_564 = STK(16);
    u32 _h_565 = STK(17);
    u32 _h_566 = STK(18);
    Term _h_547 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_566;
      STK(1) = _h_548;
      STK(2) = _h_549;
      STK(3) = _h_550;
      STK(4) = _h_551;
      STK(5) = _h_552;
      STK(6) = _h_553;
      STK(7) = _h_554;
      STK(8) = _h_547;
      STK(9) = FID_CREATED_K626;
      WL_PUSHN(10);
    } else {
      u64 _t_42 = task_node(e, FID_CREATED_K626, WL_CONT, WL_IDX, 1);
      e.mem[_t_42 + 0] = _h_566;
      e.mem[_t_42 + 1] = _h_548;
      e.mem[_t_42 + 2] = _h_549;
      e.mem[_t_42 + 3] = _h_550;
      e.mem[_t_42 + 4] = _h_551;
      e.mem[_t_42 + 5] = _h_552;
      e.mem[_t_42 + 6] = _h_553;
      e.mem[_t_42 + 7] = _h_554;
      e.mem[_t_42 + 8] = _h_547;
      WL_CONT = term_tsk(FID_CREATED_K626, _t_42);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0)) {
      u64 _t_43 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _h_555;
      e.mem[_t_43 + 1] = _h_556;
      e.mem[_t_43 + 2] = _h_557;
      e.mem[_t_43 + 3] = _h_558;
      e.mem[_t_43 + 4] = _h_559;
      e.mem[_t_43 + 5] = _h_560;
      e.mem[_t_43 + 6] = _h_561;
      e.mem[_t_43 + 7] = _h_562;
      e.mem[_t_43 + 8] = _h_563;
      e.mem[_t_43 + 9] = _h_564;
      e.mem[_t_43 + 10] = _h_565;
      e.mem[_t_43 + 11] = 2ull;
      e.mem[_t_43 + 12] = term_ctr(CID_SCON, STAT_OFF + 372);
      e.mem[_t_43 + 13] = term_ctr(CID_CON, STAT_OFF + 386);
      return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0, _t_43);
    }
    r0 = _h_555;
    r1 = _h_556;
    r2 = _h_557;
    r3 = _h_558;
    r4 = _h_559;
    r5 = _h_560;
    r6 = _h_561;
    r7 = _h_562;
    r8 = _h_563;
    r9 = _h_564;
    r10 = _h_565;
    r11 = 2ull;
    r12 = term_ctr(CID_SCON, STAT_OFF + 372);
    r13 = term_ctr(CID_CON, STAT_OFF + 386);
    WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_MATCHES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K626)
  {
    WL_POPN(9);
    u32 _h_579 = STK(0);
    Term _h_580 = STK(1);
    Term _h_581 = STK(2);
    Term _h_582 = STK(3);
    Term _h_583 = STK(4);
    Term _h_584 = STK(5);
    Term _h_585 = STK(6);
    u32 _h_586 = STK(7);
    Term _h_587 = STK(8);
    u32 _h_567 = r0;
    u32 _h_568 = r1;
    u32 _h_569 = r2;
    Term _h_570 = r3;
    u32 _h_571 = r4;
    Term _h_572 = r5;
    Term _h_573 = r6;
    Term _h_574 = r7;
    Term _h_575 = r8;
    u32 _h_576 = r9;
    u32 _h_577 = r10;
    u32 _h_578 = r11;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_567;
      STK(1) = _h_568;
      STK(2) = _h_569;
      STK(3) = _h_570;
      STK(4) = _h_571;
      STK(5) = _h_572;
      STK(6) = _h_573;
      STK(7) = _h_574;
      STK(8) = _h_575;
      STK(9) = _h_576;
      STK(10) = _h_577;
      STK(11) = _h_578;
      STK(12) = _h_580;
      STK(13) = _h_581;
      STK(14) = _h_582;
      STK(15) = _h_583;
      STK(16) = _h_584;
      STK(17) = _h_585;
      STK(18) = _h_586;
      STK(19) = _h_587;
      STK(20) = _h_579;
      STK(21) = FID_CREATED_K627;
      WL_PUSHN(22);
    } else {
      u64 _t_44 = task_node(e, FID_CREATED_K627, WL_CONT, WL_IDX, 1);
      e.mem[_t_44 + 0] = _h_567;
      e.mem[_t_44 + 1] = _h_568;
      e.mem[_t_44 + 2] = _h_569;
      e.mem[_t_44 + 3] = _h_570;
      e.mem[_t_44 + 4] = _h_571;
      e.mem[_t_44 + 5] = _h_572;
      e.mem[_t_44 + 6] = _h_573;
      e.mem[_t_44 + 7] = _h_574;
      e.mem[_t_44 + 8] = _h_575;
      e.mem[_t_44 + 9] = _h_576;
      e.mem[_t_44 + 10] = _h_577;
      e.mem[_t_44 + 11] = _h_578;
      e.mem[_t_44 + 12] = _h_580;
      e.mem[_t_44 + 13] = _h_581;
      e.mem[_t_44 + 14] = _h_582;
      e.mem[_t_44 + 15] = _h_583;
      e.mem[_t_44 + 16] = _h_584;
      e.mem[_t_44 + 17] = _h_585;
      e.mem[_t_44 + 18] = _h_586;
      e.mem[_t_44 + 19] = _h_587;
      e.mem[_t_44 + 20] = _h_579;
      WL_CONT = term_tsk(FID_CREATED_K627, _t_44);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_45 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _h_586;
      return term_tsk(FID_U32_SHOW, _t_45);
    }
    r0 = _h_586;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K627)
  {
    WL_POPN(21);
    u32 _h_589 = STK(0);
    u32 _h_590 = STK(1);
    u32 _h_591 = STK(2);
    Term _h_592 = STK(3);
    u32 _h_593 = STK(4);
    Term _h_594 = STK(5);
    Term _h_595 = STK(6);
    Term _h_596 = STK(7);
    Term _h_597 = STK(8);
    u32 _h_598 = STK(9);
    u32 _h_599 = STK(10);
    u32 _h_600 = STK(11);
    Term _h_601 = STK(12);
    Term _h_602 = STK(13);
    Term _h_603 = STK(14);
    Term _h_604 = STK(15);
    Term _h_605 = STK(16);
    Term _h_606 = STK(17);
    u32 _h_607 = STK(18);
    Term _h_608 = STK(19);
    u32 _h_609 = STK(20);
    Term _h_588 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(22);
      STK(0) = _h_589;
      STK(1) = _h_590;
      STK(2) = _h_591;
      STK(3) = _h_592;
      STK(4) = _h_593;
      STK(5) = _h_594;
      STK(6) = _h_595;
      STK(7) = _h_596;
      STK(8) = _h_597;
      STK(9) = _h_598;
      STK(10) = _h_599;
      STK(11) = _h_600;
      STK(12) = _h_601;
      STK(13) = _h_602;
      STK(14) = _h_603;
      STK(15) = _h_604;
      STK(16) = _h_605;
      STK(17) = _h_606;
      STK(18) = _h_607;
      STK(19) = _h_608;
      STK(20) = _h_609;
      STK(21) = FID_CREATED_K628;
      WL_PUSHN(22);
    } else {
      u64 _t_46 = task_node(e, FID_CREATED_K628, WL_CONT, WL_IDX, 1);
      e.mem[_t_46 + 0] = _h_589;
      e.mem[_t_46 + 1] = _h_590;
      e.mem[_t_46 + 2] = _h_591;
      e.mem[_t_46 + 3] = _h_592;
      e.mem[_t_46 + 4] = _h_593;
      e.mem[_t_46 + 5] = _h_594;
      e.mem[_t_46 + 6] = _h_595;
      e.mem[_t_46 + 7] = _h_596;
      e.mem[_t_46 + 8] = _h_597;
      e.mem[_t_46 + 9] = _h_598;
      e.mem[_t_46 + 10] = _h_599;
      e.mem[_t_46 + 11] = _h_600;
      e.mem[_t_46 + 12] = _h_601;
      e.mem[_t_46 + 13] = _h_602;
      e.mem[_t_46 + 14] = _h_603;
      e.mem[_t_46 + 15] = _h_604;
      e.mem[_t_46 + 16] = _h_605;
      e.mem[_t_46 + 17] = _h_606;
      e.mem[_t_46 + 18] = _h_607;
      e.mem[_t_46 + 19] = _h_608;
      e.mem[_t_46 + 20] = _h_609;
      WL_CONT = term_tsk(FID_CREATED_K628, _t_46);
      WL_IDX = 21;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_47 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = term_ctr(CID_SCON, STAT_OFF + 216);
      e.mem[_t_47 + 1] = _h_588;
      return term_tsk(FID_STRING_APPEND, _t_47);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 216);
    r1 = _h_588;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K628)
  {
    WL_POPN(21);
    u32 _h_611 = STK(0);
    u32 _h_612 = STK(1);
    u32 _h_613 = STK(2);
    Term _h_614 = STK(3);
    u32 _h_615 = STK(4);
    Term _h_616 = STK(5);
    Term _h_617 = STK(6);
    Term _h_618 = STK(7);
    Term _h_619 = STK(8);
    u32 _h_620 = STK(9);
    u32 _h_621 = STK(10);
    u32 _h_622 = STK(11);
    Term _h_623 = STK(12);
    Term _h_624 = STK(13);
    Term _h_625 = STK(14);
    Term _h_626 = STK(15);
    Term _h_627 = STK(16);
    Term _h_628 = STK(17);
    u32 _h_629 = STK(18);
    Term _h_630 = STK(19);
    u32 _h_631 = STK(20);
    Term _h_610 = r0;
    WL_OPEN
    Term _v_328 = 0;
    Term _v_329 = 0;
    Term _o_9[1];
    if (spin_44(e, _o_9, _h_622) == 0) {
      return 0;
    }
    _v_329 = _o_9[0];
    _v_328 = _v_329;
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_611;
      STK(1) = _h_612;
      STK(2) = _h_613;
      STK(3) = _h_614;
      STK(4) = _h_615;
      STK(5) = _h_616;
      STK(6) = _h_617;
      STK(7) = _h_618;
      STK(8) = _h_619;
      STK(9) = _h_620;
      STK(10) = _h_621;
      STK(11) = _h_623;
      STK(12) = _h_624;
      STK(13) = _h_625;
      STK(14) = _h_626;
      STK(15) = _h_627;
      STK(16) = _h_628;
      STK(17) = _h_629;
      STK(18) = _h_630;
      STK(19) = _h_631;
      STK(20) = FID_CREATED_K629;
      WL_PUSHN(21);
    } else {
      u64 _t_48 = task_node(e, FID_CREATED_K629, WL_CONT, WL_IDX, 1);
      e.mem[_t_48 + 0] = _h_611;
      e.mem[_t_48 + 1] = _h_612;
      e.mem[_t_48 + 2] = _h_613;
      e.mem[_t_48 + 3] = _h_614;
      e.mem[_t_48 + 4] = _h_615;
      e.mem[_t_48 + 5] = _h_616;
      e.mem[_t_48 + 6] = _h_617;
      e.mem[_t_48 + 7] = _h_618;
      e.mem[_t_48 + 8] = _h_619;
      e.mem[_t_48 + 9] = _h_620;
      e.mem[_t_48 + 10] = _h_621;
      e.mem[_t_48 + 11] = _h_623;
      e.mem[_t_48 + 12] = _h_624;
      e.mem[_t_48 + 13] = _h_625;
      e.mem[_t_48 + 14] = _h_626;
      e.mem[_t_48 + 15] = _h_627;
      e.mem[_t_48 + 16] = _h_628;
      e.mem[_t_48 + 17] = _h_629;
      e.mem[_t_48 + 18] = _h_630;
      e.mem[_t_48 + 19] = _h_631;
      WL_CONT = term_tsk(FID_CREATED_K629, _t_48);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_49 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_49 + 0] = _v_328;
      e.mem[_t_49 + 1] = _h_610;
      return term_tsk(FID_STRING_APPEND, _t_49);
    }
    r0 = _v_328;
    r1 = _h_610;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K629)
  {
    WL_POPN(20);
    u32 _h_633 = STK(0);
    u32 _h_634 = STK(1);
    u32 _h_635 = STK(2);
    Term _h_636 = STK(3);
    u32 _h_637 = STK(4);
    Term _h_638 = STK(5);
    Term _h_639 = STK(6);
    Term _h_640 = STK(7);
    Term _h_641 = STK(8);
    u32 _h_642 = STK(9);
    u32 _h_643 = STK(10);
    Term _h_644 = STK(11);
    Term _h_645 = STK(12);
    Term _h_646 = STK(13);
    Term _h_647 = STK(14);
    Term _h_648 = STK(15);
    Term _h_649 = STK(16);
    u32 _h_650 = STK(17);
    Term _h_651 = STK(18);
    u32 _h_652 = STK(19);
    Term _h_632 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(21);
      STK(0) = _h_633;
      STK(1) = _h_634;
      STK(2) = _h_635;
      STK(3) = _h_636;
      STK(4) = _h_637;
      STK(5) = _h_638;
      STK(6) = _h_639;
      STK(7) = _h_640;
      STK(8) = _h_641;
      STK(9) = _h_642;
      STK(10) = _h_643;
      STK(11) = _h_644;
      STK(12) = _h_645;
      STK(13) = _h_646;
      STK(14) = _h_647;
      STK(15) = _h_648;
      STK(16) = _h_649;
      STK(17) = _h_650;
      STK(18) = _h_651;
      STK(19) = _h_652;
      STK(20) = FID_CREATED_K630;
      WL_PUSHN(21);
    } else {
      u64 _t_50 = task_node(e, FID_CREATED_K630, WL_CONT, WL_IDX, 1);
      e.mem[_t_50 + 0] = _h_633;
      e.mem[_t_50 + 1] = _h_634;
      e.mem[_t_50 + 2] = _h_635;
      e.mem[_t_50 + 3] = _h_636;
      e.mem[_t_50 + 4] = _h_637;
      e.mem[_t_50 + 5] = _h_638;
      e.mem[_t_50 + 6] = _h_639;
      e.mem[_t_50 + 7] = _h_640;
      e.mem[_t_50 + 8] = _h_641;
      e.mem[_t_50 + 9] = _h_642;
      e.mem[_t_50 + 10] = _h_643;
      e.mem[_t_50 + 11] = _h_644;
      e.mem[_t_50 + 12] = _h_645;
      e.mem[_t_50 + 13] = _h_646;
      e.mem[_t_50 + 14] = _h_647;
      e.mem[_t_50 + 15] = _h_648;
      e.mem[_t_50 + 16] = _h_649;
      e.mem[_t_50 + 17] = _h_650;
      e.mem[_t_50 + 18] = _h_651;
      e.mem[_t_50 + 19] = _h_652;
      WL_CONT = term_tsk(FID_CREATED_K630, _t_50);
      WL_IDX = 20;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_51 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_51 + 0] = term_ctr(CID_SCON, STAT_OFF + 248);
      e.mem[_t_51 + 1] = _h_632;
      return term_tsk(FID_STRING_APPEND, _t_51);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 248);
    r1 = _h_632;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K630)
  {
    WL_POPN(20);
    u32 _h_654 = STK(0);
    u32 _h_655 = STK(1);
    u32 _h_656 = STK(2);
    Term _h_657 = STK(3);
    u32 _h_658 = STK(4);
    Term _h_659 = STK(5);
    Term _h_660 = STK(6);
    Term _h_661 = STK(7);
    Term _h_662 = STK(8);
    u32 _h_663 = STK(9);
    u32 _h_664 = STK(10);
    Term _h_665 = STK(11);
    Term _h_666 = STK(12);
    Term _h_667 = STK(13);
    Term _h_668 = STK(14);
    Term _h_669 = STK(15);
    Term _h_670 = STK(16);
    u32 _h_671 = STK(17);
    Term _h_672 = STK(18);
    u32 _h_673 = STK(19);
    Term _h_653 = r0;
    WL_OPEN
    Term _v_330 = 0;
    Term _v_331 = 0;
    Term _o_10[1];
    if (spin_44(e, _o_10, _h_673) == 0) {
      return 0;
    }
    _v_331 = _o_10[0];
    _v_330 = _v_331;
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_654;
      STK(1) = _h_655;
      STK(2) = _h_656;
      STK(3) = _h_657;
      STK(4) = _h_658;
      STK(5) = _h_659;
      STK(6) = _h_660;
      STK(7) = _h_661;
      STK(8) = _h_662;
      STK(9) = _h_663;
      STK(10) = _h_664;
      STK(11) = _h_665;
      STK(12) = _h_666;
      STK(13) = _h_667;
      STK(14) = _h_668;
      STK(15) = _h_669;
      STK(16) = _h_670;
      STK(17) = _h_671;
      STK(18) = _h_672;
      STK(19) = FID_CREATED_K631;
      WL_PUSHN(20);
    } else {
      u64 _t_52 = task_node(e, FID_CREATED_K631, WL_CONT, WL_IDX, 1);
      e.mem[_t_52 + 0] = _h_654;
      e.mem[_t_52 + 1] = _h_655;
      e.mem[_t_52 + 2] = _h_656;
      e.mem[_t_52 + 3] = _h_657;
      e.mem[_t_52 + 4] = _h_658;
      e.mem[_t_52 + 5] = _h_659;
      e.mem[_t_52 + 6] = _h_660;
      e.mem[_t_52 + 7] = _h_661;
      e.mem[_t_52 + 8] = _h_662;
      e.mem[_t_52 + 9] = _h_663;
      e.mem[_t_52 + 10] = _h_664;
      e.mem[_t_52 + 11] = _h_665;
      e.mem[_t_52 + 12] = _h_666;
      e.mem[_t_52 + 13] = _h_667;
      e.mem[_t_52 + 14] = _h_668;
      e.mem[_t_52 + 15] = _h_669;
      e.mem[_t_52 + 16] = _h_670;
      e.mem[_t_52 + 17] = _h_671;
      e.mem[_t_52 + 18] = _h_672;
      WL_CONT = term_tsk(FID_CREATED_K631, _t_52);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_53 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_53 + 0] = _v_330;
      e.mem[_t_53 + 1] = _h_653;
      return term_tsk(FID_STRING_APPEND, _t_53);
    }
    r0 = _v_330;
    r1 = _h_653;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K631)
  {
    WL_POPN(19);
    u32 _h_675 = STK(0);
    u32 _h_676 = STK(1);
    u32 _h_677 = STK(2);
    Term _h_678 = STK(3);
    u32 _h_679 = STK(4);
    Term _h_680 = STK(5);
    Term _h_681 = STK(6);
    Term _h_682 = STK(7);
    Term _h_683 = STK(8);
    u32 _h_684 = STK(9);
    u32 _h_685 = STK(10);
    Term _h_686 = STK(11);
    Term _h_687 = STK(12);
    Term _h_688 = STK(13);
    Term _h_689 = STK(14);
    Term _h_690 = STK(15);
    Term _h_691 = STK(16);
    u32 _h_692 = STK(17);
    Term _h_693 = STK(18);
    Term _h_674 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(20);
      STK(0) = _h_675;
      STK(1) = _h_676;
      STK(2) = _h_677;
      STK(3) = _h_678;
      STK(4) = _h_679;
      STK(5) = _h_680;
      STK(6) = _h_681;
      STK(7) = _h_682;
      STK(8) = _h_683;
      STK(9) = _h_684;
      STK(10) = _h_685;
      STK(11) = _h_686;
      STK(12) = _h_687;
      STK(13) = _h_688;
      STK(14) = _h_689;
      STK(15) = _h_690;
      STK(16) = _h_691;
      STK(17) = _h_692;
      STK(18) = _h_693;
      STK(19) = FID_CREATED_K632;
      WL_PUSHN(20);
    } else {
      u64 _t_54 = task_node(e, FID_CREATED_K632, WL_CONT, WL_IDX, 1);
      e.mem[_t_54 + 0] = _h_675;
      e.mem[_t_54 + 1] = _h_676;
      e.mem[_t_54 + 2] = _h_677;
      e.mem[_t_54 + 3] = _h_678;
      e.mem[_t_54 + 4] = _h_679;
      e.mem[_t_54 + 5] = _h_680;
      e.mem[_t_54 + 6] = _h_681;
      e.mem[_t_54 + 7] = _h_682;
      e.mem[_t_54 + 8] = _h_683;
      e.mem[_t_54 + 9] = _h_684;
      e.mem[_t_54 + 10] = _h_685;
      e.mem[_t_54 + 11] = _h_686;
      e.mem[_t_54 + 12] = _h_687;
      e.mem[_t_54 + 13] = _h_688;
      e.mem[_t_54 + 14] = _h_689;
      e.mem[_t_54 + 15] = _h_690;
      e.mem[_t_54 + 16] = _h_691;
      e.mem[_t_54 + 17] = _h_692;
      e.mem[_t_54 + 18] = _h_693;
      WL_CONT = term_tsk(FID_CREATED_K632, _t_54);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_55 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_55 + 0] = term_ctr(CID_SCON, STAT_OFF + 270);
      e.mem[_t_55 + 1] = _h_674;
      return term_tsk(FID_STRING_APPEND, _t_55);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 270);
    r1 = _h_674;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K632)
  {
    WL_POPN(19);
    u32 _h_695 = STK(0);
    u32 _h_696 = STK(1);
    u32 _h_697 = STK(2);
    Term _h_698 = STK(3);
    u32 _h_699 = STK(4);
    Term _h_700 = STK(5);
    Term _h_701 = STK(6);
    Term _h_702 = STK(7);
    Term _h_703 = STK(8);
    u32 _h_704 = STK(9);
    u32 _h_705 = STK(10);
    Term _h_706 = STK(11);
    Term _h_707 = STK(12);
    Term _h_708 = STK(13);
    Term _h_709 = STK(14);
    Term _h_710 = STK(15);
    Term _h_711 = STK(16);
    u32 _h_712 = STK(17);
    Term _h_713 = STK(18);
    Term _h_694 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(19);
      STK(0) = _h_695;
      STK(1) = _h_696;
      STK(2) = _h_697;
      STK(3) = _h_698;
      STK(4) = _h_699;
      STK(5) = _h_700;
      STK(6) = _h_701;
      STK(7) = _h_702;
      STK(8) = _h_703;
      STK(9) = _h_704;
      STK(10) = _h_705;
      STK(11) = _h_706;
      STK(12) = _h_707;
      STK(13) = _h_708;
      STK(14) = _h_709;
      STK(15) = _h_710;
      STK(16) = _h_711;
      STK(17) = _h_712;
      STK(18) = FID_CREATED_K633;
      WL_PUSHN(19);
    } else {
      u64 _t_56 = task_node(e, FID_CREATED_K633, WL_CONT, WL_IDX, 1);
      e.mem[_t_56 + 0] = _h_695;
      e.mem[_t_56 + 1] = _h_696;
      e.mem[_t_56 + 2] = _h_697;
      e.mem[_t_56 + 3] = _h_698;
      e.mem[_t_56 + 4] = _h_699;
      e.mem[_t_56 + 5] = _h_700;
      e.mem[_t_56 + 6] = _h_701;
      e.mem[_t_56 + 7] = _h_702;
      e.mem[_t_56 + 8] = _h_703;
      e.mem[_t_56 + 9] = _h_704;
      e.mem[_t_56 + 10] = _h_705;
      e.mem[_t_56 + 11] = _h_706;
      e.mem[_t_56 + 12] = _h_707;
      e.mem[_t_56 + 13] = _h_708;
      e.mem[_t_56 + 14] = _h_709;
      e.mem[_t_56 + 15] = _h_710;
      e.mem[_t_56 + 16] = _h_711;
      e.mem[_t_56 + 17] = _h_712;
      WL_CONT = term_tsk(FID_CREATED_K633, _t_56);
      WL_IDX = 18;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_57 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_57 + 0] = _h_713;
      e.mem[_t_57 + 1] = _h_694;
      return term_tsk(FID_STRING_APPEND, _t_57);
    }
    r0 = _h_713;
    r1 = _h_694;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K633)
  {
    WL_POPN(18);
    u32 _h_715 = STK(0);
    u32 _h_716 = STK(1);
    u32 _h_717 = STK(2);
    Term _h_718 = STK(3);
    u32 _h_719 = STK(4);
    Term _h_720 = STK(5);
    Term _h_721 = STK(6);
    Term _h_722 = STK(7);
    Term _h_723 = STK(8);
    u32 _h_724 = STK(9);
    u32 _h_725 = STK(10);
    Term _h_726 = STK(11);
    Term _h_727 = STK(12);
    Term _h_728 = STK(13);
    Term _h_729 = STK(14);
    Term _h_730 = STK(15);
    Term _h_731 = STK(16);
    u32 _h_732 = STK(17);
    Term _h_714 = r0;
    WL_OPEN
    u32 _v_332 = 0;
    u32 _v_333 = 0;
    u32 _v_334 = 0;
    Term _v_335 = 0;
    u32 _v_336 = 0;
    Term _v_337 = 0;
    Term _v_338 = 0;
    Term _v_339 = 0;
    Term _v_340 = 0;
    u32 _v_341 = 0;
    u32 _v_342 = 0;
    Term _v_343 = 0;
    Term _v_344 = 0;
    Term _v_345 = 0;
    Term _v_346 = 0;
    Term _v_347 = 0;
    Term _v_348 = 0;
    u32 _v_349 = 0;
    u32 _v_350 = 0;
    u32 _v_351 = 0;
    u32 _v_352 = 0;
    u32 _v_353 = 0;
    u32 _v_354 = 0;
    Term _v_355 = 0;
    u32 _v_356 = 0;
    Term _v_357 = 0;
    Term _v_358 = 0;
    Term _v_359 = 0;
    Term _v_360 = 0;
    u32 _v_361 = 0;
    u32 _v_362 = 0;
    Term _v_363 = 0;
    Term _v_364 = 0;
    Term _v_365 = 0;
    Term _v_366 = 0;
    Term _v_367 = 0;
    Term _v_368 = 0;
    u32 _v_369 = 0;
    u32 _v_370 = 0;
    u32 _v_371 = 0;
    Term _o_11[20];
    if (spin_31(e, _o_11, _h_715, _h_716, _h_717, _h_718, blk_loc(e.mem, _h_718), _h_719, _h_720, _h_721, blk_loc(e.mem, _h_721), _h_722, blk_loc(e.mem, _h_722), _h_723, blk_loc(e.mem, _h_723), _h_724, _h_725, _h_726, blk_loc(e.mem, _h_726), _h_727, blk_loc(e.mem, _h_727), _h_728, _h_729, _h_730, _h_731, 4294967294ull) == 0) {
      return 0;
    }
    _v_352 = _o_11[0];
    _v_353 = _o_11[1];
    _v_354 = _o_11[2];
    _v_355 = _o_11[3];
    _v_356 = _o_11[4];
    _v_357 = _o_11[5];
    _v_358 = _o_11[6];
    _v_359 = _o_11[7];
    _v_360 = _o_11[8];
    _v_361 = _o_11[9];
    _v_362 = _o_11[10];
    _v_363 = _o_11[11];
    _v_364 = _o_11[12];
    _v_365 = _o_11[13];
    _v_366 = _o_11[14];
    _v_367 = _o_11[15];
    _v_368 = _o_11[16];
    _v_369 = _o_11[17];
    _v_370 = _o_11[18];
    _v_371 = _o_11[19];
    _v_332 = _v_352;
    _v_333 = _v_353;
    _v_334 = _v_354;
    _v_335 = _v_355;
    _v_336 = _v_356;
    _v_337 = _v_357;
    _v_338 = _v_358;
    _v_339 = _v_359;
    _v_340 = _v_360;
    _v_341 = _v_361;
    _v_342 = _v_362;
    _v_343 = _v_363;
    _v_344 = _v_364;
    _v_345 = _v_365;
    _v_346 = _v_366;
    _v_347 = _v_367;
    _v_348 = _v_368;
    _v_349 = _v_369;
    _v_350 = _v_370;
    _v_351 = _v_371;
    if (_v_350 == 1) {
      u32 _v_372 = 0;
      u32 _v_373 = 0;
      u32 _v_374 = 0;
      Term _v_375 = 0;
      u32 _v_376 = 0;
      Term _v_377 = 0;
      Term _v_378 = 0;
      Term _v_379 = 0;
      Term _v_380 = 0;
      u32 _v_381 = 0;
      u32 _v_382 = 0;
      Term _v_383 = 0;
      Term _v_384 = 0;
      Term _v_385 = 0;
      Term _v_386 = 0;
      Term _v_387 = 0;
      Term _v_388 = 0;
      u32 _v_389 = 0;
      u32 _v_390 = 0;
      u32 _v_391 = 0;
      u32 _v_392 = 0;
      u32 _v_393 = 0;
      u32 _v_394 = 0;
      Term _v_395 = 0;
      u32 _v_396 = 0;
      Term _v_397 = 0;
      Term _v_398 = 0;
      Term _v_399 = 0;
      Term _v_400 = 0;
      u32 _v_401 = 0;
      u32 _v_402 = 0;
      Term _v_403 = 0;
      Term _v_404 = 0;
      Term _v_405 = 0;
      Term _v_406 = 0;
      Term _v_407 = 0;
      Term _v_408 = 0;
      u32 _v_409 = 0;
      u32 _v_410 = 0;
      u32 _v_411 = 0;
      Term _o_12[20];
      if (spin_31(e, _o_12, _v_332, _v_333, _v_334, _v_335, blk_loc(e.mem, _v_335), _v_336, _v_337, _v_338, blk_loc(e.mem, _v_338), _v_339, blk_loc(e.mem, _v_339), _v_340, blk_loc(e.mem, _v_340), _v_341, _v_342, _v_343, blk_loc(e.mem, _v_343), _v_344, blk_loc(e.mem, _v_344), _v_345, _v_346, _v_347, _v_348, _v_349) == 0) {
        return 0;
      }
      _v_392 = _o_12[0];
      _v_393 = _o_12[1];
      _v_394 = _o_12[2];
      _v_395 = _o_12[3];
      _v_396 = _o_12[4];
      _v_397 = _o_12[5];
      _v_398 = _o_12[6];
      _v_399 = _o_12[7];
      _v_400 = _o_12[8];
      _v_401 = _o_12[9];
      _v_402 = _o_12[10];
      _v_403 = _o_12[11];
      _v_404 = _o_12[12];
      _v_405 = _o_12[13];
      _v_406 = _o_12[14];
      _v_407 = _o_12[15];
      _v_408 = _o_12[16];
      _v_409 = _o_12[17];
      _v_410 = _o_12[18];
      _v_411 = _o_12[19];
      _v_372 = _v_392;
      _v_373 = _v_393;
      _v_374 = _v_394;
      _v_375 = _v_395;
      _v_376 = _v_396;
      _v_377 = _v_397;
      _v_378 = _v_398;
      _v_379 = _v_399;
      _v_380 = _v_400;
      _v_381 = _v_401;
      _v_382 = _v_402;
      _v_383 = _v_403;
      _v_384 = _v_404;
      _v_385 = _v_405;
      _v_386 = _v_406;
      _v_387 = _v_407;
      _v_388 = _v_408;
      _v_389 = _v_409;
      _v_390 = _v_410;
      _v_391 = _v_411;
      term_sink(e, _v_375);
      term_sink(e, _v_378);
      term_sink(e, _v_379);
      term_sink(e, _v_380);
      term_sink(e, _v_383);
      term_sink(e, _v_384);
      if (_v_390 == 0) {
        if (seq) {
          WL_ROOM(3);
          STK(0) = _v_389;
          STK(1) = _h_714;
          STK(2) = FID_CREATED_K634;
          WL_PUSHN(3);
        } else {
          u64 _t_58 = task_node(e, FID_CREATED_K634, WL_CONT, WL_IDX, 1);
          e.mem[_t_58 + 0] = _v_389;
          e.mem[_t_58 + 1] = _h_714;
          WL_CONT = term_tsk(FID_CREATED_K634, _t_58);
          WL_IDX = 2;
        }
        if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
          u64 _t_59 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
          e.mem[_t_59 + 0] = _v_351;
          return term_tsk(FID_U32_SHOW, _t_59);
        }
        r0 = _v_351;
        WL_JMP(FID_U32_SHOW);
      } else {
        term_sink(e, _h_714);
        r0 = term_ctr(CID_SCON, STAT_OFF + 90);
        WL_RETN(1);
      }
    } else {
      term_sink(e, _v_335);
      term_sink(e, _v_338);
      term_sink(e, _v_339);
      term_sink(e, _v_340);
      term_sink(e, _v_343);
      term_sink(e, _v_344);
      term_sink(e, _h_714);
      r0 = term_ctr(CID_SCON, STAT_OFF + 144);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K634)
  {
    WL_POPN(2);
    u32 _v_412 = STK(0);
    Term _h_734 = STK(1);
    Term _h_733 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_734;
      STK(1) = _h_733;
      STK(2) = FID_CREATED_K635;
      WL_PUSHN(3);
    } else {
      u64 _t_60 = task_node(e, FID_CREATED_K635, WL_CONT, WL_IDX, 1);
      e.mem[_t_60 + 0] = _h_734;
      e.mem[_t_60 + 1] = _h_733;
      WL_CONT = term_tsk(FID_CREATED_K635, _t_60);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_61 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_61 + 0] = _v_412;
      return term_tsk(FID_U32_SHOW, _t_61);
    }
    r0 = _v_412;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K635)
  {
    WL_POPN(2);
    Term _h_736 = STK(0);
    Term _h_737 = STK(1);
    Term _h_735 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_736;
      STK(1) = _h_737;
      STK(2) = FID_CREATED_K636;
      WL_PUSHN(3);
    } else {
      u64 _t_62 = task_node(e, FID_CREATED_K636, WL_CONT, WL_IDX, 1);
      e.mem[_t_62 + 0] = _h_736;
      e.mem[_t_62 + 1] = _h_737;
      WL_CONT = term_tsk(FID_CREATED_K636, _t_62);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_63 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_63 + 0] = _h_735;
      e.mem[_t_63 + 1] = term_ctr(CID_SCON, STAT_OFF + 0);
      return term_tsk(FID_STRING_APPEND, _t_63);
    }
    r0 = _h_735;
    r1 = term_ctr(CID_SCON, STAT_OFF + 0);
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K636)
  {
    WL_POPN(2);
    Term _h_739 = STK(0);
    Term _h_740 = STK(1);
    Term _h_738 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_739;
      STK(1) = _h_740;
      STK(2) = FID_CREATED_K637;
      WL_PUSHN(3);
    } else {
      u64 _t_64 = task_node(e, FID_CREATED_K637, WL_CONT, WL_IDX, 1);
      e.mem[_t_64 + 0] = _h_739;
      e.mem[_t_64 + 1] = _h_740;
      WL_CONT = term_tsk(FID_CREATED_K637, _t_64);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_65 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_65 + 0] = term_ctr(CID_SCON, STAT_OFF + 50);
      e.mem[_t_65 + 1] = _h_738;
      return term_tsk(FID_STRING_APPEND, _t_65);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 50);
    r1 = _h_738;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K637)
  {
    WL_POPN(2);
    Term _h_742 = STK(0);
    Term _h_743 = STK(1);
    Term _h_741 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_742;
      STK(1) = FID_CREATED_K638;
      WL_PUSHN(2);
    } else {
      u64 _t_66 = task_node(e, FID_CREATED_K638, WL_CONT, WL_IDX, 1);
      e.mem[_t_66 + 0] = _h_742;
      WL_CONT = term_tsk(FID_CREATED_K638, _t_66);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_67 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_67 + 0] = _h_743;
      e.mem[_t_67 + 1] = _h_741;
      return term_tsk(FID_STRING_APPEND, _t_67);
    }
    r0 = _h_743;
    r1 = _h_741;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K638)
  {
    WL_POPN(1);
    Term _h_745 = STK(0);
    Term _h_744 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_745;
      STK(1) = FID_CREATED_K639;
      WL_PUSHN(2);
    } else {
      u64 _t_68 = task_node(e, FID_CREATED_K639, WL_CONT, WL_IDX, 1);
      e.mem[_t_68 + 0] = _h_745;
      WL_CONT = term_tsk(FID_CREATED_K639, _t_68);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_69 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_69 + 0] = term_ctr(CID_SCON, STAT_OFF + 60);
      e.mem[_t_69 + 1] = _h_744;
      return term_tsk(FID_STRING_APPEND, _t_69);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 60);
    r1 = _h_744;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CREATED_K639)
  {
    WL_POPN(1);
    Term _h_747 = STK(0);
    Term _h_746 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_70 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_70 + 0] = _h_747;
      e.mem[_t_70 + 1] = _h_746;
      return term_tsk(FID_STRING_APPEND, _t_70);
    }
    r0 = _h_747;
    r1 = _h_746;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _o_0[13];
    if (spin_70(e, _o_0, U32_BIN(1ull, <, 4294967295ull), 1ull) == 0) {
      return 0;
    }
    _v_13 = _o_0[0];
    _v_14 = _o_0[1];
    _v_15 = _o_0[2];
    _v_16 = _o_0[3];
    _v_17 = _o_0[4];
    _v_18 = _o_0[5];
    _v_19 = _o_0[6];
    _v_20 = _o_0[7];
    _v_21 = _o_0[8];
    _v_22 = _o_0[9];
    _v_23 = _o_0[10];
    _v_24 = _o_0[11];
    _v_25 = _o_0[12];
    _v_0 = _v_13;
    _v_1 = _v_14;
    _v_2 = _v_15;
    _v_3 = _v_16;
    _v_4 = _v_17;
    _v_5 = _v_18;
    _v_6 = _v_19;
    _v_7 = _v_20;
    _v_8 = _v_21;
    _v_9 = _v_22;
    _v_10 = _v_23;
    _v_11 = _v_24;
    _v_12 = _v_25;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K641;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_MAIN_K641, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K641, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CREATED)) {
      u64 _t_1 = task_node(e, FID_CREATED, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      e.mem[_t_1 + 1] = _v_1;
      e.mem[_t_1 + 2] = _v_2;
      e.mem[_t_1 + 3] = _v_3;
      e.mem[_t_1 + 4] = _v_4;
      e.mem[_t_1 + 5] = _v_5;
      e.mem[_t_1 + 6] = _v_6;
      e.mem[_t_1 + 7] = _v_7;
      e.mem[_t_1 + 8] = _v_8;
      e.mem[_t_1 + 9] = _v_9;
      e.mem[_t_1 + 10] = _v_10;
      e.mem[_t_1 + 11] = _v_11;
      e.mem[_t_1 + 12] = _v_12;
      return term_tsk(FID_CREATED, _t_1);
    }
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    WL_JMP(FID_CREATED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K641)
  {
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_0;
    r0 = term_clo(FID_IO_PRINT, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_2 = r0;
    Term _k_2 = r1;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _text_2;
    e.mem[_nd_2 + 1] = _k_2;
    r0 = term_ctr(CID_IO_PRINT, _nd_2);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
