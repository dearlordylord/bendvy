function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return (_x_0) => $IO$print$(($created$(($$$$047$$$047$$$047src$047ecs$047world$058create$1260$(($$$$047$$$047$$$047src$047ecs$047world$058factory$()), {$: "Unit"})))), _x_0);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $created$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/world.CreateRejected") {
    return "unexpected-world-failure";
  } else {
    const _world_0 = _result_0["world"];
    return $unrelated_registered$(($$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, "unrelated", {$: "Nil"})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058create$1260$(_factory_0, _resource_0) {
  const _namespace_0 = _factory_0["nextNamespace"];
  return $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$((_namespace_0 < 4294967295), _namespace_0, _resource_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058factory$() {
  return {$: "../../../src/ecs/world.Factory", "nextNamespace": 1};
}

function $unrelated_registered$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationFailed") {
    return "unexpected-system-failure";
  } else {
    const _world_0 = _result_0["world"];
    return $first_reserved$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader$1260$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058start$1260$(_world_0)))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1261$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/world.CreateRejected", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../src/ecs/world.Created", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": 1, "highWater": 0, "live": array_new(0, false), "capacity": 1, "depth": 0, "store": ($empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $first_reserved$(_result_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _first_0 = _t_0["value"];
    return $second_reserved$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader$1260$(_runtime_0)), _first_0);
  } else {
    return "unexpected-reservation-failure";
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader$1260$(_runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader_checked$1260$((_nextReader_0 < 4294967295), {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0});
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058start$1260$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1260$(($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1261$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $empty$(__0) {
  return {$: "Unit"};
}

function $second_reserved$(_result_0, _first_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _second_0 = _t_0["value"];
    return $registered$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register$1260$(_runtime_0, {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/domains.DeclaredKey", "id": 1}, "tail": {$: "Nil"}}, "real", {$: "Con", "head": "Parent", "tail": {$: "Nil"}})), _first_0, _second_0);
  } else {
    return "unexpected-reservation-failure";
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader_checked$1260$(_available_0, _runtime_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _runtime_0, "snd": {$: "None"}};
  } else {
    const _world_0 = _runtime_0["world"];
    const _domains_0 = _runtime_0["domains"];
    const _positions_0 = _runtime_0["positions"];
    const _tick_0 = _runtime_0["tick"];
    const _frameStart_0 = _runtime_0["frameStart"];
    const _boundary_0 = _runtime_0["boundary"];
    const _capacity_0 = _runtime_0["capacity"];
    const _nextReader_0 = _runtime_0["nextReader"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": ((_nextReader_0 + 1) >>> 0)}, "snd": {$: "Some", "value": _nextReader_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058started_clocked$1260$(_clocked_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": {$: "Nil"}, "positions": {$: "Nil"}, "tick": _clock_0, "frameStart": 0, "boundary": 0, "capacity": 65536, "nextReader": 1};
}

function $$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1261$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $registered$(_result_0, _first_0, _second_0) {
  if (_result_0.$ === "../../../src/ecs/relation-failure-runtime.RegistrationFailed") {
    return "unexpected-registration-failure";
  } else {
    const _runtime_0 = _result_0["runtime"];
    const _reader_0 = _result_0["reader"];
    return $after_reserve$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader$1260$(_runtime_0)), _reader_0, _first_0, _second_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register$1260$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register_checked$1260$((_nextReader_0 < 4294967295), {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}, _keys_0, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1261$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $after_reserve$(_result_0, _reader_0, _first_0, _second_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _third_0 = _t_0["value"];
    return $seeded$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world$1260$(run_clo((_x_0) => {
  return $publish$(_x_0);
}), _runtime_0)), _reader_0, {$: "Con", "head": _first_0, "tail": {$: "Con", "head": _second_0, "tail": {$: "Con", "head": _third_0, "tail": {$: "Nil"}}}});
  } else {
    return "unexpected-reservation-failure";
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register_checked$1260$(_available_0, _runtime_0, _keys_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/relation-failure-runtime.RegistrationFailed", "runtime": _runtime_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register_available$1260$(_runtime_0, _keys_0, _name_0, _access_0);
  }
}

function $seeded$(_seed_0, _reader_0, _ids_0) {
  const _runtime_0 = _seed_0["fst"];
  const _t_0 = _reader_0["registry"];
  const _ns_0 = _t_0["namespace"];
  const _system_0 = _t_0["id"];
  const _name_0 = _t_0["name"];
  const _access_0 = _t_0["access"];
  const _cursor_0 = _t_0["cursor"];
  const _keys_0 = _reader_0["keys"];
  const _id_0 = _reader_0["id"];
  return $completed$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run$1260$(_runtime_0, {$: "../../../src/ecs/relation-failure-runtime.Reader", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _ns_0, "id": _system_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, "keys": _keys_0, "id": _id_0}, {$: "Unit"})), _ids_0, _id_0, _system_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world$1260$(_effect_0, _runtime_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_result$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058effect_clocked$1260$(_effect_0, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)))), _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0);
}

function $publish$(_world_0) {
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, {$: "Con", "head": 42, "tail": {$: "Nil"}})), "snd": {$: "Unit"}};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058register_available$1260$(_runtime_0, _keys_0, _name_0, _access_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058registered_result$1260$(($$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0)), _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0);
}

function $completed$(_result_0, _ids_0, _readerId_0, _systemId_0) {
  const _t_0 = _result_0["runtime"];
  const _world_0 = _t_0["world"];
  const _domains_0 = _t_0["domains"];
  const _before_0 = _t_0["positions"];
  const _tick_0 = _t_0["tick"];
  const _start_0 = _t_0["frameStart"];
  const _boundary_0 = _t_0["boundary"];
  const _capacity_0 = _t_0["capacity"];
  const _next_0 = _t_0["nextReader"];
  const _reader_0 = _result_0["reader"];
  const _t_1 = _result_0["completion"];
  if (_t_1.$ === "../../../src/ecs/relation-failure-runtime.Succeeded") {
    const _values_0 = _t_1["output"];
    const _x_0 = ($positions$(_before_0));
    const _x_1 = ($readings$(_values_0));
    const _x_2 = (",\"positionsBefore\":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($U32$show$(_systemId_0));
    const _x_5 = (",\"readings\":" + _x_3);
    const _x_6 = (_x_4 + _x_5);
    const _x_7 = ($U32$show$(_readerId_0));
    const _x_8 = (",\"system\":" + _x_6);
    const _x_9 = (_x_7 + _x_8);
    const _x_10 = ($numbers$(_ids_0));
    const _x_11 = (",\"reader\":" + _x_9);
    const _x_12 = (_x_10 + _x_11);
    return $disposed$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058dispose$1260$({$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _before_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _next_0}, _reader_0)), ("{\"reserved\":" + _x_12));
  } else {
    return "unexpected-run-failure";
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run$1260$(_runtime_0, _reader_0, _args_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  const _id_0 = _reader_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_identified$1260$(_runtime_0, {$: "Tuple", "fst": _registry_0, "snd": _id_0}, _keys_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_result$1260$(_result_0, _domains_0, _positions_0, __0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0) {
  const _world_0 = _result_0["fst"];
  const _output_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_clocked$1260$(($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)), _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058effect_clocked$1260$(_effect_0, _advanced_0) {
  const _world_0 = _advanced_0["fst"];
  return run_tail(_effect_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058next_clock$((_clock_0 < 4294967295), _clock_0))};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058registered_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationFailed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../src/ecs/relation-failure-runtime.RegistrationFailed", "runtime": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../src/ecs/relation-failure-runtime.Registered", "runtime": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": ((_nextReader_0 + 1) >>> 0)}, "reader": {$: "../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0, "id": _nextReader_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058register$1260$(_world_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0);
}

function $disposed$(_result_0, _prefix_0) {
  if (_result_0.$ === "../../../src/ecs/relation-failure-disposal.ReaderDisposalRejected") {
    return "unexpected-disposal-refusal";
  } else {
    const _t_0 = _result_0["runtime"];
    const _world_0 = _t_0["world"];
    const _domains_0 = _t_0["domains"];
    const _after_0 = _t_0["positions"];
    const _tick_0 = _t_0["tick"];
    const _start_0 = _t_0["frameStart"];
    const _boundary_0 = _t_0["boundary"];
    const _capacity_0 = _t_0["capacity"];
    const _next_0 = _t_0["nextReader"];
    const _x_0 = ($positions$(_after_0));
    const _x_1 = (",\"positionsAfter\":" + _x_0);
    return $remaining_check$(($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, 1, "unrelated", {$: "Nil"})), _domains_0, _after_0, _tick_0, _start_0, _boundary_0, _capacity_0, _next_0, (_prefix_0 + _x_1));
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058dispose$1260$(_runtime_0, _reader_0) {
  const _registry_0 = _reader_0["registry"];
  const _keys_0 = _reader_0["keys"];
  const _id_0 = _reader_0["id"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058identified$1260$(_runtime_0, {$: "Tuple", "fst": _registry_0, "snd": _id_0}, _keys_0);
}

function $numbers$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($tail$(_rest_0));
    const _x_1 = ($U32$show$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $readings$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($readings_tail$(_rest_0));
    const _x_1 = ($reading$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $positions$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "[]";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($positions_tail$(_rest_0));
    const _x_1 = ($position$(_value_0));
    const _x_2 = (_x_0 + "]");
    const _x_3 = (_x_1 + _x_2);
    return ("[" + _x_3);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_identified$1260$(_runtime_0, _identified_0, _keys_0, _args_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _registry_0 = _identified_0["fst"];
  const _id_0 = _identified_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_result$1260$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_clocked$1260$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058advance_clock$1260$(_world_0)), {$: "../../../src/ecs/relation-failure-runtime.Input", "readings": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_keys_0, _domains_0, ($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058position_or$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _id_0, _tick_0)))), "args": _args_0})), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_clocked$1260$(_clocked_0, _output_0, _domains_0, _positions_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_collected$1260$(($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _clock_0, _domains_0)), _output_0, _positions_0, _clock_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058next_clock$(_available_0, _clock_0) {
  if (!_available_0) {
    return _clock_0;
  } else {
    return ((_clock_0 + 1) >>> 0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_namespace$1260$(_named_0, _name_0, _access_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0);
}

function $remaining_check$(_checked_0, _domains_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _next_0, _prefix_0) {
  const _world_0 = _checked_0["fst"];
  const _remaining_0 = _checked_0["snd"];
  return $removed_check$(($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, 2, "real", {$: "Con", "head": "Parent", "tail": {$: "Nil"}})), _domains_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _next_0, _prefix_0, _remaining_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0))};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058identified$1260$(_runtime_0, _identity_0, _keys_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _frameStart_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  const _nextReader_0 = _runtime_0["nextReader"];
  const _registry_0 = _identity_0["fst"];
  const _id_0 = _identity_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058completed$1260$(($$$$047$$$047$$$047src$047ecs$047system$058dispose$1260$(_registry_0, _world_0)), _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0);
}

function $tail$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($U32$show$(_value_0));
    const _x_1 = ($tail$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $reading$(_value_0) {
  const _t_0 = _value_0["key"];
  const _key_0 = _t_0["id"];
  const _values_0 = _value_0["values"];
  const _lagged_0 = _value_0["lagged"];
  const _x_0 = ($bool$(_lagged_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($numbers$(_values_0));
  const _x_3 = (",\"lagged\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_key_0));
  const _x_6 = (",\"values\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"key\":" + _x_7);
}

function $readings_tail$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($reading$(_value_0));
    const _x_1 = ($readings_tail$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $position$(_value_0) {
  const _id_0 = _value_0["id"];
  const _cursor_0 = _value_0["cursor"];
  const _registered_0 = _value_0["registeredAt"];
  const _x_0 = ($Nat$show$(_registered_0));
  const _x_1 = (_x_0 + "}");
  const _x_2 = ($Nat$show$(_cursor_0));
  const _x_3 = (",\"registeredAt\":" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = ($U32$show$(_id_0));
  const _x_6 = (",\"cursor\":" + _x_4);
  const _x_7 = (_x_5 + _x_6);
  return ("{\"id\":" + _x_7);
}

function $positions_tail$(_values_0) {
  if (_values_0.$ === "Nil") {
    return "";
  } else {
    const _value_0 = _values_0["head"];
    const _rest_0 = _values_0["tail"];
    const _x_0 = ($position$(_value_0));
    const _x_1 = ($positions_tail$(_rest_0));
    const _x_2 = (_x_0 + _x_1);
    return ("," + _x_2);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_result$1260$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _t_0 = _result_0["args"];
    const _args_0 = _t_0["args"];
    return {$: "../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}, "reader": {$: "../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0, "id": _id_0}, "completion": {$: "../../../src/ecs/relation-failure-runtime.Rejected", "args": _args_0}};
  } else {
    const _registry_1 = _result_0["registry"];
    const _completed_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058outcome$1260$(_completed_0, _registry_1, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058run_clocked$1260$(_registry_0, _advanced_0, _input_0) {
  const _world_0 = _advanced_0["fst"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _input_0);
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_keys_0, _domains_0, _position_0) {
  if (_keys_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _key_0 = _keys_0["head"];
    const _rest_0 = _keys_0["tail"];
    return {$: "Con", "head": run_loop($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_domains_0, _key_0, _position_0)), "tail": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058all$1260$(_rest_0, _domains_0, _position_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058position_or$(_position_0, _id_0, _tick_0) {
  if (_position_0.$ === "None") {
    return {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _tick_0};
  } else {
    const _found_0 = _position_0["value"];
    return _found_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _position_0 = _positions_0["head"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_rest_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058with_world_collected$1260$(_collected_0, _output_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0) {
  const _world_0 = _collected_0["fst"];
  const _domains_0 = _collected_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}, "snd": _output_0};
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _tick_0, _domains_0) {
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1260$(($$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0)), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_join$1260$(_registered_0, _namespace_0, _name_0, _access_0) {
  const _world_0 = _registered_0["fst"];
  const _result_0 = _registered_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0);
}

function $removed_check$(_checked_0, _domains_0, _positions_0, _tick_0, _start_0, _boundary_0, _capacity_0, _next_0, _prefix_0, _remaining_0) {
  const _world_0 = _checked_0["fst"];
  const _disposed_0 = _checked_0["snd"];
  const _x_0 = ($U32$show$(_next_0));
  const _x_1 = ($bool$(_disposed_0));
  const _x_2 = (",\"nextReaderBeforeExhaustion\":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($bool$(_remaining_0));
  const _x_5 = (",\"disposedSystem\":" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = (",\"remainingSystem\":" + _x_6);
  return $exhaustion$({$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _next_0}, (_prefix_0 + _x_7));
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058completed$1260$(_result_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0) {
  if (_result_0.$ === "../../../src/ecs/system.Disposed") {
    const _world_0 = _result_0["world"];
    return {$: "../../../src/ecs/relation-failure-disposal.ReaderDisposed", "runtime": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": ($$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058release$1260$(_domains_0, _id_0)), "positions": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _tick_0, true)), "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _registry_0 = _result_0["registry"];
    return {$: "../../../src/ecs/relation-failure-disposal.ReaderDisposalRejected", "runtime": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_1, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}, "reader": {$: "../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0, "id": _id_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058dispose$1260$(_registry_0, _world_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058dispose_returned$1260$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047registration$058remove$1260$(_world_0, _namespace_0, _id_0, _name_0, _access_0)));
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $bool$(_value_0) {
  if (_value_0) {
    return "true";
  } else {
    return "false";
  }
}

function $Nat$show$(_n_0) {
  const _m_0 = _n_0;
  return $Nat$show$fin$(_m_0, "", ($Nat$show$put$(nat_divmod(_m_0, 10))));
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058outcome$1260$(_outcome_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058failed_clocked$1260$(($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0, _error_0);
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_clocked$1260$(($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)), _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0, _output_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_tracked$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(($$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0)));
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_domains_0, _wanted_0, _position_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "../../../src/ecs/internal/relation-failures/readings.KeyReading", "key": _wanted_0, "values": {$: "Nil"}, "lagged": false};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058select$1260$(($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _position_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058one$1260$(_rest_0, _wanted_0, _position_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup_checked$(_position_0, _id_0, _fallback_0) {
  const _actual_0 = _position_0["id"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$((_actual_0 === _id_0), {$: "../../../src/ecs/event-runtime.Position", "id": _actual_0, "cursor": _cursor_0, "registeredAt": _registered_0}, _fallback_0);
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect_view$1260$(_view_0, _tick_0, _domains_0) {
  const _world_0 = _view_0["fst"];
  const _items_0 = _view_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1260$(_world_0, ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1260$(_items_0, {$: "../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Nil"}, "batches": {$: "Nil"}})), _tick_0, _domains_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_view$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _events_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047src$047ecs$047system$058register_meta$1260$(_world_0, _result_0, _namespace_0, _name_0, _access_0) {
  if (_result_0.$ === "../../../src/ecs/world.RegistrationRejected") {
    return {$: "../../../src/ecs/system.RegistrationFailed", "world": _world_0};
  } else {
    const _id_0 = _result_0["id"];
    return {$: "../../../src/ecs/system.Registered", "world": _world_0, "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0}};
  }
}

function $exhaustion$(_runtime_0, _prefix_0) {
  const _world_0 = _runtime_0["world"];
  const _domains_0 = _runtime_0["domains"];
  const _positions_0 = _runtime_0["positions"];
  const _tick_0 = _runtime_0["tick"];
  const _start_0 = _runtime_0["frameStart"];
  const _boundary_0 = _runtime_0["boundary"];
  const _capacity_0 = _runtime_0["capacity"];
  return $last_reserved$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader$1260$({$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _start_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": 4294967294})), _prefix_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058release$1260$(_domains_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058remove$(_ids_0, _id_0))}, "tail": ($$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058release$1260$(_rest_0, _id_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_positions_0, _id_0, _cursor_0, _dispose_0) {
  if (_positions_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _positions_0["head"];
    const _actual_0 = _t_0["id"];
    const _old_0 = _t_0["cursor"];
    const _registered_0 = _t_0["registeredAt"];
    const _rest_0 = _positions_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$((_actual_0 === _id_0), _dispose_0, _actual_0, _old_0, _registered_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(_rest_0, _id_0, _cursor_0, _dispose_0)), _cursor_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058dispose_returned$1260$(_registry_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _t_0 = _observed_0["snd"];
  if (_t_0) {
    return {$: "../../../src/ecs/system.Disposed", "world": _world_0};
  } else {
    return {$: "../../../src/ecs/system.DisposalRejected", "world": _world_0, "registry": _registry_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047registration$058remove$1260$(_world_0, _namespace_0, _id_0, _name_0, _access_0) {
  const _actual_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047registration$058remove_checked$1260$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../src/ecs/world.World", "namespace": _actual_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _id_0, _name_0, _access_0);
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$fin$($0, $1, $2) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $Nat$show$put$(_qr_0) {
  const _q_0 = _qr_0["fst"];
  const _r_0 = _qr_0["snd"];
  const _x_0 = nat_chk(48 + _r_0);
  return {$: "Tuple", "fst": char_new((_x_0 >>> 0)), "snd": _q_0};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058failed_clocked$1260$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0, _error_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return {$: "../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)), "positions": ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), "tick": _clock_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}, "reader": {$: "../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0, "id": _id_0}, "completion": {$: "../../../src/ecs/relation-failure-runtime.Failed", "error": _error_0}};
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_clocked$1260$(_clocked_0, _registry_0, _keys_0, _domains_0, _positions_0, _id_0, _previous_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0, _output_0) {
  const _world_0 = _clocked_0["fst"];
  const _clock_0 = _clocked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_collected$1260$(_id_0, ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collect$1260$(_world_0, _clock_0, ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$(_keys_0, _domains_0, _id_0)))), _registry_0, _keys_0, ($$$$047$$$047$$$047src$047ecs$047event$045runtime$058update$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _previous_0)), _id_0, _clock_0, false)), _clock_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0, _output_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_result$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/system.RegistrationRejected") {
    const _registry_0 = _result_0["registry"];
    const _world_0 = _result_0["world"];
    const _args_0 = _result_0["args"];
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _registry_1 = _result_0["registry"];
    const _outcome_0 = _result_0["outcome"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_1, _outcome_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run$1260$(_registry_0, _world_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058select$1260$(_same_0, _key_0, _queue_0, _position_0, _ih_0) {
  if (_same_0) {
    return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0);
  } else {
    return run_tail(_ih_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_left_0, _right_0) {
  const _a_0 = _left_0["id"];
  const _b_0 = _right_0["id"];
  return (_a_0 === _b_0);
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058choose_position$(_found_0, _position_0, _fallback_0) {
  if (!_found_0) {
    return _fallback_0;
  } else {
    return {$: "Some", "value": _position_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058collected$1260$(_world_0, _partition_0, _tick_0, _domains_0) {
  const _ordinary_0 = _partition_0["ordinary"];
  const _batches_0 = _partition_0["batches"];
  return {$: "Tuple", "fst": ($$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, ($List$reverse$(_ordinary_0)))), "snd": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1260$(_batches_0, _tick_0, _domains_0))};
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        const _ordinary_0 = _acc_0["ordinary"];
        const _batches_0 = _acc_0["batches"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1260$(($classify$(_item_0)), _item_0, _ordinary_0, _batches_0));
        continue;
      }
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $last_reserved$(_result_0, _prefix_0) {
  const _runtime_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "Some") {
    const _last_0 = _t_0["value"];
    return $exhausted$(($$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058reserve_reader$1260$(_runtime_0)), _prefix_0, _last_0);
  } else {
    return "unexpected-early-exhaustion";
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058remove$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058keep$((_id_0 === _wanted_0), _id_0, ($$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058remove$(_rest_0, _wanted_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058update_checked$(_found_0, _dispose_0, _id_0, _old_0, _registered_0, _rest_0, _cursor_0) {
  if (!_found_0) {
    return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _old_0, "registeredAt": _registered_0}, "tail": _rest_0};
  } else {
    if (!_dispose_0) {
      return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": _cursor_0, "registeredAt": _registered_0}, "tail": _rest_0};
    } else {
      return _rest_0;
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047registration$058remove_checked$1260$(_allowed_0, _world_0, _id_0, _name_0, _access_0) {
  if (!_allowed_0) {
    return {$: "Tuple", "fst": _world_0, "snd": false};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _nextId_0 = _world_0["nextId"];
    const _highWater_0 = _world_0["highWater"];
    const _live_0 = _world_0["live"];
    const _capacity_0 = _world_0["capacity"];
    const _depth_0 = _world_0["depth"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": ($$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0)), "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": true};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $Nat$show$go$($0, $1, $2) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _dq_0 = $2;
      const _d_0 = _dq_0["fst"];
      const _t_0 = _dq_0["snd"];
      if (_t_0 === 0) {
        return (_d_0 + _acc_0);
      } else {
        const _p_0 = (_t_0 - 1);
        $0 = _g_0;
        $1 = nat_chk(_p_0 + 1);
        $2 = (_d_0 + _acc_0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = ($Nat$show$put$(nat_divmod(_n_0, 10)));
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058activate$1260$($0, $1, $2) {
  for (;;) {
    {
      const _keys_0 = $0;
      const _domains_0 = $1;
      const _id_0 = $2;
      if (_keys_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _key_0 = _keys_0["head"];
        const _rest_0 = _keys_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_domains_0, _key_0, _id_0));
        $2 = _id_0;
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activate$(_positions_0, _id_0, _registered_0) {
  return $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(($$$$047$$$047$$$047src$047ecs$047event$045runtime$058lookup$(_positions_0, _id_0)), _positions_0, _id_0, _registered_0);
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045runtime$058succeeded_collected$1260$(_id_0, _joined_0, _registry_0, _keys_0, _positions_0, _tick_0, _frameStart_0, _boundary_0, _capacity_0, _nextReader_0, _output_0) {
  const _world_0 = _joined_0["fst"];
  const _domains_0 = _joined_0["snd"];
  return {$: "../../../src/ecs/relation-failure-runtime.Ran", "runtime": {$: "../../../src/ecs/relation-failure-runtime.Runtime", "world": _world_0, "domains": _domains_0, "positions": _positions_0, "tick": _tick_0, "frameStart": _frameStart_0, "boundary": _boundary_0, "capacity": _capacity_0, "nextReader": _nextReader_0}, "reader": {$: "../../../src/ecs/relation-failure-runtime.Reader", "registry": _registry_0, "keys": _keys_0, "id": _id_0}, "completion": {$: "../../../src/ecs/relation-failure-runtime.Succeeded", "output": _output_0}};
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_outcome$1260$(_registry_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace$1260$(_registry_0, _named_0, _args_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047readings$058queue_reading$1260$(_key_0, _queue_0, _position_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  const _cursor_0 = _position_0["cursor"];
  const _registered_0 = _position_0["registeredAt"];
  const _x_0 = (_cursor_0 > _registered_0 ? _cursor_0 : _registered_0);
  return {$: "../../../src/ecs/internal/relation-failures/readings.KeyReading", "key": _key_0, "values": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read$1260$({$: "../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": _back_0, "size": _size_0, "dropped": _dropped_0}, _cursor_0)), "lagged": (_x_0 < _dropped_0)};
}

function $$$$047$$$047$$$047src$047ecs$047world$058events_replace$1260$(_world_0, _retained_0) {
  const _namespace_0 = _world_0["namespace"];
  const _nextId_0 = _world_0["nextId"];
  const _highWater_0 = _world_0["highWater"];
  const _live_0 = _world_0["live"];
  const _capacity_0 = _world_0["capacity"];
  const _depth_0 = _world_0["depth"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "nextId": _nextId_0, "highWater": _highWater_0, "live": _live_0, "capacity": _capacity_0, "depth": _depth_0, "store": _store_0, "resource": _resource_0, "events": _retained_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_batches$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _tick_0 = $1;
      const _domains_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _domains_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _key_0 = _t_0["key"];
        const _reversed_0 = _t_0["reversed"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _tick_0;
        $2 = ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_domains_0, _key_0, _tick_0, ($List$reverse$(_reversed_0))));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058partition_selected$1260$(_key_0, _item_0, _ordinary_0, _batches_0) {
  if (_key_0.$ === "None") {
    return {$: "../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": {$: "Con", "head": _item_0, "tail": _ordinary_0}, "batches": _batches_0};
  } else {
    const _wanted_0 = _key_0["value"];
    return {$: "../../../src/ecs/internal/relation-failures/routing.Partition", "ordinary": _ordinary_0, "batches": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_batches_0, _wanted_0, _item_0))};
  }
}

function $classify$(__0) {
  return {$: "Some", "value": {$: "../../../src/ecs/internal/relation-failures/domains.DeclaredKey", "id": 1}};
}

function $exhausted$(_result_0, _prefix_0, _last_0) {
  const _t_0 = _result_0["fst"];
  const _next_0 = _t_0["nextReader"];
  const _t_1 = _result_0["snd"];
  if (_t_1.$ === "None") {
    const _x_0 = ($U32$show$(_next_0));
    const _x_1 = (_x_0 + "}");
    const _x_2 = ($U32$show$(_last_0));
    const _x_3 = (",\"exhausted\":true,\"next\":" + _x_1);
    const _x_4 = (_x_2 + _x_3);
    const _x_5 = (",\"last\":" + _x_4);
    return (_prefix_0 + _x_5);
  } else {
    return "unexpected-wrap";
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047relation$045failure$045disposal$058keep$(_found_0, _id_0, _rest_0) {
  if (_found_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047registration$058without$(_registrations_0, _id_0, _name_0, _access_0) {
  if (_registrations_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _meta_0 = _registrations_0["head"];
    const _rest_0 = _registrations_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047registration$058retained$(($Bool$not$(($$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0)))), _meta_0, ($$$$047$$$047$$$047src$047ecs$047registration$058without$(_rest_0, _id_0, _name_0, _access_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_domains_0, _wanted_0, _id_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$()), "readers": {$: "Con", "head": _id_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1260$(($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), {$: "../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, _rest_0, _id_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_one$1260$(_rest_0, _wanted_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047event$045runtime$058activation$(_position_0, _positions_0, _id_0, _registered_0) {
  if (_position_0.$ === "None") {
    return {$: "Con", "head": {$: "../../../src/ecs/event-runtime.Position", "id": _id_0, "cursor": 0, "registeredAt": _registered_0}, "tail": _positions_0};
  } else {
    return _positions_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058tracked_clock$1260$(_registry_0, _output_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$({$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}, _registry_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_value$1260$(_registry_0, _world_0, _actual_0, _args_0) {
  const _namespace_0 = _registry_0["namespace"];
  const _id_0 = _registry_0["id"];
  const _name_0 = _registry_0["name"];
  const _access_0 = _registry_0["access"];
  const _cursor_0 = _registry_0["cursor"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$((_namespace_0 === _actual_0), {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read$1260$(_queue_0, _cursor_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0);
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_domains_0, _wanted_0, _tick_0, _items_0) {
  if (_domains_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/domains.Domain", "key": _wanted_0, "queue": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$()), _tick_0, _items_0)), "readers": {$: "Nil"}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _domains_0["head"];
    const _key_0 = _t_0["key"];
    const _queue_0 = _t_0["queue"];
    const _ids_0 = _t_0["readers"];
    const _rest_0 = _domains_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1260$(($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_one$1260$(_rest_0, _wanted_0, _tick_0, _items_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_batches_0, _wanted_0, _item_0) {
  if (_batches_0.$ === "Nil") {
    return {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _wanted_0, "reversed": {$: "Con", "head": _item_0, "tail": {$: "Nil"}}}, "tail": {$: "Nil"}};
  } else {
    const _t_0 = _batches_0["head"];
    const _key_0 = _t_0["key"];
    const _items_0 = _t_0["reversed"];
    const _rest_0 = _batches_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1260$(($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058key_equal$1260$(_key_0, _wanted_0)), _key_0, _items_0, _rest_0, _item_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group$1260$(_rest_0, _wanted_0, _item_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047src$047ecs$047registration$058retained$(_keep_0, _meta_0, _rest_0) {
  if (_keep_0) {
    return {$: "Con", "head": _meta_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058empty$1260$() {
  return {$: "../../../src/ecs/internal/relation-failures/queue.Queue", "front": {$: "Nil"}, "back": {$: "Nil"}, "size": 0, "dropped": 0};
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_walk$1260$(_same_0, _domain_0, _rest_0, _id_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1260$(true, _domain_0, _id_0)), "tail": _rest_0};
  } else {
    return {$: "Con", "head": _domain_0, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058cursor_outcome$1260$(_outcome_0, _registry_0, _nextCursor_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    return {$: "../../../src/ecs/system.Completed", "registry": {$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _nextCursor_0}, "outcome": {$: "../../../src/ecs/system.Succeeded", "world": _world_1, "output": _output_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_namespace_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    const _namespace_0 = _registry_0["namespace"];
    const _id_0 = _registry_0["id"];
    const _name_0 = _registry_0["name"];
    const _access_0 = _registry_0["access"];
    const _cursor_0 = _registry_0["cursor"];
    return $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$({$: "../../../src/ecs/system.Registry", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": _cursor_0}, ($$$$047$$$047$$$047src$047ecs$047world$058registration_matches$1260$(_world_0, _id_0, _name_0, _access_0)), _args_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_back$1260$(_front_0, _back_0, _cursor_0) {
  return $List$reverse$(($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$(($List$reverse$(_back_0)), _cursor_0, ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$(_front_0, _cursor_0, {$: "Nil"})))));
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(_queue_0, _tick_0, _items_0) {
  const _x_0 = ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$(_items_0, 0));
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1260$((0 < _x_0), _queue_0, _tick_0, _items_0, ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$(_items_0, 0)));
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058publish_found$1260$(_same_0, _key_0, _queue_0, _ids_0, _rest_0, _tick_0, _items_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish$1260$(_queue_0, _tick_0, _items_0)), "readers": _ids_0}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": _ids_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047routing$058group_found$1260$(_same_0, _key_0, _items_0, _rest_0, _item_0, _ih_0) {
  if (_same_0) {
    return {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": {$: "Con", "head": _item_0, "tail": _items_0}}, "tail": _rest_0};
  } else {
    return {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/routing.PendingBatch", "key": _key_0, "reversed": _items_0}, "tail": _ih_0({$: "Unit"})};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058activate_domain$1260$(_same_0, _domain_0, _id_0) {
  if (!_same_0) {
    return _domain_0;
  } else {
    const _key_0 = _domain_0["key"];
    const _queue_0 = _domain_0["queue"];
    const _ids_0 = _domain_0["readers"];
    return {$: "../../../src/ecs/internal/relation-failures/domains.Domain", "key": _key_0, "queue": _queue_0, "readers": ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_metadata$1260$(_registry_0, _checked_0, _args_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058read_loop$1260$($0, $1, $2) {
  for (;;) {
    {
      const _batches_0 = $0;
      const _cursor_0 = $1;
      const _acc_0 = $2;
      if (_batches_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _batches_0["head"];
        const _tick_0 = _t_0["tick"];
        const _items_0 = _t_0["values"];
        const _rest_0 = _batches_0["tail"];
        $0 = _rest_0;
        $1 = _cursor_0;
        $2 = ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1260$((_cursor_0 < _tick_0), _items_0, _acc_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_checked$1260$(_nonempty_0, _queue_0, _tick_0, _items_0, _count_0) {
  if (!_nonempty_0) {
    return _queue_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058count_loop$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = nat_chk(1 + _acc_0);
        continue;
      }
    }
  }
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add$(_ids_0, _id_0) {
  return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add_checked$(($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _id_0)), _ids_0, _id_0);
}

function $$$$047$$$047$$$047src$047ecs$047system$058run_checked$1260$(_allowed_0, _registry_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/system.RegistrationRejected", "registry": _registry_0, "world": _world_0, "args": _args_0};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, ($body$(_world_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058visible_items$1260$(_visible_0, _items_0, _acc_0) {
  if (!_visible_0) {
    return _acc_0;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1260$(_items_0, _acc_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058publish_nonempty$1260$(_queue_0, _tick_0, _items_0, _count_0) {
  const _front_0 = _queue_0["front"];
  const _back_0 = _queue_0["back"];
  const _size_0 = _queue_0["size"];
  const _dropped_0 = _queue_0["dropped"];
  return {$: "../../../src/ecs/internal/relation-failures/queue.Queue", "front": _front_0, "back": {$: "Con", "head": {$: "../../../src/ecs/internal/relation-failures/queue.Batch", "tick": _tick_0, "count": _count_0, "values": _items_0}, "tail": _back_0}, "size": nat_chk(_size_0 + _count_0), "dropped": _dropped_0};
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058add_checked$(_found_0, _ids_0, _id_0) {
  if (_found_0) {
    return _ids_0;
  } else {
    return {$: "Con", "head": _id_0, "tail": _ids_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_ids_0, _wanted_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _id_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_id_0 === _wanted_0);
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047domains$058member$(_rest_0, _wanted_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047system$058complete$1260$(_registry_0, _outcome_0) {
  return {$: "../../../src/ecs/system.Completed", "registry": _registry_0, "outcome": _outcome_0};
}

function $body$(_world_0, _input_0) {
  const _values_0 = _input_0["readings"];
  return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _values_0};
}

function $$$$047$$$047$$$047src$047ecs$047internal$047relation$045failures$047queue$058prepend_items$1260$($0, $1) {
  for (;;) {
    {
      const _items_0 = $0;
      const _acc_0 = $1;
      if (_items_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _item_0 = _items_0["head"];
        const _rest_0 = _items_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _item_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);