from pathlib import Path
import hashlib,json,gzip,re,importlib.util,sys
root=Path('/workspace/formal-proofs/bendvy')
wt=Path('/workspace/formal-proofs/bendvy-worktrees/readers43-shared-reader-ids')
entry=wt/'experiments/public-relation-readers/shared-reader-identities-v1/main.bend'
out=Path('/tmp/bendvy43-reader-identities-actual01')
out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
config=root/'experiments/public-simulation/delivery-v1/installed-config.py'
configuration=load('configuration',config)
runner=load('runner',root/'scripts/task_runner.py')
collector=root/'experiments/public-inspect/ordinary-declaration-v1/canonical-adoption-v1/detached-v2/development.py'
guard=root/'experiments/public-inspect/development-plan-guard-v1/plan_guard.py'
expected=b'{"reserved":[1,2,4],"reader":3,"system":2,"readings":[{"key":1,"values":[42],"lagged":false}],"positionsBefore":[{"id":3,"cursor":2,"registeredAt":1}],"positionsAfter":[],"remainingSystem":true,"disposedSystem":false,"nextReaderBeforeExhaustion":5,"last":4294967294,"exhausted":true,"next":4294967295}\n'
oracle=out/'expected.stdout.gz';oracle.write_bytes(gzip.compress(expected,mtime=0))
inventory={}
def visit(p):
 p=p.resolve(strict=True)
 if str(p) in inventory:return
 inventory[str(p)]=sha(p)
 for target in re.findall(r'^import\s+(\S+)',p.read_text(),re.M):
  if target!='Base':visit(p.parent/target)
visit(entry)
tools={'bend':'/home/node/.bend/bin/bend-2.0.35','node':'/home/node/.local/share/mise/installs/node/24.20.0/bin/node','python':str(Path(sys.executable).resolve()),'taskset':'/usr/bin/taskset','clangWrapper':'/tmp/bendvy-clang19-diagnostic/clang19','clangBinary':'/tmp/bendvy-clang19-diagnostic/root/usr/lib/llvm-19/bin/clang'}
pins=inventory|{str(p.resolve()):sha(p) for p in [config,collector,guard,root/'scripts/task_runner.py',root/'scripts/evidence_boundary.py',Path(__file__),oracle,*map(Path,tools.values())]}
resources=runner.Inputs(directories=configuration.RESOURCE_ROOTS).expected
for role in ['js','native']:
 d=out/role;d.mkdir()
 generated=d/('scenario.js' if role=='js' else 'scenario.c');native=d/'scenario.native';prefix=[tools['taskset'],'-c','5']
 commands=[{'label':'emit','argv':prefix+[tools['bend'],str(entry),'-o',str(generated)],'capSeconds':30}]
 if role=='native':commands.extend([{'label':'build','argv':prefix+[tools['clangWrapper'],'-O3',str(generated),'-o',str(native),'-pthread','-lm'],'capSeconds':120},{'label':'consumer','argv':prefix+[str(native),'--threads','1','--gpu','off'],'capSeconds':5}])
 else:commands.append({'label':'consumer','argv':prefix+[tools['node'],str(generated)],'capSeconds':5})
 plan={'scope':'#43 shared reader identity allocator interleaving, disposal and exhaustion finite control; no full provider or performance qualification','role':role,'subject':'normal','entrypoint':str(entry),'stage':str(entry.parent),'sourceInventory':inventory,'importClosure':sorted(inventory),'pins':pins,'resourceRoots':resources,'environment':configuration.environment(),'cwd':str(entry.parent),'tools':tools,'commands':commands,'oracle':str(oracle),'oracleSHA256':hashlib.sha256(expected).hexdigest(),'oracleBytes':len(expected),'normalOracle':str(oracle),'normalOracleSHA256':hashlib.sha256(expected).hexdigest(),'normalOracleBytes':len(expected),'generated':str(generated),'native':str(native),'postConsumer':'Complete independently source-derived JSON equality and empty stderr'}
 target=d/'plan.json';target.write_text(json.dumps(plan,indent=2)+'\n')
 load('guard_'+role,guard).validate(plan,output_dir=d)
 print(role,sha(target),len(inventory),len(expected))
