#!/usr/bin/env python3
"""Finite source-current application controls, no timing or proof acceptance."""
import hashlib,json,os,pathlib,re,shutil,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'experiments/s-prep/fivehour-connected-gates'));import supervisor
OUT=HERE/'evidence'/str(time.time_ns());OUT.mkdir(parents=True)
r={'status':'INCOMPLETE','limits':{'checker':5,'emit':30,'clang':120,'runtime':5},'commands':[],'pins':{},'cases':[]}
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():(OUT/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
def run(argv,limit,expected=0):
 argv=list(map(str,argv));name='command-'+str(len(r['commands']))+'.txt'
 try:code,out=supervisor.execute(argv,limit,env={**os.environ,'BENDVY_CLANG19_ROOT':'/tmp/bendvy-clang19-diagnostic/root'})
 except Exception as error:
  r['commands'].append({'argv':argv,'limitSeconds':limit,'error':repr(error)});save();raise
 (OUT/name).write_text(out);r['commands'].append({'argv':argv,'limitSeconds':limit,'exit':code,'log':name,'sha256':sha(OUT/name)});save()
 if expected is not None:assert code==expected,(code,out)
 return code,out
try:
 seen=set()
 def imports(p):
  p=p.resolve()
  if p in seen:return
  seen.add(p)
  for item in re.findall(r'^import\s+(\S+)',p.read_text(),re.M):
   if item!='Base':imports(p.parent/item)
 for name in ['main.bend','merges.bend','recursive.bend']:imports(HERE/name)
 for p in seen|set(HERE.glob('*.py'))|set(HERE.glob('*.mjs'))|set(HERE.glob('negative*.bend')):r['pins'][str(p)]=sha(p)
 manifest=json.loads((ROOT/'docs/parity/source-review.json').read_text())['references'];r['references']={}
 for name,h in manifest.items():
  _,actual=run(['git','-C',ROOT/'.references'/name,'rev-parse','HEAD'],5);assert actual.strip()==h;r['references'][name]=h
 _,merged=run(['node',HERE/'reference.mjs'],5)
 _,app=run(['node',HERE/'application-reference.mjs'],5)
 _,erased=run(['node',HERE/'erased-undeclared-reference.mjs'],5);r['erasedUndeclaredTSDiscovery']=erased
 for name,diagnostic in [('negative-schema','First'),('negative-affine','consumed more than once'),('negative-write-through-read','ValueWrite'),('negative-undeclared','H')]:
  _,out=run(['bend',HERE/(name+'.bend'),'--check-only'],5,1);assert diagnostic in out;r['cases'].append({'negative':name,'intendedDiagnostic':diagnostic})
 for case in ['merges','main','recursive','collision-omission','name-omission-effects','invalid-initialization']:
  stage=OUT/case;shutil.copytree(ROOT/'src',stage/'src');shutil.copytree(HERE,stage/'experiments/public-schema-fragments',ignore=shutil.ignore_patterns('evidence','__pycache__'))
  entry=stage/'experiments/public-schema-fragments'/('recursive.bend' if case=='recursive' else 'merges.bend' if case in ['merges','collision-omission'] else 'main.bend')
  if case=='collision-omission':
   path=stage/'src/ecs/schema-fragments.bend';text=path.read_text();old='case True{} _: Invalid{DuplicateKey{kind,key}}';assert text.count(old)==1;path.write_text(text.replace(old,'case True{} _: Valid{}'))
  if case=='name-omission-effects':
   path=stage/'src/ecs/schema-fragments.bend';text=path.read_text();old='case False{} True{}: Invalid{DuplicateName{kind,name}}';assert text.count(old)==1;path.write_text(text.replace(old,'case False{} True{}: Valid{}'))
  if case=='invalid-initialization':
   path=stage/'experiments/public-schema-fragments/application.bend';text=path.read_text();old='F.Entry{F.Component{},"other","Position"}';assert text.count(old)==1;path.write_text(text.replace(old,'F.Entry{F.Component{},"Position","Position"}'))
  run(['bend',entry,'--check-only'],5)
  for backend in ['js','native']:
   generated=stage/('main.js' if backend=='js' else 'main.c');run(['bend',entry,'-o',generated],30)
   if backend=='native':
    program=stage/'main-native';run(['/tmp/bendvy-clang19-diagnostic/clang19','-O3',generated,'-pthread','-lm','-o',program],120);argv=[program,'--threads','1','--gpu','off']
   else:argv=['node',generated]
   _,out=run(argv,5)
   if case=='merges':assert out==merged
   elif case=='recursive':assert out=='10,99:20,99:7\n'*2
   elif case=='name-omission-effects':
    lines=out.splitlines();assert lines[:4]==['12,11,:3,3,:1:9,:0:log=1,99']*4;assert lines[4:]==['rejected:10,11,:2,3,:log=0,99']*2
   elif case=='collision-omission':assert out!=merged and 'ok:10,99:20,99' in out
   else:
    lines=out.splitlines();assert '\n'.join(lines[:4])+'\n'==app
    assert lines[4:]==['rejected:10,11,:2,3,:log=0,99']*2
   r['cases'].append({'generatedSHA256':sha(generated),'nativeSHA256':sha(program) if backend=='native' else None,'case':case,'backend':backend,'status':'PASS','outputSHA256':hashlib.sha256(out.encode()).hexdigest()})
 for p,h in r['pins'].items():assert sha(p)==h
 r['status']='FINITE_APPLICATION_MERGE_CONTROL_PASS'
except Exception as error:r['status']='FAIL';r['error']=repr(error)
finally:save()
print(OUT,r['status']);sys.exit(0 if r['status']=='FINITE_APPLICATION_MERGE_CONTROL_PASS' else 1)
