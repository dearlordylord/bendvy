# Public schema fragments — #39

`src/ecs/schema-fragments.bend` composes schema-indexed descriptor metadata and arbitrary affine owner packs. Merge recursively nests pairs; there is no library restriction to two families or Data payloads. A rejected merge returns both complete input fragments. Binding validates all collisions before an initializer receives any owners. `bind_declared` additionally validates the closed initializer's required descriptor manifest.

The independently authored `fragment-left.bend` and `fragment-right.bend` supply nominal affine components containing owned arrays. `application.bend` provisions actual public Columns in a World, registers a public System, invokes an abstract gameplay callback reading/writing both component families and an actual Logger action, publishes an event, queues a resource update, and applies an explicit barrier. Both nominal schemas observe every payload cell, resource, events, pending count and both Logger cells. Invalid name/key merges and missing initializer requirements preserve all owners and leave Logger calls zero. Recursive composition also retains two affine arrays plus a third Data owner.

Run `python3 experiments/public-schema-fragments/run.py`. Receipts pin the transitive source imports, controls, reference HEADs, commands, outputs and generated program hashes. Checker 5s, emission 30s, Clang 120s, runtime 5s; no dependency installation, laws, proofs or timing measurements. A reached key-check omission compiles and admits a forbidden merge. A reached name-check omission compiles and runs the application/service which the original collision prevents.

## Reference and authority scope

The actual pinned Node TS reference executes empty, positive, key/name collisions, repeated descriptors and kind-local descriptor names in two roots. Its four Schema registries are components/resources/events/relations. Bend's additional Service registry is provisioning metadata for the supplied Logger, not a claim that TS Schema merges service fragments. Actual TS services are bound through Runtime services.

Normal well-typed application and merge transcripts compare exactly. `erased-undeclared-reference.mjs` separately preserves an observed JS boundary: an undeclared resource descriptor can reach a callback after TypeScript's static contract has been erased. Bend's required checker rejection and `bind_declared` construction rejection are stronger safety at that invalid boundary; they are not asserted as equivalent TS runtime rejection.

Caller-authored provisioning lenses and required manifests are trusted, as in the existing public Family adapter model. Exported constructors and unrestricted `bind` do not prove universal descriptor/access confinement. Gameplay receives abstract providers; intended finite negatives reject cross-schema descriptors, affine duplication, undeclared concrete-World access and writes through read providers. General feature builders belong to their separate ticket.

## Outstanding delivery gates

No full #39 completion, universal refinement, production authority, performance acceptance or issue closure is claimed. Root must obtain source-current independent review and the unchanged default #28 paired regression. Comparative/scaling measurements are deferred during CPU contention. A separate pre-barrier full-world observation and fresh independently created same-schema foreign-handle operation remain explicit follow-ups for #39; the present application observes the explicit barrier's final state. Earlier tasks' passing gates do not fill these gaps.
