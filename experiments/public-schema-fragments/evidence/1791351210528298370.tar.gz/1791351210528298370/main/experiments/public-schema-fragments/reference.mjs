import {Schema,Descriptor} from '/workspace/formal-proofs/bendvy/.references/bevy-ts/packages/core/src/index.ts';
const c=(name)=>Descriptor.Component()(name);const r=(name)=>Descriptor.Resource()(name);
const cases=[ [{},{}], [{components:{a:c('A')}},{components:{b:c('B')}}], [{components:{a:c('A')}},{components:{a:c('B')}}], [{components:{a:c('A')}},{components:{b:c('A')}}], [{},{components:{a:c('A'),b:c('A')}}], [{components:{a:c('A')}},{components:{a:c('A')}}], [{components:{a:c('A')}},{resources:{a:r('A')}}] ];
for(const root of ['Workshop','Other']) for(const [left,right] of cases) {
 try {Schema.bind(Schema.fragment(left),Schema.fragment(right),Schema.defineRoot(root));console.log('ok:10,99:20,99');}
 catch(e){const s=e.message;console.log((s.startsWith('Duplicate schema key: ')?'key:'+s.slice(22):'name:'+s.slice(27))+':10,99:20,99');}
}
