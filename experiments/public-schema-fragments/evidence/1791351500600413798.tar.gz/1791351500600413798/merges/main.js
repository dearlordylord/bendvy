function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  const _x_0 = ($cases$1261$());
  const _x_1 = ($cases$1260$());
  const _x_2 = ("\n" + _x_0);
  return (_x_3) => $IO$print$((_x_1 + _x_2), _x_3);
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $cases$1260$() {
  const _x_0 = ($case_run$1260$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "k", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "k", "name": "B"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Event"}, "key": "e1", "name": "E"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Event"}, "key": "e2", "name": "E"}, "tail": {$: "Nil"}}}}));
  const _x_1 = ($case_run$1260$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "k", "name": "A"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Event"}, "key": "e1", "name": "E"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Event"}, "key": "e2", "name": "E"}, "tail": {$: "Nil"}}}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "k", "name": "B"}, "tail": {$: "Nil"}}));
  const _x_2 = ("\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($case_run$1260$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Resource"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}));
  const _x_5 = ("\n" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($case_run$1260$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}));
  const _x_8 = ("\n" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($case_run$1260$({$: "Nil"}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "b", "name": "A"}, "tail": {$: "Nil"}}}));
  const _x_11 = ("\n" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($case_run$1260$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "b", "name": "A"}, "tail": {$: "Nil"}}));
  const _x_14 = ("\n" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($case_run$1260$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "B"}, "tail": {$: "Nil"}}));
  const _x_17 = ("\n" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($case_run$1260$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "b", "name": "B"}, "tail": {$: "Nil"}}));
  const _x_20 = ("\n" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ($case_run$1260$({$: "Nil"}, {$: "Nil"}));
  const _x_23 = ("\n" + _x_21);
  return (_x_22 + _x_23);
}

function $cases$1261$() {
  const _x_0 = ($case_run$1261$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "k", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "k", "name": "B"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Event"}, "key": "e1", "name": "E"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Event"}, "key": "e2", "name": "E"}, "tail": {$: "Nil"}}}}));
  const _x_1 = ($case_run$1261$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "k", "name": "A"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Event"}, "key": "e1", "name": "E"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Event"}, "key": "e2", "name": "E"}, "tail": {$: "Nil"}}}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "k", "name": "B"}, "tail": {$: "Nil"}}));
  const _x_2 = ("\n" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  const _x_4 = ($case_run$1261$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Resource"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}));
  const _x_5 = ("\n" + _x_3);
  const _x_6 = (_x_4 + _x_5);
  const _x_7 = ($case_run$1261$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}));
  const _x_8 = ("\n" + _x_6);
  const _x_9 = (_x_7 + _x_8);
  const _x_10 = ($case_run$1261$({$: "Nil"}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "b", "name": "A"}, "tail": {$: "Nil"}}}));
  const _x_11 = ("\n" + _x_9);
  const _x_12 = (_x_10 + _x_11);
  const _x_13 = ($case_run$1261$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "b", "name": "A"}, "tail": {$: "Nil"}}));
  const _x_14 = ("\n" + _x_12);
  const _x_15 = (_x_13 + _x_14);
  const _x_16 = ($case_run$1261$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "B"}, "tail": {$: "Nil"}}));
  const _x_17 = ("\n" + _x_15);
  const _x_18 = (_x_16 + _x_17);
  const _x_19 = ($case_run$1261$({$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "a", "name": "A"}, "tail": {$: "Nil"}}, {$: "Con", "head": {$: "../../src/ecs/schema-fragments.Entry", "kind": {$: "../../src/ecs/schema-fragments.Component"}, "key": "b", "name": "B"}, "tail": {$: "Nil"}}));
  const _x_20 = ("\n" + _x_18);
  const _x_21 = (_x_19 + _x_20);
  const _x_22 = ($case_run$1261$({$: "Nil"}, {$: "Nil"}));
  const _x_23 = ("\n" + _x_21);
  return (_x_22 + _x_23);
}

function $case_run$1260$(_left_0, _right_0) {
  return $result$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058merge$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058fragment$1260$(_left_0, ($owner$(10)))), ($$$$047$$$047src$047ecs$047schema$045fragments$058fragment$1260$(_right_0, ($owner$(20)))))));
}

function $case_run$1261$(_left_0, _right_0) {
  return $result$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058merge$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058fragment$1261$(_left_0, ($owner$(10)))), ($$$$047$$$047src$047ecs$047schema$045fragments$058fragment$1261$(_right_0, ($owner$(20)))))));
}

function $result$1260$(_merged_0) {
  if (_merged_0.$ === "../../src/ecs/schema-fragments.Rejected") {
    const _e_0 = _merged_0["error"];
    const _t_0 = _merged_0["left"];
    const _left_0 = _t_0["owners"];
    const _t_1 = _merged_0["right"];
    const _right_0 = _t_1["owners"];
    const _x_0 = ($show$(_right_0));
    const _x_1 = ($show$(_left_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($error$(_e_0));
    const _x_5 = (":" + _x_3);
    return (_x_4 + _x_5);
  } else {
    const _t_2 = _merged_0["fragment"];
    const _owners_0 = _t_2["owners"];
    return $successful$(_owners_0);
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058merge$1260$(_left_0, _right_0) {
  const _le_0 = _left_0["entries"];
  const _l_0 = _left_0["owners"];
  const _re_0 = _right_0["entries"];
  const _r_0 = _right_0["owners"];
  return $$$$047$$$047src$047ecs$047schema$045fragments$058merge_checked$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(($$$$047$$$047src$047ecs$047schema$045fragments$058validate$1260$(_le_0)), ($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(($$$$047$$$047src$047ecs$047schema$045fragments$058validate$1260$(_re_0)), ($$$$047$$$047src$047ecs$047schema$045fragments$058validate$1260$(($List$append$(_le_0, _re_0)))))))), ($List$append$(_le_0, _re_0)), {$: "../../src/ecs/schema-fragments.Fragment", "entries": _le_0, "owners": _l_0}, {$: "../../src/ecs/schema-fragments.Fragment", "entries": _re_0, "owners": _r_0});
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058fragment$1260$(_entries_0, _owners_0) {
  return {$: "../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0};
}

function $owner$(_first_0) {
  return {$: "Owned", "cells": array_node([_first_0], [99])};
}

function $result$1261$(_merged_0) {
  if (_merged_0.$ === "../../src/ecs/schema-fragments.Rejected") {
    const _e_0 = _merged_0["error"];
    const _t_0 = _merged_0["left"];
    const _left_0 = _t_0["owners"];
    const _t_1 = _merged_0["right"];
    const _right_0 = _t_1["owners"];
    const _x_0 = ($show$(_right_0));
    const _x_1 = ($show$(_left_0));
    const _x_2 = (":" + _x_0);
    const _x_3 = (_x_1 + _x_2);
    const _x_4 = ($error$(_e_0));
    const _x_5 = (":" + _x_3);
    return (_x_4 + _x_5);
  } else {
    const _t_2 = _merged_0["fragment"];
    const _owners_0 = _t_2["owners"];
    return $successful$(_owners_0);
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058merge$1261$(_left_0, _right_0) {
  const _le_0 = _left_0["entries"];
  const _l_0 = _left_0["owners"];
  const _re_0 = _right_0["entries"];
  const _r_0 = _right_0["owners"];
  return $$$$047$$$047src$047ecs$047schema$045fragments$058merge_checked$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(($$$$047$$$047src$047ecs$047schema$045fragments$058validate$1261$(_le_0)), ($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(($$$$047$$$047src$047ecs$047schema$045fragments$058validate$1261$(_re_0)), ($$$$047$$$047src$047ecs$047schema$045fragments$058validate$1261$(($List$append$(_le_0, _re_0)))))))), ($List$append$(_le_0, _re_0)), {$: "../../src/ecs/schema-fragments.Fragment", "entries": _le_0, "owners": _l_0}, {$: "../../src/ecs/schema-fragments.Fragment", "entries": _re_0, "owners": _r_0});
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058fragment$1261$(_entries_0, _owners_0) {
  return {$: "../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": _owners_0};
}

function $error$(_error_0) {
  if (_error_0.$ === "../../src/ecs/schema-fragments.DuplicateKey") {
    const _key_0 = _error_0["key"];
    return ("key:" + _key_0);
  } else if (_error_0.$ === "../../src/ecs/schema-fragments.DuplicateName") {
    const _name_0 = _error_0["name"];
    return ("name:" + _name_0);
  } else {
    const _key_1 = _error_0["key"];
    return ("undeclared:" + _key_1);
  }
}

function $show$(_owner_0) {
  const _array_0 = _owner_0["cells"];
  return $owner_first$({$: "Tuple", fst: _array_0, snd: _array_0[0 % _array_0.length]});
}

function $successful$(_owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  const _x_0 = ($show$(_right_0));
  const _x_1 = ($show$(_left_0));
  const _x_2 = (":" + _x_0);
  const _x_3 = (_x_1 + _x_2);
  return ("ok:" + _x_3);
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058merge_checked$1260$(_result_0, _entries_0, _left_0, _right_0) {
  if (_result_0.$ === "../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../src/ecs/schema-fragments.Rejected", "error": _error_0, "left": _left_0, "right": _right_0};
  } else {
    const _l_0 = _left_0["owners"];
    const _r_0 = _right_0["owners"];
    return {$: "../../src/ecs/schema-fragments.Merged", "fragment": {$: "../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": {$: "Tuple", "fst": _l_0, "snd": _r_0}}};
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(_first_0, _second_0) {
  if (_first_0.$ === "../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _first_0["error"];
    return {$: "../../src/ecs/schema-fragments.Invalid", "error": _error_0};
  } else {
    return _second_0;
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058validate$1260$(_entries_0) {
  return $$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../src/ecs/schema-fragments.Component"})), {$: "Nil"})), ($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../src/ecs/schema-fragments.Resource"})), {$: "Nil"})), ($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../src/ecs/schema-fragments.Event"})), {$: "Nil"})), ($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../src/ecs/schema-fragments.Relation"})), {$: "Nil"})), run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_entries_0, {$: "../../src/ecs/schema-fragments.Service"})), {$: "Nil"})))))))));
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058merge_checked$1261$(_result_0, _entries_0, _left_0, _right_0) {
  if (_result_0.$ === "../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../src/ecs/schema-fragments.Rejected", "error": _error_0, "left": _left_0, "right": _right_0};
  } else {
    const _l_0 = _left_0["owners"];
    const _r_0 = _right_0["owners"];
    return {$: "../../src/ecs/schema-fragments.Merged", "fragment": {$: "../../src/ecs/schema-fragments.Fragment", "entries": _entries_0, "owners": {$: "Tuple", "fst": _l_0, "snd": _r_0}}};
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058validate$1261$(_entries_0) {
  return $$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../src/ecs/schema-fragments.Component"})), {$: "Nil"})), ($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../src/ecs/schema-fragments.Resource"})), {$: "Nil"})), ($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../src/ecs/schema-fragments.Event"})), {$: "Nil"})), ($$$$047$$$047src$047ecs$047schema$045fragments$058first_failure$(run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../src/ecs/schema-fragments.Relation"})), {$: "Nil"})), run_loop($$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_entries_0, {$: "../../src/ecs/schema-fragments.Service"})), {$: "Nil"})))))))));
}

function $owner_first$(_value_0) {
  const _array_0 = _value_0["fst"];
  const _first_0 = _value_0["snd"];
  return $owner_last$({$: "Tuple", fst: _array_0, snd: _array_0[1 % _array_0.length]}, _first_0);
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(_xs_0, _seen_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "../../src/ecs/schema-fragments.Valid"};
  } else {
    const _item_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047src$047ecs$047schema$045fragments$058validation_continue$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058check_one$1260$(_seen_0, _item_0)), run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1260$(_rest_0, {$: "Con", "head": _item_0, "tail": _seen_0});
}));
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_xs_0, _kind_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _xs_0["head"];
    const _itemKind_0 = _t_0["kind"];
    const _key_0 = _t_0["key"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind_done$1260$(($$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _itemKind_0)), {$: "../../src/ecs/schema-fragments.Entry", "kind": _itemKind_0, "key": _key_0, "name": _name_0}, ($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1260$(_rest_0, _kind_0)));
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(_xs_0, _seen_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "../../src/ecs/schema-fragments.Valid"};
  } else {
    const _item_0 = _xs_0["head"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047src$047ecs$047schema$045fragments$058validation_continue$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058check_one$1261$(_seen_0, _item_0)), run_clo((_x_0) => {
  return $$$$047$$$047src$047ecs$047schema$045fragments$058validate_loop$1261$(_rest_0, {$: "Con", "head": _item_0, "tail": _seen_0});
}));
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_xs_0, _kind_0) {
  if (_xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _xs_0["head"];
    const _itemKind_0 = _t_0["kind"];
    const _key_0 = _t_0["key"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    return $$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind_done$1261$(($$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _itemKind_0)), {$: "../../src/ecs/schema-fragments.Entry", "kind": _itemKind_0, "key": _key_0, "name": _name_0}, ($$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind$1261$(_rest_0, _kind_0)));
  }
}

function $owner_last$(_value_0, _first_0) {
  const _last_0 = _value_0["snd"];
  const _x_0 = ($U32$show$(_last_0));
  const _x_1 = ($U32$show$(_first_0));
  const _x_2 = ("," + _x_0);
  return (_x_1 + _x_2);
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058validation_continue$1260$(_result_0, _next_0) {
  if (_result_0.$ === "../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../src/ecs/schema-fragments.Invalid", "error": _error_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058check_one$1260$(_seen_0, _item_0) {
  const _kind_0 = _item_0["kind"];
  const _key_0 = _item_0["key"];
  const _name_0 = _item_0["name"];
  return $$$$047$$$047src$047ecs$047schema$045fragments$058check_entry$(($$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1260$(_seen_0, _kind_0, _key_0)), ($$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1260$(_seen_0, _kind_0, _name_0)), _kind_0, _key_0, _name_0);
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind_done$1260$(_selected_0, _item_0, _rest_0) {
  if (_selected_0) {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_a_0, _b_0) {
  if (_a_0.$ === "../../src/ecs/schema-fragments.Component") {
    if (_b_0.$ === "../../src/ecs/schema-fragments.Component") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../src/ecs/schema-fragments.Resource") {
    if (_b_0.$ === "../../src/ecs/schema-fragments.Resource") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../src/ecs/schema-fragments.Event") {
    if (_b_0.$ === "../../src/ecs/schema-fragments.Event") {
      return true;
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../src/ecs/schema-fragments.Relation") {
    if (_b_0.$ === "../../src/ecs/schema-fragments.Relation") {
      return true;
    } else {
      return false;
    }
  } else {
    if (_b_0.$ === "../../src/ecs/schema-fragments.Service") {
      return true;
    } else {
      return false;
    }
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058validation_continue$1261$(_result_0, _next_0) {
  if (_result_0.$ === "../../src/ecs/schema-fragments.Invalid") {
    const _error_0 = _result_0["error"];
    return {$: "../../src/ecs/schema-fragments.Invalid", "error": _error_0};
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058check_one$1261$(_seen_0, _item_0) {
  const _kind_0 = _item_0["kind"];
  const _key_0 = _item_0["key"];
  const _name_0 = _item_0["name"];
  return $$$$047$$$047src$047ecs$047schema$045fragments$058check_entry$(($$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1261$(_seen_0, _kind_0, _key_0)), ($$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1261$(_seen_0, _kind_0, _name_0)), _kind_0, _key_0, _name_0);
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058filter_kind_done$1261$(_selected_0, _item_0, _rest_0) {
  if (_selected_0) {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  } else {
    return _rest_0;
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058check_entry$(_keyConflict_0, _nameConflict_0, _kind_0, _key_0, _name_0) {
  if (_keyConflict_0) {
    return {$: "../../src/ecs/schema-fragments.Invalid", "error": {$: "../../src/ecs/schema-fragments.DuplicateKey", "kind": _kind_0, "key": _key_0}};
  } else {
    if (_nameConflict_0) {
      return {$: "../../src/ecs/schema-fragments.Invalid", "error": {$: "../../src/ecs/schema-fragments.DuplicateName", "kind": _kind_0, "name": _name_0}};
    } else {
      return {$: "../../src/ecs/schema-fragments.Valid"};
    }
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1260$(_xs_0, _kind_0, _key_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _other_0 = _t_0["kind"];
    const _otherKey_0 = _t_0["key"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($Bool$and$(($$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_key_0, _otherKey_0))));
    const _x_1 = ($$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1260$(_rest_0, _kind_0, _key_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1260$(_xs_0, _kind_0, _name_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _other_0 = _t_0["kind"];
    const _otherName_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($Bool$and$(($$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_name_0, _otherName_0))));
    const _x_1 = ($$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1260$(_rest_0, _kind_0, _name_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1261$(_xs_0, _kind_0, _key_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _other_0 = _t_0["kind"];
    const _otherKey_0 = _t_0["key"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($Bool$and$(($$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_key_0, _otherKey_0))));
    const _x_1 = ($$$$047$$$047src$047ecs$047schema$045fragments$058key_exists$1261$(_rest_0, _kind_0, _key_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1261$(_xs_0, _kind_0, _name_0) {
  if (_xs_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _xs_0["head"];
    const _other_0 = _t_0["kind"];
    const _otherName_0 = _t_0["name"];
    const _rest_0 = _xs_0["tail"];
    const _x_0 = ($Bool$and$(($$$$047$$$047src$047ecs$047schema$045fragments$058same_kind$(_kind_0, _other_0)), ($String$eq$(_name_0, _otherName_0))));
    const _x_1 = ($$$$047$$$047src$047ecs$047schema$045fragments$058name_exists$1261$(_rest_0, _kind_0, _name_0));
    return (_x_0 || _x_1);
  }
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);