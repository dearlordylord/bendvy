function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
(() => {
// Shared across independently emitted modules in the same host JS realm.
// This registry is trusted host infrastructure, not gameplay authority.
const bendvy_namespace_slot = Symbol.for("bendvy.world.namespace.v1");
if (!Object.prototype.hasOwnProperty.call(globalThis, bendvy_namespace_slot)) {
  Object.defineProperty(globalThis, bendvy_namespace_slot, {
    value: { next: 1 }, writable: false, configurable: false, enumerable: false
  });
}
function bendvy_namespace_fresh() {
  const state = globalThis[bendvy_namespace_slot];
  if (state.next >= 0xffffffff) return 0;
  return state.next++;
}
io_eff("../../../src/ecs/world-namespace.fresh", bendvy_namespace_fresh);

})();

(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

io_eff("IO.print", io_print);

})();

for (const k of ["../../../src/ecs/world-namespace.fresh","IO.print"]) {
  if (!(k in $0eff)) {
    throw new Error("bend: no effect registers " + k);
  }
}

// Program
// =======

function $main$() {
  return run_clo((_x_0) => {
  return $IO$bind$(($$$$047$$$047$$$047src$047ecs$047world$045io$058create$1260$(10)), run_clo((_x_1) => {
  return $created$(_x_1);
}), _x_0);
});
}

function $IO$bind$(_m_0, _f_0, _k_0) {
  return run_tail(_m_0, run_clo((_x_0) => {
  return run_tail(_f_0(_x_0), _k_0);
}));
}

function $$$$047$$$047$$$047src$047ecs$047world$045io$058create$1260$(_resource_0) {
  return run_clo((_x_0) => {
  return $IO$bind$((_x_1) => $$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_x_1), run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1260$(_x_2, _resource_0);
}), _x_0);
});
}

function $created$(_value_0) {
  if (_value_0.$ === "../../../src/ecs/world-io.Created") {
    const _world_0 = _value_0["world"];
    return (_x_0) => $IO$print$(($local$045driver$058start$(_world_0)), _x_0);
  } else {
    return run_clo((_x_1) => {
  return $IO$die$(1, "world creation refused", _x_1);
});
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$045namespace$058fresh$(_k_0) {
  return { $: "$FFI", run: $0eff["../../../src/ecs/world-namespace.fresh"].run, need: $0eff["../../../src/ecs/world-namespace.fresh"].need, args: [], kont: (_k_0) };
}
function $$$$047$$$047$$$047src$047ecs$047world$045io$058with_namespace$1260$(_namespace_0, _resource_0) {
  return run_clo((_x_0) => {
  return $IO$pure$(($$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1260$(($$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(($Bool$and$((0 < _namespace_0), (_namespace_0 < 4294967295))), _namespace_0, _resource_0)))), _x_0);
});
}

function $IO$print$(_text_0, _k_0) {
  return { $: "$FFI", run: $0eff["IO.print"].run, need: $0eff["IO.print"].need, args: [(_text_0)], kont: (_k_0) };
}
function $local$045driver$058start$(_world_0) {
  return $local$045driver$058registered$(($local$045fixture$058register$(_world_0)));
}

function $IO$die$(_code_0, _msg_0, _k_0) {
  return {$: "Halt", "code": _code_0, "message": _msg_0};
}

function $IO$pure$(_x_0, _k_0) {
  return run_tail(_k_0, _x_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$045io$058convert$1260$(_created_0) {
  if (_created_0.$ === "../../../src/ecs/world.Created") {
    const _world_0 = _created_0["world"];
    return {$: "../../../src/ecs/world-io.Created", "world": _world_0};
  } else {
    const _resource_0 = _created_0["resource"];
    return {$: "../../../src/ecs/world-io.Refused", "resource": _resource_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058create_checked$1260$(_available_0, _namespace_0, _resource_0) {
  if (!_available_0) {
    return {$: "../../../src/ecs/world.CreateRejected", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": _namespace_0}, "resource": _resource_0};
  } else {
    return {$: "../../../src/ecs/world.Created", "factory": {$: "../../../src/ecs/world.Factory", "nextNamespace": ((_namespace_0 + 1) >>> 0)}, "world": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": ($$$$047$$$047$$$047src$047ecs$047entity$045allocator$058empty$()), "store": ($empty$({$: "Unit"})), "resource": _resource_0, "events": {$: "Nil"}, "pending": {$: "Nil"}, "registrations": {$: "Nil"}, "nextSystemId": 1, "clock": 0}};
  }
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $local$045driver$058registered$(_value_0) {
  if (_value_0.$ === "../../../src/ecs/ordinary-app-local-fields.Appended") {
    const _app_0 = _value_0["app"];
    return $local$045driver$058attached$(($local$045fixture$058attach$(_app_0)));
  } else {
    return "ERROR: registration";
  }
}

function $local$045fixture$058register$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058add$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty$1260$(_world_0)), "Local count", array_node([0], [1]), {$: "Unit"});
}

function $$$$047$$$047$$$047src$047ecs$047entity$045allocator$058empty$() {
  const _x_0 = {$: "../../../src/ecs/entity-allocator.Slot", "generation": 0, "phase": {$: "../../../src/ecs/entity-allocator.Consumed"}};
  return {$: "../../../src/ecs/entity-allocator.Allocator", "next": 1, "high": 0, "slots": array_new(0, _x_0), "capacity": 1, "depth": 0, "free": {$: "Nil"}, "order": {$: "Nil"}};
}

function $empty$(_value_0) {
  return _value_0;
}

function $local$045driver$058attached$(_value_0) {
  if (_value_0.$ === "../../../src/ecs/ordinary-app-schedule.Attached") {
    const _app_0 = _value_0["app"];
    return $local$045driver$058failed$(($local$045fixture$058run$(_app_0)));
  } else {
    return "ERROR: attach";
  }
}

function $local$045fixture$058attach$(_value_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058attach$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045schema$058resource_schema$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045schema$058resource$1260$("Count")))), _value_0, "Local retry", false);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058add$1260$(_value_0, _name_0, _local_0, _args_0) {
  const _t_0 = _value_0["app"];
  const _world_0 = _t_0["world"];
  const _previous_0 = _t_0["owners"];
  const _recipe_0 = _t_0["recipe"];
  const _debug_0 = _t_0["debug"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_added$1260$(_args_0, _previous_0, _recipe_0, _debug_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058define$1260$(_world_0, _name_0, _local_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty$1260$(_world_0) {
  return {$: "../../../src/ecs/ordinary-app-execution-recipe.Registered", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0)), "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}};
}

function $local$045driver$058failed$(_value_0) {
  const _t_0 = _value_0["result"];
  if (_t_0.$ === "../../../src/ecs/ordinary-app-schedule.Failed") {
    const _app_0 = _t_0["app"];
    const _t_1 = _t_0["error"];
    if (_t_1.$ === "../../../src/ecs/captured-schedule-composition.RightError") {
      const _t_2 = _t_1["error"];
      if (_t_2.$ === "../../../src/ecs/ordinary-app-local-fields.CallbackFailure") {
        const _t_3 = _t_2["error"];
        return $local$045driver$058observed$(run_clo((_x_0) => {
  return $local$045driver$058retry$(_x_0);
}), "failed", ($local$045fixture$058observed$(_app_0)));
      } else {
        return "ERROR: expected failure";
      }
    } else {
      return "ERROR: expected failure";
    }
  } else {
    return "ERROR: expected failure";
  }
}

function $local$045fixture$058run$(_app_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058run$1260$(_app_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058attach$1260$(_schema_0, _value_0, _name_0, _barrier_0) {
  const _t_0 = _value_0["app"];
  const _world_0 = _t_0["world"];
  const _owners_0 = _t_0["owners"];
  const _recipe_0 = _t_0["recipe"];
  const _debug_0 = _t_0["debug"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058planned$1260$(_schema_0, _world_0, _recipe_0, _debug_0, _name_0, _barrier_0, ($local$045fixture$058planner$())(_owners_0));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045schema$058resource_schema$1260$(_declaration_0) {
  const _key_0 = ($$$$047$$$047$$$047src$047ecs$047ordinary$045schema$058resource_key$1260$(_declaration_0));
  return {$: "../../../src/ecs/ordinary-schema.Schema", "entries": {$: "Con", "head": {$: "../../../src/ecs/schema-fragments.Entry", "kind": {$: "../../../src/ecs/schema-fragments.Resource"}, "key": _key_0, "name": _key_0}, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045schema$058resource$1260$(_key_0) {
  return {$: "../../../src/ecs/ordinary-schema.Resource", "key": _key_0};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_added$1260$(_args_0, _previous_0, _recipe_0, _debug_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/ordinary-app-local-fields.Rejected") {
    const _world_0 = _result_0["world"];
    const _local_0 = _result_0["local"];
    return {$: "../../../src/ecs/ordinary-app-local-fields.AppendRejected", "app": {$: "../../../src/ecs/ordinary-app-execution-recipe.Registered", "app": {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _previous_0, "recipe": _recipe_0, "debug": _debug_0}, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}, "local": _local_0};
  } else {
    const _world_1 = _result_0["world"];
    const _owner_0 = _result_0["owner"];
    return {$: "../../../src/ecs/ordinary-app-local-fields.Appended", "app": {$: "../../../src/ecs/ordinary-app-execution-recipe.Registered", "app": {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_1, "owners": {$: "Tuple", "fst": _previous_0, "snd": {$: "../../../src/ecs/ordinary-app-local-fields.Invocation", "owner": _owner_0, "args": _args_0}}, "recipe": _recipe_0, "debug": _debug_0}, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058define$1260$(_world_0, _name_0, _local_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058registered$1260$(($$$$047$$$047$$$047src$047ecs$047local$058register$1260$(_world_0, _name_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058access$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058clause$1260$(($local$045fixture$058declaration$()))))), _local_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045composer$058empty$1260$(_world_0) {
  return {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Unit"}, "recipe": {$: "../../../src/ecs/ordinary-app-recipe.Recipe"}, "debug": false};
}

function $local$045driver$058observed$(_next_0, _label_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _local_0 = _value_0["snd"];
  return $local$045driver$058printed$(_next_0, _label_0, _local_0, ($local$045fixture$058resource$(_app_0)));
}

function $local$045driver$058retry$(_app_0) {
  const _x_0 = ($local$045driver$058retried$(($local$045fixture$058run$(_app_0))));
  return ("\n" + _x_0);
}

function $local$045fixture$058observed$(_app_0) {
  const _t_0 = _app_0["app"];
  const _t_1 = _t_0["app"];
  const _schema_0 = _t_1["schema"];
  const _t_2 = _t_1["app"];
  const _world_0 = _t_2["world"];
  const _t_3 = _t_2["owners"];
  const _prior_0 = _t_3["fst"];
  const _t_4 = _t_3["snd"];
  const _t_5 = _t_4["owner"];
  const _t_6 = _t_5["instance"];
  const _namespace_0 = _t_6["namespace"];
  const _id_0 = _t_6["id"];
  const _name_0 = _t_6["name"];
  const _access_0 = _t_6["access"];
  const _local_0 = _t_6["local"];
  const _args_0 = _t_4["args"];
  const _recipe_0 = _t_2["recipe"];
  const _debug_0 = _t_2["debug"];
  const _plan_0 = _t_0["plan"];
  const _scheduleNamespace_0 = _t_0["namespace"];
  const _scheduleName_0 = _t_0["name"];
  const _steps_0 = _t_0["steps"];
  const _needs_0 = _t_0["needs"];
  return $local$045fixture$058restored$(_schema_0, _world_0, _prior_0, _namespace_0, _id_0, _name_0, _access_0, _args_0, _recipe_0, _debug_0, _plan_0, _scheduleNamespace_0, _scheduleName_0, _steps_0, _needs_0, ($local$045fixture$058local_observed$(_local_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058run$1260$(_value_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058run_when$1260$(_value_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058planned$1260$(_schema_0, _world_0, _recipe_0, _debug_0, _name_0, _barrier_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _selected_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058folded$1260$(_schema_0, _world_0, _recipe_0, _debug_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058initial$1260$(_barrier_0, _selected_0)), _name_0, ($local$045fixture$058folder$())(_owners_0));
}

function $local$045fixture$058planner$() {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058composed_plan$1260$();
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045schema$058resource_key$1260$(_value_0) {
  const _key_0 = _value_0["key"];
  return _key_0;
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058registered$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/local.Registered") {
    const _world_0 = _result_0["world"];
    const _instance_0 = _result_0["instance"];
    return {$: "../../../src/ecs/ordinary-app-local-fields.Registered", "world": _world_0, "owner": {$: "../../../src/ecs/ordinary-app-local-fields.Owner", "instance": _instance_0}};
  } else {
    const _world_1 = _result_0["world"];
    const _local_0 = _result_0["local"];
    return {$: "../../../src/ecs/ordinary-app-local-fields.Rejected", "world": _world_1, "local": _local_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047local$058register$1260$(_world_0, _name_0, _access_0, _local_0) {
  return $$$$047$$$047$$$047src$047ecs$047local$058register_named$1260$(($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)), _name_0, _access_0, _local_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058access$1260$(_value_0) {
  const _name_0 = _value_0["name"];
  return {$: "Con", "head": _name_0, "tail": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058clause$1260$(_declaration_0) {
  const _identity_0 = _declaration_0["identity"];
  const _kind_0 = _declaration_0["kind"];
  return {$: "../../../src/ecs/ordinary-query-declaration.Clause", "name": ($$$$047$$$047$$$047src$047ecs$047ordinary$045schema$058resource_key$1260$(_identity_0)), "mode": _kind_0};
}

function $local$045fixture$058declaration$() {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058write$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045schema$058resource$1260$("Count")));
}

function $local$045driver$058printed$(_next_0, _label_0, _local_0, _value_0) {
  const _app_0 = _value_0["fst"];
  const _resource_0 = _value_0["snd"];
  const _x_0 = _next_0(_app_0);
  const _x_1 = (_local_0 + _x_0);
  const _x_2 = ($U32$show$(_resource_0));
  const _x_3 = (" local=" + _x_1);
  const _x_4 = (_x_2 + _x_3);
  const _x_5 = (" resource=" + _x_4);
  return (_label_0 + _x_5);
}

function $local$045fixture$058resource$(_app_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058inspect$1260$(_app_0);
}

function $local$045driver$058retried$(_value_0) {
  const _t_0 = _value_0["result"];
  if (_t_0.$ === "../../../src/ecs/ordinary-app-schedule.Finished") {
    const _app_0 = _t_0["app"];
    return $local$045driver$058observed$(run_clo((_x_0) => {
  return "";
}), "retried", ($local$045fixture$058observed$(_app_0)));
  } else {
    return "ERROR: retry";
  }
}

function $local$045fixture$058restored$(_schema_0, _world_0, _prior_0, _namespace_0, _id_0, _name_0, _access_0, _args_0, _recipe_0, _debug_0, _plan_0, _scheduleNamespace_0, _scheduleName_0, _steps_0, _needs_0, _result_0) {
  const _local_0 = _result_0["fst"];
  const _text_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-run.Application", "app": {$: "../../../src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": {$: "Tuple", "fst": _prior_0, "snd": {$: "../../../src/ecs/ordinary-app-local-fields.Invocation", "owner": {$: "../../../src/ecs/ordinary-app-local-fields.Owner", "instance": {$: "../../../src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}}, "args": _args_0}}, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _scheduleNamespace_0, "name": _scheduleName_0, "steps": _steps_0, "needs": _needs_0}, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}, "snd": _text_0};
}

function $local$045fixture$058local_observed$(_owner_0) {
  return $local$045fixture$058count_observed$({$: "Tuple", fst: _owner_0, snd: _owner_0[0 % _owner_0.length]});
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058run_when$1260$(_value_0) {
  const _app_0 = _value_0["app"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058executed$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058run$1260$(_app_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058folded$1260$(_schema_0, _world_0, _recipe_0, _debug_0, _selected_0, _name_0, _result_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  const _owners_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058checked$1260$(($$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058identities_valid$(_namespace_0, _registrations_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058identities$1260$(_fields_0)), {$: "Nil"})), _schema_0, {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _owners_0, _recipe_0, _debug_0, _selected_0, _namespace_0, _name_0, ($$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058ids$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058identities$1260$(_fields_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058initial$1260$(_barrier_0, _plan_0) {
  if (!_barrier_0) {
    return _plan_0;
  } else {
    return {$: "../../../src/ecs/schedule-provision.Sequence", "left": {$: "../../../src/ecs/schedule-provision.Entry", "step": {$: "../../../src/ecs/schedule.Barrier"}, "requirements": {$: "Nil"}}, "right": _plan_0};
  }
}

function $local$045fixture$058folder$() {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_fold$1260$();
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058composed_plan$1260$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058plan_pair$1260$(_x_0);
});
}

function $$$$047$$$047$$$047src$047ecs$047local$058register_named$1260$(_named_0, _name_0, _access_0, _local_0) {
  const _world_0 = _named_0["fst"];
  const _namespace_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047local$058register_result$1260$(($$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0)), _namespace_0, _name_0, _access_0, _local_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _namespace_0};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058write$1260$(_identity_0) {
  return {$: "../../../src/ecs/ordinary-resource-system.Declaration", "identity": _identity_0, "kind": {$: "../../../src/ecs/ordinary-query-declaration.Write"}, "grant": {$: "../../../src/ecs/capabilities.ValueWrite", "get": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047resource$058tx_get$1260$(_x_0);
}), "set": run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047resource$058tx_replace$1260$(_x_1, _x_2);
});
})}};
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058inspect$1260$(_value_0) {
  const _t_0 = _value_0["app"];
  const _t_1 = _t_0["app"];
  const _schema_0 = _t_1["schema"];
  const _t_2 = _t_1["app"];
  const _world_0 = _t_2["world"];
  const _owners_0 = _t_2["owners"];
  const _recipe_0 = _t_2["recipe"];
  const _debug_0 = _t_2["debug"];
  const _selected_0 = _t_0["plan"];
  const _namespace_0 = _t_0["namespace"];
  const _name_0 = _t_0["name"];
  const _steps_0 = _t_0["steps"];
  const _needs_0 = _t_0["needs"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058inspected$1260$(_schema_0, _owners_0, _recipe_0, _debug_0, _selected_0, _namespace_0, _name_0, _steps_0, _needs_0, ($local$045fixture$058resource_world$(_world_0)));
}

function $local$045fixture$058count_observed$(_result_0) {
  const _owner_0 = _result_0["fst"];
  const _count_0 = _result_0["snd"];
  return $local$045fixture$058flag_observed$(_count_0, {$: "Tuple", fst: _owner_0, snd: _owner_0[1 % _owner_0.length]});
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058executed$1260$(_result_0) {
  const _result_1 = _result_0["result"];
  const _batch_0 = _result_0["batch"];
  return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058returned$1260$(_result_1)), "batch": _batch_0};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058run$1260$(_value_0) {
  const _t_0 = _value_0["app"];
  const _schema_0 = _t_0["schema"];
  const _t_1 = _t_0["app"];
  const _world_0 = _t_1["world"];
  const _owners_0 = _t_1["owners"];
  const _recipe_0 = _t_1["recipe"];
  const _t_2 = _t_1["debug"];
  if (!_t_2) {
    const _plan_0 = _value_0["plan"];
    const _namespace_0 = _value_0["namespace"];
    const _name_0 = _value_0["name"];
    const _steps_0 = _value_0["steps"];
    const _needs_0 = _value_0["needs"];
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058start$1260$(_schema_0, _world_0, _recipe_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _owners_0, {$: "../../../src/ecs/ordinary-app-execution.Off"});
  } else {
    const _plan_1 = _value_0["plan"];
    const _namespace_1 = _value_0["namespace"];
    const _name_1 = _value_0["name"];
    const _steps_1 = _value_0["steps"];
    const _needs_1 = _value_0["needs"];
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058prepared$1260$(_schema_0, _world_0, _recipe_0, _plan_1, _namespace_1, _name_1, _steps_1, _needs_1, ($local$045fixture$058folder$())(_owners_0));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058checked$1260$(_valid_0, _schema_0, _world_0, _owners_0, _recipe_0, _debug_0, _selected_0, _namespace_0, _name_0, _ids_0) {
  if (!_valid_0) {
    return {$: "../../../src/ecs/ordinary-app-schedule.Invalid", "app": {$: "../../../src/ecs/ordinary-app-execution-recipe.Registered", "app": {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}};
  } else {
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058built$1260$(_schema_0, _world_0, _recipe_0, _debug_0, _selected_0, ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058build$1260$(_namespace_0, _name_0, _selected_0, _ids_0, _owners_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058identities_valid$(_namespace_0, _registered_0, _items_0, _seen_0) {
  if (_items_0.$ === "Nil") {
    return true;
  } else {
    const _t_0 = _items_0["head"];
    const _ns_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _rest_0 = _items_0["tail"];
    return $Bool$and$((_namespace_0 === _ns_0), ($Bool$and$(($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registered_0, _id_0, _name_0, _access_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058identities_valid$(_namespace_0, _registered_0, _rest_0, {$: "Con", "head": _id_0, "tail": _seen_0})))))));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058identities$1260$(_fields_0) {
  if (_fields_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _fields_0["head"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _access_0 = _t_0["access"];
    const _rest_0 = _fields_0["tail"];
    return {$: "Con", "head": {$: "../../../src/ecs/captured-schedule-composition.Identity", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0}, "tail": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058identities$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058ids$(_items_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _items_0["head"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _items_0["tail"];
    return {$: "Con", "head": _id_0, "tail": ($$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058ids$(_rest_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_fold$1260$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058fold_pair$1260$(_x_0);
});
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058plan_pair$1260$(_owners_0) {
  const _a_0 = _owners_0["fst"];
  const _b_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058plan_left$1260$(_b_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty_plan$1260$(_a_0)));
}

function $$$$047$$$047$$$047src$047ecs$047local$058register_result$1260$(_registered_0, _namespace_0, _name_0, _access_0, _local_0) {
  const _world_0 = _registered_0["fst"];
  const _t_0 = _registered_0["snd"];
  if (_t_0.$ === "../../../src/ecs/world.Registered") {
    const _id_0 = _t_0["id"];
    return {$: "../../../src/ecs/local.Registered", "world": _world_0, "instance": {$: "../../../src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}};
  } else {
    return {$: "../../../src/ecs/local.RegistrationRejected", "world": _world_0, "local": _local_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058register$1260$(_world_0, _name_0, _access_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$((_nextSystemId_0 < 4294967295), {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _name_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058tx_get$1260$(_tx_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  const _trace_0 = _tx_0["trace"];
  return $$$$047$$$047$$$047src$047ecs$047resource$058get_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1260$(_world_0)), _undo_0, _commands_0, _events_0, _trace_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058tx_replace$1260$(_tx_0, _replacement_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  const _trace_0 = _tx_0["trace"];
  return $$$$047$$$047$$$047src$047ecs$047resource$058replace_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, _replacement_0)), _undo_0, _commands_0, _events_0, _trace_0);
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058inspected$1260$(_schema_0, _owners_0, _recipe_0, _debug_0, _selected_0, _namespace_0, _name_0, _steps_0, _needs_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-run.Application", "app": {$: "../../../src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _selected_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}, "snd": _value_0};
}

function $local$045fixture$058resource_world$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _value_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _value_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $local$045fixture$058flag_observed$(_first_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _flag_0 = _result_0["snd"];
  const _x_0 = ($U32$show$(_flag_0));
  const _x_1 = ($U32$show$(_first_0));
  const _x_2 = ("," + _x_0);
  return {$: "Tuple", "fst": _owner_0, "snd": (_x_1 + _x_2)};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058returned$1260$(_result_0) {
  if (_result_0.$ === "../../../src/ecs/ordinary-app-schedule.Finished") {
    const _app_0 = _result_0["app"];
    const _observations_0 = _result_0["observations"];
    return {$: "../../../src/ecs/ordinary-app-schedule.Finished", "app": {$: "../../../src/ecs/ordinary-app-run.Application", "app": _app_0, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}, "observations": _observations_0};
  } else if (_result_0.$ === "../../../src/ecs/ordinary-app-schedule.Failed") {
    const _app_1 = _result_0["app"];
    const _error_0 = _result_0["error"];
    const _observations_1 = _result_0["observations"];
    return {$: "../../../src/ecs/ordinary-app-schedule.Failed", "app": {$: "../../../src/ecs/ordinary-app-run.Application", "app": _app_1, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}, "error": _error_0, "observations": _observations_1};
  } else if (_result_0.$ === "../../../src/ecs/ordinary-app-schedule.Rejected") {
    const _app_2 = _result_0["app"];
    return {$: "../../../src/ecs/ordinary-app-schedule.Rejected", "app": {$: "../../../src/ecs/ordinary-app-run.Application", "app": _app_2, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}};
  } else {
    const _app_3 = _result_0["app"];
    const _requirements_0 = _result_0["requirements"];
    return {$: "../../../src/ecs/ordinary-app-schedule.Missing", "app": {$: "../../../src/ecs/ordinary-app-run.Application", "app": _app_3, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}, "requirements": _requirements_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058start$1260$(_schema_0, _world_0, _recipe_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _owners_0, _state_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058provisioned$1260$(_schema_0, _recipe_0, _plan_0, ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058run_with_barrier$1260$({$: "../../../src/ecs/schedule-provision.Provisioned", "schedule": {$: "../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": {$: "Tuple", "fst": _owners_0, "snd": _state_0}}, "requirements": _needs_0}, _world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058prepared$1260$(_schema_0, _world_0, _recipe_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _value_0) {
  const _owners_0 = _value_0["fst"];
  const _fields_0 = _value_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058start$1260$(_schema_0, _world_0, _recipe_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0, _owners_0, {$: "../../../src/ecs/ordinary-app-execution.On", "journal": {$: "../../../src/ecs/ordinary-app-execution.Journal", "catalog": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058catalog$1260$(_fields_0)), "events": {$: "Nil"}}});
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058built$1260$(_schema_0, _world_0, _recipe_0, _debug_0, _selected_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/schedule-provision.Invalid") {
    const _owners_0 = _result_0["owners"];
    return {$: "../../../src/ecs/ordinary-app-schedule.Invalid", "app": {$: "../../../src/ecs/ordinary-app-execution-recipe.Registered", "app": {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}};
  } else {
    const _t_0 = _result_0["schedule"];
    const _t_1 = _t_0["schedule"];
    const _namespace_0 = _t_1["namespace"];
    const _name_0 = _t_1["name"];
    const _steps_0 = _t_1["steps"];
    const _owners_1 = _t_1["owners"];
    const _needs_0 = _t_0["requirements"];
    return {$: "../../../src/ecs/ordinary-app-schedule.Attached", "app": {$: "../../../src/ecs/ordinary-app-run.Application", "app": {$: "../../../src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_1, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _selected_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0}, "execution": {$: "../../../src/ecs/ordinary-app-execution-recipe.Recipe"}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058build$1260$(_namespace_0, _name_0, _plan_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058finish_build$1260$(($$$$047$$$047$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0)), _catalog_0, _owners_0)), ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058unique$1260$(($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$(_registrations_0, _id_0, _name_0, _access_0, false);
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_ids_0, _id_0) {
  if (_ids_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _ids_0["head"];
    const _rest_0 = _ids_0["tail"];
    const _x_0 = (_head_0 === _id_0);
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_rest_0, _id_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058fold_pair$1260$(_owners_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058pair$1260$(run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_x_0);
}), run_clo((_x_1) => {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_fields$1260$(_x_1);
}), _owners_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058plan_left$1260$(_owner_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058plan_right$1260$(_left_0, _before_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_plan$1260$(_owner_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty_plan$1260$(_owner_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../src/ecs/schedule-provision.Empty"}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058register_checked$1260$(_available_0, _world_0, _name_0, _access_0) {
  if (!_available_0) {
    return {$: "Tuple", "fst": _world_0, "snd": {$: "../../../src/ecs/world.RegistrationRejected", "error": {$: "../../../src/ecs/world.SystemIdExhausted"}}};
  } else {
    const _namespace_0 = _world_0["namespace"];
    const _allocator_0 = _world_0["allocator"];
    const _store_0 = _world_0["store"];
    const _resource_0 = _world_0["resource"];
    const _events_0 = _world_0["events"];
    const _pending_0 = _world_0["pending"];
    const _registrations_0 = _world_0["registrations"];
    const _nextSystemId_0 = _world_0["nextSystemId"];
    const _clock_0 = _world_0["clock"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": {$: "Con", "head": {$: "../../../src/ecs/world.RegistrationMeta", "id": _nextSystemId_0, "name": _name_0, "access": _access_0}, "tail": _registrations_0}, "nextSystemId": ((_nextSystemId_0 + 1) >>> 0), "clock": _clock_0}, "snd": {$: "../../../src/ecs/world.Registered", "id": _nextSystemId_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047resource$058get_join$1260$(_observed_0, _undo_0, _commands_0, _events_0, _trace_0) {
  const _world_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": _undo_0, "commands": _commands_0, "events": _events_0, "trace": _trace_0}, "snd": _value_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1260$(($local$045fixture$058project$(_resource_0)), _namespace_0, _allocator_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0);
}

function $$$$047$$$047$$$047src$047ecs$047resource$058replace_join$1260$(_replaced_0, _undo_0, _commands_0, _events_0, _trace_0) {
  const _world_0 = _replaced_0["fst"];
  const _old_0 = _replaced_0["snd"];
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Con", "head": run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047resource$058restore$1260$(_x_0, _old_0);
}), "tail": _undo_0}, "commands": _commands_0, "events": _events_0, "trace": _trace_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, _replacement_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _replacement_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _resource_0};
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058provisioned$1260$(_schema_0, _recipe_0, _plan_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/schedule-provision.Executed") {
    const _result_1 = _result_0["result"];
    const _needs_0 = _result_0["requirements"];
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058executed$1260$(_schema_0, _recipe_0, _plan_0, _needs_0, _result_1);
  } else {
    const _t_0 = _result_0["schedule"];
    const _t_1 = _t_0["schedule"];
    const _namespace_0 = _t_1["namespace"];
    const _name_0 = _t_1["name"];
    const _steps_0 = _t_1["steps"];
    const _t_2 = _t_1["owners"];
    const _owners_0 = _t_2["fst"];
    const _t_3 = _t_2["snd"];
    if (_t_3.$ === "../../../src/ecs/ordinary-app-execution.Off") {
      const _needs_1 = _t_0["requirements"];
      const _world_0 = _result_0["world"];
      const _missing_0 = _result_0["missing"];
      return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": {$: "../../../src/ecs/ordinary-app-schedule.Missing", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_0, _owners_0, _recipe_0, false, _plan_0, _namespace_0, _name_0, _steps_0, _needs_1)), "requirements": _missing_0}, "batch": {$: "../../../src/ecs/execution-trace.Disabled"}};
    } else {
      const _needs_2 = _t_0["requirements"];
      const _world_1 = _result_0["world"];
      const _missing_1 = _result_0["missing"];
      return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": {$: "../../../src/ecs/ordinary-app-schedule.Missing", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_1, _owners_0, _recipe_0, true, _plan_0, _namespace_0, _name_0, _steps_0, _needs_2)), "requirements": _missing_1}, "batch": {$: "../../../src/ecs/execution-trace.Ready", "events": {$: "Con", "head": {$: "../../../src/ecs/execution-trace.ScheduleAdmissionRefused", "namespace": _namespace_0, "name": _name_0, "outcome": {$: "../../../src/ecs/execution-trace.EndMissing"}}, "tail": {$: "Nil"}}}};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058run_with_barrier$1260$(_schedule_0, _world_0) {
  const _schedule_1 = _schedule_0["schedule"];
  const _needs_0 = _schedule_0["requirements"];
  return $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058run_available$1260$(($local$045fixture$058provisioner$())(_world_0), _schedule_1, _needs_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058catalog$1260$(_fields_0) {
  if (_fields_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _t_0 = _fields_0["head"];
    const _namespace_0 = _t_0["namespace"];
    const _id_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _fields_0["tail"];
    return {$: "Con", "head": {$: "../../../src/ecs/execution-trace.Identity", "namespace": _namespace_0, "id": _id_0, "name": {$: "Some", "value": _name_0}}, "tail": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058catalog$1260$(_rest_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058finish_build$1260$(_built_0, _needs_0) {
  if (_built_0.$ === "../../../src/ecs/schedule.Invalid") {
    const _owners_0 = _built_0["owners"];
    return {$: "../../../src/ecs/schedule-provision.Invalid", "owners": _owners_0};
  } else {
    const _schedule_0 = _built_0["schedule"];
    return {$: "../../../src/ecs/schedule-provision.Built", "schedule": {$: "../../../src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058build$1260$(_namespace_0, _name_0, _steps_0, _catalog_0, _owners_0) {
  return $$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1260$(($$$$047$$$047$$$047src$047ecs$047schedule$058valid$(_steps_0, _catalog_0, {$: "Nil"})), _namespace_0, _name_0, _steps_0, _owners_0);
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058flatten$1260$(_plan_0) {
  if (_plan_0.$ === "../../../src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../src/ecs/schedule-provision.Entry") {
    const _step_0 = _plan_0["step"];
    return {$: "Con", "head": _step_0, "tail": {$: "Nil"}};
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058flatten$1260$(_left_0)), ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058flatten$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058unique$1260$(_items_0) {
  return $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, {$: "Nil"});
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058requirements$1260$(_plan_0) {
  if (_plan_0.$ === "../../../src/ecs/schedule-provision.Empty") {
    return {$: "Nil"};
  } else if (_plan_0.$ === "../../../src/ecs/schedule-provision.Entry") {
    const _needs_0 = _plan_0["requirements"];
    return _needs_0;
  } else {
    const _left_0 = _plan_0["left"];
    const _right_0 = _plan_0["right"];
    return $List$append$(($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058requirements$1260$(_left_0)), ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058requirements$1260$(_right_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_list_walk$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _registrations_0 = $0;
      const _id_0 = $1;
      const _name_0 = $2;
      const _access_0 = $3;
      const _found_0 = $4;
      if (_registrations_0.$ === "Nil") {
        if (_found_0) {
          return true;
        } else {
          return false;
        }
      } else {
        const _meta_0 = _registrations_0["head"];
        const _rest_0 = _registrations_0["tail"];
        if (_found_0) {
          return true;
        } else {
          $0 = _rest_0;
          $1 = _id_0;
          $2 = _name_0;
          $3 = _access_0;
          $4 = ($$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058pair$1260$(_leftFold_0, _rightFold_0, _owners_0) {
  const _left_0 = _owners_0["fst"];
  const _right_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058first$1260$(_rightFold_0, _right_0, _leftFold_0(_left_0));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_unit_0) {
  return {$: "Tuple", "fst": _unit_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_fields$1260$(_value_0) {
  const _owner_0 = _value_0["owner"];
  const _args_0 = _value_0["args"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_folded$1260$(_args_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058fold$1260$(_owner_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058plan_right$1260$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": {$: "../../../src/ecs/schedule-provision.Sequence", "left": _before_0, "right": _after_0}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_plan$1260$(_value_0) {
  const _owner_0 = _value_0["owner"];
  const _args_0 = _value_0["args"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_planned$1260$(_args_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058fields$1260$(_owner_0)));
}

function $$$$047$$$047$$$047src$047ecs$047world$058observe_resource_finish$1260$(_observed_0, _namespace_0, _allocator_0, _store_0, _events_0, _pending_0, _registrations_0, _nextSystemId_0, _clock_0) {
  const _resource_0 = _observed_0["fst"];
  const _value_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _value_0};
}

function $local$045fixture$058project$(_value_0) {
  const _actual_0 = _value_0;
  return {$: "Tuple", "fst": _actual_0, "snd": _actual_0};
}

function $$$$047$$$047$$$047src$047ecs$047resource$058restore$1260$(_world_0, _old_0) {
  return $$$$047$$$047$$$047src$047ecs$047resource$058restore_join$1260$(($$$$047$$$047$$$047src$047ecs$047world$058replace_resource$1260$(_world_0, _old_0)));
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058executed$1260$(_schema_0, _recipe_0, _plan_0, _needs_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/schedule.Finished") {
    const _t_0 = _result_0["schedule"];
    const _namespace_0 = _t_0["namespace"];
    const _name_0 = _t_0["name"];
    const _steps_0 = _t_0["steps"];
    const _t_1 = _t_0["owners"];
    const _owners_0 = _t_1["fst"];
    const _t_2 = _t_1["snd"];
    if (_t_2.$ === "../../../src/ecs/ordinary-app-execution.Off") {
      const _world_0 = _result_0["world"];
      const _observations_0 = _result_0["observations"];
      return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": {$: "../../../src/ecs/ordinary-app-schedule.Finished", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_0, _owners_0, _recipe_0, false, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0)), "observations": _observations_0}, "batch": {$: "../../../src/ecs/execution-trace.Disabled"}};
    } else {
      const _journal_0 = _t_2["journal"];
      const _world_1 = _result_0["world"];
      const _observations_1 = _result_0["observations"];
      return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": {$: "../../../src/ecs/ordinary-app-schedule.Finished", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_1, _owners_0, _recipe_0, true, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0)), "observations": _observations_1}, "batch": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058batch$1260$(_namespace_0, _name_0, _observations_1, _journal_0, {$: "../../../src/ecs/execution-trace.EndOk"}))};
    }
  } else if (_result_0.$ === "../../../src/ecs/schedule.Failed") {
    const _t_3 = _result_0["schedule"];
    const _namespace_1 = _t_3["namespace"];
    const _name_1 = _t_3["name"];
    const _steps_1 = _t_3["steps"];
    const _t_4 = _t_3["owners"];
    const _owners_1 = _t_4["fst"];
    const _t_5 = _t_4["snd"];
    if (_t_5.$ === "../../../src/ecs/ordinary-app-execution.Off") {
      const _world_2 = _result_0["world"];
      const _error_0 = _result_0["error"];
      const _observations_2 = _result_0["observations"];
      return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": {$: "../../../src/ecs/ordinary-app-schedule.Failed", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_2, _owners_1, _recipe_0, false, _plan_0, _namespace_1, _name_1, _steps_1, _needs_0)), "error": _error_0, "observations": _observations_2}, "batch": {$: "../../../src/ecs/execution-trace.Disabled"}};
    } else {
      const _journal_1 = _t_5["journal"];
      const _world_3 = _result_0["world"];
      const _error_1 = _result_0["error"];
      const _observations_3 = _result_0["observations"];
      return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": {$: "../../../src/ecs/ordinary-app-schedule.Failed", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_3, _owners_1, _recipe_0, true, _plan_0, _namespace_1, _name_1, _steps_1, _needs_0)), "error": _error_1, "observations": _observations_3}, "batch": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058batch$1260$(_namespace_1, _name_1, _observations_3, _journal_1, {$: "../../../src/ecs/execution-trace.EndFailed", "error": _error_1}))};
    }
  } else {
    const _t_6 = _result_0["schedule"];
    const _namespace_2 = _t_6["namespace"];
    const _name_2 = _t_6["name"];
    const _steps_2 = _t_6["steps"];
    const _t_7 = _t_6["owners"];
    const _owners_2 = _t_7["fst"];
    const _t_8 = _t_7["snd"];
    if (_t_8.$ === "../../../src/ecs/ordinary-app-execution.Off") {
      const _world_4 = _result_0["world"];
      return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": {$: "../../../src/ecs/ordinary-app-schedule.Rejected", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_4, _owners_2, _recipe_0, false, _plan_0, _namespace_2, _name_2, _steps_2, _needs_0))}, "batch": {$: "../../../src/ecs/execution-trace.Disabled"}};
    } else {
      const _world_5 = _result_0["world"];
      return {$: "../../../src/ecs/ordinary-app-execution.Run", "result": {$: "../../../src/ecs/ordinary-app-schedule.Rejected", "app": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_5, _owners_2, _recipe_0, true, _plan_0, _namespace_2, _name_2, _steps_2, _needs_0))}, "batch": {$: "../../../src/ecs/execution-trace.Ready", "events": {$: "Con", "head": {$: "../../../src/ecs/execution-trace.ScheduleAdmissionRefused", "namespace": _namespace_2, "name": _name_2, "outcome": {$: "../../../src/ecs/execution-trace.EndRejected"}}, "tail": {$: "Nil"}}}};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058restored$1260$(_schema_0, _world_0, _owners_0, _recipe_0, _debug_0, _plan_0, _namespace_0, _name_0, _steps_0, _needs_0) {
  return {$: "../../../src/ecs/ordinary-app-schedule.Application", "app": {$: "../../../src/ecs/ordinary-app-schema.Application", "schema": _schema_0, "app": {$: "../../../src/ecs/ordinary-app-composer.Registered", "world": _world_0, "owners": _owners_0, "recipe": _recipe_0, "debug": _debug_0}}, "plan": _plan_0, "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "needs": _needs_0};
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058run_available$1260$(_observed_0, _schedule_0, _needs_0) {
  const _world_0 = _observed_0["fst"];
  const _available_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058run_checked$1260$(($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_needs_0, _available_0)), _schedule_0, _world_0, _needs_0);
}

function $local$045fixture$058provisioner$() {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_provide$1260$();
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058build_checked$1260$(_allowed_0, _namespace_0, _name_0, _steps_0, _owners_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/schedule.Invalid", "owners": _owners_0};
  } else {
    return {$: "../../../src/ecs/schedule.Built", "schedule": {$: "../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058valid$($0, $1, $2) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _catalog_0 = $1;
      const _seen_0 = $2;
      if (_steps_0.$ === "Nil") {
        return true;
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../src/ecs/schedule.Phase") {
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else if (_t_0.$ === "../../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          $0 = _rest_1;
          $1 = _catalog_0;
          $2 = _seen_0;
          continue;
        } else {
          const _id_0 = _t_0["id"];
          const _rest_2 = _steps_0["tail"];
          return $Bool$and$(($$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_catalog_0, _id_0)), ($Bool$and$(($Bool$not$(($$$$047$$$047$$$047src$047ecs$047schedule$058contains$(_seen_0, _id_0)))), ($$$$047$$$047$$$047src$047ecs$047schedule$058valid$(_rest_2, _catalog_0, {$: "Con", "head": _id_0, "tail": _seen_0})))));
        }
      }
    }
  }
}

function $List$append$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    return _ys_0;
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return {$: "Con", "head": _h_0, "tail": ($List$append$(_t_0, _ys_0))};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_items_0, _seen_0) {
  if (_items_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058unique_add$1260$(($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058contains$1260$(_seen_0, _head_0)), _head_0, ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058unique_seen$1260$(_rest_0, {$: "Con", "head": _head_0, "tail": _seen_0})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058registration_meta_matches$(_meta_0, _id_0, _name_0, _access_0) {
  const _mid_0 = _meta_0["id"];
  const _mname_0 = _meta_0["name"];
  const _maccess_0 = _meta_0["access"];
  return $$$$047$$$047$$$047src$047ecs$047world$058matching_id$((_mid_0 === _id_0), _mname_0, _name_0, _maccess_0, _access_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058first$1260$(_rightFold_0, _right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058second$1260$(_left_0, _before_0, _rightFold_0(_right_0));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_folded$1260$(_args_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-local-fields.Invocation", "owner": _owner_0, "args": _args_0}, "snd": _fields_0};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058fold$1260$(_value_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058fields_list_returned$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058fields$1260$(_value_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_planned$1260$(_args_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _id_0 = _t_0["id"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-local-fields.Invocation", "owner": _owner_0, "args": _args_0}, "snd": {$: "../../../src/ecs/schedule-provision.Entry", "step": {$: "../../../src/ecs/schedule.System", "id": _id_0, "condition": 0}, "requirements": {$: "Nil"}}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058fields$1260$(_value_0) {
  const _instance_0 = _value_0["instance"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058field_values$1260$(_instance_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058clause$1260$(($local$045fixture$058declaration$()))));
}

function $$$$047$$$047$$$047src$047ecs$047resource$058restore_join$1260$(_replaced_0) {
  const _world_0 = _replaced_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058batch$1260$(_namespace_0, _name_0, _observations_0, _journal_0, _outcome_0) {
  const _events_0 = _journal_0["events"];
  return {$: "../../../src/ecs/execution-trace.Ready", "events": {$: "Con", "head": {$: "../../../src/ecs/execution-trace.ScheduleStarted", "namespace": _namespace_0, "name": _name_0}, "tail": ($List$append$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merge$1260$(_observations_0, ($List$reverse$(_events_0)))), {$: "Con", "head": {$: "../../../src/ecs/execution-trace.ScheduleEnded", "outcome": _outcome_0}, "tail": {$: "Nil"}}))}};
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058run_checked$1260$(_missing_0, _schedule_0, _world_0, _needs_0) {
  if (_missing_0.$ === "Con") {
    const _first_0 = _missing_0["head"];
    const _rest_0 = _missing_0["tail"];
    return {$: "../../../src/ecs/schedule-provision.Missing", "schedule": {$: "../../../src/ecs/schedule-provision.Provisioned", "schedule": _schedule_0, "requirements": _needs_0}, "world": _world_0, "missing": {$: "Con", "head": _first_0, "tail": _rest_0}};
  } else {
    return {$: "../../../src/ecs/schedule-provision.Executed", "result": run_loop($$$$047$$$047$$$047src$047ecs$047schedule$058run_with_barrier$1260$(_schedule_0, _world_0)), "requirements": _needs_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_needs_0, _available_0) {
  if (_needs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const _head_0 = _needs_0["head"];
    const _rest_0 = _needs_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058missing_next$1260$(($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058contains$1260$(_available_0, _head_0)), _head_0, ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058missing_requirements$1260$(_rest_0, _available_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_provide$1260$() {
  return run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058provision_pair$1260$(_x_0);
});
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058unique_add$1260$(_present_0, _item_0, _rest_0) {
  if (_present_0) {
    return _rest_0;
  } else {
    return {$: "Con", "head": _item_0, "tail": _rest_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058contains$1260$(_items_0, _item_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _head_0 = _items_0["head"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058same$1260$(_head_0, _item_0));
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047schedule$045provision$058contains$1260$(_rest_0, _item_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_id$(_sameId_0, _metaName_0, _wantedName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameId_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_metaName_0, _wantedName_0)), _metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058second$1260$(_left_0, _before_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058fields_list_returned$1260$(_result_0) {
  const _value_0 = _result_0["fst"];
  const _field_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _value_0, "snd": {$: "Con", "head": _field_0, "tail": {$: "Nil"}}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058field_values$1260$(_instance_0, _clause_0) {
  const _namespace_0 = _instance_0["namespace"];
  const _id_0 = _instance_0["id"];
  const _name_0 = _instance_0["name"];
  const _access_0 = _instance_0["access"];
  const _local_0 = _instance_0["local"];
  const _slot_0 = _clause_0["name"];
  const _mode_0 = _clause_0["mode"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-local-fields.Owner", "instance": {$: "../../../src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}}, "snd": {$: "../../../src/ecs/ordinary-app-registration-fields.Fields", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "cursor": 0, "slot": _slot_0, "clauses": {$: "Con", "head": {$: "../../../src/ecs/ordinary-query-declaration.Clause", "name": _slot_0, "mode": _mode_0}, "tail": {$: "Nil"}}, "kind": {$: "../../../src/ecs/ordinary-app-registration-fields.ResourceKind", "mode": _mode_0}}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merge$1260$(_observations_0, _journal_0) {
  if (_observations_0.$ === "Nil") {
    return _journal_0;
  } else {
    const _t_0 = _observations_0["head"];
    if (_t_0.$ === "../../../src/ecs/schedule.Entered") {
      const _name_0 = _t_0["name"];
      const _rest_0 = _observations_0["tail"];
      return {$: "Con", "head": {$: "../../../src/ecs/execution-trace.PhaseEntered", "name": _name_0}, "tail": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merge$1260$(_rest_0, _journal_0))};
    } else if (_t_0.$ === "../../../src/ecs/schedule.Skipped") {
      const _id_0 = _t_0["id"];
      const _rest_1 = _observations_0["tail"];
      return {$: "Con", "head": {$: "../../../src/ecs/execution-trace.SystemSkipped", "id": _id_0}, "tail": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merge$1260$(_rest_1, _journal_0))};
    } else if (_t_0.$ === "../../../src/ecs/schedule.Applied") {
      const _rest_2 = _observations_0["tail"];
      return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merged_chunk$1260$(run_clo((_x_0) => {
  return {$: "Con", "head": {$: "../../../src/ecs/execution-trace.DeferredApplied"}, "tail": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merge$1260$(_rest_2, _x_0))};
}), ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_chunk$1260$(_journal_0)));
    } else {
      const _rest_3 = _observations_0["tail"];
      return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merged_chunk$1260$(run_clo((_x_1) => {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merge$1260$(_rest_3, _x_1);
}), ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058ran_chunk$1260$(_journal_0)));
    }
  }
}

function $List$reverse$(_xs_0) {
  return $List$reverse$go$(_xs_0, {$: "Nil"});
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058run_with_barrier$1260$(_schedule_0, _world_0) {
  return $$$$047$$$047$$$047src$047ecs$047schedule$058run_barrier_named$1260$(_schedule_0, ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058missing_next$1260$(_present_0, _item_0, _next_0) {
  if (!_present_0) {
    return {$: "Con", "head": _item_0, "tail": _next_0};
  } else {
    return _next_0;
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058provision_pair$1260$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058provision_left$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty_provide$1261$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047schedule$045provision$058same$1260$(_a_0, _b_0) {
  if (_a_0.$ === "../../../src/ecs/schedule-provision.Component") {
    const _a_1 = _a_0["id"];
    if (_b_0.$ === "../../../src/ecs/schedule-provision.Component") {
      const _b_1 = _b_0["id"];
      return (_a_1 === _b_1);
    } else {
      return false;
    }
  } else if (_a_0.$ === "../../../src/ecs/schedule-provision.Resource") {
    const _a_2 = _a_0["id"];
    if (_b_0.$ === "../../../src/ecs/schedule-provision.Resource") {
      const _b_2 = _b_0["id"];
      return (_a_2 === _b_2);
    } else {
      return false;
    }
  } else {
    const _a_3 = _a_0["id"];
    if (_b_0.$ === "../../../src/ecs/schedule-provision.Service") {
      const _b_3 = _b_0["id"];
      return (_a_3 === _b_3);
    } else {
      return false;
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058matching_access$(_sameName_0, _metaAccess_0, _wantedAccess_0) {
  if (!_sameName_0) {
    return false;
  } else {
    return $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_metaAccess_0, _wantedAccess_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(_a_0, _b_0) {
  return $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$(_a_0, _b_0, true);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058merged_chunk$1260$(_next_0, _chunk_0) {
  const _prefix_0 = _chunk_0["fst"];
  const _remaining_0 = _chunk_0["snd"];
  return $List$append$(_prefix_0, _next_0(_remaining_0));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_chunk$1260$(_journal_0) {
  if (_journal_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _journal_0["head"];
    if (_t_0.$ === "../../../src/ecs/execution-trace.BarrierOperationObserved") {
      const _fact_0 = _t_0["fact"];
      const _rest_0 = _journal_0["tail"];
      return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058ran_chunk_more$1260$({$: "../../../src/ecs/execution-trace.BarrierOperationObserved", "fact": _fact_0}, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_chunk$1260$(_rest_0)));
    } else {
      const _rest_1 = _journal_0["tail"];
      return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Con", "head": _t_0, "tail": _rest_1}};
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058ran_chunk$1260$(_journal_0) {
  if (_journal_0.$ === "Nil") {
    return {$: "Tuple", "fst": {$: "Nil"}, "snd": {$: "Nil"}};
  } else {
    const _t_0 = _journal_0["head"];
    if (_t_0.$ === "../../../src/ecs/execution-trace.OperationObserved") {
      const _identity_0 = _t_0["identity"];
      const _fact_0 = _t_0["fact"];
      const _rest_0 = _journal_0["tail"];
      return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058ran_chunk_more$1260$({$: "../../../src/ecs/execution-trace.OperationObserved", "identity": _identity_0, "fact": _fact_0}, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058ran_chunk$1260$(_rest_0)));
    } else {
      const _rest_1 = _journal_0["tail"];
      return {$: "Tuple", "fst": {$: "Con", "head": _t_0, "tail": {$: "Nil"}}, "snd": _rest_1};
    }
  }
}

function $List$reverse$go$($0, $1) {
  for (;;) {
    {
      const _xs_0 = $0;
      const _acc_0 = $1;
      if (_xs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _xs_0["head"];
        const _t_0 = _xs_0["tail"];
        $0 = _t_0;
        $1 = {$: "Con", "head": _h_0, "tail": _acc_0};
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058run_barrier_named$1260$(_schedule_0, _named_0) {
  const _world_0 = _named_0["fst"];
  const _actual_0 = _named_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047schedule$058run_barrier_actual$1260$(_schedule_0, _world_0, _actual_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058provision_left$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  const _before_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058provision_right$1260$(_before_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty_provide$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty_provide$1261$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
}

function $$$$047$$$047$$$047src$047ecs$047world$058access_equal$(_xs_0, _ys_0) {
  if (_xs_0.$ === "Nil") {
    if (_ys_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const __2 = _xs_0["head"];
    const __3 = _xs_0["tail"];
    if (_ys_0.$ === "Nil") {
      return false;
    } else {
      const _y_0 = _ys_0["head"];
      const _ys_1 = _ys_0["tail"];
      return $Bool$and$(($$$$047$$$047$$$047src$047ecs$047string$045equality$058equal$(__2, _y_0)), ($$$$047$$$047$$$047src$047ecs$047world$058access_equal$(__3, _ys_1)));
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047string$045equality$058equal_walk$($0, $1, $2) {
  for (;;) {
    {
      const _a_0 = $0;
      const _b_0 = $1;
      const _same_0 = $2;
      if (_a_0 === "") {
        if (_b_0 === "") {
          return _same_0;
        } else {
          return false;
        }
      } else {
        const __2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
        const __3 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
        if (_b_0 === "") {
          return false;
        } else {
          const _b_1 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
          const _bs_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
          $0 = __3;
          $1 = _bs_0;
          $2 = ($Bool$and$(_same_0, ($Char$is_eq$(__2, _b_1))));
          continue;
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058ran_chunk_more$1260$(_event_0, _chunk_0) {
  const _prefix_0 = _chunk_0["fst"];
  const _remaining_0 = _chunk_0["snd"];
  return {$: "Tuple", "fst": {$: "Con", "head": _event_0, "tail": _prefix_0}, "snd": _remaining_0};
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058run_barrier_actual$1260$(_schedule_0, _world_0, _actual_0) {
  const _namespace_0 = _schedule_0["namespace"];
  const _name_0 = _schedule_0["name"];
  const _steps_0 = _schedule_0["steps"];
  const _owners_0 = _schedule_0["owners"];
  return $$$$047$$$047$$$047src$047ecs$047schedule$058run_barrier_checked$1260$((_namespace_0 === _actual_0), {$: "../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _steps_0, "owners": _owners_0}, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058provision_right$1260$(_before_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _after_0 = _result_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": ($List$append$(_before_0, _after_0))};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty_provide$1260$(_world_0) {
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Nil"}};
}

function $Char$is_eq$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return (_x_0 === _x_1);
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058run_barrier_checked$1260$(_allowed_0, _schedule_0, _world_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/schedule.Rejected", "schedule": _schedule_0, "world": _world_0};
  } else {
    const _namespace_0 = _schedule_0["namespace"];
    const _name_0 = _schedule_0["name"];
    const _steps_0 = _schedule_0["steps"];
    const _owners_0 = _schedule_0["owners"];
    return $$$$047$$$047$$$047src$047ecs$047schedule$058execute_with_barrier$1260$(_steps_0, _owners_0, _world_0, _namespace_0, _name_0, _steps_0, {$: "Nil"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058execute_with_barrier$1260$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _steps_0 = $0;
      const _owners_0 = $1;
      const _world_0 = $2;
      const _namespace_0 = $3;
      const _name_0 = $4;
      const _all_0 = $5;
      const _observations_0 = $6;
      if (_steps_0.$ === "Nil") {
        return {$: "../../../src/ecs/schedule.Finished", "schedule": {$: "../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "observations": _observations_0};
      } else {
        const _t_0 = _steps_0["head"];
        if (_t_0.$ === "../../../src/ecs/schedule.Phase") {
          const _phase_0 = _t_0["name"];
          const _rest_0 = _steps_0["tail"];
          $0 = _rest_0;
          $1 = _owners_0;
          $2 = _world_0;
          $3 = _namespace_0;
          $4 = _name_0;
          $5 = _all_0;
          $6 = ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../src/ecs/schedule.Entered", "name": _phase_0}, "tail": {$: "Nil"}}));
          continue;
        } else if (_t_0.$ === "../../../src/ecs/schedule.Barrier") {
          const _rest_1 = _steps_0["tail"];
          return $$$$047$$$047$$$047src$047ecs$047schedule$058after_skip$1260$(run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047schedule$058execute_with_barrier$1260$(_rest_1, _x_0, _x_1, _namespace_0, _name_0, _all_0, _x_2);
});
});
}), ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_state$1260$(_owners_0, _world_0)), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../src/ecs/schedule.Applied"}, "tail": {$: "Nil"}})));
        } else {
          const _id_0 = _t_0["id"];
          const _slot_0 = _t_0["condition"];
          const _rest_2 = _steps_0["tail"];
          return $$$$047$$$047$$$047src$047ecs$047schedule$058after_condition$1260$(run_clo((_x_3) => {
  return run_clo((_x_4) => {
  return run_clo((_x_5) => {
  return $$$$047$$$047$$$047src$047ecs$047schedule$058execute_with_barrier$1260$(_rest_2, _x_3, _x_4, _namespace_0, _name_0, _all_0, _x_5);
});
});
}), ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058always$1260$(_world_0, _slot_0)), _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
        }
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058after_skip$1260$(_next_0, _returned_0, _observations_0) {
  const _owners_0 = _returned_0["fst"];
  const _world_0 = _returned_0["snd"];
  return run_tail(_next_0(_owners_0)(_world_0), _observations_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_state$1260$(_owner_0, _world_0) {
  const _owners_0 = _owner_0["fst"];
  const _t_0 = _owner_0["snd"];
  if (_t_0.$ === "../../../src/ecs/ordinary-app-execution.Off") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../src/ecs/ordinary-app-execution.Off"}}, "snd": ($$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0))};
  } else {
    const _journal_0 = _t_0["journal"];
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058enabled_barrier$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_recorded$1260$({$: "Tuple", "fst": _owners_0, "snd": _journal_0}, _world_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058after_condition$1260$(_next_0, _checked_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _world_0 = _checked_0["fst"];
  const _allowed_0 = _checked_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045run$058always$1260$(_world_0, _id_0) {
  return {$: "Tuple", "fst": _world_0, "snd": true};
}

function $$$$047$$$047$$$047src$047ecs$047world$058barrier$1260$(_world_0) {
  return $$$$047$$$047$$$047src$047ecs$047deferred$045command$058world_only$1260$(run_loop($$$$047$$$047$$$047src$047ecs$047world$058barrier_traced$1260$(_world_0, {$: "../../../src/ecs/trace-facts.Off"})));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058enabled_barrier$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _owners_0 = _t_0["fst"];
  const _journal_0 = _t_0["snd"];
  const _world_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../src/ecs/ordinary-app-execution.On", "journal": _journal_0}}, "snd": _world_0};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_recorded$1260$(_owners_0, _world_0) {
  const _owners_1 = _owners_0["fst"];
  const _journal_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_returned$1260$(_owners_1, _journal_0, run_loop($$$$047$$$047$$$047src$047ecs$047world$058barrier_traced$1260$(_world_0, {$: "../../../src/ecs/trace-facts.On", "reverseFacts": {$: "Nil"}})));
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058conditioned$1260$(_next_0, _allowed_0, _owners_0, _world_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (!_allowed_0) {
    return run_tail(_next_0(_owners_0)(_world_0), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../src/ecs/schedule.Skipped", "id": _id_0}, "tail": {$: "Nil"}})));
  } else {
    return $$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatch_state$1260$(_owners_0, _world_0, _id_0)), _namespace_0, _name_0, _all_0, _observations_0, _id_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047deferred$045command$058world_only$1260$(_result_0) {
  const _world_0 = _result_0["fst"];
  return _world_0;
}

function $$$$047$$$047$$$047src$047ecs$047world$058barrier_traced$1260$(_world_0, _trace_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo_traced$1260$(_pending_0, {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Nil"}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _trace_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058barrier_returned$1260$(_owners_0, _journal_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _trace_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record_barrier_operations$1260$(($$$$047$$$047$$$047src$047ecs$047trace$045facts$058facts$(_trace_0)), _journal_0))}, "snd": _world_0};
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058after_dispatch$1260$(_next_0, _result_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatch_state$1260$(_owner_0, _world_0, _id_0) {
  const _owners_0 = _owner_0["fst"];
  const _t_0 = _owner_0["snd"];
  if (_t_0.$ === "../../../src/ecs/ordinary-app-execution.Off") {
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058disabled_dispatched$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatch_disabled$1260$(_owners_0, _world_0, _id_0)));
  } else {
    const _journal_0 = _t_0["journal"];
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058enabled_dispatched$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatch_recorded$1260$({$: "Tuple", "fst": _owners_0, "snd": _journal_0}, _world_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058drain_fifo_traced$1260$(_commands_0, _world_0, _trace_0) {
  if (_commands_0.$ === "Nil") {
    return {$: "Tuple", "fst": _world_0, "snd": _trace_0};
  } else {
    const _command_0 = _commands_0["head"];
    const _rest_0 = _commands_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058drain_apply$1260$(_command_0, run_loop($$$$047$$$047$$$047src$047ecs$047world$058drain_fifo_traced$1260$(_rest_0, _world_0, _trace_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record_barrier_operations$1260$($0, $1) {
  for (;;) {
    {
      const _facts_0 = $0;
      const _journal_0 = $1;
      if (_facts_0.$ === "Nil") {
        return _journal_0;
      } else {
        const _fact_0 = _facts_0["head"];
        const _rest_0 = _facts_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record$1260$({$: "../../../src/ecs/execution-trace.BarrierOperationObserved", "fact": _fact_0}, _journal_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047trace$045facts$058facts$(_state_0) {
  if (_state_0.$ === "../../../src/ecs/trace-facts.Off") {
    return {$: "Nil"};
  } else {
    const _facts_0 = _state_0["reverseFacts"];
    return $List$reverse$(_facts_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047schedule$058after_outcome$1260$(_next_0, _outcome_0, _owners_0, _namespace_0, _name_0, _all_0, _observations_0, _id_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Failed") {
    const _world_0 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/schedule.Failed", "schedule": {$: "../../../src/ecs/schedule.Schedule", "namespace": _namespace_0, "name": _name_0, "steps": _all_0, "owners": _owners_0}, "world": _world_0, "error": _error_0, "observations": ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}}))};
  } else {
    const _world_1 = _outcome_0["world"];
    return run_tail(_next_0(_owners_0)(_world_1), ($List$append$(_observations_0, {$: "Con", "head": {$: "../../../src/ecs/schedule.Ran", "id": _id_0}, "tail": {$: "Nil"}})));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058disabled_dispatched$1260$(_result_0) {
  const _owners_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../src/ecs/ordinary-app-execution.Off"}}, "snd": _outcome_0};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatch_disabled$1260$(_owners_0, _world_0, _id_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058disabled_outcome$1260$(($local$045fixture$058dispatcher$())(_owners_0)({$: "../../../src/ecs/execution-context.Context", "world": _world_0, "trace": {$: "../../../src/ecs/trace-facts.Off"}})(_id_0));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058enabled_dispatched$1260$(_result_0) {
  const _t_0 = _result_0["fst"];
  const _owners_0 = _t_0["fst"];
  const _journal_0 = _t_0["snd"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../src/ecs/ordinary-app-execution.On", "journal": _journal_0}}, "snd": _outcome_0};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatch_recorded$1260$(_owners_0, _world_0, _id_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatch_id$1260$(_owners_0, _world_0, _id_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058drain_apply$1260$(_command_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _trace_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047deferred$045command$058run$1260$(_command_0, _world_0, _trace_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record$1260$(_event_0, _journal_0) {
  const _catalog_0 = _journal_0["catalog"];
  const _events_0 = _journal_0["events"];
  return {$: "../../../src/ecs/ordinary-app-execution.Journal", "catalog": _catalog_0, "events": {$: "Con", "head": _event_0, "tail": _events_0}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058disabled_outcome$1260$(_result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/system.Succeeded") {
    const _t_1 = _t_0["world"];
    const _world_0 = _t_1["world"];
    const _output_0 = _t_0["output"];
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0}};
  } else {
    const _t_2 = _t_0["world"];
    const _world_1 = _t_2["world"];
    const _error_0 = _t_0["error"];
    return {$: "Tuple", "fst": _owners_0, "snd": {$: "../../../src/ecs/system.Failed", "world": _world_1, "error": _error_0}};
  }
}

function $local$045fixture$058dispatcher$() {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_dispatch$1260$();
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatch_id$1260$(_owners_0, _world_0, _id_0) {
  const _owners_1 = _owners_0["fst"];
  const _journal_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058identified$1260$(_owners_1, _journal_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058identity$1260$(_journal_0, _world_0, _id_0)));
}

function $$$$047$$$047$$$047src$047ecs$047deferred$045command$058run$1260$(_command_0, _world_0, _trace_0) {
  if (_command_0.$ === "../../../src/ecs/deferred-command.Raw") {
    const _apply_0 = _command_0["apply"];
    return {$: "Tuple", "fst": _apply_0(_world_0), "snd": _trace_0};
  } else {
    const _apply_1 = _command_0["apply"];
    return run_tail(_apply_1(_trace_0), _world_0);
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_dispatch$1260$() {
  return run_clo((_x_0) => {
  return run_clo((_x_1) => {
  return run_clo((_x_2) => {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058dispatch_pair$1260$(_x_0, _x_1, _x_2);
});
});
});
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058identified$1260$(_owners_0, _journal_0, _id_0, _result_0) {
  const _world_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _fact_0 = _t_0["fst"];
  const _before_0 = _t_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatched$1260$(_fact_0, _before_0, _journal_0, ($local$045fixture$058dispatcher$())(_owners_0)({$: "../../../src/ecs/execution-context.Context", "world": _world_0, "trace": {$: "../../../src/ecs/trace-facts.On", "reverseFacts": {$: "Nil"}}})(_id_0));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058identity$1260$(_journal_0, _world_0, _id_0) {
  const _catalog_0 = _journal_0["catalog"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058identity_namespace$1260$(_id_0, run_loop($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058registration_name$(_catalog_0, _id_0)), ($$$$047$$$047$$$047src$047ecs$047world$058namespace$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058dispatch_pair$1260$(_owners_0, _world_0, _id_0) {
  const _a_0 = _owners_0["fst"];
  const _b_0 = _owners_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058dispatch_folded$1260$(_b_0, _world_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045records$058empty$1260$(_a_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058dispatched$1260$(_fact_0, _before_0, _journal_0, _result_0) {
  const _owners_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  if (_t_0.$ === "../../../src/ecs/system.Succeeded") {
    const _t_1 = _t_0["world"];
    const _world_0 = _t_1["world"];
    const _trace_0 = _t_1["trace"];
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058succeeded$1260$(_owners_0, _fact_0, _before_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record_operations$1260$(($$$$047$$$047$$$047src$047ecs$047trace$045facts$058facts$(_trace_0)), _fact_0, _journal_0)), ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
  } else {
    const _t_2 = _t_0["world"];
    const _world_1 = _t_2["world"];
    const _trace_1 = _t_2["trace"];
    const _error_0 = _t_0["error"];
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058failed$1260$(_owners_0, _fact_0, _before_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record_operations$1260$(($$$$047$$$047$$$047src$047ecs$047trace$045facts$058facts$(_trace_1)), _fact_0, _journal_0)), _error_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_1)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058identity_namespace$1260$(_id_0, _name_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _namespace_0 = _observed_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058identity_clock$1260$(_namespace_0, _id_0, _name_0, ($$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0)));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058registration_name$(_items_0, _id_0) {
  if (_items_0.$ === "Nil") {
    return {$: "None"};
  } else {
    const _t_0 = _items_0["head"];
    const _candidate_0 = _t_0["id"];
    const _name_0 = _t_0["name"];
    const _rest_0 = _items_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058named$((_candidate_0 === _id_0), _name_0, run_clo((_x_0) => {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058registration_name$(_rest_0, _id_0);
}));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058dispatch_folded$1260$(_b_0, _world_0, _id_0, _result_0) {
  const _a_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058dispatch_selected$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058member$1260$(_fields_0, _id_0)), _a_0, _b_0, _world_0, _id_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058succeeded$1260$(_owners_0, _fact_0, _before_0, _journal_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _after_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record$1260$({$: "../../../src/ecs/execution-trace.SystemCompleted", "identity": _fact_0, "before": _before_0, "after": _after_0, "status": {$: "../../../src/ecs/execution-trace.SystemOk"}}, _journal_0))}, "snd": {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": {$: "Unit"}}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record_operations$1260$($0, $1, $2) {
  for (;;) {
    {
      const _facts_0 = $0;
      const _identity_0 = $1;
      const _journal_0 = $2;
      if (_facts_0.$ === "Nil") {
        return _journal_0;
      } else {
        const _fact_0 = _facts_0["head"];
        const _rest_0 = _facts_0["tail"];
        $0 = _rest_0;
        $1 = _identity_0;
        $2 = ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record$1260$({$: "../../../src/ecs/execution-trace.OperationObserved", "identity": _identity_0, "fact": _fact_0}, _journal_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058clock$1260$(_world_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "Tuple", "fst": {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, "snd": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058failed$1260$(_owners_0, _fact_0, _before_0, _journal_0, _error_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _after_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _owners_0, "snd": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058record$1260$({$: "../../../src/ecs/execution-trace.SystemCompleted", "identity": _fact_0, "before": _before_0, "after": _after_0, "status": {$: "../../../src/ecs/execution-trace.SystemError", "error": _error_0}}, _journal_0))}, "snd": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": _error_0}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058identity_clock$1260$(_namespace_0, _id_0, _name_0, _observed_0) {
  const _world_0 = _observed_0["fst"];
  const _clock_0 = _observed_0["snd"];
  return {$: "Tuple", "fst": _world_0, "snd": {$: "Tuple", "fst": {$: "../../../src/ecs/execution-trace.Identity", "namespace": _namespace_0, "id": _id_0, "name": _name_0}, "snd": _clock_0}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$058named$(_found_0, _name_0, _next_0) {
  if (_found_0) {
    return _name_0;
  } else {
    return run_tail(_next_0, {$: "Unit"});
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058dispatch_selected$1260$(_found_0, _a_0, _b_0, _world_0, _id_0) {
  if (_found_0) {
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058left_returned$1260$(_b_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty_dispatch$1260$(_a_0, _world_0, _id_0)));
  } else {
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058right_returned$1260$(_a_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_run$1260$(_b_0, _world_0, _id_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058member$1260$(_fields_0, _id_0) {
  return $$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058member$(($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058identities$1260$(_fields_0)), _id_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058left_returned$1260$(_right_0, _result_0) {
  const _left_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058left_outcome$1260$(_outcome_0))};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058empty_dispatch$1260$(_owner_0, _world_0, _id_0) {
  return {$: "Tuple", "fst": _owner_0, "snd": {$: "../../../src/ecs/system.Failed", "world": _world_0, "error": {$: "Unit"}}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058right_returned$1260$(_left_0, _result_0) {
  const _right_0 = _result_0["fst"];
  const _outcome_0 = _result_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _left_0, "snd": _right_0}, "snd": ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058right_outcome$1260$(_outcome_0))};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_run$1260$(_value_0, _context_0, _id_0) {
  const _owner_0 = _value_0["owner"];
  const _args_0 = _value_0["args"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_selected$1260$(_args_0, _context_0, _id_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058fields$1260$(_owner_0)));
}

function $$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058member$(_items_0, _wanted_0) {
  if (_items_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = _items_0["head"];
    const _id_0 = _t_0["id"];
    const _rest_0 = _items_0["tail"];
    const _x_0 = (_id_0 === _wanted_0);
    const _x_1 = ($$$$047$$$047$$$047src$047ecs$047captured$045schedule$045composition$058member$(_rest_0, _wanted_0));
    return (_x_0 || _x_1);
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058left_outcome$1260$(_outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Succeeded") {
    const _world_0 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0};
  } else {
    const _world_1 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Failed", "world": _world_1, "error": {$: "../../../src/ecs/captured-schedule-composition.LeftError", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058right_outcome$1260$(_outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/system.Succeeded") {
    const _world_0 = _outcome_0["world"];
    const _output_0 = _outcome_0["output"];
    return {$: "../../../src/ecs/system.Succeeded", "world": _world_0, "output": _output_0};
  } else {
    const _world_1 = _outcome_0["world"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/system.Failed", "world": _world_1, "error": {$: "../../../src/ecs/captured-schedule-composition.RightError", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_selected$1260$(_args_0, _context_0, _id_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _fields_0 = _result_0["snd"];
  const _x_0 = ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058registration_id$1260$(_fields_0));
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_allowed$1260$((_id_0 === _x_0), _owner_0, _args_0, _context_0);
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_allowed$1260$(_valid_0, _owner_0, _args_0, _context_0) {
  if (!_valid_0) {
    return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-local-fields.Invocation", "owner": _owner_0, "args": _args_0}, "snd": {$: "../../../src/ecs/system.Failed", "world": _context_0, "error": {$: "../../../src/ecs/ordinary-app-local-fields.RegistrationRefused"}}};
  } else {
    const _world_0 = _context_0["world"];
    const _trace_0 = _context_0["trace"];
    const _actual_0 = _args_0;
    return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_returned$1260$(_actual_0, _trace_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058run$1260$(_owner_0, _world_0, _actual_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045execution$045recipe$058registration_id$1260$(_fields_0) {
  const _id_0 = _fields_0["id"];
  return _id_0;
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058execution_returned$1260$(_args_0, _trace_0, _result_0) {
  if (_result_0.$ === "../../../src/ecs/local.Completed") {
    const _world_0 = _result_0["world"];
    const _instance_0 = _result_0["instance"];
    const _t_0 = _result_0["result"];
    if (_t_0.$ === "Done") {
      return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-local-fields.Invocation", "owner": {$: "../../../src/ecs/ordinary-app-local-fields.Owner", "instance": _instance_0}, "args": _args_0}, "snd": {$: "../../../src/ecs/system.Succeeded", "world": {$: "../../../src/ecs/execution-context.Context", "world": _world_0, "trace": _trace_0}, "output": {$: "Unit"}}};
    } else {
      const _error_0 = _t_0["error"];
      return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-local-fields.Invocation", "owner": {$: "../../../src/ecs/ordinary-app-local-fields.Owner", "instance": _instance_0}, "args": _args_0}, "snd": {$: "../../../src/ecs/system.Failed", "world": {$: "../../../src/ecs/execution-context.Context", "world": _world_0, "trace": _trace_0}, "error": {$: "../../../src/ecs/ordinary-app-local-fields.CallbackFailure", "error": _error_0}}};
    }
  } else {
    const _world_1 = _result_0["world"];
    const _instance_1 = _result_0["instance"];
    return {$: "Tuple", "fst": {$: "../../../src/ecs/ordinary-app-local-fields.Invocation", "owner": {$: "../../../src/ecs/ordinary-app-local-fields.Owner", "instance": _instance_1}, "args": _args_0}, "snd": {$: "../../../src/ecs/system.Failed", "world": {$: "../../../src/ecs/execution-context.Context", "world": _world_1, "trace": _trace_0}, "error": {$: "../../../src/ecs/ordinary-app-local-fields.RegistrationRefused"}}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058run$1260$(_value_0, _world_0, _args_0) {
  const _instance_0 = _value_0["instance"];
  return $$$$047$$$047$$$047src$047ecs$047local$058run$1260$(_instance_0, _world_0, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047local$058run$1260$(_instance_0, _world_0, _args_0) {
  const _namespace_0 = _instance_0["namespace"];
  const _id_0 = _instance_0["id"];
  const _name_0 = _instance_0["name"];
  const _access_0 = _instance_0["access"];
  const _local_0 = _instance_0["local"];
  const _actual_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return $$$$047$$$047$$$047src$047ecs$047local$058checked$1260$(($Bool$and$((_namespace_0 === _actual_0), ($$$$047$$$047$$$047src$047ecs$047world$058registration_list_matches$(_registrations_0, _id_0, _name_0, _access_0)))), {$: "../../../src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, {$: "../../../src/ecs/world.World", "namespace": _actual_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0}, _args_0);
}

function $$$$047$$$047$$$047src$047ecs$047local$058checked$1260$(_allowed_0, _instance_0, _world_0, _args_0) {
  if (!_allowed_0) {
    return {$: "../../../src/ecs/local.Refused", "world": _world_0, "instance": _instance_0, "args": _args_0};
  } else {
    const _namespace_0 = _instance_0["namespace"];
    const _id_0 = _instance_0["id"];
    const _name_0 = _instance_0["name"];
    const _access_0 = _instance_0["access"];
    const _local_0 = _instance_0["local"];
    return $$$$047$$$047$$$047src$047ecs$047local$058completed$1260$(_namespace_0, _id_0, _name_0, _access_0, ($$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058runner$1260$(_world_0, _local_0, _args_0)));
  }
}

function $$$$047$$$047$$$047src$047ecs$047local$058completed$1260$(_namespace_0, _id_0, _name_0, _access_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/local.Succeeded") {
    const _world_0 = _outcome_0["world"];
    const _local_0 = _outcome_0["local"];
    const _out_0 = _outcome_0["output"];
    return {$: "../../../src/ecs/local.Completed", "world": _world_0, "instance": {$: "../../../src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_0}, "result": {$: "Done", "value": _out_0}};
  } else {
    const _world_1 = _outcome_0["world"];
    const _local_1 = _outcome_0["local"];
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/local.Completed", "world": _world_1, "instance": {$: "../../../src/ecs/local.Instance", "namespace": _namespace_0, "id": _id_0, "name": _name_0, "access": _access_0, "local": _local_1}, "result": {$: "Fail", "error": _error_0}};
  }
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058runner$1260$(_world_0, _local_0, _args_0) {
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058finished$1260$(($local$045fixture$058body$1260$(_local_0, _args_0, ($$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0)))));
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058finished$1260$(_result_0) {
  const _tx_0 = _result_0["fst"];
  const _t_0 = _result_0["snd"];
  const _local_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  const _outcome_0 = _t_1["fst"];
  const _output_0 = _t_1["snd"];
  return $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058returned$1260$(_local_0, _output_0, ($$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0)));
}

function $local$045fixture$058body$1260$(_local_0, _args_0, _owner_0) {
  return $local$045fixture$058body_count$1260$(_owner_0, {$: "Tuple", fst: _local_0, snd: _local_0[0 % _local_0.length]});
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058begin$1260$(_world_0) {
  return {$: "../../../src/ecs/transaction.Tx", "world": _world_0, "undo": {$: "Nil"}, "commands": {$: "Nil"}, "events": {$: "Nil"}, "trace": {$: "../../../src/ecs/trace-facts.Off"}};
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045app$045local$045fields$058returned$1260$(_local_0, _output_0, _result_0) {
  const _world_0 = _result_0["world"];
  const _t_0 = _result_0["outcome"];
  if (_t_0.$ === "../../../src/ecs/transaction.Success") {
    return {$: "../../../src/ecs/local.Succeeded", "world": _world_0, "local": _local_0, "output": _output_0};
  } else {
    const _error_0 = _t_0["error"];
    return {$: "../../../src/ecs/local.Failed", "world": _world_0, "local": _local_0, "error": _error_0};
  }
}

function $$$$047$$$047$$$047src$047ecs$047commands$058tx_finish$1260$(_tx_0, _outcome_0) {
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0);
}

function $local$045fixture$058body_count$1260$(_owner_0, _result_0) {
  const _local_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  const _x_0 = ((_value_0 + 1) >>> 0);
  const _x_1 = (_local_0[0 % _local_0.length] = _x_0, _local_0);
  return $local$045fixture$058body_flag$1260$(_owner_0, {$: "Tuple", fst: _x_1, snd: _x_1[1 % _x_1.length]});
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish$1260$(_tx_0, _outcome_0) {
  const _world_0 = _tx_0["world"];
  const _undo_0 = _tx_0["undo"];
  const _commands_0 = _tx_0["commands"];
  const _events_0 = _tx_0["events"];
  return $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0);
}

function $local$045fixture$058body_flag$1260$(_owner_0, _result_0) {
  const _local_0 = _result_0["fst"];
  const _flag_0 = _result_0["snd"];
  return $local$045fixture$058body_resource$1260$((_local_0[1 % _local_0.length] = 0, _local_0), ($Bool$not$((_flag_0 === 0))), run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058value_get$1260$(_owner_0)));
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058finish_world$1260$(_world_0, _undo_0, _commands_0, _events_0, _outcome_0) {
  if (_outcome_0.$ === "../../../src/ecs/transaction.Success") {
    const _committed_0 = ($$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, ($List$reverse$(_commands_0))));
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_committed_0, ($List$reverse$(_events_0)))), "outcome": {$: "../../../src/ecs/transaction.Success"}};
  } else {
    const _error_0 = _outcome_0["error"];
    return {$: "../../../src/ecs/transaction.Returned", "world": ($$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$(_undo_0, _world_0)), "outcome": {$: "../../../src/ecs/transaction.Failure", "error": _error_0}};
  }
}

function $local$045fixture$058body_resource$1260$(_local_0, _fail_0, _result_0) {
  const _owner_0 = _result_0["fst"];
  const _value_0 = _result_0["snd"];
  return {$: "Tuple", "fst": run_loop($$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1260$(_owner_0, ((_value_0 + 10) >>> 0))), "snd": {$: "Tuple", "fst": _local_0, "snd": {$: "Tuple", "fst": ($local$045fixture$058outcome$(_fail_0)), "snd": array_new(0, 99)}}};
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058value_get$1260$(_ctx_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_read_field$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058grant$1260$(($local$045fixture$058declaration$()))))), _ctx_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue$1260$(_world_0, _commands_0) {
  return $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$(_commands_0, _world_0);
}

function $$$$047$$$047$$$047src$047ecs$047commands$058publish$1260$(_world_0, _events_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _events_0);
}

function $$$$047$$$047$$$047src$047ecs$047transaction$058rollback$1260$($0, $1) {
  for (;;) {
    {
      const _undo_0 = $0;
      const _world_0 = $1;
      if (_undo_0.$ === "Nil") {
        return _world_0;
      } else {
        const _inverse_0 = _undo_0["head"];
        const _rest_0 = _undo_0["tail"];
        $0 = _rest_0;
        $1 = _inverse_0(_world_0);
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058value_set$1260$(_ctx_0, _value_0) {
  return run_tail(($$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1260$(($$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058grant$1260$(($local$045fixture$058declaration$())))))(_ctx_0), _value_0);
}

function $local$045fixture$058outcome$(_fail_0) {
  if (_fail_0) {
    return {$: "../../../src/ecs/transaction.Failure", "error": {$: "local-fixture.ExpectedFailure"}};
  } else {
    return {$: "../../../src/ecs/transaction.Success"};
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_read_field$1260$(_cap_0) {
  const _get_0 = _cap_0["get"];
  return _get_0;
}

function $$$$047$$$047$$$047src$047ecs$047ordinary$045resource$045system$058grant$1260$(_declaration_0) {
  const _grant_0 = _declaration_0["grant"];
  return _grant_0;
}

function $$$$047$$$047$$$047src$047ecs$047commands$058enqueue_list$1260$($0, $1) {
  for (;;) {
    {
      const _commands_0 = $0;
      const _world_0 = $1;
      if (_commands_0.$ === "Nil") {
        return _world_0;
      } else {
        const _command_0 = _commands_0["head"];
        const _rest_0 = _commands_0["tail"];
        $0 = _rest_0;
        $1 = ($$$$047$$$047$$$047src$047ecs$047world$058enqueue_command$1260$(_world_0, _command_0));
        continue;
      }
    }
  }
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish$1260$(_world_0, _published_0) {
  if (_published_0.$ === "Nil") {
    return _world_0;
  } else {
    const _head_0 = _published_0["head"];
    const _rest_0 = _published_0["tail"];
    return $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, {$: "Con", "head": _head_0, "tail": _rest_0});
  }
}

function $$$$047$$$047$$$047src$047ecs$047capabilities$058value_write_field$1260$(_cap_0) {
  const _set_0 = _cap_0["set"];
  return _set_0;
}

function $$$$047$$$047$$$047src$047ecs$047world$058enqueue_command$1260$(_world_0, _command_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": _events_0, "pending": {$: "Con", "head": _command_0, "tail": _pending_0}, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_publish_nonempty$1260$(_world_0, _published_0) {
  const _namespace_0 = _world_0["namespace"];
  const _allocator_0 = _world_0["allocator"];
  const _store_0 = _world_0["store"];
  const _resource_0 = _world_0["resource"];
  const _events_0 = _world_0["events"];
  const _pending_0 = _world_0["pending"];
  const _registrations_0 = _world_0["registrations"];
  const _nextSystemId_0 = _world_0["nextSystemId"];
  const _clock_0 = _world_0["clock"];
  return {$: "../../../src/ecs/world.World", "namespace": _namespace_0, "allocator": _allocator_0, "store": _store_0, "resource": _resource_0, "events": ($$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_events_0, _published_0)), "pending": _pending_0, "registrations": _registrations_0, "nextSystemId": _nextSystemId_0, "clock": _clock_0};
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append$1260$(_left_0, _right_0) {
  return $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$(($List$reverse$(_left_0)), _right_0);
}

function $$$$047$$$047$$$047src$047ecs$047world$058event_append_loop$1260$($0, $1) {
  for (;;) {
    {
      const _reversed_0 = $0;
      const _output_0 = $1;
      if (_reversed_0.$ === "Nil") {
        return _output_0;
      } else {
        const _head_0 = _reversed_0["head"];
        const _rest_0 = _reversed_0["tail"];
        $0 = _rest_0;
        $1 = {$: "Con", "head": _head_0, "tail": _output_0};
        continue;
      }
    }
  }
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

// strerror needs bun:ffi; a host without it (node) gets the bare errno.
function io_strerror(code) {
  try {
    return String(io_sys().strerror(code));
  } catch (_) {
    return "errno " + code;
  }
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, io_strerror(code)) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io, block) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = !block ? 0 : soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    let look = 0;
    for (let n = 0;; n += 1) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io, true);
        continue;
      }
      if ((n & 63) === 0 && io.waits.length > 0) {
        const now = performance.now();
        if (now >= look || io.waits[0].at <= now) {
          look = now + 10;
          io_wait(io, false);
        }
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

cli(process.argv.slice(1));
io_exit($main$, null);