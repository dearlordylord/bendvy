
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_NONE 8
#define CID_SOME 9
#define CID_FALSE 10
#define CID_TRUE 11
#define CID_UNIT 12
#define CID__________SRC_ECS_WORLD_IO_CREATED 13
#define CID__________SRC_ECS_WORLD_IO_REFUSED 14
#define CID_LOCAL_FIXTURE_S 15
#define CID_CHR 16
#define CID__________SRC_ECS_WORLD_WORLD 17
#define CID__________SRC_ECS_ENTITY_ALLOCATOR_ALLOCATOR 18
#define CID_NIL 19
#define CID_CON 20
#define CID__________SRC_ECS_DEFERRED_COMMAND_RAW 21
#define CID__________SRC_ECS_DEFERRED_COMMAND_OBSERVED 22
#define CID__________SRC_ECS_WORLD_REGISTRATIONMETA 23
#define CID__________SRC_ECS_WORLD_CREATED 24
#define CID__________SRC_ECS_WORLD_CREATEREJECTED 25
#define CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_APPENDED 26
#define CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_APPENDREJECTED 27
#define CID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_REGISTERED 28
#define CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION 29
#define CID_LOCAL_FIXTURE_EXPECTEDFAILURE 30
#define CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR 31
#define CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR 32
#define CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE 33
#define CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED 34
#define CID__________SRC_ECS_ENTITY_ALLOCATOR_SLOT 35
#define CID__________SRC_ECS_ENTITY_KEY_ENTITYKEY 36
#define CID__________SRC_ECS_TRACE_FACTS_OFF 37
#define CID__________SRC_ECS_TRACE_FACTS_ON 38
#define CID__________SRC_ECS_WORLD_FACTORY 39
#define CID__________SRC_ECS_ORDINARY_APP_OBSERVATION_DATA_OBSERVATION 40
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_FIELDS 41
#define CID__________SRC_ECS_SCHEDULE_PROVISION_EMPTY 42
#define CID__________SRC_ECS_SCHEDULE_PROVISION_ENTRY 43
#define CID__________SRC_ECS_SCHEDULE_PROVISION_SEQUENCE 44
#define CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT 45
#define CID__________SRC_ECS_SYSTEM_SUCCEEDED 46
#define CID__________SRC_ECS_SYSTEM_FAILED 47
#define CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT 48
#define CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE 49
#define CID__________SRC_ECS_SCHEDULE_PROVISION_SERVICE 50
#define CID__________SRC_ECS_ORDINARY_APP_COMPOSER_REGISTERED 51
#define CID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_RECIPE 52
#define CID__________SRC_ECS_ORDINARY_RESOURCE_SYSTEM_DECLARATION 53
#define CID__________SRC_ECS_TRANSACTION_TX 54
#define CID__________SRC_ECS_TRANSACTION_SUCCESS 55
#define CID__________SRC_ECS_TRANSACTION_FAILURE 56
#define CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_OWNER 57
#define CID__________SRC_ECS_ORDINARY_APP_SCHEDULE_ATTACHED 58
#define CID__________SRC_ECS_ORDINARY_APP_SCHEDULE_INVALID 59
#define CID__________SRC_ECS_ORDINARY_APP_RUN_APPLICATION 60
#define CID__________SRC_ECS_ENTITY_ALLOCATOR_CONSUMED 61
#define CID__________SRC_ECS_ENTITY_ALLOCATOR_PENDING 62
#define CID__________SRC_ECS_ENTITY_ALLOCATOR_LIVE 63
#define CID__________SRC_ECS_ENTITY_ALLOCATOR_DEADRETAINED 64
#define CID__________SRC_ECS_ENTITY_ALLOCATOR_FREE 65
#define CID__________SRC_ECS_TRACE_FACTS_READERFACT 66
#define CID__________SRC_ECS_TRACE_FACTS_BOUNDARYFACT 67
#define CID__________SRC_ECS_TRACE_FACTS_FACT 68
#define CID__________SRC_ECS_TRACE_FACTS_RELATIONFACT 69
#define CID__________SRC_ECS_TRACE_FACTS_HANDLERFACT 70
#define CID__________SRC_ECS_TRACE_FACTS_TRANSITIONFACT 71
#define CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_CLAUSE 72
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_COMPONENTKIND 73
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_RESOURCEKIND 74
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_FIELDKIND 75
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_SERVICEKIND 76
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_EVENTKIND 77
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_MIXEDKIND 78
#define CID__________SRC_ECS_SCHEDULE_SYSTEM 79
#define CID__________SRC_ECS_SCHEDULE_PHASE 80
#define CID__________SRC_ECS_SCHEDULE_BARRIER 81
#define CID__________SRC_ECS_ORDINARY_APP_RECIPE_RECIPE 82
#define CID__________SRC_ECS_ORDINARY_SCHEMA_RESOURCE 83
#define CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_READ 84
#define CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_WRITE 85
#define CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_OPTIONAL 86
#define CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_WITH 87
#define CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_WITHOUT 88
#define CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_ADDED 89
#define CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_CHANGED 90
#define CID__________SRC_ECS_LOCAL_INSTANCE 91
#define CID__________SRC_ECS_ORDINARY_APP_SCHEDULE_APPLICATION 92
#define CID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN 93
#define CID__________SRC_ECS_ORDINARY_SCHEMA_SCHEMA 94
#define CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTERED 95
#define CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REJECTED 96
#define CID__________SRC_ECS_TRACE_FACTS_PHASEBOUNDARY 97
#define CID__________SRC_ECS_TRACE_FACTS_BARRIERENTERED 98
#define CID__________SRC_ECS_TRACE_FACTS_BARRIERFINISHED 99
#define CID__________SRC_ECS_TRACE_FACTS_COMPONENTVALUE 100
#define CID__________SRC_ECS_TRACE_FACTS_RESOURCEVALUE 101
#define CID__________SRC_ECS_TRACE_FACTS_EVENTVALUE 102
#define CID__________SRC_ECS_TRACE_FACTS_NEXTSTATEVALUE 103
#define CID__________SRC_ECS_TRACE_FACTS_DEFERREDCOMMAND 104
#define CID__________SRC_ECS_TRACE_FACTS_RELATIONOPERATION 105
#define CID__________SRC_ECS_TRACE_FACTS_TRANSITIONHANDLER 106
#define CID__________SRC_ECS_TRACE_FACTS_MISSEDVALUE 107
#define CID__________SRC_ECS_TRACE_FACTS_READOPERATION 108
#define CID__________SRC_ECS_TRACE_FACTS_WRITEOPERATION 109
#define CID__________SRC_ECS_TRACE_FACTS_REMOVEOPERATION 110
#define CID__________SRC_ECS_TRACE_FACTS_SENDOPERATION 111
#define CID__________SRC_ECS_TRACE_FACTS_STAGEOPERATION 112
#define CID__________SRC_ECS_TRACE_FACTS_APPLYOPERATION 113
#define CID__________SRC_ECS_TRACE_FACTS_HANDLEROPERATION 114
#define CID__________SRC_ECS_TRACE_FACTS_OPAQUEVALUE 115
#define CID__________SRC_ECS_TRACE_FACTS_UNAVAILABLEVALUE 116
#define CID__________SRC_ECS_TRACE_FACTS_DISPLAYEDVALUE 117
#define CID__________SRC_ECS_TRACE_FACTS_ATTEMPTED 118
#define CID__________SRC_ECS_TRACE_FACTS_APPLIED 119
#define CID__________SRC_ECS_TRACE_FACTS_REFUSED 120
#define CID__________SRC_ECS_TRACE_FACTS_ROLLEDBACK 121
#define CID__________SRC_ECS_TRACE_FACTS_RELATIONIDENTITY 122
#define CID__________SRC_ECS_TRACE_FACTS_HANDLEVALUE 123
#define CID__________SRC_ECS_TRACE_FACTS_RELATEACTION 124
#define CID__________SRC_ECS_TRACE_FACTS_UNRELATEACTION 125
#define CID__________SRC_ECS_TRACE_FACTS_REORDERACTION 126
#define CID__________SRC_ECS_TRACE_FACTS_EXITPHASE 127
#define CID__________SRC_ECS_TRACE_FACTS_TRANSITIONPHASE 128
#define CID__________SRC_ECS_TRACE_FACTS_ENTERPHASE 129
#define CID__________SRC_ECS_TRACE_FACTS_INITIALENTERPHASE 130
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_DECLAREDUSE 131
#define CID__________SRC_ECS_LOCAL_SUCCEEDED 132
#define CID__________SRC_ECS_LOCAL_FAILED 133
#define CID__________SRC_ECS_ORDINARY_APP_SCHEMA_APPLICATION 134
#define CID__________SRC_ECS_ORDINARY_APP_SCHEDULE_FINISHED 135
#define CID__________SRC_ECS_ORDINARY_APP_SCHEDULE_FAILED 136
#define CID__________SRC_ECS_ORDINARY_APP_SCHEDULE_REJECTED 137
#define CID__________SRC_ECS_ORDINARY_APP_SCHEDULE_MISSING 138
#define CID__________SRC_ECS_EXECUTION_TRACE_DISABLED 139
#define CID__________SRC_ECS_EXECUTION_TRACE_READY 140
#define CID__________SRC_ECS_SCHEDULE_ENTERED 141
#define CID__________SRC_ECS_SCHEDULE_RAN 142
#define CID__________SRC_ECS_SCHEDULE_SKIPPED 143
#define CID__________SRC_ECS_SCHEDULE_APPLIED 144
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_ENTRY 145
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_CLASSIFIED 146
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_COMPONENT 147
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_RESOURCE 148
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_EVENT 149
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_RELATION 150
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_SERVICE 151
#define CID__________SRC_ECS_LOCAL_REGISTERED 152
#define CID__________SRC_ECS_LOCAL_REGISTRATIONREJECTED 153
#define CID__________SRC_ECS_CAPABILITIES_VALUEWRITE 154
#define CID__________SRC_ECS_TRACE_FACTS_ORDINARYRELATION 155
#define CID__________SRC_ECS_TRACE_FACTS_HIERARCHYRELATION 156
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_COMPONENTUSE 157
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_RESOURCEUSE 158
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_EVENTUSE 159
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_QUERYSOURCE 160
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_MESSAGESOURCE 161
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_REMOVALSOURCE 162
#define CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_RELATIONFAILURESOURCE 163
#define CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULESTARTED 164
#define CID__________SRC_ECS_EXECUTION_TRACE_PHASEENTERED 165
#define CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMCOMPLETED 166
#define CID__________SRC_ECS_EXECUTION_TRACE_OPERATIONOBSERVED 167
#define CID__________SRC_ECS_EXECUTION_TRACE_BARRIEROPERATIONOBSERVED 168
#define CID__________SRC_ECS_EXECUTION_TRACE_EXECUTIONOPERATIONOBSERVED 169
#define CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMSKIPPED 170
#define CID__________SRC_ECS_EXECUTION_TRACE_DEFERREDAPPLIED 171
#define CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEENDED 172
#define CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEADMISSIONREFUSED 173
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_PLAIN 174
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_TRANSIENT 175
#define CID__________SRC_ECS_SCHEMA_FRAGMENTS_CONSTRUCTED 176
#define CID__________SRC_ECS_EXECUTION_TRACE_IDENTITY 177
#define CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMOK 178
#define CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMERROR 179
#define CID__________SRC_ECS_EXECUTION_TRACE_ENDOK 180
#define CID__________SRC_ECS_EXECUTION_TRACE_ENDFAILED 181
#define CID__________SRC_ECS_EXECUTION_TRACE_ENDREJECTED 182
#define CID__________SRC_ECS_EXECUTION_TRACE_ENDMISSING 183
#define CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITY 184
#define CID__________SRC_ECS_WORLD_REGISTERED 185
#define CID__________SRC_ECS_WORLD_REGISTRATIONREJECTED 186
#define CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF 187
#define CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON 188
#define CID__________SRC_ECS_SCHEDULE_PROVISION_BUILT 189
#define CID__________SRC_ECS_SCHEDULE_PROVISION_INVALID 190
#define CID__________SRC_ECS_WORLD_MISSINGENTITY 191
#define CID__________SRC_ECS_WORLD_CAPACITYEXCEEDED 192
#define CID__________SRC_ECS_WORLD_NAMESPACEEXHAUSTED 193
#define CID__________SRC_ECS_WORLD_SYSTEMIDEXHAUSTED 194
#define CID__________SRC_ECS_ORDINARY_APP_EXECUTION_JOURNAL 195
#define CID__________SRC_ECS_SCHEDULE_PROVISION_EXECUTED 196
#define CID__________SRC_ECS_SCHEDULE_PROVISION_MISSING 197
#define CID__________SRC_ECS_SCHEDULE_PROVISION_PROVISIONED 198
#define CID__________SRC_ECS_SCHEDULE_SCHEDULE 199
#define CID__________SRC_ECS_SCHEDULE_BUILT 200
#define CID__________SRC_ECS_SCHEDULE_INVALID 201
#define CID__________SRC_ECS_SCHEDULE_FINISHED 202
#define CID__________SRC_ECS_SCHEDULE_FAILED 203
#define CID__________SRC_ECS_SCHEDULE_REJECTED 204
#define CID__________SRC_ECS_LOCAL_COMPLETED 205
#define CID__________SRC_ECS_LOCAL_REFUSED 206
#define CID__________SRC_ECS_TRANSACTION_RETURNED 207
#define CID__________SRC_ECS_WORLD_NAMESPACE_FRESH 208
#define CID_IO_PRINT 209
#define FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0 0
#define FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C11 1
#define FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C12 2
#define FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C13 3
#define FID__________SRC_ECS_RESOURCE_REPLACE_JOIN_0_C14 4
#define FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K15 5
#define FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K16 6
#define FID__________SRC_ECS_TRANSACTION_ROLLBACK_0 7
#define FID__________SRC_ECS_TRANSACTION_ROLLBACK_0_K18 8
#define FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0 9
#define FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C22 10
#define FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C23 11
#define FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C24 12
#define FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_K25 13
#define FID__________SRC_ECS_COMMANDS_TX_FINISH_0 14
#define FID__________SRC_ECS_COMMANDS_TX_FINISH_0_K39 15
#define FID_LOCAL_FIXTURE_BODY_0 16
#define FID_LOCAL_FIXTURE_BODY_0_K43 17
#define FID_LOCAL_FIXTURE_BODY_0_K44 18
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0 19
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K48 20
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K49 21
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0 22
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K57 23
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K58 24
#define FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER 25
#define FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER_K68 26
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0 27
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C70 28
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C71 29
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C72 30
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0_K73 31
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0 32
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0_K78 33
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME 34
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_C92 35
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K93 36
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K94 37
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0 38
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0_K101 39
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0 40
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K144 41
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C145 42
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C146 43
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C147 44
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K148 45
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K149 46
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K150 47
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K151 48
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K152 49
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0 50
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C155 51
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C156 52
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C157 53
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K158 54
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K159 55
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K160 56
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K161 57
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K162 58
#define FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0 59
#define FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K173 60
#define FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K174 61
#define FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K175 62
#define FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K176 63
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0 64
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K178 65
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K179 66
#define FID__________SRC_ECS_WORLD_BARRIER_TRACED_0 67
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0 68
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0_K201 69
#define FID__________SRC_ECS_WORLD_BARRIER_0 70
#define FID__________SRC_ECS_WORLD_BARRIER_0_K204 71
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0 72
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K218 73
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K219 74
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0 75
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K225 76
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K226 77
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K227 78
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C228 79
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C229 80
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C230 81
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K231 82
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K232 83
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K233 84
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K234 85
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C235 86
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C236 87
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C237 88
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K238 89
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K239 90
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K240 91
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K241 92
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K242 93
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K243 94
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K244 95
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K245 96
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K246 97
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K247 98
#define FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K248 99
#define FID__________SRC_ECS_WORLD_ACCESS_EQUAL 100
#define FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K258 101
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0 102
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0_K265 103
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0 104
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0_K267 105
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0 106
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0_K269 107
#define FID__________SRC_ECS_SCHEDULE_RUN_WITH_BARRIER_0 108
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0 109
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K279 110
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K280 111
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K281 112
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C282 113
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K283 114
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K284 115
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C285 116
#define FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0 117
#define FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K292 118
#define FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0 119
#define FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K298 120
#define FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K299 121
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0 122
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K303 123
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K304 124
#define FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES 125
#define FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0 126
#define FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K318 127
#define FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K319 128
#define FID_LIST_APPEND 129
#define FID_LIST_APPEND_K321 130
#define FID__________SRC_ECS_SCHEDULE_VALID 131
#define FID__________SRC_ECS_SCHEDULE_VALID_K323 132
#define FID__________SRC_ECS_SCHEDULE_VALID_K324 133
#define FID__________SRC_ECS_SCHEDULE_VALID_K325 134
#define FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK 135
#define FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K350 136
#define FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0 137
#define FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K352 138
#define FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K353 139
#define FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0 140
#define FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0 141
#define FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K356 142
#define FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K357 143
#define FID__________SRC_ECS_SCHEDULE_BUILD_0 144
#define FID__________SRC_ECS_SCHEDULE_BUILD_0_K359 145
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0 146
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0_K362 147
#define FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0 148
#define FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_C364 149
#define FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K365 150
#define FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K366 151
#define FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K367 152
#define FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K368 153
#define FID_U32_SHOW_GO 154
#define FID__________SRC_ECS_SCHEDULE_CONTAINS 155
#define FID__________SRC_ECS_SCHEDULE_CONTAINS_K388 156
#define FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES 157
#define FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0 158
#define FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K392 159
#define FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K393 160
#define FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K394 161
#define FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K395 162
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0 163
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K400 164
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K401 165
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K402 166
#define FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS 167
#define FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS_K425 168
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0 169
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0_K427 170
#define FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID 171
#define FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K429 172
#define FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K430 173
#define FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K431 174
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0 175
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C435 176
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C436 177
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C437 178
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K438 179
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K439 180
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K440 181
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K441 182
#define FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K442 183
#define FID_U32_SHOW 184
#define FID_LOCAL_FIXTURE_LOCAL_OBSERVED 185
#define FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K476 186
#define FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K477 187
#define FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K478 188
#define FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K479 189
#define FID_LOCAL_DRIVER_RETRIED 190
#define FID_LOCAL_DRIVER_RETRIED_K482 191
#define FID_LOCAL_DRIVER_RETRIED_C483 192
#define FID_STRING_APPEND 193
#define FID_STRING_APPEND_K485 194
#define FID_LOCAL_FIXTURE_OBSERVED 195
#define FID_LOCAL_FIXTURE_OBSERVED_K521 196
#define FID_LOCAL_DRIVER_OBSERVED 197
#define FID_LOCAL_DRIVER_OBSERVED_K526 198
#define FID_LOCAL_DRIVER_OBSERVED_K527 199
#define FID_LOCAL_DRIVER_OBSERVED_K528 200
#define FID_LOCAL_DRIVER_OBSERVED_K529 201
#define FID_LOCAL_DRIVER_OBSERVED_K530 202
#define FID_LOCAL_DRIVER_OBSERVED_K531 203
#define FID_LOCAL_FIXTURE_RUN 204
#define FID_LOCAL_FIXTURE_RUN_K556 205
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C564 206
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C565 207
#define FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C566 208
#define FID_LOCAL_FIXTURE_ATTACH 209
#define FID_LOCAL_FIXTURE_ATTACH_C568 210
#define FID_LOCAL_FIXTURE_ATTACH_K569 211
#define FID_LOCAL_FIXTURE_ATTACH_C570 212
#define FID_LOCAL_FIXTURE_ATTACH_C571 213
#define FID_LOCAL_FIXTURE_ATTACH_C572 214
#define FID_LOCAL_FIXTURE_ATTACH_K573 215
#define FID_LOCAL_FIXTURE_ATTACH_K574 216
#define FID_LOCAL_FIXTURE_ATTACH_K575 217
#define FID_LOCAL_FIXTURE_ATTACH_K576 218
#define FID_LOCAL_FIXTURE_ATTACH_K577 219
#define FID_LOCAL_FIXTURE_ATTACH_K578 220
#define FID_LOCAL_FIXTURE_ATTACH_K579 221
#define FID_LOCAL_FIXTURE_ATTACH_K580 222
#define FID_LOCAL_FIXTURE_ATTACH_K581 223
#define FID_LOCAL_DRIVER_START 224
#define FID_LOCAL_DRIVER_START_K604 225
#define FID_LOCAL_DRIVER_START_K605 226
#define FID_LOCAL_DRIVER_START_K606 227
#define FID_LOCAL_DRIVER_START_C607 228
#define FID_LOCAL_DRIVER_START_K608 229
#define FID_LOCAL_DRIVER_START_K609 230
#define FID__________SRC_ECS_WORLD_IO_WITH_NAMESPACE_0_C618 231
#define FID_IO_BIND 232
#define FID_IO_BIND_C620 233
#define FID_IO_BIND_K621 234
#define FID_MAIN 235
#define FID_MAIN_C623 236
#define FID__________SRC_ECS_WORLD_IO_CREATE_0_C624 237
#define FID__________SRC_ECS_WORLD_IO_CREATE_0_C625 238
#define FID_MAIN_C626 239
#define FID_MAIN_K627 240
#define FID_MAIN_C628 241
#define FID__________SRC_ECS_WORLD_NAMESPACE_FRESH 242
#define FID_IO_PRINT 243
#define FID_IO_EMIT 244
#define FID_CLO_APPLY 245
#define FID_EXIT 246
#define FID_ENTER 247
CONSTV u8 FID_T[][3] = { { 7, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 7, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 6, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 7, 0, 2 }, { 1, 1, 2 }, { 7, 0, 2 }, { 1, 1, 2 }, { 7, 0, 2 }, { 9, 7, 2 }, { 8, 6, 2 }, { 2, 0, 2 }, { 9, 9, 2 }, { 4, 2, 2 }, { 6, 0, 2 }, { 20, 1, 2 }, { 8, 4, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 9, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 7, 0, 2 }, { 11, 9, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 0, 2 }, { 3, 0, 2 }, { 2, 2, 2 }, { 1, 1, 2 }, { 4, 0, 2 }, { 4, 2, 2 }, { 9, 0, 2 }, { 14, 6, 2 }, { 1, 0, 2 }, { 6, 0, 2 }, { 9, 0, 2 }, { 10, 1, 2 }, { 10, 10, 2 }, { 10, 1, 2 }, { 9, 1, 2 }, { 8, 1, 2 }, { 7, 0, 2 }, { 1, 0, 2 }, { 6, 0, 2 }, { 9, 0, 2 }, { 10, 1, 2 }, { 10, 10, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 4, 0, 2 }, { 5, 3, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 10, 0, 2 }, { 9, 9, 2 }, { 11, 11, 2 }, { 3, 0, 2 }, { 8, 0, 2 }, { 10, 3, 2 }, { 1, 0, 2 }, { 3, 3, 2 }, { 9, 0, 2 }, { 6, 1, 2 }, { 8, 8, 2 }, { 14, 0, 2 }, { 14, 1, 2 }, { 14, 9, 2 }, { 14, 1, 2 }, { 5, 0, 2 }, { 13, 0, 2 }, { 14, 0, 2 }, { 16, 16, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 5, 0, 2 }, { 13, 0, 2 }, { 14, 0, 2 }, { 16, 16, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 18, 12, 2 }, { 15, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 1, 0, 2 }, { 21, 2, 2 }, { 1, 0, 2 }, { 17, 2, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 12, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 3, 2, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 3, 2, 2 }, { 2, 0, 2 }, { 3, 0, 2 }, { 5, 1, 2 }, { 2, 0, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 8, 0, 2 }, { 6, 1, 2 }, { 3, 1, 2 }, { 6, 0, 2 }, { 2, 0, 2 }, { 5, 1, 2 }, { 4, 1, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 5, 1, 2 }, { 6, 1, 2 }, { 3, 1, 2 }, { 5, 0, 2 }, { 5, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 9, 0, 2 }, { 9, 1, 2 }, { 1, 0, 2 }, { 4, 1, 2 }, { 13, 0, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 13, 1, 2 }, { 14, 1, 2 }, { 17, 16, 2 }, { 3, 0, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 4, 0, 2 }, { 9, 0, 2 }, { 10, 1, 2 }, { 10, 9, 2 }, { 10, 1, 2 }, { 10, 1, 2 }, { 15, 0, 2 }, { 20, 18, 2 }, { 15, 2, 2 }, { 17, 2, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 5, 1, 2 }, { 4, 0, 2 }, { 9, 1, 2 }, { 8, 1, 2 }, { 5, 1, 2 }, { 13, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 7, 1, 2 }, { 2, 1, 2 }, { 6, 1, 2 }, { 8, 1, 2 }, { 13, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 19, 0, 2 }, { 14, 14, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 13, 0, 2 }, { 14, 2, 2 }, { 16, 0, 2 }, { 17, 1, 2 }, { 4, 1, 2 }, { 3, 1, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 2, 1, 2 }, { 13, 0, 2 }, { 19, 19, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 7, 0, 2 }, { 7, 0, 2 }, { 1, 0, 2 }, { 6, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 7, 1, 2 }, { 2, 1, 2 }, { 6, 1, 2 }, { 7, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 25, 1, 2 }, { 14, 10, 2 }, { 1, 0, 2 }, { 14, 14, 2 }, { 19, 19, 2 }, { 14, 14, 2 }, { 1, 0, 2 }, { 19, 19, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 1, 1 }, { 15, 1 }, { 7, 1 }, { 0, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 3, 1 }, { 2, 0 }, { 2, 0 }, { 1, 1 }, { 2, 1 }, { 3, 1 }, { 6, 1 }, { 0, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 0, 1 }, { 1, 1 }, { 1, 1 }, { 2, 0 }, { 9, 1 }, { 0, 1 }, { 4, 1 }, { 2, 1 }, { 3, 1 }, { 2, 1 }, { 2, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 3, 1 }, { 0, 1 }, { 3, 0 }, { 6, 1 }, { 0, 1 }, { 1, 1 }, { 5, 1 }, { 1, 1 }, { 1, 1 }, { 9, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 6, 1 }, { 2, 1 }, { 11, 1 }, { 14, 1 }, { 11, 1 }, { 7, 1 }, { 2, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 2, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 5, 1 }, { 9, 1 }, { 6, 1 }, { 1, 1 }, { 2, 0 }, { 2, 0 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 4, 1 }, { 3, 1 }, { 3, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 4, 1 }, { 3, 1 }, { 3, 1 }, { 4, 1 }, { 2, 1 }, { 3, 1 }, { 1, 1 }, { 2, 1 }, { 0, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 3, 1 }, { 4, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 6, 0 }, { 2, 0 }, { 2, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 2, 1 }, { 1, 1 }, { 8, 1 }, { 19, 1 }, { 15, 1 }, { 15, 1 }, { 1, 1 }, { 0, 1 }, { 2, 1 }, { 4, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 4, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 4, 1 }, { 1, 1 }, { 1, 1 }, { 0, 1 }, { 2, 1 }, { 5, 1 }, { 1, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 0, 1 }, { 2, 1 }, { 9, 1 }, { 7, 1 }, { 5, 1 }, { 4, 1 }, { 4, 1 }, { 1, 1 }, { 6, 1 }, { 7, 1 }, { 5, 1 }, { 8, 1 }, { 7, 1 }, { 3, 1 }, { 1, 0 }, { 2, 0 } };
#define STAT_LEN 274

#define WL_RESW 19
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
    if ((N) <= 8) break; r8 = e.mem[(A) + 8]; \
    if ((N) <= 9) break; r9 = e.mem[(A) + 9]; \
    if ((N) <= 10) break; r10 = e.mem[(A) + 10]; \
    if ((N) <= 11) break; r11 = e.mem[(A) + 11]; \
    if ((N) <= 12) break; r12 = e.mem[(A) + 12]; \
    if ((N) <= 13) break; r13 = e.mem[(A) + 13]; \
    if ((N) <= 14) break; r14 = e.mem[(A) + 14]; \
    if ((N) <= 15) break; r15 = e.mem[(A) + 15]; \
    if ((N) <= 16) break; r16 = e.mem[(A) + 16]; \
    if ((N) <= 17) break; r17 = e.mem[(A) + 17]; \
    if ((N) <= 18) break; r18 = e.mem[(A) + 18]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
    case 7: r7 = (X); \
      break; \
    case 8: r8 = (X); \
      break; \
    case 9: r9 = (X); \
      break; \
    case 10: r10 = (X); \
      break; \
    case 11: r11 = (X); \
      break; \
    case 12: r12 = (X); \
      break; \
    case 13: r13 = (X); \
      break; \
    case 14: r14 = (X); \
      break; \
    case 15: r15 = (X); \
      break; \
    case 16: r16 = (X); \
      break; \
    case 17: r17 = (X); \
      break; \
    case 18: r18 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3; (V)[4] = r4; (V)[5] = r5; (V)[6] = r6; (V)[7] = r7; (V)[8] = r8; (V)[9] = r9; (V)[10] = r10; (V)[11] = r11; (V)[12] = r12; (V)[13] = r13; (V)[14] = r14; (V)[15] = r15; (V)[16] = r16; (V)[17] = r17; (V)[18] = r18;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3]; r4 = (V)[4]; r5 = (V)[5]; r6 = (V)[6]; r7 = (V)[7]; r8 = (V)[8]; r9 = (V)[9]; r10 = (V)[10]; r11 = (V)[11]; r12 = (V)[12]; r13 = (V)[13]; r14 = (V)[14]; r15 = (V)[15]; r16 = (V)[16]; r17 = (V)[17]; r18 = (V)[18];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7, Term r8, Term r9, Term r10, Term r11, Term r12, Term r13, Term r14, Term r15, Term r16, Term r17, Term r18

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18

#define WL_TABLE WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C11) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C12) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C13) WL_X(FID__________SRC_ECS_RESOURCE_REPLACE_JOIN_0_C14) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K15) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K16) WL_X(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0) WL_X(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0_K18) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C22) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C23) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C24) WL_X(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_K25) WL_X(FID__________SRC_ECS_COMMANDS_TX_FINISH_0) WL_X(FID__________SRC_ECS_COMMANDS_TX_FINISH_0_K39) WL_X(FID_LOCAL_FIXTURE_BODY_0) WL_X(FID_LOCAL_FIXTURE_BODY_0_K43) WL_X(FID_LOCAL_FIXTURE_BODY_0_K44) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K48) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K49) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K57) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K58) WL_X(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER) WL_X(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER_K68) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C70) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C71) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C72) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0_K73) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0_K78) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_C92) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K93) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K94) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0_K101) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K144) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C145) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C146) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C147) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K148) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K149) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K150) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K151) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K152) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C155) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C156) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C157) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K158) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K159) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K160) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K161) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K162) WL_X(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0) WL_X(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K173) WL_X(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K174) WL_X(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K175) WL_X(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K176) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K178) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K179) WL_X(FID__________SRC_ECS_WORLD_BARRIER_TRACED_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0_K201) WL_X(FID__________SRC_ECS_WORLD_BARRIER_0) WL_X(FID__________SRC_ECS_WORLD_BARRIER_0_K204) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K218) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K219) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K225) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K226) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K227) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C228) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C229) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C230) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K231) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K232) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K233) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K234) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C235) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C236) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C237) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K238) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K239) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K240) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K241) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K242) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K243) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K244) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K245) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K246) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K247) WL_X(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K248) WL_X(FID__________SRC_ECS_WORLD_ACCESS_EQUAL) WL_X(FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K258) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0_K265) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0_K267) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0_K269) WL_X(FID__________SRC_ECS_SCHEDULE_RUN_WITH_BARRIER_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K279) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K280) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K281) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C282) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K283) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K284) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C285) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K292) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K298) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K299) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K303) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K304) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K318) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K319) WL_X(FID_LIST_APPEND) WL_X(FID_LIST_APPEND_K321) WL_X(FID__________SRC_ECS_SCHEDULE_VALID) WL_X(FID__________SRC_ECS_SCHEDULE_VALID_K323) WL_X(FID__________SRC_ECS_SCHEDULE_VALID_K324) WL_X(FID__________SRC_ECS_SCHEDULE_VALID_K325) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K350) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K352) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K353) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K356) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K357) WL_X(FID__________SRC_ECS_SCHEDULE_BUILD_0) WL_X(FID__________SRC_ECS_SCHEDULE_BUILD_0_K359) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0_K362) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_C364) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K365) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K366) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K367) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K368) WL_X(FID_U32_SHOW_GO) WL_X(FID__________SRC_ECS_SCHEDULE_CONTAINS) WL_X(FID__________SRC_ECS_SCHEDULE_CONTAINS_K388) WL_X(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K392) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K393) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K394) WL_X(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K395) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K400) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K401) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K402) WL_X(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS) WL_X(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS_K425) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0_K427) WL_X(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID) WL_X(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K429) WL_X(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K430) WL_X(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K431) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C435) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C436) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C437) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K438) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K439) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K440) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K441) WL_X(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K442) WL_X(FID_U32_SHOW) WL_X(FID_LOCAL_FIXTURE_LOCAL_OBSERVED) WL_X(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K476) WL_X(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K477) WL_X(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K478) WL_X(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K479) WL_X(FID_LOCAL_DRIVER_RETRIED) WL_X(FID_LOCAL_DRIVER_RETRIED_K482) WL_X(FID_LOCAL_DRIVER_RETRIED_C483) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K485) WL_X(FID_LOCAL_FIXTURE_OBSERVED) WL_X(FID_LOCAL_FIXTURE_OBSERVED_K521) WL_X(FID_LOCAL_DRIVER_OBSERVED) WL_X(FID_LOCAL_DRIVER_OBSERVED_K526) WL_X(FID_LOCAL_DRIVER_OBSERVED_K527) WL_X(FID_LOCAL_DRIVER_OBSERVED_K528) WL_X(FID_LOCAL_DRIVER_OBSERVED_K529) WL_X(FID_LOCAL_DRIVER_OBSERVED_K530) WL_X(FID_LOCAL_DRIVER_OBSERVED_K531) WL_X(FID_LOCAL_FIXTURE_RUN) WL_X(FID_LOCAL_FIXTURE_RUN_K556) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C564) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C565) WL_X(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C566) WL_X(FID_LOCAL_FIXTURE_ATTACH) WL_X(FID_LOCAL_FIXTURE_ATTACH_C568) WL_X(FID_LOCAL_FIXTURE_ATTACH_K569) WL_X(FID_LOCAL_FIXTURE_ATTACH_C570) WL_X(FID_LOCAL_FIXTURE_ATTACH_C571) WL_X(FID_LOCAL_FIXTURE_ATTACH_C572) WL_X(FID_LOCAL_FIXTURE_ATTACH_K573) WL_X(FID_LOCAL_FIXTURE_ATTACH_K574) WL_X(FID_LOCAL_FIXTURE_ATTACH_K575) WL_X(FID_LOCAL_FIXTURE_ATTACH_K576) WL_X(FID_LOCAL_FIXTURE_ATTACH_K577) WL_X(FID_LOCAL_FIXTURE_ATTACH_K578) WL_X(FID_LOCAL_FIXTURE_ATTACH_K579) WL_X(FID_LOCAL_FIXTURE_ATTACH_K580) WL_X(FID_LOCAL_FIXTURE_ATTACH_K581) WL_X(FID_LOCAL_DRIVER_START) WL_X(FID_LOCAL_DRIVER_START_K604) WL_X(FID_LOCAL_DRIVER_START_K605) WL_X(FID_LOCAL_DRIVER_START_K606) WL_X(FID_LOCAL_DRIVER_START_C607) WL_X(FID_LOCAL_DRIVER_START_K608) WL_X(FID_LOCAL_DRIVER_START_K609) WL_X(FID__________SRC_ECS_WORLD_IO_WITH_NAMESPACE_0_C618) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C620) WL_X(FID_IO_BIND_K621) WL_X(FID_MAIN) WL_X(FID_MAIN_C623) WL_X(FID__________SRC_ECS_WORLD_IO_CREATE_0_C624) WL_X(FID__________SRC_ECS_WORLD_IO_CREATE_0_C625) WL_X(FID_MAIN_C626) WL_X(FID_MAIN_K627) WL_X(FID_MAIN_C628) WL_X(FID__________SRC_ECS_WORLD_NAMESPACE_FRESH) WL_X(FID_IO_PRINT) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 1

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

// A redirect cell holds its target's loc over a 24-bit count, which
// changes by atomic adds on the low half, so a host never reads it as one
// plain word.
INLINE u64 rfc_view(DEV u64* H, u64 r) {
  DEV u32* w = a32_at(H, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return rfc_view(H, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

INLINE u64 blk_loc(DEV u64* H, Term a) {
  return blk_shr(a) ? w64_load(&H[term_loc(a)]) >> 24 : term_loc(a);
}

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE u32 blk_span(Term t) {
  u32 c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 r    = term_loc(t);
  u64 cell = rfc_view(H, r);
  u64 src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = arr ? c : buf_wcls(c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_RFCS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      u32 to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 116ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 0), 117ull, term_ctr(CID_SCON, STAT_OFF + 2), 111ull, term_ctr(CID_SCON, STAT_OFF + 4), 67ull, term_ctr(CID_SCON, STAT_OFF + 6), term_pak(CID__________SRC_ECS_SCHEDULE_APPLIED, 0), term_pak(CID_NIL, 0), 44ull, term_pak(CID_SNIL, 0), 48ull, term_pak(CID_SNIL, 0), 2, 0, 0, term_pak(CID_NIL, 0), 100ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 20), 105ull, term_ctr(CID_SCON, STAT_OFF + 22), 114ull, term_ctr(CID_SCON, STAT_OFF + 24), 116ull, term_ctr(CID_SCON, STAT_OFF + 26), 101ull, term_ctr(CID_SCON, STAT_OFF + 28), 114ull, term_ctr(CID_SCON, STAT_OFF + 30), 121ull, term_pak(CID_SNIL, 0), 114ull, term_ctr(CID_SCON, STAT_OFF + 34), 116ull, term_ctr(CID_SCON, STAT_OFF + 36), 101ull, term_ctr(CID_SCON, STAT_OFF + 38), 114ull, term_ctr(CID_SCON, STAT_OFF + 40), 32ull, term_ctr(CID_SCON, STAT_OFF + 42), 58ull, term_ctr(CID_SCON, STAT_OFF + 44), 82ull, term_ctr(CID_SCON, STAT_OFF + 46), 79ull, term_ctr(CID_SCON, STAT_OFF + 48), 82ull, term_ctr(CID_SCON, STAT_OFF + 50), 82ull, term_ctr(CID_SCON, STAT_OFF + 52), 69ull, term_ctr(CID_SCON, STAT_OFF + 54), 61ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 58), 97ull, term_ctr(CID_SCON, STAT_OFF + 60), 99ull, term_ctr(CID_SCON, STAT_OFF + 62), 111ull, term_ctr(CID_SCON, STAT_OFF + 64), 108ull, term_ctr(CID_SCON, STAT_OFF + 66), 32ull, term_ctr(CID_SCON, STAT_OFF + 68), 101ull, term_ctr(CID_SCON, STAT_OFF + 58), 99ull, term_ctr(CID_SCON, STAT_OFF + 72), 114ull, term_ctr(CID_SCON, STAT_OFF + 74), 117ull, term_ctr(CID_SCON, STAT_OFF + 76), 111ull, term_ctr(CID_SCON, STAT_OFF + 78), 115ull, term_ctr(CID_SCON, STAT_OFF + 80), 101ull, term_ctr(CID_SCON, STAT_OFF + 82), 114ull, term_ctr(CID_SCON, STAT_OFF + 84), 32ull, term_ctr(CID_SCON, STAT_OFF + 86), 10ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 22), 105ull, term_ctr(CID_SCON, STAT_OFF + 92), 97ull, term_ctr(CID_SCON, STAT_OFF + 94), 102ull, term_ctr(CID_SCON, STAT_OFF + 96), 101ull, term_pak(CID_SNIL, 0), 114ull, term_ctr(CID_SCON, STAT_OFF + 100), 117ull, term_ctr(CID_SCON, STAT_OFF + 102), 108ull, term_ctr(CID_SCON, STAT_OFF + 104), 105ull, term_ctr(CID_SCON, STAT_OFF + 106), 97ull, term_ctr(CID_SCON, STAT_OFF + 108), 102ull, term_ctr(CID_SCON, STAT_OFF + 110), 32ull, term_ctr(CID_SCON, STAT_OFF + 112), 100ull, term_ctr(CID_SCON, STAT_OFF + 114), 101ull, term_ctr(CID_SCON, STAT_OFF + 116), 116ull, term_ctr(CID_SCON, STAT_OFF + 118), 99ull, term_ctr(CID_SCON, STAT_OFF + 120), 101ull, term_ctr(CID_SCON, STAT_OFF + 122), 112ull, term_ctr(CID_SCON, STAT_OFF + 124), 120ull, term_ctr(CID_SCON, STAT_OFF + 126), 101ull, term_ctr(CID_SCON, STAT_OFF + 128), 32ull, term_ctr(CID_SCON, STAT_OFF + 130), 58ull, term_ctr(CID_SCON, STAT_OFF + 132), 82ull, term_ctr(CID_SCON, STAT_OFF + 134), 79ull, term_ctr(CID_SCON, STAT_OFF + 136), 82ull, term_ctr(CID_SCON, STAT_OFF + 138), 82ull, term_ctr(CID_SCON, STAT_OFF + 140), 69ull, term_ctr(CID_SCON, STAT_OFF + 142), 108ull, term_ctr(CID_SCON, STAT_OFF + 44), 97ull, term_ctr(CID_SCON, STAT_OFF + 146), 99ull, term_ctr(CID_SCON, STAT_OFF + 148), 111ull, term_ctr(CID_SCON, STAT_OFF + 150), 76ull, term_ctr(CID_SCON, STAT_OFF + 152), 104ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 156), 97ull, term_ctr(CID_SCON, STAT_OFF + 158), 116ull, term_ctr(CID_SCON, STAT_OFF + 160), 116ull, term_ctr(CID_SCON, STAT_OFF + 162), 97ull, term_ctr(CID_SCON, STAT_OFF + 164), 32ull, term_ctr(CID_SCON, STAT_OFF + 166), 58ull, term_ctr(CID_SCON, STAT_OFF + 168), 82ull, term_ctr(CID_SCON, STAT_OFF + 170), 79ull, term_ctr(CID_SCON, STAT_OFF + 172), 82ull, term_ctr(CID_SCON, STAT_OFF + 174), 82ull, term_ctr(CID_SCON, STAT_OFF + 176), 69ull, term_ctr(CID_SCON, STAT_OFF + 178), 99ull, term_ctr(CID_SCON, STAT_OFF + 6), 32ull, term_ctr(CID_SCON, STAT_OFF + 182), 108ull, term_ctr(CID_SCON, STAT_OFF + 184), 97ull, term_ctr(CID_SCON, STAT_OFF + 186), 99ull, term_ctr(CID_SCON, STAT_OFF + 188), 111ull, term_ctr(CID_SCON, STAT_OFF + 190), 76ull, term_ctr(CID_SCON, STAT_OFF + 192), 110ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 196), 105ull, term_ctr(CID_SCON, STAT_OFF + 198), 116ull, term_ctr(CID_SCON, STAT_OFF + 200), 97ull, term_ctr(CID_SCON, STAT_OFF + 202), 114ull, term_ctr(CID_SCON, STAT_OFF + 204), 116ull, term_ctr(CID_SCON, STAT_OFF + 206), 115ull, term_ctr(CID_SCON, STAT_OFF + 208), 105ull, term_ctr(CID_SCON, STAT_OFF + 210), 103ull, term_ctr(CID_SCON, STAT_OFF + 212), 101ull, term_ctr(CID_SCON, STAT_OFF + 214), 114ull, term_ctr(CID_SCON, STAT_OFF + 216), 32ull, term_ctr(CID_SCON, STAT_OFF + 218), 58ull, term_ctr(CID_SCON, STAT_OFF + 220), 82ull, term_ctr(CID_SCON, STAT_OFF + 222), 79ull, term_ctr(CID_SCON, STAT_OFF + 224), 82ull, term_ctr(CID_SCON, STAT_OFF + 226), 82ull, term_ctr(CID_SCON, STAT_OFF + 228), 69ull, term_ctr(CID_SCON, STAT_OFF + 230), 115ull, term_ctr(CID_SCON, STAT_OFF + 22), 117ull, term_ctr(CID_SCON, STAT_OFF + 234), 102ull, term_ctr(CID_SCON, STAT_OFF + 236), 101ull, term_ctr(CID_SCON, STAT_OFF + 238), 114ull, term_ctr(CID_SCON, STAT_OFF + 240), 32ull, term_ctr(CID_SCON, STAT_OFF + 242), 110ull, term_ctr(CID_SCON, STAT_OFF + 244), 111ull, term_ctr(CID_SCON, STAT_OFF + 246), 105ull, term_ctr(CID_SCON, STAT_OFF + 248), 116ull, term_ctr(CID_SCON, STAT_OFF + 250), 97ull, term_ctr(CID_SCON, STAT_OFF + 252), 101ull, term_ctr(CID_SCON, STAT_OFF + 254), 114ull, term_ctr(CID_SCON, STAT_OFF + 256), 99ull, term_ctr(CID_SCON, STAT_OFF + 258), 32ull, term_ctr(CID_SCON, STAT_OFF + 260), 100ull, term_ctr(CID_SCON, STAT_OFF + 262), 108ull, term_ctr(CID_SCON, STAT_OFF + 264), 114ull, term_ctr(CID_SCON, STAT_OFF + 266), 111ull, term_ctr(CID_SCON, STAT_OFF + 268), 119ull, term_ctr(CID_SCON, STAT_OFF + 270) };

INLINE Term spin_1(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_4 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_4 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_1);
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_0(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_1(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_6 = 0;
  Term _reversed_0 = r0;
  Term _output_0 = r1;
  WL_SPIN
    if (term_aux(_reversed_0) == CID_NIL) {
      _v_6 = _output_0;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _reversed_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_1 + 1] = rfc_seal(e, _output_0);
      r0 = _f_3;
      r1 = term_ctr(CID_CON, _nd_1);
      _reversed_0 = r0;
      _output_0 = r1;
      WL_AGAIN(spin_2);
    }
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_2 = 0;
  Term _left_0 = r0;
  Term _right_0 = r1;
  WL_SPIN
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _o_0[1];
    if (spin_0(e, _o_0, _left_0, _left_0 == h0 ? q0 : blk_loc(e.mem, _left_0)) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_3 = _v_4;
    Term _v_5 = 0;
    Term _o_1[1];
    if (spin_2(e, _o_1, _v_3, _v_3 == h1 ? q1 : _v_3 == h0 ? q0 : blk_loc(e.mem, _v_3), _right_0, _right_0 == h1 ? q1 : blk_loc(e.mem, _right_0)) == 0) {
      return 0;
    }
    _v_5 = _o_1[0];
    _v_2 = _v_5;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _world_1 = r0;
  Term _published_1 = r1;
  WL_SPIN
    Term _fb_1[15];
    u64 _sp_1 = ctr_take(e, _world_1, 15, _fb_1);
    u32 _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    u32 _f_4 = _fb_1[2];
    Term _f_5 = _fb_1[3];
    u32 _f_6 = _fb_1[4];
    Term _f_7 = _fb_1[5];
    Term _f_8 = _fb_1[6];
    Term _f_9 = _fb_1[7];
    Term _f_10 = _fb_1[8];
    Term _f_11 = _fb_1[9];
    Term _f_12 = _fb_1[10];
    Term _f_13 = _fb_1[11];
    Term _f_14 = _fb_1[12];
    u32 _f_15 = _fb_1[13];
    u32 _f_16 = _fb_1[14];
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[1];
    if (spin_3(e, _o_0, _f_12, _f_12 == h1 ? q1 : _f_12 == h0 ? q0 : blk_loc(e.mem, _f_12), _published_1, _published_1 == h1 ? q1 : blk_loc(e.mem, _published_1)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
    u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(15));
    e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_1 + 1] = rfc_seal(e, _f_3);
    e.mem[_nd_1 + 2] = rfc_seal(e, _f_4);
    e.mem[_nd_1 + 3] = rfc_seal(e, _f_5);
    e.mem[_nd_1 + 4] = rfc_seal(e, _f_6);
    e.mem[_nd_1 + 5] = rfc_seal(e, _f_7);
    e.mem[_nd_1 + 6] = rfc_seal(e, _f_8);
    e.mem[_nd_1 + 7] = rfc_seal(e, _f_9);
    e.mem[_nd_1 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_1 + 9] = rfc_seal(e, _f_11);
    e.mem[_nd_1 + 10] = rfc_seal(e, _v_2);
    e.mem[_nd_1 + 11] = rfc_seal(e, _f_13);
    e.mem[_nd_1 + 12] = rfc_seal(e, _f_14);
    e.mem[_nd_1 + 13] = rfc_seal(e, _f_15);
    e.mem[_nd_1 + 14] = rfc_seal(e, _f_16);
    _v_1 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_1);
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term _v_2 = 0;
  Term _world_1 = r0;
  u32 _command_0 = r1;
  Term _command_1 = r2;
  WL_SPIN
    Term _fb_3[15];
    u64 _sp_3 = ctr_take(e, _world_1, 15, _fb_3);
    u32 _f_4 = _fb_3[0];
    u32 _f_5 = _fb_3[1];
    u32 _f_6 = _fb_3[2];
    Term _f_7 = _fb_3[3];
    u32 _f_8 = _fb_3[4];
    Term _f_9 = _fb_3[5];
    Term _f_10 = _fb_3[6];
    Term _f_11 = _fb_3[7];
    Term _f_12 = _fb_3[8];
    Term _f_13 = _fb_3[9];
    Term _f_14 = _fb_3[10];
    Term _f_15 = _fb_3[11];
    Term _f_16 = _fb_3[12];
    u32 _f_17 = _fb_3[13];
    u32 _f_18 = _fb_3[14];
    Term _b_0 = 0;
    if (_command_0 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_0 + 0] = rfc_seal(e, _command_1);
      _b_0 = term_ctr(CID__________SRC_ECS_DEFERRED_COMMAND_RAW, _nd_0);
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_1 + 0] = rfc_seal(e, _command_1);
      _b_0 = term_ctr(CID__________SRC_ECS_DEFERRED_COMMAND_OBSERVED, _nd_1);
    }
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _f_15);
    u64 _nd_3 = _sp_3 >= HEAP_OFF ? _sp_3 : heap_alloc(e, cls_fit(15));
    e.mem[_nd_3 + 0] = rfc_seal(e, _f_4);
    e.mem[_nd_3 + 1] = rfc_seal(e, _f_5);
    e.mem[_nd_3 + 2] = rfc_seal(e, _f_6);
    e.mem[_nd_3 + 3] = rfc_seal(e, _f_7);
    e.mem[_nd_3 + 4] = rfc_seal(e, _f_8);
    e.mem[_nd_3 + 5] = rfc_seal(e, _f_9);
    e.mem[_nd_3 + 6] = rfc_seal(e, _f_10);
    e.mem[_nd_3 + 7] = rfc_seal(e, _f_11);
    e.mem[_nd_3 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_3 + 9] = rfc_seal(e, _f_13);
    e.mem[_nd_3 + 10] = rfc_seal(e, _f_14);
    e.mem[_nd_3 + 11] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
    e.mem[_nd_3 + 12] = rfc_seal(e, _f_16);
    e.mem[_nd_3 + 13] = rfc_seal(e, _f_17);
    e.mem[_nd_3 + 14] = rfc_seal(e, _f_18);
    _v_2 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_3);
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_27 = 0;
  u32 _v_28 = 0;
  u32 _value_1 = r0;
  WL_SPIN
    _v_27 = _value_1;
    _v_28 = _value_1;
  break;
  }
  o[0] = _v_27;
  o[1] = _v_28;
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3, u32 r4, Term r5, u64 q5, u32 r6, Term r7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, u32 r14) {
  u32 wpoll = 0;
  Term h5 = r5;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  u32 _observed_0 = r0;
  u32 _observed_1 = r1;
  u32 _namespace_0 = r2;
  u32 _allocator_0 = r3;
  u32 _allocator_1 = r4;
  Term _allocator_2 = r5;
  u32 _allocator_3 = r6;
  Term _allocator_4 = r7;
  Term _allocator_5 = r8;
  Term _allocator_6 = r9;
  Term _events_0 = r10;
  Term _pending_0 = r11;
  Term _registrations_0 = r12;
  u32 _nextSystemId_0 = r13;
  u32 _clock_0 = r14;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_0 + 0] = rfc_seal(e, _namespace_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _allocator_0);
    e.mem[_nd_0 + 2] = rfc_seal(e, _allocator_1);
    e.mem[_nd_0 + 3] = rfc_seal(e, _allocator_2);
    e.mem[_nd_0 + 4] = rfc_seal(e, _allocator_3);
    e.mem[_nd_0 + 5] = rfc_seal(e, _allocator_4);
    e.mem[_nd_0 + 6] = rfc_seal(e, _allocator_5);
    e.mem[_nd_0 + 7] = rfc_seal(e, _allocator_6);
    e.mem[_nd_0 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 9] = rfc_seal(e, _observed_0);
    e.mem[_nd_0 + 10] = rfc_seal(e, _events_0);
    e.mem[_nd_0 + 11] = rfc_seal(e, _pending_0);
    e.mem[_nd_0 + 12] = rfc_seal(e, _registrations_0);
    e.mem[_nd_0 + 13] = rfc_seal(e, _nextSystemId_0);
    e.mem[_nd_0 + 14] = rfc_seal(e, _clock_0);
    _v_31 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
    _v_32 = _observed_1;
  break;
  }
  o[0] = _v_31;
  o[1] = _v_32;
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _world_0 = r0;
  WL_SPIN
    Term _fb_1[15];
    u64 _sp_1 = ctr_take(e, _world_0, 15, _fb_1);
    u32 _f_6 = _fb_1[0];
    u32 _f_7 = _fb_1[1];
    u32 _f_8 = _fb_1[2];
    Term _f_9 = _fb_1[3];
    u32 _f_10 = _fb_1[4];
    Term _f_11 = _fb_1[5];
    Term _f_12 = _fb_1[6];
    Term _f_13 = _fb_1[7];
    Term _f_14 = _fb_1[8];
    Term _f_15 = _fb_1[9];
    Term _f_16 = _fb_1[10];
    Term _f_17 = _fb_1[11];
    Term _f_18 = _fb_1[12];
    u32 _f_19 = _fb_1[13];
    u32 _f_20 = _fb_1[14];
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _o_0[2];
    if (spin_8(e, _o_0, _f_15) == 0) {
      return 0;
    }
    _v_25 = _o_0[0];
    _v_26 = _o_0[1];
    _v_23 = _v_25;
    _v_24 = _v_26;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _o_1[2];
    if (spin_9(e, _o_1, _v_23, _v_24, _f_6, _f_7, _f_8, _f_9, _f_9 == h0 ? q0 : blk_loc(e.mem, _f_9), _f_10, _f_11, _f_12, _f_12 == h0 ? q0 : blk_loc(e.mem, _f_12), _f_13, _f_13 == h0 ? q0 : blk_loc(e.mem, _f_13), _f_16, _f_16 == h0 ? q0 : blk_loc(e.mem, _f_16), _f_17, _f_17 == h0 ? q0 : blk_loc(e.mem, _f_17), _f_18, _f_18 == h0 ? q0 : blk_loc(e.mem, _f_18), _f_19, _f_20) == 0) {
      return 0;
    }
    _v_29 = _o_1[0];
    _v_30 = _o_1[1];
    _v_21 = _v_29;
    _v_22 = _v_30;
    spare_free(e, cls_fit(15), _sp_1);
  break;
  }
  o[0] = _v_21;
  o[1] = _v_22;
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term _v_40 = 0;
  Term _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _observed_2 = r0;
  u32 _observed_3 = r1;
  Term _undo_0 = r2;
  Term _commands_0 = r3;
  Term _events_1 = r4;
  u32 _trace_0 = r5;
  Term _trace_1 = r6;
  WL_SPIN
    _v_40 = _observed_2;
    _v_41 = _undo_0;
    _v_42 = _commands_0;
    _v_43 = _events_1;
    _v_44 = _trace_0;
    _v_45 = _trace_1;
    _v_46 = _observed_3;
  break;
  }
  o[0] = _v_40;
  o[1] = _v_41;
  o[2] = _v_42;
  o[3] = _v_43;
  o[4] = _v_44;
  o[5] = _v_45;
  o[6] = _v_46;
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _tx_0 = r0;
  Term _tx_1 = r1;
  Term _tx_2 = r2;
  Term _tx_3 = r3;
  u32 _tx_4 = r4;
  Term _tx_5 = r5;
  WL_SPIN
    Term _v_17 = 0;
    u32 _v_18 = 0;
    Term _v_19 = 0;
    u32 _v_20 = 0;
    Term _o_2[2];
    if (spin_7(e, _o_2, _tx_0, _tx_0 == h0 ? q0 : blk_loc(e.mem, _tx_0)) == 0) {
      return 0;
    }
    _v_19 = _o_2[0];
    _v_20 = _o_2[1];
    _v_17 = _v_19;
    _v_18 = _v_20;
    Term _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _o_3[7];
    if (spin_10(e, _o_3, _v_17, _v_17 == h5 ? q5 : _v_17 == h3 ? q3 : _v_17 == h2 ? q2 : _v_17 == h1 ? q1 : _v_17 == h0 ? q0 : blk_loc(e.mem, _v_17), _v_18, _tx_1, _tx_1 == h1 ? q1 : blk_loc(e.mem, _tx_1), _tx_2, _tx_2 == h2 ? q2 : blk_loc(e.mem, _tx_2), _tx_3, _tx_3 == h3 ? q3 : blk_loc(e.mem, _tx_3), _tx_4, _tx_5, _tx_5 == h5 ? q5 : blk_loc(e.mem, _tx_5)) == 0) {
      return 0;
    }
    _v_33 = _o_3[0];
    _v_34 = _o_3[1];
    _v_35 = _o_3[2];
    _v_36 = _o_3[3];
    _v_37 = _o_3[4];
    _v_38 = _o_3[5];
    _v_39 = _o_3[6];
    _v_10 = _v_33;
    _v_11 = _v_34;
    _v_12 = _v_35;
    _v_13 = _v_36;
    _v_14 = _v_37;
    _v_15 = _v_38;
    _v_16 = _v_39;
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _world_1 = r0;
  u32 _replacement_1 = r1;
  WL_SPIN
    Term _fb_3[15];
    u64 _sp_3 = ctr_take(e, _world_1, 15, _fb_3);
    u32 _f_33 = _fb_3[0];
    u32 _f_34 = _fb_3[1];
    u32 _f_35 = _fb_3[2];
    Term _f_36 = _fb_3[3];
    u32 _f_37 = _fb_3[4];
    Term _f_38 = _fb_3[5];
    Term _f_39 = _fb_3[6];
    Term _f_40 = _fb_3[7];
    Term _f_41 = _fb_3[8];
    Term _f_42 = _fb_3[9];
    Term _f_43 = _fb_3[10];
    Term _f_44 = _fb_3[11];
    Term _f_45 = _fb_3[12];
    u32 _f_46 = _fb_3[13];
    u32 _f_47 = _fb_3[14];
    u64 _nd_4 = _sp_3 >= HEAP_OFF ? _sp_3 : heap_alloc(e, cls_fit(15));
    e.mem[_nd_4 + 0] = rfc_seal(e, _f_33);
    e.mem[_nd_4 + 1] = rfc_seal(e, _f_34);
    e.mem[_nd_4 + 2] = rfc_seal(e, _f_35);
    e.mem[_nd_4 + 3] = rfc_seal(e, _f_36);
    e.mem[_nd_4 + 4] = rfc_seal(e, _f_37);
    e.mem[_nd_4 + 5] = rfc_seal(e, _f_38);
    e.mem[_nd_4 + 6] = rfc_seal(e, _f_39);
    e.mem[_nd_4 + 7] = rfc_seal(e, _f_40);
    e.mem[_nd_4 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_4 + 9] = rfc_seal(e, _replacement_1);
    e.mem[_nd_4 + 10] = rfc_seal(e, _f_43);
    e.mem[_nd_4 + 11] = rfc_seal(e, _f_44);
    e.mem[_nd_4 + 12] = rfc_seal(e, _f_45);
    e.mem[_nd_4 + 13] = rfc_seal(e, _f_46);
    e.mem[_nd_4 + 14] = rfc_seal(e, _f_47);
    _v_63 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_4);
    _v_64 = _f_42;
  break;
  }
  o[0] = _v_63;
  o[1] = _v_64;
  return 1;
}

INLINE Term spin_15(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_84 = 0;
  Term _replaced_3 = r0;
  u32 _replaced_4 = r1;
  WL_SPIN
    _v_84 = _replaced_3;
  break;
  }
  o[0] = _v_84;
  return 1;
}

INLINE Term spin_14(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_78 = 0;
  Term _world_2 = r0;
  u32 _old_0 = r1;
  WL_SPIN
    Term _v_79 = 0;
    u32 _v_80 = 0;
    Term _v_81 = 0;
    u32 _v_82 = 0;
    Term _o_6[2];
    if (spin_12(e, _o_6, _world_2, _world_2 == h0 ? q0 : blk_loc(e.mem, _world_2), _old_0) == 0) {
      return 0;
    }
    _v_81 = _o_6[0];
    _v_82 = _o_6[1];
    _v_79 = _v_81;
    _v_80 = _v_82;
    Term _v_83 = 0;
    Term _o_7[1];
    if (spin_15(e, _o_7, _v_79, _v_79 == h0 ? q0 : blk_loc(e.mem, _v_79), _v_80) == 0) {
      return 0;
    }
    _v_83 = _o_7[0];
    _v_78 = _v_83;
  break;
  }
  o[0] = _v_78;
  return 1;
}

INLINE Term spin_13(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  Term _v_74 = 0;
  u32 _v_75 = 0;
  Term _v_76 = 0;
  Term _replaced_0 = r0;
  u32 _replaced_1 = r1;
  Term _undo_1 = r2;
  Term _commands_1 = r3;
  Term _events_2 = r4;
  u32 _trace_2 = r5;
  Term _trace_3 = r6;
  WL_SPIN
    u64 _nd_5 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_5 + 0] = _replaced_1;
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, term_clo(FID__________SRC_ECS_RESOURCE_REPLACE_JOIN_0_C14, _nd_5));
    e.mem[_nd_6 + 1] = rfc_seal(e, _undo_1);
    _v_71 = _replaced_0;
    _v_72 = term_ctr(CID_CON, _nd_6);
    _v_73 = _commands_1;
    _v_74 = _events_2;
    _v_75 = _trace_2;
    _v_76 = _trace_3;
  break;
  }
  o[0] = _v_71;
  o[1] = _v_72;
  o[2] = _v_73;
  o[3] = _v_74;
  o[4] = _v_75;
  o[5] = _v_76;
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, u32 r6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term _v_53 = 0;
  Term _v_54 = 0;
  Term _v_55 = 0;
  Term _v_56 = 0;
  u32 _v_57 = 0;
  Term _v_58 = 0;
  Term _tx_6 = r0;
  Term _tx_7 = r1;
  Term _tx_8 = r2;
  Term _tx_9 = r3;
  u32 _tx_10 = r4;
  Term _tx_11 = r5;
  u32 _replacement_0 = r6;
  WL_SPIN
    Term _v_59 = 0;
    u32 _v_60 = 0;
    Term _v_61 = 0;
    u32 _v_62 = 0;
    Term _o_5[2];
    if (spin_12(e, _o_5, _tx_6, _tx_6 == h0 ? q0 : blk_loc(e.mem, _tx_6), _replacement_0) == 0) {
      return 0;
    }
    _v_61 = _o_5[0];
    _v_62 = _o_5[1];
    _v_59 = _v_61;
    _v_60 = _v_62;
    Term _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    Term _v_70 = 0;
    Term _o_9[6];
    if (spin_13(e, _o_9, _v_59, _v_59 == h5 ? q5 : _v_59 == h3 ? q3 : _v_59 == h2 ? q2 : _v_59 == h1 ? q1 : _v_59 == h0 ? q0 : blk_loc(e.mem, _v_59), _v_60, _tx_7, _tx_7 == h1 ? q1 : blk_loc(e.mem, _tx_7), _tx_8, _tx_8 == h2 ? q2 : blk_loc(e.mem, _tx_8), _tx_9, _tx_9 == h3 ? q3 : blk_loc(e.mem, _tx_9), _tx_10, _tx_11, _tx_11 == h5 ? q5 : blk_loc(e.mem, _tx_11)) == 0) {
      return 0;
    }
    _v_65 = _o_9[0];
    _v_66 = _o_9[1];
    _v_67 = _o_9[2];
    _v_68 = _o_9[3];
    _v_69 = _o_9[4];
    _v_70 = _o_9[5];
    _v_53 = _v_65;
    _v_54 = _v_66;
    _v_55 = _v_67;
    _v_56 = _v_68;
    _v_57 = _v_69;
    _v_58 = _v_70;
  break;
  }
  o[0] = _v_53;
  o[1] = _v_54;
  o[2] = _v_55;
  o[3] = _v_56;
  o[4] = _v_57;
  o[5] = _v_58;
  return 1;
}

INLINE Term spin_16(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_87 = 0;
  Term _v_88 = 0;
  Term _declaration_0 = r0;
  u32 _declaration_1 = r1;
  Term _declaration_2 = r2;
  Term _declaration_3 = r3;
  WL_SPIN
    term_sink(e, _declaration_0);
    _v_87 = _declaration_2;
    _v_88 = _declaration_3;
  break;
  }
  o[0] = _v_87;
  o[1] = _v_88;
  return 1;
}

INLINE Term spin_17(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_90 = 0;
  Term _cap_0 = r0;
  Term _cap_1 = r1;
  WL_SPIN
    term_sink(e, _cap_0);
    _v_90 = _cap_1;
  break;
  }
  o[0] = _v_90;
  return 1;
}

INLINE Term spin_18(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _world_1 = r0;
  Term _published_0 = r1;
  WL_SPIN
    if (term_aux(_published_0) == CID_NIL) {
      _v_1 = _world_1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _published_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
      Term _v_2 = 0;
      Term _o_0[1];
      Term _a_0 = term_ctr(CID_CON, _nd_0);
      if (spin_4(e, _o_0, _world_1, _world_1 == h0 ? q0 : blk_loc(e.mem, _world_1), _a_0, _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      _v_1 = _v_2;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_19(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_1 = 0;
  Term _commands_1 = r0;
  Term _world_1 = r1;
  WL_SPIN
    if (term_aux(_commands_1) == CID_NIL) {
      _v_1 = _world_1;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_DEFERRED_COMMAND_RAW) {
        _o_0 = 0;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        _o_1 = _f_2;
      } else {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_3 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_3;
      }
      Term _v_2 = 0;
      Term _v_3 = 0;
      Term _o_2[1];
      if (spin_5(e, _o_2, _world_1, _world_1 == h1 ? q1 : blk_loc(e.mem, _world_1), _o_0, _o_1, _o_1 == h1 ? q1 : _o_1 == h0 ? q0 : blk_loc(e.mem, _o_1)) == 0) {
        return 0;
      }
      _v_3 = _o_2[0];
      _v_2 = _v_3;
      spare_free(e, cls_fit(2), _sp_0);
      r0 = _f_1;
      r1 = _v_2;
      _commands_1 = r0;
      _world_1 = r1;
      WL_AGAIN(spin_19);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_20(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_19 = 0;
  Term _cap_0 = r0;
  Term _cap_1 = r1;
  WL_SPIN
    term_sink(e, _cap_1);
    _v_19 = _cap_0;
  break;
  }
  o[0] = _v_19;
  return 1;
}

INLINE Term spin_21(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _fail_2 = r0;
  WL_SPIN
    if (_fail_2 == 1) {
      _v_2 = 1;
    } else {
      _v_2 = 0;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_23(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_5 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_5 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_23);
    }
  break;
  }
  o[0] = _v_5;
  return 1;
}

INLINE Term spin_22(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_3 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_4 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_23(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_4 = _o_0[0];
    _v_3 = _v_4;
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_24(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_7 = 0;
  Term _world_1 = r0;
  Term _commands_1 = r1;
  WL_SPIN
    Term _v_8 = 0;
    Term _o_2[1];
    if (spin_19(e, _o_2, _commands_1, _commands_1 == h1 ? q1 : blk_loc(e.mem, _commands_1), _world_1, _world_1 == h0 ? q0 : blk_loc(e.mem, _world_1)) == 0) {
      return 0;
    }
    _v_8 = _o_2[0];
    _v_7 = _v_8;
  break;
  }
  o[0] = _v_7;
  return 1;
}

INLINE Term spin_25(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_13 = 0;
  Term _world_2 = r0;
  Term _events_1 = r1;
  WL_SPIN
    Term _v_14 = 0;
    Term _o_5[1];
    if (spin_18(e, _o_5, _world_2, _world_2 == h0 ? q0 : blk_loc(e.mem, _world_2), _events_1, _events_1 == h1 ? q1 : blk_loc(e.mem, _events_1)) == 0) {
      return 0;
    }
    _v_14 = _o_5[0];
    _v_13 = _v_14;
  break;
  }
  o[0] = _v_13;
  return 1;
}

INLINE Term spin_26(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      _v_2 = 1;
    } else {
      _v_2 = 0;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_27(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  u32 _v_4 = 0;
  Term _v_5 = 0;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _local_0 = r0;
  Term _output_0 = r1;
  Term _result_11 = r2;
  u32 _result_12 = r3;
  WL_SPIN
    if (_result_12 == 0) {
      _v_4 = 0;
      _v_5 = _result_11;
      _v_6 = _local_0;
      _v_7 = _output_0;
    } else {
      term_sink(e, _output_0);
      _v_4 = 1;
      _v_5 = _result_11;
      _v_6 = _local_0;
      _v_7 = 0;
    }
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  o[2] = _v_6;
  o[3] = _v_7;
  return 1;
}

INLINE Term spin_28(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  Term _world_1 = r0;
  WL_SPIN
    _v_12 = _world_1;
    _v_13 = term_pak(CID_NIL, 0);
    _v_14 = term_pak(CID_NIL, 0);
    _v_15 = term_pak(CID_NIL, 0);
    _v_16 = 0;
    _v_17 = 0;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_29(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  u32 _v_11 = 0;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _namespace_0 = r0;
  u32 _id_0 = r1;
  Term _name_0 = r2;
  Term _access_0 = r3;
  u32 _outcome_0 = r4;
  Term _outcome_1 = r5;
  Term _outcome_2 = r6;
  Term _outcome_3 = r7;
  WL_SPIN
    if (_outcome_0 == 0) {
      _v_9 = 0;
      _v_10 = _outcome_1;
      _v_11 = _namespace_0;
      _v_12 = _id_0;
      _v_13 = _name_0;
      _v_14 = _access_0;
      _v_15 = _outcome_2;
      _v_16 = 1;
      _v_17 = _outcome_3;
    } else {
      _v_9 = 0;
      _v_10 = _outcome_1;
      _v_11 = _namespace_0;
      _v_12 = _id_0;
      _v_13 = _name_0;
      _v_14 = _access_0;
      _v_15 = _outcome_2;
      _v_16 = 0;
      _v_17 = 0;
    }
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_30(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      _v_2 = 0;
    } else {
      _v_2 = _b_0;
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_31(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  u32 _v_19 = 0;
  u32 _trace_0 = r0;
  Term _trace_1 = r1;
  u32 _result_0 = r2;
  Term _result_1 = r3;
  u32 _result_2 = r4;
  u32 _result_3 = r5;
  Term _result_4 = r6;
  Term _result_5 = r7;
  Term _result_6 = r8;
  u32 _result_7 = r9;
  Term _result_8 = r10;
  WL_SPIN
    if (_result_0 == 0) {
      if (_result_7 == 1) {
        term_sink(e, _result_8);
        _v_10 = _result_2;
        _v_11 = _result_3;
        _v_12 = _result_4;
        _v_13 = _result_5;
        _v_14 = _result_6;
        _v_15 = 0;
        _v_16 = _result_1;
        _v_17 = _trace_0;
        _v_18 = _trace_1;
        _v_19 = 0;
      } else {
        _v_10 = _result_2;
        _v_11 = _result_3;
        _v_12 = _result_4;
        _v_13 = _result_5;
        _v_14 = _result_6;
        _v_15 = 1;
        _v_16 = _result_1;
        _v_17 = _trace_0;
        _v_18 = _trace_1;
        _v_19 = 0;
      }
    } else {
      _v_10 = _result_2;
      _v_11 = _result_3;
      _v_12 = _result_4;
      _v_13 = _result_5;
      _v_14 = _result_6;
      _v_15 = 1;
      _v_16 = _result_1;
      _v_17 = _trace_0;
      _v_18 = _trace_1;
      _v_19 = 1;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_32(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u64 q8) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h6 = r6;
  Term h8 = r8;
  u32 _v_2 = 0;
  u32 _fields_0 = r0;
  u32 _fields_1 = r1;
  Term _fields_2 = r2;
  Term _fields_3 = r3;
  u32 _fields_4 = r4;
  Term _fields_5 = r5;
  Term _fields_6 = r6;
  u32 _fields_7 = r7;
  Term _fields_8 = r8;
  WL_SPIN
    term_sink(e, _fields_2);
    term_sink(e, _fields_3);
    term_sink(e, _fields_5);
    term_sink(e, _fields_6);
    term_sink(e, _fields_8);
    _v_2 = _fields_1;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_35(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_63 = 0;
  Term _value_10 = r0;
  WL_SPIN
    _v_63 = _value_10;
  break;
  }
  o[0] = _v_63;
  return 1;
}

INLINE Term spin_34(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_59 = 0;
  u32 _v_60 = 0;
  Term _declaration_0 = r0;
  u32 _declaration_1 = r1;
  Term _declaration_2 = r2;
  Term _declaration_3 = r3;
  WL_SPIN
    term_sink(e, _declaration_2);
    term_sink(e, _declaration_3);
    Term _v_61 = 0;
    Term _v_62 = 0;
    Term _o_2[1];
    if (spin_35(e, _o_2, _declaration_0, _declaration_0 == h0 ? q0 : blk_loc(e.mem, _declaration_0)) == 0) {
      return 0;
    }
    _v_62 = _o_2[0];
    _v_61 = _v_62;
    _v_59 = _v_61;
    _v_60 = _declaration_1;
  break;
  }
  o[0] = _v_59;
  o[1] = _v_60;
  return 1;
}

INLINE Term spin_36(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  u32 _v_78 = 0;
  u32 _v_79 = 0;
  Term _v_80 = 0;
  Term _v_81 = 0;
  Term _v_82 = 0;
  u32 _v_83 = 0;
  u32 _v_84 = 0;
  Term _v_85 = 0;
  Term _v_86 = 0;
  u32 _v_87 = 0;
  Term _v_88 = 0;
  Term _v_89 = 0;
  u32 _v_90 = 0;
  Term _v_91 = 0;
  u32 _instance_0 = r0;
  u32 _instance_1 = r1;
  Term _instance_2 = r2;
  Term _instance_3 = r3;
  Term _instance_4 = r4;
  Term _clause_0 = r5;
  u32 _clause_1 = r6;
  WL_SPIN
    _instance_2 = term_keep(e, _instance_2, 1);
    _instance_3 = term_keep(e, _instance_3, 1);
    _clause_0 = term_keep(e, _clause_0, 1);
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _clause_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _clause_1);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_QUERY_DECLARATION_CLAUSE, _nd_4));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    _v_78 = _instance_0;
    _v_79 = _instance_1;
    _v_80 = _instance_2;
    _v_81 = _instance_3;
    _v_82 = _instance_4;
    _v_83 = _instance_0;
    _v_84 = _instance_1;
    _v_85 = _instance_2;
    _v_86 = _instance_3;
    _v_87 = 0ull;
    _v_88 = _clause_0;
    _v_89 = term_ctr(CID_CON, _nd_5);
    _v_90 = 1;
    _v_91 = _clause_1;
  break;
  }
  o[0] = _v_78;
  o[1] = _v_79;
  o[2] = _v_80;
  o[3] = _v_81;
  o[4] = _v_82;
  o[5] = _v_83;
  o[6] = _v_84;
  o[7] = _v_85;
  o[8] = _v_86;
  o[9] = _v_87;
  o[10] = _v_88;
  o[11] = _v_89;
  o[12] = _v_90;
  o[13] = _v_91;
  return 1;
}

INLINE Term spin_33(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _v_40 = 0;
  Term _v_41 = 0;
  u32 _value_5 = r0;
  u32 _value_6 = r1;
  Term _value_7 = r2;
  Term _value_8 = r3;
  Term _value_9 = r4;
  WL_SPIN
    Term _v_42 = 0;
    u32 _v_43 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    Term _o_3[2];
    Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 8);
    Term _a_1 = term_clo(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C70, 0);
    Term _a_2 = term_clo(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C71, 0);
    if (spin_34(e, _o_3, _a_0, _a_0 == h4 ? q4 : _a_0 == h3 ? q3 : _a_0 == h2 ? q2 : blk_loc(e.mem, _a_0), 1, _a_1, _a_1 == h4 ? q4 : _a_1 == h3 ? q3 : _a_1 == h2 ? q2 : blk_loc(e.mem, _a_1), _a_2, _a_2 == h4 ? q4 : _a_2 == h3 ? q3 : _a_2 == h2 ? q2 : blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_57 = _o_3[0];
    _v_58 = _o_3[1];
    _v_42 = _v_57;
    _v_43 = _v_58;
    u32 _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    u32 _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    Term _v_72 = 0;
    u32 _v_73 = 0;
    Term _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    Term _o_4[14];
    if (spin_36(e, _o_4, _value_5, _value_6, _value_7, _value_7 == h2 ? q2 : blk_loc(e.mem, _value_7), _value_8, _value_8 == h3 ? q3 : blk_loc(e.mem, _value_8), _value_9, _value_9 == h4 ? q4 : blk_loc(e.mem, _value_9), _v_42, _v_42 == h4 ? q4 : _v_42 == h3 ? q3 : _v_42 == h2 ? q2 : blk_loc(e.mem, _v_42), _v_43) == 0) {
      return 0;
    }
    _v_64 = _o_4[0];
    _v_65 = _o_4[1];
    _v_66 = _o_4[2];
    _v_67 = _o_4[3];
    _v_68 = _o_4[4];
    _v_69 = _o_4[5];
    _v_70 = _o_4[6];
    _v_71 = _o_4[7];
    _v_72 = _o_4[8];
    _v_73 = _o_4[9];
    _v_74 = _o_4[10];
    _v_75 = _o_4[11];
    _v_76 = _o_4[12];
    _v_77 = _o_4[13];
    _v_28 = _v_64;
    _v_29 = _v_65;
    _v_30 = _v_66;
    _v_31 = _v_67;
    _v_32 = _v_68;
    _v_33 = _v_69;
    _v_34 = _v_70;
    _v_35 = _v_71;
    _v_36 = _v_72;
    _v_37 = _v_73;
    _v_38 = _v_74;
    _v_39 = _v_75;
    _v_40 = _v_76;
    _v_41 = _v_77;
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  o[10] = _v_38;
  o[11] = _v_39;
  o[12] = _v_40;
  o[13] = _v_41;
  return 1;
}

INLINE Term spin_37(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _outcome_0 = r0;
  Term _outcome_1 = r1;
  u32 _outcome_2 = r2;
  Term _outcome_3 = r3;
  u32 _outcome_4 = r4;
  WL_SPIN
    if (_outcome_0 == 0) {
      _v_12 = 0;
      _v_13 = _outcome_1;
      _v_14 = _outcome_2;
      _v_15 = _outcome_3;
      _v_16 = 0;
      _v_17 = 0;
    } else {
      _v_12 = 1;
      _v_13 = _outcome_1;
      _v_14 = _outcome_2;
      _v_15 = _outcome_3;
      _v_16 = 1;
      _v_17 = _outcome_4;
    }
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_38(Env e, THR Term* o, u32 r0, Term r1, u64 q1, u32 r2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h3 = r3;
  u32 _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  u32 _outcome_0 = r0;
  Term _outcome_1 = r1;
  u32 _outcome_2 = r2;
  Term _outcome_3 = r3;
  WL_SPIN
    if (_outcome_0 == 0) {
      _v_12 = 0;
      _v_13 = _outcome_1;
      _v_14 = _outcome_2;
      _v_15 = _outcome_3;
      _v_16 = 0;
      _v_17 = 0;
    } else {
      _v_12 = 1;
      _v_13 = _outcome_1;
      _v_14 = _outcome_2;
      _v_15 = _outcome_3;
      _v_16 = 0;
      _v_17 = 0;
    }
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_39(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, u32 r3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  u32 _v_8 = 0;
  Term _v_9 = 0;
  u32 _v_10 = 0;
  Term _v_11 = 0;
  Term _world_3 = r0;
  u32 _world_4 = r1;
  Term _world_5 = r2;
  u32 _id_1 = r3;
  WL_SPIN
    _v_8 = 1;
    _v_9 = _world_3;
    _v_10 = _world_4;
    _v_11 = _world_5;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  return 1;
}

INLINE Term spin_40(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, u32 r7, Term r8, u64 q8) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h8 = r8;
  u32 _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  Term _v_31 = 0;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  u32 _right_0 = r0;
  u32 _right_1 = r1;
  Term _right_2 = r2;
  Term _right_3 = r3;
  Term _right_4 = r4;
  u32 _result_0 = r5;
  Term _result_1 = r6;
  u32 _result_2 = r7;
  Term _result_3 = r8;
  WL_SPIN
    u32 _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    u32 _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    Term _o_1[6];
    if (spin_38(e, _o_1, _result_0, _result_1, _result_1 == h6 ? q6 : blk_loc(e.mem, _result_1), _result_2, _result_3, _result_3 == h8 ? q8 : blk_loc(e.mem, _result_3)) == 0) {
      return 0;
    }
    _v_40 = _o_1[0];
    _v_41 = _o_1[1];
    _v_42 = _o_1[2];
    _v_43 = _o_1[3];
    _v_44 = _o_1[4];
    _v_45 = _o_1[5];
    _v_34 = _v_40;
    _v_35 = _v_41;
    _v_36 = _v_42;
    _v_37 = _v_43;
    _v_38 = _v_44;
    _v_39 = _v_45;
    _v_23 = _right_0;
    _v_24 = _right_1;
    _v_25 = _right_2;
    _v_26 = _right_3;
    _v_27 = _right_4;
    _v_28 = _v_34;
    _v_29 = _v_35;
    _v_30 = _v_36;
    _v_31 = _v_37;
    _v_32 = _v_38;
    _v_33 = _v_39;
  break;
  }
  o[0] = _v_23;
  o[1] = _v_24;
  o[2] = _v_25;
  o[3] = _v_26;
  o[4] = _v_27;
  o[5] = _v_28;
  o[6] = _v_29;
  o[7] = _v_30;
  o[8] = _v_31;
  o[9] = _v_32;
  o[10] = _v_33;
  return 1;
}

INLINE Term spin_41(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h8 = r8;
  u32 _v_57 = 0;
  u32 _v_58 = 0;
  Term _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  u32 _v_64 = 0;
  Term _v_65 = 0;
  u32 _v_66 = 0;
  u32 _v_67 = 0;
  u32 _result_4 = r0;
  u32 _result_5 = r1;
  Term _result_6 = r2;
  Term _result_7 = r3;
  Term _result_8 = r4;
  u32 _result_9 = r5;
  Term _result_10 = r6;
  u32 _result_11 = r7;
  Term _result_12 = r8;
  u32 _result_13 = r9;
  WL_SPIN
    u32 _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    u32 _v_72 = 0;
    u32 _v_73 = 0;
    u32 _v_74 = 0;
    Term _v_75 = 0;
    u32 _v_76 = 0;
    Term _v_77 = 0;
    u32 _v_78 = 0;
    u32 _v_79 = 0;
    Term _o_3[6];
    if (spin_37(e, _o_3, _result_9, _result_10, _result_10 == h6 ? q6 : blk_loc(e.mem, _result_10), _result_11, _result_12, _result_12 == h8 ? q8 : blk_loc(e.mem, _result_12), _result_13) == 0) {
      return 0;
    }
    _v_74 = _o_3[0];
    _v_75 = _o_3[1];
    _v_76 = _o_3[2];
    _v_77 = _o_3[3];
    _v_78 = _o_3[4];
    _v_79 = _o_3[5];
    _v_68 = _v_74;
    _v_69 = _v_75;
    _v_70 = _v_76;
    _v_71 = _v_77;
    _v_72 = _v_78;
    _v_73 = _v_79;
    _v_57 = _result_4;
    _v_58 = _result_5;
    _v_59 = _result_6;
    _v_60 = _result_7;
    _v_61 = _result_8;
    _v_62 = _v_68;
    _v_63 = _v_69;
    _v_64 = _v_70;
    _v_65 = _v_71;
    _v_66 = _v_72;
    _v_67 = _v_73;
  break;
  }
  o[0] = _v_57;
  o[1] = _v_58;
  o[2] = _v_59;
  o[3] = _v_60;
  o[4] = _v_61;
  o[5] = _v_62;
  o[6] = _v_63;
  o[7] = _v_64;
  o[8] = _v_65;
  o[9] = _v_66;
  o[10] = _v_67;
  return 1;
}

INLINE Term spin_42(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term _v_4 = 0;
  Term _v_5 = 0;
  u32 _event_0 = r0;
  Term _event_1 = r1;
  Term _event_2 = r2;
  Term _event_3 = r3;
  Term _event_4 = r4;
  u32 _event_5 = r5;
  Term _event_6 = r6;
  Term _event_7 = r7;
  Term _event_8 = r8;
  u32 _event_9 = r9;
  Term _event_10 = r10;
  Term _event_11 = r11;
  Term _event_12 = r12;
  u32 _event_13 = r13;
  Term _event_14 = r14;
  Term _event_15 = r15;
  Term _event_16 = r16;
  u32 _event_17 = r17;
  u32 _event_18 = r18;
  Term _event_19 = r19;
  Term _journal_2 = r20;
  Term _journal_3 = r21;
  WL_SPIN
    Term _b_0 = 0;
    if (_event_0 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _event_2);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULESTARTED, _nd_0);
    } else if (_event_0 == 1) {
      u64 _nd_1 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_1 + 0] = rfc_seal(e, _event_1);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_PHASEENTERED, _nd_1);
    } else if (_event_0 == 2) {
      u32 _o_0 = 0;
      Term _o_1 = 0;
      if (_event_7 == 0) {
        _o_0 = 0;
      } else {
        _o_0 = 1;
        Term _b_1 = 0;
        if (_event_8 == 0) {
          u64 _nd_2 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_2 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_2);
        } else {
          Term _b_2 = 0;
          if (_event_9 == 0) {
            u64 _nd_3 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_3 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
            _b_2 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_3);
          } else {
            _b_2 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
          }
          u64 _nd_4 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_4 + 0] = rfc_seal(e, _b_2);
          _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_4);
        }
        _o_1 = _b_1;
      }
      u64 _nd_5 = heap_alloc(e, cls_fit(8));
      e.mem[_nd_5 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_5 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_5 + 2] = rfc_seal(e, _event_3);
      e.mem[_nd_5 + 3] = rfc_seal(e, _event_4);
      e.mem[_nd_5 + 4] = rfc_seal(e, _event_5);
      e.mem[_nd_5 + 5] = rfc_seal(e, _event_6);
      e.mem[_nd_5 + 6] = rfc_seal(e, _o_0);
      e.mem[_nd_5 + 7] = rfc_seal(e, _o_1);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMCOMPLETED, _nd_5);
    } else if (_event_0 == 3) {
      u64 _nd_6 = heap_alloc(e, cls_fit(19));
      e.mem[_nd_6 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_6 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_6 + 2] = rfc_seal(e, _event_3);
      e.mem[_nd_6 + 3] = rfc_seal(e, _event_4);
      e.mem[_nd_6 + 4] = rfc_seal(e, _event_5);
      e.mem[_nd_6 + 5] = rfc_seal(e, _event_6);
      e.mem[_nd_6 + 6] = rfc_seal(e, _event_7);
      e.mem[_nd_6 + 7] = rfc_seal(e, _event_8);
      e.mem[_nd_6 + 8] = rfc_seal(e, _event_9);
      e.mem[_nd_6 + 9] = rfc_seal(e, _event_10);
      e.mem[_nd_6 + 10] = rfc_seal(e, _event_11);
      e.mem[_nd_6 + 11] = rfc_seal(e, _event_12);
      e.mem[_nd_6 + 12] = rfc_seal(e, _event_13);
      e.mem[_nd_6 + 13] = rfc_seal(e, _event_14);
      e.mem[_nd_6 + 14] = rfc_seal(e, _event_15);
      e.mem[_nd_6 + 15] = rfc_seal(e, _event_16);
      e.mem[_nd_6 + 16] = rfc_seal(e, _event_17);
      e.mem[_nd_6 + 17] = rfc_seal(e, _event_18);
      e.mem[_nd_6 + 18] = rfc_seal(e, _event_19);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_OPERATIONOBSERVED, _nd_6);
    } else if (_event_0 == 4) {
      u64 _nd_7 = heap_alloc(e, cls_fit(15));
      e.mem[_nd_7 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_7 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_7 + 2] = rfc_seal(e, _event_3);
      e.mem[_nd_7 + 3] = rfc_seal(e, _event_4);
      e.mem[_nd_7 + 4] = rfc_seal(e, _event_5);
      e.mem[_nd_7 + 5] = rfc_seal(e, _event_6);
      e.mem[_nd_7 + 6] = rfc_seal(e, _event_7);
      e.mem[_nd_7 + 7] = rfc_seal(e, _event_8);
      e.mem[_nd_7 + 8] = rfc_seal(e, _event_9);
      e.mem[_nd_7 + 9] = rfc_seal(e, _event_10);
      e.mem[_nd_7 + 10] = rfc_seal(e, _event_11);
      e.mem[_nd_7 + 11] = rfc_seal(e, _event_12);
      e.mem[_nd_7 + 12] = rfc_seal(e, _event_13);
      e.mem[_nd_7 + 13] = rfc_seal(e, _event_14);
      e.mem[_nd_7 + 14] = rfc_seal(e, _event_15);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_BARRIEROPERATIONOBSERVED, _nd_7);
    } else if (_event_0 == 5) {
      u64 _nd_8 = heap_alloc(e, cls_fit(15));
      e.mem[_nd_8 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_8 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_8 + 2] = rfc_seal(e, _event_3);
      e.mem[_nd_8 + 3] = rfc_seal(e, _event_4);
      e.mem[_nd_8 + 4] = rfc_seal(e, _event_5);
      e.mem[_nd_8 + 5] = rfc_seal(e, _event_6);
      e.mem[_nd_8 + 6] = rfc_seal(e, _event_7);
      e.mem[_nd_8 + 7] = rfc_seal(e, _event_8);
      e.mem[_nd_8 + 8] = rfc_seal(e, _event_9);
      e.mem[_nd_8 + 9] = rfc_seal(e, _event_10);
      e.mem[_nd_8 + 10] = rfc_seal(e, _event_11);
      e.mem[_nd_8 + 11] = rfc_seal(e, _event_12);
      e.mem[_nd_8 + 12] = rfc_seal(e, _event_13);
      e.mem[_nd_8 + 13] = rfc_seal(e, _event_14);
      e.mem[_nd_8 + 14] = rfc_seal(e, _event_15);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_EXECUTIONOPERATIONOBSERVED, _nd_8);
    } else if (_event_0 == 6) {
      _b_0 = term_pak(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMSKIPPED, _event_1);
    } else if (_event_0 == 7) {
      _b_0 = term_pak(CID__________SRC_ECS_EXECUTION_TRACE_DEFERREDAPPLIED, 0);
    } else if (_event_0 == 8) {
      u32 _o_2 = 0;
      Term _o_3 = 0;
      if (_event_1 == 0) {
        _o_2 = 0;
      } else if (_event_1 == 1) {
        _o_2 = 1;
        Term _b_3 = 0;
        if (_event_2 == 0) {
          u64 _nd_9 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_9 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          _b_3 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_9);
        } else {
          Term _b_4 = 0;
          if (_event_3 == 0) {
            u64 _nd_10 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_10 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
            _b_4 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_10);
          } else {
            _b_4 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
          }
          u64 _nd_11 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_11 + 0] = rfc_seal(e, _b_4);
          _b_3 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_11);
        }
        _o_3 = _b_3;
      } else if (_event_1 == 2) {
        _o_2 = 2;
      } else {
        _o_2 = 3;
      }
      u64 _nd_12 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_12 + 0] = rfc_seal(e, _o_2);
      e.mem[_nd_12 + 1] = rfc_seal(e, _o_3);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEENDED, _nd_12);
    } else {
      u32 _o_4 = 0;
      Term _o_5 = 0;
      if (_event_3 == 0) {
        _o_4 = 0;
      } else if (_event_3 == 1) {
        _o_4 = 1;
        Term _b_5 = 0;
        if (_event_4 == 0) {
          u64 _nd_13 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          _b_5 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_13);
        } else {
          Term _b_6 = 0;
          if (_event_5 == 0) {
            u64 _nd_14 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_14 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
            _b_6 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_14);
          } else {
            _b_6 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
          }
          u64 _nd_15 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_15 + 0] = rfc_seal(e, _b_6);
          _b_5 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_15);
        }
        _o_5 = _b_5;
      } else if (_event_3 == 2) {
        _o_4 = 2;
      } else {
        _o_4 = 3;
      }
      u64 _nd_16 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_16 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_16 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_16 + 2] = rfc_seal(e, _o_4);
      e.mem[_nd_16 + 3] = rfc_seal(e, _o_5);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEADMISSIONREFUSED, _nd_16);
    }
    u64 _nd_17 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_17 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_17 + 1] = rfc_seal(e, _journal_3);
    _v_4 = _journal_2;
    _v_5 = term_ctr(CID_CON, _nd_17);
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_43(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _world_0 = r0;
  WL_SPIN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _world_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    Term _f_12 = _fb_0[12];
    u32 _f_13 = _fb_0[13];
    u32 _f_14 = _fb_0[14];
    u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(15));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _f_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _f_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, _f_6);
    e.mem[_nd_0 + 7] = rfc_seal(e, _f_7);
    e.mem[_nd_0 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 9] = rfc_seal(e, _f_9);
    e.mem[_nd_0 + 10] = rfc_seal(e, _f_10);
    e.mem[_nd_0 + 11] = rfc_seal(e, _f_11);
    e.mem[_nd_0 + 12] = rfc_seal(e, _f_12);
    e.mem[_nd_0 + 13] = rfc_seal(e, _f_13);
    e.mem[_nd_0 + 14] = rfc_seal(e, _f_14);
    _v_4 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
    _v_5 = _f_14;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_44(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, u32 r5) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h4 = r4;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  u32 _namespace_0 = r0;
  u32 _id_1 = r1;
  u32 _name_2 = r2;
  Term _name_3 = r3;
  Term _observed_2 = r4;
  u32 _observed_3 = r5;
  WL_SPIN
    _v_12 = _observed_2;
    _v_13 = _namespace_0;
    _v_14 = _id_1;
    _v_15 = _name_2;
    _v_16 = _name_3;
    _v_17 = _observed_3;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_47(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_8 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_8 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_47);
    }
  break;
  }
  o[0] = _v_8;
  return 1;
}

INLINE Term spin_46(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_6 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_7 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_47(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_7 = _o_0[0];
    _v_6 = _v_7;
  break;
  }
  o[0] = _v_6;
  return 1;
}

INLINE Term spin_45(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_4 = 0;
  u32 _state_0 = r0;
  Term _state_1 = r1;
  WL_SPIN
    if (_state_0 == 0) {
      _v_4 = term_pak(CID_NIL, 0);
    } else {
      Term _v_5 = 0;
      Term _o_1[1];
      if (spin_46(e, _o_1, _state_1, _state_1 == h1 ? q1 : blk_loc(e.mem, _state_1)) == 0) {
        return 0;
      }
      _v_5 = _o_1[0];
      _v_4 = _v_5;
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_48(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _facts_0 = r0;
  u32 _identity_0 = r1;
  u32 _identity_1 = r2;
  u32 _identity_2 = r3;
  Term _identity_3 = r4;
  Term _journal_2 = r5;
  Term _journal_3 = r6;
  WL_SPIN
    if (term_aux(_facts_0) == CID_NIL) {
      term_sink(e, _identity_3);
      _v_11 = _journal_2;
      _v_12 = _journal_3;
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _facts_0, 2, _fb_1);
      Term _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      u32 _o_3 = 0;
      Term _o_4 = 0;
      Term _o_5 = 0;
      Term _o_6 = 0;
      u32 _o_7 = 0;
      Term _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      u32 _o_11 = 0;
      Term _o_12 = 0;
      Term _o_13 = 0;
      Term _o_14 = 0;
      u32 _o_15 = 0;
      u32 _o_16 = 0;
      Term _o_17 = 0;
      if (term_aux(_f_2) == CID__________SRC_ECS_TRACE_FACTS_READERFACT) {
        _o_3 = 0;
        Term _fb_2[6];
        u64 _sp_2 = ctr_take(e, _f_2, 6, _fb_2);
        u32 _f_4 = _fb_2[0];
        u32 _f_5 = _fb_2[1];
        Term _f_6 = _fb_2[2];
        u32 _f_7 = _fb_2[3];
        Term _f_8 = _fb_2[4];
        u32 _f_9 = _fb_2[5];
        spare_free(e, cls_fit(6), _sp_2);
        _o_4 = _f_4;
        _o_5 = _f_5;
        _o_6 = _f_6;
        _o_7 = _f_7;
        _o_8 = _f_8;
        _o_9 = _f_9;
      } else if (term_aux(_f_2) == CID__________SRC_ECS_TRACE_FACTS_BOUNDARYFACT) {
        _o_3 = 1;
        Term _fb_3[2];
        u64 _sp_3 = ctr_take(e, _f_2, 2, _fb_3);
        u32 _f_10 = _fb_3[0];
        Term _f_11 = _fb_3[1];
        spare_free(e, cls_fit(2), _sp_3);
        _o_4 = _f_10;
        _o_5 = _f_11;
      } else if (term_aux(_f_2) == CID__________SRC_ECS_TRACE_FACTS_FACT) {
        _o_3 = 2;
        Term _fb_4[11];
        u64 _sp_4 = ctr_take(e, _f_2, 11, _fb_4);
        u32 _f_12 = _fb_4[0];
        Term _f_13 = _fb_4[1];
        u32 _f_14 = _fb_4[2];
        u32 _f_15 = _fb_4[3];
        Term _f_16 = _fb_4[4];
        u32 _f_17 = _fb_4[5];
        Term _f_18 = _fb_4[6];
        u32 _f_19 = _fb_4[7];
        Term _f_20 = _fb_4[8];
        u32 _f_21 = _fb_4[9];
        Term _f_22 = _fb_4[10];
        spare_free(e, cls_fit(11), _sp_4);
        _o_4 = _f_12;
        _o_5 = _f_13;
        _o_6 = _f_14;
        _o_7 = _f_15;
        _o_8 = _f_16;
        _o_9 = _f_17;
        _o_10 = _f_18;
        _o_11 = _f_19;
        _o_12 = _f_20;
        _o_13 = _f_21;
        _o_14 = _f_22;
      } else if (term_aux(_f_2) == CID__________SRC_ECS_TRACE_FACTS_RELATIONFACT) {
        _o_3 = 3;
        Term _fb_5[14];
        u64 _sp_5 = ctr_take(e, _f_2, 14, _fb_5);
        u32 _f_23 = _fb_5[0];
        Term _f_24 = _fb_5[1];
        Term _f_25 = _fb_5[2];
        u32 _f_26 = _fb_5[3];
        u32 _f_27 = _fb_5[4];
        u32 _f_28 = _fb_5[5];
        u32 _f_29 = _fb_5[6];
        u32 _f_30 = _fb_5[7];
        u32 _f_31 = _fb_5[8];
        Term _f_32 = _fb_5[9];
        u32 _f_33 = _fb_5[10];
        u32 _f_34 = _fb_5[11];
        u32 _f_35 = _fb_5[12];
        Term _f_36 = _fb_5[13];
        spare_free(e, cls_fit(14), _sp_5);
        _o_4 = _f_23;
        _o_5 = _f_24;
        _o_6 = _f_25;
        _o_7 = _f_26;
        _o_8 = _f_27;
        _o_9 = _f_28;
        _o_10 = _f_29;
        _o_11 = _f_30;
        _o_12 = _f_31;
        _o_13 = _f_32;
        _o_14 = _f_33;
        _o_15 = _f_34;
        _o_16 = _f_35;
        _o_17 = _f_36;
      } else if (term_aux(_f_2) == CID__________SRC_ECS_TRACE_FACTS_HANDLERFACT) {
        _o_3 = 4;
        Term _fb_6[11];
        u64 _sp_6 = ctr_take(e, _f_2, 11, _fb_6);
        u32 _f_37 = _fb_6[0];
        u32 _f_38 = _fb_6[1];
        Term _f_39 = _fb_6[2];
        u32 _f_40 = _fb_6[3];
        u32 _f_41 = _fb_6[4];
        u32 _f_42 = _fb_6[5];
        Term _f_43 = _fb_6[6];
        u32 _f_44 = _fb_6[7];
        Term _f_45 = _fb_6[8];
        u32 _f_46 = _fb_6[9];
        Term _f_47 = _fb_6[10];
        spare_free(e, cls_fit(11), _sp_6);
        _o_4 = _f_37;
        _o_5 = _f_38;
        _o_6 = _f_39;
        _o_7 = _f_40;
        _o_8 = _f_41;
        _o_9 = _f_42;
        _o_10 = _f_43;
        _o_11 = _f_44;
        _o_12 = _f_45;
        _o_13 = _f_46;
        _o_14 = _f_47;
      } else {
        _o_3 = 5;
        Term _fb_7[7];
        u64 _sp_7 = ctr_take(e, _f_2, 7, _fb_7);
        Term _f_48 = _fb_7[0];
        u32 _f_49 = _fb_7[1];
        Term _f_50 = _fb_7[2];
        u32 _f_51 = _fb_7[3];
        Term _f_52 = _fb_7[4];
        u32 _f_53 = _fb_7[5];
        Term _f_54 = _fb_7[6];
        spare_free(e, cls_fit(7), _sp_7);
        _o_4 = _f_48;
        _o_5 = _f_49;
        _o_6 = _f_50;
        _o_7 = _f_51;
        _o_8 = _f_52;
        _o_9 = _f_53;
        _o_10 = _f_54;
      }
      Term _v_13 = 0;
      Term _v_14 = 0;
      _identity_3 = term_keep(e, _identity_3, 1);
      Term _v_15 = 0;
      Term _v_16 = 0;
      Term _o_18[2];
      if (spin_42(e, _o_18, 3, _identity_0, blk_loc(e.mem, _identity_0), _identity_1, blk_loc(e.mem, _identity_1), _identity_2, blk_loc(e.mem, _identity_2), _identity_3, _identity_3 == h4 ? q4 : blk_loc(e.mem, _identity_3), _o_3, _o_4, _o_4 == h6 ? q6 : _o_4 == h5 ? q5 : _o_4 == h4 ? q4 : _o_4 == h0 ? q0 : blk_loc(e.mem, _o_4), _o_5, _o_5 == h6 ? q6 : _o_5 == h5 ? q5 : _o_5 == h4 ? q4 : _o_5 == h0 ? q0 : blk_loc(e.mem, _o_5), _o_6, _o_6 == h6 ? q6 : _o_6 == h5 ? q5 : _o_6 == h4 ? q4 : _o_6 == h0 ? q0 : blk_loc(e.mem, _o_6), _o_7, _o_8, _o_8 == h6 ? q6 : _o_8 == h5 ? q5 : _o_8 == h4 ? q4 : _o_8 == h0 ? q0 : blk_loc(e.mem, _o_8), _o_9, _o_9 == h6 ? q6 : _o_9 == h5 ? q5 : _o_9 == h4 ? q4 : _o_9 == h0 ? q0 : blk_loc(e.mem, _o_9), _o_10, _o_10 == h6 ? q6 : _o_10 == h5 ? q5 : _o_10 == h4 ? q4 : _o_10 == h0 ? q0 : blk_loc(e.mem, _o_10), _o_11, _o_12, _o_12 == h6 ? q6 : _o_12 == h5 ? q5 : _o_12 == h4 ? q4 : _o_12 == h0 ? q0 : blk_loc(e.mem, _o_12), _o_13, _o_13 == h6 ? q6 : _o_13 == h5 ? q5 : _o_13 == h4 ? q4 : _o_13 == h0 ? q0 : blk_loc(e.mem, _o_13), _o_14, _o_14 == h6 ? q6 : _o_14 == h5 ? q5 : _o_14 == h4 ? q4 : _o_14 == h0 ? q0 : blk_loc(e.mem, _o_14), _o_15, _o_16, _o_17, _o_17 == h6 ? q6 : _o_17 == h5 ? q5 : _o_17 == h4 ? q4 : _o_17 == h0 ? q0 : blk_loc(e.mem, _o_17), _journal_2, _journal_2 == h5 ? q5 : blk_loc(e.mem, _journal_2), _journal_3, _journal_3 == h6 ? q6 : blk_loc(e.mem, _journal_3)) == 0) {
        return 0;
      }
      _v_15 = _o_18[0];
      _v_16 = _o_18[1];
      _v_13 = _v_15;
      _v_14 = _v_16;
      spare_free(e, cls_fit(2), _sp_1);
      r0 = _f_3;
      r1 = _identity_0;
      r2 = _identity_1;
      r3 = _identity_2;
      r4 = _identity_3;
      r5 = _v_13;
      r6 = _v_14;
      _facts_0 = r0;
      _identity_0 = r1;
      _identity_1 = r2;
      _identity_2 = r3;
      _identity_3 = r4;
      _journal_2 = r5;
      _journal_3 = r6;
      WL_AGAIN(spin_48);
    }
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  return 1;
}

INLINE Term spin_49(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  u32 _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  u32 _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  u32 _owners_0 = r0;
  u32 _owners_1 = r1;
  Term _owners_2 = r2;
  Term _owners_3 = r3;
  Term _owners_4 = r4;
  u32 _fact_4 = r5;
  u32 _fact_5 = r6;
  u32 _fact_6 = r7;
  Term _fact_7 = r8;
  u32 _before_1 = r9;
  Term _journal_4 = r10;
  Term _journal_5 = r11;
  Term _observed_0 = r12;
  u32 _observed_1 = r13;
  WL_SPIN
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _o_21[2];
    Term _a_1 = 0;
    Term _a_2 = 0;
    Term _a_3 = 0;
    Term _a_4 = 0;
    Term _a_5 = 0;
    Term _a_6 = 0;
    Term _a_7 = 0;
    Term _a_8 = 0;
    Term _a_9 = 0;
    if (spin_42(e, _o_21, 2, _fact_4, blk_loc(e.mem, _fact_4), _fact_5, blk_loc(e.mem, _fact_5), _fact_6, blk_loc(e.mem, _fact_6), _fact_7, _fact_7 == h8 ? q8 : blk_loc(e.mem, _fact_7), _before_1, _observed_1, blk_loc(e.mem, _observed_1), _a_1, _a_1 == h12 ? q12 : _a_1 == h11 ? q11 : _a_1 == h10 ? q10 : _a_1 == h8 ? q8 : _a_1 == h4 ? q4 : _a_1 == h3 ? q3 : _a_1 == h2 ? q2 : blk_loc(e.mem, _a_1), _a_2, _a_2 == h12 ? q12 : _a_2 == h11 ? q11 : _a_2 == h10 ? q10 : _a_2 == h8 ? q8 : _a_2 == h4 ? q4 : _a_2 == h3 ? q3 : _a_2 == h2 ? q2 : blk_loc(e.mem, _a_2), 0, _a_3, _a_3 == h12 ? q12 : _a_3 == h11 ? q11 : _a_3 == h10 ? q10 : _a_3 == h8 ? q8 : _a_3 == h4 ? q4 : _a_3 == h3 ? q3 : _a_3 == h2 ? q2 : blk_loc(e.mem, _a_3), _a_4, _a_4 == h12 ? q12 : _a_4 == h11 ? q11 : _a_4 == h10 ? q10 : _a_4 == h8 ? q8 : _a_4 == h4 ? q4 : _a_4 == h3 ? q3 : _a_4 == h2 ? q2 : blk_loc(e.mem, _a_4), _a_5, _a_5 == h12 ? q12 : _a_5 == h11 ? q11 : _a_5 == h10 ? q10 : _a_5 == h8 ? q8 : _a_5 == h4 ? q4 : _a_5 == h3 ? q3 : _a_5 == h2 ? q2 : blk_loc(e.mem, _a_5), 0, _a_6, _a_6 == h12 ? q12 : _a_6 == h11 ? q11 : _a_6 == h10 ? q10 : _a_6 == h8 ? q8 : _a_6 == h4 ? q4 : _a_6 == h3 ? q3 : _a_6 == h2 ? q2 : blk_loc(e.mem, _a_6), _a_7, _a_7 == h12 ? q12 : _a_7 == h11 ? q11 : _a_7 == h10 ? q10 : _a_7 == h8 ? q8 : _a_7 == h4 ? q4 : _a_7 == h3 ? q3 : _a_7 == h2 ? q2 : blk_loc(e.mem, _a_7), _a_8, _a_8 == h12 ? q12 : _a_8 == h11 ? q11 : _a_8 == h10 ? q10 : _a_8 == h8 ? q8 : _a_8 == h4 ? q4 : _a_8 == h3 ? q3 : _a_8 == h2 ? q2 : blk_loc(e.mem, _a_8), 0, 0, _a_9, _a_9 == h12 ? q12 : _a_9 == h11 ? q11 : _a_9 == h10 ? q10 : _a_9 == h8 ? q8 : _a_9 == h4 ? q4 : _a_9 == h3 ? q3 : _a_9 == h2 ? q2 : blk_loc(e.mem, _a_9), _journal_4, _journal_4 == h10 ? q10 : blk_loc(e.mem, _journal_4), _journal_5, _journal_5 == h11 ? q11 : blk_loc(e.mem, _journal_5)) == 0) {
      return 0;
    }
    _v_45 = _o_21[0];
    _v_46 = _o_21[1];
    _v_43 = _v_45;
    _v_44 = _v_46;
    _v_32 = _owners_0;
    _v_33 = _owners_1;
    _v_34 = _owners_2;
    _v_35 = _owners_3;
    _v_36 = _owners_4;
    _v_37 = _v_43;
    _v_38 = _v_44;
    _v_39 = 0;
    _v_40 = _observed_0;
    _v_41 = 0;
    _v_42 = 0;
  break;
  }
  o[0] = _v_32;
  o[1] = _v_33;
  o[2] = _v_34;
  o[3] = _v_35;
  o[4] = _v_36;
  o[5] = _v_37;
  o[6] = _v_38;
  o[7] = _v_39;
  o[8] = _v_40;
  o[9] = _v_41;
  o[10] = _v_42;
  return 1;
}

INLINE Term spin_50(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, u32 r13, Term r14, u64 q14, u32 r15) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h14 = r14;
  u32 _v_68 = 0;
  u32 _v_69 = 0;
  Term _v_70 = 0;
  Term _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  Term _v_74 = 0;
  u32 _v_75 = 0;
  Term _v_76 = 0;
  u32 _v_77 = 0;
  u32 _v_78 = 0;
  u32 _owners_5 = r0;
  u32 _owners_6 = r1;
  Term _owners_7 = r2;
  Term _owners_8 = r3;
  Term _owners_9 = r4;
  u32 _fact_8 = r5;
  u32 _fact_9 = r6;
  u32 _fact_10 = r7;
  Term _fact_11 = r8;
  u32 _before_2 = r9;
  Term _journal_6 = r10;
  Term _journal_7 = r11;
  u32 _error_0 = r12;
  u32 _error_1 = r13;
  Term _observed_2 = r14;
  u32 _observed_3 = r15;
  WL_SPIN
    Term _v_79 = 0;
    Term _v_80 = 0;
    Term _v_81 = 0;
    Term _v_82 = 0;
    Term _o_26[2];
    Term _a_10 = 1;
    Term _a_11 = 0;
    Term _a_12 = 0;
    Term _a_13 = 0;
    Term _a_14 = 0;
    Term _a_15 = 0;
    Term _a_16 = 0;
    Term _a_17 = 0;
    if (spin_42(e, _o_26, 2, _fact_8, blk_loc(e.mem, _fact_8), _fact_9, blk_loc(e.mem, _fact_9), _fact_10, blk_loc(e.mem, _fact_10), _fact_11, _fact_11 == h8 ? q8 : blk_loc(e.mem, _fact_11), _before_2, _observed_3, blk_loc(e.mem, _observed_3), _a_10, _a_10 == h14 ? q14 : _a_10 == h11 ? q11 : _a_10 == h10 ? q10 : _a_10 == h8 ? q8 : _a_10 == h4 ? q4 : _a_10 == h3 ? q3 : _a_10 == h2 ? q2 : blk_loc(e.mem, _a_10), _error_0, blk_loc(e.mem, _error_0), _error_1, _a_11, _a_11 == h14 ? q14 : _a_11 == h11 ? q11 : _a_11 == h10 ? q10 : _a_11 == h8 ? q8 : _a_11 == h4 ? q4 : _a_11 == h3 ? q3 : _a_11 == h2 ? q2 : blk_loc(e.mem, _a_11), _a_12, _a_12 == h14 ? q14 : _a_12 == h11 ? q11 : _a_12 == h10 ? q10 : _a_12 == h8 ? q8 : _a_12 == h4 ? q4 : _a_12 == h3 ? q3 : _a_12 == h2 ? q2 : blk_loc(e.mem, _a_12), _a_13, _a_13 == h14 ? q14 : _a_13 == h11 ? q11 : _a_13 == h10 ? q10 : _a_13 == h8 ? q8 : _a_13 == h4 ? q4 : _a_13 == h3 ? q3 : _a_13 == h2 ? q2 : blk_loc(e.mem, _a_13), 0, _a_14, _a_14 == h14 ? q14 : _a_14 == h11 ? q11 : _a_14 == h10 ? q10 : _a_14 == h8 ? q8 : _a_14 == h4 ? q4 : _a_14 == h3 ? q3 : _a_14 == h2 ? q2 : blk_loc(e.mem, _a_14), _a_15, _a_15 == h14 ? q14 : _a_15 == h11 ? q11 : _a_15 == h10 ? q10 : _a_15 == h8 ? q8 : _a_15 == h4 ? q4 : _a_15 == h3 ? q3 : _a_15 == h2 ? q2 : blk_loc(e.mem, _a_15), _a_16, _a_16 == h14 ? q14 : _a_16 == h11 ? q11 : _a_16 == h10 ? q10 : _a_16 == h8 ? q8 : _a_16 == h4 ? q4 : _a_16 == h3 ? q3 : _a_16 == h2 ? q2 : blk_loc(e.mem, _a_16), 0, 0, _a_17, _a_17 == h14 ? q14 : _a_17 == h11 ? q11 : _a_17 == h10 ? q10 : _a_17 == h8 ? q8 : _a_17 == h4 ? q4 : _a_17 == h3 ? q3 : _a_17 == h2 ? q2 : blk_loc(e.mem, _a_17), _journal_6, _journal_6 == h10 ? q10 : blk_loc(e.mem, _journal_6), _journal_7, _journal_7 == h11 ? q11 : blk_loc(e.mem, _journal_7)) == 0) {
      return 0;
    }
    _v_81 = _o_26[0];
    _v_82 = _o_26[1];
    _v_79 = _v_81;
    _v_80 = _v_82;
    _v_68 = _owners_5;
    _v_69 = _owners_6;
    _v_70 = _owners_7;
    _v_71 = _owners_8;
    _v_72 = _owners_9;
    _v_73 = _v_79;
    _v_74 = _v_80;
    _v_75 = 1;
    _v_76 = _observed_2;
    _v_77 = _error_0;
    _v_78 = _error_1;
  break;
  }
  o[0] = _v_68;
  o[1] = _v_69;
  o[2] = _v_70;
  o[3] = _v_71;
  o[4] = _v_72;
  o[5] = _v_73;
  o[6] = _v_74;
  o[7] = _v_75;
  o[8] = _v_76;
  o[9] = _v_77;
  o[10] = _v_78;
  return 1;
}

INLINE Term spin_51(Env e, THR Term* o) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  WL_SPIN
    _v_2 = term_pak(CID_NIL, 0);
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_52(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _world_2 = r0;
  WL_SPIN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _world_2, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    Term _f_12 = _fb_0[12];
    u32 _f_13 = _fb_0[13];
    u32 _f_14 = _fb_0[14];
    u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(15));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _f_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _f_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, _f_6);
    e.mem[_nd_0 + 7] = rfc_seal(e, _f_7);
    e.mem[_nd_0 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 9] = rfc_seal(e, _f_9);
    e.mem[_nd_0 + 10] = rfc_seal(e, _f_10);
    e.mem[_nd_0 + 11] = rfc_seal(e, _f_11);
    e.mem[_nd_0 + 12] = rfc_seal(e, _f_12);
    e.mem[_nd_0 + 13] = rfc_seal(e, _f_13);
    e.mem[_nd_0 + 14] = rfc_seal(e, _f_14);
    _v_4 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
    _v_5 = _f_0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_53(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_12 = 0;
  u32 _v_13 = 0;
  u32 _v_14 = 0;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  u32 _id_2 = r0;
  u32 _name_0 = r1;
  Term _name_1 = r2;
  Term _observed_0 = r3;
  u32 _observed_1 = r4;
  WL_SPIN
    Term _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    Term _o_1[2];
    if (spin_43(e, _o_1, _observed_0, _observed_0 == h3 ? q3 : blk_loc(e.mem, _observed_0)) == 0) {
      return 0;
    }
    _v_20 = _o_1[0];
    _v_21 = _o_1[1];
    _v_18 = _v_20;
    _v_19 = _v_21;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_2[6];
    if (spin_44(e, _o_2, _observed_1, _id_2, _name_0, _name_1, _name_1 == h2 ? q2 : blk_loc(e.mem, _name_1), _v_18, _v_18 == h3 ? q3 : _v_18 == h2 ? q2 : blk_loc(e.mem, _v_18), _v_19) == 0) {
      return 0;
    }
    _v_22 = _o_2[0];
    _v_23 = _o_2[1];
    _v_24 = _o_2[2];
    _v_25 = _o_2[3];
    _v_26 = _o_2[4];
    _v_27 = _o_2[5];
    _v_12 = _v_22;
    _v_13 = _v_23;
    _v_14 = _v_24;
    _v_15 = _v_25;
    _v_16 = _v_26;
    _v_17 = _v_27;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_54(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u64 q13, u32 r14, Term r15, u64 q15, u32 r16, u32 r17) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term h5 = r5;
  Term h6 = r6;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h13 = r13;
  Term h15 = r15;
  u32 _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  Term _v_49 = 0;
  u32 _v_50 = 0;
  Term _v_51 = 0;
  u32 _v_52 = 0;
  u32 _v_53 = 0;
  u32 _fact_0 = r0;
  u32 _fact_1 = r1;
  u32 _fact_2 = r2;
  Term _fact_3 = r3;
  u32 _before_0 = r4;
  Term _journal_8 = r5;
  Term _journal_9 = r6;
  u32 _result_22 = r7;
  u32 _result_23 = r8;
  Term _result_24 = r9;
  Term _result_25 = r10;
  Term _result_26 = r11;
  u32 _result_27 = r12;
  Term _result_28 = r13;
  u32 _result_29 = r14;
  Term _result_30 = r15;
  u32 _result_31 = r16;
  u32 _result_32 = r17;
  WL_SPIN
    if (_result_27 == 0) {
      Term _v_54 = 0;
      Term _v_55 = 0;
      Term _v_56 = 0;
      Term _v_57 = 0;
      Term _o_13[1];
      if (spin_45(e, _o_13, _result_29, _result_30, _result_30 == h15 ? q15 : blk_loc(e.mem, _result_30)) == 0) {
        return 0;
      }
      _v_57 = _o_13[0];
      _v_56 = _v_57;
      _fact_3 = term_keep(e, _fact_3, 1);
      Term _v_58 = 0;
      Term _v_59 = 0;
      Term _o_14[2];
      if (spin_48(e, _o_14, _v_56, _v_56 == h15 ? q15 : _v_56 == h13 ? q13 : _v_56 == h11 ? q11 : _v_56 == h10 ? q10 : _v_56 == h9 ? q9 : _v_56 == h6 ? q6 : _v_56 == h5 ? q5 : _v_56 == h3 ? q3 : blk_loc(e.mem, _v_56), _fact_0, _fact_1, _fact_2, _fact_3, _fact_3 == h3 ? q3 : blk_loc(e.mem, _fact_3), _journal_8, _journal_8 == h5 ? q5 : blk_loc(e.mem, _journal_8), _journal_9, _journal_9 == h6 ? q6 : blk_loc(e.mem, _journal_9)) == 0) {
        return 0;
      }
      _v_58 = _o_14[0];
      _v_59 = _o_14[1];
      _v_54 = _v_58;
      _v_55 = _v_59;
      Term _v_60 = 0;
      u32 _v_61 = 0;
      Term _v_62 = 0;
      u32 _v_63 = 0;
      Term _o_15[2];
      if (spin_43(e, _o_15, _result_28, _result_28 == h13 ? q13 : blk_loc(e.mem, _result_28)) == 0) {
        return 0;
      }
      _v_62 = _o_15[0];
      _v_63 = _o_15[1];
      _v_60 = _v_62;
      _v_61 = _v_63;
      u32 _v_64 = 0;
      u32 _v_65 = 0;
      Term _v_66 = 0;
      Term _v_67 = 0;
      Term _v_68 = 0;
      Term _v_69 = 0;
      Term _v_70 = 0;
      u32 _v_71 = 0;
      Term _v_72 = 0;
      u32 _v_73 = 0;
      u32 _v_74 = 0;
      Term _o_16[11];
      if (spin_49(e, _o_16, _result_22, _result_23, _result_24, _result_24 == h9 ? q9 : blk_loc(e.mem, _result_24), _result_25, _result_25 == h10 ? q10 : blk_loc(e.mem, _result_25), _result_26, _result_26 == h11 ? q11 : blk_loc(e.mem, _result_26), _fact_0, _fact_1, _fact_2, _fact_3, _fact_3 == h3 ? q3 : blk_loc(e.mem, _fact_3), _before_0, _v_54, _v_54 == h15 ? q15 : _v_54 == h13 ? q13 : _v_54 == h11 ? q11 : _v_54 == h10 ? q10 : _v_54 == h9 ? q9 : _v_54 == h6 ? q6 : _v_54 == h5 ? q5 : _v_54 == h3 ? q3 : blk_loc(e.mem, _v_54), _v_55, _v_55 == h15 ? q15 : _v_55 == h13 ? q13 : _v_55 == h11 ? q11 : _v_55 == h10 ? q10 : _v_55 == h9 ? q9 : _v_55 == h6 ? q6 : _v_55 == h5 ? q5 : _v_55 == h3 ? q3 : blk_loc(e.mem, _v_55), _v_60, _v_60 == h15 ? q15 : _v_60 == h13 ? q13 : _v_60 == h11 ? q11 : _v_60 == h10 ? q10 : _v_60 == h9 ? q9 : _v_60 == h6 ? q6 : _v_60 == h5 ? q5 : _v_60 == h3 ? q3 : blk_loc(e.mem, _v_60), _v_61) == 0) {
        return 0;
      }
      _v_64 = _o_16[0];
      _v_65 = _o_16[1];
      _v_66 = _o_16[2];
      _v_67 = _o_16[3];
      _v_68 = _o_16[4];
      _v_69 = _o_16[5];
      _v_70 = _o_16[6];
      _v_71 = _o_16[7];
      _v_72 = _o_16[8];
      _v_73 = _o_16[9];
      _v_74 = _o_16[10];
      _v_43 = _v_64;
      _v_44 = _v_65;
      _v_45 = _v_66;
      _v_46 = _v_67;
      _v_47 = _v_68;
      _v_48 = _v_69;
      _v_49 = _v_70;
      _v_50 = _v_71;
      _v_51 = _v_72;
      _v_52 = _v_73;
      _v_53 = _v_74;
    } else {
      Term _v_75 = 0;
      Term _v_76 = 0;
      Term _v_77 = 0;
      Term _v_78 = 0;
      Term _o_17[1];
      if (spin_45(e, _o_17, _result_29, _result_30, _result_30 == h15 ? q15 : blk_loc(e.mem, _result_30)) == 0) {
        return 0;
      }
      _v_78 = _o_17[0];
      _v_77 = _v_78;
      _fact_3 = term_keep(e, _fact_3, 1);
      Term _v_79 = 0;
      Term _v_80 = 0;
      Term _o_18[2];
      if (spin_48(e, _o_18, _v_77, _v_77 == h15 ? q15 : _v_77 == h13 ? q13 : _v_77 == h11 ? q11 : _v_77 == h10 ? q10 : _v_77 == h9 ? q9 : _v_77 == h6 ? q6 : _v_77 == h5 ? q5 : _v_77 == h3 ? q3 : blk_loc(e.mem, _v_77), _fact_0, _fact_1, _fact_2, _fact_3, _fact_3 == h3 ? q3 : blk_loc(e.mem, _fact_3), _journal_8, _journal_8 == h5 ? q5 : blk_loc(e.mem, _journal_8), _journal_9, _journal_9 == h6 ? q6 : blk_loc(e.mem, _journal_9)) == 0) {
        return 0;
      }
      _v_79 = _o_18[0];
      _v_80 = _o_18[1];
      _v_75 = _v_79;
      _v_76 = _v_80;
      Term _v_81 = 0;
      u32 _v_82 = 0;
      Term _v_83 = 0;
      u32 _v_84 = 0;
      Term _o_19[2];
      if (spin_43(e, _o_19, _result_28, _result_28 == h13 ? q13 : blk_loc(e.mem, _result_28)) == 0) {
        return 0;
      }
      _v_83 = _o_19[0];
      _v_84 = _o_19[1];
      _v_81 = _v_83;
      _v_82 = _v_84;
      u32 _v_85 = 0;
      u32 _v_86 = 0;
      Term _v_87 = 0;
      Term _v_88 = 0;
      Term _v_89 = 0;
      Term _v_90 = 0;
      Term _v_91 = 0;
      u32 _v_92 = 0;
      Term _v_93 = 0;
      u32 _v_94 = 0;
      u32 _v_95 = 0;
      Term _o_20[11];
      if (spin_50(e, _o_20, _result_22, _result_23, _result_24, _result_24 == h9 ? q9 : blk_loc(e.mem, _result_24), _result_25, _result_25 == h10 ? q10 : blk_loc(e.mem, _result_25), _result_26, _result_26 == h11 ? q11 : blk_loc(e.mem, _result_26), _fact_0, _fact_1, _fact_2, _fact_3, _fact_3 == h3 ? q3 : blk_loc(e.mem, _fact_3), _before_0, _v_75, _v_75 == h15 ? q15 : _v_75 == h13 ? q13 : _v_75 == h11 ? q11 : _v_75 == h10 ? q10 : _v_75 == h9 ? q9 : _v_75 == h6 ? q6 : _v_75 == h5 ? q5 : _v_75 == h3 ? q3 : blk_loc(e.mem, _v_75), _v_76, _v_76 == h15 ? q15 : _v_76 == h13 ? q13 : _v_76 == h11 ? q11 : _v_76 == h10 ? q10 : _v_76 == h9 ? q9 : _v_76 == h6 ? q6 : _v_76 == h5 ? q5 : _v_76 == h3 ? q3 : blk_loc(e.mem, _v_76), _result_31, _result_32, _v_81, _v_81 == h15 ? q15 : _v_81 == h13 ? q13 : _v_81 == h11 ? q11 : _v_81 == h10 ? q10 : _v_81 == h9 ? q9 : _v_81 == h6 ? q6 : _v_81 == h5 ? q5 : _v_81 == h3 ? q3 : blk_loc(e.mem, _v_81), _v_82) == 0) {
        return 0;
      }
      _v_85 = _o_20[0];
      _v_86 = _o_20[1];
      _v_87 = _o_20[2];
      _v_88 = _o_20[3];
      _v_89 = _o_20[4];
      _v_90 = _o_20[5];
      _v_91 = _o_20[6];
      _v_92 = _o_20[7];
      _v_93 = _o_20[8];
      _v_94 = _o_20[9];
      _v_95 = _o_20[10];
      _v_43 = _v_85;
      _v_44 = _v_86;
      _v_45 = _v_87;
      _v_46 = _v_88;
      _v_47 = _v_89;
      _v_48 = _v_90;
      _v_49 = _v_91;
      _v_50 = _v_92;
      _v_51 = _v_93;
      _v_52 = _v_94;
      _v_53 = _v_95;
    }
  break;
  }
  o[0] = _v_43;
  o[1] = _v_44;
  o[2] = _v_45;
  o[3] = _v_46;
  o[4] = _v_47;
  o[5] = _v_48;
  o[6] = _v_49;
  o[7] = _v_50;
  o[8] = _v_51;
  o[9] = _v_52;
  o[10] = _v_53;
  return 1;
}

INLINE Term spin_56(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h8 = r8;
  u32 _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  Term _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  Term _v_47 = 0;
  u32 _v_48 = 0;
  u32 _v_49 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  Term _result_6 = r6;
  u32 _result_7 = r7;
  Term _result_8 = r8;
  u32 _result_9 = r9;
  u32 _result_10 = r10;
  WL_SPIN
    if (_result_5 == 0) {
      term_sink(e, _result_8);
      _v_41 = _result_0;
      _v_42 = _result_1;
      _v_43 = _result_2;
      _v_44 = _result_3;
      _v_45 = _result_4;
      _v_46 = 0;
      _v_47 = _result_6;
      _v_48 = 0;
      _v_49 = 0;
    } else {
      term_sink(e, _result_8);
      _v_41 = _result_0;
      _v_42 = _result_1;
      _v_43 = _result_2;
      _v_44 = _result_3;
      _v_45 = _result_4;
      _v_46 = 1;
      _v_47 = _result_6;
      _v_48 = _result_9;
      _v_49 = _result_10;
    }
  break;
  }
  o[0] = _v_41;
  o[1] = _v_42;
  o[2] = _v_43;
  o[3] = _v_44;
  o[4] = _v_45;
  o[5] = _v_46;
  o[6] = _v_47;
  o[7] = _v_48;
  o[8] = _v_49;
  return 1;
}

INLINE Term spin_57(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, u32 r7, u32 r8) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  Term _result_6 = r6;
  u32 _result_7 = r7;
  u32 _result_8 = r8;
  WL_SPIN
    _v_12 = _result_0;
    _v_13 = _result_1;
    _v_14 = _result_2;
    _v_15 = _result_3;
    _v_16 = _result_4;
    _v_17 = 0;
    _v_18 = 0;
    _v_19 = 0;
    _v_20 = _result_5;
    _v_21 = _result_6;
    _v_22 = _result_7;
    _v_23 = _result_8;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  o[6] = _v_18;
  o[7] = _v_19;
  o[8] = _v_20;
  o[9] = _v_21;
  o[10] = _v_22;
  o[11] = _v_23;
  return 1;
}

INLINE Term spin_58(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, u32 r10) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h8 = r8;
  u32 _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  u32 _v_46 = 0;
  u32 _v_47 = 0;
  u32 _result_9 = r0;
  u32 _result_10 = r1;
  Term _result_11 = r2;
  Term _result_12 = r3;
  Term _result_13 = r4;
  Term _result_14 = r5;
  Term _result_15 = r6;
  u32 _result_16 = r7;
  Term _result_17 = r8;
  u32 _result_18 = r9;
  u32 _result_19 = r10;
  WL_SPIN
    _v_36 = _result_9;
    _v_37 = _result_10;
    _v_38 = _result_11;
    _v_39 = _result_12;
    _v_40 = _result_13;
    _v_41 = 1;
    _v_42 = _result_14;
    _v_43 = _result_15;
    _v_44 = _result_16;
    _v_45 = _result_17;
    _v_46 = _result_18;
    _v_47 = _result_19;
  break;
  }
  o[0] = _v_36;
  o[1] = _v_37;
  o[2] = _v_38;
  o[3] = _v_39;
  o[4] = _v_40;
  o[5] = _v_41;
  o[6] = _v_42;
  o[7] = _v_43;
  o[8] = _v_44;
  o[9] = _v_45;
  o[10] = _v_46;
  o[11] = _v_47;
  return 1;
}

INLINE Term spin_59(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_6 = 0;
  Term _v_7 = 0;
  Term _facts_0 = r0;
  Term _journal_2 = r1;
  Term _journal_3 = r2;
  WL_SPIN
    if (term_aux(_facts_0) == CID_NIL) {
      _v_6 = _journal_2;
      _v_7 = _journal_3;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _facts_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      Term _o_4 = 0;
      u32 _o_5 = 0;
      Term _o_6 = 0;
      u32 _o_7 = 0;
      Term _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      Term _o_11 = 0;
      Term _o_12 = 0;
      u32 _o_13 = 0;
      u32 _o_14 = 0;
      Term _o_15 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_TRACE_FACTS_READERFACT) {
        _o_1 = 0;
        Term _fb_1[6];
        u64 _sp_1 = ctr_take(e, _f_0, 6, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        Term _f_4 = _fb_1[2];
        u32 _f_5 = _fb_1[3];
        Term _f_6 = _fb_1[4];
        u32 _f_7 = _fb_1[5];
        spare_free(e, cls_fit(6), _sp_1);
        _o_2 = _f_2;
        _o_3 = _f_3;
        _o_4 = _f_4;
        _o_5 = _f_5;
        _o_6 = _f_6;
        _o_7 = _f_7;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_TRACE_FACTS_BOUNDARYFACT) {
        _o_1 = 1;
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _f_0, 2, _fb_2);
        u32 _f_8 = _fb_2[0];
        Term _f_9 = _fb_2[1];
        spare_free(e, cls_fit(2), _sp_2);
        _o_2 = _f_8;
        _o_3 = _f_9;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_TRACE_FACTS_FACT) {
        _o_1 = 2;
        Term _fb_3[11];
        u64 _sp_3 = ctr_take(e, _f_0, 11, _fb_3);
        u32 _f_10 = _fb_3[0];
        Term _f_11 = _fb_3[1];
        u32 _f_12 = _fb_3[2];
        u32 _f_13 = _fb_3[3];
        Term _f_14 = _fb_3[4];
        u32 _f_15 = _fb_3[5];
        Term _f_16 = _fb_3[6];
        u32 _f_17 = _fb_3[7];
        Term _f_18 = _fb_3[8];
        u32 _f_19 = _fb_3[9];
        Term _f_20 = _fb_3[10];
        spare_free(e, cls_fit(11), _sp_3);
        _o_2 = _f_10;
        _o_3 = _f_11;
        _o_4 = _f_12;
        _o_5 = _f_13;
        _o_6 = _f_14;
        _o_7 = _f_15;
        _o_8 = _f_16;
        _o_9 = _f_17;
        _o_10 = _f_18;
        _o_11 = _f_19;
        _o_12 = _f_20;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_TRACE_FACTS_RELATIONFACT) {
        _o_1 = 3;
        Term _fb_4[14];
        u64 _sp_4 = ctr_take(e, _f_0, 14, _fb_4);
        u32 _f_21 = _fb_4[0];
        Term _f_22 = _fb_4[1];
        Term _f_23 = _fb_4[2];
        u32 _f_24 = _fb_4[3];
        u32 _f_25 = _fb_4[4];
        u32 _f_26 = _fb_4[5];
        u32 _f_27 = _fb_4[6];
        u32 _f_28 = _fb_4[7];
        u32 _f_29 = _fb_4[8];
        Term _f_30 = _fb_4[9];
        u32 _f_31 = _fb_4[10];
        u32 _f_32 = _fb_4[11];
        u32 _f_33 = _fb_4[12];
        Term _f_34 = _fb_4[13];
        spare_free(e, cls_fit(14), _sp_4);
        _o_2 = _f_21;
        _o_3 = _f_22;
        _o_4 = _f_23;
        _o_5 = _f_24;
        _o_6 = _f_25;
        _o_7 = _f_26;
        _o_8 = _f_27;
        _o_9 = _f_28;
        _o_10 = _f_29;
        _o_11 = _f_30;
        _o_12 = _f_31;
        _o_13 = _f_32;
        _o_14 = _f_33;
        _o_15 = _f_34;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_TRACE_FACTS_HANDLERFACT) {
        _o_1 = 4;
        Term _fb_5[11];
        u64 _sp_5 = ctr_take(e, _f_0, 11, _fb_5);
        u32 _f_35 = _fb_5[0];
        u32 _f_36 = _fb_5[1];
        Term _f_37 = _fb_5[2];
        u32 _f_38 = _fb_5[3];
        u32 _f_39 = _fb_5[4];
        u32 _f_40 = _fb_5[5];
        Term _f_41 = _fb_5[6];
        u32 _f_42 = _fb_5[7];
        Term _f_43 = _fb_5[8];
        u32 _f_44 = _fb_5[9];
        Term _f_45 = _fb_5[10];
        spare_free(e, cls_fit(11), _sp_5);
        _o_2 = _f_35;
        _o_3 = _f_36;
        _o_4 = _f_37;
        _o_5 = _f_38;
        _o_6 = _f_39;
        _o_7 = _f_40;
        _o_8 = _f_41;
        _o_9 = _f_42;
        _o_10 = _f_43;
        _o_11 = _f_44;
        _o_12 = _f_45;
      } else {
        _o_1 = 5;
        Term _fb_6[7];
        u64 _sp_6 = ctr_take(e, _f_0, 7, _fb_6);
        Term _f_46 = _fb_6[0];
        u32 _f_47 = _fb_6[1];
        Term _f_48 = _fb_6[2];
        u32 _f_49 = _fb_6[3];
        Term _f_50 = _fb_6[4];
        u32 _f_51 = _fb_6[5];
        Term _f_52 = _fb_6[6];
        spare_free(e, cls_fit(7), _sp_6);
        _o_2 = _f_46;
        _o_3 = _f_47;
        _o_4 = _f_48;
        _o_5 = _f_49;
        _o_6 = _f_50;
        _o_7 = _f_51;
        _o_8 = _f_52;
      }
      Term _v_8 = 0;
      Term _v_9 = 0;
      Term _v_10 = 0;
      Term _v_11 = 0;
      Term _o_16[2];
      Term _a_0 = 0;
      Term _a_1 = 0;
      if (spin_42(e, _o_16, 4, _o_1, _o_1 == h2 ? q2 : _o_1 == h1 ? q1 : _o_1 == h0 ? q0 : blk_loc(e.mem, _o_1), _o_2, _o_2 == h2 ? q2 : _o_2 == h1 ? q1 : _o_2 == h0 ? q0 : blk_loc(e.mem, _o_2), _o_3, _o_3 == h2 ? q2 : _o_3 == h1 ? q1 : _o_3 == h0 ? q0 : blk_loc(e.mem, _o_3), _o_4, _o_4 == h2 ? q2 : _o_4 == h1 ? q1 : _o_4 == h0 ? q0 : blk_loc(e.mem, _o_4), _o_5, _o_6, _o_6 == h2 ? q2 : _o_6 == h1 ? q1 : _o_6 == h0 ? q0 : blk_loc(e.mem, _o_6), _o_7, _o_7 == h2 ? q2 : _o_7 == h1 ? q1 : _o_7 == h0 ? q0 : blk_loc(e.mem, _o_7), _o_8, _o_8 == h2 ? q2 : _o_8 == h1 ? q1 : _o_8 == h0 ? q0 : blk_loc(e.mem, _o_8), _o_9, _o_10, _o_10 == h2 ? q2 : _o_10 == h1 ? q1 : _o_10 == h0 ? q0 : blk_loc(e.mem, _o_10), _o_11, _o_11 == h2 ? q2 : _o_11 == h1 ? q1 : _o_11 == h0 ? q0 : blk_loc(e.mem, _o_11), _o_12, _o_12 == h2 ? q2 : _o_12 == h1 ? q1 : _o_12 == h0 ? q0 : blk_loc(e.mem, _o_12), _o_13, _o_14, _o_14 == h2 ? q2 : _o_14 == h1 ? q1 : _o_14 == h0 ? q0 : blk_loc(e.mem, _o_14), _o_15, _o_15 == h2 ? q2 : _o_15 == h1 ? q1 : _o_15 == h0 ? q0 : blk_loc(e.mem, _o_15), _a_0, _a_0 == h2 ? q2 : _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), 0, 0, _a_1, _a_1 == h2 ? q2 : _a_1 == h1 ? q1 : _a_1 == h0 ? q0 : blk_loc(e.mem, _a_1), _journal_2, _journal_2 == h1 ? q1 : blk_loc(e.mem, _journal_2), _journal_3, _journal_3 == h2 ? q2 : blk_loc(e.mem, _journal_3)) == 0) {
        return 0;
      }
      _v_10 = _o_16[0];
      _v_11 = _o_16[1];
      _v_8 = _v_10;
      _v_9 = _v_11;
      spare_free(e, cls_fit(2), _sp_0);
      r0 = _f_1;
      r1 = _v_8;
      r2 = _v_9;
      _facts_0 = r0;
      _journal_2 = r1;
      _journal_3 = r2;
      WL_AGAIN(spin_59);
    }
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  return 1;
}

INLINE Term spin_60(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h9 = r9;
  u32 _v_8 = 0;
  u32 _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _owners_14 = r0;
  u32 _owners_15 = r1;
  Term _owners_16 = r2;
  Term _owners_17 = r3;
  Term _owners_18 = r4;
  Term _journal_0 = r5;
  Term _journal_1 = r6;
  Term _result_0 = r7;
  u32 _result_1 = r8;
  Term _result_2 = r9;
  WL_SPIN
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _o_0[1];
    if (spin_45(e, _o_0, _result_1, _result_2, _result_2 == h9 ? q9 : blk_loc(e.mem, _result_2)) == 0) {
      return 0;
    }
    _v_19 = _o_0[0];
    _v_18 = _v_19;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _o_1[2];
    if (spin_59(e, _o_1, _v_18, _v_18 == h9 ? q9 : _v_18 == h7 ? q7 : _v_18 == h6 ? q6 : _v_18 == h5 ? q5 : _v_18 == h4 ? q4 : _v_18 == h3 ? q3 : _v_18 == h2 ? q2 : blk_loc(e.mem, _v_18), _journal_0, _journal_0 == h5 ? q5 : blk_loc(e.mem, _journal_0), _journal_1, _journal_1 == h6 ? q6 : blk_loc(e.mem, _journal_1)) == 0) {
      return 0;
    }
    _v_20 = _o_1[0];
    _v_21 = _o_1[1];
    _v_16 = _v_20;
    _v_17 = _v_21;
    _v_8 = _owners_14;
    _v_9 = _owners_15;
    _v_10 = _owners_16;
    _v_11 = _owners_17;
    _v_12 = _owners_18;
    _v_13 = _v_16;
    _v_14 = _v_17;
    _v_15 = _result_0;
  break;
  }
  o[0] = _v_8;
  o[1] = _v_9;
  o[2] = _v_10;
  o[3] = _v_11;
  o[4] = _v_12;
  o[5] = _v_13;
  o[6] = _v_14;
  o[7] = _v_15;
  return 1;
}

INLINE Term spin_61(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term _v_1 = 0;
  Term _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  WL_SPIN
    term_sink(e, _result_2);
    _v_1 = _result_0;
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_62(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  WL_SPIN
    _v_9 = _result_0;
    _v_10 = _result_1;
    _v_11 = _result_2;
    _v_12 = _result_3;
    _v_13 = _result_4;
    _v_14 = 1;
    _v_15 = _result_5;
    _v_16 = _result_6;
    _v_17 = _result_7;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_63(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _world_2 = r0;
  u32 _id_0 = r1;
  WL_SPIN
    _v_4 = _world_2;
    _v_5 = 1;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_64(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _v_3 = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    _v_3 = U32_BIN(_a_1, ==, _b_1);
  break;
  }
  o[0] = _v_3;
  return 1;
}

INLINE Term spin_66(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_4 = 0;
  Term _a_1 = r0;
  Term _b_1 = r1;
  u32 _same_0 = r2;
  WL_SPIN
    if (term_aux(_a_1) == CID_SNIL) {
      if (term_aux(_b_1) == CID_SNIL) {
        _v_4 = _same_0;
      } else {
        u64 _sp_3 = term_peek(e.mem, _b_1);
        u32 _f_8 = e.mem[_sp_3 + 0];
        Term _f_9 = e.mem[_sp_3 + 1];
        _v_4 = 0;
      }
    } else {
      u64 _sp_4 = term_peek(e.mem, _a_1);
      u32 _f_10 = e.mem[_sp_4 + 0];
      Term _f_11 = e.mem[_sp_4 + 1];
      if (term_aux(_b_1) == CID_SNIL) {
        _v_4 = 0;
      } else {
        u64 _sp_5 = term_peek(e.mem, _b_1);
        u32 _f_12 = e.mem[_sp_5 + 0];
        Term _f_13 = e.mem[_sp_5 + 1];
        u32 _v_5 = 0;
        u32 _v_6 = 0;
        u32 _v_7 = 0;
        Term _o_0[1];
        if (spin_64(e, _o_0, _f_10, _f_12) == 0) {
          return 0;
        }
        _v_7 = _o_0[0];
        _v_6 = _v_7;
        u32 _v_8 = 0;
        Term _o_1[1];
        if (spin_30(e, _o_1, _same_0, _v_6) == 0) {
          return 0;
        }
        _v_8 = _o_1[0];
        _v_5 = _v_8;
        r0 = _f_11;
        r1 = _f_13;
        r2 = _v_5;
        _a_1 = r0;
        _b_1 = r1;
        _same_0 = r2;
        WL_AGAIN(spin_66);
      }
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_65(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  u32 _v_2 = 0;
  Term _a_0 = r0;
  Term _b_0 = r1;
  WL_SPIN
    u32 _v_3 = 0;
    Term _o_2[1];
    if (spin_66(e, _o_2, _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), _b_0, _b_0 == h1 ? q1 : blk_loc(e.mem, _b_0), 1) == 0) {
      return 0;
    }
    _v_3 = _o_2[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_67(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  Term _v_5 = 0;
  Term _world_0 = r0;
  WL_SPIN
    _v_4 = _world_0;
    _v_5 = term_pak(CID_NIL, 0);
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_68(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13, Term r14, u64 q14, Term r15, u64 q15, Term r16, u64 q16, u32 r17, u32 r18, Term r19, u64 q19, Term r20, u64 q20, Term r21, u64 q21) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h14 = r14;
  Term h15 = r15;
  Term h16 = r16;
  Term h19 = r19;
  Term h20 = r20;
  Term h21 = r21;
  Term _v_2 = 0;
  Term _v_3 = 0;
  u32 _event_0 = r0;
  Term _event_1 = r1;
  Term _event_2 = r2;
  Term _event_3 = r3;
  Term _event_4 = r4;
  u32 _event_5 = r5;
  Term _event_6 = r6;
  Term _event_7 = r7;
  Term _event_8 = r8;
  u32 _event_9 = r9;
  Term _event_10 = r10;
  Term _event_11 = r11;
  Term _event_12 = r12;
  u32 _event_13 = r13;
  Term _event_14 = r14;
  Term _event_15 = r15;
  Term _event_16 = r16;
  u32 _event_17 = r17;
  u32 _event_18 = r18;
  Term _event_19 = r19;
  Term _chunk_0 = r20;
  Term _chunk_1 = r21;
  WL_SPIN
    Term _b_0 = 0;
    if (_event_0 == 0) {
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_0 + 1] = rfc_seal(e, _event_2);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULESTARTED, _nd_0);
    } else if (_event_0 == 1) {
      u64 _nd_1 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_1 + 0] = rfc_seal(e, _event_1);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_PHASEENTERED, _nd_1);
    } else if (_event_0 == 2) {
      u32 _o_57 = 0;
      Term _o_58 = 0;
      if (_event_7 == 0) {
        _o_57 = 0;
      } else {
        _o_57 = 1;
        Term _b_1 = 0;
        if (_event_8 == 0) {
          u64 _nd_2 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_2 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_2);
        } else {
          Term _b_2 = 0;
          if (_event_9 == 0) {
            u64 _nd_3 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_3 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
            _b_2 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_3);
          } else {
            _b_2 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
          }
          u64 _nd_4 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_4 + 0] = rfc_seal(e, _b_2);
          _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_4);
        }
        _o_58 = _b_1;
      }
      u64 _nd_5 = heap_alloc(e, cls_fit(8));
      e.mem[_nd_5 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_5 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_5 + 2] = rfc_seal(e, _event_3);
      e.mem[_nd_5 + 3] = rfc_seal(e, _event_4);
      e.mem[_nd_5 + 4] = rfc_seal(e, _event_5);
      e.mem[_nd_5 + 5] = rfc_seal(e, _event_6);
      e.mem[_nd_5 + 6] = rfc_seal(e, _o_57);
      e.mem[_nd_5 + 7] = rfc_seal(e, _o_58);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMCOMPLETED, _nd_5);
    } else if (_event_0 == 3) {
      u64 _nd_6 = heap_alloc(e, cls_fit(19));
      e.mem[_nd_6 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_6 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_6 + 2] = rfc_seal(e, _event_3);
      e.mem[_nd_6 + 3] = rfc_seal(e, _event_4);
      e.mem[_nd_6 + 4] = rfc_seal(e, _event_5);
      e.mem[_nd_6 + 5] = rfc_seal(e, _event_6);
      e.mem[_nd_6 + 6] = rfc_seal(e, _event_7);
      e.mem[_nd_6 + 7] = rfc_seal(e, _event_8);
      e.mem[_nd_6 + 8] = rfc_seal(e, _event_9);
      e.mem[_nd_6 + 9] = rfc_seal(e, _event_10);
      e.mem[_nd_6 + 10] = rfc_seal(e, _event_11);
      e.mem[_nd_6 + 11] = rfc_seal(e, _event_12);
      e.mem[_nd_6 + 12] = rfc_seal(e, _event_13);
      e.mem[_nd_6 + 13] = rfc_seal(e, _event_14);
      e.mem[_nd_6 + 14] = rfc_seal(e, _event_15);
      e.mem[_nd_6 + 15] = rfc_seal(e, _event_16);
      e.mem[_nd_6 + 16] = rfc_seal(e, _event_17);
      e.mem[_nd_6 + 17] = rfc_seal(e, _event_18);
      e.mem[_nd_6 + 18] = rfc_seal(e, _event_19);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_OPERATIONOBSERVED, _nd_6);
    } else if (_event_0 == 4) {
      u64 _nd_7 = heap_alloc(e, cls_fit(15));
      e.mem[_nd_7 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_7 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_7 + 2] = rfc_seal(e, _event_3);
      e.mem[_nd_7 + 3] = rfc_seal(e, _event_4);
      e.mem[_nd_7 + 4] = rfc_seal(e, _event_5);
      e.mem[_nd_7 + 5] = rfc_seal(e, _event_6);
      e.mem[_nd_7 + 6] = rfc_seal(e, _event_7);
      e.mem[_nd_7 + 7] = rfc_seal(e, _event_8);
      e.mem[_nd_7 + 8] = rfc_seal(e, _event_9);
      e.mem[_nd_7 + 9] = rfc_seal(e, _event_10);
      e.mem[_nd_7 + 10] = rfc_seal(e, _event_11);
      e.mem[_nd_7 + 11] = rfc_seal(e, _event_12);
      e.mem[_nd_7 + 12] = rfc_seal(e, _event_13);
      e.mem[_nd_7 + 13] = rfc_seal(e, _event_14);
      e.mem[_nd_7 + 14] = rfc_seal(e, _event_15);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_BARRIEROPERATIONOBSERVED, _nd_7);
    } else if (_event_0 == 5) {
      u64 _nd_8 = heap_alloc(e, cls_fit(15));
      e.mem[_nd_8 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_8 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_8 + 2] = rfc_seal(e, _event_3);
      e.mem[_nd_8 + 3] = rfc_seal(e, _event_4);
      e.mem[_nd_8 + 4] = rfc_seal(e, _event_5);
      e.mem[_nd_8 + 5] = rfc_seal(e, _event_6);
      e.mem[_nd_8 + 6] = rfc_seal(e, _event_7);
      e.mem[_nd_8 + 7] = rfc_seal(e, _event_8);
      e.mem[_nd_8 + 8] = rfc_seal(e, _event_9);
      e.mem[_nd_8 + 9] = rfc_seal(e, _event_10);
      e.mem[_nd_8 + 10] = rfc_seal(e, _event_11);
      e.mem[_nd_8 + 11] = rfc_seal(e, _event_12);
      e.mem[_nd_8 + 12] = rfc_seal(e, _event_13);
      e.mem[_nd_8 + 13] = rfc_seal(e, _event_14);
      e.mem[_nd_8 + 14] = rfc_seal(e, _event_15);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_EXECUTIONOPERATIONOBSERVED, _nd_8);
    } else if (_event_0 == 6) {
      _b_0 = term_pak(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMSKIPPED, _event_1);
    } else if (_event_0 == 7) {
      _b_0 = term_pak(CID__________SRC_ECS_EXECUTION_TRACE_DEFERREDAPPLIED, 0);
    } else if (_event_0 == 8) {
      u32 _o_59 = 0;
      Term _o_60 = 0;
      if (_event_1 == 0) {
        _o_59 = 0;
      } else if (_event_1 == 1) {
        _o_59 = 1;
        Term _b_3 = 0;
        if (_event_2 == 0) {
          u64 _nd_9 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_9 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          _b_3 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_9);
        } else {
          Term _b_4 = 0;
          if (_event_3 == 0) {
            u64 _nd_10 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_10 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
            _b_4 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_10);
          } else {
            _b_4 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
          }
          u64 _nd_11 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_11 + 0] = rfc_seal(e, _b_4);
          _b_3 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_11);
        }
        _o_60 = _b_3;
      } else if (_event_1 == 2) {
        _o_59 = 2;
      } else {
        _o_59 = 3;
      }
      u64 _nd_12 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_12 + 0] = rfc_seal(e, _o_59);
      e.mem[_nd_12 + 1] = rfc_seal(e, _o_60);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEENDED, _nd_12);
    } else {
      u32 _o_61 = 0;
      Term _o_62 = 0;
      if (_event_3 == 0) {
        _o_61 = 0;
      } else if (_event_3 == 1) {
        _o_61 = 1;
        Term _b_5 = 0;
        if (_event_4 == 0) {
          u64 _nd_13 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          _b_5 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_13);
        } else {
          Term _b_6 = 0;
          if (_event_5 == 0) {
            u64 _nd_14 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_14 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
            _b_6 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_14);
          } else {
            _b_6 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
          }
          u64 _nd_15 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_15 + 0] = rfc_seal(e, _b_6);
          _b_5 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_15);
        }
        _o_62 = _b_5;
      } else if (_event_3 == 2) {
        _o_61 = 2;
      } else {
        _o_61 = 3;
      }
      u64 _nd_16 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_16 + 0] = rfc_seal(e, _event_1);
      e.mem[_nd_16 + 1] = rfc_seal(e, _event_2);
      e.mem[_nd_16 + 2] = rfc_seal(e, _o_61);
      e.mem[_nd_16 + 3] = rfc_seal(e, _o_62);
      _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEADMISSIONREFUSED, _nd_16);
    }
    u64 _nd_17 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_17 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_17 + 1] = rfc_seal(e, _chunk_0);
    _v_2 = term_ctr(CID_CON, _nd_17);
    _v_3 = _chunk_1;
  break;
  }
  o[0] = _v_2;
  o[1] = _v_3;
  return 1;
}

INLINE Term spin_69(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  Term _v_5 = 0;
  Term _world_1 = r0;
  WL_SPIN
    _v_4 = _world_1;
    _v_5 = term_pak(CID_NIL, 0);
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_71(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, u32 r3) {
  u32 wpoll = 0;
  u32 _v_2 = 0;
  u32 _a_0 = r0;
  u32 _a_1 = r1;
  u32 _b_0 = r2;
  u32 _b_1 = r3;
  WL_SPIN
    if (_a_0 == 0) {
      if (_b_0 == 0) {
        _v_2 = U32_BIN(_a_1, ==, _b_1);
      } else {
        _v_2 = 0;
      }
    } else if (_a_0 == 1) {
      if (_b_0 == 1) {
        _v_2 = U32_BIN(_a_1, ==, _b_1);
      } else {
        _v_2 = 0;
      }
    } else {
      if (_b_0 == 2) {
        _v_2 = U32_BIN(_a_1, ==, _b_1);
      } else {
        _v_2 = 0;
      }
    }
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_72(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_1 = 0;
  u32 _present_0 = r0;
  u32 _item_0 = r1;
  u32 _item_1 = r2;
  Term _next_0 = r3;
  WL_SPIN
    if (_present_0 == 0) {
      Term _b_0 = 0;
      if (_item_0 == 0) {
        _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT, _item_1);
      } else if (_item_0 == 1) {
        _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE, _item_1);
      } else {
        _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_SERVICE, _item_1);
      }
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _next_0);
      _v_1 = term_ctr(CID_CON, _nd_0);
    } else {
      _v_1 = _next_0;
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_74(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term _v_4 = 0;
  Term _xs_1 = r0;
  Term _acc_0 = r1;
  WL_SPIN
    if (term_aux(_xs_1) == CID_NIL) {
      _v_4 = _acc_0;
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
      e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
      r0 = _f_1;
      r1 = term_ctr(CID_CON, _nd_0);
      _xs_1 = r0;
      _acc_0 = r1;
      WL_AGAIN(spin_74);
    }
  break;
  }
  o[0] = _v_4;
  return 1;
}

INLINE Term spin_73(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_2 = 0;
  Term _xs_0 = r0;
  WL_SPIN
    Term _v_3 = 0;
    Term _o_0[1];
    Term _a_0 = term_pak(CID_NIL, 0);
    if (spin_74(e, _o_0, _xs_0, _xs_0 == h0 ? q0 : blk_loc(e.mem, _xs_0), _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_75(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h13 = r13;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  u32 _result_9 = r9;
  Term _result_10 = r10;
  Term _result_11 = r11;
  u32 _result_12 = r12;
  Term _result_13 = r13;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_0 + 0] = rfc_seal(e, _result_5);
    e.mem[_nd_0 + 1] = rfc_seal(e, _result_6);
    e.mem[_nd_0 + 2] = rfc_seal(e, _result_7);
    e.mem[_nd_0 + 3] = rfc_seal(e, _result_8);
    e.mem[_nd_0 + 4] = rfc_seal(e, _result_9);
    e.mem[_nd_0 + 5] = rfc_seal(e, _result_10);
    e.mem[_nd_0 + 6] = rfc_seal(e, _result_11);
    e.mem[_nd_0 + 7] = rfc_seal(e, _result_12);
    e.mem[_nd_0 + 8] = rfc_seal(e, _result_13);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_REGISTRATION_FIELDS_FIELDS, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    _v_34 = _result_0;
    _v_35 = _result_1;
    _v_36 = _result_2;
    _v_37 = _result_3;
    _v_38 = _result_4;
    _v_39 = term_ctr(CID_CON, _nd_1);
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  return 1;
}

INLINE Term spin_76(Env e, THR Term* o, u32 r0, u32 r1, u32 r2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h3 = r3;
  Term _v_1 = 0;
  u32 _present_0 = r0;
  u32 _item_0 = r1;
  u32 _item_1 = r2;
  Term _rest_0 = r3;
  WL_SPIN
    if (_present_0 == 1) {
      _v_1 = _rest_0;
    } else {
      Term _b_1 = 0;
      if (_item_0 == 0) {
        _b_1 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT, _item_1);
      } else if (_item_0 == 1) {
        _b_1 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE, _item_1);
      } else {
        _b_1 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_SERVICE, _item_1);
      }
      u64 _nd_1 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _b_1);
      e.mem[_nd_1 + 1] = rfc_seal(e, _rest_0);
      _v_1 = term_ctr(CID_CON, _nd_1);
    }
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_78(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_26 = 0;
  Term _v_27 = 0;
  u32 _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _schema_1 = r0;
  Term _world_0 = r1;
  u32 _owners_0 = r2;
  u32 _owners_1 = r3;
  Term _owners_2 = r4;
  Term _owners_3 = r5;
  Term _owners_4 = r6;
  u32 _debug_0 = r7;
  Term _plan_1 = r8;
  u32 _namespace_0 = r9;
  Term _name_0 = r10;
  Term _steps_0 = r11;
  Term _needs_1 = r12;
  WL_SPIN
    _v_26 = _schema_1;
    _v_27 = _world_0;
    _v_28 = _owners_0;
    _v_29 = _owners_1;
    _v_30 = _owners_2;
    _v_31 = _owners_3;
    _v_32 = _owners_4;
    _v_33 = _debug_0;
    _v_34 = _plan_1;
    _v_35 = _namespace_0;
    _v_36 = _name_0;
    _v_37 = _steps_0;
    _v_38 = _needs_1;
  break;
  }
  o[0] = _v_26;
  o[1] = _v_27;
  o[2] = _v_28;
  o[3] = _v_29;
  o[4] = _v_30;
  o[5] = _v_31;
  o[6] = _v_32;
  o[7] = _v_33;
  o[8] = _v_34;
  o[9] = _v_35;
  o[10] = _v_36;
  o[11] = _v_37;
  o[12] = _v_38;
  return 1;
}

INLINE Term spin_79(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, u32 r5, u32 r6, Term r7, u64 q7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, u32 r12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h7 = r7;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h13 = r13;
  u32 _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  Term _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  u32 _result_5 = r5;
  u32 _result_6 = r6;
  Term _result_7 = r7;
  Term _result_8 = r8;
  u32 _result_9 = r9;
  Term _result_10 = r10;
  Term _result_11 = r11;
  u32 _result_12 = r12;
  Term _result_13 = r13;
  WL_SPIN
    term_sink(e, _result_7);
    term_sink(e, _result_8);
    term_sink(e, _result_10);
    term_sink(e, _result_11);
    term_sink(e, _result_13);
    u64 _nd_0 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_0 + 0] = rfc_seal(e, 0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _result_6);
    e.mem[_nd_0 + 2] = rfc_seal(e, 0ull);
    e.mem[_nd_0 + 3] = rfc_seal(e, term_pak(CID_NIL, 0));
    _v_34 = _result_0;
    _v_35 = _result_1;
    _v_36 = _result_2;
    _v_37 = _result_3;
    _v_38 = _result_4;
    _v_39 = term_ctr(CID__________SRC_ECS_SCHEDULE_PROVISION_ENTRY, _nd_0);
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  return 1;
}

INLINE Term spin_80(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  u32 _value_5 = r0;
  u32 _value_6 = r1;
  Term _value_7 = r2;
  Term _value_8 = r3;
  Term _value_9 = r4;
  WL_SPIN
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    Term _o_0[14];
    if (spin_33(e, _o_0, _value_5, _value_6, _value_7, _value_7 == h2 ? q2 : blk_loc(e.mem, _value_7), _value_8, _value_8 == h3 ? q3 : blk_loc(e.mem, _value_8), _value_9, _value_9 == h4 ? q4 : blk_loc(e.mem, _value_9)) == 0) {
      return 0;
    }
    _v_32 = _o_0[0];
    _v_33 = _o_0[1];
    _v_34 = _o_0[2];
    _v_35 = _o_0[3];
    _v_36 = _o_0[4];
    _v_37 = _o_0[5];
    _v_38 = _o_0[6];
    _v_39 = _o_0[7];
    _v_40 = _o_0[8];
    _v_41 = _o_0[9];
    _v_42 = _o_0[10];
    _v_43 = _o_0[11];
    _v_44 = _o_0[12];
    _v_45 = _o_0[13];
    _v_18 = _v_32;
    _v_19 = _v_33;
    _v_20 = _v_34;
    _v_21 = _v_35;
    _v_22 = _v_36;
    _v_23 = _v_37;
    _v_24 = _v_38;
    _v_25 = _v_39;
    _v_26 = _v_40;
    _v_27 = _v_41;
    _v_28 = _v_42;
    _v_29 = _v_43;
    _v_30 = _v_44;
    _v_31 = _v_45;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _o_1[6];
    if (spin_75(e, _o_1, _v_18, _v_19, _v_20, _v_20 == h4 ? q4 : _v_20 == h3 ? q3 : _v_20 == h2 ? q2 : blk_loc(e.mem, _v_20), _v_21, _v_21 == h4 ? q4 : _v_21 == h3 ? q3 : _v_21 == h2 ? q2 : blk_loc(e.mem, _v_21), _v_22, _v_22 == h4 ? q4 : _v_22 == h3 ? q3 : _v_22 == h2 ? q2 : blk_loc(e.mem, _v_22), _v_23, _v_24, _v_25, _v_25 == h4 ? q4 : _v_25 == h3 ? q3 : _v_25 == h2 ? q2 : blk_loc(e.mem, _v_25), _v_26, _v_26 == h4 ? q4 : _v_26 == h3 ? q3 : _v_26 == h2 ? q2 : blk_loc(e.mem, _v_26), _v_27, _v_28, _v_28 == h4 ? q4 : _v_28 == h3 ? q3 : _v_28 == h2 ? q2 : blk_loc(e.mem, _v_28), _v_29, _v_29 == h4 ? q4 : _v_29 == h3 ? q3 : _v_29 == h2 ? q2 : blk_loc(e.mem, _v_29), _v_30, _v_31, _v_31 == h4 ? q4 : _v_31 == h3 ? q3 : _v_31 == h2 ? q2 : blk_loc(e.mem, _v_31)) == 0) {
      return 0;
    }
    _v_46 = _o_1[0];
    _v_47 = _o_1[1];
    _v_48 = _o_1[2];
    _v_49 = _o_1[3];
    _v_50 = _o_1[4];
    _v_51 = _o_1[5];
    _v_12 = _v_46;
    _v_13 = _v_47;
    _v_14 = _v_48;
    _v_15 = _v_49;
    _v_16 = _v_50;
    _v_17 = _v_51;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_81(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  u32 _result_0 = r0;
  u32 _result_1 = r1;
  Term _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  Term _result_5 = r5;
  WL_SPIN
    _v_58 = _result_0;
    _v_59 = _result_1;
    _v_60 = _result_2;
    _v_61 = _result_3;
    _v_62 = _result_4;
    _v_63 = _result_5;
  break;
  }
  o[0] = _v_58;
  o[1] = _v_59;
  o[2] = _v_60;
  o[3] = _v_61;
  o[4] = _v_62;
  o[5] = _v_63;
  return 1;
}

INLINE Term spin_82(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  u32 _allowed_0 = r0;
  u32 _namespace_2 = r1;
  Term _name_2 = r2;
  Term _steps_2 = r3;
  u32 _owners_10 = r4;
  u32 _owners_11 = r5;
  Term _owners_12 = r6;
  Term _owners_13 = r7;
  Term _owners_14 = r8;
  WL_SPIN
    if (_allowed_0 == 0) {
      term_sink(e, _name_2);
      term_sink(e, _steps_2);
      _v_9 = 1;
      _v_10 = _owners_10;
      _v_11 = _owners_11;
      _v_12 = _owners_12;
      _v_13 = _owners_13;
      _v_14 = _owners_14;
      _v_15 = 0;
      _v_16 = 0;
      _v_17 = 0;
    } else {
      _v_9 = 0;
      _v_10 = _namespace_2;
      _v_11 = _name_2;
      _v_12 = _steps_2;
      _v_13 = _owners_10;
      _v_14 = _owners_11;
      _v_15 = _owners_12;
      _v_16 = _owners_13;
      _v_17 = _owners_14;
    }
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  o[6] = _v_15;
  o[7] = _v_16;
  o[8] = _v_17;
  return 1;
}

INLINE Term spin_83(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  u32 _v_12 = 0;
  u32 _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  u32 _value_0 = r0;
  u32 _value_1 = r1;
  Term _value_2 = r2;
  Term _value_3 = r3;
  Term _value_4 = r4;
  WL_SPIN
    u32 _v_18 = 0;
    u32 _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _v_45 = 0;
    Term _o_0[14];
    if (spin_33(e, _o_0, _value_0, _value_1, _value_2, _value_2 == h2 ? q2 : blk_loc(e.mem, _value_2), _value_3, _value_3 == h3 ? q3 : blk_loc(e.mem, _value_3), _value_4, _value_4 == h4 ? q4 : blk_loc(e.mem, _value_4)) == 0) {
      return 0;
    }
    _v_32 = _o_0[0];
    _v_33 = _o_0[1];
    _v_34 = _o_0[2];
    _v_35 = _o_0[3];
    _v_36 = _o_0[4];
    _v_37 = _o_0[5];
    _v_38 = _o_0[6];
    _v_39 = _o_0[7];
    _v_40 = _o_0[8];
    _v_41 = _o_0[9];
    _v_42 = _o_0[10];
    _v_43 = _o_0[11];
    _v_44 = _o_0[12];
    _v_45 = _o_0[13];
    _v_18 = _v_32;
    _v_19 = _v_33;
    _v_20 = _v_34;
    _v_21 = _v_35;
    _v_22 = _v_36;
    _v_23 = _v_37;
    _v_24 = _v_38;
    _v_25 = _v_39;
    _v_26 = _v_40;
    _v_27 = _v_41;
    _v_28 = _v_42;
    _v_29 = _v_43;
    _v_30 = _v_44;
    _v_31 = _v_45;
    u32 _v_46 = 0;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _o_1[6];
    if (spin_79(e, _o_1, _v_18, _v_19, _v_20, _v_20 == h4 ? q4 : _v_20 == h3 ? q3 : _v_20 == h2 ? q2 : blk_loc(e.mem, _v_20), _v_21, _v_21 == h4 ? q4 : _v_21 == h3 ? q3 : _v_21 == h2 ? q2 : blk_loc(e.mem, _v_21), _v_22, _v_22 == h4 ? q4 : _v_22 == h3 ? q3 : _v_22 == h2 ? q2 : blk_loc(e.mem, _v_22), _v_23, _v_24, _v_25, _v_25 == h4 ? q4 : _v_25 == h3 ? q3 : _v_25 == h2 ? q2 : blk_loc(e.mem, _v_25), _v_26, _v_26 == h4 ? q4 : _v_26 == h3 ? q3 : _v_26 == h2 ? q2 : blk_loc(e.mem, _v_26), _v_27, _v_28, _v_28 == h4 ? q4 : _v_28 == h3 ? q3 : _v_28 == h2 ? q2 : blk_loc(e.mem, _v_28), _v_29, _v_29 == h4 ? q4 : _v_29 == h3 ? q3 : _v_29 == h2 ? q2 : blk_loc(e.mem, _v_29), _v_30, _v_31, _v_31 == h4 ? q4 : _v_31 == h3 ? q3 : _v_31 == h2 ? q2 : blk_loc(e.mem, _v_31)) == 0) {
      return 0;
    }
    _v_46 = _o_1[0];
    _v_47 = _o_1[1];
    _v_48 = _o_1[2];
    _v_49 = _o_1[3];
    _v_50 = _o_1[4];
    _v_51 = _o_1[5];
    _v_12 = _v_46;
    _v_13 = _v_47;
    _v_14 = _v_48;
    _v_15 = _v_49;
    _v_16 = _v_50;
    _v_17 = _v_51;
  break;
  }
  o[0] = _v_12;
  o[1] = _v_13;
  o[2] = _v_14;
  o[3] = _v_15;
  o[4] = _v_16;
  o[5] = _v_17;
  return 1;
}

INLINE Term spin_84(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  u32 _v_58 = 0;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  Term _v_62 = 0;
  Term _v_63 = 0;
  Term _before_0 = r0;
  u32 _result_1 = r1;
  u32 _result_2 = r2;
  Term _result_3 = r3;
  Term _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _before_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _result_6);
    _v_58 = _result_1;
    _v_59 = _result_2;
    _v_60 = _result_3;
    _v_61 = _result_4;
    _v_62 = _result_5;
    _v_63 = term_ctr(CID__________SRC_ECS_SCHEDULE_PROVISION_SEQUENCE, _nd_0);
  break;
  }
  o[0] = _v_58;
  o[1] = _v_59;
  o[2] = _v_60;
  o[3] = _v_61;
  o[4] = _v_62;
  o[5] = _v_63;
  return 1;
}

INLINE Term spin_85(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  u32 _value_0 = r0;
  u32 _value_1 = r1;
  Term _value_2 = r2;
  Term _value_3 = r3;
  Term _value_4 = r4;
  WL_SPIN
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _o_1[6];
    if (spin_80(e, _o_1, _value_0, _value_1, _value_2, _value_2 == h2 ? q2 : blk_loc(e.mem, _value_2), _value_3, _value_3 == h3 ? q3 : blk_loc(e.mem, _value_3), _value_4, _value_4 == h4 ? q4 : blk_loc(e.mem, _value_4)) == 0) {
      return 0;
    }
    _v_19 = _o_1[0];
    _v_20 = _o_1[1];
    _v_21 = _o_1[2];
    _v_22 = _o_1[3];
    _v_23 = _o_1[4];
    _v_24 = _o_1[5];
    _v_13 = _v_19;
    _v_14 = _v_20;
    _v_15 = _v_21;
    _v_16 = _v_22;
    _v_17 = _v_23;
    _v_18 = _v_24;
    u32 _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _o_2[6];
    if (spin_81(e, _o_2, _v_13, _v_14, _v_15, _v_15 == h4 ? q4 : _v_15 == h3 ? q3 : _v_15 == h2 ? q2 : blk_loc(e.mem, _v_15), _v_16, _v_16 == h4 ? q4 : _v_16 == h3 ? q3 : _v_16 == h2 ? q2 : blk_loc(e.mem, _v_16), _v_17, _v_17 == h4 ? q4 : _v_17 == h3 ? q3 : _v_17 == h2 ? q2 : blk_loc(e.mem, _v_17), _v_18, _v_18 == h4 ? q4 : _v_18 == h3 ? q3 : _v_18 == h2 ? q2 : blk_loc(e.mem, _v_18)) == 0) {
      return 0;
    }
    _v_25 = _o_2[0];
    _v_26 = _o_2[1];
    _v_27 = _o_2[2];
    _v_28 = _o_2[3];
    _v_29 = _o_2[4];
    _v_30 = _o_2[5];
    _v_7 = _v_25;
    _v_8 = _v_26;
    _v_9 = _v_27;
    _v_10 = _v_28;
    _v_11 = _v_29;
    _v_12 = _v_30;
  break;
  }
  o[0] = _v_7;
  o[1] = _v_8;
  o[2] = _v_9;
  o[3] = _v_10;
  o[4] = _v_11;
  o[5] = _v_12;
  return 1;
}

INLINE Term spin_86(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  u32 _built_0 = r0;
  u32 _built_1 = r1;
  Term _built_2 = r2;
  Term _built_3 = r3;
  Term _built_4 = r4;
  Term _built_5 = r5;
  Term _built_6 = r6;
  Term _built_7 = r7;
  Term _built_8 = r8;
  Term _needs_0 = r9;
  WL_SPIN
    if (_built_0 == 1) {
      term_sink(e, _needs_0);
      _v_10 = 1;
      _v_11 = _built_1;
      _v_12 = _built_2;
      _v_13 = _built_3;
      _v_14 = _built_4;
      _v_15 = _built_5;
      _v_16 = 0;
      _v_17 = 0;
      _v_18 = 0;
      _v_19 = 0;
    } else {
      _v_10 = 0;
      _v_11 = _built_1;
      _v_12 = _built_2;
      _v_13 = _built_3;
      _v_14 = _built_4;
      _v_15 = _built_5;
      _v_16 = _built_6;
      _v_17 = _built_7;
      _v_18 = _built_8;
      _v_19 = _needs_0;
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  o[3] = _v_13;
  o[4] = _v_14;
  o[5] = _v_15;
  o[6] = _v_16;
  o[7] = _v_17;
  o[8] = _v_18;
  o[9] = _v_19;
  return 1;
}

INLINE Term spin_87(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  Term _v_3 = 0;
  u32 _v_4 = 0;
  u32 _v_5 = 0;
  u32 _available_0 = r0;
  Term _world_1 = r1;
  Term _name_1 = r2;
  Term _access_1 = r3;
  WL_SPIN
    if (_available_0 == 0) {
      term_sink(e, _name_1);
      term_sink(e, _access_1);
      _v_3 = _world_1;
      _v_4 = 1;
      _v_5 = 3;
    } else {
      Term _fb_1[15];
      u64 _sp_1 = ctr_take(e, _world_1, 15, _fb_1);
      u32 _f_15 = _fb_1[0];
      u32 _f_16 = _fb_1[1];
      u32 _f_17 = _fb_1[2];
      Term _f_18 = _fb_1[3];
      u32 _f_19 = _fb_1[4];
      Term _f_20 = _fb_1[5];
      Term _f_21 = _fb_1[6];
      Term _f_22 = _fb_1[7];
      Term _f_23 = _fb_1[8];
      Term _f_24 = _fb_1[9];
      Term _f_25 = _fb_1[10];
      Term _f_26 = _fb_1[11];
      Term _f_27 = _fb_1[12];
      u32 _f_28 = _fb_1[13];
      u32 _f_29 = _fb_1[14];
      u64 _nd_1 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_1 + 0] = rfc_seal(e, _f_28);
      e.mem[_nd_1 + 1] = rfc_seal(e, _name_1);
      e.mem[_nd_1 + 2] = rfc_seal(e, _access_1);
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_WORLD_REGISTRATIONMETA, _nd_1));
      e.mem[_nd_2 + 1] = rfc_seal(e, _f_27);
      u64 _nd_3 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(15));
      e.mem[_nd_3 + 0] = rfc_seal(e, _f_15);
      e.mem[_nd_3 + 1] = rfc_seal(e, _f_16);
      e.mem[_nd_3 + 2] = rfc_seal(e, _f_17);
      e.mem[_nd_3 + 3] = rfc_seal(e, _f_18);
      e.mem[_nd_3 + 4] = rfc_seal(e, _f_19);
      e.mem[_nd_3 + 5] = rfc_seal(e, _f_20);
      e.mem[_nd_3 + 6] = rfc_seal(e, _f_21);
      e.mem[_nd_3 + 7] = rfc_seal(e, _f_22);
      e.mem[_nd_3 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_3 + 9] = rfc_seal(e, _f_24);
      e.mem[_nd_3 + 10] = rfc_seal(e, _f_25);
      e.mem[_nd_3 + 11] = rfc_seal(e, _f_26);
      e.mem[_nd_3 + 12] = rfc_seal(e, term_ctr(CID_CON, _nd_2));
      e.mem[_nd_3 + 13] = rfc_seal(e, U32_BIN(_f_28, +, 1ull));
      e.mem[_nd_3 + 14] = rfc_seal(e, _f_29);
      _v_3 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_3);
      _v_4 = 0;
      _v_5 = _f_28;
    }
  break;
  }
  o[0] = _v_3;
  o[1] = _v_4;
  o[2] = _v_5;
  return 1;
}

INLINE Term spin_88(Env e, THR Term* o) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  WL_SPIN
    _v_2 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_EMPTY, 0);
  break;
  }
  o[0] = _v_2;
  return 1;
}

INLINE Term spin_89(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  u32 _v_9 = 0;
  u32 _v_10 = 0;
  Term _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  Term _v_14 = 0;
  u32 _owner_0 = r0;
  u32 _owner_1 = r1;
  Term _owner_2 = r2;
  Term _owner_3 = r3;
  Term _owner_4 = r4;
  Term _result_0 = r5;
  WL_SPIN
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _o_1[6];
    if (spin_83(e, _o_1, _owner_0, _owner_1, _owner_2, _owner_2 == h2 ? q2 : blk_loc(e.mem, _owner_2), _owner_3, _owner_3 == h3 ? q3 : blk_loc(e.mem, _owner_3), _owner_4, _owner_4 == h4 ? q4 : blk_loc(e.mem, _owner_4)) == 0) {
      return 0;
    }
    _v_21 = _o_1[0];
    _v_22 = _o_1[1];
    _v_23 = _o_1[2];
    _v_24 = _o_1[3];
    _v_25 = _o_1[4];
    _v_26 = _o_1[5];
    _v_15 = _v_21;
    _v_16 = _v_22;
    _v_17 = _v_23;
    _v_18 = _v_24;
    _v_19 = _v_25;
    _v_20 = _v_26;
    u32 _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _o_2[6];
    if (spin_84(e, _o_2, _result_0, _result_0 == h5 ? q5 : blk_loc(e.mem, _result_0), _v_15, _v_16, _v_17, _v_17 == h5 ? q5 : _v_17 == h4 ? q4 : _v_17 == h3 ? q3 : _v_17 == h2 ? q2 : blk_loc(e.mem, _v_17), _v_18, _v_18 == h5 ? q5 : _v_18 == h4 ? q4 : _v_18 == h3 ? q3 : _v_18 == h2 ? q2 : blk_loc(e.mem, _v_18), _v_19, _v_19 == h5 ? q5 : _v_19 == h4 ? q4 : _v_19 == h3 ? q3 : _v_19 == h2 ? q2 : blk_loc(e.mem, _v_19), _v_20, _v_20 == h5 ? q5 : _v_20 == h4 ? q4 : _v_20 == h3 ? q3 : _v_20 == h2 ? q2 : blk_loc(e.mem, _v_20)) == 0) {
      return 0;
    }
    _v_27 = _o_2[0];
    _v_28 = _o_2[1];
    _v_29 = _o_2[2];
    _v_30 = _o_2[3];
    _v_31 = _o_2[4];
    _v_32 = _o_2[5];
    _v_9 = _v_27;
    _v_10 = _v_28;
    _v_11 = _v_29;
    _v_12 = _v_30;
    _v_13 = _v_31;
    _v_14 = _v_32;
  break;
  }
  o[0] = _v_9;
  o[1] = _v_10;
  o[2] = _v_11;
  o[3] = _v_12;
  o[4] = _v_13;
  o[5] = _v_14;
  return 1;
}

INLINE Term spin_90(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, Term r3, u64 q3, u32 r4, u32 r5, Term r6, u64 q6, Term r7, u64 q7, Term r8, u64 q8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h3 = r3;
  Term h6 = r6;
  Term h7 = r7;
  Term h8 = r8;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  u32 _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _schema_2 = r0;
  Term _world_2 = r1;
  u32 _debug_2 = r2;
  Term _selected_2 = r3;
  u32 _result_0 = r4;
  u32 _result_1 = r5;
  Term _result_2 = r6;
  Term _result_3 = r7;
  Term _result_4 = r8;
  Term _result_5 = r9;
  Term _result_6 = r10;
  Term _result_7 = r11;
  Term _result_8 = r12;
  Term _result_9 = r13;
  WL_SPIN
    if (_result_0 == 1) {
      term_sink(e, _schema_2);
      term_sink(e, _selected_2);
      _v_14 = 1;
      _v_15 = _world_2;
      _v_16 = _result_1;
      _v_17 = _result_2;
      _v_18 = _result_3;
      _v_19 = _result_4;
      _v_20 = _result_5;
      _v_21 = _debug_2;
      _v_22 = 0;
      _v_23 = 0;
      _v_24 = 0;
      _v_25 = 0;
      _v_26 = 0;
      _v_27 = 0;
    } else {
      _v_14 = 0;
      _v_15 = _schema_2;
      _v_16 = _world_2;
      _v_17 = _result_4;
      _v_18 = _result_5;
      _v_19 = _result_6;
      _v_20 = _result_7;
      _v_21 = _result_8;
      _v_22 = _debug_2;
      _v_23 = _selected_2;
      _v_24 = _result_1;
      _v_25 = _result_2;
      _v_26 = _result_3;
      _v_27 = _result_9;
    }
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

INLINE Term spin_91(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h9 = r9;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  u32 _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _v_41 = 0;
  u32 _v_42 = 0;
  Term _v_43 = 0;
  u32 _v_44 = 0;
  Term _v_45 = 0;
  Term _v_46 = 0;
  Term _v_47 = 0;
  Term _v_48 = 0;
  u32 _v_49 = 0;
  Term _v_50 = 0;
  u32 _result_19 = r0;
  Term _result_20 = r1;
  Term _result_21 = r2;
  u32 _result_22 = r3;
  u32 _result_23 = r4;
  Term _result_24 = r5;
  Term _result_25 = r6;
  Term _result_26 = r7;
  u32 _result_27 = r8;
  Term _result_28 = r9;
  u32 _result_29 = r10;
  Term _result_30 = r11;
  Term _result_31 = r12;
  Term _result_32 = r13;
  Term _result_33 = r14;
  u32 _result_34 = r15;
  Term _result_35 = r16;
  WL_SPIN
    if (_result_19 == 0) {
      _v_34 = 0;
      _v_35 = _result_20;
      _v_36 = _result_21;
      _v_37 = _result_22;
      _v_38 = _result_23;
      _v_39 = _result_24;
      _v_40 = _result_25;
      _v_41 = _result_26;
      _v_42 = _result_27;
      _v_43 = _result_28;
      _v_44 = _result_29;
      _v_45 = _result_30;
      _v_46 = _result_31;
      _v_47 = _result_32;
      _v_48 = _result_33;
      _v_49 = 0;
      _v_50 = 0;
    } else if (_result_19 == 1) {
      _v_34 = 1;
      _v_35 = _result_20;
      _v_36 = _result_21;
      _v_37 = _result_22;
      _v_38 = _result_23;
      _v_39 = _result_24;
      _v_40 = _result_25;
      _v_41 = _result_26;
      _v_42 = _result_27;
      _v_43 = _result_28;
      _v_44 = _result_29;
      _v_45 = _result_30;
      _v_46 = _result_31;
      _v_47 = _result_32;
      _v_48 = _result_33;
      _v_49 = _result_34;
      _v_50 = _result_35;
    } else if (_result_19 == 2) {
      _v_34 = 2;
      _v_35 = _result_20;
      _v_36 = _result_21;
      _v_37 = _result_22;
      _v_38 = _result_23;
      _v_39 = _result_24;
      _v_40 = _result_25;
      _v_41 = _result_26;
      _v_42 = _result_27;
      _v_43 = _result_28;
      _v_44 = _result_29;
      _v_45 = _result_30;
      _v_46 = _result_31;
      _v_47 = _result_32;
      _v_48 = 0;
      _v_49 = 0;
      _v_50 = 0;
    } else {
      _v_34 = 3;
      _v_35 = _result_20;
      _v_36 = _result_21;
      _v_37 = _result_22;
      _v_38 = _result_23;
      _v_39 = _result_24;
      _v_40 = _result_25;
      _v_41 = _result_26;
      _v_42 = _result_27;
      _v_43 = _result_28;
      _v_44 = _result_29;
      _v_45 = _result_30;
      _v_46 = _result_31;
      _v_47 = _result_32;
      _v_48 = _result_33;
      _v_49 = 0;
      _v_50 = 0;
    }
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  o[7] = _v_41;
  o[8] = _v_42;
  o[9] = _v_43;
  o[10] = _v_44;
  o[11] = _v_45;
  o[12] = _v_46;
  o[13] = _v_47;
  o[14] = _v_48;
  o[15] = _v_49;
  o[16] = _v_50;
  return 1;
}

INLINE Term spin_92(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _world_0 = r0;
  WL_SPIN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _world_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    Term _f_12 = _fb_0[12];
    u32 _f_13 = _fb_0[13];
    u32 _f_14 = _fb_0[14];
    u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(15));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _f_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _f_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, _f_6);
    e.mem[_nd_0 + 7] = rfc_seal(e, _f_7);
    e.mem[_nd_0 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 9] = rfc_seal(e, _f_9);
    e.mem[_nd_0 + 10] = rfc_seal(e, _f_10);
    e.mem[_nd_0 + 11] = rfc_seal(e, _f_11);
    e.mem[_nd_0 + 12] = rfc_seal(e, _f_12);
    e.mem[_nd_0 + 13] = rfc_seal(e, _f_13);
    e.mem[_nd_0 + 14] = rfc_seal(e, _f_14);
    _v_4 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
    _v_5 = _f_9;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_93(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, Term r3, u64 q3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, u32 r13) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h3 = r3;
  Term h4 = r4;
  Term h5 = r5;
  Term h7 = r7;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  u32 _v_33 = 0;
  Term _schema_0 = r0;
  u32 _owners_0 = r1;
  u32 _owners_1 = r2;
  Term _owners_2 = r3;
  Term _owners_3 = r4;
  Term _owners_4 = r5;
  u32 _debug_0 = r6;
  Term _selected_0 = r7;
  u32 _namespace_0 = r8;
  Term _name_0 = r9;
  Term _steps_0 = r10;
  Term _needs_0 = r11;
  Term _result_0 = r12;
  u32 _result_1 = r13;
  WL_SPIN
    _v_20 = _schema_0;
    _v_21 = _result_0;
    _v_22 = _owners_0;
    _v_23 = _owners_1;
    _v_24 = _owners_2;
    _v_25 = _owners_3;
    _v_26 = _owners_4;
    _v_27 = _debug_0;
    _v_28 = _selected_0;
    _v_29 = _namespace_0;
    _v_30 = _name_0;
    _v_31 = _steps_0;
    _v_32 = _needs_0;
    _v_33 = _result_1;
  break;
  }
  o[0] = _v_20;
  o[1] = _v_21;
  o[2] = _v_22;
  o[3] = _v_23;
  o[4] = _v_24;
  o[5] = _v_25;
  o[6] = _v_26;
  o[7] = _v_27;
  o[8] = _v_28;
  o[9] = _v_29;
  o[10] = _v_30;
  o[11] = _v_31;
  o[12] = _v_32;
  o[13] = _v_33;
  return 1;
}

INLINE Term spin_94(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_6 = 0;
  u32 _v_7 = 0;
  u32 _v_8 = 0;
  Term _world_0 = r0;
  Term _name_1 = r1;
  Term _access_1 = r2;
  WL_SPIN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _world_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    Term _f_12 = _fb_0[12];
    u32 _f_13 = _fb_0[13];
    u32 _f_14 = _fb_0[14];
    u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(15));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _f_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _f_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, _f_6);
    e.mem[_nd_0 + 7] = rfc_seal(e, _f_7);
    e.mem[_nd_0 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 9] = rfc_seal(e, _f_9);
    e.mem[_nd_0 + 10] = rfc_seal(e, _f_10);
    e.mem[_nd_0 + 11] = rfc_seal(e, _f_11);
    e.mem[_nd_0 + 12] = rfc_seal(e, _f_12);
    e.mem[_nd_0 + 13] = rfc_seal(e, _f_13);
    e.mem[_nd_0 + 14] = rfc_seal(e, _f_14);
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _o_0[3];
    Term _a_0 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
    if (spin_87(e, _o_0, U32_BIN(_f_13, <, 4294967295ull), _a_0, _a_0 == h2 ? q2 : _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), _name_1, _name_1 == h1 ? q1 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h2 ? q2 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_9 = _o_0[0];
    _v_10 = _o_0[1];
    _v_11 = _o_0[2];
    _v_6 = _v_9;
    _v_7 = _v_10;
    _v_8 = _v_11;
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  return 1;
}

INLINE Term spin_95(Env e, THR Term* o, Term r0, u64 q0, u32 r1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _registered_0 = r0;
  u32 _registered_1 = r1;
  u32 _registered_2 = r2;
  u32 _namespace_0 = r3;
  Term _name_2 = r4;
  Term _access_2 = r5;
  Term _local_1 = r6;
  WL_SPIN
    if (_registered_1 == 0) {
      _v_19 = 0;
      _v_20 = _registered_0;
      _v_21 = _namespace_0;
      _v_22 = _registered_2;
      _v_23 = _name_2;
      _v_24 = _access_2;
      _v_25 = _local_1;
    } else {
      term_sink(e, _name_2);
      term_sink(e, _access_2);
      _v_19 = 1;
      _v_20 = _registered_0;
      _v_21 = _local_1;
      _v_22 = 0;
      _v_23 = 0;
      _v_24 = 0;
      _v_25 = 0;
    }
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  return 1;
}

INLINE Term spin_96(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  u32 _v_6 = 0;
  u32 _v_7 = 0;
  Term _v_8 = 0;
  Term _v_9 = 0;
  Term _v_10 = 0;
  Term _v_11 = 0;
  u32 _owners_0 = r0;
  u32 _owners_1 = r1;
  Term _owners_2 = r2;
  Term _owners_3 = r3;
  Term _owners_4 = r4;
  WL_SPIN
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _o_0[1];
    if (spin_88(e, _o_0) == 0) {
      return 0;
    }
    _v_13 = _o_0[0];
    _v_12 = _v_13;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _o_1[6];
    if (spin_89(e, _o_1, _owners_0, _owners_1, _owners_2, _owners_2 == h2 ? q2 : blk_loc(e.mem, _owners_2), _owners_3, _owners_3 == h3 ? q3 : blk_loc(e.mem, _owners_3), _owners_4, _owners_4 == h4 ? q4 : blk_loc(e.mem, _owners_4), _v_12, _v_12 == h4 ? q4 : _v_12 == h3 ? q3 : _v_12 == h2 ? q2 : blk_loc(e.mem, _v_12)) == 0) {
      return 0;
    }
    _v_14 = _o_1[0];
    _v_15 = _o_1[1];
    _v_16 = _o_1[2];
    _v_17 = _o_1[3];
    _v_18 = _o_1[4];
    _v_19 = _o_1[5];
    _v_6 = _v_14;
    _v_7 = _v_15;
    _v_8 = _v_16;
    _v_9 = _v_17;
    _v_10 = _v_18;
    _v_11 = _v_19;
  break;
  }
  o[0] = _v_6;
  o[1] = _v_7;
  o[2] = _v_8;
  o[3] = _v_9;
  o[4] = _v_10;
  o[5] = _v_11;
  return 1;
}

INLINE Term spin_98(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, u32 r10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13, Term r14, u64 q14, u32 r15, Term r16, u64 q16, u32 r17, Term r18, u64 q18) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  Term h9 = r9;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term h14 = r14;
  Term h16 = r16;
  Term h18 = r18;
  u32 _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  u32 _v_22 = 0;
  u32 _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _v_28 = 0;
  u32 _v_29 = 0;
  Term _v_30 = 0;
  Term _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  u32 _v_36 = 0;
  Term _v_37 = 0;
  u32 _result_0 = r0;
  Term _result_1 = r1;
  Term _result_2 = r2;
  u32 _result_3 = r3;
  u32 _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  Term _result_7 = r7;
  u32 _result_8 = r8;
  Term _result_9 = r9;
  u32 _result_10 = r10;
  Term _result_11 = r11;
  Term _result_12 = r12;
  Term _result_13 = r13;
  Term _result_14 = r14;
  u32 _result_15 = r15;
  Term _result_16 = r16;
  u32 _result_17 = r17;
  Term _result_18 = r18;
  WL_SPIN
    u32 _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    u32 _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    Term _v_57 = 0;
    u32 _v_58 = 0;
    u32 _v_59 = 0;
    Term _v_60 = 0;
    Term _v_61 = 0;
    Term _v_62 = 0;
    u32 _v_63 = 0;
    Term _v_64 = 0;
    u32 _v_65 = 0;
    Term _v_66 = 0;
    Term _v_67 = 0;
    Term _v_68 = 0;
    Term _v_69 = 0;
    u32 _v_70 = 0;
    Term _v_71 = 0;
    Term _o_0[17];
    if (spin_91(e, _o_0, _result_0, _result_1, _result_1 == h1 ? q1 : blk_loc(e.mem, _result_1), _result_2, _result_2 == h2 ? q2 : blk_loc(e.mem, _result_2), _result_3, _result_4, _result_5, _result_5 == h5 ? q5 : blk_loc(e.mem, _result_5), _result_6, _result_6 == h6 ? q6 : blk_loc(e.mem, _result_6), _result_7, _result_7 == h7 ? q7 : blk_loc(e.mem, _result_7), _result_8, _result_9, _result_9 == h9 ? q9 : blk_loc(e.mem, _result_9), _result_10, _result_11, _result_11 == h11 ? q11 : blk_loc(e.mem, _result_11), _result_12, _result_12 == h12 ? q12 : blk_loc(e.mem, _result_12), _result_13, _result_13 == h13 ? q13 : blk_loc(e.mem, _result_13), _result_14, _result_14 == h14 ? q14 : blk_loc(e.mem, _result_14), _result_15, _result_16, _result_16 == h16 ? q16 : blk_loc(e.mem, _result_16)) == 0) {
      return 0;
    }
    _v_55 = _o_0[0];
    _v_56 = _o_0[1];
    _v_57 = _o_0[2];
    _v_58 = _o_0[3];
    _v_59 = _o_0[4];
    _v_60 = _o_0[5];
    _v_61 = _o_0[6];
    _v_62 = _o_0[7];
    _v_63 = _o_0[8];
    _v_64 = _o_0[9];
    _v_65 = _o_0[10];
    _v_66 = _o_0[11];
    _v_67 = _o_0[12];
    _v_68 = _o_0[13];
    _v_69 = _o_0[14];
    _v_70 = _o_0[15];
    _v_71 = _o_0[16];
    _v_38 = _v_55;
    _v_39 = _v_56;
    _v_40 = _v_57;
    _v_41 = _v_58;
    _v_42 = _v_59;
    _v_43 = _v_60;
    _v_44 = _v_61;
    _v_45 = _v_62;
    _v_46 = _v_63;
    _v_47 = _v_64;
    _v_48 = _v_65;
    _v_49 = _v_66;
    _v_50 = _v_67;
    _v_51 = _v_68;
    _v_52 = _v_69;
    _v_53 = _v_70;
    _v_54 = _v_71;
    _v_19 = _v_38;
    _v_20 = _v_39;
    _v_21 = _v_40;
    _v_22 = _v_41;
    _v_23 = _v_42;
    _v_24 = _v_43;
    _v_25 = _v_44;
    _v_26 = _v_45;
    _v_27 = _v_46;
    _v_28 = _v_47;
    _v_29 = _v_48;
    _v_30 = _v_49;
    _v_31 = _v_50;
    _v_32 = _v_51;
    _v_33 = _v_52;
    _v_34 = _v_53;
    _v_35 = _v_54;
    _v_36 = _result_17;
    _v_37 = _result_18;
  break;
  }
  o[0] = _v_19;
  o[1] = _v_20;
  o[2] = _v_21;
  o[3] = _v_22;
  o[4] = _v_23;
  o[5] = _v_24;
  o[6] = _v_25;
  o[7] = _v_26;
  o[8] = _v_27;
  o[9] = _v_28;
  o[10] = _v_29;
  o[11] = _v_30;
  o[12] = _v_31;
  o[13] = _v_32;
  o[14] = _v_33;
  o[15] = _v_34;
  o[16] = _v_35;
  o[17] = _v_36;
  o[18] = _v_37;
  return 1;
}

INLINE Term spin_99(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  u32 _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  u32 _v_27 = 0;
  Term _value_0 = r0;
  Term _value_1 = r1;
  u32 _value_2 = r2;
  u32 _value_3 = r3;
  Term _value_4 = r4;
  Term _value_5 = r5;
  Term _value_6 = r6;
  u32 _value_7 = r7;
  Term _value_8 = r8;
  u32 _value_9 = r9;
  Term _value_10 = r10;
  Term _value_11 = r11;
  Term _value_12 = r12;
  WL_SPIN
    Term _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_0[2];
    if (spin_92(e, _o_0, _value_1, _value_1 == h1 ? q1 : blk_loc(e.mem, _value_1)) == 0) {
      return 0;
    }
    _v_30 = _o_0[0];
    _v_31 = _o_0[1];
    _v_28 = _v_30;
    _v_29 = _v_31;
    Term _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    Term _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    Term _o_1[14];
    if (spin_93(e, _o_1, _value_0, _value_0 == h0 ? q0 : blk_loc(e.mem, _value_0), _value_2, _value_3, _value_4, _value_4 == h4 ? q4 : blk_loc(e.mem, _value_4), _value_5, _value_5 == h5 ? q5 : blk_loc(e.mem, _value_5), _value_6, _value_6 == h6 ? q6 : blk_loc(e.mem, _value_6), _value_7, _value_8, _value_8 == h8 ? q8 : blk_loc(e.mem, _value_8), _value_9, _value_10, _value_10 == h10 ? q10 : blk_loc(e.mem, _value_10), _value_11, _value_11 == h11 ? q11 : blk_loc(e.mem, _value_11), _value_12, _value_12 == h12 ? q12 : blk_loc(e.mem, _value_12), _v_28, _v_28 == h12 ? q12 : _v_28 == h11 ? q11 : _v_28 == h10 ? q10 : _v_28 == h8 ? q8 : _v_28 == h6 ? q6 : _v_28 == h5 ? q5 : _v_28 == h4 ? q4 : _v_28 == h1 ? q1 : _v_28 == h0 ? q0 : blk_loc(e.mem, _v_28), _v_29) == 0) {
      return 0;
    }
    _v_32 = _o_1[0];
    _v_33 = _o_1[1];
    _v_34 = _o_1[2];
    _v_35 = _o_1[3];
    _v_36 = _o_1[4];
    _v_37 = _o_1[5];
    _v_38 = _o_1[6];
    _v_39 = _o_1[7];
    _v_40 = _o_1[8];
    _v_41 = _o_1[9];
    _v_42 = _o_1[10];
    _v_43 = _o_1[11];
    _v_44 = _o_1[12];
    _v_45 = _o_1[13];
    _v_14 = _v_32;
    _v_15 = _v_33;
    _v_16 = _v_34;
    _v_17 = _v_35;
    _v_18 = _v_36;
    _v_19 = _v_37;
    _v_20 = _v_38;
    _v_21 = _v_39;
    _v_22 = _v_40;
    _v_23 = _v_41;
    _v_24 = _v_42;
    _v_25 = _v_43;
    _v_26 = _v_44;
    _v_27 = _v_45;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

INLINE Term spin_101(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, Term r4, u64 q4) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  Term h4 = r4;
  u32 _v_11 = 0;
  Term _v_12 = 0;
  Term _v_13 = 0;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  Term _v_17 = 0;
  Term _named_0 = r0;
  u32 _named_1 = r1;
  Term _name_1 = r2;
  Term _access_1 = r3;
  Term _local_1 = r4;
  WL_SPIN
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    _name_1 = term_keep(e, _name_1, 1);
    _access_1 = term_keep(e, _access_1, 1);
    Term _v_21 = 0;
    u32 _v_22 = 0;
    u32 _v_23 = 0;
    Term _o_1[3];
    if (spin_94(e, _o_1, _named_0, _named_0 == h0 ? q0 : blk_loc(e.mem, _named_0), _name_1, _name_1 == h2 ? q2 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h3 ? q3 : blk_loc(e.mem, _access_1)) == 0) {
      return 0;
    }
    _v_21 = _o_1[0];
    _v_22 = _o_1[1];
    _v_23 = _o_1[2];
    _v_18 = _v_21;
    _v_19 = _v_22;
    _v_20 = _v_23;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    Term _v_30 = 0;
    Term _o_2[7];
    if (spin_95(e, _o_2, _v_18, _v_18 == h4 ? q4 : _v_18 == h3 ? q3 : _v_18 == h2 ? q2 : _v_18 == h0 ? q0 : blk_loc(e.mem, _v_18), _v_19, _v_20, _named_1, _name_1, _name_1 == h2 ? q2 : blk_loc(e.mem, _name_1), _access_1, _access_1 == h3 ? q3 : blk_loc(e.mem, _access_1), _local_1, _local_1 == h4 ? q4 : blk_loc(e.mem, _local_1)) == 0) {
      return 0;
    }
    _v_24 = _o_2[0];
    _v_25 = _o_2[1];
    _v_26 = _o_2[2];
    _v_27 = _o_2[3];
    _v_28 = _o_2[4];
    _v_29 = _o_2[5];
    _v_30 = _o_2[6];
    _v_11 = _v_24;
    _v_12 = _v_25;
    _v_13 = _v_26;
    _v_14 = _v_27;
    _v_15 = _v_28;
    _v_16 = _v_29;
    _v_17 = _v_30;
  break;
  }
  o[0] = _v_11;
  o[1] = _v_12;
  o[2] = _v_13;
  o[3] = _v_14;
  o[4] = _v_15;
  o[5] = _v_16;
  o[6] = _v_17;
  return 1;
}

INLINE Term spin_103(Env e, THR Term* o, u32 r0, Term r1, u64 q1) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term _v_9 = 0;
  u32 _barrier_2 = r0;
  Term _plan_0 = r1;
  WL_SPIN
    if (_barrier_2 == 0) {
      _v_9 = _plan_0;
    } else {
      u64 _nd_9 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_SCHEDULE_PROVISION_ENTRY, STAT_OFF + 16));
      e.mem[_nd_9 + 1] = rfc_seal(e, _plan_0);
      _v_9 = term_ctr(CID__________SRC_ECS_SCHEDULE_PROVISION_SEQUENCE, _nd_9);
    }
  break;
  }
  o[0] = _v_9;
  return 1;
}

INLINE Term spin_104(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, u32 r6, Term r7, u64 q7, u32 r8, Term r9, u64 q9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12, Term r13, u64 q13) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h4 = r4;
  Term h5 = r5;
  Term h7 = r7;
  Term h9 = r9;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term h13 = r13;
  Term _v_14 = 0;
  Term _v_15 = 0;
  u32 _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  u32 _v_21 = 0;
  Term _v_22 = 0;
  u32 _v_23 = 0;
  Term _v_24 = 0;
  Term _v_25 = 0;
  Term _v_26 = 0;
  Term _v_27 = 0;
  Term _schema_0 = r0;
  Term _world_0 = r1;
  u32 _namespace_0 = r2;
  u32 _id_0 = r3;
  Term _name_0 = r4;
  Term _access_0 = r5;
  u32 _debug_0 = r6;
  Term _plan_0 = r7;
  u32 _scheduleNamespace_0 = r8;
  Term _scheduleName_0 = r9;
  Term _steps_0 = r10;
  Term _needs_0 = r11;
  Term _result_0 = r12;
  Term _result_1 = r13;
  WL_SPIN
    _v_14 = _schema_0;
    _v_15 = _world_0;
    _v_16 = _namespace_0;
    _v_17 = _id_0;
    _v_18 = _name_0;
    _v_19 = _access_0;
    _v_20 = _result_0;
    _v_21 = _debug_0;
    _v_22 = _plan_0;
    _v_23 = _scheduleNamespace_0;
    _v_24 = _scheduleName_0;
    _v_25 = _steps_0;
    _v_26 = _needs_0;
    _v_27 = _result_1;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  o[7] = _v_21;
  o[8] = _v_22;
  o[9] = _v_23;
  o[10] = _v_24;
  o[11] = _v_25;
  o[12] = _v_26;
  o[13] = _v_27;
  return 1;
}

INLINE Term spin_105(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, u32 r2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6, u32 r7, Term r8, u64 q8, u32 r9, Term r10, u64 q10, Term r11, u64 q11, Term r12, u64 q12) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  Term h8 = r8;
  Term h10 = r10;
  Term h11 = r11;
  Term h12 = r12;
  Term _v_28 = 0;
  Term _v_29 = 0;
  u32 _v_30 = 0;
  u32 _v_31 = 0;
  Term _v_32 = 0;
  Term _v_33 = 0;
  Term _v_34 = 0;
  u32 _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  u32 _v_41 = 0;
  Term _app_0 = r0;
  Term _app_1 = r1;
  u32 _app_2 = r2;
  u32 _app_3 = r3;
  Term _app_4 = r4;
  Term _app_5 = r5;
  Term _app_6 = r6;
  u32 _app_7 = r7;
  Term _app_8 = r8;
  u32 _app_9 = r9;
  Term _app_10 = r10;
  Term _app_11 = r11;
  Term _app_12 = r12;
  WL_SPIN
    Term _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    u32 _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    Term _v_48 = 0;
    u32 _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _o_0[14];
    if (spin_99(e, _o_0, _app_0, _app_0 == h0 ? q0 : blk_loc(e.mem, _app_0), _app_1, _app_1 == h1 ? q1 : blk_loc(e.mem, _app_1), _app_2, _app_3, _app_4, _app_4 == h4 ? q4 : blk_loc(e.mem, _app_4), _app_5, _app_5 == h5 ? q5 : blk_loc(e.mem, _app_5), _app_6, _app_6 == h6 ? q6 : blk_loc(e.mem, _app_6), _app_7, _app_8, _app_8 == h8 ? q8 : blk_loc(e.mem, _app_8), _app_9, _app_10, _app_10 == h10 ? q10 : blk_loc(e.mem, _app_10), _app_11, _app_11 == h11 ? q11 : blk_loc(e.mem, _app_11), _app_12, _app_12 == h12 ? q12 : blk_loc(e.mem, _app_12)) == 0) {
      return 0;
    }
    _v_42 = _o_0[0];
    _v_43 = _o_0[1];
    _v_44 = _o_0[2];
    _v_45 = _o_0[3];
    _v_46 = _o_0[4];
    _v_47 = _o_0[5];
    _v_48 = _o_0[6];
    _v_49 = _o_0[7];
    _v_50 = _o_0[8];
    _v_51 = _o_0[9];
    _v_52 = _o_0[10];
    _v_53 = _o_0[11];
    _v_54 = _o_0[12];
    _v_55 = _o_0[13];
    _v_28 = _v_42;
    _v_29 = _v_43;
    _v_30 = _v_44;
    _v_31 = _v_45;
    _v_32 = _v_46;
    _v_33 = _v_47;
    _v_34 = _v_48;
    _v_35 = _v_49;
    _v_36 = _v_50;
    _v_37 = _v_51;
    _v_38 = _v_52;
    _v_39 = _v_53;
    _v_40 = _v_54;
    _v_41 = _v_55;
  break;
  }
  o[0] = _v_28;
  o[1] = _v_29;
  o[2] = _v_30;
  o[3] = _v_31;
  o[4] = _v_32;
  o[5] = _v_33;
  o[6] = _v_34;
  o[7] = _v_35;
  o[8] = _v_36;
  o[9] = _v_37;
  o[10] = _v_38;
  o[11] = _v_39;
  o[12] = _v_40;
  o[13] = _v_41;
  return 1;
}

INLINE Term spin_106(Env e, THR Term* o, Term r0, u64 q0, u32 r1) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_26 = 0;
  Term _value_0 = r0;
  u32 _value_1 = r1;
  WL_SPIN
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _value_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    _v_26 = term_ctr(CID_CON, _nd_4);
  break;
  }
  o[0] = _v_26;
  return 1;
}

INLINE Term spin_107(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  Term h3 = r3;
  u32 _v_34 = 0;
  Term _v_35 = 0;
  Term _v_36 = 0;
  u32 _v_37 = 0;
  Term _v_38 = 0;
  Term _v_39 = 0;
  Term _v_40 = 0;
  Term _world_1 = r0;
  Term _name_1 = r1;
  Term _access_0 = r2;
  Term _local_1 = r3;
  WL_SPIN
    Term _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    u32 _v_44 = 0;
    Term _o_4[2];
    if (spin_52(e, _o_4, _world_1, _world_1 == h0 ? q0 : blk_loc(e.mem, _world_1)) == 0) {
      return 0;
    }
    _v_43 = _o_4[0];
    _v_44 = _o_4[1];
    _v_41 = _v_43;
    _v_42 = _v_44;
    u32 _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _o_5[7];
    if (spin_101(e, _o_5, _v_41, _v_41 == h3 ? q3 : _v_41 == h2 ? q2 : _v_41 == h1 ? q1 : _v_41 == h0 ? q0 : blk_loc(e.mem, _v_41), _v_42, _name_1, _name_1 == h1 ? q1 : blk_loc(e.mem, _name_1), _access_0, _access_0 == h2 ? q2 : blk_loc(e.mem, _access_0), _local_1, _local_1 == h3 ? q3 : blk_loc(e.mem, _local_1)) == 0) {
      return 0;
    }
    _v_45 = _o_5[0];
    _v_46 = _o_5[1];
    _v_47 = _o_5[2];
    _v_48 = _o_5[3];
    _v_49 = _o_5[4];
    _v_50 = _o_5[5];
    _v_51 = _o_5[6];
    _v_34 = _v_45;
    _v_35 = _v_46;
    _v_36 = _v_47;
    _v_37 = _v_48;
    _v_38 = _v_49;
    _v_39 = _v_50;
    _v_40 = _v_51;
  break;
  }
  o[0] = _v_34;
  o[1] = _v_35;
  o[2] = _v_36;
  o[3] = _v_37;
  o[4] = _v_38;
  o[5] = _v_39;
  o[6] = _v_40;
  return 1;
}

INLINE Term spin_108(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2, u32 r3, Term r4, u64 q4, Term r5, u64 q5, Term r6, u64 q6) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term h4 = r4;
  Term h5 = r5;
  Term h6 = r6;
  u32 _v_59 = 0;
  Term _v_60 = 0;
  Term _v_61 = 0;
  u32 _v_62 = 0;
  Term _v_63 = 0;
  Term _v_64 = 0;
  Term _v_65 = 0;
  u32 _result_0 = r0;
  Term _result_1 = r1;
  Term _result_2 = r2;
  u32 _result_3 = r3;
  Term _result_4 = r4;
  Term _result_5 = r5;
  Term _result_6 = r6;
  WL_SPIN
    if (_result_0 == 0) {
      _v_59 = 0;
      _v_60 = _result_1;
      _v_61 = _result_2;
      _v_62 = _result_3;
      _v_63 = _result_4;
      _v_64 = _result_5;
      _v_65 = _result_6;
    } else {
      _v_59 = 1;
      _v_60 = _result_1;
      _v_61 = _result_2;
      _v_62 = 0;
      _v_63 = 0;
      _v_64 = 0;
      _v_65 = 0;
    }
  break;
  }
  o[0] = _v_59;
  o[1] = _v_60;
  o[2] = _v_61;
  o[3] = _v_62;
  o[4] = _v_63;
  o[5] = _v_64;
  o[6] = _v_65;
  return 1;
}

INLINE Term spin_109(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _world_1 = r0;
  WL_SPIN
    _v_4 = _world_1;
    _v_5 = 0;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_110(Env e, THR Term* o, Term r0, u64 q0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h1 = r1;
  Term h2 = r2;
  u32 _v_14 = 0;
  Term _v_15 = 0;
  Term _v_16 = 0;
  u32 _v_17 = 0;
  Term _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _world_0 = r0;
  Term _name_1 = r1;
  Term _local_1 = r2;
  WL_SPIN
    u32 _v_21 = 0;
    Term _v_22 = 0;
    Term _v_23 = 0;
    u32 _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_44 = 0;
    u32 _v_45 = 0;
    Term _o_2[2];
    Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 8);
    Term _a_1 = term_clo(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C564, 0);
    Term _a_2 = term_clo(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C565, 0);
    if (spin_34(e, _o_2, _a_0, _a_0 == h2 ? q2 : _a_0 == h1 ? q1 : _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), 1, _a_1, _a_1 == h2 ? q2 : _a_1 == h1 ? q1 : _a_1 == h0 ? q0 : blk_loc(e.mem, _a_1), _a_2, _a_2 == h2 ? q2 : _a_2 == h1 ? q1 : _a_2 == h0 ? q0 : blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_44 = _o_2[0];
    _v_45 = _o_2[1];
    _v_29 = _v_44;
    _v_30 = _v_45;
    Term _v_46 = 0;
    Term _o_3[1];
    if (spin_106(e, _o_3, _v_29, _v_29 == h2 ? q2 : _v_29 == h1 ? q1 : _v_29 == h0 ? q0 : blk_loc(e.mem, _v_29), _v_30) == 0) {
      return 0;
    }
    _v_46 = _o_3[0];
    _v_28 = _v_46;
    u32 _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    u32 _v_50 = 0;
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _o_4[7];
    if (spin_107(e, _o_4, _world_0, _world_0 == h0 ? q0 : blk_loc(e.mem, _world_0), _name_1, _name_1 == h1 ? q1 : blk_loc(e.mem, _name_1), _v_28, _v_28 == h2 ? q2 : _v_28 == h1 ? q1 : _v_28 == h0 ? q0 : blk_loc(e.mem, _v_28), _local_1, _local_1 == h2 ? q2 : blk_loc(e.mem, _local_1)) == 0) {
      return 0;
    }
    _v_47 = _o_4[0];
    _v_48 = _o_4[1];
    _v_49 = _o_4[2];
    _v_50 = _o_4[3];
    _v_51 = _o_4[4];
    _v_52 = _o_4[5];
    _v_53 = _o_4[6];
    _v_21 = _v_47;
    _v_22 = _v_48;
    _v_23 = _v_49;
    _v_24 = _v_50;
    _v_25 = _v_51;
    _v_26 = _v_52;
    _v_27 = _v_53;
    u32 _v_54 = 0;
    Term _v_55 = 0;
    Term _v_56 = 0;
    u32 _v_57 = 0;
    Term _v_58 = 0;
    Term _v_59 = 0;
    Term _v_60 = 0;
    Term _o_5[7];
    if (spin_108(e, _o_5, _v_21, _v_22, _v_22 == h2 ? q2 : _v_22 == h1 ? q1 : _v_22 == h0 ? q0 : blk_loc(e.mem, _v_22), _v_23, _v_23 == h2 ? q2 : _v_23 == h1 ? q1 : _v_23 == h0 ? q0 : blk_loc(e.mem, _v_23), _v_24, _v_25, _v_25 == h2 ? q2 : _v_25 == h1 ? q1 : _v_25 == h0 ? q0 : blk_loc(e.mem, _v_25), _v_26, _v_26 == h2 ? q2 : _v_26 == h1 ? q1 : _v_26 == h0 ? q0 : blk_loc(e.mem, _v_26), _v_27, _v_27 == h2 ? q2 : _v_27 == h1 ? q1 : _v_27 == h0 ? q0 : blk_loc(e.mem, _v_27)) == 0) {
      return 0;
    }
    _v_54 = _o_5[0];
    _v_55 = _o_5[1];
    _v_56 = _o_5[2];
    _v_57 = _o_5[3];
    _v_58 = _o_5[4];
    _v_59 = _o_5[5];
    _v_60 = _o_5[6];
    _v_14 = _v_54;
    _v_15 = _v_55;
    _v_16 = _v_56;
    _v_17 = _v_57;
    _v_18 = _v_58;
    _v_19 = _v_59;
    _v_20 = _v_60;
  break;
  }
  o[0] = _v_14;
  o[1] = _v_15;
  o[2] = _v_16;
  o[3] = _v_17;
  o[4] = _v_18;
  o[5] = _v_19;
  o[6] = _v_20;
  return 1;
}

INLINE Term spin_111(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2, Term r3, u64 q3, u32 r4, Term r5, u64 q5, Term r6, u64 q6, Term r7, u64 q7) {
  u32 wpoll = 0;
  Term h2 = r2;
  Term h3 = r3;
  Term h5 = r5;
  Term h6 = r6;
  Term h7 = r7;
  u32 _v_69 = 0;
  Term _v_70 = 0;
  u32 _v_71 = 0;
  Term _v_72 = 0;
  Term _v_73 = 0;
  Term _v_74 = 0;
  Term _v_75 = 0;
  u32 _v_76 = 0;
  u32 _debug_0 = r0;
  u32 _result_0 = r1;
  Term _result_1 = r2;
  Term _result_2 = r3;
  u32 _result_3 = r4;
  Term _result_4 = r5;
  Term _result_5 = r6;
  Term _result_6 = r7;
  WL_SPIN
    if (_result_0 == 1) {
      _v_69 = 1;
      _v_70 = _result_1;
      _v_71 = _debug_0;
      _v_72 = _result_2;
      _v_73 = 0;
      _v_74 = 0;
      _v_75 = 0;
      _v_76 = 0;
    } else {
      _v_69 = 0;
      _v_70 = _result_1;
      _v_71 = _result_2;
      _v_72 = _result_3;
      _v_73 = _result_4;
      _v_74 = _result_5;
      _v_75 = _result_6;
      _v_76 = _debug_0;
    }
  break;
  }
  o[0] = _v_69;
  o[1] = _v_70;
  o[2] = _v_71;
  o[3] = _v_72;
  o[4] = _v_73;
  o[5] = _v_74;
  o[6] = _v_75;
  o[7] = _v_76;
  return 1;
}

INLINE Term spin_112(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term _v_4 = 0;
  u32 _v_5 = 0;
  Term _world_1 = r0;
  WL_SPIN
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _o_0[2];
    if (spin_109(e, _o_0, _world_1, _world_1 == h0 ? q0 : blk_loc(e.mem, _world_1)) == 0) {
      return 0;
    }
    _v_8 = _o_0[0];
    _v_9 = _o_0[1];
    _v_6 = _v_8;
    _v_7 = _v_9;
    _v_4 = _v_6;
    _v_5 = _v_7;
  break;
  }
  o[0] = _v_4;
  o[1] = _v_5;
  return 1;
}

INLINE Term spin_113(Env e, THR Term* o, Term r0, u64 q0, u32 r1, Term r2, u64 q2, Term r3, u64 q3) {
  u32 wpoll = 0;
  Term h0 = r0;
  Term h2 = r2;
  Term h3 = r3;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  u32 _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  Term _v_23 = 0;
  Term _v_24 = 0;
  u32 _v_25 = 0;
  Term _value_0 = r0;
  u32 _value_1 = r1;
  Term _name_0 = r2;
  Term _local_0 = r3;
  WL_SPIN
    u32 _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    u32 _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _o_2[7];
    if (spin_110(e, _o_2, _value_0, _value_0 == h0 ? q0 : blk_loc(e.mem, _value_0), _name_0, _name_0 == h2 ? q2 : blk_loc(e.mem, _name_0), _local_0, _local_0 == h3 ? q3 : blk_loc(e.mem, _local_0)) == 0) {
      return 0;
    }
    _v_33 = _o_2[0];
    _v_34 = _o_2[1];
    _v_35 = _o_2[2];
    _v_36 = _o_2[3];
    _v_37 = _o_2[4];
    _v_38 = _o_2[5];
    _v_39 = _o_2[6];
    _v_26 = _v_33;
    _v_27 = _v_34;
    _v_28 = _v_35;
    _v_29 = _v_36;
    _v_30 = _v_37;
    _v_31 = _v_38;
    _v_32 = _v_39;
    u32 _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    u32 _v_47 = 0;
    Term _o_3[8];
    if (spin_111(e, _o_3, _value_1, _v_26, _v_27, _v_27 == h3 ? q3 : _v_27 == h2 ? q2 : _v_27 == h0 ? q0 : blk_loc(e.mem, _v_27), _v_28, _v_28 == h3 ? q3 : _v_28 == h2 ? q2 : _v_28 == h0 ? q0 : blk_loc(e.mem, _v_28), _v_29, _v_30, _v_30 == h3 ? q3 : _v_30 == h2 ? q2 : _v_30 == h0 ? q0 : blk_loc(e.mem, _v_30), _v_31, _v_31 == h3 ? q3 : _v_31 == h2 ? q2 : _v_31 == h0 ? q0 : blk_loc(e.mem, _v_31), _v_32, _v_32 == h3 ? q3 : _v_32 == h2 ? q2 : _v_32 == h0 ? q0 : blk_loc(e.mem, _v_32)) == 0) {
      return 0;
    }
    _v_40 = _o_3[0];
    _v_41 = _o_3[1];
    _v_42 = _o_3[2];
    _v_43 = _o_3[3];
    _v_44 = _o_3[4];
    _v_45 = _o_3[5];
    _v_46 = _o_3[6];
    _v_47 = _o_3[7];
    _v_18 = _v_40;
    _v_19 = _v_41;
    _v_20 = _v_42;
    _v_21 = _v_43;
    _v_22 = _v_44;
    _v_23 = _v_45;
    _v_24 = _v_46;
    _v_25 = _v_47;
  break;
  }
  o[0] = _v_18;
  o[1] = _v_19;
  o[2] = _v_20;
  o[3] = _v_21;
  o[4] = _v_22;
  o[5] = _v_23;
  o[6] = _v_24;
  o[7] = _v_25;
  return 1;
}

INLINE Term spin_114(Env e, THR Term* o, Term r0, u64 q0) {
  u32 wpoll = 0;
  Term h0 = r0;
  u32 _v_16 = 0;
  Term _v_17 = 0;
  u32 _v_18 = 0;
  Term _v_19 = 0;
  Term _v_20 = 0;
  Term _v_21 = 0;
  Term _v_22 = 0;
  u32 _v_23 = 0;
  Term _world_1 = r0;
  WL_SPIN
    Term _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_0[2];
    if (spin_112(e, _o_0, _world_1, _world_1 == h0 ? q0 : blk_loc(e.mem, _world_1)) == 0) {
      return 0;
    }
    _v_26 = _o_0[0];
    _v_27 = _o_0[1];
    _v_24 = _v_26;
    _v_25 = _v_27;
    Term _fv_0[1];
    _fv_0[0] = 0ull;
    Term _fv_1[1];
    _fv_1[0] = 1ull;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    Term _o_1[8];
    Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 194);
    Term _a_1 = blk_node(e, blk_new(e, 0, 0, 0, 1, _fv_0), blk_new(e, 0, 0, 0, 1, _fv_1));
    if (spin_113(e, _o_1, _v_24, _v_24 == h0 ? q0 : blk_loc(e.mem, _v_24), _v_25, _a_0, _a_0 == h0 ? q0 : blk_loc(e.mem, _a_0), _a_1, _a_1 == h0 ? q0 : blk_loc(e.mem, _a_1)) == 0) {
      return 0;
    }
    _v_28 = _o_1[0];
    _v_29 = _o_1[1];
    _v_30 = _o_1[2];
    _v_31 = _o_1[3];
    _v_32 = _o_1[4];
    _v_33 = _o_1[5];
    _v_34 = _o_1[6];
    _v_35 = _o_1[7];
    _v_16 = _v_28;
    _v_17 = _v_29;
    _v_18 = _v_30;
    _v_19 = _v_31;
    _v_20 = _v_32;
    _v_21 = _v_33;
    _v_22 = _v_34;
    _v_23 = _v_35;
  break;
  }
  o[0] = _v_16;
  o[1] = _v_17;
  o[2] = _v_18;
  o[3] = _v_19;
  o[4] = _v_20;
  o[5] = _v_21;
  o[6] = _v_22;
  o[7] = _v_23;
  return 1;
}

INLINE Term spin_115(Env e, THR Term* o, u32 r0, u32 r1, u32 r2) {
  u32 wpoll = 0;
  u32 _v_10 = 0;
  u32 _v_11 = 0;
  Term _v_12 = 0;
  u32 _available_0 = r0;
  u32 _namespace_2 = r1;
  u32 _resource_2 = r2;
  WL_SPIN
    if (_available_0 == 0) {
      _v_10 = 1;
      _v_11 = _namespace_2;
      _v_12 = _resource_2;
    } else {
      Term _fv_0[2];
      _fv_0[0] = 0ull;
      _fv_0[1] = 0;
      u64 _nd_1 = heap_alloc(e, cls_fit(15));
      e.mem[_nd_1 + 0] = rfc_seal(e, _namespace_2);
      e.mem[_nd_1 + 1] = rfc_seal(e, 1ull);
      e.mem[_nd_1 + 2] = rfc_seal(e, 0ull);
      e.mem[_nd_1 + 3] = rfc_seal(e, blk_new(e, 0, 0, 1, 2, _fv_0));
      e.mem[_nd_1 + 4] = rfc_seal(e, 1ull);
      e.mem[_nd_1 + 5] = rfc_seal(e, 0);
      e.mem[_nd_1 + 6] = rfc_seal(e, term_pak(CID_NIL, 0));
      e.mem[_nd_1 + 7] = rfc_seal(e, term_pak(CID_NIL, 0));
      e.mem[_nd_1 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_1 + 9] = rfc_seal(e, _resource_2);
      e.mem[_nd_1 + 10] = rfc_seal(e, term_pak(CID_NIL, 0));
      e.mem[_nd_1 + 11] = rfc_seal(e, term_pak(CID_NIL, 0));
      e.mem[_nd_1 + 12] = rfc_seal(e, term_pak(CID_NIL, 0));
      e.mem[_nd_1 + 13] = rfc_seal(e, 1ull);
      e.mem[_nd_1 + 14] = rfc_seal(e, 0ull);
      _v_10 = 0;
      _v_11 = U32_BIN(_namespace_2, +, 1ull);
      _v_12 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_1);
    }
  break;
  }
  o[0] = _v_10;
  o[1] = _v_11;
  o[2] = _v_12;
  return 1;
}

INLINE Term spin_116(Env e, THR Term* o, u32 r0, u32 r1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h2 = r2;
  u32 _v_15 = 0;
  Term _v_16 = 0;
  u32 _created_0 = r0;
  u32 _created_1 = r1;
  Term _created_2 = r2;
  WL_SPIN
    if (_created_0 == 0) {
      _v_15 = 0;
      _v_16 = _created_2;
    } else {
      _v_15 = 1;
      _v_16 = _created_2;
    }
  break;
  }
  o[0] = _v_15;
  o[1] = _v_16;
  return 1;
}

INLINE Term spin_117(Env e, THR Term* o, u32 r0, Term r1, u64 q1, Term r2, u64 q2) {
  u32 wpoll = 0;
  Term h1 = r1;
  Term h2 = r2;
  Term _v_1 = 0;
  u32 _code_0 = r0;
  Term _msg_0 = r1;
  Term _k_0 = r2;
  WL_SPIN
    term_sink(e, _k_0);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = _code_0;
    e.mem[_nd_1 + 1] = _msg_0;
    _v_1 = term_ctr(CID_HALT, _nd_1);
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_118(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  Term _v_1 = 0;
  u32 _namespace_0 = r0;
  u32 _resource_3 = r1;
  WL_SPIN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _namespace_0;
    e.mem[_nd_2 + 1] = _resource_3;
    _v_1 = term_clo(FID__________SRC_ECS_WORLD_IO_WITH_NAMESPACE_0_C618, _nd_2);
  break;
  }
  o[0] = _v_1;
  return 1;
}

INLINE Term spin_119(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  Term _v_2 = 0;
  u32 _resource_0 = r0;
  WL_SPIN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _resource_0;
    _v_2 = term_clo(FID__________SRC_ECS_WORLD_IO_CREATE_0_C624, _nd_0);
  break;
  }
  o[0] = _v_2;
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0)
  {
    Term _ctx_0 = r0;
    Term _ctx_1 = r1;
    Term _ctx_2 = r2;
    Term _ctx_3 = r3;
    u32 _ctx_4 = r4;
    Term _ctx_5 = r5;
    u32 _value_0 = r6;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_85 = 0;
    Term _v_86 = 0;
    Term _o_11[2];
    Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 8);
    Term _a_1 = term_clo(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C11, 0);
    Term _a_2 = term_clo(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C12, 0);
    if (spin_16(e, _o_11, _a_0, blk_loc(e.mem, _a_0), 1, _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_85 = _o_11[0];
    _v_86 = _o_11[1];
    _v_1 = _v_85;
    _v_2 = _v_86;
    Term _v_89 = 0;
    Term _o_12[1];
    if (spin_17(e, _o_12, _v_1, blk_loc(e.mem, _v_1), _v_2, blk_loc(e.mem, _v_2)) == 0) {
      return 0;
    }
    _v_89 = _o_12[0];
    _v_0 = _v_89;
    u64 _nd_8 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_8 + 0] = rfc_seal(e, _ctx_0);
    e.mem[_nd_8 + 1] = rfc_seal(e, _ctx_1);
    e.mem[_nd_8 + 2] = rfc_seal(e, _ctx_2);
    e.mem[_nd_8 + 3] = rfc_seal(e, _ctx_3);
    e.mem[_nd_8 + 4] = rfc_seal(e, _ctx_4);
    e.mem[_nd_8 + 5] = rfc_seal(e, _ctx_5);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _value_0;
      STK(1) = FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K15;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K15, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K15, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      e.mem[_t_1 + 1] = term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_8);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _v_0;
    r1 = term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_8);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C11)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[6];
    u64 _sp_0 = ctr_take(e, _x_0, 6, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    spare_free(e, cls_fit(6), _sp_0);
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _o_4[7];
    if (spin_6(e, _o_4, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1), _f_2, blk_loc(e.mem, _f_2), _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, blk_loc(e.mem, _f_5)) == 0) {
      return 0;
    }
    _v_3 = _o_4[0];
    _v_4 = _o_4[1];
    _v_5 = _o_4[2];
    _v_6 = _o_4[3];
    _v_7 = _o_4[4];
    _v_8 = _o_4[5];
    _v_9 = _o_4[6];
    u64 _nd_1 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_3);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_4);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_5);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_6);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_7);
    e.mem[_nd_1 + 5] = rfc_seal(e, _v_8);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_9);
    r0 = term_ctr(CID_TUPLE, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C12)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_2[6];
    u64 _sp_2 = ctr_take(e, _x_1, 6, _fb_2);
    Term _f_21 = _fb_2[0];
    Term _f_22 = _fb_2[1];
    Term _f_23 = _fb_2[2];
    Term _f_24 = _fb_2[3];
    u32 _f_25 = _fb_2[4];
    Term _f_26 = _fb_2[5];
    spare_free(e, cls_fit(6), _sp_2);
    u64 _nd_3 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_3 + 0] = _f_21;
    e.mem[_nd_3 + 1] = _f_22;
    e.mem[_nd_3 + 2] = _f_23;
    e.mem[_nd_3 + 3] = _f_24;
    e.mem[_nd_3 + 4] = _f_25;
    e.mem[_nd_3 + 5] = _f_26;
    r0 = term_clo(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C13, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_C13)
  {
    Term _f_27 = r0;
    Term _f_28 = r1;
    Term _f_29 = r2;
    Term _f_30 = r3;
    u32 _f_31 = r4;
    Term _f_32 = r5;
    Term _x_2 = r6;
    WL_OPEN
    Term _v_47 = 0;
    Term _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    u32 _v_51 = 0;
    Term _v_52 = 0;
    Term _o_10[6];
    if (spin_11(e, _o_10, _f_27, blk_loc(e.mem, _f_27), _f_28, blk_loc(e.mem, _f_28), _f_29, blk_loc(e.mem, _f_29), _f_30, blk_loc(e.mem, _f_30), _f_31, _f_32, blk_loc(e.mem, _f_32), _x_2) == 0) {
      return 0;
    }
    _v_47 = _o_10[0];
    _v_48 = _o_10[1];
    _v_49 = _o_10[2];
    _v_50 = _o_10[3];
    _v_51 = _o_10[4];
    _v_52 = _o_10[5];
    u64 _nd_7 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_7 + 0] = rfc_seal(e, _v_47);
    e.mem[_nd_7 + 1] = rfc_seal(e, _v_48);
    e.mem[_nd_7 + 2] = rfc_seal(e, _v_49);
    e.mem[_nd_7 + 3] = rfc_seal(e, _v_50);
    e.mem[_nd_7 + 4] = rfc_seal(e, _v_51);
    e.mem[_nd_7 + 5] = rfc_seal(e, _v_52);
    r0 = term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_7);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_RESOURCE_REPLACE_JOIN_0_C14)
  {
    u32 _replaced_2 = r0;
    Term _x_3 = r1;
    WL_OPEN
    Term _v_77 = 0;
    Term _o_8[1];
    if (spin_14(e, _o_8, _x_3, blk_loc(e.mem, _x_3), _replaced_2) == 0) {
      return 0;
    }
    _v_77 = _o_8[0];
    r0 = _v_77;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K15)
  {
    WL_POPN(1);
    u32 _value_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K16;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K16, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K16, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _value_2;
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _h_0;
    r1 = _value_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0_K16)
  {
    Term _r_0 = r0;
    WL_OPEN
    Term _fb_4[6];
    u64 _sp_4 = ctr_take(e, _r_0, 6, _fb_4);
    Term _f_48 = _fb_4[0];
    Term _f_49 = _fb_4[1];
    Term _f_50 = _fb_4[2];
    Term _f_51 = _fb_4[3];
    u32 _f_52 = _fb_4[4];
    Term _f_53 = _fb_4[5];
    spare_free(e, cls_fit(6), _sp_4);
    r0 = _f_48;
    r1 = _f_49;
    r2 = _f_50;
    r3 = _f_51;
    r4 = _f_52;
    r5 = _f_53;
    WL_RETN(6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0)
  {
    Term _undo_0 = r0;
    Term _world_0 = r1;
    WL_OPEN
    if (term_aux(_undo_0) == CID_NIL) {
      r0 = _world_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _undo_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_1;
        STK(1) = FID__________SRC_ECS_TRANSACTION_ROLLBACK_0_K18;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_TRANSACTION_ROLLBACK_0_K18, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_1;
        WL_CONT = term_tsk(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0_K18, _t_0);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_0;
        e.mem[_t_1 + 1] = _world_0;
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _f_0;
      r1 = _world_0;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0_K18)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_TRANSACTION_ROLLBACK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_2;
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0, _t_2);
    }
    r0 = _f_2;
    r1 = _h_0;
    WL_JMP(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0)
  {
    Term _ctx_0 = r0;
    Term _ctx_1 = r1;
    Term _ctx_2 = r2;
    Term _ctx_3 = r3;
    u32 _ctx_4 = r4;
    Term _ctx_5 = r5;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _o_2[2];
    Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 8);
    Term _a_1 = term_clo(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C22, 0);
    Term _a_2 = term_clo(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C23, 0);
    if (spin_16(e, _o_2, _a_0, blk_loc(e.mem, _a_0), 1, _a_1, blk_loc(e.mem, _a_1), _a_2, blk_loc(e.mem, _a_2)) == 0) {
      return 0;
    }
    _v_16 = _o_2[0];
    _v_17 = _o_2[1];
    _v_1 = _v_16;
    _v_2 = _v_17;
    Term _v_18 = 0;
    Term _o_3[1];
    if (spin_20(e, _o_3, _v_1, blk_loc(e.mem, _v_1), _v_2, blk_loc(e.mem, _v_2)) == 0) {
      return 0;
    }
    _v_18 = _o_3[0];
    _v_0 = _v_18;
    u64 _nd_4 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_4 + 0] = rfc_seal(e, _ctx_0);
    e.mem[_nd_4 + 1] = rfc_seal(e, _ctx_1);
    e.mem[_nd_4 + 2] = rfc_seal(e, _ctx_2);
    e.mem[_nd_4 + 3] = rfc_seal(e, _ctx_3);
    e.mem[_nd_4 + 4] = rfc_seal(e, _ctx_4);
    e.mem[_nd_4 + 5] = rfc_seal(e, _ctx_5);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_K25;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_K25, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_K25, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      e.mem[_t_1 + 1] = term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_4);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _v_0;
    r1 = term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_4);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C22)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[6];
    u64 _sp_0 = ctr_take(e, _x_0, 6, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    spare_free(e, cls_fit(6), _sp_0);
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _o_0[7];
    if (spin_6(e, _o_0, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1), _f_2, blk_loc(e.mem, _f_2), _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, blk_loc(e.mem, _f_5)) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_4 = _o_0[1];
    _v_5 = _o_0[2];
    _v_6 = _o_0[3];
    _v_7 = _o_0[4];
    _v_8 = _o_0[5];
    _v_9 = _o_0[6];
    u64 _nd_0 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_3);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_4);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_5);
    e.mem[_nd_0 + 3] = rfc_seal(e, _v_6);
    e.mem[_nd_0 + 4] = rfc_seal(e, _v_7);
    e.mem[_nd_0 + 5] = rfc_seal(e, _v_8);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_9);
    r0 = term_ctr(CID_TUPLE, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C23)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_1[6];
    u64 _sp_1 = ctr_take(e, _x_1, 6, _fb_1);
    Term _f_6 = _fb_1[0];
    Term _f_7 = _fb_1[1];
    Term _f_8 = _fb_1[2];
    Term _f_9 = _fb_1[3];
    u32 _f_10 = _fb_1[4];
    Term _f_11 = _fb_1[5];
    spare_free(e, cls_fit(6), _sp_1);
    u64 _nd_2 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_2 + 0] = _f_6;
    e.mem[_nd_2 + 1] = _f_7;
    e.mem[_nd_2 + 2] = _f_8;
    e.mem[_nd_2 + 3] = _f_9;
    e.mem[_nd_2 + 4] = _f_10;
    e.mem[_nd_2 + 5] = _f_11;
    r0 = term_clo(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C24, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_C24)
  {
    Term _f_12 = r0;
    Term _f_13 = r1;
    Term _f_14 = r2;
    Term _f_15 = r3;
    u32 _f_16 = r4;
    Term _f_17 = r5;
    Term _x_2 = r6;
    WL_OPEN
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    Term _v_15 = 0;
    Term _o_1[6];
    if (spin_11(e, _o_1, _f_12, blk_loc(e.mem, _f_12), _f_13, blk_loc(e.mem, _f_13), _f_14, blk_loc(e.mem, _f_14), _f_15, blk_loc(e.mem, _f_15), _f_16, _f_17, blk_loc(e.mem, _f_17), _x_2) == 0) {
      return 0;
    }
    _v_10 = _o_1[0];
    _v_11 = _o_1[1];
    _v_12 = _o_1[2];
    _v_13 = _o_1[3];
    _v_14 = _o_1[4];
    _v_15 = _o_1[5];
    u64 _nd_3 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_3 + 0] = rfc_seal(e, _v_10);
    e.mem[_nd_3 + 1] = rfc_seal(e, _v_11);
    e.mem[_nd_3 + 2] = rfc_seal(e, _v_12);
    e.mem[_nd_3 + 3] = rfc_seal(e, _v_13);
    e.mem[_nd_3 + 4] = rfc_seal(e, _v_14);
    e.mem[_nd_3 + 5] = rfc_seal(e, _v_15);
    r0 = term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0_K25)
  {
    Term _r_0 = r0;
    WL_OPEN
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _r_0, 2, _fb_2);
    Term _f_18 = _fb_2[0];
    Term _f_19 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    Term _fb_3[6];
    u64 _sp_3 = ctr_take(e, _f_18, 6, _fb_3);
    Term _f_20 = _fb_3[0];
    Term _f_21 = _fb_3[1];
    Term _f_22 = _fb_3[2];
    Term _f_23 = _fb_3[3];
    u32 _f_24 = _fb_3[4];
    Term _f_25 = _fb_3[5];
    spare_free(e, cls_fit(6), _sp_3);
    r0 = _f_20;
    r1 = _f_21;
    r2 = _f_22;
    r3 = _f_23;
    r4 = _f_24;
    r5 = _f_25;
    r6 = _f_19;
    WL_RETN(7);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_COMMANDS_TX_FINISH_0)
  {
    Term _tx_0 = r0;
    Term _tx_1 = r1;
    Term _tx_2 = r2;
    Term _tx_3 = r3;
    u32 _tx_4 = r4;
    Term _tx_5 = r5;
    u32 _outcome_0 = r6;
    WL_OPEN
    term_sink(e, _tx_5);
    if (_outcome_0 == 0) {
      term_sink(e, _tx_1);
      Term _v_0 = 0;
      Term _v_1 = 0;
      Term _v_2 = 0;
      Term _o_0[1];
      if (spin_22(e, _o_0, _tx_2, blk_loc(e.mem, _tx_2)) == 0) {
        return 0;
      }
      _v_2 = _o_0[0];
      _v_1 = _v_2;
      Term _v_3 = 0;
      Term _o_1[1];
      if (spin_24(e, _o_1, _tx_0, blk_loc(e.mem, _tx_0), _v_1, blk_loc(e.mem, _v_1)) == 0) {
        return 0;
      }
      _v_3 = _o_1[0];
      _v_0 = _v_3;
      Term _v_4 = 0;
      Term _v_5 = 0;
      Term _v_6 = 0;
      Term _o_2[1];
      if (spin_0(e, _o_2, _tx_3, blk_loc(e.mem, _tx_3)) == 0) {
        return 0;
      }
      _v_6 = _o_2[0];
      _v_5 = _v_6;
      Term _v_7 = 0;
      Term _o_3[1];
      if (spin_25(e, _o_3, _v_0, blk_loc(e.mem, _v_0), _v_5, blk_loc(e.mem, _v_5)) == 0) {
        return 0;
      }
      _v_7 = _o_3[0];
      _v_4 = _v_7;
      r0 = _v_4;
      r1 = 0;
      WL_RETN(2);
    } else {
      term_sink(e, _tx_2);
      term_sink(e, _tx_3);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID__________SRC_ECS_COMMANDS_TX_FINISH_0_K39;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_COMMANDS_TX_FINISH_0_K39, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID__________SRC_ECS_COMMANDS_TX_FINISH_0_K39, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_TRANSACTION_ROLLBACK_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _tx_1;
        e.mem[_t_1 + 1] = _tx_0;
        return term_tsk(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0, _t_1);
      }
      r0 = _tx_1;
      r1 = _tx_0;
      WL_JMP(FID__________SRC_ECS_TRANSACTION_ROLLBACK_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_COMMANDS_TX_FINISH_0_K39)
  {
    Term _h_0 = r0;
    WL_OPEN
    r0 = _h_0;
    r1 = 1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_BODY_0)
  {
    Term _local_0 = r0;
    Term _owner_0 = r1;
    Term _owner_1 = r2;
    Term _owner_2 = r3;
    Term _owner_3 = r4;
    u32 _owner_4 = r5;
    Term _owner_5 = r6;
    WL_OPEN
    Term _at_0 = blk_loc(e.mem, _local_0);
    Term _at_1 = blk_at(_local_0, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _at_2 = blk_loc(e.mem, _local_0);
    Term _at_3 = blk_at(_local_0, 0ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    blk_write(e.mem, 0, _at_2, _at_3 + 0, U32_BIN(_c_0, +, 1ull));
    Term _at_4 = blk_loc(e.mem, _local_0);
    Term _at_5 = blk_at(_local_0, 1ull, 0);
    u32 _c_2 = blk_read(e.mem, 0, _at_4, _at_5 + 0);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _local_0;
      STK(1) = _c_2;
      STK(2) = FID_LOCAL_FIXTURE_BODY_0_K43;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_LOCAL_FIXTURE_BODY_0_K43, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _local_0;
      e.mem[_t_0 + 1] = _c_2;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_BODY_0_K43, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owner_0;
      e.mem[_t_1 + 1] = _owner_1;
      e.mem[_t_1 + 2] = _owner_2;
      e.mem[_t_1 + 3] = _owner_3;
      e.mem[_t_1 + 4] = _owner_4;
      e.mem[_t_1 + 5] = _owner_5;
      return term_tsk(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0, _t_1);
    }
    r0 = _owner_0;
    r1 = _owner_1;
    r2 = _owner_2;
    r3 = _owner_3;
    r4 = _owner_4;
    r5 = _owner_5;
    WL_JMP(FID__________SRC_ECS_CAPABILITIES_VALUE_GET_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_BODY_0_K43)
  {
    WL_POPN(2);
    Term _local_1 = STK(0);
    u32 _c_3 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    u32 _h_6 = r6;
    WL_OPEN
    Term _at_6 = blk_loc(e.mem, _local_1);
    Term _at_7 = blk_at(_local_1, 1ull, 0);
    u32 _c_4 = blk_read(e.mem, 0, _at_6, _at_7 + 0);
    blk_write(e.mem, 0, _at_6, _at_7 + 0, 0ull);
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_26(e, _o_0, U32_BIN(_c_3, ==, 0ull)) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(3);
      STK(0) = _local_1;
      STK(1) = _v_0;
      STK(2) = FID_LOCAL_FIXTURE_BODY_0_K44;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_LOCAL_FIXTURE_BODY_0_K44, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _local_1;
      e.mem[_t_2 + 1] = _v_0;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_BODY_0_K44, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = U32_BIN(_h_6, +, 10ull);
      return term_tsk(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = U32_BIN(_h_6, +, 10ull);
    WL_JMP(FID__________SRC_ECS_CAPABILITIES_VALUE_SET_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_BODY_0_K44)
  {
    WL_POPN(2);
    Term _local_2 = STK(0);
    u32 _v_2 = STK(1);
    Term _h_7 = r0;
    Term _h_8 = r1;
    Term _h_9 = r2;
    Term _h_10 = r3;
    u32 _h_11 = r4;
    Term _h_12 = r5;
    WL_OPEN
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    Term _o_1[1];
    if (spin_21(e, _o_1, _v_2) == 0) {
      return 0;
    }
    _v_4 = _o_1[0];
    _v_3 = _v_4;
    Term _fv_0[1];
    _fv_0[0] = 99ull;
    r0 = _h_7;
    r1 = _h_8;
    r2 = _h_9;
    r3 = _h_10;
    r4 = _h_11;
    r5 = _h_12;
    r6 = _local_2;
    r7 = _v_3;
    r8 = blk_new(e, 0, 0, 0, 1, _fv_0);
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0)
  {
    Term _world_0 = r0;
    Term _local_0 = r1;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _o_0[6];
    if (spin_28(e, _o_0, _world_0, blk_loc(e.mem, _world_0)) == 0) {
      return 0;
    }
    _v_6 = _o_0[0];
    _v_7 = _o_0[1];
    _v_8 = _o_0[2];
    _v_9 = _o_0[3];
    _v_10 = _o_0[4];
    _v_11 = _o_0[5];
    _v_0 = _v_6;
    _v_1 = _v_7;
    _v_2 = _v_8;
    _v_3 = _v_9;
    _v_4 = _v_10;
    _v_5 = _v_11;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K48;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K48, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K48, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOCAL_FIXTURE_BODY_0)) {
      u64 _t_1 = task_node(e, FID_LOCAL_FIXTURE_BODY_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _local_0;
      e.mem[_t_1 + 1] = _v_0;
      e.mem[_t_1 + 2] = _v_1;
      e.mem[_t_1 + 3] = _v_2;
      e.mem[_t_1 + 4] = _v_3;
      e.mem[_t_1 + 5] = _v_4;
      e.mem[_t_1 + 6] = _v_5;
      return term_tsk(FID_LOCAL_FIXTURE_BODY_0, _t_1);
    }
    r0 = _local_0;
    r1 = _v_0;
    r2 = _v_1;
    r3 = _v_2;
    r4 = _v_3;
    r5 = _v_4;
    r6 = _v_5;
    WL_JMP(FID_LOCAL_FIXTURE_BODY_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K48)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_6;
      STK(1) = _h_8;
      STK(2) = FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K49;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K49, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _h_6;
      e.mem[_t_2 + 1] = _h_8;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K49, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_COMMANDS_TX_FINISH_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_COMMANDS_TX_FINISH_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = _h_1;
      e.mem[_t_3 + 2] = _h_2;
      e.mem[_t_3 + 3] = _h_3;
      e.mem[_t_3 + 4] = _h_4;
      e.mem[_t_3 + 5] = _h_5;
      e.mem[_t_3 + 6] = _h_7;
      return term_tsk(FID__________SRC_ECS_COMMANDS_TX_FINISH_0, _t_3);
    }
    r0 = _h_0;
    r1 = _h_1;
    r2 = _h_2;
    r3 = _h_3;
    r4 = _h_4;
    r5 = _h_5;
    r6 = _h_7;
    WL_JMP(FID__________SRC_ECS_COMMANDS_TX_FINISH_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0_K49)
  {
    WL_POPN(2);
    Term _h_11 = STK(0);
    Term _h_12 = STK(1);
    Term _h_9 = r0;
    u32 _h_10 = r1;
    WL_OPEN
    u32 _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    Term _v_21 = 0;
    Term _o_1[4];
    if (spin_27(e, _o_1, _h_11, blk_loc(e.mem, _h_11), _h_12, blk_loc(e.mem, _h_12), _h_9, blk_loc(e.mem, _h_9), _h_10) == 0) {
      return 0;
    }
    _v_18 = _o_1[0];
    _v_19 = _o_1[1];
    _v_20 = _o_1[2];
    _v_21 = _o_1[3];
    r0 = _v_18;
    r1 = _v_19;
    r2 = _v_20;
    r3 = _v_21;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    Term _value_2 = r2;
    Term _value_3 = r3;
    Term _value_4 = r4;
    Term _world_0 = r5;
    WL_OPEN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _world_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    Term _f_12 = _fb_0[12];
    u32 _f_13 = _fb_0[13];
    u32 _f_14 = _fb_0[14];
    spare_free(e, cls_fit(15), _sp_0);
    if (seq) {
      WL_ROOM(20);
      STK(0) = _value_0;
      STK(1) = _value_1;
      STK(2) = _value_2;
      STK(3) = _value_3;
      STK(4) = _value_4;
      STK(5) = _f_0;
      STK(6) = _f_1;
      STK(7) = _f_2;
      STK(8) = _f_3;
      STK(9) = _f_4;
      STK(10) = _f_5;
      STK(11) = _f_6;
      STK(12) = _f_7;
      STK(13) = _f_9;
      STK(14) = _f_10;
      STK(15) = _f_11;
      STK(16) = _f_12;
      STK(17) = _f_13;
      STK(18) = _f_14;
      STK(19) = FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K57;
      WL_PUSHN(20);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K57, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _value_0;
      e.mem[_t_0 + 1] = _value_1;
      e.mem[_t_0 + 2] = _value_2;
      e.mem[_t_0 + 3] = _value_3;
      e.mem[_t_0 + 4] = _value_4;
      e.mem[_t_0 + 5] = _f_0;
      e.mem[_t_0 + 6] = _f_1;
      e.mem[_t_0 + 7] = _f_2;
      e.mem[_t_0 + 8] = _f_3;
      e.mem[_t_0 + 9] = _f_4;
      e.mem[_t_0 + 10] = _f_5;
      e.mem[_t_0 + 11] = _f_6;
      e.mem[_t_0 + 12] = _f_7;
      e.mem[_t_0 + 13] = _f_9;
      e.mem[_t_0 + 14] = _f_10;
      e.mem[_t_0 + 15] = _f_11;
      e.mem[_t_0 + 16] = _f_12;
      e.mem[_t_0 + 17] = _f_13;
      e.mem[_t_0 + 18] = _f_14;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K57, _t_0);
      WL_IDX = 19;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_12;
      e.mem[_t_1 + 1] = _value_1;
      e.mem[_t_1 + 2] = _value_2;
      e.mem[_t_1 + 3] = _value_3;
      return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, _t_1);
    }
    r0 = _f_12;
    r1 = _value_1;
    r2 = _value_2;
    r3 = _value_3;
    WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K57)
  {
    WL_POPN(19);
    u32 _value_5 = STK(0);
    u32 _value_6 = STK(1);
    Term _value_7 = STK(2);
    Term _value_8 = STK(3);
    Term _value_9 = STK(4);
    u32 _f_15 = STK(5);
    u32 _f_16 = STK(6);
    u32 _f_17 = STK(7);
    Term _f_18 = STK(8);
    u32 _f_19 = STK(9);
    Term _f_20 = STK(10);
    Term _f_21 = STK(11);
    Term _f_22 = STK(12);
    u32 _f_23 = STK(13);
    Term _f_24 = STK(14);
    Term _f_25 = STK(15);
    Term _f_26 = STK(16);
    u32 _f_27 = STK(17);
    u32 _f_28 = STK(18);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_0[1];
    if (spin_30(e, _o_0, U32_BIN(_value_5, ==, _f_15), _h_0) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    u64 _nd_0 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_15);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_16);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_17);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_18);
    e.mem[_nd_0 + 4] = rfc_seal(e, _f_19);
    e.mem[_nd_0 + 5] = rfc_seal(e, _f_20);
    e.mem[_nd_0 + 6] = rfc_seal(e, _f_21);
    e.mem[_nd_0 + 7] = rfc_seal(e, _f_22);
    e.mem[_nd_0 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 9] = rfc_seal(e, _f_23);
    e.mem[_nd_0 + 10] = rfc_seal(e, _f_24);
    e.mem[_nd_0 + 11] = rfc_seal(e, _f_25);
    e.mem[_nd_0 + 12] = rfc_seal(e, _f_26);
    e.mem[_nd_0 + 13] = rfc_seal(e, _f_27);
    e.mem[_nd_0 + 14] = rfc_seal(e, _f_28);
    if (_v_0 == 0) {
      Term _world_1 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
      r0 = 1;
      r1 = _world_1;
      r2 = _value_5;
      r3 = _value_6;
      r4 = _value_7;
      r5 = _value_8;
      r6 = _value_9;
      r7 = 0;
      r8 = 0;
      WL_RETN(9);
    } else {
      Term _world_2 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
      if (seq) {
        WL_ROOM(5);
        STK(0) = _value_5;
        STK(1) = _value_6;
        STK(2) = _value_7;
        STK(3) = _value_8;
        STK(4) = FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K58;
        WL_PUSHN(5);
      } else {
        u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K58, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _value_5;
        e.mem[_t_2 + 1] = _value_6;
        e.mem[_t_2 + 2] = _value_7;
        e.mem[_t_2 + 3] = _value_8;
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K58, _t_2);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0)) {
        u64 _t_3 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _world_2;
        e.mem[_t_3 + 1] = _value_9;
        return term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0, _t_3);
      }
      r0 = _world_2;
      r1 = _value_9;
      WL_JMP(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUNNER_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0_K58)
  {
    WL_POPN(4);
    u32 _value_10 = STK(0);
    u32 _value_11 = STK(1);
    Term _value_12 = STK(2);
    Term _value_13 = STK(3);
    u32 _h_1 = r0;
    Term _h_2 = r1;
    Term _h_3 = r2;
    Term _h_4 = r3;
    WL_OPEN
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _o_1[9];
    if (spin_29(e, _o_1, _value_10, _value_11, _value_12, blk_loc(e.mem, _value_12), _value_13, blk_loc(e.mem, _value_13), _h_1, _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4)) == 0) {
      return 0;
    }
    _v_2 = _o_1[0];
    _v_3 = _o_1[1];
    _v_4 = _o_1[2];
    _v_5 = _o_1[3];
    _v_6 = _o_1[4];
    _v_7 = _o_1[5];
    _v_8 = _o_1[6];
    _v_9 = _o_1[7];
    _v_10 = _o_1[8];
    r0 = _v_2;
    r1 = _v_3;
    r2 = _v_4;
    r3 = _v_5;
    r4 = _v_6;
    r5 = _v_7;
    r6 = _v_8;
    r7 = _v_9;
    r8 = _v_10;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER)
  {
    Term _items_0 = r0;
    u32 _wanted_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_items_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[4];
      u64 _sp_1 = ctr_take(e, _f_0, 4, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      spare_free(e, cls_fit(4), _sp_1);
      term_sink(e, _f_4);
      term_sink(e, _f_5);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_3;
        STK(1) = _wanted_0;
        STK(2) = FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER_K68;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER_K68, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_3;
        e.mem[_t_0 + 1] = _wanted_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER_K68, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _wanted_0;
      _items_0 = r0;
      _wanted_0 = r1;
      WL_AGAIN(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER_K68)
  {
    WL_POPN(2);
    u32 _f_6 = STK(0);
    u32 _wanted_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = ((U32_BIN(_f_6, ==, _wanted_1)) | (_h_0));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0)
  {
    u32 _value_0 = r0;
    u32 _value_1 = r1;
    Term _value_2 = r2;
    Term _value_3 = r3;
    Term _value_4 = r4;
    Term _context_0 = r5;
    u32 _context_1 = r6;
    Term _context_2 = r7;
    u32 _id_0 = r8;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    u32 _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    u32 _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    Term _v_17 = 0;
    Term _v_18 = 0;
    u32 _v_19 = 0;
    u32 _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    Term _o_5[14];
    if (spin_33(e, _o_5, _value_0, _value_1, _value_2, blk_loc(e.mem, _value_2), _value_3, blk_loc(e.mem, _value_3), _value_4, blk_loc(e.mem, _value_4)) == 0) {
      return 0;
    }
    _v_14 = _o_5[0];
    _v_15 = _o_5[1];
    _v_16 = _o_5[2];
    _v_17 = _o_5[3];
    _v_18 = _o_5[4];
    _v_19 = _o_5[5];
    _v_20 = _o_5[6];
    _v_21 = _o_5[7];
    _v_22 = _o_5[8];
    _v_23 = _o_5[9];
    _v_24 = _o_5[10];
    _v_25 = _o_5[11];
    _v_26 = _o_5[12];
    _v_27 = _o_5[13];
    _v_0 = _v_14;
    _v_1 = _v_15;
    _v_2 = _v_16;
    _v_3 = _v_17;
    _v_4 = _v_18;
    _v_5 = _v_19;
    _v_6 = _v_20;
    _v_7 = _v_21;
    _v_8 = _v_22;
    _v_9 = _v_23;
    _v_10 = _v_24;
    _v_11 = _v_25;
    _v_12 = _v_26;
    _v_13 = _v_27;
    u32 _v_92 = 0;
    u32 _v_93 = 0;
    Term _o_6[1];
    if (spin_32(e, _o_6, _v_5, _v_6, _v_7, blk_loc(e.mem, _v_7), _v_8, blk_loc(e.mem, _v_8), _v_9, _v_10, blk_loc(e.mem, _v_10), _v_11, blk_loc(e.mem, _v_11), _v_12, _v_13, blk_loc(e.mem, _v_13)) == 0) {
      return 0;
    }
    _v_93 = _o_6[0];
    _v_92 = _v_93;
    u32 _s_0 = U32_BIN(_id_0, ==, _v_92);
    if (_s_0 == 0) {
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = 1;
      r6 = _context_0;
      r7 = _context_1;
      r8 = _context_2;
      r9 = 1;
      WL_RETN(10);
    } else {
      if (seq) {
        WL_ROOM(3);
        STK(0) = _context_1;
        STK(1) = _context_2;
        STK(2) = FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0_K73;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0_K73, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _context_1;
        e.mem[_t_0 + 1] = _context_2;
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0_K73, _t_0);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_0;
        e.mem[_t_1 + 1] = _v_1;
        e.mem[_t_1 + 2] = _v_2;
        e.mem[_t_1 + 3] = _v_3;
        e.mem[_t_1 + 4] = _v_4;
        e.mem[_t_1 + 5] = _context_0;
        return term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0, _t_1);
      }
      r0 = _v_0;
      r1 = _v_1;
      r2 = _v_2;
      r3 = _v_3;
      r4 = _v_4;
      r5 = _context_0;
      WL_JMP(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_RUN_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C70)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[6];
    u64 _sp_0 = ctr_take(e, _x_0, 6, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    spare_free(e, cls_fit(6), _sp_0);
    Term _v_44 = 0;
    Term _v_45 = 0;
    Term _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    u32 _v_50 = 0;
    Term _o_0[7];
    if (spin_6(e, _o_0, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1), _f_2, blk_loc(e.mem, _f_2), _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, blk_loc(e.mem, _f_5)) == 0) {
      return 0;
    }
    _v_44 = _o_0[0];
    _v_45 = _o_0[1];
    _v_46 = _o_0[2];
    _v_47 = _o_0[3];
    _v_48 = _o_0[4];
    _v_49 = _o_0[5];
    _v_50 = _o_0[6];
    u64 _nd_0 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_44);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_45);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_46);
    e.mem[_nd_0 + 3] = rfc_seal(e, _v_47);
    e.mem[_nd_0 + 4] = rfc_seal(e, _v_48);
    e.mem[_nd_0 + 5] = rfc_seal(e, _v_49);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_50);
    r0 = term_ctr(CID_TUPLE, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C71)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_1[6];
    u64 _sp_1 = ctr_take(e, _x_1, 6, _fb_1);
    Term _f_6 = _fb_1[0];
    Term _f_7 = _fb_1[1];
    Term _f_8 = _fb_1[2];
    Term _f_9 = _fb_1[3];
    u32 _f_10 = _fb_1[4];
    Term _f_11 = _fb_1[5];
    spare_free(e, cls_fit(6), _sp_1);
    u64 _nd_2 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_2 + 0] = _f_6;
    e.mem[_nd_2 + 1] = _f_7;
    e.mem[_nd_2 + 2] = _f_8;
    e.mem[_nd_2 + 3] = _f_9;
    e.mem[_nd_2 + 4] = _f_10;
    e.mem[_nd_2 + 5] = _f_11;
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C72, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_FIELDS_0_C72)
  {
    Term _f_12 = r0;
    Term _f_13 = r1;
    Term _f_14 = r2;
    Term _f_15 = r3;
    u32 _f_16 = r4;
    Term _f_17 = r5;
    Term _x_2 = r6;
    WL_OPEN
    Term _v_51 = 0;
    Term _v_52 = 0;
    Term _v_53 = 0;
    Term _v_54 = 0;
    u32 _v_55 = 0;
    Term _v_56 = 0;
    Term _o_1[6];
    if (spin_11(e, _o_1, _f_12, blk_loc(e.mem, _f_12), _f_13, blk_loc(e.mem, _f_13), _f_14, blk_loc(e.mem, _f_14), _f_15, blk_loc(e.mem, _f_15), _f_16, _f_17, blk_loc(e.mem, _f_17), _x_2) == 0) {
      return 0;
    }
    _v_51 = _o_1[0];
    _v_52 = _o_1[1];
    _v_53 = _o_1[2];
    _v_54 = _o_1[3];
    _v_55 = _o_1[4];
    _v_56 = _o_1[5];
    u64 _nd_3 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_3 + 0] = rfc_seal(e, _v_51);
    e.mem[_nd_3 + 1] = rfc_seal(e, _v_52);
    e.mem[_nd_3 + 2] = rfc_seal(e, _v_53);
    e.mem[_nd_3 + 3] = rfc_seal(e, _v_54);
    e.mem[_nd_3 + 4] = rfc_seal(e, _v_55);
    e.mem[_nd_3 + 5] = rfc_seal(e, _v_56);
    r0 = term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0_K73)
  {
    WL_POPN(2);
    u32 _context_3 = STK(0);
    Term _context_4 = STK(1);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    WL_OPEN
    u32 _v_94 = 0;
    u32 _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    Term _v_98 = 0;
    u32 _v_99 = 0;
    Term _v_100 = 0;
    u32 _v_101 = 0;
    Term _v_102 = 0;
    u32 _v_103 = 0;
    Term _o_7[10];
    if (spin_31(e, _o_7, _context_3, _context_4, blk_loc(e.mem, _context_4), _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, _h_3, _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8, blk_loc(e.mem, _h_8)) == 0) {
      return 0;
    }
    _v_94 = _o_7[0];
    _v_95 = _o_7[1];
    _v_96 = _o_7[2];
    _v_97 = _o_7[3];
    _v_98 = _o_7[4];
    _v_99 = _o_7[5];
    _v_100 = _o_7[6];
    _v_101 = _o_7[7];
    _v_102 = _o_7[8];
    _v_103 = _o_7[9];
    r0 = _v_94;
    r1 = _v_95;
    r2 = _v_96;
    r3 = _v_97;
    r4 = _v_98;
    r5 = _v_99;
    r6 = _v_100;
    r7 = _v_101;
    r8 = _v_102;
    r9 = _v_103;
    WL_RETN(10);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0)
  {
    Term _fields_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _id_0;
      STK(1) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0_K78;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0_K78, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _id_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0_K78, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _fields_0;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0, _t_1);
    }
    r0 = _fields_0;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0_K78)
  {
    WL_POPN(1);
    u32 _id_1 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _id_1;
      return term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER, _t_2);
    }
    r0 = _h_0;
    r1 = _id_1;
    WL_JMP(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_MEMBER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME)
  {
    Term _items_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    if (term_aux(_items_0) == CID_NIL) {
      r0 = 0;
      r1 = 0;
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[4];
      u64 _sp_1 = ctr_take(e, _f_0, 4, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      u32 _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      spare_free(e, cls_fit(4), _sp_1);
      u64 _nd_0 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_0 + 0] = _f_1;
      e.mem[_nd_0 + 1] = _id_0;
      u32 _s_0 = U32_BIN(_f_3, ==, _id_0);
      if (_s_0 == 1) {
        Term _next_0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_C92, _nd_0);
        term_sink(e, _next_0);
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _f_4;
        r1 = _f_5;
        WL_RETN(2);
      } else {
        term_sink(e, _f_5);
        Term _next_1 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_C92, _nd_0);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(1);
          STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K94;
          WL_PUSHN(1);
        } else {
          u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K94, WL_CONT, WL_IDX, 1);
          WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K94, _t_2);
          WL_IDX = 0;
        }
        if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
          u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _next_1;
          e.mem[_t_3 + 1] = term_pak(CID_UNIT, 0);
          return term_tsk(FID_CLO_APPLY, _t_3);
        }
        r0 = _next_1;
        r1 = term_pak(CID_UNIT, 0);
        WL_JMP(FID_CLO_APPLY);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_C92)
  {
    Term _f_6 = r0;
    u32 _id_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K93;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K93, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K93, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_6;
      e.mem[_t_1 + 1] = _id_1;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME, _t_1);
    }
    r0 = _f_6;
    r1 = _id_1;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K93)
  {
    u32 _r_0 = r0;
    Term _r_1 = r1;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      _b_0 = term_pak(CID_NONE, 0);
    } else {
      u64 _nd_1 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_1 + 0] = rfc_seal(e, _r_1);
      _b_0 = term_ctr(CID_SOME, _nd_1);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME_K94)
  {
    Term _r_2 = r0;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    if (term_aux(_r_2) == CID_NONE) {
      _o_0 = 0;
    } else {
      _o_0 = 1;
      Term _fb_2[1];
      u64 _sp_2 = ctr_take(e, _r_2, 1, _fb_2);
      Term _f_7 = _fb_2[0];
      spare_free(e, cls_fit(1), _sp_2);
      _o_1 = _f_7;
    }
    r0 = _o_0;
    r1 = _o_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0)
  {
    Term _journal_0 = r0;
    Term _journal_1 = r1;
    Term _world_0 = r2;
    u32 _id_0 = r3;
    WL_OPEN
    term_sink(e, _journal_1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _world_0;
      STK(1) = _id_0;
      STK(2) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0_K101;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0_K101, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _world_0;
      e.mem[_t_0 + 1] = _id_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0_K101, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _journal_0;
      e.mem[_t_1 + 1] = _id_0;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME, _t_1);
    }
    r0 = _journal_0;
    r1 = _id_0;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_REGISTRATION_NAME);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0_K101)
  {
    WL_POPN(2);
    Term _world_1 = STK(0);
    u32 _id_1 = STK(1);
    u32 _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    u32 _v_3 = 0;
    Term _o_0[2];
    if (spin_52(e, _o_0, _world_1, blk_loc(e.mem, _world_1)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    u32 _v_11 = 0;
    Term _o_3[6];
    if (spin_53(e, _o_3, _id_1, _h_0, _h_1, blk_loc(e.mem, _h_1), _v_0, blk_loc(e.mem, _v_0), _v_1) == 0) {
      return 0;
    }
    _v_6 = _o_3[0];
    _v_7 = _o_3[1];
    _v_8 = _o_3[2];
    _v_9 = _o_3[3];
    _v_10 = _o_3[4];
    _v_11 = _o_3[5];
    r0 = _v_6;
    r1 = _v_7;
    r2 = _v_8;
    r3 = _v_9;
    r4 = _v_10;
    r5 = _v_11;
    WL_RETN(6);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0)
  {
    u32 _owners_0 = r0;
    u32 _owners_1 = r1;
    Term _owners_2 = r2;
    Term _owners_3 = r3;
    Term _owners_4 = r4;
    Term _owners_5 = r5;
    Term _owners_6 = r6;
    Term _world_0 = r7;
    u32 _id_0 = r8;
    WL_OPEN
    _owners_5 = term_keep(e, _owners_5, 1);
    _owners_6 = term_keep(e, _owners_6, 1);
    if (seq) {
      WL_ROOM(9);
      STK(0) = _owners_0;
      STK(1) = _owners_1;
      STK(2) = _owners_2;
      STK(3) = _owners_3;
      STK(4) = _owners_4;
      STK(5) = _owners_5;
      STK(6) = _owners_6;
      STK(7) = _id_0;
      STK(8) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K144;
      WL_PUSHN(9);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K144, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owners_0;
      e.mem[_t_0 + 1] = _owners_1;
      e.mem[_t_0 + 2] = _owners_2;
      e.mem[_t_0 + 3] = _owners_3;
      e.mem[_t_0 + 4] = _owners_4;
      e.mem[_t_0 + 5] = _owners_5;
      e.mem[_t_0 + 6] = _owners_6;
      e.mem[_t_0 + 7] = _id_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K144, _t_0);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _owners_5;
      e.mem[_t_1 + 1] = _owners_6;
      e.mem[_t_1 + 2] = _world_0;
      e.mem[_t_1 + 3] = _id_0;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0, _t_1);
    }
    r0 = _owners_5;
    r1 = _owners_6;
    r2 = _world_0;
    r3 = _id_0;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_IDENTITY_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K144)
  {
    WL_POPN(8);
    u32 _owners_7 = STK(0);
    u32 _owners_8 = STK(1);
    Term _owners_9 = STK(2);
    Term _owners_10 = STK(3);
    Term _owners_11 = STK(4);
    Term _owners_12 = STK(5);
    Term _owners_13 = STK(6);
    u32 _id_1 = STK(7);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    WL_OPEN
    u64 _nd_22 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_22 + 0] = rfc_seal(e, _owners_7);
    e.mem[_nd_22 + 1] = rfc_seal(e, _owners_8);
    e.mem[_nd_22 + 2] = rfc_seal(e, _owners_9);
    e.mem[_nd_22 + 3] = rfc_seal(e, _owners_10);
    e.mem[_nd_22 + 4] = rfc_seal(e, _owners_11);
    e.mem[_nd_22 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_23 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_23 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_23 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_22));
    if (seq) {
      WL_ROOM(10);
      STK(0) = _owners_12;
      STK(1) = _owners_13;
      STK(2) = _id_1;
      STK(3) = _h_0;
      STK(4) = _h_1;
      STK(5) = _h_2;
      STK(6) = _h_3;
      STK(7) = _h_4;
      STK(8) = _h_5;
      STK(9) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K150;
      WL_PUSHN(10);
    } else {
      u64 _t_6 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K150, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _owners_12;
      e.mem[_t_6 + 1] = _owners_13;
      e.mem[_t_6 + 2] = _id_1;
      e.mem[_t_6 + 3] = _h_0;
      e.mem[_t_6 + 4] = _h_1;
      e.mem[_t_6 + 5] = _h_2;
      e.mem[_t_6 + 6] = _h_3;
      e.mem[_t_6 + 7] = _h_4;
      e.mem[_t_6 + 8] = _h_5;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K150, _t_6);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_7 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C145, 0);
      e.mem[_t_7 + 1] = term_ctr(CID_TUPLE, _nd_23);
      return term_tsk(FID_CLO_APPLY, _t_7);
    }
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C145, 0);
    r1 = term_ctr(CID_TUPLE, _nd_23);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C145)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _x_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[6];
    u64 _sp_1 = ctr_take(e, _f_1, 6, _fb_1);
    u32 _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    Term _f_5 = _fb_1[3];
    Term _f_6 = _fb_1[4];
    Term _f_7 = _fb_1[5];
    spare_free(e, cls_fit(6), _sp_1);
    u64 _nd_0 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_0 + 0] = _f_2;
    e.mem[_nd_0 + 1] = _f_3;
    e.mem[_nd_0 + 2] = _f_4;
    e.mem[_nd_0 + 3] = _f_5;
    e.mem[_nd_0 + 4] = _f_6;
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C146, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C146)
  {
    u32 _f_8 = r0;
    u32 _f_9 = r1;
    Term _f_10 = r2;
    Term _f_11 = r3;
    Term _f_12 = r4;
    Term _x_1 = r5;
    WL_OPEN
    Term _fb_2[3];
    u64 _sp_2 = ctr_take(e, _x_1, 3, _fb_2);
    Term _f_13 = _fb_2[0];
    u32 _f_14 = _fb_2[1];
    Term _f_15 = _fb_2[2];
    spare_free(e, cls_fit(3), _sp_2);
    u64 _nd_1 = heap_alloc(e, cls_fit(8));
    e.mem[_nd_1 + 0] = _f_8;
    e.mem[_nd_1 + 1] = _f_9;
    e.mem[_nd_1 + 2] = _f_10;
    e.mem[_nd_1 + 3] = _f_11;
    e.mem[_nd_1 + 4] = _f_12;
    e.mem[_nd_1 + 5] = _f_13;
    e.mem[_nd_1 + 6] = _f_14;
    e.mem[_nd_1 + 7] = _f_15;
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C147, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_C147)
  {
    u32 _f_16 = r0;
    u32 _f_17 = r1;
    Term _f_18 = r2;
    Term _f_19 = r3;
    Term _f_20 = r4;
    Term _f_21 = r5;
    u32 _f_22 = r6;
    Term _f_23 = r7;
    Term _x_2 = r8;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_51(e, _o_0) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(10);
      STK(0) = _f_16;
      STK(1) = _f_17;
      STK(2) = _f_18;
      STK(3) = _f_19;
      STK(4) = _f_20;
      STK(5) = _f_21;
      STK(6) = _f_22;
      STK(7) = _f_23;
      STK(8) = _x_2;
      STK(9) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K148;
      WL_PUSHN(10);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K148, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_16;
      e.mem[_t_2 + 1] = _f_17;
      e.mem[_t_2 + 2] = _f_18;
      e.mem[_t_2 + 3] = _f_19;
      e.mem[_t_2 + 4] = _f_20;
      e.mem[_t_2 + 5] = _f_21;
      e.mem[_t_2 + 6] = _f_22;
      e.mem[_t_2 + 7] = _f_23;
      e.mem[_t_2 + 8] = _x_2;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K148, _t_2);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _v_0;
      e.mem[_t_3 + 1] = _x_2;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0, _t_3);
    }
    r0 = _v_0;
    r1 = _x_2;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K148)
  {
    WL_POPN(9);
    u32 _f_24 = STK(0);
    u32 _f_25 = STK(1);
    Term _f_26 = STK(2);
    Term _f_27 = STK(3);
    Term _f_28 = STK(4);
    Term _f_29 = STK(5);
    u32 _f_30 = STK(6);
    Term _f_31 = STK(7);
    u32 _x_3 = STK(8);
    u32 _h_6 = r0;
    WL_OPEN
    if (_h_6 == 1) {
      u32 _v_2 = 0;
      Term _v_3 = 0;
      u32 _v_4 = 0;
      Term _v_5 = 0;
      u32 _v_6 = 0;
      Term _v_7 = 0;
      u32 _v_8 = 0;
      Term _v_9 = 0;
      Term _o_1[4];
      if (spin_39(e, _o_1, _f_29, blk_loc(e.mem, _f_29), _f_30, _f_31, blk_loc(e.mem, _f_31), _x_3) == 0) {
        return 0;
      }
      _v_6 = _o_1[0];
      _v_7 = _o_1[1];
      _v_8 = _o_1[2];
      _v_9 = _o_1[3];
      _v_2 = _v_6;
      _v_3 = _v_7;
      _v_4 = _v_8;
      _v_5 = _v_9;
      u32 _v_10 = 0;
      u32 _v_11 = 0;
      Term _v_12 = 0;
      Term _v_13 = 0;
      Term _v_14 = 0;
      u32 _v_15 = 0;
      Term _v_16 = 0;
      u32 _v_17 = 0;
      Term _v_18 = 0;
      u32 _v_19 = 0;
      u32 _v_20 = 0;
      Term _o_2[11];
      if (spin_40(e, _o_2, _f_24, _f_25, _f_26, blk_loc(e.mem, _f_26), _f_27, blk_loc(e.mem, _f_27), _f_28, blk_loc(e.mem, _f_28), _v_2, _v_3, blk_loc(e.mem, _v_3), _v_4, _v_5, blk_loc(e.mem, _v_5)) == 0) {
        return 0;
      }
      _v_10 = _o_2[0];
      _v_11 = _o_2[1];
      _v_12 = _o_2[2];
      _v_13 = _o_2[3];
      _v_14 = _o_2[4];
      _v_15 = _o_2[5];
      _v_16 = _o_2[6];
      _v_17 = _o_2[7];
      _v_18 = _o_2[8];
      _v_19 = _o_2[9];
      _v_20 = _o_2[10];
      u64 _nd_2 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_10);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_11);
      e.mem[_nd_2 + 2] = rfc_seal(e, _v_12);
      e.mem[_nd_2 + 3] = rfc_seal(e, _v_13);
      e.mem[_nd_2 + 4] = rfc_seal(e, _v_14);
      e.mem[_nd_2 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_2));
      Term _b_0 = 0;
      if (_v_15 == 0) {
        u64 _nd_4 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_4 + 0] = rfc_seal(e, _v_16);
        e.mem[_nd_4 + 1] = rfc_seal(e, _v_17);
        e.mem[_nd_4 + 2] = rfc_seal(e, _v_18);
        u64 _nd_5 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_4));
        e.mem[_nd_5 + 1] = rfc_seal(e, term_pak(CID_UNIT, 0));
        _b_0 = term_ctr(CID__________SRC_ECS_SYSTEM_SUCCEEDED, _nd_5);
      } else {
        u64 _nd_6 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_6 + 0] = rfc_seal(e, _v_16);
        e.mem[_nd_6 + 1] = rfc_seal(e, _v_17);
        e.mem[_nd_6 + 2] = rfc_seal(e, _v_18);
        Term _b_1 = 0;
        if (_v_19 == 0) {
          u64 _nd_7 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_7 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_7);
        } else {
          Term _b_2 = 0;
          if (_v_20 == 0) {
            u64 _nd_8 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_8 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
            _b_2 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_8);
          } else {
            _b_2 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
          }
          u64 _nd_9 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_9 + 0] = rfc_seal(e, _b_2);
          _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_9);
        }
        u64 _nd_10 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_10 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_6));
        e.mem[_nd_10 + 1] = rfc_seal(e, _b_1);
        _b_0 = term_ctr(CID__________SRC_ECS_SYSTEM_FAILED, _nd_10);
      }
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_3));
      e.mem[_nd_11 + 1] = rfc_seal(e, _b_0);
      r0 = term_ctr(CID_TUPLE, _nd_11);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K149;
        WL_PUSHN(1);
      } else {
        u64 _t_4 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K149, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K149, _t_4);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0)) {
        u64 _t_5 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_5 + 0] = _f_24;
        e.mem[_t_5 + 1] = _f_25;
        e.mem[_t_5 + 2] = _f_26;
        e.mem[_t_5 + 3] = _f_27;
        e.mem[_t_5 + 4] = _f_28;
        e.mem[_t_5 + 5] = _f_29;
        e.mem[_t_5 + 6] = _f_30;
        e.mem[_t_5 + 7] = _f_31;
        e.mem[_t_5 + 8] = _x_3;
        return term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0, _t_5);
      }
      r0 = _f_24;
      r1 = _f_25;
      r2 = _f_26;
      r3 = _f_27;
      r4 = _f_28;
      r5 = _f_29;
      r6 = _f_30;
      r7 = _f_31;
      r8 = _x_3;
      WL_JMP(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K149)
  {
    u32 _h_7 = r0;
    u32 _h_8 = r1;
    Term _h_9 = r2;
    Term _h_10 = r3;
    Term _h_11 = r4;
    u32 _h_12 = r5;
    Term _h_13 = r6;
    u32 _h_14 = r7;
    Term _h_15 = r8;
    u32 _h_16 = r9;
    WL_OPEN
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_3[11];
    if (spin_41(e, _o_3, _h_7, _h_8, _h_9, blk_loc(e.mem, _h_9), _h_10, blk_loc(e.mem, _h_10), _h_11, blk_loc(e.mem, _h_11), _h_12, _h_13, blk_loc(e.mem, _h_13), _h_14, _h_15, blk_loc(e.mem, _h_15), _h_16) == 0) {
      return 0;
    }
    _v_21 = _o_3[0];
    _v_22 = _o_3[1];
    _v_23 = _o_3[2];
    _v_24 = _o_3[3];
    _v_25 = _o_3[4];
    _v_26 = _o_3[5];
    _v_27 = _o_3[6];
    _v_28 = _o_3[7];
    _v_29 = _o_3[8];
    _v_30 = _o_3[9];
    _v_31 = _o_3[10];
    u64 _nd_12 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_12 + 0] = rfc_seal(e, _v_21);
    e.mem[_nd_12 + 1] = rfc_seal(e, _v_22);
    e.mem[_nd_12 + 2] = rfc_seal(e, _v_23);
    e.mem[_nd_12 + 3] = rfc_seal(e, _v_24);
    e.mem[_nd_12 + 4] = rfc_seal(e, _v_25);
    e.mem[_nd_12 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_13 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_12));
    Term _b_3 = 0;
    if (_v_26 == 0) {
      u64 _nd_14 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_14 + 0] = rfc_seal(e, _v_27);
      e.mem[_nd_14 + 1] = rfc_seal(e, _v_28);
      e.mem[_nd_14 + 2] = rfc_seal(e, _v_29);
      u64 _nd_15 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_15 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_14));
      e.mem[_nd_15 + 1] = rfc_seal(e, term_pak(CID_UNIT, 0));
      _b_3 = term_ctr(CID__________SRC_ECS_SYSTEM_SUCCEEDED, _nd_15);
    } else {
      u64 _nd_16 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_16 + 0] = rfc_seal(e, _v_27);
      e.mem[_nd_16 + 1] = rfc_seal(e, _v_28);
      e.mem[_nd_16 + 2] = rfc_seal(e, _v_29);
      Term _b_4 = 0;
      if (_v_30 == 0) {
        u64 _nd_17 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_17 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
        _b_4 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_17);
      } else {
        Term _b_5 = 0;
        if (_v_31 == 0) {
          u64 _nd_18 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_18 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
          _b_5 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_18);
        } else {
          _b_5 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
        }
        u64 _nd_19 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_19 + 0] = rfc_seal(e, _b_5);
        _b_4 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_19);
      }
      u64 _nd_20 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_20 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_16));
      e.mem[_nd_20 + 1] = rfc_seal(e, _b_4);
      _b_3 = term_ctr(CID__________SRC_ECS_SYSTEM_FAILED, _nd_20);
    }
    u64 _nd_21 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_21 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_13));
    e.mem[_nd_21 + 1] = rfc_seal(e, _b_3);
    r0 = term_ctr(CID_TUPLE, _nd_21);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K150)
  {
    WL_POPN(9);
    Term _owners_14 = STK(0);
    Term _owners_15 = STK(1);
    u32 _id_2 = STK(2);
    Term _h_18 = STK(3);
    u32 _h_19 = STK(4);
    u32 _h_20 = STK(5);
    u32 _h_21 = STK(6);
    Term _h_22 = STK(7);
    u32 _h_23 = STK(8);
    Term _h_17 = r0;
    WL_OPEN
    u64 _nd_24 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_24 + 0] = rfc_seal(e, _h_18);
    e.mem[_nd_24 + 1] = rfc_seal(e, 1);
    e.mem[_nd_24 + 2] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(9);
      STK(0) = _owners_14;
      STK(1) = _owners_15;
      STK(2) = _id_2;
      STK(3) = _h_19;
      STK(4) = _h_20;
      STK(5) = _h_21;
      STK(6) = _h_22;
      STK(7) = _h_23;
      STK(8) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K151;
      WL_PUSHN(9);
    } else {
      u64 _t_8 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K151, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _owners_14;
      e.mem[_t_8 + 1] = _owners_15;
      e.mem[_t_8 + 2] = _id_2;
      e.mem[_t_8 + 3] = _h_19;
      e.mem[_t_8 + 4] = _h_20;
      e.mem[_t_8 + 5] = _h_21;
      e.mem[_t_8 + 6] = _h_22;
      e.mem[_t_8 + 7] = _h_23;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K151, _t_8);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_9 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_17;
      e.mem[_t_9 + 1] = term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_24);
      return term_tsk(FID_CLO_APPLY, _t_9);
    }
    r0 = _h_17;
    r1 = term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_24);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K151)
  {
    WL_POPN(8);
    Term _owners_16 = STK(0);
    Term _owners_17 = STK(1);
    u32 _id_3 = STK(2);
    u32 _h_25 = STK(3);
    u32 _h_26 = STK(4);
    u32 _h_27 = STK(5);
    Term _h_28 = STK(6);
    u32 _h_29 = STK(7);
    Term _h_24 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _owners_16;
      STK(1) = _owners_17;
      STK(2) = _h_25;
      STK(3) = _h_26;
      STK(4) = _h_27;
      STK(5) = _h_28;
      STK(6) = _h_29;
      STK(7) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K152;
      WL_PUSHN(8);
    } else {
      u64 _t_10 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K152, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _owners_16;
      e.mem[_t_10 + 1] = _owners_17;
      e.mem[_t_10 + 2] = _h_25;
      e.mem[_t_10 + 3] = _h_26;
      e.mem[_t_10 + 4] = _h_27;
      e.mem[_t_10 + 5] = _h_28;
      e.mem[_t_10 + 6] = _h_29;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K152, _t_10);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_11 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _h_24;
      e.mem[_t_11 + 1] = _id_3;
      return term_tsk(FID_CLO_APPLY, _t_11);
    }
    r0 = _h_24;
    r1 = _id_3;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0_K152)
  {
    WL_POPN(7);
    Term _owners_18 = STK(0);
    Term _owners_19 = STK(1);
    u32 _h_31 = STK(2);
    u32 _h_32 = STK(3);
    u32 _h_33 = STK(4);
    Term _h_34 = STK(5);
    u32 _h_35 = STK(6);
    Term _h_30 = r0;
    WL_OPEN
    Term _fb_3[2];
    u64 _sp_3 = ctr_take(e, _h_30, 2, _fb_3);
    Term _f_32 = _fb_3[0];
    Term _f_33 = _fb_3[1];
    spare_free(e, cls_fit(2), _sp_3);
    Term _fb_4[2];
    u64 _sp_4 = ctr_take(e, _f_32, 2, _fb_4);
    Term _f_34 = _fb_4[0];
    Term _f_35 = _fb_4[1];
    spare_free(e, cls_fit(2), _sp_4);
    Term _fb_5[6];
    u64 _sp_5 = ctr_take(e, _f_35, 6, _fb_5);
    u32 _f_36 = _fb_5[0];
    u32 _f_37 = _fb_5[1];
    Term _f_38 = _fb_5[2];
    Term _f_39 = _fb_5[3];
    Term _f_40 = _fb_5[4];
    Term _f_41 = _fb_5[5];
    spare_free(e, cls_fit(6), _sp_5);
    u32 _o_4 = 0;
    Term _o_5 = 0;
    u32 _o_6 = 0;
    Term _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    if (term_aux(_f_33) == CID__________SRC_ECS_SYSTEM_SUCCEEDED) {
      _o_4 = 0;
      Term _fb_6[2];
      u64 _sp_6 = ctr_take(e, _f_33, 2, _fb_6);
      Term _f_42 = _fb_6[0];
      Term _f_43 = _fb_6[1];
      spare_free(e, cls_fit(2), _sp_6);
      Term _fb_7[3];
      u64 _sp_7 = ctr_take(e, _f_42, 3, _fb_7);
      Term _f_44 = _fb_7[0];
      u32 _f_45 = _fb_7[1];
      Term _f_46 = _fb_7[2];
      spare_free(e, cls_fit(3), _sp_7);
      _o_5 = _f_44;
      _o_6 = _f_45;
      _o_7 = _f_46;
    } else {
      _o_4 = 1;
      Term _fb_8[2];
      u64 _sp_8 = ctr_take(e, _f_33, 2, _fb_8);
      Term _f_47 = _fb_8[0];
      Term _f_48 = _fb_8[1];
      spare_free(e, cls_fit(2), _sp_8);
      Term _fb_9[3];
      u64 _sp_9 = ctr_take(e, _f_47, 3, _fb_9);
      Term _f_49 = _fb_9[0];
      u32 _f_50 = _fb_9[1];
      Term _f_51 = _fb_9[2];
      spare_free(e, cls_fit(3), _sp_9);
      u32 _o_10 = 0;
      u32 _o_11 = 0;
      if (term_aux(_f_48) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
        _o_10 = 0;
        Term _fb_10[1];
        u64 _sp_10 = ctr_take(e, _f_48, 1, _fb_10);
        Term _f_52 = _fb_10[0];
        spare_free(e, cls_fit(1), _sp_10);
      } else {
        _o_10 = 1;
        Term _fb_11[1];
        u64 _sp_11 = ctr_take(e, _f_48, 1, _fb_11);
        Term _f_53 = _fb_11[0];
        spare_free(e, cls_fit(1), _sp_11);
        u32 _o_12 = 0;
        if (term_aux(_f_53) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
          _o_12 = 0;
          Term _fb_12[1];
          u64 _sp_12 = ctr_take(e, _f_53, 1, _fb_12);
          Term _f_54 = _fb_12[0];
          spare_free(e, cls_fit(1), _sp_12);
        } else {
          _o_12 = 1;
        }
        _o_11 = _o_12;
      }
      _o_5 = _f_49;
      _o_6 = _f_50;
      _o_7 = _f_51;
      _o_8 = _o_10;
      _o_9 = _o_11;
    }
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    Term _o_13[11];
    if (spin_54(e, _o_13, _h_31, _h_32, _h_33, _h_34, blk_loc(e.mem, _h_34), _h_35, _owners_18, blk_loc(e.mem, _owners_18), _owners_19, blk_loc(e.mem, _owners_19), _f_36, _f_37, _f_38, blk_loc(e.mem, _f_38), _f_39, blk_loc(e.mem, _f_39), _f_40, blk_loc(e.mem, _f_40), _o_4, _o_5, blk_loc(e.mem, _o_5), _o_6, _o_7, blk_loc(e.mem, _o_7), _o_8, _o_9) == 0) {
      return 0;
    }
    _v_32 = _o_13[0];
    _v_33 = _o_13[1];
    _v_34 = _o_13[2];
    _v_35 = _o_13[3];
    _v_36 = _o_13[4];
    _v_37 = _o_13[5];
    _v_38 = _o_13[6];
    _v_39 = _o_13[7];
    _v_40 = _o_13[8];
    _v_41 = _o_13[9];
    _v_42 = _o_13[10];
    r0 = _v_32;
    r1 = _v_33;
    r2 = _v_34;
    r3 = _v_35;
    r4 = _v_36;
    r5 = _v_37;
    r6 = _v_38;
    r7 = _v_39;
    r8 = _v_40;
    r9 = _v_41;
    r10 = _v_42;
    WL_RETN(11);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0)
  {
    u32 _owners_0 = r0;
    u32 _owners_1 = r1;
    Term _owners_2 = r2;
    Term _owners_3 = r3;
    Term _owners_4 = r4;
    Term _world_0 = r5;
    u32 _id_0 = r6;
    WL_OPEN
    u64 _nd_22 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_22 + 0] = rfc_seal(e, _owners_0);
    e.mem[_nd_22 + 1] = rfc_seal(e, _owners_1);
    e.mem[_nd_22 + 2] = rfc_seal(e, _owners_2);
    e.mem[_nd_22 + 3] = rfc_seal(e, _owners_3);
    e.mem[_nd_22 + 4] = rfc_seal(e, _owners_4);
    e.mem[_nd_22 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_23 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_23 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_23 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_22));
    if (seq) {
      WL_ROOM(3);
      STK(0) = _world_0;
      STK(1) = _id_0;
      STK(2) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K160;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K160, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _world_0;
      e.mem[_t_4 + 1] = _id_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K160, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_5 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C155, 0);
      e.mem[_t_5 + 1] = term_ctr(CID_TUPLE, _nd_23);
      return term_tsk(FID_CLO_APPLY, _t_5);
    }
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C155, 0);
    r1 = term_ctr(CID_TUPLE, _nd_23);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C155)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _x_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[6];
    u64 _sp_1 = ctr_take(e, _f_1, 6, _fb_1);
    u32 _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    Term _f_5 = _fb_1[3];
    Term _f_6 = _fb_1[4];
    Term _f_7 = _fb_1[5];
    spare_free(e, cls_fit(6), _sp_1);
    u64 _nd_0 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_0 + 0] = _f_2;
    e.mem[_nd_0 + 1] = _f_3;
    e.mem[_nd_0 + 2] = _f_4;
    e.mem[_nd_0 + 3] = _f_5;
    e.mem[_nd_0 + 4] = _f_6;
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C156, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C156)
  {
    u32 _f_8 = r0;
    u32 _f_9 = r1;
    Term _f_10 = r2;
    Term _f_11 = r3;
    Term _f_12 = r4;
    Term _x_1 = r5;
    WL_OPEN
    Term _fb_2[3];
    u64 _sp_2 = ctr_take(e, _x_1, 3, _fb_2);
    Term _f_13 = _fb_2[0];
    u32 _f_14 = _fb_2[1];
    Term _f_15 = _fb_2[2];
    spare_free(e, cls_fit(3), _sp_2);
    u64 _nd_1 = heap_alloc(e, cls_fit(8));
    e.mem[_nd_1 + 0] = _f_8;
    e.mem[_nd_1 + 1] = _f_9;
    e.mem[_nd_1 + 2] = _f_10;
    e.mem[_nd_1 + 3] = _f_11;
    e.mem[_nd_1 + 4] = _f_12;
    e.mem[_nd_1 + 5] = _f_13;
    e.mem[_nd_1 + 6] = _f_14;
    e.mem[_nd_1 + 7] = _f_15;
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C157, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_C157)
  {
    u32 _f_16 = r0;
    u32 _f_17 = r1;
    Term _f_18 = r2;
    Term _f_19 = r3;
    Term _f_20 = r4;
    Term _f_21 = r5;
    u32 _f_22 = r6;
    Term _f_23 = r7;
    Term _x_2 = r8;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_0[1];
    if (spin_51(e, _o_0) == 0) {
      return 0;
    }
    _v_1 = _o_0[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(10);
      STK(0) = _f_16;
      STK(1) = _f_17;
      STK(2) = _f_18;
      STK(3) = _f_19;
      STK(4) = _f_20;
      STK(5) = _f_21;
      STK(6) = _f_22;
      STK(7) = _f_23;
      STK(8) = _x_2;
      STK(9) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K158;
      WL_PUSHN(10);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K158, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _f_16;
      e.mem[_t_0 + 1] = _f_17;
      e.mem[_t_0 + 2] = _f_18;
      e.mem[_t_0 + 3] = _f_19;
      e.mem[_t_0 + 4] = _f_20;
      e.mem[_t_0 + 5] = _f_21;
      e.mem[_t_0 + 6] = _f_22;
      e.mem[_t_0 + 7] = _f_23;
      e.mem[_t_0 + 8] = _x_2;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K158, _t_0);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_0;
      e.mem[_t_1 + 1] = _x_2;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0, _t_1);
    }
    r0 = _v_0;
    r1 = _x_2;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_MEMBER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K158)
  {
    WL_POPN(9);
    u32 _f_24 = STK(0);
    u32 _f_25 = STK(1);
    Term _f_26 = STK(2);
    Term _f_27 = STK(3);
    Term _f_28 = STK(4);
    Term _f_29 = STK(5);
    u32 _f_30 = STK(6);
    Term _f_31 = STK(7);
    u32 _x_3 = STK(8);
    u32 _h_0 = r0;
    WL_OPEN
    if (_h_0 == 1) {
      u32 _v_2 = 0;
      Term _v_3 = 0;
      u32 _v_4 = 0;
      Term _v_5 = 0;
      u32 _v_6 = 0;
      Term _v_7 = 0;
      u32 _v_8 = 0;
      Term _v_9 = 0;
      Term _o_1[4];
      if (spin_39(e, _o_1, _f_29, blk_loc(e.mem, _f_29), _f_30, _f_31, blk_loc(e.mem, _f_31), _x_3) == 0) {
        return 0;
      }
      _v_6 = _o_1[0];
      _v_7 = _o_1[1];
      _v_8 = _o_1[2];
      _v_9 = _o_1[3];
      _v_2 = _v_6;
      _v_3 = _v_7;
      _v_4 = _v_8;
      _v_5 = _v_9;
      u32 _v_10 = 0;
      u32 _v_11 = 0;
      Term _v_12 = 0;
      Term _v_13 = 0;
      Term _v_14 = 0;
      u32 _v_15 = 0;
      Term _v_16 = 0;
      u32 _v_17 = 0;
      Term _v_18 = 0;
      u32 _v_19 = 0;
      u32 _v_20 = 0;
      Term _o_2[11];
      if (spin_40(e, _o_2, _f_24, _f_25, _f_26, blk_loc(e.mem, _f_26), _f_27, blk_loc(e.mem, _f_27), _f_28, blk_loc(e.mem, _f_28), _v_2, _v_3, blk_loc(e.mem, _v_3), _v_4, _v_5, blk_loc(e.mem, _v_5)) == 0) {
        return 0;
      }
      _v_10 = _o_2[0];
      _v_11 = _o_2[1];
      _v_12 = _o_2[2];
      _v_13 = _o_2[3];
      _v_14 = _o_2[4];
      _v_15 = _o_2[5];
      _v_16 = _o_2[6];
      _v_17 = _o_2[7];
      _v_18 = _o_2[8];
      _v_19 = _o_2[9];
      _v_20 = _o_2[10];
      u64 _nd_2 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_2 + 0] = rfc_seal(e, _v_10);
      e.mem[_nd_2 + 1] = rfc_seal(e, _v_11);
      e.mem[_nd_2 + 2] = rfc_seal(e, _v_12);
      e.mem[_nd_2 + 3] = rfc_seal(e, _v_13);
      e.mem[_nd_2 + 4] = rfc_seal(e, _v_14);
      e.mem[_nd_2 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_2));
      Term _b_0 = 0;
      if (_v_15 == 0) {
        u64 _nd_4 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_4 + 0] = rfc_seal(e, _v_16);
        e.mem[_nd_4 + 1] = rfc_seal(e, _v_17);
        e.mem[_nd_4 + 2] = rfc_seal(e, _v_18);
        u64 _nd_5 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_4));
        e.mem[_nd_5 + 1] = rfc_seal(e, term_pak(CID_UNIT, 0));
        _b_0 = term_ctr(CID__________SRC_ECS_SYSTEM_SUCCEEDED, _nd_5);
      } else {
        u64 _nd_6 = heap_alloc(e, cls_fit(3));
        e.mem[_nd_6 + 0] = rfc_seal(e, _v_16);
        e.mem[_nd_6 + 1] = rfc_seal(e, _v_17);
        e.mem[_nd_6 + 2] = rfc_seal(e, _v_18);
        Term _b_1 = 0;
        if (_v_19 == 0) {
          u64 _nd_7 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_7 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_7);
        } else {
          Term _b_2 = 0;
          if (_v_20 == 0) {
            u64 _nd_8 = heap_alloc(e, cls_fit(1));
            e.mem[_nd_8 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
            _b_2 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_8);
          } else {
            _b_2 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
          }
          u64 _nd_9 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_9 + 0] = rfc_seal(e, _b_2);
          _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_9);
        }
        u64 _nd_10 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_10 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_6));
        e.mem[_nd_10 + 1] = rfc_seal(e, _b_1);
        _b_0 = term_ctr(CID__________SRC_ECS_SYSTEM_FAILED, _nd_10);
      }
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_3));
      e.mem[_nd_11 + 1] = rfc_seal(e, _b_0);
      r0 = term_ctr(CID_TUPLE, _nd_11);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K159;
        WL_PUSHN(1);
      } else {
        u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K159, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K159, _t_2);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0)) {
        u64 _t_3 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _f_24;
        e.mem[_t_3 + 1] = _f_25;
        e.mem[_t_3 + 2] = _f_26;
        e.mem[_t_3 + 3] = _f_27;
        e.mem[_t_3 + 4] = _f_28;
        e.mem[_t_3 + 5] = _f_29;
        e.mem[_t_3 + 6] = _f_30;
        e.mem[_t_3 + 7] = _f_31;
        e.mem[_t_3 + 8] = _x_3;
        return term_tsk(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0, _t_3);
      }
      r0 = _f_24;
      r1 = _f_25;
      r2 = _f_26;
      r3 = _f_27;
      r4 = _f_28;
      r5 = _f_29;
      r6 = _f_30;
      r7 = _f_31;
      r8 = _x_3;
      WL_JMP(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_EXECUTION_RUN_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K159)
  {
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    Term _h_3 = r2;
    Term _h_4 = r3;
    Term _h_5 = r4;
    u32 _h_6 = r5;
    Term _h_7 = r6;
    u32 _h_8 = r7;
    Term _h_9 = r8;
    u32 _h_10 = r9;
    WL_OPEN
    u32 _v_21 = 0;
    u32 _v_22 = 0;
    Term _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    u32 _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    u32 _v_31 = 0;
    Term _o_3[11];
    if (spin_41(e, _o_3, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, _h_7, blk_loc(e.mem, _h_7), _h_8, _h_9, blk_loc(e.mem, _h_9), _h_10) == 0) {
      return 0;
    }
    _v_21 = _o_3[0];
    _v_22 = _o_3[1];
    _v_23 = _o_3[2];
    _v_24 = _o_3[3];
    _v_25 = _o_3[4];
    _v_26 = _o_3[5];
    _v_27 = _o_3[6];
    _v_28 = _o_3[7];
    _v_29 = _o_3[8];
    _v_30 = _o_3[9];
    _v_31 = _o_3[10];
    u64 _nd_12 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_12 + 0] = rfc_seal(e, _v_21);
    e.mem[_nd_12 + 1] = rfc_seal(e, _v_22);
    e.mem[_nd_12 + 2] = rfc_seal(e, _v_23);
    e.mem[_nd_12 + 3] = rfc_seal(e, _v_24);
    e.mem[_nd_12 + 4] = rfc_seal(e, _v_25);
    e.mem[_nd_12 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_13 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_12));
    Term _b_3 = 0;
    if (_v_26 == 0) {
      u64 _nd_14 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_14 + 0] = rfc_seal(e, _v_27);
      e.mem[_nd_14 + 1] = rfc_seal(e, _v_28);
      e.mem[_nd_14 + 2] = rfc_seal(e, _v_29);
      u64 _nd_15 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_15 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_14));
      e.mem[_nd_15 + 1] = rfc_seal(e, term_pak(CID_UNIT, 0));
      _b_3 = term_ctr(CID__________SRC_ECS_SYSTEM_SUCCEEDED, _nd_15);
    } else {
      u64 _nd_16 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_16 + 0] = rfc_seal(e, _v_27);
      e.mem[_nd_16 + 1] = rfc_seal(e, _v_28);
      e.mem[_nd_16 + 2] = rfc_seal(e, _v_29);
      Term _b_4 = 0;
      if (_v_30 == 0) {
        u64 _nd_17 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_17 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
        _b_4 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_17);
      } else {
        Term _b_5 = 0;
        if (_v_31 == 0) {
          u64 _nd_18 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_18 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
          _b_5 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_18);
        } else {
          _b_5 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
        }
        u64 _nd_19 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_19 + 0] = rfc_seal(e, _b_5);
        _b_4 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_19);
      }
      u64 _nd_20 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_20 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_16));
      e.mem[_nd_20 + 1] = rfc_seal(e, _b_4);
      _b_3 = term_ctr(CID__________SRC_ECS_SYSTEM_FAILED, _nd_20);
    }
    u64 _nd_21 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_21 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_13));
    e.mem[_nd_21 + 1] = rfc_seal(e, _b_3);
    r0 = term_ctr(CID_TUPLE, _nd_21);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K160)
  {
    WL_POPN(2);
    Term _world_1 = STK(0);
    u32 _id_1 = STK(1);
    Term _h_11 = r0;
    WL_OPEN
    u64 _nd_24 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_24 + 0] = rfc_seal(e, _world_1);
    e.mem[_nd_24 + 1] = rfc_seal(e, 0);
    e.mem[_nd_24 + 2] = rfc_seal(e, 0);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _id_1;
      STK(1) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K161;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K161, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _id_1;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K161, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_7 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_11;
      e.mem[_t_7 + 1] = term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_24);
      return term_tsk(FID_CLO_APPLY, _t_7);
    }
    r0 = _h_11;
    r1 = term_ctr(CID__________SRC_ECS_EXECUTION_CONTEXT_CONTEXT, _nd_24);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K161)
  {
    WL_POPN(1);
    u32 _id_2 = STK(0);
    Term _h_12 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K162;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K162, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K162, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_9 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_12;
      e.mem[_t_9 + 1] = _id_2;
      return term_tsk(FID_CLO_APPLY, _t_9);
    }
    r0 = _h_12;
    r1 = _id_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0_K162)
  {
    Term _h_13 = r0;
    WL_OPEN
    Term _fb_3[2];
    u64 _sp_3 = ctr_take(e, _h_13, 2, _fb_3);
    Term _f_32 = _fb_3[0];
    Term _f_33 = _fb_3[1];
    spare_free(e, cls_fit(2), _sp_3);
    Term _fb_4[2];
    u64 _sp_4 = ctr_take(e, _f_32, 2, _fb_4);
    Term _f_34 = _fb_4[0];
    Term _f_35 = _fb_4[1];
    spare_free(e, cls_fit(2), _sp_4);
    Term _fb_5[6];
    u64 _sp_5 = ctr_take(e, _f_35, 6, _fb_5);
    u32 _f_36 = _fb_5[0];
    u32 _f_37 = _fb_5[1];
    Term _f_38 = _fb_5[2];
    Term _f_39 = _fb_5[3];
    Term _f_40 = _fb_5[4];
    Term _f_41 = _fb_5[5];
    spare_free(e, cls_fit(6), _sp_5);
    u32 _o_4 = 0;
    Term _o_5 = 0;
    u32 _o_6 = 0;
    Term _o_7 = 0;
    u32 _o_8 = 0;
    u32 _o_9 = 0;
    if (term_aux(_f_33) == CID__________SRC_ECS_SYSTEM_SUCCEEDED) {
      _o_4 = 0;
      Term _fb_6[2];
      u64 _sp_6 = ctr_take(e, _f_33, 2, _fb_6);
      Term _f_42 = _fb_6[0];
      Term _f_43 = _fb_6[1];
      spare_free(e, cls_fit(2), _sp_6);
      Term _fb_7[3];
      u64 _sp_7 = ctr_take(e, _f_42, 3, _fb_7);
      Term _f_44 = _fb_7[0];
      u32 _f_45 = _fb_7[1];
      Term _f_46 = _fb_7[2];
      spare_free(e, cls_fit(3), _sp_7);
      _o_5 = _f_44;
      _o_6 = _f_45;
      _o_7 = _f_46;
    } else {
      _o_4 = 1;
      Term _fb_8[2];
      u64 _sp_8 = ctr_take(e, _f_33, 2, _fb_8);
      Term _f_47 = _fb_8[0];
      Term _f_48 = _fb_8[1];
      spare_free(e, cls_fit(2), _sp_8);
      Term _fb_9[3];
      u64 _sp_9 = ctr_take(e, _f_47, 3, _fb_9);
      Term _f_49 = _fb_9[0];
      u32 _f_50 = _fb_9[1];
      Term _f_51 = _fb_9[2];
      spare_free(e, cls_fit(3), _sp_9);
      u32 _o_10 = 0;
      u32 _o_11 = 0;
      if (term_aux(_f_48) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
        _o_10 = 0;
        Term _fb_10[1];
        u64 _sp_10 = ctr_take(e, _f_48, 1, _fb_10);
        Term _f_52 = _fb_10[0];
        spare_free(e, cls_fit(1), _sp_10);
      } else {
        _o_10 = 1;
        Term _fb_11[1];
        u64 _sp_11 = ctr_take(e, _f_48, 1, _fb_11);
        Term _f_53 = _fb_11[0];
        spare_free(e, cls_fit(1), _sp_11);
        u32 _o_12 = 0;
        if (term_aux(_f_53) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
          _o_12 = 0;
          Term _fb_12[1];
          u64 _sp_12 = ctr_take(e, _f_53, 1, _fb_12);
          Term _f_54 = _fb_12[0];
          spare_free(e, cls_fit(1), _sp_12);
        } else {
          _o_12 = 1;
        }
        _o_11 = _o_12;
      }
      _o_5 = _f_49;
      _o_6 = _f_50;
      _o_7 = _f_51;
      _o_8 = _o_10;
      _o_9 = _o_11;
    }
    u32 _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    Term _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    Term _v_38 = 0;
    u32 _v_39 = 0;
    u32 _v_40 = 0;
    Term _o_13[9];
    if (spin_56(e, _o_13, _f_36, _f_37, _f_38, blk_loc(e.mem, _f_38), _f_39, blk_loc(e.mem, _f_39), _f_40, blk_loc(e.mem, _f_40), _o_4, _o_5, blk_loc(e.mem, _o_5), _o_6, _o_7, blk_loc(e.mem, _o_7), _o_8, _o_9) == 0) {
      return 0;
    }
    _v_32 = _o_13[0];
    _v_33 = _o_13[1];
    _v_34 = _o_13[2];
    _v_35 = _o_13[3];
    _v_36 = _o_13[4];
    _v_37 = _o_13[5];
    _v_38 = _o_13[6];
    _v_39 = _o_13[7];
    _v_40 = _o_13[8];
    r0 = _v_32;
    r1 = _v_33;
    r2 = _v_34;
    r3 = _v_35;
    r4 = _v_36;
    r5 = _v_37;
    r6 = _v_38;
    r7 = _v_39;
    r8 = _v_40;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0)
  {
    Term _commands_0 = r0;
    Term _world_0 = r1;
    u32 _trace_0 = r2;
    Term _trace_1 = r3;
    WL_OPEN
    WL_SPIN
    if (term_aux(_commands_0) == CID_NIL) {
      r0 = _world_0;
      r1 = _trace_0;
      r2 = _trace_1;
      WL_RETN(3);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _commands_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_DEFERRED_COMMAND_RAW) {
        _o_0 = 0;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        _o_1 = _f_2;
      } else {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_3 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_3;
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K173;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K173, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K173, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _world_0;
      r2 = _trace_0;
      r3 = _trace_1;
      _commands_0 = r0;
      _world_0 = r1;
      _trace_0 = r2;
      _trace_1 = r3;
      WL_AGAIN(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K173)
  {
    WL_POPN(2);
    u32 _o_2 = STK(0);
    Term _o_3 = STK(1);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    if (_o_2 == 0) {
      if (seq) {
        WL_ROOM(3);
        STK(0) = _h_1;
        STK(1) = _h_2;
        STK(2) = FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K174;
        WL_PUSHN(3);
      } else {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K174, WL_CONT, WL_IDX, 1);
        e.mem[_t_1 + 0] = _h_1;
        e.mem[_t_1 + 1] = _h_2;
        WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K174, _t_1);
        WL_IDX = 2;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_2 + 0] = _o_3;
        e.mem[_t_2 + 1] = _h_0;
        return term_tsk(FID_CLO_APPLY, _t_2);
      }
      r0 = _o_3;
      r1 = _h_0;
      WL_JMP(FID_CLO_APPLY);
    } else {
      Term _b_0 = 0;
      if (_h_1 == 0) {
        _b_0 = term_pak(CID__________SRC_ECS_TRACE_FACTS_OFF, 0);
      } else {
        u64 _nd_0 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_0 + 0] = rfc_seal(e, _h_2);
        _b_0 = term_ctr(CID__________SRC_ECS_TRACE_FACTS_ON, _nd_0);
      }
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_0;
        STK(1) = FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K175;
        WL_PUSHN(2);
      } else {
        u64 _t_3 = task_node(e, FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K175, WL_CONT, WL_IDX, 1);
        e.mem[_t_3 + 0] = _h_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K175, _t_3);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_4 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_4 + 0] = _o_3;
        e.mem[_t_4 + 1] = _b_0;
        return term_tsk(FID_CLO_APPLY, _t_4);
      }
      r0 = _o_3;
      r1 = _b_0;
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K174)
  {
    WL_POPN(2);
    u32 _h_4 = STK(0);
    Term _h_5 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    r0 = _h_3;
    r1 = _h_4;
    r2 = _h_5;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K175)
  {
    WL_POPN(1);
    Term _h_7 = STK(0);
    Term _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K176;
      WL_PUSHN(1);
    } else {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K176, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K176, _t_5);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_6 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_6;
      e.mem[_t_6 + 1] = _h_7;
      return term_tsk(FID_CLO_APPLY, _t_6);
    }
    r0 = _h_6;
    r1 = _h_7;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0_K176)
  {
    Term _r_0 = r0;
    WL_OPEN
    Term _fb_3[2];
    u64 _sp_3 = ctr_take(e, _r_0, 2, _fb_3);
    Term _f_4 = _fb_3[0];
    Term _f_5 = _fb_3[1];
    spare_free(e, cls_fit(2), _sp_3);
    u32 _o_4 = 0;
    Term _o_5 = 0;
    if (term_aux(_f_5) == CID__________SRC_ECS_TRACE_FACTS_OFF) {
      _o_4 = 0;
    } else {
      _o_4 = 1;
      Term _fb_4[1];
      u64 _sp_4 = ctr_take(e, _f_5, 1, _fb_4);
      Term _f_6 = _fb_4[0];
      spare_free(e, cls_fit(1), _sp_4);
      _o_5 = _f_6;
    }
    r0 = _f_4;
    r1 = _o_4;
    r2 = _o_5;
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    Term _owner_3 = r3;
    Term _owner_4 = r4;
    u32 _owner_5 = r5;
    Term _owner_6 = r6;
    Term _owner_7 = r7;
    Term _world_0 = r8;
    u32 _id_0 = r9;
    WL_OPEN
    if (_owner_5 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K178;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K178, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K178, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _owner_0;
        e.mem[_t_1 + 1] = _owner_1;
        e.mem[_t_1 + 2] = _owner_2;
        e.mem[_t_1 + 3] = _owner_3;
        e.mem[_t_1 + 4] = _owner_4;
        e.mem[_t_1 + 5] = _world_0;
        e.mem[_t_1 + 6] = _id_0;
        return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0, _t_1);
      }
      r0 = _owner_0;
      r1 = _owner_1;
      r2 = _owner_2;
      r3 = _owner_3;
      r4 = _owner_4;
      r5 = _world_0;
      r6 = _id_0;
      WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_DISABLED_0);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K179;
        WL_PUSHN(1);
      } else {
        u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K179, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K179, _t_2);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0)) {
        u64 _t_3 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _owner_0;
        e.mem[_t_3 + 1] = _owner_1;
        e.mem[_t_3 + 2] = _owner_2;
        e.mem[_t_3 + 3] = _owner_3;
        e.mem[_t_3 + 4] = _owner_4;
        e.mem[_t_3 + 5] = _owner_6;
        e.mem[_t_3 + 6] = _owner_7;
        e.mem[_t_3 + 7] = _world_0;
        e.mem[_t_3 + 8] = _id_0;
        return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0, _t_3);
      }
      r0 = _owner_0;
      r1 = _owner_1;
      r2 = _owner_2;
      r3 = _owner_3;
      r4 = _owner_4;
      r5 = _owner_6;
      r6 = _owner_7;
      r7 = _world_0;
      r8 = _id_0;
      WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_RECORDED_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K178)
  {
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    u32 _h_8 = r8;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    u32 _v_11 = 0;
    Term _o_0[12];
    if (spin_57(e, _o_0, _h_0, _h_1, _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, _h_6, blk_loc(e.mem, _h_6), _h_7, _h_8) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0_K179)
  {
    u32 _h_9 = r0;
    u32 _h_10 = r1;
    Term _h_11 = r2;
    Term _h_12 = r3;
    Term _h_13 = r4;
    Term _h_14 = r5;
    Term _h_15 = r6;
    u32 _h_16 = r7;
    Term _h_17 = r8;
    u32 _h_18 = r9;
    u32 _h_19 = r10;
    WL_OPEN
    u32 _v_24 = 0;
    u32 _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    Term _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    u32 _v_32 = 0;
    Term _v_33 = 0;
    u32 _v_34 = 0;
    u32 _v_35 = 0;
    Term _o_1[12];
    if (spin_58(e, _o_1, _h_9, _h_10, _h_11, blk_loc(e.mem, _h_11), _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, blk_loc(e.mem, _h_15), _h_16, _h_17, blk_loc(e.mem, _h_17), _h_18, _h_19) == 0) {
      return 0;
    }
    _v_24 = _o_1[0];
    _v_25 = _o_1[1];
    _v_26 = _o_1[2];
    _v_27 = _o_1[3];
    _v_28 = _o_1[4];
    _v_29 = _o_1[5];
    _v_30 = _o_1[6];
    _v_31 = _o_1[7];
    _v_32 = _o_1[8];
    _v_33 = _o_1[9];
    _v_34 = _o_1[10];
    _v_35 = _o_1[11];
    r0 = _v_24;
    r1 = _v_25;
    r2 = _v_26;
    r3 = _v_27;
    r4 = _v_28;
    r5 = _v_29;
    r6 = _v_30;
    r7 = _v_31;
    r8 = _v_32;
    r9 = _v_33;
    r10 = _v_34;
    r11 = _v_35;
    WL_RETN(12);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_BARRIER_TRACED_0)
  {
    Term _world_0 = r0;
    u32 _trace_0 = r1;
    Term _trace_1 = r2;
    WL_OPEN
    Term _fb_0[15];
    u64 _sp_0 = ctr_take(e, _world_0, 15, _fb_0);
    u32 _f_0 = _fb_0[0];
    u32 _f_1 = _fb_0[1];
    u32 _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    Term _f_9 = _fb_0[9];
    Term _f_10 = _fb_0[10];
    Term _f_11 = _fb_0[11];
    Term _f_12 = _fb_0[12];
    u32 _f_13 = _fb_0[13];
    u32 _f_14 = _fb_0[14];
    u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(15));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_3);
    e.mem[_nd_0 + 4] = rfc_seal(e, _f_4);
    e.mem[_nd_0 + 5] = rfc_seal(e, _f_5);
    e.mem[_nd_0 + 6] = rfc_seal(e, _f_6);
    e.mem[_nd_0 + 7] = rfc_seal(e, _f_7);
    e.mem[_nd_0 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 9] = rfc_seal(e, _f_9);
    e.mem[_nd_0 + 10] = rfc_seal(e, _f_10);
    e.mem[_nd_0 + 11] = rfc_seal(e, term_pak(CID_NIL, 0));
    e.mem[_nd_0 + 12] = rfc_seal(e, _f_12);
    e.mem[_nd_0 + 13] = rfc_seal(e, _f_13);
    e.mem[_nd_0 + 14] = rfc_seal(e, _f_14);
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0)) {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _f_11;
      e.mem[_t_0 + 1] = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
      e.mem[_t_0 + 2] = _trace_0;
      e.mem[_t_0 + 3] = _trace_1;
      return term_tsk(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0, _t_0);
    }
    r0 = _f_11;
    r1 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_0);
    r2 = _trace_0;
    r3 = _trace_1;
    WL_JMP(FID__________SRC_ECS_WORLD_DRAIN_FIFO_TRACED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0)
  {
    u32 _owners_0 = r0;
    u32 _owners_1 = r1;
    Term _owners_2 = r2;
    Term _owners_3 = r3;
    Term _owners_4 = r4;
    Term _owners_5 = r5;
    Term _owners_6 = r6;
    Term _world_0 = r7;
    WL_OPEN
    if (seq) {
      WL_ROOM(8);
      STK(0) = _owners_0;
      STK(1) = _owners_1;
      STK(2) = _owners_2;
      STK(3) = _owners_3;
      STK(4) = _owners_4;
      STK(5) = _owners_5;
      STK(6) = _owners_6;
      STK(7) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0_K201;
      WL_PUSHN(8);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0_K201, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owners_0;
      e.mem[_t_0 + 1] = _owners_1;
      e.mem[_t_0 + 2] = _owners_2;
      e.mem[_t_0 + 3] = _owners_3;
      e.mem[_t_0 + 4] = _owners_4;
      e.mem[_t_0 + 5] = _owners_5;
      e.mem[_t_0 + 6] = _owners_6;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0_K201, _t_0);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_BARRIER_TRACED_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_BARRIER_TRACED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = 1;
      e.mem[_t_1 + 2] = term_pak(CID_NIL, 0);
      return term_tsk(FID__________SRC_ECS_WORLD_BARRIER_TRACED_0, _t_1);
    }
    r0 = _world_0;
    r1 = 1;
    r2 = term_pak(CID_NIL, 0);
    WL_JMP(FID__________SRC_ECS_WORLD_BARRIER_TRACED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0_K201)
  {
    WL_POPN(7);
    u32 _owners_7 = STK(0);
    u32 _owners_8 = STK(1);
    Term _owners_9 = STK(2);
    Term _owners_10 = STK(3);
    Term _owners_11 = STK(4);
    Term _owners_12 = STK(5);
    Term _owners_13 = STK(6);
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _o_2[8];
    if (spin_60(e, _o_2, _owners_7, _owners_8, _owners_9, blk_loc(e.mem, _owners_9), _owners_10, blk_loc(e.mem, _owners_10), _owners_11, blk_loc(e.mem, _owners_11), _owners_12, blk_loc(e.mem, _owners_12), _owners_13, blk_loc(e.mem, _owners_13), _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_2[0];
    _v_1 = _o_2[1];
    _v_2 = _o_2[2];
    _v_3 = _o_2[3];
    _v_4 = _o_2[4];
    _v_5 = _o_2[5];
    _v_6 = _o_2[6];
    _v_7 = _o_2[7];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    WL_RETN(8);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_BARRIER_0)
  {
    Term _world_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_WORLD_BARRIER_0_K204;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_BARRIER_0_K204, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_BARRIER_0_K204, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_BARRIER_TRACED_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_BARRIER_TRACED_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _world_0;
      e.mem[_t_1 + 1] = 0;
      e.mem[_t_1 + 2] = 0;
      return term_tsk(FID__________SRC_ECS_WORLD_BARRIER_TRACED_0, _t_1);
    }
    r0 = _world_0;
    r1 = 0;
    r2 = 0;
    WL_JMP(FID__________SRC_ECS_WORLD_BARRIER_TRACED_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_BARRIER_0_K204)
  {
    Term _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_61(e, _o_0, _h_0, blk_loc(e.mem, _h_0), _h_1, _h_2, blk_loc(e.mem, _h_2)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0)
  {
    u32 _owner_0 = r0;
    u32 _owner_1 = r1;
    Term _owner_2 = r2;
    Term _owner_3 = r3;
    Term _owner_4 = r4;
    u32 _owner_5 = r5;
    Term _owner_6 = r6;
    Term _owner_7 = r7;
    Term _world_0 = r8;
    WL_OPEN
    if (_owner_5 == 0) {
      if (seq) {
        WL_ROOM(6);
        STK(0) = _owner_0;
        STK(1) = _owner_1;
        STK(2) = _owner_2;
        STK(3) = _owner_3;
        STK(4) = _owner_4;
        STK(5) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K218;
        WL_PUSHN(6);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K218, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _owner_0;
        e.mem[_t_0 + 1] = _owner_1;
        e.mem[_t_0 + 2] = _owner_2;
        e.mem[_t_0 + 3] = _owner_3;
        e.mem[_t_0 + 4] = _owner_4;
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K218, _t_0);
        WL_IDX = 5;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_BARRIER_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_BARRIER_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _world_0;
        return term_tsk(FID__________SRC_ECS_WORLD_BARRIER_0, _t_1);
      }
      r0 = _world_0;
      WL_JMP(FID__________SRC_ECS_WORLD_BARRIER_0);
    } else {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K219;
        WL_PUSHN(1);
      } else {
        u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K219, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K219, _t_2);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0)) {
        u64 _t_3 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _owner_0;
        e.mem[_t_3 + 1] = _owner_1;
        e.mem[_t_3 + 2] = _owner_2;
        e.mem[_t_3 + 3] = _owner_3;
        e.mem[_t_3 + 4] = _owner_4;
        e.mem[_t_3 + 5] = _owner_6;
        e.mem[_t_3 + 6] = _owner_7;
        e.mem[_t_3 + 7] = _world_0;
        return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0, _t_3);
      }
      r0 = _owner_0;
      r1 = _owner_1;
      r2 = _owner_2;
      r3 = _owner_3;
      r4 = _owner_4;
      r5 = _owner_6;
      r6 = _owner_7;
      r7 = _world_0;
      WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_RECORDED_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K218)
  {
    WL_POPN(5);
    u32 _owner_8 = STK(0);
    u32 _owner_9 = STK(1);
    Term _owner_10 = STK(2);
    Term _owner_11 = STK(3);
    Term _owner_12 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    r0 = _owner_8;
    r1 = _owner_9;
    r2 = _owner_10;
    r3 = _owner_11;
    r4 = _owner_12;
    r5 = 0;
    r6 = 0;
    r7 = 0;
    r8 = _h_0;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0_K219)
  {
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    Term _h_3 = r2;
    Term _h_4 = r3;
    Term _h_5 = r4;
    Term _h_6 = r5;
    Term _h_7 = r6;
    Term _h_8 = r7;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _o_0[9];
    if (spin_62(e, _o_0, _h_1, _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0)
  {
    Term _steps_0 = r0;
    u32 _owners_0 = r1;
    u32 _owners_1 = r2;
    Term _owners_2 = r3;
    Term _owners_3 = r4;
    Term _owners_4 = r5;
    u32 _owners_5 = r6;
    Term _owners_6 = r7;
    Term _owners_7 = r8;
    Term _world_0 = r9;
    u32 _namespace_0 = r10;
    Term _name_0 = r11;
    Term _all_0 = r12;
    Term _observations_0 = r13;
    WL_OPEN
    if (term_aux(_steps_0) == CID_NIL) {
      r0 = 0;
      r1 = _namespace_0;
      r2 = _name_0;
      r3 = _all_0;
      r4 = _owners_0;
      r5 = _owners_1;
      r6 = _owners_2;
      r7 = _owners_3;
      r8 = _owners_4;
      r9 = _owners_5;
      r10 = _owners_6;
      r11 = _owners_7;
      r12 = _world_0;
      r13 = _observations_0;
      r14 = 0;
      r15 = 0;
      WL_RETN(16);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _steps_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      u32 _o_2 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_SYSTEM) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_PHASE) {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_4;
      } else {
        _o_0 = 2;
      }
      if (_o_0 == 1) {
        u64 _nd_0 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_0 + 0] = rfc_seal(e, _o_1);
        u64 _nd_1 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_SCHEDULE_ENTERED, _nd_0));
        e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        if (seq) {
          WL_ROOM(14);
          STK(0) = _f_1;
          STK(1) = _owners_0;
          STK(2) = _owners_1;
          STK(3) = _owners_2;
          STK(4) = _owners_3;
          STK(5) = _owners_4;
          STK(6) = _owners_5;
          STK(7) = _owners_6;
          STK(8) = _owners_7;
          STK(9) = _world_0;
          STK(10) = _namespace_0;
          STK(11) = _name_0;
          STK(12) = _all_0;
          STK(13) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K225;
          WL_PUSHN(14);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K225, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          e.mem[_t_0 + 1] = _owners_0;
          e.mem[_t_0 + 2] = _owners_1;
          e.mem[_t_0 + 3] = _owners_2;
          e.mem[_t_0 + 4] = _owners_3;
          e.mem[_t_0 + 5] = _owners_4;
          e.mem[_t_0 + 6] = _owners_5;
          e.mem[_t_0 + 7] = _owners_6;
          e.mem[_t_0 + 8] = _owners_7;
          e.mem[_t_0 + 9] = _world_0;
          e.mem[_t_0 + 10] = _namespace_0;
          e.mem[_t_0 + 11] = _name_0;
          e.mem[_t_0 + 12] = _all_0;
          WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K225, _t_0);
          WL_IDX = 13;
        }
        if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
          u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _observations_0;
          e.mem[_t_1 + 1] = term_ctr(CID_CON, _nd_1);
          return term_tsk(FID_LIST_APPEND, _t_1);
        }
        r0 = _observations_0;
        r1 = term_ctr(CID_CON, _nd_1);
        WL_JMP(FID_LIST_APPEND);
      } else if (_o_0 == 2) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(6);
          STK(0) = _f_1;
          STK(1) = _namespace_0;
          STK(2) = _name_0;
          STK(3) = _all_0;
          STK(4) = _observations_0;
          STK(5) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K226;
          WL_PUSHN(6);
        } else {
          u64 _t_3 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K226, WL_CONT, WL_IDX, 1);
          e.mem[_t_3 + 0] = _f_1;
          e.mem[_t_3 + 1] = _namespace_0;
          e.mem[_t_3 + 2] = _name_0;
          e.mem[_t_3 + 3] = _all_0;
          e.mem[_t_3 + 4] = _observations_0;
          WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K226, _t_3);
          WL_IDX = 5;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0)) {
          u64 _t_4 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_4 + 0] = _owners_0;
          e.mem[_t_4 + 1] = _owners_1;
          e.mem[_t_4 + 2] = _owners_2;
          e.mem[_t_4 + 3] = _owners_3;
          e.mem[_t_4 + 4] = _owners_4;
          e.mem[_t_4 + 5] = _owners_5;
          e.mem[_t_4 + 6] = _owners_6;
          e.mem[_t_4 + 7] = _owners_7;
          e.mem[_t_4 + 8] = _world_0;
          return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0, _t_4);
        }
        r0 = _owners_0;
        r1 = _owners_1;
        r2 = _owners_2;
        r3 = _owners_3;
        r4 = _owners_4;
        r5 = _owners_5;
        r6 = _owners_6;
        r7 = _owners_7;
        r8 = _world_0;
        WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_STATE_0);
      } else {
        _name_0 = term_keep(e, _name_0, 1);
        _all_0 = term_keep(e, _all_0, 1);
        u64 _nd_27 = heap_alloc(e, cls_fit(4));
        e.mem[_nd_27 + 0] = _f_1;
        e.mem[_nd_27 + 1] = _namespace_0;
        e.mem[_nd_27 + 2] = _name_0;
        e.mem[_nd_27 + 3] = _all_0;
        Term _v_0 = 0;
        u32 _v_1 = 0;
        Term _v_2 = 0;
        u32 _v_3 = 0;
        Term _o_49[2];
        if (spin_63(e, _o_49, _world_0, blk_loc(e.mem, _world_0), _o_2) == 0) {
          return 0;
        }
        _v_2 = _o_49[0];
        _v_3 = _o_49[1];
        _v_0 = _v_2;
        _v_1 = _v_3;
        Term _next_1 = term_clo(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C235, _nd_27);
        if (_v_1 == 0) {
          term_sink(e, _name_0);
          term_sink(e, _all_0);
          u64 _nd_48 = heap_alloc(e, cls_fit(6));
          e.mem[_nd_48 + 0] = rfc_seal(e, _owners_0);
          e.mem[_nd_48 + 1] = rfc_seal(e, _owners_1);
          e.mem[_nd_48 + 2] = rfc_seal(e, _owners_2);
          e.mem[_nd_48 + 3] = rfc_seal(e, _owners_3);
          e.mem[_nd_48 + 4] = rfc_seal(e, _owners_4);
          e.mem[_nd_48 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
          u64 _nd_49 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_49 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
          e.mem[_nd_49 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_48));
          Term _b_13 = 0;
          if (_owners_5 == 0) {
            _b_13 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
          } else {
            u64 _nd_50 = heap_alloc(e, cls_fit(2));
            e.mem[_nd_50 + 0] = rfc_seal(e, _owners_6);
            e.mem[_nd_50 + 1] = rfc_seal(e, _owners_7);
            _b_13 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_50);
          }
          u64 _nd_51 = heap_alloc(e, cls_fit(2));
          e.mem[_nd_51 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_49));
          e.mem[_nd_51 + 1] = rfc_seal(e, _b_13);
          if (seq) {
            WL_ROOM(4);
            STK(0) = _v_0;
            STK(1) = _observations_0;
            STK(2) = _o_1;
            STK(3) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K239;
            WL_PUSHN(4);
          } else {
            u64 _t_17 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K239, WL_CONT, WL_IDX, 1);
            e.mem[_t_17 + 0] = _v_0;
            e.mem[_t_17 + 1] = _observations_0;
            e.mem[_t_17 + 2] = _o_1;
            WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K239, _t_17);
            WL_IDX = 3;
          }
          if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
            u64 _t_18 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
            e.mem[_t_18 + 0] = _next_1;
            e.mem[_t_18 + 1] = term_ctr(CID_TUPLE, _nd_51);
            return term_tsk(FID_CLO_APPLY, _t_18);
          }
          r0 = _next_1;
          r1 = term_ctr(CID_TUPLE, _nd_51);
          WL_JMP(FID_CLO_APPLY);
        } else {
          spare_free(e, cls_fit(2), _sp_0);
          if (seq) {
            WL_ROOM(7);
            STK(0) = _next_1;
            STK(1) = _namespace_0;
            STK(2) = _name_0;
            STK(3) = _all_0;
            STK(4) = _observations_0;
            STK(5) = _o_1;
            STK(6) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K243;
            WL_PUSHN(7);
          } else {
            u64 _t_25 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K243, WL_CONT, WL_IDX, 1);
            e.mem[_t_25 + 0] = _next_1;
            e.mem[_t_25 + 1] = _namespace_0;
            e.mem[_t_25 + 2] = _name_0;
            e.mem[_t_25 + 3] = _all_0;
            e.mem[_t_25 + 4] = _observations_0;
            e.mem[_t_25 + 5] = _o_1;
            WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K243, _t_25);
            WL_IDX = 6;
          }
          if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0)) {
            u64 _t_26 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0, WL_CONT, WL_IDX, 0);
            e.mem[_t_26 + 0] = _owners_0;
            e.mem[_t_26 + 1] = _owners_1;
            e.mem[_t_26 + 2] = _owners_2;
            e.mem[_t_26 + 3] = _owners_3;
            e.mem[_t_26 + 4] = _owners_4;
            e.mem[_t_26 + 5] = _owners_5;
            e.mem[_t_26 + 6] = _owners_6;
            e.mem[_t_26 + 7] = _owners_7;
            e.mem[_t_26 + 8] = _v_0;
            e.mem[_t_26 + 9] = _o_1;
            return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0, _t_26);
          }
          r0 = _owners_0;
          r1 = _owners_1;
          r2 = _owners_2;
          r3 = _owners_3;
          r4 = _owners_4;
          r5 = _owners_5;
          r6 = _owners_6;
          r7 = _owners_7;
          r8 = _v_0;
          r9 = _o_1;
          WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_DISPATCH_STATE_0);
        }
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K225)
  {
    WL_POPN(13);
    Term _f_5 = STK(0);
    u32 _owners_8 = STK(1);
    u32 _owners_9 = STK(2);
    Term _owners_10 = STK(3);
    Term _owners_11 = STK(4);
    Term _owners_12 = STK(5);
    u32 _owners_13 = STK(6);
    Term _owners_14 = STK(7);
    Term _owners_15 = STK(8);
    Term _world_1 = STK(9);
    u32 _namespace_1 = STK(10);
    Term _name_1 = STK(11);
    Term _all_1 = STK(12);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _owners_8;
      e.mem[_t_2 + 2] = _owners_9;
      e.mem[_t_2 + 3] = _owners_10;
      e.mem[_t_2 + 4] = _owners_11;
      e.mem[_t_2 + 5] = _owners_12;
      e.mem[_t_2 + 6] = _owners_13;
      e.mem[_t_2 + 7] = _owners_14;
      e.mem[_t_2 + 8] = _owners_15;
      e.mem[_t_2 + 9] = _world_1;
      e.mem[_t_2 + 10] = _namespace_1;
      e.mem[_t_2 + 11] = _name_1;
      e.mem[_t_2 + 12] = _all_1;
      e.mem[_t_2 + 13] = _h_0;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0, _t_2);
    }
    r0 = _f_5;
    r1 = _owners_8;
    r2 = _owners_9;
    r3 = _owners_10;
    r4 = _owners_11;
    r5 = _owners_12;
    r6 = _owners_13;
    r7 = _owners_14;
    r8 = _owners_15;
    r9 = _world_1;
    r10 = _namespace_1;
    r11 = _name_1;
    r12 = _all_1;
    r13 = _h_0;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K226)
  {
    WL_POPN(5);
    Term _f_6 = STK(0);
    u32 _namespace_2 = STK(1);
    Term _name_2 = STK(2);
    Term _all_2 = STK(3);
    Term _observations_1 = STK(4);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    Term _h_3 = r2;
    Term _h_4 = r3;
    Term _h_5 = r4;
    u32 _h_6 = r5;
    Term _h_7 = r6;
    Term _h_8 = r7;
    Term _h_9 = r8;
    WL_OPEN
    if (seq) {
      WL_ROOM(14);
      STK(0) = _f_6;
      STK(1) = _namespace_2;
      STK(2) = _name_2;
      STK(3) = _all_2;
      STK(4) = _h_1;
      STK(5) = _h_2;
      STK(6) = _h_3;
      STK(7) = _h_4;
      STK(8) = _h_5;
      STK(9) = _h_6;
      STK(10) = _h_7;
      STK(11) = _h_8;
      STK(12) = _h_9;
      STK(13) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K227;
      WL_PUSHN(14);
    } else {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K227, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _f_6;
      e.mem[_t_5 + 1] = _namespace_2;
      e.mem[_t_5 + 2] = _name_2;
      e.mem[_t_5 + 3] = _all_2;
      e.mem[_t_5 + 4] = _h_1;
      e.mem[_t_5 + 5] = _h_2;
      e.mem[_t_5 + 6] = _h_3;
      e.mem[_t_5 + 7] = _h_4;
      e.mem[_t_5 + 8] = _h_5;
      e.mem[_t_5 + 9] = _h_6;
      e.mem[_t_5 + 10] = _h_7;
      e.mem[_t_5 + 11] = _h_8;
      e.mem[_t_5 + 12] = _h_9;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K227, _t_5);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_6 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _observations_1;
      e.mem[_t_6 + 1] = term_ctr(CID_CON, STAT_OFF + 10);
      return term_tsk(FID_LIST_APPEND, _t_6);
    }
    r0 = _observations_1;
    r1 = term_ctr(CID_CON, STAT_OFF + 10);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K227)
  {
    WL_POPN(13);
    Term _f_7 = STK(0);
    u32 _namespace_3 = STK(1);
    Term _name_3 = STK(2);
    Term _all_3 = STK(3);
    u32 _h_11 = STK(4);
    u32 _h_12 = STK(5);
    Term _h_13 = STK(6);
    Term _h_14 = STK(7);
    Term _h_15 = STK(8);
    u32 _h_16 = STK(9);
    Term _h_17 = STK(10);
    Term _h_18 = STK(11);
    Term _h_19 = STK(12);
    Term _h_10 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_2 + 0] = _f_7;
    e.mem[_nd_2 + 1] = _namespace_3;
    e.mem[_nd_2 + 2] = _name_3;
    e.mem[_nd_2 + 3] = _all_3;
    Term _next_0 = term_clo(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C228, _nd_2);
    u64 _nd_23 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_23 + 0] = rfc_seal(e, _h_11);
    e.mem[_nd_23 + 1] = rfc_seal(e, _h_12);
    e.mem[_nd_23 + 2] = rfc_seal(e, _h_13);
    e.mem[_nd_23 + 3] = rfc_seal(e, _h_14);
    e.mem[_nd_23 + 4] = rfc_seal(e, _h_15);
    e.mem[_nd_23 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_24 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_24 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_24 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_23));
    Term _b_6 = 0;
    if (_h_16 == 0) {
      _b_6 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
    } else {
      u64 _nd_25 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_25 + 0] = rfc_seal(e, _h_17);
      e.mem[_nd_25 + 1] = rfc_seal(e, _h_18);
      _b_6 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_25);
    }
    u64 _nd_26 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_26 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_24));
    e.mem[_nd_26 + 1] = rfc_seal(e, _b_6);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_19;
      STK(1) = _h_10;
      STK(2) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K232;
      WL_PUSHN(3);
    } else {
      u64 _t_9 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K232, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _h_19;
      e.mem[_t_9 + 1] = _h_10;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K232, _t_9);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_10 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _next_0;
      e.mem[_t_10 + 1] = term_ctr(CID_TUPLE, _nd_26);
      return term_tsk(FID_CLO_APPLY, _t_10);
    }
    r0 = _next_0;
    r1 = term_ctr(CID_TUPLE, _nd_26);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C228)
  {
    Term _f_8 = r0;
    u32 _namespace_4 = r1;
    Term _name_4 = r2;
    Term _all_4 = r3;
    Term _x_0 = r4;
    WL_OPEN
    Term _fb_3[2];
    u64 _sp_3 = ctr_take(e, _x_0, 2, _fb_3);
    Term _f_9 = _fb_3[0];
    Term _f_10 = _fb_3[1];
    spare_free(e, cls_fit(2), _sp_3);
    Term _fb_4[2];
    u64 _sp_4 = ctr_take(e, _f_9, 2, _fb_4);
    Term _f_11 = _fb_4[0];
    Term _f_12 = _fb_4[1];
    spare_free(e, cls_fit(2), _sp_4);
    Term _fb_5[6];
    u64 _sp_5 = ctr_take(e, _f_12, 6, _fb_5);
    u32 _f_13 = _fb_5[0];
    u32 _f_14 = _fb_5[1];
    Term _f_15 = _fb_5[2];
    Term _f_16 = _fb_5[3];
    Term _f_17 = _fb_5[4];
    Term _f_18 = _fb_5[5];
    spare_free(e, cls_fit(6), _sp_5);
    u32 _o_3 = 0;
    Term _o_4 = 0;
    Term _o_5 = 0;
    if (term_aux(_f_10) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
      _o_3 = 0;
    } else {
      _o_3 = 1;
      Term _fb_6[2];
      u64 _sp_6 = ctr_take(e, _f_10, 2, _fb_6);
      Term _f_19 = _fb_6[0];
      Term _f_20 = _fb_6[1];
      spare_free(e, cls_fit(2), _sp_6);
      _o_4 = _f_19;
      _o_5 = _f_20;
    }
    u64 _nd_3 = heap_alloc(e, cls_fit(12));
    e.mem[_nd_3 + 0] = _f_8;
    e.mem[_nd_3 + 1] = _namespace_4;
    e.mem[_nd_3 + 2] = _name_4;
    e.mem[_nd_3 + 3] = _all_4;
    e.mem[_nd_3 + 4] = _f_13;
    e.mem[_nd_3 + 5] = _f_14;
    e.mem[_nd_3 + 6] = _f_15;
    e.mem[_nd_3 + 7] = _f_16;
    e.mem[_nd_3 + 8] = _f_17;
    e.mem[_nd_3 + 9] = _o_3;
    e.mem[_nd_3 + 10] = _o_4;
    e.mem[_nd_3 + 11] = _o_5;
    r0 = term_clo(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C229, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C229)
  {
    Term _f_21 = r0;
    u32 _namespace_5 = r1;
    Term _name_5 = r2;
    Term _all_5 = r3;
    u32 _f_22 = r4;
    u32 _f_23 = r5;
    Term _f_24 = r6;
    Term _f_25 = r7;
    Term _f_26 = r8;
    u32 _o_6 = r9;
    Term _o_7 = r10;
    Term _o_8 = r11;
    Term _x_1 = r12;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_4 + 0] = _f_21;
    e.mem[_nd_4 + 1] = _namespace_5;
    e.mem[_nd_4 + 2] = _name_5;
    e.mem[_nd_4 + 3] = _all_5;
    e.mem[_nd_4 + 4] = _f_22;
    e.mem[_nd_4 + 5] = _f_23;
    e.mem[_nd_4 + 6] = _f_24;
    e.mem[_nd_4 + 7] = _f_25;
    e.mem[_nd_4 + 8] = _f_26;
    e.mem[_nd_4 + 9] = _o_6;
    e.mem[_nd_4 + 10] = _o_7;
    e.mem[_nd_4 + 11] = _o_8;
    e.mem[_nd_4 + 12] = _x_1;
    r0 = term_clo(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C230, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C230)
  {
    Term _f_27 = r0;
    u32 _namespace_6 = r1;
    Term _name_6 = r2;
    Term _all_6 = r3;
    u32 _f_28 = r4;
    u32 _f_29 = r5;
    Term _f_30 = r6;
    Term _f_31 = r7;
    Term _f_32 = r8;
    u32 _o_9 = r9;
    Term _o_10 = r10;
    Term _o_11 = r11;
    Term _x_3 = r12;
    Term _x_2 = r13;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K231;
      WL_PUSHN(1);
    } else {
      u64 _t_7 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K231, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K231, _t_7);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0)) {
      u64 _t_8 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _f_27;
      e.mem[_t_8 + 1] = _f_28;
      e.mem[_t_8 + 2] = _f_29;
      e.mem[_t_8 + 3] = _f_30;
      e.mem[_t_8 + 4] = _f_31;
      e.mem[_t_8 + 5] = _f_32;
      e.mem[_t_8 + 6] = _o_9;
      e.mem[_t_8 + 7] = _o_10;
      e.mem[_t_8 + 8] = _o_11;
      e.mem[_t_8 + 9] = _x_3;
      e.mem[_t_8 + 10] = _namespace_6;
      e.mem[_t_8 + 11] = _name_6;
      e.mem[_t_8 + 12] = _all_6;
      e.mem[_t_8 + 13] = _x_2;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0, _t_8);
    }
    r0 = _f_27;
    r1 = _f_28;
    r2 = _f_29;
    r3 = _f_30;
    r4 = _f_31;
    r5 = _f_32;
    r6 = _o_9;
    r7 = _o_10;
    r8 = _o_11;
    r9 = _x_3;
    r10 = _namespace_6;
    r11 = _name_6;
    r12 = _all_6;
    r13 = _x_2;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K231)
  {
    u32 _r_0 = r0;
    u32 _r_1 = r1;
    Term _r_2 = r2;
    Term _r_3 = r3;
    u32 _r_4 = r4;
    u32 _r_5 = r5;
    Term _r_6 = r6;
    Term _r_7 = r7;
    Term _r_8 = r8;
    u32 _r_9 = r9;
    Term _r_10 = r10;
    Term _r_11 = r11;
    Term _r_12 = r12;
    Term _r_13 = r13;
    u32 _r_14 = r14;
    Term _r_15 = r15;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      u64 _nd_5 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_5 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_5 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_5 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_5 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_5 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_5 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_6 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_6 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_5));
      Term _b_1 = 0;
      if (_r_9 == 0) {
        _b_1 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
      } else {
        u64 _nd_7 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_7 + 0] = rfc_seal(e, _r_10);
        e.mem[_nd_7 + 1] = rfc_seal(e, _r_11);
        _b_1 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_7);
      }
      u64 _nd_8 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_8 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_6));
      e.mem[_nd_8 + 1] = rfc_seal(e, _b_1);
      u64 _nd_9 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_9 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_9 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_9 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_9 + 3] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_8));
      e.mem[_nd_9 + 4] = rfc_seal(e, _r_12);
      e.mem[_nd_9 + 5] = rfc_seal(e, _r_13);
      _b_0 = term_ctr(CID__________SRC_ECS_SCHEDULE_FINISHED, _nd_9);
    } else if (_r_0 == 1) {
      u64 _nd_10 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_10 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_10 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_10 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_10 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_10 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_10 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_11 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_11 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_11 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_10));
      Term _b_2 = 0;
      if (_r_9 == 0) {
        _b_2 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
      } else {
        u64 _nd_12 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_12 + 0] = rfc_seal(e, _r_10);
        e.mem[_nd_12 + 1] = rfc_seal(e, _r_11);
        _b_2 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_12);
      }
      u64 _nd_13 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_13 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_11));
      e.mem[_nd_13 + 1] = rfc_seal(e, _b_2);
      Term _b_3 = 0;
      if (_r_13 == 0) {
        u64 _nd_14 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_14 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
        _b_3 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_14);
      } else {
        Term _b_4 = 0;
        if (_r_14 == 0) {
          u64 _nd_15 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_15 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
          _b_4 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_15);
        } else {
          _b_4 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
        }
        u64 _nd_16 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_16 + 0] = rfc_seal(e, _b_4);
        _b_3 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_16);
      }
      u64 _nd_17 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_17 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_17 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_17 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_17 + 3] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_13));
      e.mem[_nd_17 + 4] = rfc_seal(e, _r_12);
      e.mem[_nd_17 + 5] = rfc_seal(e, _b_3);
      e.mem[_nd_17 + 6] = rfc_seal(e, _r_15);
      _b_0 = term_ctr(CID__________SRC_ECS_SCHEDULE_FAILED, _nd_17);
    } else {
      u64 _nd_18 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_18 + 0] = rfc_seal(e, _r_4);
      e.mem[_nd_18 + 1] = rfc_seal(e, _r_5);
      e.mem[_nd_18 + 2] = rfc_seal(e, _r_6);
      e.mem[_nd_18 + 3] = rfc_seal(e, _r_7);
      e.mem[_nd_18 + 4] = rfc_seal(e, _r_8);
      e.mem[_nd_18 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_19 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_19 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_19 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_18));
      Term _b_5 = 0;
      if (_r_9 == 0) {
        _b_5 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
      } else {
        u64 _nd_20 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_20 + 0] = rfc_seal(e, _r_10);
        e.mem[_nd_20 + 1] = rfc_seal(e, _r_11);
        _b_5 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_20);
      }
      u64 _nd_21 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_21 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_19));
      e.mem[_nd_21 + 1] = rfc_seal(e, _b_5);
      u64 _nd_22 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_22 + 0] = rfc_seal(e, _r_1);
      e.mem[_nd_22 + 1] = rfc_seal(e, _r_2);
      e.mem[_nd_22 + 2] = rfc_seal(e, _r_3);
      e.mem[_nd_22 + 3] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_21));
      e.mem[_nd_22 + 4] = rfc_seal(e, _r_12);
      _b_0 = term_ctr(CID__________SRC_ECS_SCHEDULE_REJECTED, _nd_22);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K232)
  {
    WL_POPN(2);
    Term _h_21 = STK(0);
    Term _h_22 = STK(1);
    Term _h_20 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_22;
      STK(1) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K233;
      WL_PUSHN(2);
    } else {
      u64 _t_11 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K233, WL_CONT, WL_IDX, 1);
      e.mem[_t_11 + 0] = _h_22;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K233, _t_11);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_12 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _h_20;
      e.mem[_t_12 + 1] = _h_21;
      return term_tsk(FID_CLO_APPLY, _t_12);
    }
    r0 = _h_20;
    r1 = _h_21;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K233)
  {
    WL_POPN(1);
    Term _h_24 = STK(0);
    Term _h_23 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K234;
      WL_PUSHN(1);
    } else {
      u64 _t_13 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K234, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K234, _t_13);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_14 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = _h_23;
      e.mem[_t_14 + 1] = _h_24;
      return term_tsk(FID_CLO_APPLY, _t_14);
    }
    r0 = _h_23;
    r1 = _h_24;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K234)
  {
    Term _r_16 = r0;
    WL_OPEN
    u32 _o_12 = 0;
    u32 _o_13 = 0;
    Term _o_14 = 0;
    Term _o_15 = 0;
    u32 _o_16 = 0;
    u32 _o_17 = 0;
    Term _o_18 = 0;
    Term _o_19 = 0;
    Term _o_20 = 0;
    u32 _o_21 = 0;
    Term _o_22 = 0;
    Term _o_23 = 0;
    Term _o_24 = 0;
    Term _o_25 = 0;
    u32 _o_26 = 0;
    Term _o_27 = 0;
    if (term_aux(_r_16) == CID__________SRC_ECS_SCHEDULE_FINISHED) {
      _o_12 = 0;
      Term _fb_7[6];
      u64 _sp_7 = ctr_take(e, _r_16, 6, _fb_7);
      u32 _f_33 = _fb_7[0];
      Term _f_34 = _fb_7[1];
      Term _f_35 = _fb_7[2];
      Term _f_36 = _fb_7[3];
      Term _f_37 = _fb_7[4];
      Term _f_38 = _fb_7[5];
      spare_free(e, cls_fit(6), _sp_7);
      Term _fb_8[2];
      u64 _sp_8 = ctr_take(e, _f_36, 2, _fb_8);
      Term _f_39 = _fb_8[0];
      Term _f_40 = _fb_8[1];
      spare_free(e, cls_fit(2), _sp_8);
      Term _fb_9[2];
      u64 _sp_9 = ctr_take(e, _f_39, 2, _fb_9);
      Term _f_41 = _fb_9[0];
      Term _f_42 = _fb_9[1];
      spare_free(e, cls_fit(2), _sp_9);
      Term _fb_10[6];
      u64 _sp_10 = ctr_take(e, _f_42, 6, _fb_10);
      u32 _f_43 = _fb_10[0];
      u32 _f_44 = _fb_10[1];
      Term _f_45 = _fb_10[2];
      Term _f_46 = _fb_10[3];
      Term _f_47 = _fb_10[4];
      Term _f_48 = _fb_10[5];
      spare_free(e, cls_fit(6), _sp_10);
      u32 _o_28 = 0;
      Term _o_29 = 0;
      Term _o_30 = 0;
      if (term_aux(_f_40) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_28 = 0;
      } else {
        _o_28 = 1;
        Term _fb_11[2];
        u64 _sp_11 = ctr_take(e, _f_40, 2, _fb_11);
        Term _f_49 = _fb_11[0];
        Term _f_50 = _fb_11[1];
        spare_free(e, cls_fit(2), _sp_11);
        _o_29 = _f_49;
        _o_30 = _f_50;
      }
      _o_13 = _f_33;
      _o_14 = _f_34;
      _o_15 = _f_35;
      _o_16 = _f_43;
      _o_17 = _f_44;
      _o_18 = _f_45;
      _o_19 = _f_46;
      _o_20 = _f_47;
      _o_21 = _o_28;
      _o_22 = _o_29;
      _o_23 = _o_30;
      _o_24 = _f_37;
      _o_25 = _f_38;
    } else if (term_aux(_r_16) == CID__________SRC_ECS_SCHEDULE_FAILED) {
      _o_12 = 1;
      Term _fb_12[7];
      u64 _sp_12 = ctr_take(e, _r_16, 7, _fb_12);
      u32 _f_51 = _fb_12[0];
      Term _f_52 = _fb_12[1];
      Term _f_53 = _fb_12[2];
      Term _f_54 = _fb_12[3];
      Term _f_55 = _fb_12[4];
      Term _f_56 = _fb_12[5];
      Term _f_57 = _fb_12[6];
      spare_free(e, cls_fit(7), _sp_12);
      Term _fb_13[2];
      u64 _sp_13 = ctr_take(e, _f_54, 2, _fb_13);
      Term _f_58 = _fb_13[0];
      Term _f_59 = _fb_13[1];
      spare_free(e, cls_fit(2), _sp_13);
      Term _fb_14[2];
      u64 _sp_14 = ctr_take(e, _f_58, 2, _fb_14);
      Term _f_60 = _fb_14[0];
      Term _f_61 = _fb_14[1];
      spare_free(e, cls_fit(2), _sp_14);
      Term _fb_15[6];
      u64 _sp_15 = ctr_take(e, _f_61, 6, _fb_15);
      u32 _f_62 = _fb_15[0];
      u32 _f_63 = _fb_15[1];
      Term _f_64 = _fb_15[2];
      Term _f_65 = _fb_15[3];
      Term _f_66 = _fb_15[4];
      Term _f_67 = _fb_15[5];
      spare_free(e, cls_fit(6), _sp_15);
      u32 _o_31 = 0;
      Term _o_32 = 0;
      Term _o_33 = 0;
      if (term_aux(_f_59) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_31 = 0;
      } else {
        _o_31 = 1;
        Term _fb_16[2];
        u64 _sp_16 = ctr_take(e, _f_59, 2, _fb_16);
        Term _f_68 = _fb_16[0];
        Term _f_69 = _fb_16[1];
        spare_free(e, cls_fit(2), _sp_16);
        _o_32 = _f_68;
        _o_33 = _f_69;
      }
      u32 _o_34 = 0;
      u32 _o_35 = 0;
      if (term_aux(_f_56) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
        _o_34 = 0;
        Term _fb_17[1];
        u64 _sp_17 = ctr_take(e, _f_56, 1, _fb_17);
        Term _f_70 = _fb_17[0];
        spare_free(e, cls_fit(1), _sp_17);
      } else {
        _o_34 = 1;
        Term _fb_18[1];
        u64 _sp_18 = ctr_take(e, _f_56, 1, _fb_18);
        Term _f_71 = _fb_18[0];
        spare_free(e, cls_fit(1), _sp_18);
        u32 _o_36 = 0;
        if (term_aux(_f_71) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
          _o_36 = 0;
          Term _fb_19[1];
          u64 _sp_19 = ctr_take(e, _f_71, 1, _fb_19);
          Term _f_72 = _fb_19[0];
          spare_free(e, cls_fit(1), _sp_19);
        } else {
          _o_36 = 1;
        }
        _o_35 = _o_36;
      }
      _o_13 = _f_51;
      _o_14 = _f_52;
      _o_15 = _f_53;
      _o_16 = _f_62;
      _o_17 = _f_63;
      _o_18 = _f_64;
      _o_19 = _f_65;
      _o_20 = _f_66;
      _o_21 = _o_31;
      _o_22 = _o_32;
      _o_23 = _o_33;
      _o_24 = _f_55;
      _o_25 = _o_34;
      _o_26 = _o_35;
      _o_27 = _f_57;
    } else {
      _o_12 = 2;
      Term _fb_20[5];
      u64 _sp_20 = ctr_take(e, _r_16, 5, _fb_20);
      u32 _f_73 = _fb_20[0];
      Term _f_74 = _fb_20[1];
      Term _f_75 = _fb_20[2];
      Term _f_76 = _fb_20[3];
      Term _f_77 = _fb_20[4];
      spare_free(e, cls_fit(5), _sp_20);
      Term _fb_21[2];
      u64 _sp_21 = ctr_take(e, _f_76, 2, _fb_21);
      Term _f_78 = _fb_21[0];
      Term _f_79 = _fb_21[1];
      spare_free(e, cls_fit(2), _sp_21);
      Term _fb_22[2];
      u64 _sp_22 = ctr_take(e, _f_78, 2, _fb_22);
      Term _f_80 = _fb_22[0];
      Term _f_81 = _fb_22[1];
      spare_free(e, cls_fit(2), _sp_22);
      Term _fb_23[6];
      u64 _sp_23 = ctr_take(e, _f_81, 6, _fb_23);
      u32 _f_82 = _fb_23[0];
      u32 _f_83 = _fb_23[1];
      Term _f_84 = _fb_23[2];
      Term _f_85 = _fb_23[3];
      Term _f_86 = _fb_23[4];
      Term _f_87 = _fb_23[5];
      spare_free(e, cls_fit(6), _sp_23);
      u32 _o_37 = 0;
      Term _o_38 = 0;
      Term _o_39 = 0;
      if (term_aux(_f_79) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_37 = 0;
      } else {
        _o_37 = 1;
        Term _fb_24[2];
        u64 _sp_24 = ctr_take(e, _f_79, 2, _fb_24);
        Term _f_88 = _fb_24[0];
        Term _f_89 = _fb_24[1];
        spare_free(e, cls_fit(2), _sp_24);
        _o_38 = _f_88;
        _o_39 = _f_89;
      }
      _o_13 = _f_73;
      _o_14 = _f_74;
      _o_15 = _f_75;
      _o_16 = _f_82;
      _o_17 = _f_83;
      _o_18 = _f_84;
      _o_19 = _f_85;
      _o_20 = _f_86;
      _o_21 = _o_37;
      _o_22 = _o_38;
      _o_23 = _o_39;
      _o_24 = _f_77;
    }
    r0 = _o_12;
    r1 = _o_13;
    r2 = _o_14;
    r3 = _o_15;
    r4 = _o_16;
    r5 = _o_17;
    r6 = _o_18;
    r7 = _o_19;
    r8 = _o_20;
    r9 = _o_21;
    r10 = _o_22;
    r11 = _o_23;
    r12 = _o_24;
    r13 = _o_25;
    r14 = _o_26;
    r15 = _o_27;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C235)
  {
    Term _f_90 = r0;
    u32 _namespace_7 = r1;
    Term _name_7 = r2;
    Term _all_7 = r3;
    Term _x_4 = r4;
    WL_OPEN
    Term _fb_25[2];
    u64 _sp_25 = ctr_take(e, _x_4, 2, _fb_25);
    Term _f_91 = _fb_25[0];
    Term _f_92 = _fb_25[1];
    spare_free(e, cls_fit(2), _sp_25);
    Term _fb_26[2];
    u64 _sp_26 = ctr_take(e, _f_91, 2, _fb_26);
    Term _f_93 = _fb_26[0];
    Term _f_94 = _fb_26[1];
    spare_free(e, cls_fit(2), _sp_26);
    Term _fb_27[6];
    u64 _sp_27 = ctr_take(e, _f_94, 6, _fb_27);
    u32 _f_95 = _fb_27[0];
    u32 _f_96 = _fb_27[1];
    Term _f_97 = _fb_27[2];
    Term _f_98 = _fb_27[3];
    Term _f_99 = _fb_27[4];
    Term _f_100 = _fb_27[5];
    spare_free(e, cls_fit(6), _sp_27);
    u32 _o_40 = 0;
    Term _o_41 = 0;
    Term _o_42 = 0;
    if (term_aux(_f_92) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
      _o_40 = 0;
    } else {
      _o_40 = 1;
      Term _fb_28[2];
      u64 _sp_28 = ctr_take(e, _f_92, 2, _fb_28);
      Term _f_101 = _fb_28[0];
      Term _f_102 = _fb_28[1];
      spare_free(e, cls_fit(2), _sp_28);
      _o_41 = _f_101;
      _o_42 = _f_102;
    }
    u64 _nd_28 = heap_alloc(e, cls_fit(12));
    e.mem[_nd_28 + 0] = _f_90;
    e.mem[_nd_28 + 1] = _namespace_7;
    e.mem[_nd_28 + 2] = _name_7;
    e.mem[_nd_28 + 3] = _all_7;
    e.mem[_nd_28 + 4] = _f_95;
    e.mem[_nd_28 + 5] = _f_96;
    e.mem[_nd_28 + 6] = _f_97;
    e.mem[_nd_28 + 7] = _f_98;
    e.mem[_nd_28 + 8] = _f_99;
    e.mem[_nd_28 + 9] = _o_40;
    e.mem[_nd_28 + 10] = _o_41;
    e.mem[_nd_28 + 11] = _o_42;
    r0 = term_clo(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C236, _nd_28);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C236)
  {
    Term _f_103 = r0;
    u32 _namespace_8 = r1;
    Term _name_8 = r2;
    Term _all_8 = r3;
    u32 _f_104 = r4;
    u32 _f_105 = r5;
    Term _f_106 = r6;
    Term _f_107 = r7;
    Term _f_108 = r8;
    u32 _o_43 = r9;
    Term _o_44 = r10;
    Term _o_45 = r11;
    Term _x_5 = r12;
    WL_OPEN
    u64 _nd_29 = heap_alloc(e, cls_fit(13));
    e.mem[_nd_29 + 0] = _f_103;
    e.mem[_nd_29 + 1] = _namespace_8;
    e.mem[_nd_29 + 2] = _name_8;
    e.mem[_nd_29 + 3] = _all_8;
    e.mem[_nd_29 + 4] = _f_104;
    e.mem[_nd_29 + 5] = _f_105;
    e.mem[_nd_29 + 6] = _f_106;
    e.mem[_nd_29 + 7] = _f_107;
    e.mem[_nd_29 + 8] = _f_108;
    e.mem[_nd_29 + 9] = _o_43;
    e.mem[_nd_29 + 10] = _o_44;
    e.mem[_nd_29 + 11] = _o_45;
    e.mem[_nd_29 + 12] = _x_5;
    r0 = term_clo(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C237, _nd_29);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_C237)
  {
    Term _f_109 = r0;
    u32 _namespace_9 = r1;
    Term _name_9 = r2;
    Term _all_9 = r3;
    u32 _f_110 = r4;
    u32 _f_111 = r5;
    Term _f_112 = r6;
    Term _f_113 = r7;
    Term _f_114 = r8;
    u32 _o_46 = r9;
    Term _o_47 = r10;
    Term _o_48 = r11;
    Term _x_7 = r12;
    Term _x_6 = r13;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K238;
      WL_PUSHN(1);
    } else {
      u64 _t_15 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K238, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K238, _t_15);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0)) {
      u64 _t_16 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = _f_109;
      e.mem[_t_16 + 1] = _f_110;
      e.mem[_t_16 + 2] = _f_111;
      e.mem[_t_16 + 3] = _f_112;
      e.mem[_t_16 + 4] = _f_113;
      e.mem[_t_16 + 5] = _f_114;
      e.mem[_t_16 + 6] = _o_46;
      e.mem[_t_16 + 7] = _o_47;
      e.mem[_t_16 + 8] = _o_48;
      e.mem[_t_16 + 9] = _x_7;
      e.mem[_t_16 + 10] = _namespace_9;
      e.mem[_t_16 + 11] = _name_9;
      e.mem[_t_16 + 12] = _all_9;
      e.mem[_t_16 + 13] = _x_6;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0, _t_16);
    }
    r0 = _f_109;
    r1 = _f_110;
    r2 = _f_111;
    r3 = _f_112;
    r4 = _f_113;
    r5 = _f_114;
    r6 = _o_46;
    r7 = _o_47;
    r8 = _o_48;
    r9 = _x_7;
    r10 = _namespace_9;
    r11 = _name_9;
    r12 = _all_9;
    r13 = _x_6;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K238)
  {
    u32 _r_17 = r0;
    u32 _r_18 = r1;
    Term _r_19 = r2;
    Term _r_20 = r3;
    u32 _r_21 = r4;
    u32 _r_22 = r5;
    Term _r_23 = r6;
    Term _r_24 = r7;
    Term _r_25 = r8;
    u32 _r_26 = r9;
    Term _r_27 = r10;
    Term _r_28 = r11;
    Term _r_29 = r12;
    Term _r_30 = r13;
    u32 _r_31 = r14;
    Term _r_32 = r15;
    WL_OPEN
    Term _b_7 = 0;
    if (_r_17 == 0) {
      u64 _nd_30 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_30 + 0] = rfc_seal(e, _r_21);
      e.mem[_nd_30 + 1] = rfc_seal(e, _r_22);
      e.mem[_nd_30 + 2] = rfc_seal(e, _r_23);
      e.mem[_nd_30 + 3] = rfc_seal(e, _r_24);
      e.mem[_nd_30 + 4] = rfc_seal(e, _r_25);
      e.mem[_nd_30 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_31 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_31 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_31 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_30));
      Term _b_8 = 0;
      if (_r_26 == 0) {
        _b_8 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
      } else {
        u64 _nd_32 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_32 + 0] = rfc_seal(e, _r_27);
        e.mem[_nd_32 + 1] = rfc_seal(e, _r_28);
        _b_8 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_32);
      }
      u64 _nd_33 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_33 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_31));
      e.mem[_nd_33 + 1] = rfc_seal(e, _b_8);
      u64 _nd_34 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_34 + 0] = rfc_seal(e, _r_18);
      e.mem[_nd_34 + 1] = rfc_seal(e, _r_19);
      e.mem[_nd_34 + 2] = rfc_seal(e, _r_20);
      e.mem[_nd_34 + 3] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_33));
      e.mem[_nd_34 + 4] = rfc_seal(e, _r_29);
      e.mem[_nd_34 + 5] = rfc_seal(e, _r_30);
      _b_7 = term_ctr(CID__________SRC_ECS_SCHEDULE_FINISHED, _nd_34);
    } else if (_r_17 == 1) {
      u64 _nd_35 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_35 + 0] = rfc_seal(e, _r_21);
      e.mem[_nd_35 + 1] = rfc_seal(e, _r_22);
      e.mem[_nd_35 + 2] = rfc_seal(e, _r_23);
      e.mem[_nd_35 + 3] = rfc_seal(e, _r_24);
      e.mem[_nd_35 + 4] = rfc_seal(e, _r_25);
      e.mem[_nd_35 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_36 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_36 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_36 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_35));
      Term _b_9 = 0;
      if (_r_26 == 0) {
        _b_9 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
      } else {
        u64 _nd_37 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_37 + 0] = rfc_seal(e, _r_27);
        e.mem[_nd_37 + 1] = rfc_seal(e, _r_28);
        _b_9 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_37);
      }
      u64 _nd_38 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_38 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_36));
      e.mem[_nd_38 + 1] = rfc_seal(e, _b_9);
      Term _b_10 = 0;
      if (_r_30 == 0) {
        u64 _nd_39 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_39 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
        _b_10 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_39);
      } else {
        Term _b_11 = 0;
        if (_r_31 == 0) {
          u64 _nd_40 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_40 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
          _b_11 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_40);
        } else {
          _b_11 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
        }
        u64 _nd_41 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_41 + 0] = rfc_seal(e, _b_11);
        _b_10 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_41);
      }
      u64 _nd_42 = heap_alloc(e, cls_fit(7));
      e.mem[_nd_42 + 0] = rfc_seal(e, _r_18);
      e.mem[_nd_42 + 1] = rfc_seal(e, _r_19);
      e.mem[_nd_42 + 2] = rfc_seal(e, _r_20);
      e.mem[_nd_42 + 3] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_38));
      e.mem[_nd_42 + 4] = rfc_seal(e, _r_29);
      e.mem[_nd_42 + 5] = rfc_seal(e, _b_10);
      e.mem[_nd_42 + 6] = rfc_seal(e, _r_32);
      _b_7 = term_ctr(CID__________SRC_ECS_SCHEDULE_FAILED, _nd_42);
    } else {
      u64 _nd_43 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_43 + 0] = rfc_seal(e, _r_21);
      e.mem[_nd_43 + 1] = rfc_seal(e, _r_22);
      e.mem[_nd_43 + 2] = rfc_seal(e, _r_23);
      e.mem[_nd_43 + 3] = rfc_seal(e, _r_24);
      e.mem[_nd_43 + 4] = rfc_seal(e, _r_25);
      e.mem[_nd_43 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_44 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_44 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_44 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_43));
      Term _b_12 = 0;
      if (_r_26 == 0) {
        _b_12 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
      } else {
        u64 _nd_45 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_45 + 0] = rfc_seal(e, _r_27);
        e.mem[_nd_45 + 1] = rfc_seal(e, _r_28);
        _b_12 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_45);
      }
      u64 _nd_46 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_46 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_44));
      e.mem[_nd_46 + 1] = rfc_seal(e, _b_12);
      u64 _nd_47 = heap_alloc(e, cls_fit(5));
      e.mem[_nd_47 + 0] = rfc_seal(e, _r_18);
      e.mem[_nd_47 + 1] = rfc_seal(e, _r_19);
      e.mem[_nd_47 + 2] = rfc_seal(e, _r_20);
      e.mem[_nd_47 + 3] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_46));
      e.mem[_nd_47 + 4] = rfc_seal(e, _r_29);
      _b_7 = term_ctr(CID__________SRC_ECS_SCHEDULE_REJECTED, _nd_47);
    }
    r0 = _b_7;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K239)
  {
    WL_POPN(3);
    Term _v_6 = STK(0);
    Term _observations_2 = STK(1);
    u32 _o_50 = STK(2);
    Term _h_25 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _observations_2;
      STK(1) = _o_50;
      STK(2) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K240;
      WL_PUSHN(3);
    } else {
      u64 _t_19 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K240, WL_CONT, WL_IDX, 1);
      e.mem[_t_19 + 0] = _observations_2;
      e.mem[_t_19 + 1] = _o_50;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K240, _t_19);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_20 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = _h_25;
      e.mem[_t_20 + 1] = _v_6;
      return term_tsk(FID_CLO_APPLY, _t_20);
    }
    r0 = _h_25;
    r1 = _v_6;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K240)
  {
    WL_POPN(2);
    Term _observations_3 = STK(0);
    u32 _o_51 = STK(1);
    Term _h_26 = r0;
    WL_OPEN
    u64 _nd_52 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_52 + 0] = rfc_seal(e, term_pak(CID__________SRC_ECS_SCHEDULE_SKIPPED, _o_51));
    e.mem[_nd_52 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_26;
      STK(1) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K241;
      WL_PUSHN(2);
    } else {
      u64 _t_21 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K241, WL_CONT, WL_IDX, 1);
      e.mem[_t_21 + 0] = _h_26;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K241, _t_21);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_22 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = _observations_3;
      e.mem[_t_22 + 1] = term_ctr(CID_CON, _nd_52);
      return term_tsk(FID_LIST_APPEND, _t_22);
    }
    r0 = _observations_3;
    r1 = term_ctr(CID_CON, _nd_52);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K241)
  {
    WL_POPN(1);
    Term _h_28 = STK(0);
    Term _h_27 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K242;
      WL_PUSHN(1);
    } else {
      u64 _t_23 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K242, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K242, _t_23);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_24 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_24 + 0] = _h_28;
      e.mem[_t_24 + 1] = _h_27;
      return term_tsk(FID_CLO_APPLY, _t_24);
    }
    r0 = _h_28;
    r1 = _h_27;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K242)
  {
    Term _r_33 = r0;
    WL_OPEN
    u32 _o_52 = 0;
    u32 _o_53 = 0;
    Term _o_54 = 0;
    Term _o_55 = 0;
    u32 _o_56 = 0;
    u32 _o_57 = 0;
    Term _o_58 = 0;
    Term _o_59 = 0;
    Term _o_60 = 0;
    u32 _o_61 = 0;
    Term _o_62 = 0;
    Term _o_63 = 0;
    Term _o_64 = 0;
    Term _o_65 = 0;
    u32 _o_66 = 0;
    Term _o_67 = 0;
    if (term_aux(_r_33) == CID__________SRC_ECS_SCHEDULE_FINISHED) {
      _o_52 = 0;
      Term _fb_29[6];
      u64 _sp_29 = ctr_take(e, _r_33, 6, _fb_29);
      u32 _f_115 = _fb_29[0];
      Term _f_116 = _fb_29[1];
      Term _f_117 = _fb_29[2];
      Term _f_118 = _fb_29[3];
      Term _f_119 = _fb_29[4];
      Term _f_120 = _fb_29[5];
      spare_free(e, cls_fit(6), _sp_29);
      Term _fb_30[2];
      u64 _sp_30 = ctr_take(e, _f_118, 2, _fb_30);
      Term _f_121 = _fb_30[0];
      Term _f_122 = _fb_30[1];
      spare_free(e, cls_fit(2), _sp_30);
      Term _fb_31[2];
      u64 _sp_31 = ctr_take(e, _f_121, 2, _fb_31);
      Term _f_123 = _fb_31[0];
      Term _f_124 = _fb_31[1];
      spare_free(e, cls_fit(2), _sp_31);
      Term _fb_32[6];
      u64 _sp_32 = ctr_take(e, _f_124, 6, _fb_32);
      u32 _f_125 = _fb_32[0];
      u32 _f_126 = _fb_32[1];
      Term _f_127 = _fb_32[2];
      Term _f_128 = _fb_32[3];
      Term _f_129 = _fb_32[4];
      Term _f_130 = _fb_32[5];
      spare_free(e, cls_fit(6), _sp_32);
      u32 _o_68 = 0;
      Term _o_69 = 0;
      Term _o_70 = 0;
      if (term_aux(_f_122) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_68 = 0;
      } else {
        _o_68 = 1;
        Term _fb_33[2];
        u64 _sp_33 = ctr_take(e, _f_122, 2, _fb_33);
        Term _f_131 = _fb_33[0];
        Term _f_132 = _fb_33[1];
        spare_free(e, cls_fit(2), _sp_33);
        _o_69 = _f_131;
        _o_70 = _f_132;
      }
      _o_53 = _f_115;
      _o_54 = _f_116;
      _o_55 = _f_117;
      _o_56 = _f_125;
      _o_57 = _f_126;
      _o_58 = _f_127;
      _o_59 = _f_128;
      _o_60 = _f_129;
      _o_61 = _o_68;
      _o_62 = _o_69;
      _o_63 = _o_70;
      _o_64 = _f_119;
      _o_65 = _f_120;
    } else if (term_aux(_r_33) == CID__________SRC_ECS_SCHEDULE_FAILED) {
      _o_52 = 1;
      Term _fb_34[7];
      u64 _sp_34 = ctr_take(e, _r_33, 7, _fb_34);
      u32 _f_133 = _fb_34[0];
      Term _f_134 = _fb_34[1];
      Term _f_135 = _fb_34[2];
      Term _f_136 = _fb_34[3];
      Term _f_137 = _fb_34[4];
      Term _f_138 = _fb_34[5];
      Term _f_139 = _fb_34[6];
      spare_free(e, cls_fit(7), _sp_34);
      Term _fb_35[2];
      u64 _sp_35 = ctr_take(e, _f_136, 2, _fb_35);
      Term _f_140 = _fb_35[0];
      Term _f_141 = _fb_35[1];
      spare_free(e, cls_fit(2), _sp_35);
      Term _fb_36[2];
      u64 _sp_36 = ctr_take(e, _f_140, 2, _fb_36);
      Term _f_142 = _fb_36[0];
      Term _f_143 = _fb_36[1];
      spare_free(e, cls_fit(2), _sp_36);
      Term _fb_37[6];
      u64 _sp_37 = ctr_take(e, _f_143, 6, _fb_37);
      u32 _f_144 = _fb_37[0];
      u32 _f_145 = _fb_37[1];
      Term _f_146 = _fb_37[2];
      Term _f_147 = _fb_37[3];
      Term _f_148 = _fb_37[4];
      Term _f_149 = _fb_37[5];
      spare_free(e, cls_fit(6), _sp_37);
      u32 _o_71 = 0;
      Term _o_72 = 0;
      Term _o_73 = 0;
      if (term_aux(_f_141) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_71 = 0;
      } else {
        _o_71 = 1;
        Term _fb_38[2];
        u64 _sp_38 = ctr_take(e, _f_141, 2, _fb_38);
        Term _f_150 = _fb_38[0];
        Term _f_151 = _fb_38[1];
        spare_free(e, cls_fit(2), _sp_38);
        _o_72 = _f_150;
        _o_73 = _f_151;
      }
      u32 _o_74 = 0;
      u32 _o_75 = 0;
      if (term_aux(_f_138) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
        _o_74 = 0;
        Term _fb_39[1];
        u64 _sp_39 = ctr_take(e, _f_138, 1, _fb_39);
        Term _f_152 = _fb_39[0];
        spare_free(e, cls_fit(1), _sp_39);
      } else {
        _o_74 = 1;
        Term _fb_40[1];
        u64 _sp_40 = ctr_take(e, _f_138, 1, _fb_40);
        Term _f_153 = _fb_40[0];
        spare_free(e, cls_fit(1), _sp_40);
        u32 _o_76 = 0;
        if (term_aux(_f_153) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
          _o_76 = 0;
          Term _fb_41[1];
          u64 _sp_41 = ctr_take(e, _f_153, 1, _fb_41);
          Term _f_154 = _fb_41[0];
          spare_free(e, cls_fit(1), _sp_41);
        } else {
          _o_76 = 1;
        }
        _o_75 = _o_76;
      }
      _o_53 = _f_133;
      _o_54 = _f_134;
      _o_55 = _f_135;
      _o_56 = _f_144;
      _o_57 = _f_145;
      _o_58 = _f_146;
      _o_59 = _f_147;
      _o_60 = _f_148;
      _o_61 = _o_71;
      _o_62 = _o_72;
      _o_63 = _o_73;
      _o_64 = _f_137;
      _o_65 = _o_74;
      _o_66 = _o_75;
      _o_67 = _f_139;
    } else {
      _o_52 = 2;
      Term _fb_42[5];
      u64 _sp_42 = ctr_take(e, _r_33, 5, _fb_42);
      u32 _f_155 = _fb_42[0];
      Term _f_156 = _fb_42[1];
      Term _f_157 = _fb_42[2];
      Term _f_158 = _fb_42[3];
      Term _f_159 = _fb_42[4];
      spare_free(e, cls_fit(5), _sp_42);
      Term _fb_43[2];
      u64 _sp_43 = ctr_take(e, _f_158, 2, _fb_43);
      Term _f_160 = _fb_43[0];
      Term _f_161 = _fb_43[1];
      spare_free(e, cls_fit(2), _sp_43);
      Term _fb_44[2];
      u64 _sp_44 = ctr_take(e, _f_160, 2, _fb_44);
      Term _f_162 = _fb_44[0];
      Term _f_163 = _fb_44[1];
      spare_free(e, cls_fit(2), _sp_44);
      Term _fb_45[6];
      u64 _sp_45 = ctr_take(e, _f_163, 6, _fb_45);
      u32 _f_164 = _fb_45[0];
      u32 _f_165 = _fb_45[1];
      Term _f_166 = _fb_45[2];
      Term _f_167 = _fb_45[3];
      Term _f_168 = _fb_45[4];
      Term _f_169 = _fb_45[5];
      spare_free(e, cls_fit(6), _sp_45);
      u32 _o_77 = 0;
      Term _o_78 = 0;
      Term _o_79 = 0;
      if (term_aux(_f_161) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_77 = 0;
      } else {
        _o_77 = 1;
        Term _fb_46[2];
        u64 _sp_46 = ctr_take(e, _f_161, 2, _fb_46);
        Term _f_170 = _fb_46[0];
        Term _f_171 = _fb_46[1];
        spare_free(e, cls_fit(2), _sp_46);
        _o_78 = _f_170;
        _o_79 = _f_171;
      }
      _o_53 = _f_155;
      _o_54 = _f_156;
      _o_55 = _f_157;
      _o_56 = _f_164;
      _o_57 = _f_165;
      _o_58 = _f_166;
      _o_59 = _f_167;
      _o_60 = _f_168;
      _o_61 = _o_77;
      _o_62 = _o_78;
      _o_63 = _o_79;
      _o_64 = _f_159;
    }
    r0 = _o_52;
    r1 = _o_53;
    r2 = _o_54;
    r3 = _o_55;
    r4 = _o_56;
    r5 = _o_57;
    r6 = _o_58;
    r7 = _o_59;
    r8 = _o_60;
    r9 = _o_61;
    r10 = _o_62;
    r11 = _o_63;
    r12 = _o_64;
    r13 = _o_65;
    r14 = _o_66;
    r15 = _o_67;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K243)
  {
    WL_POPN(6);
    Term _next_2 = STK(0);
    u32 _namespace_10 = STK(1);
    Term _name_10 = STK(2);
    Term _all_10 = STK(3);
    Term _observations_4 = STK(4);
    u32 _o_80 = STK(5);
    u32 _h_29 = r0;
    u32 _h_30 = r1;
    Term _h_31 = r2;
    Term _h_32 = r3;
    Term _h_33 = r4;
    u32 _h_34 = r5;
    Term _h_35 = r6;
    Term _h_36 = r7;
    u32 _h_37 = r8;
    Term _h_38 = r9;
    u32 _h_39 = r10;
    u32 _h_40 = r11;
    WL_OPEN
    if (_h_37 == 1) {
      term_sink(e, _next_2);
      u64 _nd_53 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_53 + 0] = rfc_seal(e, term_pak(CID__________SRC_ECS_SCHEDULE_RAN, _o_80));
      e.mem[_nd_53 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      if (seq) {
        WL_ROOM(15);
        STK(0) = _h_38;
        STK(1) = _h_39;
        STK(2) = _h_40;
        STK(3) = _h_29;
        STK(4) = _h_30;
        STK(5) = _h_31;
        STK(6) = _h_32;
        STK(7) = _h_33;
        STK(8) = _h_34;
        STK(9) = _h_35;
        STK(10) = _h_36;
        STK(11) = _namespace_10;
        STK(12) = _name_10;
        STK(13) = _all_10;
        STK(14) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K244;
        WL_PUSHN(15);
      } else {
        u64 _t_27 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K244, WL_CONT, WL_IDX, 1);
        e.mem[_t_27 + 0] = _h_38;
        e.mem[_t_27 + 1] = _h_39;
        e.mem[_t_27 + 2] = _h_40;
        e.mem[_t_27 + 3] = _h_29;
        e.mem[_t_27 + 4] = _h_30;
        e.mem[_t_27 + 5] = _h_31;
        e.mem[_t_27 + 6] = _h_32;
        e.mem[_t_27 + 7] = _h_33;
        e.mem[_t_27 + 8] = _h_34;
        e.mem[_t_27 + 9] = _h_35;
        e.mem[_t_27 + 10] = _h_36;
        e.mem[_t_27 + 11] = _namespace_10;
        e.mem[_t_27 + 12] = _name_10;
        e.mem[_t_27 + 13] = _all_10;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K244, _t_27);
        WL_IDX = 14;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
        u64 _t_28 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_28 + 0] = _observations_4;
        e.mem[_t_28 + 1] = term_ctr(CID_CON, _nd_53);
        return term_tsk(FID_LIST_APPEND, _t_28);
      }
      r0 = _observations_4;
      r1 = term_ctr(CID_CON, _nd_53);
      WL_JMP(FID_LIST_APPEND);
    } else {
      term_sink(e, _name_10);
      term_sink(e, _all_10);
      u64 _nd_54 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_54 + 0] = rfc_seal(e, _h_29);
      e.mem[_nd_54 + 1] = rfc_seal(e, _h_30);
      e.mem[_nd_54 + 2] = rfc_seal(e, _h_31);
      e.mem[_nd_54 + 3] = rfc_seal(e, _h_32);
      e.mem[_nd_54 + 4] = rfc_seal(e, _h_33);
      e.mem[_nd_54 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_55 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_55 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_55 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_54));
      Term _b_14 = 0;
      if (_h_34 == 0) {
        _b_14 = term_pak(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF, 0);
      } else {
        u64 _nd_56 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_56 + 0] = rfc_seal(e, _h_35);
        e.mem[_nd_56 + 1] = rfc_seal(e, _h_36);
        _b_14 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_EXECUTION_ON, _nd_56);
      }
      u64 _nd_57 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_57 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_55));
      e.mem[_nd_57 + 1] = rfc_seal(e, _b_14);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _h_38;
        STK(1) = _observations_4;
        STK(2) = _o_80;
        STK(3) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K245;
        WL_PUSHN(4);
      } else {
        u64 _t_29 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K245, WL_CONT, WL_IDX, 1);
        e.mem[_t_29 + 0] = _h_38;
        e.mem[_t_29 + 1] = _observations_4;
        e.mem[_t_29 + 2] = _o_80;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K245, _t_29);
        WL_IDX = 3;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_30 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_30 + 0] = _next_2;
        e.mem[_t_30 + 1] = term_ctr(CID_TUPLE, _nd_57);
        return term_tsk(FID_CLO_APPLY, _t_30);
      }
      r0 = _next_2;
      r1 = term_ctr(CID_TUPLE, _nd_57);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K244)
  {
    WL_POPN(14);
    Term _h_42 = STK(0);
    u32 _h_43 = STK(1);
    u32 _h_44 = STK(2);
    u32 _h_45 = STK(3);
    u32 _h_46 = STK(4);
    Term _h_47 = STK(5);
    Term _h_48 = STK(6);
    Term _h_49 = STK(7);
    u32 _h_50 = STK(8);
    Term _h_51 = STK(9);
    Term _h_52 = STK(10);
    u32 _namespace_11 = STK(11);
    Term _name_11 = STK(12);
    Term _all_11 = STK(13);
    Term _h_41 = r0;
    WL_OPEN
    r0 = 1;
    r1 = _namespace_11;
    r2 = _name_11;
    r3 = _all_11;
    r4 = _h_45;
    r5 = _h_46;
    r6 = _h_47;
    r7 = _h_48;
    r8 = _h_49;
    r9 = _h_50;
    r10 = _h_51;
    r11 = _h_52;
    r12 = _h_42;
    r13 = _h_43;
    r14 = _h_44;
    r15 = _h_41;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K245)
  {
    WL_POPN(3);
    Term _h_54 = STK(0);
    Term _observations_5 = STK(1);
    u32 _o_81 = STK(2);
    Term _h_53 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _observations_5;
      STK(1) = _o_81;
      STK(2) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K246;
      WL_PUSHN(3);
    } else {
      u64 _t_31 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K246, WL_CONT, WL_IDX, 1);
      e.mem[_t_31 + 0] = _observations_5;
      e.mem[_t_31 + 1] = _o_81;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K246, _t_31);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_32 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_32 + 0] = _h_53;
      e.mem[_t_32 + 1] = _h_54;
      return term_tsk(FID_CLO_APPLY, _t_32);
    }
    r0 = _h_53;
    r1 = _h_54;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K246)
  {
    WL_POPN(2);
    Term _observations_6 = STK(0);
    u32 _o_82 = STK(1);
    Term _h_55 = r0;
    WL_OPEN
    u64 _nd_58 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_58 + 0] = rfc_seal(e, term_pak(CID__________SRC_ECS_SCHEDULE_RAN, _o_82));
    e.mem[_nd_58 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_55;
      STK(1) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K247;
      WL_PUSHN(2);
    } else {
      u64 _t_33 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K247, WL_CONT, WL_IDX, 1);
      e.mem[_t_33 + 0] = _h_55;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K247, _t_33);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_34 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_34 + 0] = _observations_6;
      e.mem[_t_34 + 1] = term_ctr(CID_CON, _nd_58);
      return term_tsk(FID_LIST_APPEND, _t_34);
    }
    r0 = _observations_6;
    r1 = term_ctr(CID_CON, _nd_58);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K247)
  {
    WL_POPN(1);
    Term _h_57 = STK(0);
    Term _h_56 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K248;
      WL_PUSHN(1);
    } else {
      u64 _t_35 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K248, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K248, _t_35);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_36 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_36 + 0] = _h_57;
      e.mem[_t_36 + 1] = _h_56;
      return term_tsk(FID_CLO_APPLY, _t_36);
    }
    r0 = _h_57;
    r1 = _h_56;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0_K248)
  {
    Term _r_34 = r0;
    WL_OPEN
    u32 _o_83 = 0;
    u32 _o_84 = 0;
    Term _o_85 = 0;
    Term _o_86 = 0;
    u32 _o_87 = 0;
    u32 _o_88 = 0;
    Term _o_89 = 0;
    Term _o_90 = 0;
    Term _o_91 = 0;
    u32 _o_92 = 0;
    Term _o_93 = 0;
    Term _o_94 = 0;
    Term _o_95 = 0;
    Term _o_96 = 0;
    u32 _o_97 = 0;
    Term _o_98 = 0;
    if (term_aux(_r_34) == CID__________SRC_ECS_SCHEDULE_FINISHED) {
      _o_83 = 0;
      Term _fb_47[6];
      u64 _sp_47 = ctr_take(e, _r_34, 6, _fb_47);
      u32 _f_172 = _fb_47[0];
      Term _f_173 = _fb_47[1];
      Term _f_174 = _fb_47[2];
      Term _f_175 = _fb_47[3];
      Term _f_176 = _fb_47[4];
      Term _f_177 = _fb_47[5];
      spare_free(e, cls_fit(6), _sp_47);
      Term _fb_48[2];
      u64 _sp_48 = ctr_take(e, _f_175, 2, _fb_48);
      Term _f_178 = _fb_48[0];
      Term _f_179 = _fb_48[1];
      spare_free(e, cls_fit(2), _sp_48);
      Term _fb_49[2];
      u64 _sp_49 = ctr_take(e, _f_178, 2, _fb_49);
      Term _f_180 = _fb_49[0];
      Term _f_181 = _fb_49[1];
      spare_free(e, cls_fit(2), _sp_49);
      Term _fb_50[6];
      u64 _sp_50 = ctr_take(e, _f_181, 6, _fb_50);
      u32 _f_182 = _fb_50[0];
      u32 _f_183 = _fb_50[1];
      Term _f_184 = _fb_50[2];
      Term _f_185 = _fb_50[3];
      Term _f_186 = _fb_50[4];
      Term _f_187 = _fb_50[5];
      spare_free(e, cls_fit(6), _sp_50);
      u32 _o_99 = 0;
      Term _o_100 = 0;
      Term _o_101 = 0;
      if (term_aux(_f_179) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_99 = 0;
      } else {
        _o_99 = 1;
        Term _fb_51[2];
        u64 _sp_51 = ctr_take(e, _f_179, 2, _fb_51);
        Term _f_188 = _fb_51[0];
        Term _f_189 = _fb_51[1];
        spare_free(e, cls_fit(2), _sp_51);
        _o_100 = _f_188;
        _o_101 = _f_189;
      }
      _o_84 = _f_172;
      _o_85 = _f_173;
      _o_86 = _f_174;
      _o_87 = _f_182;
      _o_88 = _f_183;
      _o_89 = _f_184;
      _o_90 = _f_185;
      _o_91 = _f_186;
      _o_92 = _o_99;
      _o_93 = _o_100;
      _o_94 = _o_101;
      _o_95 = _f_176;
      _o_96 = _f_177;
    } else if (term_aux(_r_34) == CID__________SRC_ECS_SCHEDULE_FAILED) {
      _o_83 = 1;
      Term _fb_52[7];
      u64 _sp_52 = ctr_take(e, _r_34, 7, _fb_52);
      u32 _f_190 = _fb_52[0];
      Term _f_191 = _fb_52[1];
      Term _f_192 = _fb_52[2];
      Term _f_193 = _fb_52[3];
      Term _f_194 = _fb_52[4];
      Term _f_195 = _fb_52[5];
      Term _f_196 = _fb_52[6];
      spare_free(e, cls_fit(7), _sp_52);
      Term _fb_53[2];
      u64 _sp_53 = ctr_take(e, _f_193, 2, _fb_53);
      Term _f_197 = _fb_53[0];
      Term _f_198 = _fb_53[1];
      spare_free(e, cls_fit(2), _sp_53);
      Term _fb_54[2];
      u64 _sp_54 = ctr_take(e, _f_197, 2, _fb_54);
      Term _f_199 = _fb_54[0];
      Term _f_200 = _fb_54[1];
      spare_free(e, cls_fit(2), _sp_54);
      Term _fb_55[6];
      u64 _sp_55 = ctr_take(e, _f_200, 6, _fb_55);
      u32 _f_201 = _fb_55[0];
      u32 _f_202 = _fb_55[1];
      Term _f_203 = _fb_55[2];
      Term _f_204 = _fb_55[3];
      Term _f_205 = _fb_55[4];
      Term _f_206 = _fb_55[5];
      spare_free(e, cls_fit(6), _sp_55);
      u32 _o_102 = 0;
      Term _o_103 = 0;
      Term _o_104 = 0;
      if (term_aux(_f_198) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_102 = 0;
      } else {
        _o_102 = 1;
        Term _fb_56[2];
        u64 _sp_56 = ctr_take(e, _f_198, 2, _fb_56);
        Term _f_207 = _fb_56[0];
        Term _f_208 = _fb_56[1];
        spare_free(e, cls_fit(2), _sp_56);
        _o_103 = _f_207;
        _o_104 = _f_208;
      }
      u32 _o_105 = 0;
      u32 _o_106 = 0;
      if (term_aux(_f_195) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
        _o_105 = 0;
        Term _fb_57[1];
        u64 _sp_57 = ctr_take(e, _f_195, 1, _fb_57);
        Term _f_209 = _fb_57[0];
        spare_free(e, cls_fit(1), _sp_57);
      } else {
        _o_105 = 1;
        Term _fb_58[1];
        u64 _sp_58 = ctr_take(e, _f_195, 1, _fb_58);
        Term _f_210 = _fb_58[0];
        spare_free(e, cls_fit(1), _sp_58);
        u32 _o_107 = 0;
        if (term_aux(_f_210) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
          _o_107 = 0;
          Term _fb_59[1];
          u64 _sp_59 = ctr_take(e, _f_210, 1, _fb_59);
          Term _f_211 = _fb_59[0];
          spare_free(e, cls_fit(1), _sp_59);
        } else {
          _o_107 = 1;
        }
        _o_106 = _o_107;
      }
      _o_84 = _f_190;
      _o_85 = _f_191;
      _o_86 = _f_192;
      _o_87 = _f_201;
      _o_88 = _f_202;
      _o_89 = _f_203;
      _o_90 = _f_204;
      _o_91 = _f_205;
      _o_92 = _o_102;
      _o_93 = _o_103;
      _o_94 = _o_104;
      _o_95 = _f_194;
      _o_96 = _o_105;
      _o_97 = _o_106;
      _o_98 = _f_196;
    } else {
      _o_83 = 2;
      Term _fb_60[5];
      u64 _sp_60 = ctr_take(e, _r_34, 5, _fb_60);
      u32 _f_212 = _fb_60[0];
      Term _f_213 = _fb_60[1];
      Term _f_214 = _fb_60[2];
      Term _f_215 = _fb_60[3];
      Term _f_216 = _fb_60[4];
      spare_free(e, cls_fit(5), _sp_60);
      Term _fb_61[2];
      u64 _sp_61 = ctr_take(e, _f_215, 2, _fb_61);
      Term _f_217 = _fb_61[0];
      Term _f_218 = _fb_61[1];
      spare_free(e, cls_fit(2), _sp_61);
      Term _fb_62[2];
      u64 _sp_62 = ctr_take(e, _f_217, 2, _fb_62);
      Term _f_219 = _fb_62[0];
      Term _f_220 = _fb_62[1];
      spare_free(e, cls_fit(2), _sp_62);
      Term _fb_63[6];
      u64 _sp_63 = ctr_take(e, _f_220, 6, _fb_63);
      u32 _f_221 = _fb_63[0];
      u32 _f_222 = _fb_63[1];
      Term _f_223 = _fb_63[2];
      Term _f_224 = _fb_63[3];
      Term _f_225 = _fb_63[4];
      Term _f_226 = _fb_63[5];
      spare_free(e, cls_fit(6), _sp_63);
      u32 _o_108 = 0;
      Term _o_109 = 0;
      Term _o_110 = 0;
      if (term_aux(_f_218) == CID__________SRC_ECS_ORDINARY_APP_EXECUTION_OFF) {
        _o_108 = 0;
      } else {
        _o_108 = 1;
        Term _fb_64[2];
        u64 _sp_64 = ctr_take(e, _f_218, 2, _fb_64);
        Term _f_227 = _fb_64[0];
        Term _f_228 = _fb_64[1];
        spare_free(e, cls_fit(2), _sp_64);
        _o_109 = _f_227;
        _o_110 = _f_228;
      }
      _o_84 = _f_212;
      _o_85 = _f_213;
      _o_86 = _f_214;
      _o_87 = _f_221;
      _o_88 = _f_222;
      _o_89 = _f_223;
      _o_90 = _f_224;
      _o_91 = _f_225;
      _o_92 = _o_108;
      _o_93 = _o_109;
      _o_94 = _o_110;
      _o_95 = _f_216;
    }
    r0 = _o_83;
    r1 = _o_84;
    r2 = _o_85;
    r3 = _o_86;
    r4 = _o_87;
    r5 = _o_88;
    r6 = _o_89;
    r7 = _o_90;
    r8 = _o_91;
    r9 = _o_92;
    r10 = _o_93;
    r11 = _o_94;
    r12 = _o_95;
    r13 = _o_96;
    r14 = _o_97;
    r15 = _o_98;
    WL_RETN(16);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_ACCESS_EQUAL)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      if (term_aux(_ys_0) == CID_NIL) {
        r0 = 1;
        WL_RETN(1);
      } else {
        u64 _sp_0 = term_peek(e.mem, _ys_0);
        Term _f_0 = e.mem[_sp_0 + 0];
        Term _f_1 = e.mem[_sp_0 + 1];
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      u64 _sp_1 = term_peek(e.mem, _xs_0);
      Term _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      if (term_aux(_ys_0) == CID_NIL) {
        r0 = 0;
        WL_RETN(1);
      } else {
        u64 _sp_2 = term_peek(e.mem, _ys_0);
        Term _f_4 = e.mem[_sp_2 + 0];
        Term _f_5 = e.mem[_sp_2 + 1];
        if (seq) {
          WL_ROOM(3);
          STK(0) = _f_2;
          STK(1) = _f_4;
          STK(2) = FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K258;
          WL_PUSHN(3);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K258, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_2;
          e.mem[_t_0 + 1] = _f_4;
          WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K258, _t_0);
          WL_IDX = 2;
        }
        r0 = _f_3;
        r1 = _f_5;
        _xs_0 = r0;
        _ys_0 = r1;
        WL_AGAIN(FID__________SRC_ECS_WORLD_ACCESS_EQUAL);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_ACCESS_EQUAL_K258)
  {
    WL_POPN(2);
    Term _f_6 = STK(0);
    Term _f_7 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_3[1];
    if (spin_65(e, _o_3, _f_6, blk_loc(e.mem, _f_6), _f_7, blk_loc(e.mem, _f_7)) == 0) {
      return 0;
    }
    _v_1 = _o_3[0];
    _v_0 = _v_1;
    u32 _v_9 = 0;
    Term _o_4[1];
    if (spin_30(e, _o_4, _v_0, _h_0) == 0) {
      return 0;
    }
    _v_9 = _o_4[0];
    r0 = _v_9;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0)
  {
    Term _journal_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_journal_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      r1 = term_pak(CID_NIL, 0);
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _journal_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      Term _o_4 = 0;
      u32 _o_5 = 0;
      Term _o_6 = 0;
      Term _o_7 = 0;
      Term _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      Term _o_11 = 0;
      Term _o_12 = 0;
      u32 _o_13 = 0;
      Term _o_14 = 0;
      Term _o_15 = 0;
      Term _o_16 = 0;
      u32 _o_17 = 0;
      u32 _o_18 = 0;
      Term _o_19 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULESTARTED) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_PHASEENTERED) {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_4;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMCOMPLETED) {
        _o_0 = 2;
        Term _fb_3[8];
        u64 _sp_3 = ctr_take(e, _f_0, 8, _fb_3);
        u32 _f_5 = _fb_3[0];
        u32 _f_6 = _fb_3[1];
        u32 _f_7 = _fb_3[2];
        Term _f_8 = _fb_3[3];
        u32 _f_9 = _fb_3[4];
        u32 _f_10 = _fb_3[5];
        u32 _f_11 = _fb_3[6];
        Term _f_12 = _fb_3[7];
        spare_free(e, cls_fit(8), _sp_3);
        u32 _o_20 = 0;
        u32 _o_21 = 0;
        u32 _o_22 = 0;
        if (_f_11 == 0) {
          _o_20 = 0;
        } else {
          _o_20 = 1;
          u32 _o_23 = 0;
          u32 _o_24 = 0;
          if (term_aux(_f_12) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
            _o_23 = 0;
            Term _fb_4[1];
            u64 _sp_4 = ctr_take(e, _f_12, 1, _fb_4);
            Term _f_13 = _fb_4[0];
            spare_free(e, cls_fit(1), _sp_4);
          } else {
            _o_23 = 1;
            Term _fb_5[1];
            u64 _sp_5 = ctr_take(e, _f_12, 1, _fb_5);
            Term _f_14 = _fb_5[0];
            spare_free(e, cls_fit(1), _sp_5);
            u32 _o_25 = 0;
            if (term_aux(_f_14) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
              _o_25 = 0;
              Term _fb_6[1];
              u64 _sp_6 = ctr_take(e, _f_14, 1, _fb_6);
              Term _f_15 = _fb_6[0];
              spare_free(e, cls_fit(1), _sp_6);
            } else {
              _o_25 = 1;
            }
            _o_24 = _o_25;
          }
          _o_21 = _o_23;
          _o_22 = _o_24;
        }
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
        _o_5 = _f_9;
        _o_6 = _f_10;
        _o_7 = _o_20;
        _o_8 = _o_21;
        _o_9 = _o_22;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_OPERATIONOBSERVED) {
        _o_0 = 3;
        Term _fb_7[19];
        u64 _sp_7 = ctr_take(e, _f_0, 19, _fb_7);
        u32 _f_16 = _fb_7[0];
        u32 _f_17 = _fb_7[1];
        u32 _f_18 = _fb_7[2];
        Term _f_19 = _fb_7[3];
        u32 _f_20 = _fb_7[4];
        Term _f_21 = _fb_7[5];
        Term _f_22 = _fb_7[6];
        Term _f_23 = _fb_7[7];
        u32 _f_24 = _fb_7[8];
        Term _f_25 = _fb_7[9];
        u32 _f_26 = _fb_7[10];
        Term _f_27 = _fb_7[11];
        u32 _f_28 = _fb_7[12];
        Term _f_29 = _fb_7[13];
        Term _f_30 = _fb_7[14];
        Term _f_31 = _fb_7[15];
        u32 _f_32 = _fb_7[16];
        u32 _f_33 = _fb_7[17];
        Term _f_34 = _fb_7[18];
        spare_free(e, cls_fit(19), _sp_7);
        _o_1 = _f_16;
        _o_2 = _f_17;
        _o_3 = _f_18;
        _o_4 = _f_19;
        _o_5 = _f_20;
        _o_6 = _f_21;
        _o_7 = _f_22;
        _o_8 = _f_23;
        _o_9 = _f_24;
        _o_10 = _f_25;
        _o_11 = _f_26;
        _o_12 = _f_27;
        _o_13 = _f_28;
        _o_14 = _f_29;
        _o_15 = _f_30;
        _o_16 = _f_31;
        _o_17 = _f_32;
        _o_18 = _f_33;
        _o_19 = _f_34;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_BARRIEROPERATIONOBSERVED) {
        _o_0 = 4;
        Term _fb_8[15];
        u64 _sp_8 = ctr_take(e, _f_0, 15, _fb_8);
        u32 _f_35 = _fb_8[0];
        Term _f_36 = _fb_8[1];
        Term _f_37 = _fb_8[2];
        Term _f_38 = _fb_8[3];
        u32 _f_39 = _fb_8[4];
        Term _f_40 = _fb_8[5];
        u32 _f_41 = _fb_8[6];
        Term _f_42 = _fb_8[7];
        u32 _f_43 = _fb_8[8];
        Term _f_44 = _fb_8[9];
        Term _f_45 = _fb_8[10];
        Term _f_46 = _fb_8[11];
        u32 _f_47 = _fb_8[12];
        u32 _f_48 = _fb_8[13];
        Term _f_49 = _fb_8[14];
        spare_free(e, cls_fit(15), _sp_8);
        _o_1 = _f_35;
        _o_2 = _f_36;
        _o_3 = _f_37;
        _o_4 = _f_38;
        _o_5 = _f_39;
        _o_6 = _f_40;
        _o_7 = _f_41;
        _o_8 = _f_42;
        _o_9 = _f_43;
        _o_10 = _f_44;
        _o_11 = _f_45;
        _o_12 = _f_46;
        _o_13 = _f_47;
        _o_14 = _f_48;
        _o_15 = _f_49;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_EXECUTIONOPERATIONOBSERVED) {
        _o_0 = 5;
        Term _fb_9[15];
        u64 _sp_9 = ctr_take(e, _f_0, 15, _fb_9);
        u32 _f_50 = _fb_9[0];
        Term _f_51 = _fb_9[1];
        Term _f_52 = _fb_9[2];
        Term _f_53 = _fb_9[3];
        u32 _f_54 = _fb_9[4];
        Term _f_55 = _fb_9[5];
        u32 _f_56 = _fb_9[6];
        Term _f_57 = _fb_9[7];
        u32 _f_58 = _fb_9[8];
        Term _f_59 = _fb_9[9];
        Term _f_60 = _fb_9[10];
        Term _f_61 = _fb_9[11];
        u32 _f_62 = _fb_9[12];
        u32 _f_63 = _fb_9[13];
        Term _f_64 = _fb_9[14];
        spare_free(e, cls_fit(15), _sp_9);
        _o_1 = _f_50;
        _o_2 = _f_51;
        _o_3 = _f_52;
        _o_4 = _f_53;
        _o_5 = _f_54;
        _o_6 = _f_55;
        _o_7 = _f_56;
        _o_8 = _f_57;
        _o_9 = _f_58;
        _o_10 = _f_59;
        _o_11 = _f_60;
        _o_12 = _f_61;
        _o_13 = _f_62;
        _o_14 = _f_63;
        _o_15 = _f_64;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMSKIPPED) {
        _o_0 = 6;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_DEFERREDAPPLIED) {
        _o_0 = 7;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEENDED) {
        _o_0 = 8;
        Term _fb_10[2];
        u64 _sp_10 = ctr_take(e, _f_0, 2, _fb_10);
        u32 _f_65 = _fb_10[0];
        Term _f_66 = _fb_10[1];
        spare_free(e, cls_fit(2), _sp_10);
        u32 _o_26 = 0;
        u32 _o_27 = 0;
        u32 _o_28 = 0;
        if (_f_65 == 0) {
          _o_26 = 0;
        } else if (_f_65 == 1) {
          _o_26 = 1;
          u32 _o_29 = 0;
          u32 _o_30 = 0;
          if (term_aux(_f_66) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
            _o_29 = 0;
            Term _fb_11[1];
            u64 _sp_11 = ctr_take(e, _f_66, 1, _fb_11);
            Term _f_67 = _fb_11[0];
            spare_free(e, cls_fit(1), _sp_11);
          } else {
            _o_29 = 1;
            Term _fb_12[1];
            u64 _sp_12 = ctr_take(e, _f_66, 1, _fb_12);
            Term _f_68 = _fb_12[0];
            spare_free(e, cls_fit(1), _sp_12);
            u32 _o_31 = 0;
            if (term_aux(_f_68) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
              _o_31 = 0;
              Term _fb_13[1];
              u64 _sp_13 = ctr_take(e, _f_68, 1, _fb_13);
              Term _f_69 = _fb_13[0];
              spare_free(e, cls_fit(1), _sp_13);
            } else {
              _o_31 = 1;
            }
            _o_30 = _o_31;
          }
          _o_27 = _o_29;
          _o_28 = _o_30;
        } else if (_f_65 == 2) {
          _o_26 = 2;
        } else {
          _o_26 = 3;
        }
        _o_1 = _o_26;
        _o_2 = _o_27;
        _o_3 = _o_28;
      } else {
        _o_0 = 9;
        Term _fb_14[4];
        u64 _sp_14 = ctr_take(e, _f_0, 4, _fb_14);
        u32 _f_70 = _fb_14[0];
        Term _f_71 = _fb_14[1];
        u32 _f_72 = _fb_14[2];
        Term _f_73 = _fb_14[3];
        spare_free(e, cls_fit(4), _sp_14);
        u32 _o_32 = 0;
        u32 _o_33 = 0;
        u32 _o_34 = 0;
        if (_f_72 == 0) {
          _o_32 = 0;
        } else if (_f_72 == 1) {
          _o_32 = 1;
          u32 _o_35 = 0;
          u32 _o_36 = 0;
          if (term_aux(_f_73) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
            _o_35 = 0;
            Term _fb_15[1];
            u64 _sp_15 = ctr_take(e, _f_73, 1, _fb_15);
            Term _f_74 = _fb_15[0];
            spare_free(e, cls_fit(1), _sp_15);
          } else {
            _o_35 = 1;
            Term _fb_16[1];
            u64 _sp_16 = ctr_take(e, _f_73, 1, _fb_16);
            Term _f_75 = _fb_16[0];
            spare_free(e, cls_fit(1), _sp_16);
            u32 _o_37 = 0;
            if (term_aux(_f_75) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
              _o_37 = 0;
              Term _fb_17[1];
              u64 _sp_17 = ctr_take(e, _f_75, 1, _fb_17);
              Term _f_76 = _fb_17[0];
              spare_free(e, cls_fit(1), _sp_17);
            } else {
              _o_37 = 1;
            }
            _o_36 = _o_37;
          }
          _o_33 = _o_35;
          _o_34 = _o_36;
        } else if (_f_72 == 2) {
          _o_32 = 2;
        } else {
          _o_32 = 3;
        }
        _o_1 = _f_70;
        _o_2 = _f_71;
        _o_3 = _o_32;
        _o_4 = _o_33;
        _o_5 = _o_34;
      }
      if (_o_0 == 3) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(20);
          STK(0) = _o_1;
          STK(1) = _o_2;
          STK(2) = _o_3;
          STK(3) = _o_4;
          STK(4) = _o_5;
          STK(5) = _o_6;
          STK(6) = _o_7;
          STK(7) = _o_8;
          STK(8) = _o_9;
          STK(9) = _o_10;
          STK(10) = _o_11;
          STK(11) = _o_12;
          STK(12) = _o_13;
          STK(13) = _o_14;
          STK(14) = _o_15;
          STK(15) = _o_16;
          STK(16) = _o_17;
          STK(17) = _o_18;
          STK(18) = _o_19;
          STK(19) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0_K265;
          WL_PUSHN(20);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0_K265, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          e.mem[_t_0 + 1] = _o_2;
          e.mem[_t_0 + 2] = _o_3;
          e.mem[_t_0 + 3] = _o_4;
          e.mem[_t_0 + 4] = _o_5;
          e.mem[_t_0 + 5] = _o_6;
          e.mem[_t_0 + 6] = _o_7;
          e.mem[_t_0 + 7] = _o_8;
          e.mem[_t_0 + 8] = _o_9;
          e.mem[_t_0 + 9] = _o_10;
          e.mem[_t_0 + 10] = _o_11;
          e.mem[_t_0 + 11] = _o_12;
          e.mem[_t_0 + 12] = _o_13;
          e.mem[_t_0 + 13] = _o_14;
          e.mem[_t_0 + 14] = _o_15;
          e.mem[_t_0 + 15] = _o_16;
          e.mem[_t_0 + 16] = _o_17;
          e.mem[_t_0 + 17] = _o_18;
          e.mem[_t_0 + 18] = _o_19;
          WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0_K265, _t_0);
          WL_IDX = 19;
        }
        r0 = _f_1;
        _journal_0 = r0;
        WL_AGAIN(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0);
      } else {
        Term _b_7 = 0;
        if (_o_0 == 0) {
          u64 _nd_18 = heap_alloc(e, cls_fit(2));
          e.mem[_nd_18 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_18 + 1] = rfc_seal(e, _o_2);
          _b_7 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULESTARTED, _nd_18);
        } else if (_o_0 == 1) {
          u64 _nd_19 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_19 + 0] = rfc_seal(e, _o_1);
          _b_7 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_PHASEENTERED, _nd_19);
        } else if (_o_0 == 2) {
          u32 _o_64 = 0;
          Term _o_65 = 0;
          if (_o_7 == 0) {
            _o_64 = 0;
          } else {
            _o_64 = 1;
            Term _b_8 = 0;
            if (_o_8 == 0) {
              u64 _nd_20 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_20 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
              _b_8 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_20);
            } else {
              Term _b_9 = 0;
              if (_o_9 == 0) {
                u64 _nd_21 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_21 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
                _b_9 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_21);
              } else {
                _b_9 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
              }
              u64 _nd_22 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_22 + 0] = rfc_seal(e, _b_9);
              _b_8 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_22);
            }
            _o_65 = _b_8;
          }
          u64 _nd_23 = heap_alloc(e, cls_fit(8));
          e.mem[_nd_23 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_23 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_23 + 2] = rfc_seal(e, _o_3);
          e.mem[_nd_23 + 3] = rfc_seal(e, _o_4);
          e.mem[_nd_23 + 4] = rfc_seal(e, _o_5);
          e.mem[_nd_23 + 5] = rfc_seal(e, _o_6);
          e.mem[_nd_23 + 6] = rfc_seal(e, _o_64);
          e.mem[_nd_23 + 7] = rfc_seal(e, _o_65);
          _b_7 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMCOMPLETED, _nd_23);
        } else if (_o_0 == 3) {
          u64 _nd_24 = heap_alloc(e, cls_fit(19));
          e.mem[_nd_24 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_24 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_24 + 2] = rfc_seal(e, _o_3);
          e.mem[_nd_24 + 3] = rfc_seal(e, _o_4);
          e.mem[_nd_24 + 4] = rfc_seal(e, _o_5);
          e.mem[_nd_24 + 5] = rfc_seal(e, _o_6);
          e.mem[_nd_24 + 6] = rfc_seal(e, _o_7);
          e.mem[_nd_24 + 7] = rfc_seal(e, _o_8);
          e.mem[_nd_24 + 8] = rfc_seal(e, _o_9);
          e.mem[_nd_24 + 9] = rfc_seal(e, _o_10);
          e.mem[_nd_24 + 10] = rfc_seal(e, _o_11);
          e.mem[_nd_24 + 11] = rfc_seal(e, _o_12);
          e.mem[_nd_24 + 12] = rfc_seal(e, _o_13);
          e.mem[_nd_24 + 13] = rfc_seal(e, _o_14);
          e.mem[_nd_24 + 14] = rfc_seal(e, _o_15);
          e.mem[_nd_24 + 15] = rfc_seal(e, _o_16);
          e.mem[_nd_24 + 16] = rfc_seal(e, _o_17);
          e.mem[_nd_24 + 17] = rfc_seal(e, _o_18);
          e.mem[_nd_24 + 18] = rfc_seal(e, _o_19);
          _b_7 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_OPERATIONOBSERVED, _nd_24);
        } else if (_o_0 == 4) {
          u64 _nd_25 = heap_alloc(e, cls_fit(15));
          e.mem[_nd_25 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_25 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_25 + 2] = rfc_seal(e, _o_3);
          e.mem[_nd_25 + 3] = rfc_seal(e, _o_4);
          e.mem[_nd_25 + 4] = rfc_seal(e, _o_5);
          e.mem[_nd_25 + 5] = rfc_seal(e, _o_6);
          e.mem[_nd_25 + 6] = rfc_seal(e, _o_7);
          e.mem[_nd_25 + 7] = rfc_seal(e, _o_8);
          e.mem[_nd_25 + 8] = rfc_seal(e, _o_9);
          e.mem[_nd_25 + 9] = rfc_seal(e, _o_10);
          e.mem[_nd_25 + 10] = rfc_seal(e, _o_11);
          e.mem[_nd_25 + 11] = rfc_seal(e, _o_12);
          e.mem[_nd_25 + 12] = rfc_seal(e, _o_13);
          e.mem[_nd_25 + 13] = rfc_seal(e, _o_14);
          e.mem[_nd_25 + 14] = rfc_seal(e, _o_15);
          _b_7 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_BARRIEROPERATIONOBSERVED, _nd_25);
        } else if (_o_0 == 5) {
          u64 _nd_26 = heap_alloc(e, cls_fit(15));
          e.mem[_nd_26 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_26 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_26 + 2] = rfc_seal(e, _o_3);
          e.mem[_nd_26 + 3] = rfc_seal(e, _o_4);
          e.mem[_nd_26 + 4] = rfc_seal(e, _o_5);
          e.mem[_nd_26 + 5] = rfc_seal(e, _o_6);
          e.mem[_nd_26 + 6] = rfc_seal(e, _o_7);
          e.mem[_nd_26 + 7] = rfc_seal(e, _o_8);
          e.mem[_nd_26 + 8] = rfc_seal(e, _o_9);
          e.mem[_nd_26 + 9] = rfc_seal(e, _o_10);
          e.mem[_nd_26 + 10] = rfc_seal(e, _o_11);
          e.mem[_nd_26 + 11] = rfc_seal(e, _o_12);
          e.mem[_nd_26 + 12] = rfc_seal(e, _o_13);
          e.mem[_nd_26 + 13] = rfc_seal(e, _o_14);
          e.mem[_nd_26 + 14] = rfc_seal(e, _o_15);
          _b_7 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_EXECUTIONOPERATIONOBSERVED, _nd_26);
        } else if (_o_0 == 6) {
          _b_7 = term_pak(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMSKIPPED, _o_1);
        } else if (_o_0 == 7) {
          _b_7 = term_pak(CID__________SRC_ECS_EXECUTION_TRACE_DEFERREDAPPLIED, 0);
        } else if (_o_0 == 8) {
          u32 _o_66 = 0;
          Term _o_67 = 0;
          if (_o_1 == 0) {
            _o_66 = 0;
          } else if (_o_1 == 1) {
            _o_66 = 1;
            Term _b_10 = 0;
            if (_o_2 == 0) {
              u64 _nd_27 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_27 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
              _b_10 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_27);
            } else {
              Term _b_11 = 0;
              if (_o_3 == 0) {
                u64 _nd_28 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_28 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
                _b_11 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_28);
              } else {
                _b_11 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
              }
              u64 _nd_29 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_29 + 0] = rfc_seal(e, _b_11);
              _b_10 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_29);
            }
            _o_67 = _b_10;
          } else if (_o_1 == 2) {
            _o_66 = 2;
          } else {
            _o_66 = 3;
          }
          u64 _nd_30 = heap_alloc(e, cls_fit(2));
          e.mem[_nd_30 + 0] = rfc_seal(e, _o_66);
          e.mem[_nd_30 + 1] = rfc_seal(e, _o_67);
          _b_7 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEENDED, _nd_30);
        } else {
          u32 _o_68 = 0;
          Term _o_69 = 0;
          if (_o_3 == 0) {
            _o_68 = 0;
          } else if (_o_3 == 1) {
            _o_68 = 1;
            Term _b_12 = 0;
            if (_o_4 == 0) {
              u64 _nd_31 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_31 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
              _b_12 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_31);
            } else {
              Term _b_13 = 0;
              if (_o_5 == 0) {
                u64 _nd_32 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_32 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
                _b_13 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_32);
              } else {
                _b_13 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
              }
              u64 _nd_33 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_33 + 0] = rfc_seal(e, _b_13);
              _b_12 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_33);
            }
            _o_69 = _b_12;
          } else if (_o_3 == 2) {
            _o_68 = 2;
          } else {
            _o_68 = 3;
          }
          u64 _nd_34 = heap_alloc(e, cls_fit(4));
          e.mem[_nd_34 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_34 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_34 + 2] = rfc_seal(e, _o_68);
          e.mem[_nd_34 + 3] = rfc_seal(e, _o_69);
          _b_7 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEADMISSIONREFUSED, _nd_34);
        }
        u64 _nd_35 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_35 + 0] = rfc_seal(e, _b_7);
        e.mem[_nd_35 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        r0 = term_ctr(CID_CON, _nd_35);
        r1 = _f_1;
        WL_RETN(2);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0_K265)
  {
    WL_POPN(19);
    u32 _o_38 = STK(0);
    u32 _o_39 = STK(1);
    u32 _o_40 = STK(2);
    Term _o_41 = STK(3);
    u32 _o_42 = STK(4);
    Term _o_43 = STK(5);
    Term _o_44 = STK(6);
    Term _o_45 = STK(7);
    u32 _o_46 = STK(8);
    Term _o_47 = STK(9);
    u32 _o_48 = STK(10);
    Term _o_49 = STK(11);
    u32 _o_50 = STK(12);
    Term _o_51 = STK(13);
    Term _o_52 = STK(14);
    Term _o_53 = STK(15);
    u32 _o_54 = STK(16);
    u32 _o_55 = STK(17);
    Term _o_56 = STK(18);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_63[2];
    if (spin_68(e, _o_63, 3, _o_38, blk_loc(e.mem, _o_38), _o_39, blk_loc(e.mem, _o_39), _o_40, blk_loc(e.mem, _o_40), _o_41, blk_loc(e.mem, _o_41), _o_42, _o_43, blk_loc(e.mem, _o_43), _o_44, blk_loc(e.mem, _o_44), _o_45, blk_loc(e.mem, _o_45), _o_46, _o_47, blk_loc(e.mem, _o_47), _o_48, blk_loc(e.mem, _o_48), _o_49, blk_loc(e.mem, _o_49), _o_50, _o_51, blk_loc(e.mem, _o_51), _o_52, blk_loc(e.mem, _o_52), _o_53, blk_loc(e.mem, _o_53), _o_54, _o_55, _o_56, blk_loc(e.mem, _o_56), _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_0 = _o_63[0];
    _v_1 = _o_63[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0)
  {
    Term _journal_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_journal_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      r1 = term_pak(CID_NIL, 0);
      WL_RETN(2);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _journal_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      Term _o_2 = 0;
      Term _o_3 = 0;
      Term _o_4 = 0;
      u32 _o_5 = 0;
      Term _o_6 = 0;
      Term _o_7 = 0;
      Term _o_8 = 0;
      u32 _o_9 = 0;
      Term _o_10 = 0;
      Term _o_11 = 0;
      Term _o_12 = 0;
      u32 _o_13 = 0;
      Term _o_14 = 0;
      Term _o_15 = 0;
      Term _o_16 = 0;
      u32 _o_17 = 0;
      u32 _o_18 = 0;
      Term _o_19 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULESTARTED) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        Term _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_PHASEENTERED) {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_4;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMCOMPLETED) {
        _o_0 = 2;
        Term _fb_3[8];
        u64 _sp_3 = ctr_take(e, _f_0, 8, _fb_3);
        u32 _f_5 = _fb_3[0];
        u32 _f_6 = _fb_3[1];
        u32 _f_7 = _fb_3[2];
        Term _f_8 = _fb_3[3];
        u32 _f_9 = _fb_3[4];
        u32 _f_10 = _fb_3[5];
        u32 _f_11 = _fb_3[6];
        Term _f_12 = _fb_3[7];
        spare_free(e, cls_fit(8), _sp_3);
        u32 _o_20 = 0;
        u32 _o_21 = 0;
        u32 _o_22 = 0;
        if (_f_11 == 0) {
          _o_20 = 0;
        } else {
          _o_20 = 1;
          u32 _o_23 = 0;
          u32 _o_24 = 0;
          if (term_aux(_f_12) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
            _o_23 = 0;
            Term _fb_4[1];
            u64 _sp_4 = ctr_take(e, _f_12, 1, _fb_4);
            Term _f_13 = _fb_4[0];
            spare_free(e, cls_fit(1), _sp_4);
          } else {
            _o_23 = 1;
            Term _fb_5[1];
            u64 _sp_5 = ctr_take(e, _f_12, 1, _fb_5);
            Term _f_14 = _fb_5[0];
            spare_free(e, cls_fit(1), _sp_5);
            u32 _o_25 = 0;
            if (term_aux(_f_14) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
              _o_25 = 0;
              Term _fb_6[1];
              u64 _sp_6 = ctr_take(e, _f_14, 1, _fb_6);
              Term _f_15 = _fb_6[0];
              spare_free(e, cls_fit(1), _sp_6);
            } else {
              _o_25 = 1;
            }
            _o_24 = _o_25;
          }
          _o_21 = _o_23;
          _o_22 = _o_24;
        }
        _o_1 = _f_5;
        _o_2 = _f_6;
        _o_3 = _f_7;
        _o_4 = _f_8;
        _o_5 = _f_9;
        _o_6 = _f_10;
        _o_7 = _o_20;
        _o_8 = _o_21;
        _o_9 = _o_22;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_OPERATIONOBSERVED) {
        _o_0 = 3;
        Term _fb_7[19];
        u64 _sp_7 = ctr_take(e, _f_0, 19, _fb_7);
        u32 _f_16 = _fb_7[0];
        u32 _f_17 = _fb_7[1];
        u32 _f_18 = _fb_7[2];
        Term _f_19 = _fb_7[3];
        u32 _f_20 = _fb_7[4];
        Term _f_21 = _fb_7[5];
        Term _f_22 = _fb_7[6];
        Term _f_23 = _fb_7[7];
        u32 _f_24 = _fb_7[8];
        Term _f_25 = _fb_7[9];
        u32 _f_26 = _fb_7[10];
        Term _f_27 = _fb_7[11];
        u32 _f_28 = _fb_7[12];
        Term _f_29 = _fb_7[13];
        Term _f_30 = _fb_7[14];
        Term _f_31 = _fb_7[15];
        u32 _f_32 = _fb_7[16];
        u32 _f_33 = _fb_7[17];
        Term _f_34 = _fb_7[18];
        spare_free(e, cls_fit(19), _sp_7);
        _o_1 = _f_16;
        _o_2 = _f_17;
        _o_3 = _f_18;
        _o_4 = _f_19;
        _o_5 = _f_20;
        _o_6 = _f_21;
        _o_7 = _f_22;
        _o_8 = _f_23;
        _o_9 = _f_24;
        _o_10 = _f_25;
        _o_11 = _f_26;
        _o_12 = _f_27;
        _o_13 = _f_28;
        _o_14 = _f_29;
        _o_15 = _f_30;
        _o_16 = _f_31;
        _o_17 = _f_32;
        _o_18 = _f_33;
        _o_19 = _f_34;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_BARRIEROPERATIONOBSERVED) {
        _o_0 = 4;
        Term _fb_8[15];
        u64 _sp_8 = ctr_take(e, _f_0, 15, _fb_8);
        u32 _f_35 = _fb_8[0];
        Term _f_36 = _fb_8[1];
        Term _f_37 = _fb_8[2];
        Term _f_38 = _fb_8[3];
        u32 _f_39 = _fb_8[4];
        Term _f_40 = _fb_8[5];
        u32 _f_41 = _fb_8[6];
        Term _f_42 = _fb_8[7];
        u32 _f_43 = _fb_8[8];
        Term _f_44 = _fb_8[9];
        Term _f_45 = _fb_8[10];
        Term _f_46 = _fb_8[11];
        u32 _f_47 = _fb_8[12];
        u32 _f_48 = _fb_8[13];
        Term _f_49 = _fb_8[14];
        spare_free(e, cls_fit(15), _sp_8);
        _o_1 = _f_35;
        _o_2 = _f_36;
        _o_3 = _f_37;
        _o_4 = _f_38;
        _o_5 = _f_39;
        _o_6 = _f_40;
        _o_7 = _f_41;
        _o_8 = _f_42;
        _o_9 = _f_43;
        _o_10 = _f_44;
        _o_11 = _f_45;
        _o_12 = _f_46;
        _o_13 = _f_47;
        _o_14 = _f_48;
        _o_15 = _f_49;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_EXECUTIONOPERATIONOBSERVED) {
        _o_0 = 5;
        Term _fb_9[15];
        u64 _sp_9 = ctr_take(e, _f_0, 15, _fb_9);
        u32 _f_50 = _fb_9[0];
        Term _f_51 = _fb_9[1];
        Term _f_52 = _fb_9[2];
        Term _f_53 = _fb_9[3];
        u32 _f_54 = _fb_9[4];
        Term _f_55 = _fb_9[5];
        u32 _f_56 = _fb_9[6];
        Term _f_57 = _fb_9[7];
        u32 _f_58 = _fb_9[8];
        Term _f_59 = _fb_9[9];
        Term _f_60 = _fb_9[10];
        Term _f_61 = _fb_9[11];
        u32 _f_62 = _fb_9[12];
        u32 _f_63 = _fb_9[13];
        Term _f_64 = _fb_9[14];
        spare_free(e, cls_fit(15), _sp_9);
        _o_1 = _f_50;
        _o_2 = _f_51;
        _o_3 = _f_52;
        _o_4 = _f_53;
        _o_5 = _f_54;
        _o_6 = _f_55;
        _o_7 = _f_56;
        _o_8 = _f_57;
        _o_9 = _f_58;
        _o_10 = _f_59;
        _o_11 = _f_60;
        _o_12 = _f_61;
        _o_13 = _f_62;
        _o_14 = _f_63;
        _o_15 = _f_64;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMSKIPPED) {
        _o_0 = 6;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_DEFERREDAPPLIED) {
        _o_0 = 7;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEENDED) {
        _o_0 = 8;
        Term _fb_10[2];
        u64 _sp_10 = ctr_take(e, _f_0, 2, _fb_10);
        u32 _f_65 = _fb_10[0];
        Term _f_66 = _fb_10[1];
        spare_free(e, cls_fit(2), _sp_10);
        u32 _o_26 = 0;
        u32 _o_27 = 0;
        u32 _o_28 = 0;
        if (_f_65 == 0) {
          _o_26 = 0;
        } else if (_f_65 == 1) {
          _o_26 = 1;
          u32 _o_29 = 0;
          u32 _o_30 = 0;
          if (term_aux(_f_66) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
            _o_29 = 0;
            Term _fb_11[1];
            u64 _sp_11 = ctr_take(e, _f_66, 1, _fb_11);
            Term _f_67 = _fb_11[0];
            spare_free(e, cls_fit(1), _sp_11);
          } else {
            _o_29 = 1;
            Term _fb_12[1];
            u64 _sp_12 = ctr_take(e, _f_66, 1, _fb_12);
            Term _f_68 = _fb_12[0];
            spare_free(e, cls_fit(1), _sp_12);
            u32 _o_31 = 0;
            if (term_aux(_f_68) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
              _o_31 = 0;
              Term _fb_13[1];
              u64 _sp_13 = ctr_take(e, _f_68, 1, _fb_13);
              Term _f_69 = _fb_13[0];
              spare_free(e, cls_fit(1), _sp_13);
            } else {
              _o_31 = 1;
            }
            _o_30 = _o_31;
          }
          _o_27 = _o_29;
          _o_28 = _o_30;
        } else if (_f_65 == 2) {
          _o_26 = 2;
        } else {
          _o_26 = 3;
        }
        _o_1 = _o_26;
        _o_2 = _o_27;
        _o_3 = _o_28;
      } else {
        _o_0 = 9;
        Term _fb_14[4];
        u64 _sp_14 = ctr_take(e, _f_0, 4, _fb_14);
        u32 _f_70 = _fb_14[0];
        Term _f_71 = _fb_14[1];
        u32 _f_72 = _fb_14[2];
        Term _f_73 = _fb_14[3];
        spare_free(e, cls_fit(4), _sp_14);
        u32 _o_32 = 0;
        u32 _o_33 = 0;
        u32 _o_34 = 0;
        if (_f_72 == 0) {
          _o_32 = 0;
        } else if (_f_72 == 1) {
          _o_32 = 1;
          u32 _o_35 = 0;
          u32 _o_36 = 0;
          if (term_aux(_f_73) == CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR) {
            _o_35 = 0;
            Term _fb_15[1];
            u64 _sp_15 = ctr_take(e, _f_73, 1, _fb_15);
            Term _f_74 = _fb_15[0];
            spare_free(e, cls_fit(1), _sp_15);
          } else {
            _o_35 = 1;
            Term _fb_16[1];
            u64 _sp_16 = ctr_take(e, _f_73, 1, _fb_16);
            Term _f_75 = _fb_16[0];
            spare_free(e, cls_fit(1), _sp_16);
            u32 _o_37 = 0;
            if (term_aux(_f_75) == CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE) {
              _o_37 = 0;
              Term _fb_17[1];
              u64 _sp_17 = ctr_take(e, _f_75, 1, _fb_17);
              Term _f_76 = _fb_17[0];
              spare_free(e, cls_fit(1), _sp_17);
            } else {
              _o_37 = 1;
            }
            _o_36 = _o_37;
          }
          _o_33 = _o_35;
          _o_34 = _o_36;
        } else if (_f_72 == 2) {
          _o_32 = 2;
        } else {
          _o_32 = 3;
        }
        _o_1 = _f_70;
        _o_2 = _f_71;
        _o_3 = _o_32;
        _o_4 = _o_33;
        _o_5 = _o_34;
      }
      if (_o_0 == 4) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(16);
          STK(0) = _o_1;
          STK(1) = _o_2;
          STK(2) = _o_3;
          STK(3) = _o_4;
          STK(4) = _o_5;
          STK(5) = _o_6;
          STK(6) = _o_7;
          STK(7) = _o_8;
          STK(8) = _o_9;
          STK(9) = _o_10;
          STK(10) = _o_11;
          STK(11) = _o_12;
          STK(12) = _o_13;
          STK(13) = _o_14;
          STK(14) = _o_15;
          STK(15) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0_K267;
          WL_PUSHN(16);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0_K267, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          e.mem[_t_0 + 1] = _o_2;
          e.mem[_t_0 + 2] = _o_3;
          e.mem[_t_0 + 3] = _o_4;
          e.mem[_t_0 + 4] = _o_5;
          e.mem[_t_0 + 5] = _o_6;
          e.mem[_t_0 + 6] = _o_7;
          e.mem[_t_0 + 7] = _o_8;
          e.mem[_t_0 + 8] = _o_9;
          e.mem[_t_0 + 9] = _o_10;
          e.mem[_t_0 + 10] = _o_11;
          e.mem[_t_0 + 11] = _o_12;
          e.mem[_t_0 + 12] = _o_13;
          e.mem[_t_0 + 13] = _o_14;
          e.mem[_t_0 + 14] = _o_15;
          WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0_K267, _t_0);
          WL_IDX = 15;
        }
        r0 = _f_1;
        _journal_0 = r0;
        WL_AGAIN(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0);
      } else {
        Term _b_0 = 0;
        if (_o_0 == 0) {
          u64 _nd_0 = heap_alloc(e, cls_fit(2));
          e.mem[_nd_0 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_0 + 1] = rfc_seal(e, _o_2);
          _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULESTARTED, _nd_0);
        } else if (_o_0 == 1) {
          u64 _nd_1 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_1 + 0] = rfc_seal(e, _o_1);
          _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_PHASEENTERED, _nd_1);
        } else if (_o_0 == 2) {
          u32 _o_54 = 0;
          Term _o_55 = 0;
          if (_o_7 == 0) {
            _o_54 = 0;
          } else {
            _o_54 = 1;
            Term _b_1 = 0;
            if (_o_8 == 0) {
              u64 _nd_2 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_2 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
              _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_2);
            } else {
              Term _b_2 = 0;
              if (_o_9 == 0) {
                u64 _nd_3 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_3 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
                _b_2 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_3);
              } else {
                _b_2 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
              }
              u64 _nd_4 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_4 + 0] = rfc_seal(e, _b_2);
              _b_1 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_4);
            }
            _o_55 = _b_1;
          }
          u64 _nd_5 = heap_alloc(e, cls_fit(8));
          e.mem[_nd_5 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_5 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_5 + 2] = rfc_seal(e, _o_3);
          e.mem[_nd_5 + 3] = rfc_seal(e, _o_4);
          e.mem[_nd_5 + 4] = rfc_seal(e, _o_5);
          e.mem[_nd_5 + 5] = rfc_seal(e, _o_6);
          e.mem[_nd_5 + 6] = rfc_seal(e, _o_54);
          e.mem[_nd_5 + 7] = rfc_seal(e, _o_55);
          _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMCOMPLETED, _nd_5);
        } else if (_o_0 == 3) {
          u64 _nd_6 = heap_alloc(e, cls_fit(19));
          e.mem[_nd_6 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_6 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_6 + 2] = rfc_seal(e, _o_3);
          e.mem[_nd_6 + 3] = rfc_seal(e, _o_4);
          e.mem[_nd_6 + 4] = rfc_seal(e, _o_5);
          e.mem[_nd_6 + 5] = rfc_seal(e, _o_6);
          e.mem[_nd_6 + 6] = rfc_seal(e, _o_7);
          e.mem[_nd_6 + 7] = rfc_seal(e, _o_8);
          e.mem[_nd_6 + 8] = rfc_seal(e, _o_9);
          e.mem[_nd_6 + 9] = rfc_seal(e, _o_10);
          e.mem[_nd_6 + 10] = rfc_seal(e, _o_11);
          e.mem[_nd_6 + 11] = rfc_seal(e, _o_12);
          e.mem[_nd_6 + 12] = rfc_seal(e, _o_13);
          e.mem[_nd_6 + 13] = rfc_seal(e, _o_14);
          e.mem[_nd_6 + 14] = rfc_seal(e, _o_15);
          e.mem[_nd_6 + 15] = rfc_seal(e, _o_16);
          e.mem[_nd_6 + 16] = rfc_seal(e, _o_17);
          e.mem[_nd_6 + 17] = rfc_seal(e, _o_18);
          e.mem[_nd_6 + 18] = rfc_seal(e, _o_19);
          _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_OPERATIONOBSERVED, _nd_6);
        } else if (_o_0 == 4) {
          u64 _nd_7 = heap_alloc(e, cls_fit(15));
          e.mem[_nd_7 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_7 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_7 + 2] = rfc_seal(e, _o_3);
          e.mem[_nd_7 + 3] = rfc_seal(e, _o_4);
          e.mem[_nd_7 + 4] = rfc_seal(e, _o_5);
          e.mem[_nd_7 + 5] = rfc_seal(e, _o_6);
          e.mem[_nd_7 + 6] = rfc_seal(e, _o_7);
          e.mem[_nd_7 + 7] = rfc_seal(e, _o_8);
          e.mem[_nd_7 + 8] = rfc_seal(e, _o_9);
          e.mem[_nd_7 + 9] = rfc_seal(e, _o_10);
          e.mem[_nd_7 + 10] = rfc_seal(e, _o_11);
          e.mem[_nd_7 + 11] = rfc_seal(e, _o_12);
          e.mem[_nd_7 + 12] = rfc_seal(e, _o_13);
          e.mem[_nd_7 + 13] = rfc_seal(e, _o_14);
          e.mem[_nd_7 + 14] = rfc_seal(e, _o_15);
          _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_BARRIEROPERATIONOBSERVED, _nd_7);
        } else if (_o_0 == 5) {
          u64 _nd_8 = heap_alloc(e, cls_fit(15));
          e.mem[_nd_8 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_8 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_8 + 2] = rfc_seal(e, _o_3);
          e.mem[_nd_8 + 3] = rfc_seal(e, _o_4);
          e.mem[_nd_8 + 4] = rfc_seal(e, _o_5);
          e.mem[_nd_8 + 5] = rfc_seal(e, _o_6);
          e.mem[_nd_8 + 6] = rfc_seal(e, _o_7);
          e.mem[_nd_8 + 7] = rfc_seal(e, _o_8);
          e.mem[_nd_8 + 8] = rfc_seal(e, _o_9);
          e.mem[_nd_8 + 9] = rfc_seal(e, _o_10);
          e.mem[_nd_8 + 10] = rfc_seal(e, _o_11);
          e.mem[_nd_8 + 11] = rfc_seal(e, _o_12);
          e.mem[_nd_8 + 12] = rfc_seal(e, _o_13);
          e.mem[_nd_8 + 13] = rfc_seal(e, _o_14);
          e.mem[_nd_8 + 14] = rfc_seal(e, _o_15);
          _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_EXECUTIONOPERATIONOBSERVED, _nd_8);
        } else if (_o_0 == 6) {
          _b_0 = term_pak(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMSKIPPED, _o_1);
        } else if (_o_0 == 7) {
          _b_0 = term_pak(CID__________SRC_ECS_EXECUTION_TRACE_DEFERREDAPPLIED, 0);
        } else if (_o_0 == 8) {
          u32 _o_56 = 0;
          Term _o_57 = 0;
          if (_o_1 == 0) {
            _o_56 = 0;
          } else if (_o_1 == 1) {
            _o_56 = 1;
            Term _b_3 = 0;
            if (_o_2 == 0) {
              u64 _nd_9 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_9 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
              _b_3 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_9);
            } else {
              Term _b_4 = 0;
              if (_o_3 == 0) {
                u64 _nd_10 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_10 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
                _b_4 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_10);
              } else {
                _b_4 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
              }
              u64 _nd_11 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_11 + 0] = rfc_seal(e, _b_4);
              _b_3 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_11);
            }
            _o_57 = _b_3;
          } else if (_o_1 == 2) {
            _o_56 = 2;
          } else {
            _o_56 = 3;
          }
          u64 _nd_12 = heap_alloc(e, cls_fit(2));
          e.mem[_nd_12 + 0] = rfc_seal(e, _o_56);
          e.mem[_nd_12 + 1] = rfc_seal(e, _o_57);
          _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEENDED, _nd_12);
        } else {
          u32 _o_58 = 0;
          Term _o_59 = 0;
          if (_o_3 == 0) {
            _o_58 = 0;
          } else if (_o_3 == 1) {
            _o_58 = 1;
            Term _b_5 = 0;
            if (_o_4 == 0) {
              u64 _nd_13 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_13 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
              _b_5 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_13);
            } else {
              Term _b_6 = 0;
              if (_o_5 == 0) {
                u64 _nd_14 = heap_alloc(e, cls_fit(1));
                e.mem[_nd_14 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
                _b_6 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_14);
              } else {
                _b_6 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
              }
              u64 _nd_15 = heap_alloc(e, cls_fit(1));
              e.mem[_nd_15 + 0] = rfc_seal(e, _b_6);
              _b_5 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_15);
            }
            _o_59 = _b_5;
          } else if (_o_3 == 2) {
            _o_58 = 2;
          } else {
            _o_58 = 3;
          }
          u64 _nd_16 = heap_alloc(e, cls_fit(4));
          e.mem[_nd_16 + 0] = rfc_seal(e, _o_1);
          e.mem[_nd_16 + 1] = rfc_seal(e, _o_2);
          e.mem[_nd_16 + 2] = rfc_seal(e, _o_58);
          e.mem[_nd_16 + 3] = rfc_seal(e, _o_59);
          _b_0 = term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEADMISSIONREFUSED, _nd_16);
        }
        u64 _nd_17 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_17 + 0] = rfc_seal(e, _b_0);
        e.mem[_nd_17 + 1] = rfc_seal(e, _f_1);
        r0 = term_pak(CID_NIL, 0);
        r1 = term_ctr(CID_CON, _nd_17);
        WL_RETN(2);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0_K267)
  {
    WL_POPN(15);
    u32 _o_38 = STK(0);
    Term _o_39 = STK(1);
    Term _o_40 = STK(2);
    Term _o_41 = STK(3);
    u32 _o_42 = STK(4);
    Term _o_43 = STK(5);
    u32 _o_44 = STK(6);
    Term _o_45 = STK(7);
    u32 _o_46 = STK(8);
    Term _o_47 = STK(9);
    Term _o_48 = STK(10);
    Term _o_49 = STK(11);
    u32 _o_50 = STK(12);
    u32 _o_51 = STK(13);
    Term _o_52 = STK(14);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_53[2];
    Term _a_0 = 0;
    Term _a_1 = 0;
    if (spin_68(e, _o_53, 4, _o_38, blk_loc(e.mem, _o_38), _o_39, blk_loc(e.mem, _o_39), _o_40, blk_loc(e.mem, _o_40), _o_41, blk_loc(e.mem, _o_41), _o_42, _o_43, blk_loc(e.mem, _o_43), _o_44, blk_loc(e.mem, _o_44), _o_45, blk_loc(e.mem, _o_45), _o_46, _o_47, blk_loc(e.mem, _o_47), _o_48, blk_loc(e.mem, _o_48), _o_49, blk_loc(e.mem, _o_49), _o_50, _o_51, blk_loc(e.mem, _o_51), _o_52, blk_loc(e.mem, _o_52), _a_0, blk_loc(e.mem, _a_0), 0, 0, _a_1, blk_loc(e.mem, _a_1), _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_0 = _o_53[0];
    _v_1 = _o_53[1];
    r0 = _v_0;
    r1 = _v_1;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0)
  {
    Term _next_0 = r0;
    Term _chunk_0 = r1;
    Term _chunk_1 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _chunk_0;
      STK(1) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0_K269;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0_K269, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _chunk_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0_K269, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _next_0;
      e.mem[_t_1 + 1] = _chunk_1;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _next_0;
    r1 = _chunk_1;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0_K269)
  {
    WL_POPN(1);
    Term _chunk_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_2 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _chunk_2;
      e.mem[_t_2 + 1] = _h_0;
      return term_tsk(FID_LIST_APPEND, _t_2);
    }
    r0 = _chunk_2;
    r1 = _h_0;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_RUN_WITH_BARRIER_0)
  {
    u32 _schedule_0 = r0;
    Term _schedule_1 = r1;
    Term _schedule_2 = r2;
    u32 _schedule_3 = r3;
    u32 _schedule_4 = r4;
    Term _schedule_5 = r5;
    Term _schedule_6 = r6;
    Term _schedule_7 = r7;
    u32 _schedule_8 = r8;
    Term _schedule_9 = r9;
    Term _schedule_10 = r10;
    Term _world_0 = r11;
    WL_OPEN
    Term _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    u32 _v_3 = 0;
    Term _o_0[2];
    if (spin_52(e, _o_0, _world_0, blk_loc(e.mem, _world_0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    u32 _s_0 = U32_BIN(_schedule_0, ==, _v_1);
    if (_s_0 == 0) {
      r0 = 2;
      r1 = _schedule_0;
      r2 = _schedule_1;
      r3 = _schedule_2;
      r4 = _schedule_3;
      r5 = _schedule_4;
      r6 = _schedule_5;
      r7 = _schedule_6;
      r8 = _schedule_7;
      r9 = _schedule_8;
      r10 = _schedule_9;
      r11 = _schedule_10;
      r12 = _v_0;
      r13 = 0;
      r14 = 0;
      r15 = 0;
      WL_RETN(16);
    } else {
      _schedule_2 = term_keep(e, _schedule_2, 1);
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0)) {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _schedule_2;
        e.mem[_t_0 + 1] = _schedule_3;
        e.mem[_t_0 + 2] = _schedule_4;
        e.mem[_t_0 + 3] = _schedule_5;
        e.mem[_t_0 + 4] = _schedule_6;
        e.mem[_t_0 + 5] = _schedule_7;
        e.mem[_t_0 + 6] = _schedule_8;
        e.mem[_t_0 + 7] = _schedule_9;
        e.mem[_t_0 + 8] = _schedule_10;
        e.mem[_t_0 + 9] = _v_0;
        e.mem[_t_0 + 10] = _schedule_0;
        e.mem[_t_0 + 11] = _schedule_1;
        e.mem[_t_0 + 12] = _schedule_2;
        e.mem[_t_0 + 13] = term_pak(CID_NIL, 0);
        return term_tsk(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0, _t_0);
      }
      r0 = _schedule_2;
      r1 = _schedule_3;
      r2 = _schedule_4;
      r3 = _schedule_5;
      r4 = _schedule_6;
      r5 = _schedule_7;
      r6 = _schedule_8;
      r7 = _schedule_9;
      r8 = _schedule_10;
      r9 = _v_0;
      r10 = _schedule_0;
      r11 = _schedule_1;
      r12 = _schedule_2;
      r13 = term_pak(CID_NIL, 0);
      WL_JMP(FID__________SRC_ECS_SCHEDULE_EXECUTE_WITH_BARRIER_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0)
  {
    Term _observations_0 = r0;
    Term _journal_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_observations_0) == CID_NIL) {
      r0 = _journal_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _observations_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_ENTERED) {
        _o_0 = 0;
        Term _fb_1[1];
        u64 _sp_1 = ctr_take(e, _f_0, 1, _fb_1);
        Term _f_2 = _fb_1[0];
        spare_free(e, cls_fit(1), _sp_1);
        _o_1 = _f_2;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_RAN) {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_SKIPPED) {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 3;
      }
      if (_o_0 == 0) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _o_1;
          STK(1) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K279;
          WL_PUSHN(2);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K279, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K279, _t_0);
          WL_IDX = 1;
        }
        r0 = _f_1;
        r1 = _journal_0;
        _observations_0 = r0;
        _journal_0 = r1;
        WL_AGAIN(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0);
      } else if (_o_0 == 2) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _o_1;
          STK(1) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K280;
          WL_PUSHN(2);
        } else {
          u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K280, WL_CONT, WL_IDX, 1);
          e.mem[_t_1 + 0] = _o_1;
          WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K280, _t_1);
          WL_IDX = 1;
        }
        r0 = _f_1;
        r1 = _journal_0;
        _observations_0 = r0;
        _journal_0 = r1;
        WL_AGAIN(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0);
      } else if (_o_0 == 3) {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K281;
          WL_PUSHN(2);
        } else {
          u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K281, WL_CONT, WL_IDX, 1);
          e.mem[_t_2 + 0] = _f_1;
          WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K281, _t_2);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0)) {
          u64 _t_3 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_3 + 0] = _journal_0;
          return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0, _t_3);
        }
        r0 = _journal_0;
        WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BARRIER_CHUNK_0);
      } else {
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_1;
          STK(1) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K284;
          WL_PUSHN(2);
        } else {
          u64 _t_7 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K284, WL_CONT, WL_IDX, 1);
          e.mem[_t_7 + 0] = _f_1;
          WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K284, _t_7);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0)) {
          u64 _t_8 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0, WL_CONT, WL_IDX, 0);
          e.mem[_t_8 + 0] = _journal_0;
          return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0, _t_8);
        }
        r0 = _journal_0;
        WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RAN_CHUNK_0);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K279)
  {
    WL_POPN(1);
    Term _o_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = rfc_seal(e, _o_2);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_PHASEENTERED, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K280)
  {
    WL_POPN(1);
    u32 _o_3 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_pak(CID__________SRC_ECS_EXECUTION_TRACE_SYSTEMSKIPPED, _o_3));
    e.mem[_nd_2 + 1] = rfc_seal(e, _h_1);
    r0 = term_ctr(CID_CON, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K281)
  {
    WL_POPN(1);
    Term _f_3 = STK(0);
    Term _h_2 = r0;
    Term _h_3 = r1;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_3 + 0] = _f_3;
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0)) {
      u64 _t_6 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C282, _nd_3);
      e.mem[_t_6 + 1] = _h_2;
      e.mem[_t_6 + 2] = _h_3;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0, _t_6);
    }
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C282, _nd_3);
    r1 = _h_2;
    r2 = _h_3;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C282)
  {
    Term _f_4 = r0;
    Term _x_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K283;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K283, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K283, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0)) {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_4;
      e.mem[_t_5 + 1] = _x_0;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0, _t_5);
    }
    r0 = _f_4;
    r1 = _x_0;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K283)
  {
    Term _h_4 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, term_pak(CID__________SRC_ECS_EXECUTION_TRACE_DEFERREDAPPLIED, 0));
    e.mem[_nd_4 + 1] = rfc_seal(e, _h_4);
    r0 = term_ctr(CID_CON, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_K284)
  {
    WL_POPN(1);
    Term _f_5 = STK(0);
    Term _h_5 = r0;
    Term _h_6 = r1;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_5 + 0] = _f_5;
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0)) {
      u64 _t_10 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C285, _nd_5);
      e.mem[_t_10 + 1] = _h_5;
      e.mem[_t_10 + 2] = _h_6;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0, _t_10);
    }
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C285, _nd_5);
    r1 = _h_5;
    r2 = _h_6;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGED_CHUNK_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0_C285)
  {
    Term _f_6 = r0;
    Term _x_1 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0)) {
      u64 _t_9 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _f_6;
      e.mem[_t_9 + 1] = _x_1;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0, _t_9);
    }
    r0 = _f_6;
    r1 = _x_1;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0)
  {
    Term _items_0 = r0;
    u32 _item_0 = r1;
    u32 _item_1 = r2;
    WL_OPEN
    WL_SPIN
    if (term_aux(_items_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _items_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT) {
        _o_0 = 0;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE) {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      }
      if (seq) {
        WL_ROOM(5);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = _item_0;
        STK(3) = _item_1;
        STK(4) = FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K292;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K292, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        e.mem[_t_0 + 2] = _item_0;
        e.mem[_t_0 + 3] = _item_1;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K292, _t_0);
        WL_IDX = 4;
      }
      r0 = _f_1;
      r1 = _item_0;
      r2 = _item_1;
      _items_0 = r0;
      _item_0 = r1;
      _item_1 = r2;
      WL_AGAIN(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0_K292)
  {
    WL_POPN(4);
    u32 _o_2 = STK(0);
    u32 _o_3 = STK(1);
    u32 _item_2 = STK(2);
    u32 _item_3 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _o_4[1];
    if (spin_71(e, _o_4, _o_2, _o_3, _item_2, _item_3) == 0) {
      return 0;
    }
    _v_1 = _o_4[0];
    _v_0 = _v_1;
    r0 = ((_v_0) | (_h_0));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0)
  {
    Term _needs_0 = r0;
    Term _available_0 = r1;
    WL_OPEN
    if (term_aux(_needs_0) == CID_NIL) {
      term_sink(e, _available_0);
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      u64 _sp_0 = term_peek(e.mem, _needs_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT) {
        _o_0 = 0;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE) {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      }
      if (seq) {
        WL_ROOM(5);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = _f_1;
        STK(3) = _available_0;
        STK(4) = FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K298;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K298, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        e.mem[_t_0 + 2] = _f_1;
        e.mem[_t_0 + 3] = _available_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K298, _t_0);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _available_0;
        e.mem[_t_1 + 1] = _o_0;
        e.mem[_t_1 + 2] = _o_1;
        return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0, _t_1);
      }
      r0 = _available_0;
      r1 = _o_0;
      r2 = _o_1;
      WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K298)
  {
    WL_POPN(4);
    u32 _o_2 = STK(0);
    u32 _o_3 = STK(1);
    Term _f_2 = STK(2);
    Term _available_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(4);
      STK(0) = _o_2;
      STK(1) = _o_3;
      STK(2) = _h_0;
      STK(3) = FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K299;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K299, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _o_2;
      e.mem[_t_2 + 1] = _o_3;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K299, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      e.mem[_t_3 + 1] = _available_1;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0, _t_3);
    }
    r0 = _f_2;
    r1 = _available_1;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0_K299)
  {
    WL_POPN(3);
    u32 _o_4 = STK(0);
    u32 _o_5 = STK(1);
    u32 _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_6[1];
    if (spin_72(e, _o_6, _h_2, _o_4, _o_5, _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_0 = _o_6[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0)
  {
    u32 _namespace_0 = r0;
    Term _name_0 = r1;
    Term _observations_0 = r2;
    Term _journal_0 = r3;
    Term _journal_1 = r4;
    u32 _outcome_0 = r5;
    u32 _outcome_1 = r6;
    u32 _outcome_2 = r7;
    WL_OPEN
    term_sink(e, _journal_0);
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_1[1];
    if (spin_73(e, _o_1, _journal_1, blk_loc(e.mem, _journal_1)) == 0) {
      return 0;
    }
    _v_1 = _o_1[0];
    _v_0 = _v_1;
    if (seq) {
      WL_ROOM(6);
      STK(0) = _namespace_0;
      STK(1) = _name_0;
      STK(2) = _outcome_0;
      STK(3) = _outcome_1;
      STK(4) = _outcome_2;
      STK(5) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K303;
      WL_PUSHN(6);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K303, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _namespace_0;
      e.mem[_t_0 + 1] = _name_0;
      e.mem[_t_0 + 2] = _outcome_0;
      e.mem[_t_0 + 3] = _outcome_1;
      e.mem[_t_0 + 4] = _outcome_2;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K303, _t_0);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _observations_0;
      e.mem[_t_1 + 1] = _v_0;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0, _t_1);
    }
    r0 = _observations_0;
    r1 = _v_0;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_MERGE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K303)
  {
    WL_POPN(5);
    u32 _namespace_1 = STK(0);
    Term _name_1 = STK(1);
    u32 _outcome_3 = STK(2);
    u32 _outcome_4 = STK(3);
    u32 _outcome_5 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (_outcome_3 == 0) {
      _o_2 = 0;
    } else if (_outcome_3 == 1) {
      _o_2 = 1;
      Term _b_0 = 0;
      if (_outcome_4 == 0) {
        u64 _nd_1 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_1 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
        _b_0 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_LEFTERROR, _nd_1);
      } else {
        Term _b_1 = 0;
        if (_outcome_5 == 0) {
          u64 _nd_2 = heap_alloc(e, cls_fit(1));
          e.mem[_nd_2 + 0] = rfc_seal(e, term_pak(CID_LOCAL_FIXTURE_EXPECTEDFAILURE, 0));
          _b_1 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_CALLBACKFAILURE, _nd_2);
        } else {
          _b_1 = term_pak(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_REGISTRATIONREFUSED, 0);
        }
        u64 _nd_3 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_3 + 0] = rfc_seal(e, _b_1);
        _b_0 = term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_RIGHTERROR, _nd_3);
      }
      _o_3 = _b_0;
    } else if (_outcome_3 == 2) {
      _o_2 = 2;
    } else {
      _o_2 = 3;
    }
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, _o_2);
    e.mem[_nd_4 + 1] = rfc_seal(e, _o_3);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEENDED, _nd_4));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(3);
      STK(0) = _namespace_1;
      STK(1) = _name_1;
      STK(2) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K304;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K304, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _namespace_1;
      e.mem[_t_2 + 1] = _name_1;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K304, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_3 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_0;
      e.mem[_t_3 + 1] = term_ctr(CID_CON, _nd_5);
      return term_tsk(FID_LIST_APPEND, _t_3);
    }
    r0 = _h_0;
    r1 = term_ctr(CID_CON, _nd_5);
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0_K304)
  {
    WL_POPN(2);
    u32 _namespace_2 = STK(0);
    Term _name_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, _namespace_2);
    e.mem[_nd_6 + 1] = rfc_seal(e, _name_2);
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULESTARTED, _nd_6));
    e.mem[_nd_7 + 1] = rfc_seal(e, _h_1);
    r0 = 1;
    r1 = term_ctr(CID_CON, _nd_7);
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES)
  {
    u32 _meta_0 = r0;
    Term _meta_1 = r1;
    Term _meta_2 = r2;
    u32 _id_0 = r3;
    Term _name_0 = r4;
    Term _access_0 = r5;
    WL_OPEN
    u32 _s_0 = U32_BIN(_meta_0, ==, _id_0);
    if (_s_0 == 0) {
      r0 = 0;
      WL_RETN(1);
    } else {
      u32 _v_0 = 0;
      u32 _v_1 = 0;
      Term _o_0[1];
      if (spin_65(e, _o_0, _meta_1, blk_loc(e.mem, _meta_1), _name_0, blk_loc(e.mem, _name_0)) == 0) {
        return 0;
      }
      _v_1 = _o_0[0];
      _v_0 = _v_1;
      if (_v_0 == 0) {
        r0 = 0;
        WL_RETN(1);
      } else {
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_ACCESS_EQUAL)) {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_ACCESS_EQUAL, WL_CONT, WL_IDX, 0);
          e.mem[_t_0 + 0] = _meta_2;
          e.mem[_t_0 + 1] = _access_0;
          return term_tsk(FID__________SRC_ECS_WORLD_ACCESS_EQUAL, _t_0);
        }
        r0 = _meta_2;
        r1 = _access_0;
        WL_JMP(FID__________SRC_ECS_WORLD_ACCESS_EQUAL);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0)
  {
    Term _items_0 = r0;
    Term _seen_0 = r1;
    WL_OPEN
    if (term_aux(_items_0) == CID_NIL) {
      term_sink(e, _seen_0);
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      u32 _o_1 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT) {
        _o_0 = 0;
        _o_1 = term_loc(_f_0);
      } else if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE) {
        _o_0 = 1;
        _o_1 = term_loc(_f_0);
      } else {
        _o_0 = 2;
        _o_1 = term_loc(_f_0);
      }
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(5);
        STK(0) = _o_0;
        STK(1) = _o_1;
        STK(2) = _f_1;
        STK(3) = _seen_0;
        STK(4) = FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K318;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K318, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _o_0;
        e.mem[_t_0 + 1] = _o_1;
        e.mem[_t_0 + 2] = _f_1;
        e.mem[_t_0 + 3] = _seen_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K318, _t_0);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _seen_0;
        e.mem[_t_1 + 1] = _o_0;
        e.mem[_t_1 + 2] = _o_1;
        return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0, _t_1);
      }
      r0 = _seen_0;
      r1 = _o_0;
      r2 = _o_1;
      WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_CONTAINS_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K318)
  {
    WL_POPN(4);
    u32 _o_2 = STK(0);
    u32 _o_3 = STK(1);
    Term _f_2 = STK(2);
    Term _seen_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    Term _b_0 = 0;
    if (_o_2 == 0) {
      _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT, _o_3);
    } else if (_o_2 == 1) {
      _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE, _o_3);
    } else {
      _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_SERVICE, _o_3);
    }
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _b_0);
    e.mem[_nd_0 + 1] = rfc_seal(e, _seen_1);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _o_2;
      STK(1) = _o_3;
      STK(2) = _h_0;
      STK(3) = FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K319;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K319, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _o_2;
      e.mem[_t_2 + 1] = _o_3;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K319, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_2;
      e.mem[_t_3 + 1] = term_ctr(CID_CON, _nd_0);
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0, _t_3);
    }
    r0 = _f_2;
    r1 = term_ctr(CID_CON, _nd_0);
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0_K319)
  {
    WL_POPN(3);
    u32 _o_4 = STK(0);
    u32 _o_5 = STK(1);
    u32 _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_6[1];
    if (spin_76(e, _o_6, _h_2, _o_4, _o_5, _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_0 = _o_6[0];
    r0 = _v_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND)
  {
    Term _xs_0 = r0;
    Term _ys_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_xs_0) == CID_NIL) {
      r0 = _ys_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _xs_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_LIST_APPEND_K321;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_LIST_APPEND_K321, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_LIST_APPEND_K321, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _ys_0;
      _xs_0 = r0;
      _ys_0 = r1;
      WL_AGAIN(FID_LIST_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LIST_APPEND_K321)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_VALID)
  {
    Term _steps_0 = r0;
    Term _catalog_0 = r1;
    Term _seen_0 = r2;
    WL_OPEN
    WL_SPIN
    if (term_aux(_steps_0) == CID_NIL) {
      term_sink(e, _catalog_0);
      term_sink(e, _seen_0);
      r0 = 1;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _steps_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _o_0 = 0;
      Term _o_1 = 0;
      u32 _o_2 = 0;
      if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_SYSTEM) {
        _o_0 = 0;
        Term _fb_1[2];
        u64 _sp_1 = ctr_take(e, _f_0, 2, _fb_1);
        u32 _f_2 = _fb_1[0];
        u32 _f_3 = _fb_1[1];
        spare_free(e, cls_fit(2), _sp_1);
        _o_1 = _f_2;
        _o_2 = _f_3;
      } else if (term_aux(_f_0) == CID__________SRC_ECS_SCHEDULE_PHASE) {
        _o_0 = 1;
        Term _fb_2[1];
        u64 _sp_2 = ctr_take(e, _f_0, 1, _fb_2);
        Term _f_4 = _fb_2[0];
        spare_free(e, cls_fit(1), _sp_2);
        _o_1 = _f_4;
      } else {
        _o_0 = 2;
      }
      if (_o_0 == 1) {
        term_sink(e, _o_1);
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _f_1;
        r1 = _catalog_0;
        r2 = _seen_0;
        _steps_0 = r0;
        _catalog_0 = r1;
        _seen_0 = r2;
        WL_AGAIN(FID__________SRC_ECS_SCHEDULE_VALID);
      } else if (_o_0 == 2) {
        spare_free(e, cls_fit(2), _sp_0);
        r0 = _f_1;
        r1 = _catalog_0;
        r2 = _seen_0;
        _steps_0 = r0;
        _catalog_0 = r1;
        _seen_0 = r2;
        WL_AGAIN(FID__________SRC_ECS_SCHEDULE_VALID);
      } else {
        _catalog_0 = term_keep(e, _catalog_0, 1);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(5);
          STK(0) = _o_1;
          STK(1) = _f_1;
          STK(2) = _catalog_0;
          STK(3) = _seen_0;
          STK(4) = FID__________SRC_ECS_SCHEDULE_VALID_K323;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_VALID_K323, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _o_1;
          e.mem[_t_0 + 1] = _f_1;
          e.mem[_t_0 + 2] = _catalog_0;
          e.mem[_t_0 + 3] = _seen_0;
          WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_VALID_K323, _t_0);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_CONTAINS)) {
          u64 _t_1 = task_node(e, FID__________SRC_ECS_SCHEDULE_CONTAINS, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _catalog_0;
          e.mem[_t_1 + 1] = _o_1;
          return term_tsk(FID__________SRC_ECS_SCHEDULE_CONTAINS, _t_1);
        }
        r0 = _catalog_0;
        r1 = _o_1;
        WL_JMP(FID__________SRC_ECS_SCHEDULE_CONTAINS);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_VALID_K323)
  {
    WL_POPN(4);
    u32 _o_3 = STK(0);
    Term _f_5 = STK(1);
    Term _catalog_1 = STK(2);
    Term _seen_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    _seen_1 = term_keep(e, _seen_1, 1);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _o_3;
      STK(1) = _f_5;
      STK(2) = _catalog_1;
      STK(3) = _seen_1;
      STK(4) = _h_0;
      STK(5) = FID__________SRC_ECS_SCHEDULE_VALID_K324;
      WL_PUSHN(6);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_SCHEDULE_VALID_K324, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _o_3;
      e.mem[_t_2 + 1] = _f_5;
      e.mem[_t_2 + 2] = _catalog_1;
      e.mem[_t_2 + 3] = _seen_1;
      e.mem[_t_2 + 4] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_VALID_K324, _t_2);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_CONTAINS)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_SCHEDULE_CONTAINS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _seen_1;
      e.mem[_t_3 + 1] = _o_3;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_CONTAINS, _t_3);
    }
    r0 = _seen_1;
    r1 = _o_3;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_CONTAINS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_VALID_K324)
  {
    WL_POPN(5);
    u32 _o_4 = STK(0);
    Term _f_6 = STK(1);
    Term _catalog_2 = STK(2);
    Term _seen_2 = STK(3);
    u32 _h_2 = STK(4);
    u32 _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _o_4);
    e.mem[_nd_0 + 1] = rfc_seal(e, _seen_2);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_2;
      STK(1) = _h_1;
      STK(2) = FID__________SRC_ECS_SCHEDULE_VALID_K325;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID__________SRC_ECS_SCHEDULE_VALID_K325, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_2;
      e.mem[_t_4 + 1] = _h_1;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_VALID_K325, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_VALID)) {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_SCHEDULE_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_6;
      e.mem[_t_5 + 1] = _catalog_2;
      e.mem[_t_5 + 2] = term_ctr(CID_CON, _nd_0);
      return term_tsk(FID__________SRC_ECS_SCHEDULE_VALID, _t_5);
    }
    r0 = _f_6;
    r1 = _catalog_2;
    r2 = term_ctr(CID_CON, _nd_0);
    WL_JMP(FID__________SRC_ECS_SCHEDULE_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_VALID_K325)
  {
    WL_POPN(2);
    u32 _h_4 = STK(0);
    u32 _h_5 = STK(1);
    u32 _h_3 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _o_5[1];
    if (spin_26(e, _o_5, _h_5) == 0) {
      return 0;
    }
    _v_2 = _o_5[0];
    _v_1 = _v_2;
    u32 _v_3 = 0;
    Term _o_6[1];
    if (spin_30(e, _o_6, _v_1, _h_3) == 0) {
      return 0;
    }
    _v_3 = _o_6[0];
    _v_0 = _v_3;
    u32 _v_4 = 0;
    Term _o_7[1];
    if (spin_30(e, _o_7, _h_4, _v_0) == 0) {
      return 0;
    }
    _v_4 = _o_7[0];
    r0 = _v_4;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK)
  {
    Term _registrations_0 = r0;
    u32 _id_0 = r1;
    Term _name_0 = r2;
    Term _access_0 = r3;
    u32 _found_0 = r4;
    WL_OPEN
    if (term_aux(_registrations_0) == CID_NIL) {
      if (_found_0 == 1) {
        r0 = 1;
        WL_RETN(1);
      } else {
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      u64 _sp_0 = term_peek(e.mem, _registrations_0);
      Term _f_0 = e.mem[_sp_0 + 0];
      Term _f_1 = e.mem[_sp_0 + 1];
      u64 _sp_1 = term_peek(e.mem, _f_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      Term _f_4 = e.mem[_sp_1 + 2];
      if (_found_0 == 1) {
        r0 = 1;
        WL_RETN(1);
      } else {
        if (seq) {
          WL_ROOM(5);
          STK(0) = _f_1;
          STK(1) = _id_0;
          STK(2) = _name_0;
          STK(3) = _access_0;
          STK(4) = FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K350;
          WL_PUSHN(5);
        } else {
          u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K350, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_1;
          e.mem[_t_0 + 1] = _id_0;
          e.mem[_t_0 + 2] = _name_0;
          e.mem[_t_0 + 3] = _access_0;
          WL_CONT = term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K350, _t_0);
          WL_IDX = 4;
        }
        if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES)) {
          u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _f_2;
          e.mem[_t_1 + 1] = _f_3;
          e.mem[_t_1 + 2] = _f_4;
          e.mem[_t_1 + 3] = _id_0;
          e.mem[_t_1 + 4] = _name_0;
          e.mem[_t_1 + 5] = _access_0;
          return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES, _t_1);
        }
        r0 = _f_2;
        r1 = _f_3;
        r2 = _f_4;
        r3 = _id_0;
        r4 = _name_0;
        r5 = _access_0;
        WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_META_MATCHES);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK_K350)
  {
    WL_POPN(4);
    Term _f_5 = STK(0);
    u32 _id_1 = STK(1);
    Term _name_1 = STK(2);
    Term _access_1 = STK(3);
    u32 _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_5;
      e.mem[_t_2 + 1] = _id_1;
      e.mem[_t_2 + 2] = _name_1;
      e.mem[_t_2 + 3] = _access_1;
      e.mem[_t_2 + 4] = _h_0;
      return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK, _t_2);
    }
    r0 = _f_5;
    r1 = _id_1;
    r2 = _name_1;
    r3 = _access_1;
    r4 = _h_0;
    WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0)
  {
    Term _plan_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_plan_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_EMPTY) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else if (term_aux(_plan_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_ENTRY) {
      Term _fb_0[4];
      u64 _sp_0 = ctr_take(e, _plan_0, 4, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _f_2 = _fb_0[2];
      Term _f_3 = _fb_0[3];
      term_sink(e, _f_1);
      spare_free(e, cls_fit(4), _sp_0);
      r0 = _f_3;
      WL_RETN(1);
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _plan_0, 2, _fb_1);
      Term _f_4 = _fb_1[0];
      Term _f_5 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_5;
        STK(1) = FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K352;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K352, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_5;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K352, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_4;
      _plan_0 = r0;
      WL_AGAIN(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K352)
  {
    WL_POPN(1);
    Term _f_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K353;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K353, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K353, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_6;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0, _t_2);
    }
    r0 = _f_6;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0_K353)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_3 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_2;
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_LIST_APPEND, _t_3);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0)
  {
    Term _items_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0)) {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _items_0;
      e.mem[_t_0 + 1] = term_pak(CID_NIL, 0);
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0, _t_0);
    }
    r0 = _items_0;
    r1 = term_pak(CID_NIL, 0);
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_SEEN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0)
  {
    Term _plan_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_plan_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_EMPTY) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else if (term_aux(_plan_0) == CID__________SRC_ECS_SCHEDULE_PROVISION_ENTRY) {
      Term _fb_0[4];
      u64 _sp_0 = ctr_take(e, _plan_0, 4, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      u32 _f_2 = _fb_0[2];
      Term _f_3 = _fb_0[3];
      term_sink(e, _f_3);
      Term _b_0 = 0;
      if (_f_0 == 0) {
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_1);
        e.mem[_nd_0 + 1] = rfc_seal(e, _f_2);
        _b_0 = term_ctr(CID__________SRC_ECS_SCHEDULE_SYSTEM, _nd_0);
      } else if (_f_0 == 1) {
        u64 _nd_1 = heap_alloc(e, cls_fit(1));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_1);
        _b_0 = term_ctr(CID__________SRC_ECS_SCHEDULE_PHASE, _nd_1);
      } else {
        _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_BARRIER, 0);
      }
      u64 _nd_2 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_2 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
      spare_free(e, cls_fit(4), _sp_0);
      r0 = term_ctr(CID_CON, _nd_2);
      WL_RETN(1);
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _plan_0, 2, _fb_1);
      Term _f_4 = _fb_1[0];
      Term _f_5 = _fb_1[1];
      spare_free(e, cls_fit(2), _sp_1);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_5;
        STK(1) = FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K356;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K356, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_5;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K356, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_4;
      _plan_0 = r0;
      WL_AGAIN(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K356)
  {
    WL_POPN(1);
    Term _f_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_0;
      STK(1) = FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K357;
      WL_PUSHN(2);
    } else {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K357, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K357, _t_1);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0)) {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _f_6;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0, _t_2);
    }
    r0 = _f_6;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0_K357)
  {
    WL_POPN(1);
    Term _h_2 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_3 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _h_2;
      e.mem[_t_3 + 1] = _h_1;
      return term_tsk(FID_LIST_APPEND, _t_3);
    }
    r0 = _h_2;
    r1 = _h_1;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_BUILD_0)
  {
    u32 _namespace_0 = r0;
    Term _name_0 = r1;
    Term _steps_0 = r2;
    Term _catalog_0 = r3;
    u32 _owners_0 = r4;
    u32 _owners_1 = r5;
    Term _owners_2 = r6;
    Term _owners_3 = r7;
    Term _owners_4 = r8;
    WL_OPEN
    _steps_0 = term_keep(e, _steps_0, 1);
    if (seq) {
      WL_ROOM(9);
      STK(0) = _namespace_0;
      STK(1) = _name_0;
      STK(2) = _steps_0;
      STK(3) = _owners_0;
      STK(4) = _owners_1;
      STK(5) = _owners_2;
      STK(6) = _owners_3;
      STK(7) = _owners_4;
      STK(8) = FID__________SRC_ECS_SCHEDULE_BUILD_0_K359;
      WL_PUSHN(9);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_BUILD_0_K359, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _namespace_0;
      e.mem[_t_0 + 1] = _name_0;
      e.mem[_t_0 + 2] = _steps_0;
      e.mem[_t_0 + 3] = _owners_0;
      e.mem[_t_0 + 4] = _owners_1;
      e.mem[_t_0 + 5] = _owners_2;
      e.mem[_t_0 + 6] = _owners_3;
      e.mem[_t_0 + 7] = _owners_4;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_BUILD_0_K359, _t_0);
      WL_IDX = 8;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_VALID)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_SCHEDULE_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _steps_0;
      e.mem[_t_1 + 1] = _catalog_0;
      e.mem[_t_1 + 2] = term_pak(CID_NIL, 0);
      return term_tsk(FID__________SRC_ECS_SCHEDULE_VALID, _t_1);
    }
    r0 = _steps_0;
    r1 = _catalog_0;
    r2 = term_pak(CID_NIL, 0);
    WL_JMP(FID__________SRC_ECS_SCHEDULE_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_BUILD_0_K359)
  {
    WL_POPN(8);
    u32 _namespace_1 = STK(0);
    Term _name_1 = STK(1);
    Term _steps_1 = STK(2);
    u32 _owners_5 = STK(3);
    u32 _owners_6 = STK(4);
    Term _owners_7 = STK(5);
    Term _owners_8 = STK(6);
    Term _owners_9 = STK(7);
    u32 _h_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _o_0[9];
    if (spin_82(e, _o_0, _h_0, _namespace_1, _name_1, blk_loc(e.mem, _name_1), _steps_1, blk_loc(e.mem, _steps_1), _owners_5, _owners_6, _owners_7, blk_loc(e.mem, _owners_7), _owners_8, blk_loc(e.mem, _owners_8), _owners_9, blk_loc(e.mem, _owners_9)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    WL_RETN(9);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0)
  {
    Term _fields_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_fields_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _fields_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[9];
      u64 _sp_1 = ctr_take(e, _f_0, 9, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      Term _f_8 = _fb_1[6];
      u32 _f_9 = _fb_1[7];
      Term _f_10 = _fb_1[8];
      spare_free(e, cls_fit(9), _sp_1);
      term_sink(e, _f_5);
      term_sink(e, _f_7);
      term_sink(e, _f_8);
      term_sink(e, _f_10);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(4);
        STK(0) = _f_2;
        STK(1) = _f_3;
        STK(2) = _f_4;
        STK(3) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0_K362;
        WL_PUSHN(4);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0_K362, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_2;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _f_4;
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0_K362, _t_0);
        WL_IDX = 3;
      }
      r0 = _f_1;
      _fields_0 = r0;
      WL_AGAIN(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0_K362)
  {
    WL_POPN(3);
    u32 _f_11 = STK(0);
    u32 _f_12 = STK(1);
    Term _f_13 = STK(2);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_11);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_12);
    e.mem[_nd_0 + 2] = rfc_seal(e, 1);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_13);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_IDENTITY, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0)
  {
    u32 _schedule_0 = r0;
    Term _schedule_1 = r1;
    Term _schedule_2 = r2;
    u32 _schedule_3 = r3;
    u32 _schedule_4 = r4;
    Term _schedule_5 = r5;
    Term _schedule_6 = r6;
    Term _schedule_7 = r7;
    u32 _schedule_8 = r8;
    Term _schedule_9 = r9;
    Term _schedule_10 = r10;
    Term _schedule_11 = r11;
    Term _world_0 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _schedule_0;
      STK(1) = _schedule_1;
      STK(2) = _schedule_2;
      STK(3) = _schedule_3;
      STK(4) = _schedule_4;
      STK(5) = _schedule_5;
      STK(6) = _schedule_6;
      STK(7) = _schedule_7;
      STK(8) = _schedule_8;
      STK(9) = _schedule_9;
      STK(10) = _schedule_10;
      STK(11) = _schedule_11;
      STK(12) = FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K366;
      WL_PUSHN(13);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K366, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _schedule_0;
      e.mem[_t_2 + 1] = _schedule_1;
      e.mem[_t_2 + 2] = _schedule_2;
      e.mem[_t_2 + 3] = _schedule_3;
      e.mem[_t_2 + 4] = _schedule_4;
      e.mem[_t_2 + 5] = _schedule_5;
      e.mem[_t_2 + 6] = _schedule_6;
      e.mem[_t_2 + 7] = _schedule_7;
      e.mem[_t_2 + 8] = _schedule_8;
      e.mem[_t_2 + 9] = _schedule_9;
      e.mem[_t_2 + 10] = _schedule_10;
      e.mem[_t_2 + 11] = _schedule_11;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K366, _t_2);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_clo(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_C364, 0);
      e.mem[_t_3 + 1] = _world_0;
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = term_clo(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_C364, 0);
    r1 = _world_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_C364)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _o_0[2];
    if (spin_69(e, _o_0, _x_0, blk_loc(e.mem, _x_0)) == 0) {
      return 0;
    }
    _v_2 = _o_0[0];
    _v_3 = _o_0[1];
    _v_0 = _v_2;
    _v_1 = _v_3;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _o_1[2];
    if (spin_67(e, _o_1, _v_0, blk_loc(e.mem, _v_0)) == 0) {
      return 0;
    }
    _v_6 = _o_1[0];
    _v_7 = _o_1[1];
    _v_4 = _v_6;
    _v_5 = _v_7;
    if (seq) {
      WL_ROOM(2);
      STK(0) = _v_4;
      STK(1) = FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K365;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K365, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _v_4;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K365, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_1 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_1;
      e.mem[_t_1 + 1] = _v_5;
      return term_tsk(FID_LIST_APPEND, _t_1);
    }
    r0 = _v_1;
    r1 = _v_5;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K365)
  {
    WL_POPN(1);
    Term _v_8 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_8);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_TUPLE, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K366)
  {
    WL_POPN(12);
    u32 _schedule_12 = STK(0);
    Term _schedule_13 = STK(1);
    Term _schedule_14 = STK(2);
    u32 _schedule_15 = STK(3);
    u32 _schedule_16 = STK(4);
    Term _schedule_17 = STK(5);
    Term _schedule_18 = STK(6);
    Term _schedule_19 = STK(7);
    u32 _schedule_20 = STK(8);
    Term _schedule_21 = STK(9);
    Term _schedule_22 = STK(10);
    Term _schedule_23 = STK(11);
    Term _h_1 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _h_1, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    if (seq) {
      WL_ROOM(14);
      STK(0) = _f_0;
      STK(1) = _schedule_12;
      STK(2) = _schedule_13;
      STK(3) = _schedule_14;
      STK(4) = _schedule_15;
      STK(5) = _schedule_16;
      STK(6) = _schedule_17;
      STK(7) = _schedule_18;
      STK(8) = _schedule_19;
      STK(9) = _schedule_20;
      STK(10) = _schedule_21;
      STK(11) = _schedule_22;
      STK(12) = _schedule_23;
      STK(13) = FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K367;
      WL_PUSHN(14);
    } else {
      u64 _t_4 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K367, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _f_0;
      e.mem[_t_4 + 1] = _schedule_12;
      e.mem[_t_4 + 2] = _schedule_13;
      e.mem[_t_4 + 3] = _schedule_14;
      e.mem[_t_4 + 4] = _schedule_15;
      e.mem[_t_4 + 5] = _schedule_16;
      e.mem[_t_4 + 6] = _schedule_17;
      e.mem[_t_4 + 7] = _schedule_18;
      e.mem[_t_4 + 8] = _schedule_19;
      e.mem[_t_4 + 9] = _schedule_20;
      e.mem[_t_4 + 10] = _schedule_21;
      e.mem[_t_4 + 11] = _schedule_22;
      e.mem[_t_4 + 12] = _schedule_23;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K367, _t_4);
      WL_IDX = 13;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0)) {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _schedule_23;
      e.mem[_t_5 + 1] = _f_1;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0, _t_5);
    }
    r0 = _schedule_23;
    r1 = _f_1;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_MISSING_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K367)
  {
    WL_POPN(13);
    Term _f_2 = STK(0);
    u32 _schedule_24 = STK(1);
    Term _schedule_25 = STK(2);
    Term _schedule_26 = STK(3);
    u32 _schedule_27 = STK(4);
    u32 _schedule_28 = STK(5);
    Term _schedule_29 = STK(6);
    Term _schedule_30 = STK(7);
    Term _schedule_31 = STK(8);
    u32 _schedule_32 = STK(9);
    Term _schedule_33 = STK(10);
    Term _schedule_34 = STK(11);
    Term _schedule_35 = STK(12);
    Term _h_2 = r0;
    WL_OPEN
    if (term_aux(_h_2) == CID_CON) {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _h_2, 2, _fb_1);
      Term _f_3 = _fb_1[0];
      Term _f_4 = _fb_1[1];
      u32 _o_2 = 0;
      u32 _o_3 = 0;
      if (term_aux(_f_3) == CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT) {
        _o_2 = 0;
        _o_3 = term_loc(_f_3);
      } else if (term_aux(_f_3) == CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE) {
        _o_2 = 1;
        _o_3 = term_loc(_f_3);
      } else {
        _o_2 = 2;
        _o_3 = term_loc(_f_3);
      }
      Term _b_0 = 0;
      if (_o_2 == 0) {
        _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_COMPONENT, _o_3);
      } else if (_o_2 == 1) {
        _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_RESOURCE, _o_3);
      } else {
        _b_0 = term_pak(CID__________SRC_ECS_SCHEDULE_PROVISION_SERVICE, _o_3);
      }
      u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
      e.mem[_nd_1 + 0] = rfc_seal(e, _b_0);
      e.mem[_nd_1 + 1] = rfc_seal(e, _f_4);
      r0 = 1;
      r1 = _schedule_24;
      r2 = _schedule_25;
      r3 = _schedule_26;
      r4 = _schedule_27;
      r5 = _schedule_28;
      r6 = _schedule_29;
      r7 = _schedule_30;
      r8 = _schedule_31;
      r9 = _schedule_32;
      r10 = _schedule_33;
      r11 = _schedule_34;
      r12 = _schedule_35;
      r13 = _f_2;
      r14 = term_ctr(CID_CON, _nd_1);
      r15 = 0;
      r16 = 0;
      r17 = 0;
      WL_RETN(18);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _schedule_35;
        STK(1) = FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K368;
        WL_PUSHN(2);
      } else {
        u64 _t_6 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K368, WL_CONT, WL_IDX, 1);
        e.mem[_t_6 + 0] = _schedule_35;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K368, _t_6);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_RUN_WITH_BARRIER_0)) {
        u64 _t_7 = task_node(e, FID__________SRC_ECS_SCHEDULE_RUN_WITH_BARRIER_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_7 + 0] = _schedule_24;
        e.mem[_t_7 + 1] = _schedule_25;
        e.mem[_t_7 + 2] = _schedule_26;
        e.mem[_t_7 + 3] = _schedule_27;
        e.mem[_t_7 + 4] = _schedule_28;
        e.mem[_t_7 + 5] = _schedule_29;
        e.mem[_t_7 + 6] = _schedule_30;
        e.mem[_t_7 + 7] = _schedule_31;
        e.mem[_t_7 + 8] = _schedule_32;
        e.mem[_t_7 + 9] = _schedule_33;
        e.mem[_t_7 + 10] = _schedule_34;
        e.mem[_t_7 + 11] = _f_2;
        return term_tsk(FID__________SRC_ECS_SCHEDULE_RUN_WITH_BARRIER_0, _t_7);
      }
      r0 = _schedule_24;
      r1 = _schedule_25;
      r2 = _schedule_26;
      r3 = _schedule_27;
      r4 = _schedule_28;
      r5 = _schedule_29;
      r6 = _schedule_30;
      r7 = _schedule_31;
      r8 = _schedule_32;
      r9 = _schedule_33;
      r10 = _schedule_34;
      r11 = _f_2;
      WL_JMP(FID__________SRC_ECS_SCHEDULE_RUN_WITH_BARRIER_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0_K368)
  {
    WL_POPN(1);
    Term _schedule_36 = STK(0);
    u32 _h_3 = r0;
    u32 _h_4 = r1;
    Term _h_5 = r2;
    Term _h_6 = r3;
    u32 _h_7 = r4;
    u32 _h_8 = r5;
    Term _h_9 = r6;
    Term _h_10 = r7;
    Term _h_11 = r8;
    u32 _h_12 = r9;
    Term _h_13 = r10;
    Term _h_14 = r11;
    Term _h_15 = r12;
    Term _h_16 = r13;
    u32 _h_17 = r14;
    Term _h_18 = r15;
    WL_OPEN
    r0 = 0;
    r1 = _h_3;
    r2 = _h_4;
    r3 = _h_5;
    r4 = _h_6;
    r5 = _h_7;
    r6 = _h_8;
    r7 = _h_9;
    r8 = _h_10;
    r9 = _h_11;
    r10 = _h_12;
    r11 = _h_13;
    r12 = _h_14;
    r13 = _h_15;
    r14 = _h_16;
    r15 = _h_17;
    r16 = _h_18;
    r17 = _schedule_36;
    WL_RETN(18);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW_GO)
  {
    Term _f_0 = r0;
    u32 _n_0 = r1;
    Term _acc_0 = r2;
    WL_OPEN
    WL_SPIN
    if (_f_0 == 0) {
      r0 = _acc_0;
      WL_RETN(1);
    } else {
      Term _g_0 = (_f_0 - 1);
      u32 _s_0 = U32_BIN(_n_0, ==, 0);
      if (_s_0 == 1) {
        r0 = _acc_0;
        WL_RETN(1);
      } else {
        Term _a_0 = 10ull;
        Term _a_1 = 10ull;
        u64 _nd_0 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, U32_BIN(48ull, +, ((u32)(_a_1) == 0 ? _n_0 : U32_BIN(_n_0, -, U32_QUO((u32)(_n_0), (u32)(_a_1)) * _a_1))));
        e.mem[_nd_0 + 1] = rfc_seal(e, _acc_0);
        r0 = _g_0;
        r1 = ((u32)(_a_0) == 0 ? 0 : (u64)U32_QUO((u32)(_n_0), (u32)(_a_0)));
        r2 = term_ctr(CID_SCON, _nd_0);
        _f_0 = r0;
        _n_0 = r1;
        _acc_0 = r2;
        WL_AGAIN(FID_U32_SHOW_GO);
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_CONTAINS)
  {
    Term _ids_0 = r0;
    u32 _id_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_ids_0) == CID_NIL) {
      r0 = 0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _ids_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(3);
        STK(0) = _f_0;
        STK(1) = _id_0;
        STK(2) = FID__________SRC_ECS_SCHEDULE_CONTAINS_K388;
        WL_PUSHN(3);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_CONTAINS_K388, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        e.mem[_t_0 + 1] = _id_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_CONTAINS_K388, _t_0);
        WL_IDX = 2;
      }
      r0 = _f_1;
      r1 = _id_0;
      _ids_0 = r0;
      _id_0 = r1;
      WL_AGAIN(FID__________SRC_ECS_SCHEDULE_CONTAINS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_CONTAINS_K388)
  {
    WL_POPN(2);
    u32 _f_2 = STK(0);
    u32 _id_1 = STK(1);
    u32 _h_0 = r0;
    WL_OPEN
    r0 = ((U32_BIN(_f_2, ==, _id_1)) | (_h_0));
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)
  {
    Term _registrations_0 = r0;
    u32 _id_0 = r1;
    Term _name_0 = r2;
    Term _access_0 = r3;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK)) {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _registrations_0;
      e.mem[_t_0 + 1] = _id_0;
      e.mem[_t_0 + 2] = _name_0;
      e.mem[_t_0 + 3] = _access_0;
      e.mem[_t_0 + 4] = 0;
      return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK, _t_0);
    }
    r0 = _registrations_0;
    r1 = _id_0;
    r2 = _name_0;
    r3 = _access_0;
    r4 = 0;
    WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_WALK);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0)
  {
    u32 _namespace_0 = r0;
    Term _name_0 = r1;
    Term _plan_0 = r2;
    Term _catalog_0 = r3;
    u32 _owners_0 = r4;
    u32 _owners_1 = r5;
    Term _owners_2 = r6;
    Term _owners_3 = r7;
    Term _owners_4 = r8;
    WL_OPEN
    _plan_0 = term_keep(e, _plan_0, 1);
    if (seq) {
      WL_ROOM(10);
      STK(0) = _namespace_0;
      STK(1) = _name_0;
      STK(2) = _plan_0;
      STK(3) = _catalog_0;
      STK(4) = _owners_0;
      STK(5) = _owners_1;
      STK(6) = _owners_2;
      STK(7) = _owners_3;
      STK(8) = _owners_4;
      STK(9) = FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K392;
      WL_PUSHN(10);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K392, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _namespace_0;
      e.mem[_t_0 + 1] = _name_0;
      e.mem[_t_0 + 2] = _plan_0;
      e.mem[_t_0 + 3] = _catalog_0;
      e.mem[_t_0 + 4] = _owners_0;
      e.mem[_t_0 + 5] = _owners_1;
      e.mem[_t_0 + 6] = _owners_2;
      e.mem[_t_0 + 7] = _owners_3;
      e.mem[_t_0 + 8] = _owners_4;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K392, _t_0);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _plan_0;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0, _t_1);
    }
    r0 = _plan_0;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_FLATTEN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K392)
  {
    WL_POPN(9);
    u32 _namespace_1 = STK(0);
    Term _name_1 = STK(1);
    Term _plan_1 = STK(2);
    Term _catalog_1 = STK(3);
    u32 _owners_5 = STK(4);
    u32 _owners_6 = STK(5);
    Term _owners_7 = STK(6);
    Term _owners_8 = STK(7);
    Term _owners_9 = STK(8);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _plan_1;
      STK(1) = FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K393;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K393, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _plan_1;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K393, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_BUILD_0)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_SCHEDULE_BUILD_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _namespace_1;
      e.mem[_t_3 + 1] = _name_1;
      e.mem[_t_3 + 2] = _h_0;
      e.mem[_t_3 + 3] = _catalog_1;
      e.mem[_t_3 + 4] = _owners_5;
      e.mem[_t_3 + 5] = _owners_6;
      e.mem[_t_3 + 6] = _owners_7;
      e.mem[_t_3 + 7] = _owners_8;
      e.mem[_t_3 + 8] = _owners_9;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_BUILD_0, _t_3);
    }
    r0 = _namespace_1;
    r1 = _name_1;
    r2 = _h_0;
    r3 = _catalog_1;
    r4 = _owners_5;
    r5 = _owners_6;
    r6 = _owners_7;
    r7 = _owners_8;
    r8 = _owners_9;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_BUILD_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K393)
  {
    WL_POPN(1);
    Term _plan_2 = STK(0);
    u32 _h_1 = r0;
    u32 _h_2 = r1;
    Term _h_3 = r2;
    Term _h_4 = r3;
    Term _h_5 = r4;
    Term _h_6 = r5;
    Term _h_7 = r6;
    Term _h_8 = r7;
    Term _h_9 = r8;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_1;
      STK(1) = _h_2;
      STK(2) = _h_3;
      STK(3) = _h_4;
      STK(4) = _h_5;
      STK(5) = _h_6;
      STK(6) = _h_7;
      STK(7) = _h_8;
      STK(8) = _h_9;
      STK(9) = FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K394;
      WL_PUSHN(10);
    } else {
      u64 _t_4 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K394, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _h_1;
      e.mem[_t_4 + 1] = _h_2;
      e.mem[_t_4 + 2] = _h_3;
      e.mem[_t_4 + 3] = _h_4;
      e.mem[_t_4 + 4] = _h_5;
      e.mem[_t_4 + 5] = _h_6;
      e.mem[_t_4 + 6] = _h_7;
      e.mem[_t_4 + 7] = _h_8;
      e.mem[_t_4 + 8] = _h_9;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K394, _t_4);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0)) {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _plan_2;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0, _t_5);
    }
    r0 = _plan_2;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_REQUIREMENTS_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K394)
  {
    WL_POPN(9);
    u32 _h_11 = STK(0);
    u32 _h_12 = STK(1);
    Term _h_13 = STK(2);
    Term _h_14 = STK(3);
    Term _h_15 = STK(4);
    Term _h_16 = STK(5);
    Term _h_17 = STK(6);
    Term _h_18 = STK(7);
    Term _h_19 = STK(8);
    Term _h_10 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(10);
      STK(0) = _h_11;
      STK(1) = _h_12;
      STK(2) = _h_13;
      STK(3) = _h_14;
      STK(4) = _h_15;
      STK(5) = _h_16;
      STK(6) = _h_17;
      STK(7) = _h_18;
      STK(8) = _h_19;
      STK(9) = FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K395;
      WL_PUSHN(10);
    } else {
      u64 _t_6 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K395, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _h_11;
      e.mem[_t_6 + 1] = _h_12;
      e.mem[_t_6 + 2] = _h_13;
      e.mem[_t_6 + 3] = _h_14;
      e.mem[_t_6 + 4] = _h_15;
      e.mem[_t_6 + 5] = _h_16;
      e.mem[_t_6 + 6] = _h_17;
      e.mem[_t_6 + 7] = _h_18;
      e.mem[_t_6 + 8] = _h_19;
      WL_CONT = term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K395, _t_6);
      WL_IDX = 9;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0)) {
      u64 _t_7 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_10;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0, _t_7);
    }
    r0 = _h_10;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_UNIQUE_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0_K395)
  {
    WL_POPN(9);
    u32 _h_21 = STK(0);
    u32 _h_22 = STK(1);
    Term _h_23 = STK(2);
    Term _h_24 = STK(3);
    Term _h_25 = STK(4);
    Term _h_26 = STK(5);
    Term _h_27 = STK(6);
    Term _h_28 = STK(7);
    Term _h_29 = STK(8);
    Term _h_20 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    Term _v_8 = 0;
    Term _v_9 = 0;
    Term _o_0[10];
    if (spin_86(e, _o_0, _h_21, _h_22, _h_23, blk_loc(e.mem, _h_23), _h_24, blk_loc(e.mem, _h_24), _h_25, blk_loc(e.mem, _h_25), _h_26, blk_loc(e.mem, _h_26), _h_27, blk_loc(e.mem, _h_27), _h_28, blk_loc(e.mem, _h_28), _h_29, blk_loc(e.mem, _h_29), _h_20, blk_loc(e.mem, _h_20)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    WL_RETN(10);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0)
  {
    Term _schema_0 = r0;
    Term _world_0 = r1;
    Term _plan_0 = r2;
    u32 _namespace_0 = r3;
    Term _name_0 = r4;
    Term _steps_0 = r5;
    Term _needs_0 = r6;
    u32 _owners_0 = r7;
    u32 _owners_1 = r8;
    Term _owners_2 = r9;
    Term _owners_3 = r10;
    Term _owners_4 = r11;
    u32 _state_0 = r12;
    Term _state_1 = r13;
    Term _state_2 = r14;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _schema_0;
      STK(1) = _plan_0;
      STK(2) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K400;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K400, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _schema_0;
      e.mem[_t_0 + 1] = _plan_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K400, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _namespace_0;
      e.mem[_t_1 + 1] = _name_0;
      e.mem[_t_1 + 2] = _steps_0;
      e.mem[_t_1 + 3] = _owners_0;
      e.mem[_t_1 + 4] = _owners_1;
      e.mem[_t_1 + 5] = _owners_2;
      e.mem[_t_1 + 6] = _owners_3;
      e.mem[_t_1 + 7] = _owners_4;
      e.mem[_t_1 + 8] = _state_0;
      e.mem[_t_1 + 9] = _state_1;
      e.mem[_t_1 + 10] = _state_2;
      e.mem[_t_1 + 11] = _needs_0;
      e.mem[_t_1 + 12] = _world_0;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0, _t_1);
    }
    r0 = _namespace_0;
    r1 = _name_0;
    r2 = _steps_0;
    r3 = _owners_0;
    r4 = _owners_1;
    r5 = _owners_2;
    r6 = _owners_3;
    r7 = _owners_4;
    r8 = _state_0;
    r9 = _state_1;
    r10 = _state_2;
    r11 = _needs_0;
    r12 = _world_0;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_RUN_WITH_BARRIER_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K400)
  {
    WL_POPN(2);
    Term _schema_1 = STK(0);
    Term _plan_1 = STK(1);
    u32 _h_0 = r0;
    u32 _h_1 = r1;
    Term _h_2 = r2;
    Term _h_3 = r3;
    Term _h_4 = r4;
    u32 _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    Term _h_8 = r8;
    Term _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    Term _h_17 = r17;
    WL_OPEN
    if (_h_0 == 0) {
      if (_h_1 == 0) {
        if (_h_10 == 0) {
          Term _v_0 = 0;
          Term _v_1 = 0;
          u32 _v_2 = 0;
          u32 _v_3 = 0;
          Term _v_4 = 0;
          Term _v_5 = 0;
          Term _v_6 = 0;
          u32 _v_7 = 0;
          Term _v_8 = 0;
          u32 _v_9 = 0;
          Term _v_10 = 0;
          Term _v_11 = 0;
          Term _v_12 = 0;
          Term _v_13 = 0;
          Term _v_14 = 0;
          u32 _v_15 = 0;
          u32 _v_16 = 0;
          Term _v_17 = 0;
          Term _v_18 = 0;
          Term _v_19 = 0;
          u32 _v_20 = 0;
          Term _v_21 = 0;
          u32 _v_22 = 0;
          Term _v_23 = 0;
          Term _v_24 = 0;
          Term _v_25 = 0;
          Term _o_0[13];
          if (spin_78(e, _o_0, _schema_1, blk_loc(e.mem, _schema_1), _h_13, blk_loc(e.mem, _h_13), _h_5, _h_6, _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), 0, _plan_1, blk_loc(e.mem, _plan_1), _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_17, blk_loc(e.mem, _h_17)) == 0) {
            return 0;
          }
          _v_13 = _o_0[0];
          _v_14 = _o_0[1];
          _v_15 = _o_0[2];
          _v_16 = _o_0[3];
          _v_17 = _o_0[4];
          _v_18 = _o_0[5];
          _v_19 = _o_0[6];
          _v_20 = _o_0[7];
          _v_21 = _o_0[8];
          _v_22 = _o_0[9];
          _v_23 = _o_0[10];
          _v_24 = _o_0[11];
          _v_25 = _o_0[12];
          _v_0 = _v_13;
          _v_1 = _v_14;
          _v_2 = _v_15;
          _v_3 = _v_16;
          _v_4 = _v_17;
          _v_5 = _v_18;
          _v_6 = _v_19;
          _v_7 = _v_20;
          _v_8 = _v_21;
          _v_9 = _v_22;
          _v_10 = _v_23;
          _v_11 = _v_24;
          _v_12 = _v_25;
          r0 = 0;
          r1 = _v_0;
          r2 = _v_1;
          r3 = _v_2;
          r4 = _v_3;
          r5 = _v_4;
          r6 = _v_5;
          r7 = _v_6;
          r8 = _v_7;
          r9 = _v_8;
          r10 = _v_9;
          r11 = _v_10;
          r12 = _v_11;
          r13 = _v_12;
          r14 = _h_14;
          r15 = 0;
          r16 = 0;
          r17 = 0;
          r18 = 0;
          WL_RETN(19);
        } else {
          _h_3 = term_keep(e, _h_3, 1);
          _h_14 = term_keep(e, _h_14, 1);
          if (seq) {
            WL_ROOM(14);
            STK(0) = _schema_1;
            STK(1) = _plan_1;
            STK(2) = _h_17;
            STK(3) = _h_2;
            STK(4) = _h_3;
            STK(5) = _h_4;
            STK(6) = _h_5;
            STK(7) = _h_6;
            STK(8) = _h_7;
            STK(9) = _h_8;
            STK(10) = _h_9;
            STK(11) = _h_13;
            STK(12) = _h_14;
            STK(13) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K401;
            WL_PUSHN(14);
          } else {
            u64 _t_2 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K401, WL_CONT, WL_IDX, 1);
            e.mem[_t_2 + 0] = _schema_1;
            e.mem[_t_2 + 1] = _plan_1;
            e.mem[_t_2 + 2] = _h_17;
            e.mem[_t_2 + 3] = _h_2;
            e.mem[_t_2 + 4] = _h_3;
            e.mem[_t_2 + 5] = _h_4;
            e.mem[_t_2 + 6] = _h_5;
            e.mem[_t_2 + 7] = _h_6;
            e.mem[_t_2 + 8] = _h_7;
            e.mem[_t_2 + 9] = _h_8;
            e.mem[_t_2 + 10] = _h_9;
            e.mem[_t_2 + 11] = _h_13;
            e.mem[_t_2 + 12] = _h_14;
            WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K401, _t_2);
            WL_IDX = 13;
          }
          if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0)) {
            u64 _t_3 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0, WL_CONT, WL_IDX, 0);
            e.mem[_t_3 + 0] = _h_2;
            e.mem[_t_3 + 1] = _h_3;
            e.mem[_t_3 + 2] = _h_14;
            e.mem[_t_3 + 3] = _h_11;
            e.mem[_t_3 + 4] = _h_12;
            e.mem[_t_3 + 5] = 0;
            e.mem[_t_3 + 6] = 0;
            e.mem[_t_3 + 7] = 0;
            return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0, _t_3);
          }
          r0 = _h_2;
          r1 = _h_3;
          r2 = _h_14;
          r3 = _h_11;
          r4 = _h_12;
          r5 = 0;
          r6 = 0;
          r7 = 0;
          WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0);
        }
      } else if (_h_1 == 1) {
        if (_h_10 == 0) {
          Term _v_52 = 0;
          Term _v_53 = 0;
          u32 _v_54 = 0;
          u32 _v_55 = 0;
          Term _v_56 = 0;
          Term _v_57 = 0;
          Term _v_58 = 0;
          u32 _v_59 = 0;
          Term _v_60 = 0;
          u32 _v_61 = 0;
          Term _v_62 = 0;
          Term _v_63 = 0;
          Term _v_64 = 0;
          Term _v_65 = 0;
          Term _v_66 = 0;
          u32 _v_67 = 0;
          u32 _v_68 = 0;
          Term _v_69 = 0;
          Term _v_70 = 0;
          Term _v_71 = 0;
          u32 _v_72 = 0;
          Term _v_73 = 0;
          u32 _v_74 = 0;
          Term _v_75 = 0;
          Term _v_76 = 0;
          Term _v_77 = 0;
          Term _o_2[13];
          if (spin_78(e, _o_2, _schema_1, blk_loc(e.mem, _schema_1), _h_13, blk_loc(e.mem, _h_13), _h_5, _h_6, _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), 0, _plan_1, blk_loc(e.mem, _plan_1), _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_17, blk_loc(e.mem, _h_17)) == 0) {
            return 0;
          }
          _v_65 = _o_2[0];
          _v_66 = _o_2[1];
          _v_67 = _o_2[2];
          _v_68 = _o_2[3];
          _v_69 = _o_2[4];
          _v_70 = _o_2[5];
          _v_71 = _o_2[6];
          _v_72 = _o_2[7];
          _v_73 = _o_2[8];
          _v_74 = _o_2[9];
          _v_75 = _o_2[10];
          _v_76 = _o_2[11];
          _v_77 = _o_2[12];
          _v_52 = _v_65;
          _v_53 = _v_66;
          _v_54 = _v_67;
          _v_55 = _v_68;
          _v_56 = _v_69;
          _v_57 = _v_70;
          _v_58 = _v_71;
          _v_59 = _v_72;
          _v_60 = _v_73;
          _v_61 = _v_74;
          _v_62 = _v_75;
          _v_63 = _v_76;
          _v_64 = _v_77;
          r0 = 1;
          r1 = _v_52;
          r2 = _v_53;
          r3 = _v_54;
          r4 = _v_55;
          r5 = _v_56;
          r6 = _v_57;
          r7 = _v_58;
          r8 = _v_59;
          r9 = _v_60;
          r10 = _v_61;
          r11 = _v_62;
          r12 = _v_63;
          r13 = _v_64;
          r14 = _h_14;
          r15 = _h_15;
          r16 = _h_16;
          r17 = 0;
          r18 = 0;
          WL_RETN(19);
        } else {
          _h_3 = term_keep(e, _h_3, 1);
          _h_16 = term_keep(e, _h_16, 1);
          if (seq) {
            WL_ROOM(16);
            STK(0) = _schema_1;
            STK(1) = _plan_1;
            STK(2) = _h_17;
            STK(3) = _h_2;
            STK(4) = _h_3;
            STK(5) = _h_4;
            STK(6) = _h_5;
            STK(7) = _h_6;
            STK(8) = _h_7;
            STK(9) = _h_8;
            STK(10) = _h_9;
            STK(11) = _h_13;
            STK(12) = _h_14;
            STK(13) = _h_15;
            STK(14) = _h_16;
            STK(15) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K402;
            WL_PUSHN(16);
          } else {
            u64 _t_4 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K402, WL_CONT, WL_IDX, 1);
            e.mem[_t_4 + 0] = _schema_1;
            e.mem[_t_4 + 1] = _plan_1;
            e.mem[_t_4 + 2] = _h_17;
            e.mem[_t_4 + 3] = _h_2;
            e.mem[_t_4 + 4] = _h_3;
            e.mem[_t_4 + 5] = _h_4;
            e.mem[_t_4 + 6] = _h_5;
            e.mem[_t_4 + 7] = _h_6;
            e.mem[_t_4 + 8] = _h_7;
            e.mem[_t_4 + 9] = _h_8;
            e.mem[_t_4 + 10] = _h_9;
            e.mem[_t_4 + 11] = _h_13;
            e.mem[_t_4 + 12] = _h_14;
            e.mem[_t_4 + 13] = _h_15;
            e.mem[_t_4 + 14] = _h_16;
            WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K402, _t_4);
            WL_IDX = 15;
          }
          if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0)) {
            u64 _t_5 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0, WL_CONT, WL_IDX, 0);
            e.mem[_t_5 + 0] = _h_2;
            e.mem[_t_5 + 1] = _h_3;
            e.mem[_t_5 + 2] = _h_16;
            e.mem[_t_5 + 3] = _h_11;
            e.mem[_t_5 + 4] = _h_12;
            e.mem[_t_5 + 5] = 1;
            e.mem[_t_5 + 6] = _h_14;
            e.mem[_t_5 + 7] = _h_15;
            return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0, _t_5);
          }
          r0 = _h_2;
          r1 = _h_3;
          r2 = _h_16;
          r3 = _h_11;
          r4 = _h_12;
          r5 = 1;
          r6 = _h_14;
          r7 = _h_15;
          WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_BATCH_0);
        }
      } else {
        if (_h_10 == 0) {
          Term _v_104 = 0;
          Term _v_105 = 0;
          u32 _v_106 = 0;
          u32 _v_107 = 0;
          Term _v_108 = 0;
          Term _v_109 = 0;
          Term _v_110 = 0;
          u32 _v_111 = 0;
          Term _v_112 = 0;
          u32 _v_113 = 0;
          Term _v_114 = 0;
          Term _v_115 = 0;
          Term _v_116 = 0;
          Term _v_117 = 0;
          Term _v_118 = 0;
          u32 _v_119 = 0;
          u32 _v_120 = 0;
          Term _v_121 = 0;
          Term _v_122 = 0;
          Term _v_123 = 0;
          u32 _v_124 = 0;
          Term _v_125 = 0;
          u32 _v_126 = 0;
          Term _v_127 = 0;
          Term _v_128 = 0;
          Term _v_129 = 0;
          Term _o_4[13];
          if (spin_78(e, _o_4, _schema_1, blk_loc(e.mem, _schema_1), _h_13, blk_loc(e.mem, _h_13), _h_5, _h_6, _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), 0, _plan_1, blk_loc(e.mem, _plan_1), _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_17, blk_loc(e.mem, _h_17)) == 0) {
            return 0;
          }
          _v_117 = _o_4[0];
          _v_118 = _o_4[1];
          _v_119 = _o_4[2];
          _v_120 = _o_4[3];
          _v_121 = _o_4[4];
          _v_122 = _o_4[5];
          _v_123 = _o_4[6];
          _v_124 = _o_4[7];
          _v_125 = _o_4[8];
          _v_126 = _o_4[9];
          _v_127 = _o_4[10];
          _v_128 = _o_4[11];
          _v_129 = _o_4[12];
          _v_104 = _v_117;
          _v_105 = _v_118;
          _v_106 = _v_119;
          _v_107 = _v_120;
          _v_108 = _v_121;
          _v_109 = _v_122;
          _v_110 = _v_123;
          _v_111 = _v_124;
          _v_112 = _v_125;
          _v_113 = _v_126;
          _v_114 = _v_127;
          _v_115 = _v_128;
          _v_116 = _v_129;
          r0 = 2;
          r1 = _v_104;
          r2 = _v_105;
          r3 = _v_106;
          r4 = _v_107;
          r5 = _v_108;
          r6 = _v_109;
          r7 = _v_110;
          r8 = _v_111;
          r9 = _v_112;
          r10 = _v_113;
          r11 = _v_114;
          r12 = _v_115;
          r13 = _v_116;
          r14 = 0;
          r15 = 0;
          r16 = 0;
          r17 = 0;
          r18 = 0;
          WL_RETN(19);
        } else {
          term_sink(e, _h_11);
          term_sink(e, _h_12);
          Term _v_130 = 0;
          Term _v_131 = 0;
          u32 _v_132 = 0;
          u32 _v_133 = 0;
          Term _v_134 = 0;
          Term _v_135 = 0;
          Term _v_136 = 0;
          u32 _v_137 = 0;
          Term _v_138 = 0;
          u32 _v_139 = 0;
          Term _v_140 = 0;
          Term _v_141 = 0;
          Term _v_142 = 0;
          _h_3 = term_keep(e, _h_3, 1);
          Term _v_143 = 0;
          Term _v_144 = 0;
          u32 _v_145 = 0;
          u32 _v_146 = 0;
          Term _v_147 = 0;
          Term _v_148 = 0;
          Term _v_149 = 0;
          u32 _v_150 = 0;
          Term _v_151 = 0;
          u32 _v_152 = 0;
          Term _v_153 = 0;
          Term _v_154 = 0;
          Term _v_155 = 0;
          Term _o_5[13];
          if (spin_78(e, _o_5, _schema_1, blk_loc(e.mem, _schema_1), _h_13, blk_loc(e.mem, _h_13), _h_5, _h_6, _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), _h_9, blk_loc(e.mem, _h_9), 1, _plan_1, blk_loc(e.mem, _plan_1), _h_2, _h_3, blk_loc(e.mem, _h_3), _h_4, blk_loc(e.mem, _h_4), _h_17, blk_loc(e.mem, _h_17)) == 0) {
            return 0;
          }
          _v_143 = _o_5[0];
          _v_144 = _o_5[1];
          _v_145 = _o_5[2];
          _v_146 = _o_5[3];
          _v_147 = _o_5[4];
          _v_148 = _o_5[5];
          _v_149 = _o_5[6];
          _v_150 = _o_5[7];
          _v_151 = _o_5[8];
          _v_152 = _o_5[9];
          _v_153 = _o_5[10];
          _v_154 = _o_5[11];
          _v_155 = _o_5[12];
          _v_130 = _v_143;
          _v_131 = _v_144;
          _v_132 = _v_145;
          _v_133 = _v_146;
          _v_134 = _v_147;
          _v_135 = _v_148;
          _v_136 = _v_149;
          _v_137 = _v_150;
          _v_138 = _v_151;
          _v_139 = _v_152;
          _v_140 = _v_153;
          _v_141 = _v_154;
          _v_142 = _v_155;
          u64 _nd_0 = heap_alloc(e, cls_fit(4));
          e.mem[_nd_0 + 0] = rfc_seal(e, _h_2);
          e.mem[_nd_0 + 1] = rfc_seal(e, _h_3);
          e.mem[_nd_0 + 2] = rfc_seal(e, 2);
          e.mem[_nd_0 + 3] = rfc_seal(e, 0);
          u64 _nd_1 = heap_alloc(e, cls_fit(2));
          e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEADMISSIONREFUSED, _nd_0));
          e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
          r0 = 2;
          r1 = _v_130;
          r2 = _v_131;
          r3 = _v_132;
          r4 = _v_133;
          r5 = _v_134;
          r6 = _v_135;
          r7 = _v_136;
          r8 = _v_137;
          r9 = _v_138;
          r10 = _v_139;
          r11 = _v_140;
          r12 = _v_141;
          r13 = _v_142;
          r14 = 0;
          r15 = 0;
          r16 = 0;
          r17 = 1;
          r18 = term_ctr(CID_CON, _nd_1);
          WL_RETN(19);
        }
      }
    } else {
      if (_h_9 == 0) {
        Term _v_156 = 0;
        Term _v_157 = 0;
        u32 _v_158 = 0;
        u32 _v_159 = 0;
        Term _v_160 = 0;
        Term _v_161 = 0;
        Term _v_162 = 0;
        u32 _v_163 = 0;
        Term _v_164 = 0;
        u32 _v_165 = 0;
        Term _v_166 = 0;
        Term _v_167 = 0;
        Term _v_168 = 0;
        Term _v_169 = 0;
        Term _v_170 = 0;
        u32 _v_171 = 0;
        u32 _v_172 = 0;
        Term _v_173 = 0;
        Term _v_174 = 0;
        Term _v_175 = 0;
        u32 _v_176 = 0;
        Term _v_177 = 0;
        u32 _v_178 = 0;
        Term _v_179 = 0;
        Term _v_180 = 0;
        Term _v_181 = 0;
        Term _o_6[13];
        if (spin_78(e, _o_6, _schema_1, blk_loc(e.mem, _schema_1), _h_13, blk_loc(e.mem, _h_13), _h_4, _h_5, _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), 0, _plan_1, blk_loc(e.mem, _plan_1), _h_1, _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_12, blk_loc(e.mem, _h_12)) == 0) {
          return 0;
        }
        _v_169 = _o_6[0];
        _v_170 = _o_6[1];
        _v_171 = _o_6[2];
        _v_172 = _o_6[3];
        _v_173 = _o_6[4];
        _v_174 = _o_6[5];
        _v_175 = _o_6[6];
        _v_176 = _o_6[7];
        _v_177 = _o_6[8];
        _v_178 = _o_6[9];
        _v_179 = _o_6[10];
        _v_180 = _o_6[11];
        _v_181 = _o_6[12];
        _v_156 = _v_169;
        _v_157 = _v_170;
        _v_158 = _v_171;
        _v_159 = _v_172;
        _v_160 = _v_173;
        _v_161 = _v_174;
        _v_162 = _v_175;
        _v_163 = _v_176;
        _v_164 = _v_177;
        _v_165 = _v_178;
        _v_166 = _v_179;
        _v_167 = _v_180;
        _v_168 = _v_181;
        r0 = 3;
        r1 = _v_156;
        r2 = _v_157;
        r3 = _v_158;
        r4 = _v_159;
        r5 = _v_160;
        r6 = _v_161;
        r7 = _v_162;
        r8 = _v_163;
        r9 = _v_164;
        r10 = _v_165;
        r11 = _v_166;
        r12 = _v_167;
        r13 = _v_168;
        r14 = _h_14;
        r15 = 0;
        r16 = 0;
        r17 = 0;
        r18 = 0;
        WL_RETN(19);
      } else {
        term_sink(e, _h_10);
        term_sink(e, _h_11);
        Term _v_182 = 0;
        Term _v_183 = 0;
        u32 _v_184 = 0;
        u32 _v_185 = 0;
        Term _v_186 = 0;
        Term _v_187 = 0;
        Term _v_188 = 0;
        u32 _v_189 = 0;
        Term _v_190 = 0;
        u32 _v_191 = 0;
        Term _v_192 = 0;
        Term _v_193 = 0;
        Term _v_194 = 0;
        _h_2 = term_keep(e, _h_2, 1);
        Term _v_195 = 0;
        Term _v_196 = 0;
        u32 _v_197 = 0;
        u32 _v_198 = 0;
        Term _v_199 = 0;
        Term _v_200 = 0;
        Term _v_201 = 0;
        u32 _v_202 = 0;
        Term _v_203 = 0;
        u32 _v_204 = 0;
        Term _v_205 = 0;
        Term _v_206 = 0;
        Term _v_207 = 0;
        Term _o_7[13];
        if (spin_78(e, _o_7, _schema_1, blk_loc(e.mem, _schema_1), _h_13, blk_loc(e.mem, _h_13), _h_4, _h_5, _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, blk_loc(e.mem, _h_8), 1, _plan_1, blk_loc(e.mem, _plan_1), _h_1, _h_2, blk_loc(e.mem, _h_2), _h_3, blk_loc(e.mem, _h_3), _h_12, blk_loc(e.mem, _h_12)) == 0) {
          return 0;
        }
        _v_195 = _o_7[0];
        _v_196 = _o_7[1];
        _v_197 = _o_7[2];
        _v_198 = _o_7[3];
        _v_199 = _o_7[4];
        _v_200 = _o_7[5];
        _v_201 = _o_7[6];
        _v_202 = _o_7[7];
        _v_203 = _o_7[8];
        _v_204 = _o_7[9];
        _v_205 = _o_7[10];
        _v_206 = _o_7[11];
        _v_207 = _o_7[12];
        _v_182 = _v_195;
        _v_183 = _v_196;
        _v_184 = _v_197;
        _v_185 = _v_198;
        _v_186 = _v_199;
        _v_187 = _v_200;
        _v_188 = _v_201;
        _v_189 = _v_202;
        _v_190 = _v_203;
        _v_191 = _v_204;
        _v_192 = _v_205;
        _v_193 = _v_206;
        _v_194 = _v_207;
        u64 _nd_2 = heap_alloc(e, cls_fit(4));
        e.mem[_nd_2 + 0] = rfc_seal(e, _h_1);
        e.mem[_nd_2 + 1] = rfc_seal(e, _h_2);
        e.mem[_nd_2 + 2] = rfc_seal(e, 3);
        e.mem[_nd_2 + 3] = rfc_seal(e, 0);
        u64 _nd_3 = heap_alloc(e, cls_fit(2));
        e.mem[_nd_3 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_EXECUTION_TRACE_SCHEDULEADMISSIONREFUSED, _nd_2));
        e.mem[_nd_3 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
        r0 = 3;
        r1 = _v_182;
        r2 = _v_183;
        r3 = _v_184;
        r4 = _v_185;
        r5 = _v_186;
        r6 = _v_187;
        r7 = _v_188;
        r8 = _v_189;
        r9 = _v_190;
        r10 = _v_191;
        r11 = _v_192;
        r12 = _v_193;
        r13 = _v_194;
        r14 = _h_14;
        r15 = 0;
        r16 = 0;
        r17 = 1;
        r18 = term_ctr(CID_CON, _nd_3);
        WL_RETN(19);
      }
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K401)
  {
    WL_POPN(13);
    Term _schema_2 = STK(0);
    Term _plan_2 = STK(1);
    Term _h_20 = STK(2);
    u32 _h_21 = STK(3);
    Term _h_22 = STK(4);
    Term _h_23 = STK(5);
    u32 _h_24 = STK(6);
    u32 _h_25 = STK(7);
    Term _h_26 = STK(8);
    Term _h_27 = STK(9);
    Term _h_28 = STK(10);
    Term _h_29 = STK(11);
    Term _h_30 = STK(12);
    u32 _h_18 = r0;
    Term _h_19 = r1;
    WL_OPEN
    Term _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    u32 _v_29 = 0;
    Term _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    u32 _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    Term _v_36 = 0;
    Term _v_37 = 0;
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    u32 _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    Term _v_44 = 0;
    Term _v_45 = 0;
    u32 _v_46 = 0;
    Term _v_47 = 0;
    u32 _v_48 = 0;
    Term _v_49 = 0;
    Term _v_50 = 0;
    Term _v_51 = 0;
    Term _o_1[13];
    if (spin_78(e, _o_1, _schema_2, blk_loc(e.mem, _schema_2), _h_29, blk_loc(e.mem, _h_29), _h_24, _h_25, _h_26, blk_loc(e.mem, _h_26), _h_27, blk_loc(e.mem, _h_27), _h_28, blk_loc(e.mem, _h_28), 1, _plan_2, blk_loc(e.mem, _plan_2), _h_21, _h_22, blk_loc(e.mem, _h_22), _h_23, blk_loc(e.mem, _h_23), _h_20, blk_loc(e.mem, _h_20)) == 0) {
      return 0;
    }
    _v_39 = _o_1[0];
    _v_40 = _o_1[1];
    _v_41 = _o_1[2];
    _v_42 = _o_1[3];
    _v_43 = _o_1[4];
    _v_44 = _o_1[5];
    _v_45 = _o_1[6];
    _v_46 = _o_1[7];
    _v_47 = _o_1[8];
    _v_48 = _o_1[9];
    _v_49 = _o_1[10];
    _v_50 = _o_1[11];
    _v_51 = _o_1[12];
    _v_26 = _v_39;
    _v_27 = _v_40;
    _v_28 = _v_41;
    _v_29 = _v_42;
    _v_30 = _v_43;
    _v_31 = _v_44;
    _v_32 = _v_45;
    _v_33 = _v_46;
    _v_34 = _v_47;
    _v_35 = _v_48;
    _v_36 = _v_49;
    _v_37 = _v_50;
    _v_38 = _v_51;
    r0 = 0;
    r1 = _v_26;
    r2 = _v_27;
    r3 = _v_28;
    r4 = _v_29;
    r5 = _v_30;
    r6 = _v_31;
    r7 = _v_32;
    r8 = _v_33;
    r9 = _v_34;
    r10 = _v_35;
    r11 = _v_36;
    r12 = _v_37;
    r13 = _v_38;
    r14 = _h_30;
    r15 = 0;
    r16 = 0;
    r17 = _h_18;
    r18 = _h_19;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0_K402)
  {
    WL_POPN(15);
    Term _schema_3 = STK(0);
    Term _plan_3 = STK(1);
    Term _h_33 = STK(2);
    u32 _h_34 = STK(3);
    Term _h_35 = STK(4);
    Term _h_36 = STK(5);
    u32 _h_37 = STK(6);
    u32 _h_38 = STK(7);
    Term _h_39 = STK(8);
    Term _h_40 = STK(9);
    Term _h_41 = STK(10);
    Term _h_42 = STK(11);
    u32 _h_43 = STK(12);
    u32 _h_44 = STK(13);
    Term _h_45 = STK(14);
    u32 _h_31 = r0;
    Term _h_32 = r1;
    WL_OPEN
    Term _v_78 = 0;
    Term _v_79 = 0;
    u32 _v_80 = 0;
    u32 _v_81 = 0;
    Term _v_82 = 0;
    Term _v_83 = 0;
    Term _v_84 = 0;
    u32 _v_85 = 0;
    Term _v_86 = 0;
    u32 _v_87 = 0;
    Term _v_88 = 0;
    Term _v_89 = 0;
    Term _v_90 = 0;
    Term _v_91 = 0;
    Term _v_92 = 0;
    u32 _v_93 = 0;
    u32 _v_94 = 0;
    Term _v_95 = 0;
    Term _v_96 = 0;
    Term _v_97 = 0;
    u32 _v_98 = 0;
    Term _v_99 = 0;
    u32 _v_100 = 0;
    Term _v_101 = 0;
    Term _v_102 = 0;
    Term _v_103 = 0;
    Term _o_3[13];
    if (spin_78(e, _o_3, _schema_3, blk_loc(e.mem, _schema_3), _h_42, blk_loc(e.mem, _h_42), _h_37, _h_38, _h_39, blk_loc(e.mem, _h_39), _h_40, blk_loc(e.mem, _h_40), _h_41, blk_loc(e.mem, _h_41), 1, _plan_3, blk_loc(e.mem, _plan_3), _h_34, _h_35, blk_loc(e.mem, _h_35), _h_36, blk_loc(e.mem, _h_36), _h_33, blk_loc(e.mem, _h_33)) == 0) {
      return 0;
    }
    _v_91 = _o_3[0];
    _v_92 = _o_3[1];
    _v_93 = _o_3[2];
    _v_94 = _o_3[3];
    _v_95 = _o_3[4];
    _v_96 = _o_3[5];
    _v_97 = _o_3[6];
    _v_98 = _o_3[7];
    _v_99 = _o_3[8];
    _v_100 = _o_3[9];
    _v_101 = _o_3[10];
    _v_102 = _o_3[11];
    _v_103 = _o_3[12];
    _v_78 = _v_91;
    _v_79 = _v_92;
    _v_80 = _v_93;
    _v_81 = _v_94;
    _v_82 = _v_95;
    _v_83 = _v_96;
    _v_84 = _v_97;
    _v_85 = _v_98;
    _v_86 = _v_99;
    _v_87 = _v_100;
    _v_88 = _v_101;
    _v_89 = _v_102;
    _v_90 = _v_103;
    r0 = 1;
    r1 = _v_78;
    r2 = _v_79;
    r3 = _v_80;
    r4 = _v_81;
    r5 = _v_82;
    r6 = _v_83;
    r7 = _v_84;
    r8 = _v_85;
    r9 = _v_86;
    r10 = _v_87;
    r11 = _v_88;
    r12 = _v_89;
    r13 = _v_90;
    r14 = _h_43;
    r15 = _h_44;
    r16 = _h_45;
    r17 = _h_31;
    r18 = _h_32;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS)
  {
    Term _items_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_items_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[4];
      u64 _sp_1 = ctr_take(e, _f_0, 4, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      spare_free(e, cls_fit(4), _sp_1);
      term_sink(e, _f_4);
      term_sink(e, _f_5);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_3;
        STK(1) = FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS_K425;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS_K425, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_3;
        WL_CONT = term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS_K425, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      _items_0 = r0;
      WL_AGAIN(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS_K425)
  {
    WL_POPN(1);
    u32 _f_6 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_6);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0)
  {
    Term _fields_0 = r0;
    WL_OPEN
    WL_SPIN
    if (term_aux(_fields_0) == CID_NIL) {
      r0 = term_pak(CID_NIL, 0);
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _fields_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[9];
      u64 _sp_1 = ctr_take(e, _f_0, 9, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      u32 _f_6 = _fb_1[4];
      Term _f_7 = _fb_1[5];
      Term _f_8 = _fb_1[6];
      u32 _f_9 = _fb_1[7];
      Term _f_10 = _fb_1[8];
      spare_free(e, cls_fit(9), _sp_1);
      term_sink(e, _f_7);
      term_sink(e, _f_8);
      term_sink(e, _f_10);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(5);
        STK(0) = _f_2;
        STK(1) = _f_3;
        STK(2) = _f_4;
        STK(3) = _f_5;
        STK(4) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0_K427;
        WL_PUSHN(5);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0_K427, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_2;
        e.mem[_t_0 + 1] = _f_3;
        e.mem[_t_0 + 2] = _f_4;
        e.mem[_t_0 + 3] = _f_5;
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0_K427, _t_0);
        WL_IDX = 4;
      }
      r0 = _f_1;
      _fields_0 = r0;
      WL_AGAIN(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0_K427)
  {
    WL_POPN(4);
    u32 _f_11 = STK(0);
    u32 _f_12 = STK(1);
    Term _f_13 = STK(2);
    Term _f_14 = STK(3);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_11);
    e.mem[_nd_0 + 1] = rfc_seal(e, _f_12);
    e.mem[_nd_0 + 2] = rfc_seal(e, _f_13);
    e.mem[_nd_0 + 3] = rfc_seal(e, _f_14);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITY, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_CON, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID)
  {
    u32 _namespace_0 = r0;
    Term _registered_0 = r1;
    Term _items_0 = r2;
    Term _seen_0 = r3;
    WL_OPEN
    if (term_aux(_items_0) == CID_NIL) {
      term_sink(e, _seen_0);
      r0 = 1;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _items_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      Term _fb_1[4];
      u64 _sp_1 = ctr_take(e, _f_0, 4, _fb_1);
      u32 _f_2 = _fb_1[0];
      u32 _f_3 = _fb_1[1];
      Term _f_4 = _fb_1[2];
      Term _f_5 = _fb_1[3];
      spare_free(e, cls_fit(4), _sp_1);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(9);
        STK(0) = _namespace_0;
        STK(1) = _registered_0;
        STK(2) = _f_2;
        STK(3) = _f_3;
        STK(4) = _f_4;
        STK(5) = _f_5;
        STK(6) = _f_1;
        STK(7) = _seen_0;
        STK(8) = FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K429;
        WL_PUSHN(9);
      } else {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K429, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _namespace_0;
        e.mem[_t_0 + 1] = _registered_0;
        e.mem[_t_0 + 2] = _f_2;
        e.mem[_t_0 + 3] = _f_3;
        e.mem[_t_0 + 4] = _f_4;
        e.mem[_t_0 + 5] = _f_5;
        e.mem[_t_0 + 6] = _f_1;
        e.mem[_t_0 + 7] = _seen_0;
        WL_CONT = term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K429, _t_0);
        WL_IDX = 8;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES)) {
        u64 _t_1 = task_node(e, FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _registered_0;
        e.mem[_t_1 + 1] = _f_3;
        e.mem[_t_1 + 2] = _f_4;
        e.mem[_t_1 + 3] = _f_5;
        return term_tsk(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES, _t_1);
      }
      r0 = _registered_0;
      r1 = _f_3;
      r2 = _f_4;
      r3 = _f_5;
      WL_JMP(FID__________SRC_ECS_WORLD_REGISTRATION_LIST_MATCHES);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K429)
  {
    WL_POPN(8);
    u32 _namespace_1 = STK(0);
    Term _registered_1 = STK(1);
    u32 _f_6 = STK(2);
    u32 _f_7 = STK(3);
    Term _f_8 = STK(4);
    Term _f_9 = STK(5);
    Term _f_10 = STK(6);
    Term _seen_1 = STK(7);
    u32 _h_0 = r0;
    WL_OPEN
    term_sink(e, _f_8);
    term_sink(e, _f_9);
    _seen_1 = term_keep(e, _seen_1, 1);
    if (seq) {
      WL_ROOM(8);
      STK(0) = _namespace_1;
      STK(1) = _registered_1;
      STK(2) = _f_6;
      STK(3) = _f_7;
      STK(4) = _f_10;
      STK(5) = _seen_1;
      STK(6) = _h_0;
      STK(7) = FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K430;
      WL_PUSHN(8);
    } else {
      u64 _t_2 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K430, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _namespace_1;
      e.mem[_t_2 + 1] = _registered_1;
      e.mem[_t_2 + 2] = _f_6;
      e.mem[_t_2 + 3] = _f_7;
      e.mem[_t_2 + 4] = _f_10;
      e.mem[_t_2 + 5] = _seen_1;
      e.mem[_t_2 + 6] = _h_0;
      WL_CONT = term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K430, _t_2);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_CONTAINS)) {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_SCHEDULE_CONTAINS, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _seen_1;
      e.mem[_t_3 + 1] = _f_7;
      return term_tsk(FID__________SRC_ECS_SCHEDULE_CONTAINS, _t_3);
    }
    r0 = _seen_1;
    r1 = _f_7;
    WL_JMP(FID__________SRC_ECS_SCHEDULE_CONTAINS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K430)
  {
    WL_POPN(7);
    u32 _namespace_2 = STK(0);
    Term _registered_2 = STK(1);
    u32 _f_11 = STK(2);
    u32 _f_12 = STK(3);
    Term _f_13 = STK(4);
    Term _seen_2 = STK(5);
    u32 _h_2 = STK(6);
    u32 _h_1 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_12);
    e.mem[_nd_0 + 1] = rfc_seal(e, _seen_2);
    if (seq) {
      WL_ROOM(5);
      STK(0) = _namespace_2;
      STK(1) = _f_11;
      STK(2) = _h_2;
      STK(3) = _h_1;
      STK(4) = FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K431;
      WL_PUSHN(5);
    } else {
      u64 _t_4 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K431, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _namespace_2;
      e.mem[_t_4 + 1] = _f_11;
      e.mem[_t_4 + 2] = _h_2;
      e.mem[_t_4 + 3] = _h_1;
      WL_CONT = term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K431, _t_4);
      WL_IDX = 4;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID)) {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _namespace_2;
      e.mem[_t_5 + 1] = _registered_2;
      e.mem[_t_5 + 2] = _f_13;
      e.mem[_t_5 + 3] = term_ctr(CID_CON, _nd_0);
      return term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID, _t_5);
    }
    r0 = _namespace_2;
    r1 = _registered_2;
    r2 = _f_13;
    r3 = term_ctr(CID_CON, _nd_0);
    WL_JMP(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID_K431)
  {
    WL_POPN(4);
    u32 _namespace_3 = STK(0);
    u32 _f_14 = STK(1);
    u32 _h_4 = STK(2);
    u32 _h_5 = STK(3);
    u32 _h_3 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _o_0[1];
    if (spin_26(e, _o_0, _h_5) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    _v_2 = _v_3;
    u32 _v_4 = 0;
    Term _o_1[1];
    if (spin_30(e, _o_1, _v_2, _h_3) == 0) {
      return 0;
    }
    _v_4 = _o_1[0];
    _v_1 = _v_4;
    u32 _v_5 = 0;
    Term _o_2[1];
    if (spin_30(e, _o_2, _h_4, _v_1) == 0) {
      return 0;
    }
    _v_5 = _o_2[0];
    _v_0 = _v_5;
    u32 _v_6 = 0;
    Term _o_3[1];
    if (spin_30(e, _o_3, U32_BIN(_namespace_3, ==, _f_14), _v_0) == 0) {
      return 0;
    }
    _v_6 = _o_3[0];
    r0 = _v_6;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0)
  {
    Term _value_0 = r0;
    Term _value_1 = r1;
    u32 _value_2 = r2;
    u32 _value_3 = r3;
    Term _value_4 = r4;
    Term _value_5 = r5;
    Term _value_6 = r6;
    u32 _value_7 = r7;
    Term _value_8 = r8;
    u32 _value_9 = r9;
    Term _value_10 = r10;
    Term _value_11 = r11;
    Term _value_12 = r12;
    WL_OPEN
    if (_value_7 == 0) {
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0)) {
        u64 _t_0 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _value_0;
        e.mem[_t_0 + 1] = _value_1;
        e.mem[_t_0 + 2] = _value_8;
        e.mem[_t_0 + 3] = _value_9;
        e.mem[_t_0 + 4] = _value_10;
        e.mem[_t_0 + 5] = _value_11;
        e.mem[_t_0 + 6] = _value_12;
        e.mem[_t_0 + 7] = _value_2;
        e.mem[_t_0 + 8] = _value_3;
        e.mem[_t_0 + 9] = _value_4;
        e.mem[_t_0 + 10] = _value_5;
        e.mem[_t_0 + 11] = _value_6;
        e.mem[_t_0 + 12] = 0;
        e.mem[_t_0 + 13] = 0;
        e.mem[_t_0 + 14] = 0;
        return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0, _t_0);
      }
      r0 = _value_0;
      r1 = _value_1;
      r2 = _value_8;
      r3 = _value_9;
      r4 = _value_10;
      r5 = _value_11;
      r6 = _value_12;
      r7 = _value_2;
      r8 = _value_3;
      r9 = _value_4;
      r10 = _value_5;
      r11 = _value_6;
      r12 = 0;
      r13 = 0;
      r14 = 0;
      WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0);
    } else {
      u64 _nd_7 = heap_alloc(e, cls_fit(6));
      e.mem[_nd_7 + 0] = rfc_seal(e, _value_2);
      e.mem[_nd_7 + 1] = rfc_seal(e, _value_3);
      e.mem[_nd_7 + 2] = rfc_seal(e, _value_4);
      e.mem[_nd_7 + 3] = rfc_seal(e, _value_5);
      e.mem[_nd_7 + 4] = rfc_seal(e, _value_6);
      e.mem[_nd_7 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
      u64 _nd_8 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_8 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
      e.mem[_nd_8 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_7));
      if (seq) {
        WL_ROOM(8);
        STK(0) = _value_0;
        STK(1) = _value_1;
        STK(2) = _value_8;
        STK(3) = _value_9;
        STK(4) = _value_10;
        STK(5) = _value_11;
        STK(6) = _value_12;
        STK(7) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K441;
        WL_PUSHN(8);
      } else {
        u64 _t_7 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K441, WL_CONT, WL_IDX, 1);
        e.mem[_t_7 + 0] = _value_0;
        e.mem[_t_7 + 1] = _value_1;
        e.mem[_t_7 + 2] = _value_8;
        e.mem[_t_7 + 3] = _value_9;
        e.mem[_t_7 + 4] = _value_10;
        e.mem[_t_7 + 5] = _value_11;
        e.mem[_t_7 + 6] = _value_12;
        WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K441, _t_7);
        WL_IDX = 7;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_8 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_8 + 0] = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C435, 0);
        e.mem[_t_8 + 1] = term_ctr(CID_TUPLE, _nd_8);
        return term_tsk(FID_CLO_APPLY, _t_8);
      }
      r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C435, 0);
      r1 = term_ctr(CID_TUPLE, _nd_8);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C435)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _x_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[6];
    u64 _sp_1 = ctr_take(e, _f_1, 6, _fb_1);
    u32 _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    Term _f_5 = _fb_1[3];
    Term _f_6 = _fb_1[4];
    Term _f_7 = _fb_1[5];
    spare_free(e, cls_fit(6), _sp_1);
    Term _leftFold_0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C436, 0);
    Term _rightFold_0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C437, 0);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _rightFold_0;
      STK(1) = _f_2;
      STK(2) = _f_3;
      STK(3) = _f_4;
      STK(4) = _f_5;
      STK(5) = _f_6;
      STK(6) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K438;
      WL_PUSHN(7);
    } else {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K438, WL_CONT, WL_IDX, 1);
      e.mem[_t_1 + 0] = _rightFold_0;
      e.mem[_t_1 + 1] = _f_2;
      e.mem[_t_1 + 2] = _f_3;
      e.mem[_t_1 + 3] = _f_4;
      e.mem[_t_1 + 4] = _f_5;
      e.mem[_t_1 + 5] = _f_6;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K438, _t_1);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _leftFold_0;
      e.mem[_t_2 + 1] = term_pak(CID_UNIT, 0);
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _leftFold_0;
    r1 = term_pak(CID_UNIT, 0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C436)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_0[1];
    if (spin_51(e, _o_0) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_0);
    r0 = term_ctr(CID_TUPLE, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_C437)
  {
    Term _x_2 = r0;
    WL_OPEN
    Term _fb_2[6];
    u64 _sp_2 = ctr_take(e, _x_2, 6, _fb_2);
    u32 _f_8 = _fb_2[0];
    u32 _f_9 = _fb_2[1];
    Term _f_10 = _fb_2[2];
    Term _f_11 = _fb_2[3];
    Term _f_12 = _fb_2[4];
    Term _f_13 = _fb_2[5];
    spare_free(e, cls_fit(6), _sp_2);
    u32 _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _o_1[6];
    if (spin_85(e, _o_1, _f_8, _f_9, _f_10, blk_loc(e.mem, _f_10), _f_11, blk_loc(e.mem, _f_11), _f_12, blk_loc(e.mem, _f_12)) == 0) {
      return 0;
    }
    _v_1 = _o_1[0];
    _v_2 = _o_1[1];
    _v_3 = _o_1[2];
    _v_4 = _o_1[3];
    _v_5 = _o_1[4];
    _v_6 = _o_1[5];
    u64 _nd_1 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_1 + 0] = rfc_seal(e, _v_1);
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_2);
    e.mem[_nd_1 + 2] = rfc_seal(e, _v_3);
    e.mem[_nd_1 + 3] = rfc_seal(e, _v_4);
    e.mem[_nd_1 + 4] = rfc_seal(e, _v_5);
    e.mem[_nd_1 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_1));
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_6);
    r0 = term_ctr(CID_TUPLE, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K438)
  {
    WL_POPN(6);
    Term _rightFold_1 = STK(0);
    u32 _f_14 = STK(1);
    u32 _f_15 = STK(2);
    Term _f_16 = STK(3);
    Term _f_17 = STK(4);
    Term _f_18 = STK(5);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_3[2];
    u64 _sp_3 = ctr_take(e, _h_0, 2, _fb_3);
    Term _f_19 = _fb_3[0];
    Term _f_20 = _fb_3[1];
    spare_free(e, cls_fit(2), _sp_3);
    u64 _nd_3 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_3 + 0] = rfc_seal(e, _f_14);
    e.mem[_nd_3 + 1] = rfc_seal(e, _f_15);
    e.mem[_nd_3 + 2] = rfc_seal(e, _f_16);
    e.mem[_nd_3 + 3] = rfc_seal(e, _f_17);
    e.mem[_nd_3 + 4] = rfc_seal(e, _f_18);
    e.mem[_nd_3 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (seq) {
      WL_ROOM(2);
      STK(0) = _f_20;
      STK(1) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K439;
      WL_PUSHN(2);
    } else {
      u64 _t_3 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K439, WL_CONT, WL_IDX, 1);
      e.mem[_t_3 + 0] = _f_20;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K439, _t_3);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_4 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _rightFold_1;
      e.mem[_t_4 + 1] = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_3);
      return term_tsk(FID_CLO_APPLY, _t_4);
    }
    r0 = _rightFold_1;
    r1 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_3);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K439)
  {
    WL_POPN(1);
    Term _f_21 = STK(0);
    Term _h_1 = r0;
    WL_OPEN
    Term _fb_4[2];
    u64 _sp_4 = ctr_take(e, _h_1, 2, _fb_4);
    Term _f_22 = _fb_4[0];
    Term _f_23 = _fb_4[1];
    spare_free(e, cls_fit(2), _sp_4);
    Term _fb_5[6];
    u64 _sp_5 = ctr_take(e, _f_22, 6, _fb_5);
    u32 _f_24 = _fb_5[0];
    u32 _f_25 = _fb_5[1];
    Term _f_26 = _fb_5[2];
    Term _f_27 = _fb_5[3];
    Term _f_28 = _fb_5[4];
    Term _f_29 = _fb_5[5];
    spare_free(e, cls_fit(6), _sp_5);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _f_24;
      STK(1) = _f_25;
      STK(2) = _f_26;
      STK(3) = _f_27;
      STK(4) = _f_28;
      STK(5) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K440;
      WL_PUSHN(6);
    } else {
      u64 _t_5 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K440, WL_CONT, WL_IDX, 1);
      e.mem[_t_5 + 0] = _f_24;
      e.mem[_t_5 + 1] = _f_25;
      e.mem[_t_5 + 2] = _f_26;
      e.mem[_t_5 + 3] = _f_27;
      e.mem[_t_5 + 4] = _f_28;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K440, _t_5);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_6 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _f_21;
      e.mem[_t_6 + 1] = _f_23;
      return term_tsk(FID_LIST_APPEND, _t_6);
    }
    r0 = _f_21;
    r1 = _f_23;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K440)
  {
    WL_POPN(5);
    u32 _f_30 = STK(0);
    u32 _f_31 = STK(1);
    Term _f_32 = STK(2);
    Term _f_33 = STK(3);
    Term _f_34 = STK(4);
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_4 + 0] = rfc_seal(e, _f_30);
    e.mem[_nd_4 + 1] = rfc_seal(e, _f_31);
    e.mem[_nd_4 + 2] = rfc_seal(e, _f_32);
    e.mem[_nd_4 + 3] = rfc_seal(e, _f_33);
    e.mem[_nd_4 + 4] = rfc_seal(e, _f_34);
    e.mem[_nd_4 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_5 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_4));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_5));
    e.mem[_nd_6 + 1] = rfc_seal(e, _h_2);
    r0 = term_ctr(CID_TUPLE, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K441)
  {
    WL_POPN(7);
    Term _value_13 = STK(0);
    Term _value_14 = STK(1);
    Term _value_15 = STK(2);
    u32 _value_16 = STK(3);
    Term _value_17 = STK(4);
    Term _value_18 = STK(5);
    Term _value_19 = STK(6);
    Term _h_3 = r0;
    WL_OPEN
    Term _fb_6[2];
    u64 _sp_6 = ctr_take(e, _h_3, 2, _fb_6);
    Term _f_35 = _fb_6[0];
    Term _f_36 = _fb_6[1];
    spare_free(e, cls_fit(2), _sp_6);
    Term _fb_7[2];
    u64 _sp_7 = ctr_take(e, _f_35, 2, _fb_7);
    Term _f_37 = _fb_7[0];
    Term _f_38 = _fb_7[1];
    spare_free(e, cls_fit(2), _sp_7);
    Term _fb_8[6];
    u64 _sp_8 = ctr_take(e, _f_38, 6, _fb_8);
    u32 _f_39 = _fb_8[0];
    u32 _f_40 = _fb_8[1];
    Term _f_41 = _fb_8[2];
    Term _f_42 = _fb_8[3];
    Term _f_43 = _fb_8[4];
    Term _f_44 = _fb_8[5];
    spare_free(e, cls_fit(6), _sp_8);
    if (seq) {
      WL_ROOM(13);
      STK(0) = _value_13;
      STK(1) = _value_14;
      STK(2) = _value_15;
      STK(3) = _value_16;
      STK(4) = _value_17;
      STK(5) = _value_18;
      STK(6) = _value_19;
      STK(7) = _f_39;
      STK(8) = _f_40;
      STK(9) = _f_41;
      STK(10) = _f_42;
      STK(11) = _f_43;
      STK(12) = FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K442;
      WL_PUSHN(13);
    } else {
      u64 _t_9 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K442, WL_CONT, WL_IDX, 1);
      e.mem[_t_9 + 0] = _value_13;
      e.mem[_t_9 + 1] = _value_14;
      e.mem[_t_9 + 2] = _value_15;
      e.mem[_t_9 + 3] = _value_16;
      e.mem[_t_9 + 4] = _value_17;
      e.mem[_t_9 + 5] = _value_18;
      e.mem[_t_9 + 6] = _value_19;
      e.mem[_t_9 + 7] = _f_39;
      e.mem[_t_9 + 8] = _f_40;
      e.mem[_t_9 + 9] = _f_41;
      e.mem[_t_9 + 10] = _f_42;
      e.mem[_t_9 + 11] = _f_43;
      WL_CONT = term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K442, _t_9);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0)) {
      u64 _t_10 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = _f_36;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0, _t_10);
    }
    r0 = _f_36;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_CATALOG_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0_K442)
  {
    WL_POPN(12);
    Term _value_20 = STK(0);
    Term _value_21 = STK(1);
    Term _value_22 = STK(2);
    u32 _value_23 = STK(3);
    Term _value_24 = STK(4);
    Term _value_25 = STK(5);
    Term _value_26 = STK(6);
    u32 _f_45 = STK(7);
    u32 _f_46 = STK(8);
    Term _f_47 = STK(9);
    Term _f_48 = STK(10);
    Term _f_49 = STK(11);
    Term _h_4 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0)) {
      u64 _t_11 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _value_20;
      e.mem[_t_11 + 1] = _value_21;
      e.mem[_t_11 + 2] = _value_22;
      e.mem[_t_11 + 3] = _value_23;
      e.mem[_t_11 + 4] = _value_24;
      e.mem[_t_11 + 5] = _value_25;
      e.mem[_t_11 + 6] = _value_26;
      e.mem[_t_11 + 7] = _f_45;
      e.mem[_t_11 + 8] = _f_46;
      e.mem[_t_11 + 9] = _f_47;
      e.mem[_t_11 + 10] = _f_48;
      e.mem[_t_11 + 11] = _f_49;
      e.mem[_t_11 + 12] = 1;
      e.mem[_t_11 + 13] = _h_4;
      e.mem[_t_11 + 14] = term_pak(CID_NIL, 0);
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0, _t_11);
    }
    r0 = _value_20;
    r1 = _value_21;
    r2 = _value_22;
    r3 = _value_23;
    r4 = _value_24;
    r5 = _value_25;
    r6 = _value_26;
    r7 = _f_45;
    r8 = _f_46;
    r9 = _f_47;
    r10 = _f_48;
    r11 = _f_49;
    r12 = 1;
    r13 = _h_4;
    r14 = term_pak(CID_NIL, 0);
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_START_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_U32_SHOW)
  {
    u32 _a_0 = r0;
    WL_OPEN
    u32 _s_0 = U32_BIN(_a_0, ==, 0);
    if (_s_0 == 1) {
      r0 = term_ctr(CID_SCON, STAT_OFF + 14);
      WL_RETN(1);
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW_GO)) {
        u64 _t_0 = task_node(e, FID_U32_SHOW_GO, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = 10ull;
        e.mem[_t_0 + 1] = _a_0;
        e.mem[_t_0 + 2] = term_pak(CID_SNIL, 0);
        return term_tsk(FID_U32_SHOW_GO, _t_0);
      }
      r0 = 10ull;
      r1 = _a_0;
      r2 = term_pak(CID_SNIL, 0);
      WL_JMP(FID_U32_SHOW_GO);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_LOCAL_OBSERVED)
  {
    Term _owner_0 = r0;
    WL_OPEN
    Term _at_0 = blk_loc(e.mem, _owner_0);
    Term _at_1 = blk_at(_owner_0, 0ull, 0);
    u32 _c_0 = blk_read(e.mem, 0, _at_0, _at_1 + 0);
    Term _at_2 = blk_loc(e.mem, _owner_0);
    Term _at_3 = blk_at(_owner_0, 1ull, 0);
    u32 _c_1 = blk_read(e.mem, 0, _at_2, _at_3 + 0);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _owner_0;
      STK(1) = _c_1;
      STK(2) = FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K476;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K476, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _owner_0;
      e.mem[_t_0 + 1] = _c_1;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K476, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _c_0;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _c_0;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K476)
  {
    WL_POPN(2);
    Term _owner_1 = STK(0);
    u32 _c_2 = STK(1);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _owner_1;
      STK(1) = _h_0;
      STK(2) = FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K477;
      WL_PUSHN(3);
    } else {
      u64 _t_2 = task_node(e, FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K477, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _owner_1;
      e.mem[_t_2 + 1] = _h_0;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K477, _t_2);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_3 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _c_2;
      return term_tsk(FID_U32_SHOW, _t_3);
    }
    r0 = _c_2;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K477)
  {
    WL_POPN(2);
    Term _owner_2 = STK(0);
    Term _h_2 = STK(1);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _owner_2;
      STK(1) = _h_2;
      STK(2) = FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K478;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K478, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _owner_2;
      e.mem[_t_4 + 1] = _h_2;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K478, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 12);
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 12);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K478)
  {
    WL_POPN(2);
    Term _owner_3 = STK(0);
    Term _h_4 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _owner_3;
      STK(1) = FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K479;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K479, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _owner_3;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K479, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _h_4;
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _h_4;
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_LOCAL_OBSERVED_K479)
  {
    WL_POPN(1);
    Term _owner_4 = STK(0);
    Term _h_5 = r0;
    WL_OPEN
    r0 = _owner_4;
    r1 = _h_5;
    WL_RETN(2);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_RETRIED)
  {
    u32 _value_0 = r0;
    Term _value_1 = r1;
    Term _value_2 = r2;
    u32 _value_3 = r3;
    u32 _value_4 = r4;
    Term _value_5 = r5;
    Term _value_6 = r6;
    Term _value_7 = r7;
    u32 _value_8 = r8;
    Term _value_9 = r9;
    u32 _value_10 = r10;
    Term _value_11 = r11;
    Term _value_12 = r12;
    Term _value_13 = r13;
    Term _value_14 = r14;
    u32 _value_15 = r15;
    Term _value_16 = r16;
    u32 _value_17 = r17;
    Term _value_18 = r18;
    WL_OPEN
    if (_value_0 == 0) {
      term_sink(e, _value_14);
      term_sink(e, _value_18);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_LOCAL_DRIVER_RETRIED_K482;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_LOCAL_DRIVER_RETRIED_K482, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_LOCAL_DRIVER_RETRIED_K482, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LOCAL_FIXTURE_OBSERVED)) {
        u64 _t_1 = task_node(e, FID_LOCAL_FIXTURE_OBSERVED, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _value_1;
        e.mem[_t_1 + 1] = _value_2;
        e.mem[_t_1 + 2] = _value_3;
        e.mem[_t_1 + 3] = _value_4;
        e.mem[_t_1 + 4] = _value_5;
        e.mem[_t_1 + 5] = _value_6;
        e.mem[_t_1 + 6] = _value_7;
        e.mem[_t_1 + 7] = _value_8;
        e.mem[_t_1 + 8] = _value_9;
        e.mem[_t_1 + 9] = _value_10;
        e.mem[_t_1 + 10] = _value_11;
        e.mem[_t_1 + 11] = _value_12;
        e.mem[_t_1 + 12] = _value_13;
        return term_tsk(FID_LOCAL_FIXTURE_OBSERVED, _t_1);
      }
      r0 = _value_1;
      r1 = _value_2;
      r2 = _value_3;
      r3 = _value_4;
      r4 = _value_5;
      r5 = _value_6;
      r6 = _value_7;
      r7 = _value_8;
      r8 = _value_9;
      r9 = _value_10;
      r10 = _value_11;
      r11 = _value_12;
      r12 = _value_13;
      WL_JMP(FID_LOCAL_FIXTURE_OBSERVED);
    } else {
      term_sink(e, _value_1);
      term_sink(e, _value_2);
      term_sink(e, _value_5);
      term_sink(e, _value_6);
      term_sink(e, _value_7);
      term_sink(e, _value_9);
      term_sink(e, _value_11);
      term_sink(e, _value_12);
      term_sink(e, _value_13);
      term_sink(e, _value_14);
      term_sink(e, _value_16);
      term_sink(e, _value_18);
      r0 = term_ctr(CID_SCON, STAT_OFF + 56);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_RETRIED_K482)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    u32 _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    u32 _h_7 = r7;
    Term _h_8 = r8;
    u32 _h_9 = r9;
    Term _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_LOCAL_DRIVER_OBSERVED)) {
      u64 _t_2 = task_node(e, FID_LOCAL_DRIVER_OBSERVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = term_clo(FID_LOCAL_DRIVER_RETRIED_C483, 0);
      e.mem[_t_2 + 1] = term_ctr(CID_SCON, STAT_OFF + 32);
      e.mem[_t_2 + 2] = _h_0;
      e.mem[_t_2 + 3] = _h_1;
      e.mem[_t_2 + 4] = _h_2;
      e.mem[_t_2 + 5] = _h_3;
      e.mem[_t_2 + 6] = _h_4;
      e.mem[_t_2 + 7] = _h_5;
      e.mem[_t_2 + 8] = _h_6;
      e.mem[_t_2 + 9] = _h_7;
      e.mem[_t_2 + 10] = _h_8;
      e.mem[_t_2 + 11] = _h_9;
      e.mem[_t_2 + 12] = _h_10;
      e.mem[_t_2 + 13] = _h_11;
      e.mem[_t_2 + 14] = _h_12;
      e.mem[_t_2 + 15] = _h_13;
      return term_tsk(FID_LOCAL_DRIVER_OBSERVED, _t_2);
    }
    r0 = term_clo(FID_LOCAL_DRIVER_RETRIED_C483, 0);
    r1 = term_ctr(CID_SCON, STAT_OFF + 32);
    r2 = _h_0;
    r3 = _h_1;
    r4 = _h_2;
    r5 = _h_3;
    r6 = _h_4;
    r7 = _h_5;
    r8 = _h_6;
    r9 = _h_7;
    r10 = _h_8;
    r11 = _h_9;
    r12 = _h_10;
    r13 = _h_11;
    r14 = _h_12;
    r15 = _h_13;
    WL_JMP(FID_LOCAL_DRIVER_OBSERVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_RETRIED_C483)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[9];
    u64 _sp_0 = ctr_take(e, _x_0, 9, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    u32 _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    u32 _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    spare_free(e, cls_fit(9), _sp_0);
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _f_2, 2, _fb_1);
    Term _f_9 = _fb_1[0];
    Term _f_10 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    Term _fb_2[6];
    u64 _sp_2 = ctr_take(e, _f_10, 6, _fb_2);
    u32 _f_11 = _fb_2[0];
    u32 _f_12 = _fb_2[1];
    Term _f_13 = _fb_2[2];
    Term _f_14 = _fb_2[3];
    Term _f_15 = _fb_2[4];
    Term _f_16 = _fb_2[5];
    spare_free(e, cls_fit(6), _sp_2);
    term_sink(e, _f_0);
    term_sink(e, _f_1);
    term_sink(e, _f_13);
    term_sink(e, _f_14);
    term_sink(e, _f_15);
    term_sink(e, _f_4);
    term_sink(e, _f_6);
    term_sink(e, _f_7);
    term_sink(e, _f_8);
    r0 = term_pak(CID_SNIL, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K485;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K485, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K485, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K485)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_OBSERVED)
  {
    Term _app_0 = r0;
    Term _app_1 = r1;
    u32 _app_2 = r2;
    u32 _app_3 = r3;
    Term _app_4 = r4;
    Term _app_5 = r5;
    Term _app_6 = r6;
    u32 _app_7 = r7;
    Term _app_8 = r8;
    u32 _app_9 = r9;
    Term _app_10 = r10;
    Term _app_11 = r11;
    Term _app_12 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(13);
      STK(0) = _app_0;
      STK(1) = _app_1;
      STK(2) = _app_2;
      STK(3) = _app_3;
      STK(4) = _app_4;
      STK(5) = _app_5;
      STK(6) = _app_7;
      STK(7) = _app_8;
      STK(8) = _app_9;
      STK(9) = _app_10;
      STK(10) = _app_11;
      STK(11) = _app_12;
      STK(12) = FID_LOCAL_FIXTURE_OBSERVED_K521;
      WL_PUSHN(13);
    } else {
      u64 _t_0 = task_node(e, FID_LOCAL_FIXTURE_OBSERVED_K521, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _app_0;
      e.mem[_t_0 + 1] = _app_1;
      e.mem[_t_0 + 2] = _app_2;
      e.mem[_t_0 + 3] = _app_3;
      e.mem[_t_0 + 4] = _app_4;
      e.mem[_t_0 + 5] = _app_5;
      e.mem[_t_0 + 6] = _app_7;
      e.mem[_t_0 + 7] = _app_8;
      e.mem[_t_0 + 8] = _app_9;
      e.mem[_t_0 + 9] = _app_10;
      e.mem[_t_0 + 10] = _app_11;
      e.mem[_t_0 + 11] = _app_12;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_OBSERVED_K521, _t_0);
      WL_IDX = 12;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOCAL_FIXTURE_LOCAL_OBSERVED)) {
      u64 _t_1 = task_node(e, FID_LOCAL_FIXTURE_LOCAL_OBSERVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _app_6;
      return term_tsk(FID_LOCAL_FIXTURE_LOCAL_OBSERVED, _t_1);
    }
    r0 = _app_6;
    WL_JMP(FID_LOCAL_FIXTURE_LOCAL_OBSERVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_OBSERVED_K521)
  {
    WL_POPN(12);
    Term _app_13 = STK(0);
    Term _app_14 = STK(1);
    u32 _app_15 = STK(2);
    u32 _app_16 = STK(3);
    Term _app_17 = STK(4);
    Term _app_18 = STK(5);
    u32 _app_19 = STK(6);
    Term _app_20 = STK(7);
    u32 _app_21 = STK(8);
    Term _app_22 = STK(9);
    Term _app_23 = STK(10);
    Term _app_24 = STK(11);
    Term _h_0 = r0;
    Term _h_1 = r1;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _o_0[14];
    if (spin_104(e, _o_0, _app_13, blk_loc(e.mem, _app_13), _app_14, blk_loc(e.mem, _app_14), _app_15, _app_16, _app_17, blk_loc(e.mem, _app_17), _app_18, blk_loc(e.mem, _app_18), _app_19, _app_20, blk_loc(e.mem, _app_20), _app_21, _app_22, blk_loc(e.mem, _app_22), _app_23, blk_loc(e.mem, _app_23), _app_24, blk_loc(e.mem, _app_24), _h_0, blk_loc(e.mem, _h_0), _h_1, blk_loc(e.mem, _h_1)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_OBSERVED)
  {
    Term _next_0 = r0;
    Term _label_0 = r1;
    Term _value_0 = r2;
    Term _value_1 = r3;
    u32 _value_2 = r4;
    u32 _value_3 = r5;
    Term _value_4 = r6;
    Term _value_5 = r7;
    Term _value_6 = r8;
    u32 _value_7 = r9;
    Term _value_8 = r10;
    u32 _value_9 = r11;
    Term _value_10 = r12;
    Term _value_11 = r13;
    Term _value_12 = r14;
    Term _value_13 = r15;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    Term _v_8 = 0;
    u32 _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    u32 _v_13 = 0;
    Term _v_14 = 0;
    Term _v_15 = 0;
    u32 _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    Term _v_19 = 0;
    Term _v_20 = 0;
    u32 _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    u32 _v_27 = 0;
    Term _o_1[14];
    if (spin_105(e, _o_1, _value_0, blk_loc(e.mem, _value_0), _value_1, blk_loc(e.mem, _value_1), _value_2, _value_3, _value_4, blk_loc(e.mem, _value_4), _value_5, blk_loc(e.mem, _value_5), _value_6, blk_loc(e.mem, _value_6), _value_7, _value_8, blk_loc(e.mem, _value_8), _value_9, _value_10, blk_loc(e.mem, _value_10), _value_11, blk_loc(e.mem, _value_11), _value_12, blk_loc(e.mem, _value_12)) == 0) {
      return 0;
    }
    _v_14 = _o_1[0];
    _v_15 = _o_1[1];
    _v_16 = _o_1[2];
    _v_17 = _o_1[3];
    _v_18 = _o_1[4];
    _v_19 = _o_1[5];
    _v_20 = _o_1[6];
    _v_21 = _o_1[7];
    _v_22 = _o_1[8];
    _v_23 = _o_1[9];
    _v_24 = _o_1[10];
    _v_25 = _o_1[11];
    _v_26 = _o_1[12];
    _v_27 = _o_1[13];
    _v_0 = _v_14;
    _v_1 = _v_15;
    _v_2 = _v_16;
    _v_3 = _v_17;
    _v_4 = _v_18;
    _v_5 = _v_19;
    _v_6 = _v_20;
    _v_7 = _v_21;
    _v_8 = _v_22;
    _v_9 = _v_23;
    _v_10 = _v_24;
    _v_11 = _v_25;
    _v_12 = _v_26;
    _v_13 = _v_27;
    if (seq) {
      WL_ROOM(17);
      STK(0) = _next_0;
      STK(1) = _label_0;
      STK(2) = _value_13;
      STK(3) = _v_0;
      STK(4) = _v_1;
      STK(5) = _v_2;
      STK(6) = _v_3;
      STK(7) = _v_4;
      STK(8) = _v_5;
      STK(9) = _v_6;
      STK(10) = _v_7;
      STK(11) = _v_8;
      STK(12) = _v_9;
      STK(13) = _v_10;
      STK(14) = _v_11;
      STK(15) = _v_12;
      STK(16) = FID_LOCAL_DRIVER_OBSERVED_K526;
      WL_PUSHN(17);
    } else {
      u64 _t_0 = task_node(e, FID_LOCAL_DRIVER_OBSERVED_K526, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _next_0;
      e.mem[_t_0 + 1] = _label_0;
      e.mem[_t_0 + 2] = _value_13;
      e.mem[_t_0 + 3] = _v_0;
      e.mem[_t_0 + 4] = _v_1;
      e.mem[_t_0 + 5] = _v_2;
      e.mem[_t_0 + 6] = _v_3;
      e.mem[_t_0 + 7] = _v_4;
      e.mem[_t_0 + 8] = _v_5;
      e.mem[_t_0 + 9] = _v_6;
      e.mem[_t_0 + 10] = _v_7;
      e.mem[_t_0 + 11] = _v_8;
      e.mem[_t_0 + 12] = _v_9;
      e.mem[_t_0 + 13] = _v_10;
      e.mem[_t_0 + 14] = _v_11;
      e.mem[_t_0 + 15] = _v_12;
      WL_CONT = term_tsk(FID_LOCAL_DRIVER_OBSERVED_K526, _t_0);
      WL_IDX = 16;
    }
    if (!DEVICE && !seq && fid_nofk(FID_U32_SHOW)) {
      u64 _t_1 = task_node(e, FID_U32_SHOW, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _v_13;
      return term_tsk(FID_U32_SHOW, _t_1);
    }
    r0 = _v_13;
    WL_JMP(FID_U32_SHOW);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_OBSERVED_K526)
  {
    WL_POPN(16);
    Term _next_1 = STK(0);
    Term _label_1 = STK(1);
    Term _value_14 = STK(2);
    Term _v_56 = STK(3);
    Term _v_57 = STK(4);
    u32 _v_58 = STK(5);
    u32 _v_59 = STK(6);
    Term _v_60 = STK(7);
    Term _v_61 = STK(8);
    Term _v_62 = STK(9);
    u32 _v_63 = STK(10);
    Term _v_64 = STK(11);
    u32 _v_65 = STK(12);
    Term _v_66 = STK(13);
    Term _v_67 = STK(14);
    Term _v_68 = STK(15);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_58);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_59);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_60);
    e.mem[_nd_0 + 3] = rfc_seal(e, _v_61);
    e.mem[_nd_0 + 4] = rfc_seal(e, _v_62);
    e.mem[_nd_0 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_0));
    u64 _nd_2 = heap_alloc(e, cls_fit(9));
    e.mem[_nd_2 + 0] = rfc_seal(e, _v_56);
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_57);
    e.mem[_nd_2 + 2] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_1));
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_63);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_64);
    e.mem[_nd_2 + 5] = rfc_seal(e, _v_65);
    e.mem[_nd_2 + 6] = rfc_seal(e, _v_66);
    e.mem[_nd_2 + 7] = rfc_seal(e, _v_67);
    e.mem[_nd_2 + 8] = rfc_seal(e, _v_68);
    if (seq) {
      WL_ROOM(4);
      STK(0) = _label_1;
      STK(1) = _value_14;
      STK(2) = _h_0;
      STK(3) = FID_LOCAL_DRIVER_OBSERVED_K527;
      WL_PUSHN(4);
    } else {
      u64 _t_2 = task_node(e, FID_LOCAL_DRIVER_OBSERVED_K527, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _label_1;
      e.mem[_t_2 + 1] = _value_14;
      e.mem[_t_2 + 2] = _h_0;
      WL_CONT = term_tsk(FID_LOCAL_DRIVER_OBSERVED_K527, _t_2);
      WL_IDX = 3;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _next_1;
      e.mem[_t_3 + 1] = term_ctr(CID__________SRC_ECS_ORDINARY_APP_RUN_APPLICATION, _nd_2);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _next_1;
    r1 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_RUN_APPLICATION, _nd_2);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_OBSERVED_K527)
  {
    WL_POPN(3);
    Term _label_2 = STK(0);
    Term _value_15 = STK(1);
    Term _h_2 = STK(2);
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _label_2;
      STK(1) = _h_2;
      STK(2) = FID_LOCAL_DRIVER_OBSERVED_K528;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_LOCAL_DRIVER_OBSERVED_K528, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _label_2;
      e.mem[_t_4 + 1] = _h_2;
      WL_CONT = term_tsk(FID_LOCAL_DRIVER_OBSERVED_K528, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _value_15;
      e.mem[_t_5 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _value_15;
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_OBSERVED_K528)
  {
    WL_POPN(2);
    Term _label_3 = STK(0);
    Term _h_4 = STK(1);
    Term _h_3 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _label_3;
      STK(1) = _h_4;
      STK(2) = FID_LOCAL_DRIVER_OBSERVED_K529;
      WL_PUSHN(3);
    } else {
      u64 _t_6 = task_node(e, FID_LOCAL_DRIVER_OBSERVED_K529, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _label_3;
      e.mem[_t_6 + 1] = _h_4;
      WL_CONT = term_tsk(FID_LOCAL_DRIVER_OBSERVED_K529, _t_6);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_ctr(CID_SCON, STAT_OFF + 70);
      e.mem[_t_7 + 1] = _h_3;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 70);
    r1 = _h_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_OBSERVED_K529)
  {
    WL_POPN(2);
    Term _label_4 = STK(0);
    Term _h_6 = STK(1);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _label_4;
      STK(1) = FID_LOCAL_DRIVER_OBSERVED_K530;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_LOCAL_DRIVER_OBSERVED_K530, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _label_4;
      WL_CONT = term_tsk(FID_LOCAL_DRIVER_OBSERVED_K530, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_9 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_6;
      e.mem[_t_9 + 1] = _h_5;
      return term_tsk(FID_STRING_APPEND, _t_9);
    }
    r0 = _h_6;
    r1 = _h_5;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_OBSERVED_K530)
  {
    WL_POPN(1);
    Term _label_5 = STK(0);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _label_5;
      STK(1) = FID_LOCAL_DRIVER_OBSERVED_K531;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_LOCAL_DRIVER_OBSERVED_K531, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _label_5;
      WL_CONT = term_tsk(FID_LOCAL_DRIVER_OBSERVED_K531, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_11 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_ctr(CID_SCON, STAT_OFF + 88);
      e.mem[_t_11 + 1] = _h_7;
      return term_tsk(FID_STRING_APPEND, _t_11);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 88);
    r1 = _h_7;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_OBSERVED_K531)
  {
    WL_POPN(1);
    Term _label_6 = STK(0);
    Term _h_8 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_12 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_12 + 0] = _label_6;
      e.mem[_t_12 + 1] = _h_8;
      return term_tsk(FID_STRING_APPEND, _t_12);
    }
    r0 = _label_6;
    r1 = _h_8;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_RUN)
  {
    Term _app_0 = r0;
    Term _app_1 = r1;
    u32 _app_2 = r2;
    u32 _app_3 = r3;
    Term _app_4 = r4;
    Term _app_5 = r5;
    Term _app_6 = r6;
    u32 _app_7 = r7;
    Term _app_8 = r8;
    u32 _app_9 = r9;
    Term _app_10 = r10;
    Term _app_11 = r11;
    Term _app_12 = r12;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LOCAL_FIXTURE_RUN_K556;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_LOCAL_FIXTURE_RUN_K556, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_RUN_K556, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0)) {
      u64 _t_1 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _app_0;
      e.mem[_t_1 + 1] = _app_1;
      e.mem[_t_1 + 2] = _app_2;
      e.mem[_t_1 + 3] = _app_3;
      e.mem[_t_1 + 4] = _app_4;
      e.mem[_t_1 + 5] = _app_5;
      e.mem[_t_1 + 6] = _app_6;
      e.mem[_t_1 + 7] = _app_7;
      e.mem[_t_1 + 8] = _app_8;
      e.mem[_t_1 + 9] = _app_9;
      e.mem[_t_1 + 10] = _app_10;
      e.mem[_t_1 + 11] = _app_11;
      e.mem[_t_1 + 12] = _app_12;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0, _t_1);
    }
    r0 = _app_0;
    r1 = _app_1;
    r2 = _app_2;
    r3 = _app_3;
    r4 = _app_4;
    r5 = _app_5;
    r6 = _app_6;
    r7 = _app_7;
    r8 = _app_8;
    r9 = _app_9;
    r10 = _app_10;
    r11 = _app_11;
    r12 = _app_12;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RUN_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_RUN_K556)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    u32 _h_3 = r3;
    u32 _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    Term _h_14 = r14;
    u32 _h_15 = r15;
    Term _h_16 = r16;
    u32 _h_17 = r17;
    Term _h_18 = r18;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    Term _v_2 = 0;
    u32 _v_3 = 0;
    u32 _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    Term _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _v_16 = 0;
    u32 _v_17 = 0;
    Term _v_18 = 0;
    Term _o_0[19];
    if (spin_98(e, _o_0, _h_0, _h_1, blk_loc(e.mem, _h_1), _h_2, blk_loc(e.mem, _h_2), _h_3, _h_4, _h_5, blk_loc(e.mem, _h_5), _h_6, blk_loc(e.mem, _h_6), _h_7, blk_loc(e.mem, _h_7), _h_8, _h_9, blk_loc(e.mem, _h_9), _h_10, _h_11, blk_loc(e.mem, _h_11), _h_12, blk_loc(e.mem, _h_12), _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, _h_16, blk_loc(e.mem, _h_16), _h_17, _h_18, blk_loc(e.mem, _h_18)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    _v_6 = _o_0[6];
    _v_7 = _o_0[7];
    _v_8 = _o_0[8];
    _v_9 = _o_0[9];
    _v_10 = _o_0[10];
    _v_11 = _o_0[11];
    _v_12 = _o_0[12];
    _v_13 = _o_0[13];
    _v_14 = _o_0[14];
    _v_15 = _o_0[15];
    _v_16 = _o_0[16];
    _v_17 = _o_0[17];
    _v_18 = _o_0[18];
    r0 = _v_0;
    r1 = _v_1;
    r2 = _v_2;
    r3 = _v_3;
    r4 = _v_4;
    r5 = _v_5;
    r6 = _v_6;
    r7 = _v_7;
    r8 = _v_8;
    r9 = _v_9;
    r10 = _v_10;
    r11 = _v_11;
    r12 = _v_12;
    r13 = _v_13;
    r14 = _v_14;
    r15 = _v_15;
    r16 = _v_16;
    r17 = _v_17;
    r18 = _v_18;
    WL_RETN(19);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C564)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[6];
    u64 _sp_0 = ctr_take(e, _x_0, 6, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    Term _f_3 = _fb_0[3];
    u32 _f_4 = _fb_0[4];
    Term _f_5 = _fb_0[5];
    spare_free(e, cls_fit(6), _sp_0);
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _v_34 = 0;
    u32 _v_35 = 0;
    Term _v_36 = 0;
    u32 _v_37 = 0;
    Term _o_0[7];
    if (spin_6(e, _o_0, _f_0, blk_loc(e.mem, _f_0), _f_1, blk_loc(e.mem, _f_1), _f_2, blk_loc(e.mem, _f_2), _f_3, blk_loc(e.mem, _f_3), _f_4, _f_5, blk_loc(e.mem, _f_5)) == 0) {
      return 0;
    }
    _v_31 = _o_0[0];
    _v_32 = _o_0[1];
    _v_33 = _o_0[2];
    _v_34 = _o_0[3];
    _v_35 = _o_0[4];
    _v_36 = _o_0[5];
    _v_37 = _o_0[6];
    u64 _nd_0 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_0 + 0] = rfc_seal(e, _v_31);
    e.mem[_nd_0 + 1] = rfc_seal(e, _v_32);
    e.mem[_nd_0 + 2] = rfc_seal(e, _v_33);
    e.mem[_nd_0 + 3] = rfc_seal(e, _v_34);
    e.mem[_nd_0 + 4] = rfc_seal(e, _v_35);
    e.mem[_nd_0 + 5] = rfc_seal(e, _v_36);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, _v_37);
    r0 = term_ctr(CID_TUPLE, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C565)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_1[6];
    u64 _sp_1 = ctr_take(e, _x_1, 6, _fb_1);
    Term _f_6 = _fb_1[0];
    Term _f_7 = _fb_1[1];
    Term _f_8 = _fb_1[2];
    Term _f_9 = _fb_1[3];
    u32 _f_10 = _fb_1[4];
    Term _f_11 = _fb_1[5];
    spare_free(e, cls_fit(6), _sp_1);
    u64 _nd_2 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_2 + 0] = _f_6;
    e.mem[_nd_2 + 1] = _f_7;
    e.mem[_nd_2 + 2] = _f_8;
    e.mem[_nd_2 + 3] = _f_9;
    e.mem[_nd_2 + 4] = _f_10;
    e.mem[_nd_2 + 5] = _f_11;
    r0 = term_clo(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C566, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_DEFINE_0_C566)
  {
    Term _f_12 = r0;
    Term _f_13 = r1;
    Term _f_14 = r2;
    Term _f_15 = r3;
    u32 _f_16 = r4;
    Term _f_17 = r5;
    Term _x_2 = r6;
    WL_OPEN
    Term _v_38 = 0;
    Term _v_39 = 0;
    Term _v_40 = 0;
    Term _v_41 = 0;
    u32 _v_42 = 0;
    Term _v_43 = 0;
    Term _o_1[6];
    if (spin_11(e, _o_1, _f_12, blk_loc(e.mem, _f_12), _f_13, blk_loc(e.mem, _f_13), _f_14, blk_loc(e.mem, _f_14), _f_15, blk_loc(e.mem, _f_15), _f_16, _f_17, blk_loc(e.mem, _f_17), _x_2) == 0) {
      return 0;
    }
    _v_38 = _o_1[0];
    _v_39 = _o_1[1];
    _v_40 = _o_1[2];
    _v_41 = _o_1[3];
    _v_42 = _o_1[4];
    _v_43 = _o_1[5];
    u64 _nd_3 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_3 + 0] = rfc_seal(e, _v_38);
    e.mem[_nd_3 + 1] = rfc_seal(e, _v_39);
    e.mem[_nd_3 + 2] = rfc_seal(e, _v_40);
    e.mem[_nd_3 + 3] = rfc_seal(e, _v_41);
    e.mem[_nd_3 + 4] = rfc_seal(e, _v_42);
    e.mem[_nd_3 + 5] = rfc_seal(e, _v_43);
    r0 = term_ctr(CID__________SRC_ECS_TRANSACTION_TX, _nd_3);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH)
  {
    Term _value_0 = r0;
    u32 _value_1 = r1;
    u32 _value_2 = r2;
    Term _value_3 = r3;
    Term _value_4 = r4;
    Term _value_5 = r5;
    u32 _value_6 = r6;
    WL_OPEN
    Term _key_0 = term_ctr(CID_SCON, STAT_OFF + 8);
    _key_0 = term_keep(e, _key_0, 1);
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = rfc_seal(e, 1);
    e.mem[_nd_0 + 1] = rfc_seal(e, _key_0);
    e.mem[_nd_0 + 2] = rfc_seal(e, _key_0);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_SCHEMA_FRAGMENTS_ENTRY, _nd_0));
    e.mem[_nd_1 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    Term _schema_0 = term_ctr(CID_CON, _nd_1);
    Term _name_0 = term_ctr(CID_SCON, STAT_OFF + 154);
    u32 _barrier_0 = 0;
    u64 _nd_5 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_5 + 0] = rfc_seal(e, _value_1);
    e.mem[_nd_5 + 1] = rfc_seal(e, _value_2);
    e.mem[_nd_5 + 2] = rfc_seal(e, _value_3);
    e.mem[_nd_5 + 3] = rfc_seal(e, _value_4);
    e.mem[_nd_5 + 4] = rfc_seal(e, _value_5);
    e.mem[_nd_5 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_6 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_6 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_6 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_5));
    if (seq) {
      WL_ROOM(6);
      STK(0) = _schema_0;
      STK(1) = _value_0;
      STK(2) = _value_6;
      STK(3) = _name_0;
      STK(4) = _barrier_0;
      STK(5) = FID_LOCAL_FIXTURE_ATTACH_K569;
      WL_PUSHN(6);
    } else {
      u64 _t_0 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K569, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _schema_0;
      e.mem[_t_0 + 1] = _value_0;
      e.mem[_t_0 + 2] = _value_6;
      e.mem[_t_0 + 3] = _name_0;
      e.mem[_t_0 + 4] = _barrier_0;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K569, _t_0);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = term_clo(FID_LOCAL_FIXTURE_ATTACH_C568, 0);
      e.mem[_t_1 + 1] = term_ctr(CID_TUPLE, _nd_6);
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = term_clo(FID_LOCAL_FIXTURE_ATTACH_C568, 0);
    r1 = term_ctr(CID_TUPLE, _nd_6);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_C568)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[2];
    u64 _sp_0 = ctr_take(e, _x_0, 2, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    spare_free(e, cls_fit(2), _sp_0);
    Term _fb_1[6];
    u64 _sp_1 = ctr_take(e, _f_1, 6, _fb_1);
    u32 _f_2 = _fb_1[0];
    u32 _f_3 = _fb_1[1];
    Term _f_4 = _fb_1[2];
    Term _f_5 = _fb_1[3];
    Term _f_6 = _fb_1[4];
    Term _f_7 = _fb_1[5];
    spare_free(e, cls_fit(6), _sp_1);
    u32 _v_0 = 0;
    u32 _v_1 = 0;
    Term _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _o_0[6];
    if (spin_96(e, _o_0, _f_2, _f_3, _f_4, blk_loc(e.mem, _f_4), _f_5, blk_loc(e.mem, _f_5), _f_6, blk_loc(e.mem, _f_6)) == 0) {
      return 0;
    }
    _v_0 = _o_0[0];
    _v_1 = _o_0[1];
    _v_2 = _o_0[2];
    _v_3 = _o_0[3];
    _v_4 = _o_0[4];
    _v_5 = _o_0[5];
    u64 _nd_2 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_2 + 0] = rfc_seal(e, _v_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _v_1);
    e.mem[_nd_2 + 2] = rfc_seal(e, _v_2);
    e.mem[_nd_2 + 3] = rfc_seal(e, _v_3);
    e.mem[_nd_2 + 4] = rfc_seal(e, _v_4);
    e.mem[_nd_2 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_3 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_2));
    u64 _nd_4 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_4 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_3));
    e.mem[_nd_4 + 1] = rfc_seal(e, _v_5);
    r0 = term_ctr(CID_TUPLE, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K569)
  {
    WL_POPN(5);
    Term _schema_1 = STK(0);
    Term _value_7 = STK(1);
    u32 _value_8 = STK(2);
    Term _name_1 = STK(3);
    u32 _barrier_1 = STK(4);
    Term _h_0 = r0;
    WL_OPEN
    Term _fb_2[2];
    u64 _sp_2 = ctr_take(e, _h_0, 2, _fb_2);
    Term _f_8 = _fb_2[0];
    Term _f_9 = _fb_2[1];
    spare_free(e, cls_fit(2), _sp_2);
    Term _fb_3[2];
    u64 _sp_3 = ctr_take(e, _f_8, 2, _fb_3);
    Term _f_10 = _fb_3[0];
    Term _f_11 = _fb_3[1];
    spare_free(e, cls_fit(2), _sp_3);
    Term _fb_4[6];
    u64 _sp_4 = ctr_take(e, _f_11, 6, _fb_4);
    u32 _f_12 = _fb_4[0];
    u32 _f_13 = _fb_4[1];
    Term _f_14 = _fb_4[2];
    Term _f_15 = _fb_4[3];
    Term _f_16 = _fb_4[4];
    Term _f_17 = _fb_4[5];
    spare_free(e, cls_fit(6), _sp_4);
    u64 _nd_14 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_14 + 0] = rfc_seal(e, _f_12);
    e.mem[_nd_14 + 1] = rfc_seal(e, _f_13);
    e.mem[_nd_14 + 2] = rfc_seal(e, _f_14);
    e.mem[_nd_14 + 3] = rfc_seal(e, _f_15);
    e.mem[_nd_14 + 4] = rfc_seal(e, _f_16);
    e.mem[_nd_14 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_15 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_15 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_15 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_14));
    if (seq) {
      WL_ROOM(7);
      STK(0) = _schema_1;
      STK(1) = _value_7;
      STK(2) = _value_8;
      STK(3) = _name_1;
      STK(4) = _barrier_1;
      STK(5) = _f_9;
      STK(6) = FID_LOCAL_FIXTURE_ATTACH_K576;
      WL_PUSHN(7);
    } else {
      u64 _t_8 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K576, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _schema_1;
      e.mem[_t_8 + 1] = _value_7;
      e.mem[_t_8 + 2] = _value_8;
      e.mem[_t_8 + 3] = _name_1;
      e.mem[_t_8 + 4] = _barrier_1;
      e.mem[_t_8 + 5] = _f_9;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K576, _t_8);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_9 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_clo(FID_LOCAL_FIXTURE_ATTACH_C570, 0);
      e.mem[_t_9 + 1] = term_ctr(CID_TUPLE, _nd_15);
      return term_tsk(FID_CLO_APPLY, _t_9);
    }
    r0 = term_clo(FID_LOCAL_FIXTURE_ATTACH_C570, 0);
    r1 = term_ctr(CID_TUPLE, _nd_15);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_C570)
  {
    Term _x_1 = r0;
    WL_OPEN
    Term _fb_5[2];
    u64 _sp_5 = ctr_take(e, _x_1, 2, _fb_5);
    Term _f_18 = _fb_5[0];
    Term _f_19 = _fb_5[1];
    spare_free(e, cls_fit(2), _sp_5);
    Term _fb_6[6];
    u64 _sp_6 = ctr_take(e, _f_19, 6, _fb_6);
    u32 _f_20 = _fb_6[0];
    u32 _f_21 = _fb_6[1];
    Term _f_22 = _fb_6[2];
    Term _f_23 = _fb_6[3];
    Term _f_24 = _fb_6[4];
    Term _f_25 = _fb_6[5];
    spare_free(e, cls_fit(6), _sp_6);
    Term _leftFold_0 = term_clo(FID_LOCAL_FIXTURE_ATTACH_C571, 0);
    Term _rightFold_0 = term_clo(FID_LOCAL_FIXTURE_ATTACH_C572, 0);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _rightFold_0;
      STK(1) = _f_20;
      STK(2) = _f_21;
      STK(3) = _f_22;
      STK(4) = _f_23;
      STK(5) = _f_24;
      STK(6) = FID_LOCAL_FIXTURE_ATTACH_K573;
      WL_PUSHN(7);
    } else {
      u64 _t_2 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K573, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _rightFold_0;
      e.mem[_t_2 + 1] = _f_20;
      e.mem[_t_2 + 2] = _f_21;
      e.mem[_t_2 + 3] = _f_22;
      e.mem[_t_2 + 4] = _f_23;
      e.mem[_t_2 + 5] = _f_24;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K573, _t_2);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _leftFold_0;
      e.mem[_t_3 + 1] = term_pak(CID_UNIT, 0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _leftFold_0;
    r1 = term_pak(CID_UNIT, 0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_C571)
  {
    Term _x_2 = r0;
    WL_OPEN
    Term _v_6 = 0;
    Term _o_1[1];
    if (spin_51(e, _o_1) == 0) {
      return 0;
    }
    _v_6 = _o_1[0];
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_7 + 1] = rfc_seal(e, _v_6);
    r0 = term_ctr(CID_TUPLE, _nd_7);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_C572)
  {
    Term _x_3 = r0;
    WL_OPEN
    Term _fb_7[6];
    u64 _sp_7 = ctr_take(e, _x_3, 6, _fb_7);
    u32 _f_26 = _fb_7[0];
    u32 _f_27 = _fb_7[1];
    Term _f_28 = _fb_7[2];
    Term _f_29 = _fb_7[3];
    Term _f_30 = _fb_7[4];
    Term _f_31 = _fb_7[5];
    spare_free(e, cls_fit(6), _sp_7);
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    Term _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _o_2[6];
    if (spin_85(e, _o_2, _f_26, _f_27, _f_28, blk_loc(e.mem, _f_28), _f_29, blk_loc(e.mem, _f_29), _f_30, blk_loc(e.mem, _f_30)) == 0) {
      return 0;
    }
    _v_7 = _o_2[0];
    _v_8 = _o_2[1];
    _v_9 = _o_2[2];
    _v_10 = _o_2[3];
    _v_11 = _o_2[4];
    _v_12 = _o_2[5];
    u64 _nd_8 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_8 + 0] = rfc_seal(e, _v_7);
    e.mem[_nd_8 + 1] = rfc_seal(e, _v_8);
    e.mem[_nd_8 + 2] = rfc_seal(e, _v_9);
    e.mem[_nd_8 + 3] = rfc_seal(e, _v_10);
    e.mem[_nd_8 + 4] = rfc_seal(e, _v_11);
    e.mem[_nd_8 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_8));
    e.mem[_nd_9 + 1] = rfc_seal(e, _v_12);
    r0 = term_ctr(CID_TUPLE, _nd_9);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K573)
  {
    WL_POPN(6);
    Term _rightFold_1 = STK(0);
    u32 _f_32 = STK(1);
    u32 _f_33 = STK(2);
    Term _f_34 = STK(3);
    Term _f_35 = STK(4);
    Term _f_36 = STK(5);
    Term _h_1 = r0;
    WL_OPEN
    Term _fb_8[2];
    u64 _sp_8 = ctr_take(e, _h_1, 2, _fb_8);
    Term _f_37 = _fb_8[0];
    Term _f_38 = _fb_8[1];
    spare_free(e, cls_fit(2), _sp_8);
    u64 _nd_10 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_10 + 0] = rfc_seal(e, _f_32);
    e.mem[_nd_10 + 1] = rfc_seal(e, _f_33);
    e.mem[_nd_10 + 2] = rfc_seal(e, _f_34);
    e.mem[_nd_10 + 3] = rfc_seal(e, _f_35);
    e.mem[_nd_10 + 4] = rfc_seal(e, _f_36);
    e.mem[_nd_10 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    if (seq) {
      WL_ROOM(2);
      STK(0) = _f_38;
      STK(1) = FID_LOCAL_FIXTURE_ATTACH_K574;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K574, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _f_38;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K574, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_5 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _rightFold_1;
      e.mem[_t_5 + 1] = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_10);
      return term_tsk(FID_CLO_APPLY, _t_5);
    }
    r0 = _rightFold_1;
    r1 = term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_10);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K574)
  {
    WL_POPN(1);
    Term _f_39 = STK(0);
    Term _h_2 = r0;
    WL_OPEN
    Term _fb_9[2];
    u64 _sp_9 = ctr_take(e, _h_2, 2, _fb_9);
    Term _f_40 = _fb_9[0];
    Term _f_41 = _fb_9[1];
    spare_free(e, cls_fit(2), _sp_9);
    Term _fb_10[6];
    u64 _sp_10 = ctr_take(e, _f_40, 6, _fb_10);
    u32 _f_42 = _fb_10[0];
    u32 _f_43 = _fb_10[1];
    Term _f_44 = _fb_10[2];
    Term _f_45 = _fb_10[3];
    Term _f_46 = _fb_10[4];
    Term _f_47 = _fb_10[5];
    spare_free(e, cls_fit(6), _sp_10);
    if (seq) {
      WL_ROOM(6);
      STK(0) = _f_42;
      STK(1) = _f_43;
      STK(2) = _f_44;
      STK(3) = _f_45;
      STK(4) = _f_46;
      STK(5) = FID_LOCAL_FIXTURE_ATTACH_K575;
      WL_PUSHN(6);
    } else {
      u64 _t_6 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K575, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _f_42;
      e.mem[_t_6 + 1] = _f_43;
      e.mem[_t_6 + 2] = _f_44;
      e.mem[_t_6 + 3] = _f_45;
      e.mem[_t_6 + 4] = _f_46;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K575, _t_6);
      WL_IDX = 5;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LIST_APPEND)) {
      u64 _t_7 = task_node(e, FID_LIST_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _f_39;
      e.mem[_t_7 + 1] = _f_41;
      return term_tsk(FID_LIST_APPEND, _t_7);
    }
    r0 = _f_39;
    r1 = _f_41;
    WL_JMP(FID_LIST_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K575)
  {
    WL_POPN(5);
    u32 _f_48 = STK(0);
    u32 _f_49 = STK(1);
    Term _f_50 = STK(2);
    Term _f_51 = STK(3);
    Term _f_52 = STK(4);
    Term _h_3 = r0;
    WL_OPEN
    u64 _nd_11 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_11 + 0] = rfc_seal(e, _f_48);
    e.mem[_nd_11 + 1] = rfc_seal(e, _f_49);
    e.mem[_nd_11 + 2] = rfc_seal(e, _f_50);
    e.mem[_nd_11 + 3] = rfc_seal(e, _f_51);
    e.mem[_nd_11 + 4] = rfc_seal(e, _f_52);
    e.mem[_nd_11 + 5] = rfc_seal(e, term_pak(CID_UNIT, 0));
    u64 _nd_12 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_12 + 0] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_12 + 1] = rfc_seal(e, term_ctr(CID__________SRC_ECS_ORDINARY_APP_LOCAL_FIELDS_INVOCATION, _nd_11));
    u64 _nd_13 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_13 + 0] = rfc_seal(e, term_ctr(CID_TUPLE, _nd_12));
    e.mem[_nd_13 + 1] = rfc_seal(e, _h_3);
    r0 = term_ctr(CID_TUPLE, _nd_13);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K576)
  {
    WL_POPN(6);
    Term _schema_2 = STK(0);
    Term _value_9 = STK(1);
    u32 _value_10 = STK(2);
    Term _name_2 = STK(3);
    u32 _barrier_2 = STK(4);
    Term _f_53 = STK(5);
    Term _h_4 = r0;
    WL_OPEN
    Term _v_13 = 0;
    Term _v_14 = 0;
    Term _o_3[1];
    if (spin_103(e, _o_3, _barrier_2, _f_53, blk_loc(e.mem, _f_53)) == 0) {
      return 0;
    }
    _v_14 = _o_3[0];
    _v_13 = _v_14;
    Term _fb_11[2];
    u64 _sp_11 = ctr_take(e, _h_4, 2, _fb_11);
    Term _f_54 = _fb_11[0];
    Term _f_55 = _fb_11[1];
    spare_free(e, cls_fit(2), _sp_11);
    Term _fb_12[2];
    u64 _sp_12 = ctr_take(e, _f_54, 2, _fb_12);
    Term _f_56 = _fb_12[0];
    Term _f_57 = _fb_12[1];
    spare_free(e, cls_fit(2), _sp_12);
    Term _fb_13[6];
    u64 _sp_13 = ctr_take(e, _f_57, 6, _fb_13);
    u32 _f_58 = _fb_13[0];
    u32 _f_59 = _fb_13[1];
    Term _f_60 = _fb_13[2];
    Term _f_61 = _fb_13[3];
    Term _f_62 = _fb_13[4];
    Term _f_63 = _fb_13[5];
    spare_free(e, cls_fit(6), _sp_13);
    Term _fb_14[15];
    u64 _sp_14 = ctr_take(e, _value_9, 15, _fb_14);
    u32 _f_64 = _fb_14[0];
    u32 _f_65 = _fb_14[1];
    u32 _f_66 = _fb_14[2];
    Term _f_67 = _fb_14[3];
    u32 _f_68 = _fb_14[4];
    Term _f_69 = _fb_14[5];
    Term _f_70 = _fb_14[6];
    Term _f_71 = _fb_14[7];
    Term _f_72 = _fb_14[8];
    Term _f_73 = _fb_14[9];
    Term _f_74 = _fb_14[10];
    Term _f_75 = _fb_14[11];
    Term _f_76 = _fb_14[12];
    u32 _f_77 = _fb_14[13];
    u32 _f_78 = _fb_14[14];
    _f_55 = term_keep(e, _f_55, 1);
    spare_free(e, cls_fit(15), _sp_14);
    if (seq) {
      WL_ROOM(25);
      STK(0) = _schema_2;
      STK(1) = _f_64;
      STK(2) = _f_65;
      STK(3) = _f_66;
      STK(4) = _f_67;
      STK(5) = _f_68;
      STK(6) = _f_69;
      STK(7) = _f_70;
      STK(8) = _f_71;
      STK(9) = _f_73;
      STK(10) = _f_74;
      STK(11) = _f_75;
      STK(12) = _f_76;
      STK(13) = _f_77;
      STK(14) = _f_78;
      STK(15) = _value_10;
      STK(16) = _v_13;
      STK(17) = _name_2;
      STK(18) = _f_58;
      STK(19) = _f_59;
      STK(20) = _f_60;
      STK(21) = _f_61;
      STK(22) = _f_62;
      STK(23) = _f_55;
      STK(24) = FID_LOCAL_FIXTURE_ATTACH_K577;
      WL_PUSHN(25);
    } else {
      u64 _t_10 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K577, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _schema_2;
      e.mem[_t_10 + 1] = _f_64;
      e.mem[_t_10 + 2] = _f_65;
      e.mem[_t_10 + 3] = _f_66;
      e.mem[_t_10 + 4] = _f_67;
      e.mem[_t_10 + 5] = _f_68;
      e.mem[_t_10 + 6] = _f_69;
      e.mem[_t_10 + 7] = _f_70;
      e.mem[_t_10 + 8] = _f_71;
      e.mem[_t_10 + 9] = _f_73;
      e.mem[_t_10 + 10] = _f_74;
      e.mem[_t_10 + 11] = _f_75;
      e.mem[_t_10 + 12] = _f_76;
      e.mem[_t_10 + 13] = _f_77;
      e.mem[_t_10 + 14] = _f_78;
      e.mem[_t_10 + 15] = _value_10;
      e.mem[_t_10 + 16] = _v_13;
      e.mem[_t_10 + 17] = _name_2;
      e.mem[_t_10 + 18] = _f_58;
      e.mem[_t_10 + 19] = _f_59;
      e.mem[_t_10 + 20] = _f_60;
      e.mem[_t_10 + 21] = _f_61;
      e.mem[_t_10 + 22] = _f_62;
      e.mem[_t_10 + 23] = _f_55;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K577, _t_10);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0)) {
      u64 _t_11 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _f_55;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0, _t_11);
    }
    r0 = _f_55;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K577)
  {
    WL_POPN(24);
    Term _schema_3 = STK(0);
    u32 _f_79 = STK(1);
    u32 _f_80 = STK(2);
    u32 _f_81 = STK(3);
    Term _f_82 = STK(4);
    u32 _f_83 = STK(5);
    Term _f_84 = STK(6);
    Term _f_85 = STK(7);
    Term _f_86 = STK(8);
    u32 _f_87 = STK(9);
    Term _f_88 = STK(10);
    Term _f_89 = STK(11);
    Term _f_90 = STK(12);
    u32 _f_91 = STK(13);
    u32 _f_92 = STK(14);
    u32 _value_11 = STK(15);
    Term _v_15 = STK(16);
    Term _name_3 = STK(17);
    u32 _f_93 = STK(18);
    u32 _f_94 = STK(19);
    Term _f_95 = STK(20);
    Term _f_96 = STK(21);
    Term _f_97 = STK(22);
    Term _f_98 = STK(23);
    Term _h_5 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _schema_3;
      STK(1) = _f_79;
      STK(2) = _f_80;
      STK(3) = _f_81;
      STK(4) = _f_82;
      STK(5) = _f_83;
      STK(6) = _f_84;
      STK(7) = _f_85;
      STK(8) = _f_86;
      STK(9) = _f_87;
      STK(10) = _f_88;
      STK(11) = _f_89;
      STK(12) = _f_90;
      STK(13) = _f_91;
      STK(14) = _f_92;
      STK(15) = _value_11;
      STK(16) = _v_15;
      STK(17) = _name_3;
      STK(18) = _f_93;
      STK(19) = _f_94;
      STK(20) = _f_95;
      STK(21) = _f_96;
      STK(22) = _f_97;
      STK(23) = _f_98;
      STK(24) = FID_LOCAL_FIXTURE_ATTACH_K578;
      WL_PUSHN(25);
    } else {
      u64 _t_12 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K578, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _schema_3;
      e.mem[_t_12 + 1] = _f_79;
      e.mem[_t_12 + 2] = _f_80;
      e.mem[_t_12 + 3] = _f_81;
      e.mem[_t_12 + 4] = _f_82;
      e.mem[_t_12 + 5] = _f_83;
      e.mem[_t_12 + 6] = _f_84;
      e.mem[_t_12 + 7] = _f_85;
      e.mem[_t_12 + 8] = _f_86;
      e.mem[_t_12 + 9] = _f_87;
      e.mem[_t_12 + 10] = _f_88;
      e.mem[_t_12 + 11] = _f_89;
      e.mem[_t_12 + 12] = _f_90;
      e.mem[_t_12 + 13] = _f_91;
      e.mem[_t_12 + 14] = _f_92;
      e.mem[_t_12 + 15] = _value_11;
      e.mem[_t_12 + 16] = _v_15;
      e.mem[_t_12 + 17] = _name_3;
      e.mem[_t_12 + 18] = _f_93;
      e.mem[_t_12 + 19] = _f_94;
      e.mem[_t_12 + 20] = _f_95;
      e.mem[_t_12 + 21] = _f_96;
      e.mem[_t_12 + 22] = _f_97;
      e.mem[_t_12 + 23] = _f_98;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K578, _t_12);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID)) {
      u64 _t_13 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _f_79;
      e.mem[_t_13 + 1] = _f_90;
      e.mem[_t_13 + 2] = _h_5;
      e.mem[_t_13 + 3] = term_pak(CID_NIL, 0);
      return term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID, _t_13);
    }
    r0 = _f_79;
    r1 = _f_90;
    r2 = _h_5;
    r3 = term_pak(CID_NIL, 0);
    WL_JMP(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDENTITIES_VALID);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K578)
  {
    WL_POPN(24);
    Term _schema_4 = STK(0);
    u32 _f_99 = STK(1);
    u32 _f_100 = STK(2);
    u32 _f_101 = STK(3);
    Term _f_102 = STK(4);
    u32 _f_103 = STK(5);
    Term _f_104 = STK(6);
    Term _f_105 = STK(7);
    Term _f_106 = STK(8);
    u32 _f_107 = STK(9);
    Term _f_108 = STK(10);
    Term _f_109 = STK(11);
    Term _f_110 = STK(12);
    u32 _f_111 = STK(13);
    u32 _f_112 = STK(14);
    u32 _value_12 = STK(15);
    Term _v_16 = STK(16);
    Term _name_4 = STK(17);
    u32 _f_113 = STK(18);
    u32 _f_114 = STK(19);
    Term _f_115 = STK(20);
    Term _f_116 = STK(21);
    Term _f_117 = STK(22);
    Term _f_118 = STK(23);
    u32 _h_6 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _schema_4;
      STK(1) = _f_99;
      STK(2) = _f_100;
      STK(3) = _f_101;
      STK(4) = _f_102;
      STK(5) = _f_103;
      STK(6) = _f_104;
      STK(7) = _f_105;
      STK(8) = _f_106;
      STK(9) = _f_107;
      STK(10) = _f_108;
      STK(11) = _f_109;
      STK(12) = _f_110;
      STK(13) = _f_111;
      STK(14) = _f_112;
      STK(15) = _value_12;
      STK(16) = _v_16;
      STK(17) = _name_4;
      STK(18) = _f_113;
      STK(19) = _f_114;
      STK(20) = _f_115;
      STK(21) = _f_116;
      STK(22) = _f_117;
      STK(23) = _h_6;
      STK(24) = FID_LOCAL_FIXTURE_ATTACH_K579;
      WL_PUSHN(25);
    } else {
      u64 _t_14 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K579, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _schema_4;
      e.mem[_t_14 + 1] = _f_99;
      e.mem[_t_14 + 2] = _f_100;
      e.mem[_t_14 + 3] = _f_101;
      e.mem[_t_14 + 4] = _f_102;
      e.mem[_t_14 + 5] = _f_103;
      e.mem[_t_14 + 6] = _f_104;
      e.mem[_t_14 + 7] = _f_105;
      e.mem[_t_14 + 8] = _f_106;
      e.mem[_t_14 + 9] = _f_107;
      e.mem[_t_14 + 10] = _f_108;
      e.mem[_t_14 + 11] = _f_109;
      e.mem[_t_14 + 12] = _f_110;
      e.mem[_t_14 + 13] = _f_111;
      e.mem[_t_14 + 14] = _f_112;
      e.mem[_t_14 + 15] = _value_12;
      e.mem[_t_14 + 16] = _v_16;
      e.mem[_t_14 + 17] = _name_4;
      e.mem[_t_14 + 18] = _f_113;
      e.mem[_t_14 + 19] = _f_114;
      e.mem[_t_14 + 20] = _f_115;
      e.mem[_t_14 + 21] = _f_116;
      e.mem[_t_14 + 22] = _f_117;
      e.mem[_t_14 + 23] = _h_6;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K579, _t_14);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0)) {
      u64 _t_15 = task_node(e, FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _f_118;
      return term_tsk(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0, _t_15);
    }
    r0 = _f_118;
    WL_JMP(FID__________SRC_ECS_ORDINARY_APP_EXECUTION_RECIPE_IDENTITIES_0);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K579)
  {
    WL_POPN(24);
    Term _schema_5 = STK(0);
    u32 _f_119 = STK(1);
    u32 _f_120 = STK(2);
    u32 _f_121 = STK(3);
    Term _f_122 = STK(4);
    u32 _f_123 = STK(5);
    Term _f_124 = STK(6);
    Term _f_125 = STK(7);
    Term _f_126 = STK(8);
    u32 _f_127 = STK(9);
    Term _f_128 = STK(10);
    Term _f_129 = STK(11);
    Term _f_130 = STK(12);
    u32 _f_131 = STK(13);
    u32 _f_132 = STK(14);
    u32 _value_13 = STK(15);
    Term _v_17 = STK(16);
    Term _name_5 = STK(17);
    u32 _f_133 = STK(18);
    u32 _f_134 = STK(19);
    Term _f_135 = STK(20);
    Term _f_136 = STK(21);
    Term _f_137 = STK(22);
    u32 _h_8 = STK(23);
    Term _h_7 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(25);
      STK(0) = _schema_5;
      STK(1) = _f_119;
      STK(2) = _f_120;
      STK(3) = _f_121;
      STK(4) = _f_122;
      STK(5) = _f_123;
      STK(6) = _f_124;
      STK(7) = _f_125;
      STK(8) = _f_126;
      STK(9) = _f_127;
      STK(10) = _f_128;
      STK(11) = _f_129;
      STK(12) = _f_130;
      STK(13) = _f_131;
      STK(14) = _f_132;
      STK(15) = _value_13;
      STK(16) = _v_17;
      STK(17) = _name_5;
      STK(18) = _f_133;
      STK(19) = _f_134;
      STK(20) = _f_135;
      STK(21) = _f_136;
      STK(22) = _f_137;
      STK(23) = _h_8;
      STK(24) = FID_LOCAL_FIXTURE_ATTACH_K580;
      WL_PUSHN(25);
    } else {
      u64 _t_16 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K580, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _schema_5;
      e.mem[_t_16 + 1] = _f_119;
      e.mem[_t_16 + 2] = _f_120;
      e.mem[_t_16 + 3] = _f_121;
      e.mem[_t_16 + 4] = _f_122;
      e.mem[_t_16 + 5] = _f_123;
      e.mem[_t_16 + 6] = _f_124;
      e.mem[_t_16 + 7] = _f_125;
      e.mem[_t_16 + 8] = _f_126;
      e.mem[_t_16 + 9] = _f_127;
      e.mem[_t_16 + 10] = _f_128;
      e.mem[_t_16 + 11] = _f_129;
      e.mem[_t_16 + 12] = _f_130;
      e.mem[_t_16 + 13] = _f_131;
      e.mem[_t_16 + 14] = _f_132;
      e.mem[_t_16 + 15] = _value_13;
      e.mem[_t_16 + 16] = _v_17;
      e.mem[_t_16 + 17] = _name_5;
      e.mem[_t_16 + 18] = _f_133;
      e.mem[_t_16 + 19] = _f_134;
      e.mem[_t_16 + 20] = _f_135;
      e.mem[_t_16 + 21] = _f_136;
      e.mem[_t_16 + 22] = _f_137;
      e.mem[_t_16 + 23] = _h_8;
      WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K580, _t_16);
      WL_IDX = 24;
    }
    if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS)) {
      u64 _t_17 = task_node(e, FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_7;
      return term_tsk(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS, _t_17);
    }
    r0 = _h_7;
    WL_JMP(FID__________SRC_ECS_CAPTURED_SCHEDULE_COMPOSITION_IDS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K580)
  {
    WL_POPN(24);
    Term _schema_6 = STK(0);
    u32 _f_138 = STK(1);
    u32 _f_139 = STK(2);
    u32 _f_140 = STK(3);
    Term _f_141 = STK(4);
    u32 _f_142 = STK(5);
    Term _f_143 = STK(6);
    Term _f_144 = STK(7);
    Term _f_145 = STK(8);
    u32 _f_146 = STK(9);
    Term _f_147 = STK(10);
    Term _f_148 = STK(11);
    Term _f_149 = STK(12);
    u32 _f_150 = STK(13);
    u32 _f_151 = STK(14);
    u32 _value_14 = STK(15);
    Term _v_18 = STK(16);
    Term _name_6 = STK(17);
    u32 _f_152 = STK(18);
    u32 _f_153 = STK(19);
    Term _f_154 = STK(20);
    Term _f_155 = STK(21);
    Term _f_156 = STK(22);
    u32 _h_10 = STK(23);
    Term _h_9 = r0;
    WL_OPEN
    u64 _nd_16 = heap_alloc(e, cls_fit(15));
    e.mem[_nd_16 + 0] = rfc_seal(e, _f_138);
    e.mem[_nd_16 + 1] = rfc_seal(e, _f_139);
    e.mem[_nd_16 + 2] = rfc_seal(e, _f_140);
    e.mem[_nd_16 + 3] = rfc_seal(e, _f_141);
    e.mem[_nd_16 + 4] = rfc_seal(e, _f_142);
    e.mem[_nd_16 + 5] = rfc_seal(e, _f_143);
    e.mem[_nd_16 + 6] = rfc_seal(e, _f_144);
    e.mem[_nd_16 + 7] = rfc_seal(e, _f_145);
    e.mem[_nd_16 + 8] = rfc_seal(e, term_pak(CID_UNIT, 0));
    e.mem[_nd_16 + 9] = rfc_seal(e, _f_146);
    e.mem[_nd_16 + 10] = rfc_seal(e, _f_147);
    e.mem[_nd_16 + 11] = rfc_seal(e, _f_148);
    e.mem[_nd_16 + 12] = rfc_seal(e, _f_149);
    e.mem[_nd_16 + 13] = rfc_seal(e, _f_150);
    e.mem[_nd_16 + 14] = rfc_seal(e, _f_151);
    if (_h_10 == 0) {
      term_sink(e, _schema_6);
      Term _world_0 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_16);
      term_sink(e, _v_18);
      term_sink(e, _name_6);
      term_sink(e, _h_9);
      r0 = 1;
      r1 = _world_0;
      r2 = _f_152;
      r3 = _f_153;
      r4 = _f_154;
      r5 = _f_155;
      r6 = _f_156;
      r7 = _value_14;
      r8 = 0;
      r9 = 0;
      r10 = 0;
      r11 = 0;
      r12 = 0;
      r13 = 0;
      WL_RETN(14);
    } else {
      Term _world_1 = term_ctr(CID__________SRC_ECS_WORLD_WORLD, _nd_16);
      _v_18 = term_keep(e, _v_18, 1);
      if (seq) {
        WL_ROOM(5);
        STK(0) = _schema_6;
        STK(1) = _world_1;
        STK(2) = _value_14;
        STK(3) = _v_18;
        STK(4) = FID_LOCAL_FIXTURE_ATTACH_K581;
        WL_PUSHN(5);
      } else {
        u64 _t_18 = task_node(e, FID_LOCAL_FIXTURE_ATTACH_K581, WL_CONT, WL_IDX, 1);
        e.mem[_t_18 + 0] = _schema_6;
        e.mem[_t_18 + 1] = _world_1;
        e.mem[_t_18 + 2] = _value_14;
        e.mem[_t_18 + 3] = _v_18;
        WL_CONT = term_tsk(FID_LOCAL_FIXTURE_ATTACH_K581, _t_18);
        WL_IDX = 4;
      }
      if (!DEVICE && !seq && fid_nofk(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0)) {
        u64 _t_19 = task_node(e, FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0, WL_CONT, WL_IDX, 0);
        e.mem[_t_19 + 0] = _f_138;
        e.mem[_t_19 + 1] = _name_6;
        e.mem[_t_19 + 2] = _v_18;
        e.mem[_t_19 + 3] = _h_9;
        e.mem[_t_19 + 4] = _f_152;
        e.mem[_t_19 + 5] = _f_153;
        e.mem[_t_19 + 6] = _f_154;
        e.mem[_t_19 + 7] = _f_155;
        e.mem[_t_19 + 8] = _f_156;
        return term_tsk(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0, _t_19);
      }
      r0 = _f_138;
      r1 = _name_6;
      r2 = _v_18;
      r3 = _h_9;
      r4 = _f_152;
      r5 = _f_153;
      r6 = _f_154;
      r7 = _f_155;
      r8 = _f_156;
      WL_JMP(FID__________SRC_ECS_SCHEDULE_PROVISION_BUILD_0);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_FIXTURE_ATTACH_K581)
  {
    WL_POPN(4);
    Term _schema_7 = STK(0);
    Term _world_2 = STK(1);
    u32 _value_15 = STK(2);
    Term _v_19 = STK(3);
    u32 _h_11 = r0;
    u32 _h_12 = r1;
    Term _h_13 = r2;
    Term _h_14 = r3;
    Term _h_15 = r4;
    Term _h_16 = r5;
    Term _h_17 = r6;
    Term _h_18 = r7;
    Term _h_19 = r8;
    Term _h_20 = r9;
    WL_OPEN
    u32 _v_20 = 0;
    Term _v_21 = 0;
    Term _v_22 = 0;
    u32 _v_23 = 0;
    Term _v_24 = 0;
    Term _v_25 = 0;
    Term _v_26 = 0;
    Term _v_27 = 0;
    u32 _v_28 = 0;
    Term _v_29 = 0;
    u32 _v_30 = 0;
    Term _v_31 = 0;
    Term _v_32 = 0;
    Term _v_33 = 0;
    Term _o_4[14];
    if (spin_90(e, _o_4, _schema_7, blk_loc(e.mem, _schema_7), _world_2, blk_loc(e.mem, _world_2), _value_15, _v_19, blk_loc(e.mem, _v_19), _h_11, _h_12, _h_13, blk_loc(e.mem, _h_13), _h_14, blk_loc(e.mem, _h_14), _h_15, blk_loc(e.mem, _h_15), _h_16, blk_loc(e.mem, _h_16), _h_17, blk_loc(e.mem, _h_17), _h_18, blk_loc(e.mem, _h_18), _h_19, blk_loc(e.mem, _h_19), _h_20, blk_loc(e.mem, _h_20)) == 0) {
      return 0;
    }
    _v_20 = _o_4[0];
    _v_21 = _o_4[1];
    _v_22 = _o_4[2];
    _v_23 = _o_4[3];
    _v_24 = _o_4[4];
    _v_25 = _o_4[5];
    _v_26 = _o_4[6];
    _v_27 = _o_4[7];
    _v_28 = _o_4[8];
    _v_29 = _o_4[9];
    _v_30 = _o_4[10];
    _v_31 = _o_4[11];
    _v_32 = _o_4[12];
    _v_33 = _o_4[13];
    r0 = _v_20;
    r1 = _v_21;
    r2 = _v_22;
    r3 = _v_23;
    r4 = _v_24;
    r5 = _v_25;
    r6 = _v_26;
    r7 = _v_27;
    r8 = _v_28;
    r9 = _v_29;
    r10 = _v_30;
    r11 = _v_31;
    r12 = _v_32;
    r13 = _v_33;
    WL_RETN(14);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_START)
  {
    Term _world_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _v_1 = 0;
    u32 _v_2 = 0;
    Term _v_3 = 0;
    Term _v_4 = 0;
    Term _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _v_12 = 0;
    Term _v_13 = 0;
    Term _v_14 = 0;
    u32 _v_15 = 0;
    Term _o_2[8];
    if (spin_114(e, _o_2, _world_0, blk_loc(e.mem, _world_0)) == 0) {
      return 0;
    }
    _v_8 = _o_2[0];
    _v_9 = _o_2[1];
    _v_10 = _o_2[2];
    _v_11 = _o_2[3];
    _v_12 = _o_2[4];
    _v_13 = _o_2[5];
    _v_14 = _o_2[6];
    _v_15 = _o_2[7];
    _v_0 = _v_8;
    _v_1 = _v_9;
    _v_2 = _v_10;
    _v_3 = _v_11;
    _v_4 = _v_12;
    _v_5 = _v_13;
    _v_6 = _v_14;
    _v_7 = _v_15;
    if (_v_0 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_LOCAL_DRIVER_START_K604;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_LOCAL_DRIVER_START_K604, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_LOCAL_DRIVER_START_K604, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LOCAL_FIXTURE_ATTACH)) {
        u64 _t_1 = task_node(e, FID_LOCAL_FIXTURE_ATTACH, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _v_1;
        e.mem[_t_1 + 1] = _v_2;
        e.mem[_t_1 + 2] = _v_3;
        e.mem[_t_1 + 3] = _v_4;
        e.mem[_t_1 + 4] = _v_5;
        e.mem[_t_1 + 5] = _v_6;
        e.mem[_t_1 + 6] = _v_7;
        return term_tsk(FID_LOCAL_FIXTURE_ATTACH, _t_1);
      }
      r0 = _v_1;
      r1 = _v_2;
      r2 = _v_3;
      r3 = _v_4;
      r4 = _v_5;
      r5 = _v_6;
      r6 = _v_7;
      WL_JMP(FID_LOCAL_FIXTURE_ATTACH);
    } else {
      term_sink(e, _v_1);
      term_sink(e, _v_3);
      term_sink(e, _v_4);
      term_sink(e, _v_5);
      term_sink(e, _v_6);
      r0 = term_ctr(CID_SCON, STAT_OFF + 232);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_START_K604)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    u32 _h_3 = r3;
    Term _h_4 = r4;
    Term _h_5 = r5;
    Term _h_6 = r6;
    Term _h_7 = r7;
    u32 _h_8 = r8;
    Term _h_9 = r9;
    u32 _h_10 = r10;
    Term _h_11 = r11;
    Term _h_12 = r12;
    Term _h_13 = r13;
    WL_OPEN
    if (_h_0 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_LOCAL_DRIVER_START_K605;
        WL_PUSHN(1);
      } else {
        u64 _t_2 = task_node(e, FID_LOCAL_DRIVER_START_K605, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_LOCAL_DRIVER_START_K605, _t_2);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LOCAL_FIXTURE_RUN)) {
        u64 _t_3 = task_node(e, FID_LOCAL_FIXTURE_RUN, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _h_1;
        e.mem[_t_3 + 1] = _h_2;
        e.mem[_t_3 + 2] = _h_3;
        e.mem[_t_3 + 3] = _h_4;
        e.mem[_t_3 + 4] = _h_5;
        e.mem[_t_3 + 5] = _h_6;
        e.mem[_t_3 + 6] = _h_7;
        e.mem[_t_3 + 7] = _h_8;
        e.mem[_t_3 + 8] = _h_9;
        e.mem[_t_3 + 9] = _h_10;
        e.mem[_t_3 + 10] = _h_11;
        e.mem[_t_3 + 11] = _h_12;
        e.mem[_t_3 + 12] = _h_13;
        return term_tsk(FID_LOCAL_FIXTURE_RUN, _t_3);
      }
      r0 = _h_1;
      r1 = _h_2;
      r2 = _h_3;
      r3 = _h_4;
      r4 = _h_5;
      r5 = _h_6;
      r6 = _h_7;
      r7 = _h_8;
      r8 = _h_9;
      r9 = _h_10;
      r10 = _h_11;
      r11 = _h_12;
      r12 = _h_13;
      WL_JMP(FID_LOCAL_FIXTURE_RUN);
    } else {
      term_sink(e, _h_1);
      term_sink(e, _h_2);
      term_sink(e, _h_4);
      term_sink(e, _h_5);
      term_sink(e, _h_6);
      term_sink(e, _h_7);
      term_sink(e, _h_9);
      term_sink(e, _h_11);
      term_sink(e, _h_12);
      term_sink(e, _h_13);
      r0 = term_ctr(CID_SCON, STAT_OFF + 180);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_START_K605)
  {
    u32 _h_14 = r0;
    Term _h_15 = r1;
    Term _h_16 = r2;
    u32 _h_17 = r3;
    u32 _h_18 = r4;
    Term _h_19 = r5;
    Term _h_20 = r6;
    Term _h_21 = r7;
    u32 _h_22 = r8;
    Term _h_23 = r9;
    u32 _h_24 = r10;
    Term _h_25 = r11;
    Term _h_26 = r12;
    Term _h_27 = r13;
    Term _h_28 = r14;
    u32 _h_29 = r15;
    Term _h_30 = r16;
    u32 _h_31 = r17;
    Term _h_32 = r18;
    WL_OPEN
    if (_h_14 == 1) {
      if (_h_28 == 1) {
        if (_h_29 == 0) {
          term_sink(e, _h_30);
          term_sink(e, _h_32);
          if (seq) {
            WL_ROOM(1);
            STK(0) = FID_LOCAL_DRIVER_START_K606;
            WL_PUSHN(1);
          } else {
            u64 _t_4 = task_node(e, FID_LOCAL_DRIVER_START_K606, WL_CONT, WL_IDX, 1);
            WL_CONT = term_tsk(FID_LOCAL_DRIVER_START_K606, _t_4);
            WL_IDX = 0;
          }
          if (!DEVICE && !seq && fid_nofk(FID_LOCAL_FIXTURE_OBSERVED)) {
            u64 _t_5 = task_node(e, FID_LOCAL_FIXTURE_OBSERVED, WL_CONT, WL_IDX, 0);
            e.mem[_t_5 + 0] = _h_15;
            e.mem[_t_5 + 1] = _h_16;
            e.mem[_t_5 + 2] = _h_17;
            e.mem[_t_5 + 3] = _h_18;
            e.mem[_t_5 + 4] = _h_19;
            e.mem[_t_5 + 5] = _h_20;
            e.mem[_t_5 + 6] = _h_21;
            e.mem[_t_5 + 7] = _h_22;
            e.mem[_t_5 + 8] = _h_23;
            e.mem[_t_5 + 9] = _h_24;
            e.mem[_t_5 + 10] = _h_25;
            e.mem[_t_5 + 11] = _h_26;
            e.mem[_t_5 + 12] = _h_27;
            return term_tsk(FID_LOCAL_FIXTURE_OBSERVED, _t_5);
          }
          r0 = _h_15;
          r1 = _h_16;
          r2 = _h_17;
          r3 = _h_18;
          r4 = _h_19;
          r5 = _h_20;
          r6 = _h_21;
          r7 = _h_22;
          r8 = _h_23;
          r9 = _h_24;
          r10 = _h_25;
          r11 = _h_26;
          r12 = _h_27;
          WL_JMP(FID_LOCAL_FIXTURE_OBSERVED);
        } else {
          term_sink(e, _h_15);
          term_sink(e, _h_16);
          term_sink(e, _h_19);
          term_sink(e, _h_20);
          term_sink(e, _h_21);
          term_sink(e, _h_23);
          term_sink(e, _h_25);
          term_sink(e, _h_26);
          term_sink(e, _h_27);
          term_sink(e, _h_30);
          term_sink(e, _h_32);
          r0 = term_ctr(CID_SCON, STAT_OFF + 144);
          WL_RETN(1);
        }
      } else {
        term_sink(e, _h_15);
        term_sink(e, _h_16);
        term_sink(e, _h_19);
        term_sink(e, _h_20);
        term_sink(e, _h_21);
        term_sink(e, _h_23);
        term_sink(e, _h_25);
        term_sink(e, _h_26);
        term_sink(e, _h_27);
        term_sink(e, _h_30);
        term_sink(e, _h_32);
        r0 = term_ctr(CID_SCON, STAT_OFF + 144);
        WL_RETN(1);
      }
    } else {
      term_sink(e, _h_15);
      term_sink(e, _h_16);
      term_sink(e, _h_19);
      term_sink(e, _h_20);
      term_sink(e, _h_21);
      term_sink(e, _h_23);
      term_sink(e, _h_25);
      term_sink(e, _h_26);
      term_sink(e, _h_27);
      term_sink(e, _h_28);
      term_sink(e, _h_30);
      term_sink(e, _h_32);
      r0 = term_ctr(CID_SCON, STAT_OFF + 144);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_START_K606)
  {
    Term _h_33 = r0;
    Term _h_34 = r1;
    u32 _h_35 = r2;
    u32 _h_36 = r3;
    Term _h_37 = r4;
    Term _h_38 = r5;
    Term _h_39 = r6;
    u32 _h_40 = r7;
    Term _h_41 = r8;
    u32 _h_42 = r9;
    Term _h_43 = r10;
    Term _h_44 = r11;
    Term _h_45 = r12;
    Term _h_46 = r13;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_LOCAL_DRIVER_OBSERVED)) {
      u64 _t_11 = task_node(e, FID_LOCAL_DRIVER_OBSERVED, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = term_clo(FID_LOCAL_DRIVER_START_C607, 0);
      e.mem[_t_11 + 1] = term_ctr(CID_SCON, STAT_OFF + 98);
      e.mem[_t_11 + 2] = _h_33;
      e.mem[_t_11 + 3] = _h_34;
      e.mem[_t_11 + 4] = _h_35;
      e.mem[_t_11 + 5] = _h_36;
      e.mem[_t_11 + 6] = _h_37;
      e.mem[_t_11 + 7] = _h_38;
      e.mem[_t_11 + 8] = _h_39;
      e.mem[_t_11 + 9] = _h_40;
      e.mem[_t_11 + 10] = _h_41;
      e.mem[_t_11 + 11] = _h_42;
      e.mem[_t_11 + 12] = _h_43;
      e.mem[_t_11 + 13] = _h_44;
      e.mem[_t_11 + 14] = _h_45;
      e.mem[_t_11 + 15] = _h_46;
      return term_tsk(FID_LOCAL_DRIVER_OBSERVED, _t_11);
    }
    r0 = term_clo(FID_LOCAL_DRIVER_START_C607, 0);
    r1 = term_ctr(CID_SCON, STAT_OFF + 98);
    r2 = _h_33;
    r3 = _h_34;
    r4 = _h_35;
    r5 = _h_36;
    r6 = _h_37;
    r7 = _h_38;
    r8 = _h_39;
    r9 = _h_40;
    r10 = _h_41;
    r11 = _h_42;
    r12 = _h_43;
    r13 = _h_44;
    r14 = _h_45;
    r15 = _h_46;
    WL_JMP(FID_LOCAL_DRIVER_OBSERVED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_START_C607)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _fb_0[9];
    u64 _sp_0 = ctr_take(e, _x_0, 9, _fb_0);
    Term _f_0 = _fb_0[0];
    Term _f_1 = _fb_0[1];
    Term _f_2 = _fb_0[2];
    u32 _f_3 = _fb_0[3];
    Term _f_4 = _fb_0[4];
    u32 _f_5 = _fb_0[5];
    Term _f_6 = _fb_0[6];
    Term _f_7 = _fb_0[7];
    Term _f_8 = _fb_0[8];
    spare_free(e, cls_fit(9), _sp_0);
    Term _fb_1[2];
    u64 _sp_1 = ctr_take(e, _f_2, 2, _fb_1);
    Term _f_9 = _fb_1[0];
    Term _f_10 = _fb_1[1];
    spare_free(e, cls_fit(2), _sp_1);
    Term _fb_2[6];
    u64 _sp_2 = ctr_take(e, _f_10, 6, _fb_2);
    u32 _f_11 = _fb_2[0];
    u32 _f_12 = _fb_2[1];
    Term _f_13 = _fb_2[2];
    Term _f_14 = _fb_2[3];
    Term _f_15 = _fb_2[4];
    Term _f_16 = _fb_2[5];
    spare_free(e, cls_fit(6), _sp_2);
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LOCAL_DRIVER_START_K608;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_LOCAL_DRIVER_START_K608, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LOCAL_DRIVER_START_K608, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOCAL_FIXTURE_RUN)) {
      u64 _t_7 = task_node(e, FID_LOCAL_FIXTURE_RUN, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _f_0;
      e.mem[_t_7 + 1] = _f_1;
      e.mem[_t_7 + 2] = _f_11;
      e.mem[_t_7 + 3] = _f_12;
      e.mem[_t_7 + 4] = _f_13;
      e.mem[_t_7 + 5] = _f_14;
      e.mem[_t_7 + 6] = _f_15;
      e.mem[_t_7 + 7] = _f_3;
      e.mem[_t_7 + 8] = _f_4;
      e.mem[_t_7 + 9] = _f_5;
      e.mem[_t_7 + 10] = _f_6;
      e.mem[_t_7 + 11] = _f_7;
      e.mem[_t_7 + 12] = _f_8;
      return term_tsk(FID_LOCAL_FIXTURE_RUN, _t_7);
    }
    r0 = _f_0;
    r1 = _f_1;
    r2 = _f_11;
    r3 = _f_12;
    r4 = _f_13;
    r5 = _f_14;
    r6 = _f_15;
    r7 = _f_3;
    r8 = _f_4;
    r9 = _f_5;
    r10 = _f_6;
    r11 = _f_7;
    r12 = _f_8;
    WL_JMP(FID_LOCAL_FIXTURE_RUN);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_START_K608)
  {
    u32 _h_47 = r0;
    Term _h_48 = r1;
    Term _h_49 = r2;
    u32 _h_50 = r3;
    u32 _h_51 = r4;
    Term _h_52 = r5;
    Term _h_53 = r6;
    Term _h_54 = r7;
    u32 _h_55 = r8;
    Term _h_56 = r9;
    u32 _h_57 = r10;
    Term _h_58 = r11;
    Term _h_59 = r12;
    Term _h_60 = r13;
    Term _h_61 = r14;
    u32 _h_62 = r15;
    Term _h_63 = r16;
    u32 _h_64 = r17;
    Term _h_65 = r18;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_LOCAL_DRIVER_START_K609;
      WL_PUSHN(1);
    } else {
      u64 _t_8 = task_node(e, FID_LOCAL_DRIVER_START_K609, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_LOCAL_DRIVER_START_K609, _t_8);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_LOCAL_DRIVER_RETRIED)) {
      u64 _t_9 = task_node(e, FID_LOCAL_DRIVER_RETRIED, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _h_47;
      e.mem[_t_9 + 1] = _h_48;
      e.mem[_t_9 + 2] = _h_49;
      e.mem[_t_9 + 3] = _h_50;
      e.mem[_t_9 + 4] = _h_51;
      e.mem[_t_9 + 5] = _h_52;
      e.mem[_t_9 + 6] = _h_53;
      e.mem[_t_9 + 7] = _h_54;
      e.mem[_t_9 + 8] = _h_55;
      e.mem[_t_9 + 9] = _h_56;
      e.mem[_t_9 + 10] = _h_57;
      e.mem[_t_9 + 11] = _h_58;
      e.mem[_t_9 + 12] = _h_59;
      e.mem[_t_9 + 13] = _h_60;
      e.mem[_t_9 + 14] = _h_61;
      e.mem[_t_9 + 15] = _h_62;
      e.mem[_t_9 + 16] = _h_63;
      e.mem[_t_9 + 17] = _h_64;
      e.mem[_t_9 + 18] = _h_65;
      return term_tsk(FID_LOCAL_DRIVER_RETRIED, _t_9);
    }
    r0 = _h_47;
    r1 = _h_48;
    r2 = _h_49;
    r3 = _h_50;
    r4 = _h_51;
    r5 = _h_52;
    r6 = _h_53;
    r7 = _h_54;
    r8 = _h_55;
    r9 = _h_56;
    r10 = _h_57;
    r11 = _h_58;
    r12 = _h_59;
    r13 = _h_60;
    r14 = _h_61;
    r15 = _h_62;
    r16 = _h_63;
    r17 = _h_64;
    r18 = _h_65;
    WL_JMP(FID_LOCAL_DRIVER_RETRIED);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_LOCAL_DRIVER_START_K609)
  {
    Term _h_66 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_10 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_10 + 0] = term_ctr(CID_SCON, STAT_OFF + 90);
      e.mem[_t_10 + 1] = _h_66;
      return term_tsk(FID_STRING_APPEND, _t_10);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 90);
    r1 = _h_66;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_IO_WITH_NAMESPACE_0_C618)
  {
    u32 _namespace_1 = r0;
    u32 _resource_4 = r1;
    Term _x_2 = r2;
    WL_OPEN
    u32 _v_2 = 0;
    Term _v_3 = 0;
    u32 _v_4 = 0;
    u32 _v_5 = 0;
    Term _v_6 = 0;
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _o_0[1];
    if (spin_30(e, _o_0, U32_BIN(0ull, <, _namespace_1), U32_BIN(_namespace_1, <, 4294967295ull)) == 0) {
      return 0;
    }
    _v_8 = _o_0[0];
    _v_7 = _v_8;
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    Term _v_11 = 0;
    Term _o_1[3];
    if (spin_115(e, _o_1, _v_7, _namespace_1, _resource_4) == 0) {
      return 0;
    }
    _v_9 = _o_1[0];
    _v_10 = _o_1[1];
    _v_11 = _o_1[2];
    _v_4 = _v_9;
    _v_5 = _v_10;
    _v_6 = _v_11;
    u32 _v_12 = 0;
    Term _v_13 = 0;
    Term _o_2[2];
    if (spin_116(e, _o_2, _v_4, _v_5, _v_6, blk_loc(e.mem, _v_6)) == 0) {
      return 0;
    }
    _v_12 = _o_2[0];
    _v_13 = _o_2[1];
    _v_2 = _v_12;
    _v_3 = _v_13;
    Term _b_0 = 0;
    if (_v_2 == 0) {
      u64 _nd_3 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_3 + 0] = rfc_seal(e, _v_3);
      _b_0 = term_ctr(CID__________SRC_ECS_WORLD_IO_CREATED, _nd_3);
    } else {
      u64 _nd_4 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_4 + 0] = rfc_seal(e, _v_3);
      _b_0 = term_ctr(CID__________SRC_ECS_WORLD_IO_REFUSED, _nd_4);
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_0 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _x_2;
      e.mem[_t_0 + 1] = _b_0;
      return term_tsk(FID_CLO_APPLY, _t_0);
    }
    r0 = _x_2;
    r1 = _b_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C620, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C620, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C620)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K621;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K621, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K621, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K621)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    r0 = term_clo(FID_MAIN_C623, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C623)
  {
    Term _x_0 = r0;
    WL_OPEN
    Term _v_0 = 0;
    Term _v_1 = 0;
    Term _o_1[1];
    if (spin_119(e, _o_1, 10ull) == 0) {
      return 0;
    }
    _v_1 = _o_1[0];
    _v_0 = _v_1;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_3 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _v_0;
      e.mem[_t_3 + 1] = term_clo(FID_MAIN_C626, 0);
      e.mem[_t_3 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_3);
    }
    r0 = _v_0;
    r1 = term_clo(FID_MAIN_C626, 0);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_IO_CREATE_0_C624)
  {
    u32 _resource_1 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _resource_1;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_0 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = term_clo(FID__________SRC_ECS_WORLD_NAMESPACE_FRESH, 0);
      e.mem[_t_0 + 1] = term_clo(FID__________SRC_ECS_WORLD_IO_CREATE_0_C625, _nd_1);
      e.mem[_t_0 + 2] = _x_1;
      return term_tsk(FID_IO_BIND, _t_0);
    }
    r0 = term_clo(FID__________SRC_ECS_WORLD_NAMESPACE_FRESH, 0);
    r1 = term_clo(FID__________SRC_ECS_WORLD_IO_CREATE_0_C625, _nd_1);
    r2 = _x_1;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_IO_CREATE_0_C625)
  {
    u32 _resource_2 = r0;
    Term _x_2 = r1;
    WL_OPEN
    Term _v_3 = 0;
    Term _o_0[1];
    if (spin_118(e, _o_0, _x_2, _resource_2) == 0) {
      return 0;
    }
    _v_3 = _o_0[0];
    r0 = _v_3;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C626)
  {
    Term _x_3 = r0;
    WL_OPEN
    u32 _o_2 = 0;
    Term _o_3 = 0;
    if (term_aux(_x_3) == CID__________SRC_ECS_WORLD_IO_CREATED) {
      _o_2 = 0;
      Term _fb_0[1];
      u64 _sp_0 = ctr_take(e, _x_3, 1, _fb_0);
      Term _f_0 = _fb_0[0];
      spare_free(e, cls_fit(1), _sp_0);
      _o_3 = _f_0;
    } else {
      _o_2 = 1;
      Term _fb_1[1];
      u64 _sp_1 = ctr_take(e, _x_3, 1, _fb_1);
      Term _f_1 = _fb_1[0];
      spare_free(e, cls_fit(1), _sp_1);
      _o_3 = _f_1;
    }
    if (_o_2 == 0) {
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_MAIN_K627;
        WL_PUSHN(1);
      } else {
        u64 _t_1 = task_node(e, FID_MAIN_K627, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_MAIN_K627, _t_1);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_LOCAL_DRIVER_START)) {
        u64 _t_2 = task_node(e, FID_LOCAL_DRIVER_START, WL_CONT, WL_IDX, 0);
        e.mem[_t_2 + 0] = _o_3;
        return term_tsk(FID_LOCAL_DRIVER_START, _t_2);
      }
      r0 = _o_3;
      WL_JMP(FID_LOCAL_DRIVER_START);
    } else {
      term_sink(e, _o_3);
      r0 = term_clo(FID_MAIN_C628, 0);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K627)
  {
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_2 + 0] = _h_0;
    r0 = term_clo(FID_IO_PRINT, _nd_2);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C628)
  {
    Term _x_4 = r0;
    WL_OPEN
    Term _v_4 = 0;
    Term _o_4[1];
    Term _a_0 = term_ctr(CID_SCON, STAT_OFF + 272);
    if (spin_117(e, _o_4, 1ull, _a_0, blk_loc(e.mem, _a_0), _x_4, blk_loc(e.mem, _x_4)) == 0) {
      return 0;
    }
    _v_4 = _o_4[0];
    r0 = _v_4;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID__________SRC_ECS_WORLD_NAMESPACE_FRESH)
  {
    Term _k_6 = r0;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _k_6;
    r0 = term_ctr(CID__________SRC_ECS_WORLD_NAMESPACE_FRESH, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_3 = r0;
    Term _k_7 = r1;
    WL_OPEN
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = _text_3;
    e.mem[_nd_7 + 1] = _k_7;
    r0 = term_ctr(CID_IO_PRINT, _nd_7);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 drains each lane's ring,
// pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without).

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0 || n > RING_LEN) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Term r = work_loop(e, io_stk, t, !BANGS && pool_size == 1);
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        u64  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, NULL);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run, u32 need) {
  if (io_eff_rows[cid].run != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = (IoEff){ run, need };
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
    return;
  }
  while (p->next->time - 1 <= w->time - 1) {
    p = p->next;
  }
  io_push(&p, w);
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  u64  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_fail(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  Term t = io_tup(e, code, io_str(e, s, strlen(s)));
  return io_box(e, CID_FAIL, t);
}

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static Term io_exec(Env e, IoWork* w) {
  Term fs[256];
  u32  c = (u32)term_aux(w->cont);
  u32  n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, w->cont, n, fs));
  w->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        printf("%s{", SHOW_NAMES[D[a]]);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    u64  at  = term_peek(e.mem, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      exit((int)(u32)e.mem[at]);
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail("an alien request");
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(a, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return;
    }
    Term x = io_exec(e, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    if ((n & 63) == 0 && io_busy != 0) {
      io_take(e);
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0 && io_park != NULL) {
      u64 now = io_tick();
      if (now >= look || io_park->next->time - 1 < now) {
        look = now + 10000000;
        io_wait(e, false);
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

#include <stdatomic.h>
#include <stdint.h>

// Saturate rather than wrapping or reusing a disposed world's namespace.
static _Atomic uint32_t bendvy_namespace_next = 1;
static Term bendvy_namespace_fresh(Env e, Term* f, IoWork* w) {
  uint32_t old = atomic_load_explicit(&bendvy_namespace_next, memory_order_relaxed);
  while (old < UINT32_MAX) {
    if (atomic_compare_exchange_weak_explicit(&bendvy_namespace_next, &old,
        old + 1, memory_order_relaxed, memory_order_relaxed)) return (Term)old;
  }
  return (Term)0;
}
static void __attribute__((constructor)) bendvy_namespace_use(void) {
  io_eff(CID__________SRC_ECS_WORLD_NAMESPACE_FRESH, bendvy_namespace_fresh, 0);
}
// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    err_fail("--gpu on, but this binary found no usable GPU (a CUDA GPU needs"
      " concurrent managed access, which WSL2's lack)");
  }
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
