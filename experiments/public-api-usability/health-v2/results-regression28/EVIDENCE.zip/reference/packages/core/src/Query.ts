/**
 * Query declarations, matching semantics, and typed cell access surfaces.
 *
 * Queries are the read-side center of ECS gameplay code. They describe which
 * entities a system is allowed to see and exactly which component cells that
 * system may read or write once a match is found.
 *
 * In practice this module answers three different design questions at once:
 *
 * - which entities should this system iterate over
 * - which components prove an entity belongs in that iteration
 * - which slots are readable, writable, or only optionally available
 *
 * Reach for this module whenever game logic needs to iterate entity state,
 * perform host sync from ECS data, or resolve durable handles back into
 * current-world entity proofs.
 *
 * @example
 * ```ts
 * // Describe exactly which entities the movement system may see.
 * const MovingActors = Game.Query({
 *   selection: {
 *     // Writable slots declare mutation capability in the query result.
 *     position: Game.Query.write(Position),
 *     // Read-only slots prove presence without granting mutation.
 *     velocity: Game.Query.read(Velocity),
 *     // Optional slots do not affect matching and must be narrowed explicitly.
 *     sprite: Game.Query.optional(Sprite)
 *   },
 *   // Structural filters describe who participates in the system at all.
 *   with: [Movable],
 *   without: [Frozen]
 * })
 *
 * const MoveActors = Game.System("MoveActors", {
 *   queries: { moving: MovingActors },
 *   resources: { dt: Game.System.readResource(DeltaTime) }
 * }, ({ queries, resources }) => {
 *   const dt = resources.dt.get()
 *
 *   for (const { data } of queries.moving.each()) {
 *     const velocity = data.velocity.get()
 *     data.position.update((position) => ({
 *       x: position.x + velocity.x * dt,
 *       y: position.y + velocity.y * dt
 *     }))
 *
 *     // Optional reads stay explicit at the use site.
 *     if (data.sprite.present) {
 *       void data.sprite.get()
 *     }
 *   }
 * })
 * ```
 *
 * @module Query
 * @docGroup core
 *
 * @groupDescription Namespaces
 * Grouped proof helpers that derive precise component evidence from one query selection.
 *
 * @groupDescription Interfaces
 * Public query contracts for selections, filters, matches, and read/write views.
 *
 * @groupDescription Type Aliases
 * Shared query access, proof, and lifecycle helper types.
 *
 * @groupDescription Functions
 * Query authoring helpers for selecting components and declaring explicit filters.
 */
import type { DecodeError } from "./Decode.ts"
import type { Descriptor, StateValue } from "./Descriptor.ts"
import type { EntityId, EntityMut, EntityRef } from "./Entity.ts"
import type * as Result from "./Result.ts"
import type * as Relation from "./Relation.ts"
import type { Schema } from "./Schema.ts"

type ComponentDescriptor = Descriptor<"component", string, any>

/**
 * Query declarations and typed query result cells.
 *
 * Queries are the main way systems gain typed entity access. A query spec is
 * fully explicit:
 *
 * - `selection` declares readable and writable slots
 * - `with` / `without` refine structural matching
 * - `added` / `changed` refine matching to changes since the system's previous run
 * - relation filters refine matching using explicit relation state
 *
 * The key mental model is that query matching is separate from the cell API:
 * required slots affect matching, while `optional(...)` does not.
 *
 * @example
 * ```ts
 * const Moving = Game.Query({
 *   selection: {
 *     position: Game.Query.write(Position),
 *     velocity: Game.Query.read(Velocity),
 *     sprite: Game.Query.optional(Sprite)
 *   },
 *   with: [Position, Velocity]
 * })
 * ```
 */

/**
 * A read access declaration for a descriptor.
 *
 * Read accesses allow systems to observe data without gaining mutation
 * capability in the resulting query or view type.
 */
export interface ReadAccess<D extends ComponentDescriptor> {
  /**
   * Distinguishes read access from write access at both type and runtime level.
   */
  readonly mode: "read"
  /**
   * The descriptor being accessed.
   */
  readonly descriptor: D
}

/**
 * A write access declaration for a descriptor.
 *
 * Write accesses produce writable cells and mutable entity proofs.
 */
export interface WriteAccess<D extends ComponentDescriptor> {
  /**
   * Distinguishes write access from read access at both type and runtime level.
   */
  readonly mode: "write"
  /**
   * The descriptor being accessed.
   */
  readonly descriptor: D
}

/**
 * Any supported query access declaration.
 */
export interface OptionalReadAccess<D extends ComponentDescriptor> {
  /**
   * Distinguishes maybe-present reads from required reads.
   */
  readonly mode: "optional"
  /**
   * The component descriptor being accessed.
   */
  readonly descriptor: D
}

export type Access<D extends ComponentDescriptor> =
  | ReadAccess<D>
  | WriteAccess<D>
  | OptionalReadAccess<D>

export type SelectionAccess<
  S extends Schema.Any = Schema.Any,
  Root = unknown
> = Access<ComponentDescriptor> | Relation.SelectionAccess<S, Root>

/**
 * A filter that matches entities whose component was added since the reading
 * system's previous run.
 */
export interface AddedFilter<D extends ComponentDescriptor> {
  readonly kind: "added"
  readonly descriptor: D
}

/**
 * A filter that matches entities whose component was added or written since
 * the reading system's previous run.
 */
export interface ChangedFilter<D extends ComponentDescriptor> {
  readonly kind: "changed"
  readonly descriptor: D
}

export type Filter<D extends ComponentDescriptor> =
  | AddedFilter<D>
  | ChangedFilter<D>

/**
 * Declares read-only access to a component in a query selection.
 *
 * A required read slot is both a matching requirement and a typing decision:
 * the entity must have that component, and the resulting slot becomes a
 * `ReadCell`. Use this for data the system needs to inspect but must not
 * mutate.
 */
export const read = <D extends ComponentDescriptor>(descriptor: D): ReadAccess<D> => ({
  mode: "read",
  descriptor
})

/**
 * Declares writable access to a component in a query selection.
 *
 * Use this when the system is responsible for mutating component state in
 * place. A write slot both requires component presence and exposes the slot as
 * a `WriteCell`, so mutation capability stays visible in the query spec rather
 * than appearing ad hoc in the loop body.
 */
export const write = <D extends ComponentDescriptor>(descriptor: D): WriteAccess<D> => ({
  mode: "write",
  descriptor
})

/**
 * Declares maybe-present read-only access to a component in a query
 * specification.
 *
 * `optional(...)` is for enrichment, not matching. It keeps the entity set
 * broad while letting one system opportunistically read extra data when
 * present. The returned cell forces an explicit `present` check before use, so
 * the possibility of absence remains visible in the type surface.
 *
 * @example
 * ```ts
 * // Keep the main query focused on movers, but read sprite data when available.
 * const query = Game.Query({
 *   selection: {
 *     position: Game.Query.read(Position),
 *     sprite: Game.Query.optional(Sprite)
 *   }
 * })
 * ```
 */
export const optional = <D extends ComponentDescriptor>(descriptor: D): OptionalReadAccess<D> => ({
  mode: "optional",
  descriptor
})

/**
 * Declares a filter that matches components added since the reading system's
 * previous run.
 *
 * Change detection is per system: every system sees each addition exactly
 * once, on its first run after the addition, independently of other systems.
 * A system's first run sees every existing component as added. This is the
 * usual entrypoint for incremental host sync, such as creating renderer nodes.
 *
 * @example
 * ```ts
 * const AddedRenderableQuery = Game.Query({
 *   selection: {
 *     position: Game.Query.read(Position),
 *     renderable: Game.Query.read(Renderable)
 *   },
 *   filters: [Game.Query.added(Renderable)]
 * })
 * ```
 */
export const added = <D extends ComponentDescriptor>(descriptor: D): AddedFilter<D> => ({
  kind: "added",
  descriptor
})

/**
 * Declares a filter that matches components added or written since the
 * reading system's previous run.
 *
 * Any write through a write cell counts, even when the value is equal to the
 * previous one. Writes from a system whose run failed are rolled back and do
 * not count.
 *
 * @example
 * ```ts
 * const MovedQuery = Game.Query({
 *   selection: {
 *     position: Game.Query.read(Position)
 *   },
 *   filters: [Game.Query.changed(Position)]
 * })
 * ```
 */
export const changed = <D extends ComponentDescriptor>(descriptor: D): ChangedFilter<D> => ({
  kind: "changed",
  descriptor
})

/**
 * A fully explicit query specification.
 *
 * Queries describe exactly which components are read or written, plus optional
 * `with` and `without` filters. They are the source of typed entity proofs.
 */
export interface QuerySpec<
  out Selection extends Record<string, SelectionAccess<any, Root>>,
  out With extends ReadonlyArray<ComponentDescriptor> = [],
  out Without extends ReadonlyArray<ComponentDescriptor> = [],
  out Filters extends ReadonlyArray<Filter<ComponentDescriptor>> = [],
  out WithRelations extends ReadonlyArray<Relation.Relation.Any> = [],
  out WithoutRelations extends ReadonlyArray<Relation.Relation.Any> = [],
  out WithRelated extends ReadonlyArray<Relation.Relation.Any> = [],
  out WithoutRelated extends ReadonlyArray<Relation.Relation.Any> = [],
  Root = unknown
> {
  /**
   * Named access slots that become typed cells in query results.
   */
  readonly selection: Selection
  /**
   * Components that must be present for an entity to match.
   */
  readonly with: With
  /**
   * Components that must be absent for an entity to match.
   */
  readonly without: Without
  /**
   * Change filters that refine matching relative to the reading system's previous run.
   */
  readonly filters: Filters
  /**
   * Relations that must be present on the entity as outgoing edges.
   */
  readonly withRelations: WithRelations
  /**
   * Relations that must be absent on the entity as outgoing edges.
   */
  readonly withoutRelations: WithoutRelations
  /**
   * Reverse relation collections that must be present and non-empty.
   */
  readonly withRelated: WithRelated
  /**
   * Reverse relation collections that must be absent or empty.
   */
  readonly withoutRelated: WithoutRelated
  /**
   * Hidden schema-root brand used by schema-bound APIs.
   */
  readonly __schemaRoot?: Root | undefined
}

/**
 * Type-level helpers for queries.
 */
export namespace Query {
  /**
   * A non-empty readonly array.
   */
  export type NonEmptyReadonlyArray<T> = readonly [T, ...T[]]

  /**
   * Any supported query specification.
   */
  export type Any<Root = unknown> = QuerySpec<
    Record<string, SelectionAccess<any, Root>>,
    ReadonlyArray<ComponentDescriptor>,
    ReadonlyArray<ComponentDescriptor>,
    ReadonlyArray<Filter<ComponentDescriptor>>,
    ReadonlyArray<Relation.Relation.Any>,
    ReadonlyArray<Relation.Relation.Any>,
    ReadonlyArray<Relation.Relation.Any>,
    ReadonlyArray<Relation.Relation.Any>,
    Root
  >

  /**
   * Extracts the schema-root brand carried by one query.
   */
  export type Root<T extends Any> = T extends QuerySpec<any, any, any, any, any, any, any, any, infer R> ? R : never

  type RequiredSelectionDescriptors<T extends Any> = {
    readonly [K in keyof T["selection"]]:
      T["selection"][K] extends ReadAccess<infer D> | WriteAccess<infer D> ? D : never
  }[keyof T["selection"]]

  /**
   * Whether one query statically proves the presence of a component descriptor.
   *
   * This is used by durable-handle resolution so intent-qualified handles can
   * only be resolved with queries that actually prove the intended role.
   */
  export type ProvesComponent<
    T extends Any,
    D extends ComponentDescriptor
  > = [Extract<RequiredSelectionDescriptors<T> | T["with"][number], D>] extends [never]
    ? false
    : true

  /**
   * The readable proof produced by a query.
   */
  export type ReadProof<T extends Any> = {
    readonly [K in keyof T["selection"] as
      T["selection"][K] extends OptionalReadAccess<any> | Relation.SelectionAccess<any, any> ? never
      : T["selection"][K] extends Access<any> ? K
      : never]:
      T["selection"][K] extends Access<infer D> ? ReadonlyValue<Descriptor.Value<D>> : never
  }

  /**
   * The writable proof produced by a query.
   */
  export type WriteProof<T extends Any> = {
    readonly [K in keyof T["selection"] as
      T["selection"][K] extends WriteAccess<any> ? K : never]:
      T["selection"][K] extends WriteAccess<infer D> ? ReadonlyValue<Descriptor.Value<D>> : never
  }

  /**
   * The per-slot cell API derived from a query.
   */
  export type Cells<T extends Any> = {
    readonly [K in keyof T["selection"]]:
      T["selection"][K] extends ReadAccess<infer D> ? ReadCell<Descriptor.Value<D>>
      : T["selection"][K] extends OptionalReadAccess<infer D> ? OptionalReadCell<Descriptor.Value<D>>
      : T["selection"][K] extends WriteAccess<infer D> ? WriteCellForDescriptor<D>
      : T["selection"][K] extends Relation.RelationReadAccess<any, infer S extends Schema.Any, infer Root> ? ReadCell<EntityId<S, Root>>
      : T["selection"][K] extends Relation.OptionalRelationReadAccess<any, infer S extends Schema.Any, infer Root> ? OptionalReadCell<EntityId<S, Root>>
      : T["selection"][K] extends Relation.RelatedReadAccess<any, infer S extends Schema.Any, infer Root> ? ReadCell<ReadonlyArray<EntityId<S, Root>>>
      : T["selection"][K] extends Relation.OptionalRelatedReadAccess<any, infer S extends Schema.Any, infer Root> ? OptionalReadCell<ReadonlyArray<EntityId<S, Root>>>
      : never
  }

  /**
   * Entity lookup failed because the entity id is not currently alive.
   */
  export interface MissingEntityError {
    readonly _tag: "MissingEntity"
    readonly entityId: number
  }

  /**
   * Entity lookup failed because the entity does not satisfy the query.
   */
  export interface QueryMismatchError {
    readonly _tag: "QueryMismatch"
    readonly entityId: number
  }

  /**
   * A query expected one result, but matched none.
   */
  export interface NoEntitiesError {
    readonly _tag: "NoEntities"
  }

  /**
   * A query expected one result, but matched multiple.
   */
  export interface MultipleEntitiesError {
    readonly _tag: "MultipleEntities"
    readonly count: number
  }

  /**
   * Errors produced by exact entity lookup helpers.
   */
  export type LookupError = MissingEntityError | QueryMismatchError

  /**
   * Errors produced by exact-one query helpers.
   */
  export type SingleError = NoEntitiesError | MultipleEntitiesError
}

/** Deep read projection used by every ECS read capability. */
export type ReadonlyValue<T> =
  T extends string | number | boolean | bigint | symbol | null | undefined ? T
  : T extends (...args: ReadonlyArray<any>) => any ? T
  : T extends ReadonlyMap<infer Key, infer Value> ? ReadonlyMap<ReadonlyValue<Key>, ReadonlyValue<Value>>
  : T extends ReadonlySet<infer Value> ? ReadonlySet<ReadonlyValue<Value>>
  : T extends readonly unknown[] ? { readonly [K in keyof T]: ReadonlyValue<T[K]> }
  : T extends object ? { readonly [K in keyof T]: ReadonlyValue<T[K]> }
  : T

/**
 * A read-only cell returned from query or resource access.
 *
 * Object and collection values are deeply readonly so in-place mutation cannot
 * bypass lifecycle tracking, validation, or a system transaction.
 */
export interface ReadCell<T> {
  /**
   * Reads the current value.
   */
  get(): ReadonlyValue<T>
}

/**
 * A mutable cell returned from query or resource access.
 *
 * This gives a narrow mutation surface instead of exposing raw storage objects.
 */
export interface WriteCell<T> extends ReadCell<T> {
  /**
   * Replaces the current value.
   */
  set(value: T): void
  /**
   * Replaces the current value from an explicit result.
   */
  setResult<E>(result: Result.Result<T, E>): Result.Result<void, E>
  /**
   * Updates the current value based on the previous one.
   */
  update(f: (current: ReadonlyValue<T>) => T): void
  /**
   * Updates the current value from an explicit result-producing callback.
   */
  updateResult<E>(f: (current: ReadonlyValue<T>) => Result.Result<T, E>): Result.Result<void, E>
}

/**
 * Writable cell for data backed by a constructed descriptor.
 *
 * This extends the normal write-cell surface with explicit raw-validation
 * helpers. It never appears for plain descriptors.
 */
export interface ConstructedWriteCell<T, Raw, Error> extends WriteCell<T> {
  /**
   * Validates one raw candidate and writes it only on success.
   *
   * @example
   * ```ts
   * data.position.setRaw({ x: 16, y: 24 })
   * ```
   */
  setRaw(raw: Raw): Result.Result<void, Error>
  /**
   * Derives one raw candidate from the current value, validates it, and writes
   * it only on success.
   *
   * @example
   * ```ts
   * data.position.updateRaw((position) => ({
   *   x: position.x + 1,
   *   y: position.y
   * }))
   * ```
   */
  updateRaw(f: (current: ReadonlyValue<T>) => Raw): Result.Result<void, Error>
}

/**
 * A `transition(from, to)` found the state component in another state, so
 * nothing was written.
 */
export interface StateMismatchError<T> {
  readonly _tag: "StateMismatch"
  /** Name of the state component. */
  readonly state: string
  /** The `from` state the transition expected. */
  readonly expected: T
  /** The state the component was actually in. */
  readonly actual: T
}

/**
 * Writable cell for a state component (`Descriptor.State`).
 *
 * `transition(from, to)` is a compare-and-set: it writes `to` only while the
 * current state is `from`, and otherwise returns `StateMismatch` without
 * writing. With a transition graph, `to` must be one of the moves the graph
 * allows from `from`; without one, any pair of states is accepted.
 */
export interface StateWriteCell<T, Transitions> extends ConstructedWriteCell<T, T, DecodeError> {
  /**
   * Moves from `from` to `to` if the component is still in `from`.
   *
   * @example
   * ```ts
   * const moved = data.phase.transition("windup", "active")
   * if (!moved.ok) {
   *   // moved.error.actual is the state some earlier write left
   * }
   * ```
   */
  transition<const From extends T & keyof Transitions>(
    from: From,
    to: StateTarget<T, Transitions, From>
  ): Result.Result<void, StateMismatchError<T>>
}

type StateTarget<T, Transitions, From extends keyof Transitions> =
  Transitions[From] extends ReadonlyArray<infer To> ? To & T : never

/**
 * Write-cell surface produced for one queried component descriptor.
 */
export type WriteCellForDescriptor<D extends ComponentDescriptor> =
  D extends import("./Descriptor.ts").StateDescriptor<string, infer States extends readonly [StateValue, ...Array<StateValue>], any>
    ? StateWriteCell<States[number], D["transitions"] extends undefined ? { readonly [K in States[number]]: States } : D["transitions"]>
    : D extends import("./Descriptor.ts").ConstructedDescriptor<"component", string, infer Value, infer Raw, infer Error>
    ? ConstructedWriteCell<Value, Raw, Error>
    : WriteCell<Descriptor.Value<D>>

/**
 * Present branch for a maybe-present query slot.
 */
export interface PresentOptionalReadCell<T> extends ReadCell<T> {
  readonly present: true
}

/**
 * Absent branch for a maybe-present query slot.
 */
export interface AbsentOptionalReadCell {
  readonly present: false
}

/**
 * A query slot that may or may not be present on the matched entity.
 *
 * Callers must narrow on `present` before reading the value.
 */
export type OptionalReadCell<T> = PresentOptionalReadCell<T> | AbsentOptionalReadCell

/**
 * The typed item returned by iterating a query handle.
 *
 * If the query contains at least one write access, the entity proof is mutable.
 * Otherwise it remains read-only.
 */
export type QueryMatch<S extends Schema.Any, Q extends Query.Any> =
  keyof Query.WriteProof<Q> extends never
    ? {
        readonly entity: EntityRef<S, Query.ReadProof<Q>, Query.Root<Q>>
        readonly data: Query.Cells<Q>
      }
    : {
        readonly entity: EntityMut<S, Query.ReadProof<Q>, Query.WriteProof<Q>, Query.Root<Q>>
        readonly data: Query.Cells<Q>
      }

/**
 * Creates a typed missing-entity error.
 */
export const missingEntityError = (entityId: number): Query.MissingEntityError => ({
  _tag: "MissingEntity",
  entityId
})

/**
 * Creates a typed query-mismatch error.
 */
export const queryMismatchError = (entityId: number): Query.QueryMismatchError => ({
  _tag: "QueryMismatch",
  entityId
})

/**
 * Creates a typed zero-match error.
 */
export const noEntitiesError = (): Query.NoEntitiesError => ({
  _tag: "NoEntities"
})

/**
 * Creates a typed multi-match error.
 */
export const multipleEntitiesError = (count: number): Query.MultipleEntitiesError => ({
  _tag: "MultipleEntities",
  count
})

/**
 * Creates an explicit query specification.
 *
 * Use this inside system specs instead of relying on callback parameter
 * inference. The resulting value drives both runtime execution and the derived
 * query result type.
 *
 * A query spec is purely declarative. It does not access the world by itself;
 * systems receive `QueryHandle`s derived from the spec. In practice this is
 * where you encode the exact shape of one gameplay iteration pass.
 *
 * @example
 * ```ts
 * // Define one reusable iteration contract for a movement system.
 * const Moving = Game.Query({
 *   selection: {
 *     position: Game.Query.write(Position),
 *     velocity: Game.Query.read(Velocity)
 *   },
 *   with: [Position, Velocity],
 *   without: [Sleeping]
 * })
 * ```
 */
export const Query = <
  const Selection extends Record<string, SelectionAccess<any, Root>>,
  const With extends ReadonlyArray<ComponentDescriptor> = [],
  const Without extends ReadonlyArray<ComponentDescriptor> = [],
  const Filters extends ReadonlyArray<Filter<ComponentDescriptor>> = [],
  const WithRelations extends ReadonlyArray<Relation.Relation.Any> = [],
  const WithoutRelations extends ReadonlyArray<Relation.Relation.Any> = [],
  const WithRelated extends ReadonlyArray<Relation.Relation.Any> = [],
  const WithoutRelated extends ReadonlyArray<Relation.Relation.Any> = [],
  Root = unknown
>(spec: {
  readonly selection: Selection
  readonly with?: With
  readonly without?: Without
  readonly filters?: Filters
  readonly withRelations?: WithRelations
  readonly withoutRelations?: WithoutRelations
  readonly withRelated?: WithRelated
  readonly withoutRelated?: WithoutRelated
}): QuerySpec<Selection, With, Without, Filters, WithRelations, WithoutRelations, WithRelated, WithoutRelated, Root> => ({
  selection: spec.selection,
  with: (spec.with ?? []) as With,
  without: (spec.without ?? []) as Without,
  filters: (spec.filters ?? []) as Filters,
  withRelations: (spec.withRelations ?? []) as WithRelations,
  withoutRelations: (spec.withoutRelations ?? []) as WithoutRelations,
  withRelated: (spec.withRelated ?? []) as WithRelated,
  withoutRelated: (spec.withoutRelated ?? []) as WithoutRelated,
  __schemaRoot: undefined as unknown as Root
})
